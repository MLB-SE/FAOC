import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0.0,0.04267253659827727,-91.86871690080199,100.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-85.0889522841893,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(10.257956359554015,-6.271176178698724,2.9154768318608006,87.81383644803748,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(10.847939162075395,42.4746750119716,139.89548075216317,-145.38575434438314,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(11.193847713496524,-1.231163140365041,30.732194331721587,33.293462910538835,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(11.658108064476977,-4.069026153525584,17.935704600133604,-26.658858710935917,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(12.387948365940687,-3.4349038677770096,85.23754159537512,84.4662727582074,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(12.443377924582052,-4.853532291500869,4.691151256247991,-99.6224418098429,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(1.2446378564143146,-0.30882327094114714,18.52606112809434,-25.804040129720036,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(12.79337464930994,-2.107136555753627,9.937753722058758,-11.235577751341069,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(12.956457068222477,-3.577237812426688,72.10897580781165,-35.445478434489914,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(13.037120879122412,-6.4851880902160985,15.238841423446686,-83.62830541908288,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(13.191567888129583,-6.0238161482783,51.52763696049465,-90.98666742445778,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(13.205870964342921,-4.4660499038675,56.31914128165147,-24.502469025255664,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(13.286640657774512,-14.664679438158657,87.59249161613567,-43.722158392176965,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(13.369280004209955,-4.562678486471071,42.07150827342005,90.7413955791991,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(-13.469850554816887,12.871297656973368,-60.75511315266861,-13.039582976620622,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(13.686917987745744,-10.422086837215701,6.693551773109036,-58.98338316275387,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(13.758245078126379,-12.002720385391626,-24.40634153988681,-49.382123473275016,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(1.3840944070417556,-4.26239470782443E-255,92.9775210429284,67.28759155511658,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(14.559527798243366,-14.442670595442266,59.04134735023172,-25.72162339771276,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(14.60893054405281,-6.9350481439578004,66.8197404178888,-81.41230260539376,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(14.612811994925707,-16.412654366682972,80.63772967070224,-25.873141051249874,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(14.792352268894177,-6.911016328247314,86.8292385159865,70.50190798382917,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(15.221015859481852,-6.357061701955246,45.9571742534028,-62.23642880687596,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(15.4084806409017,-12.763062919333805,34.44786620265117,86.58486398349726,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(15.566773404871498,-6.614099885785166,50.03060144948907,-52.66428651795083,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(15.58625362519173,-10.024894600566768,33.30938828237521,79.07767756794988,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(15.758923838250155,-1.055038812495269,45.00499424193896,-76.73655716518302,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(15.814326111697213,-4.5521932871747595,46.571691968922494,76.99624343874225,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark63(15.85227260252249,-4.6080772253096995,93.76989839234781,94.82195237713745,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark63(15.910120375936756,-14.131659733838546,4.59306059247308,-21.83413369313405,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark63(16.036728006415174,-5.209217602237786,32.89936385400989,82.09844119341477,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark63(16.083981337387442,-9.597874051014912,61.34239781345889,-88.62969359051107,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark63(16.128039004858437,-22.51929846604112,-89.35834627820083,10.500764282226967,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark63(16.142527441927683,-11.670083122728812,50.53491871887002,-52.9208816197249,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark63(16.143432083278014,-13.514328297028982,-13.52693505893005,-21.96262650884111,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark63(16.185092667603,-7.577427322705361,49.53367350091702,-2.996290250436303,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark63(16.188391988543202,-5.477949614861274,-4.050381880679652,16.94795389565016,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark63(16.34555075596434,-1.3344024548655966,66.55777719575124,22.95828861252059,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark63(16.400424197761467,-10.467260131518216,19.979909910322746,-63.07488073936476,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark63(16.437790035393206,-4.705836103226659,9.370974647139604,6.416466924780735,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark63(16.514415494849672,-14.610401208893137,38.58352964249818,-23.61970871974819,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark63(16.735803097058337,-30.19797383375318,-83.1964095708344,3.748871294729028,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark63(16.865240204545543,-6.549810063855773,-1.8476223953598776,-37.184246640779904,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark63(1.6959915550646372,-83.7368345270952,-98.94787054639768,0.21252368090445373,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark63(17.05335726645683,-0.6893355033699748,12.753987903919324,-17.739024175794654,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark63(17.15127996258829,-2.6252792015384045,88.29350126523252,70.1722107395168,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark63(17.167572827018375,-13.100516647227863,12.405491622785163,14.674628841814851,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark63(17.172536892967003,-22.413592392588114,86.49420434392707,-7.465207578725554,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark63(17.264201655797052,-8.43375708663126,58.85337398844456,-64.68348700247195,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark63(17.292960640484907,-4.190147264284221,11.17462676262133,-65.14634865140849,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark63(17.322337646244492,-8.170248849133245,-21.610599146626484,-28.89155432427617,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark63(17.537534450217734,-11.23046076701739,72.67204780809158,-33.658162159996934,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark63(17.690256902252628,-0.3679126679137994,46.30121016669176,47.411157469239186,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark63(17.801260296669795,-4.731500611656486,76.72555202111619,73.31643015289976,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark63(17.801601535916348,-2.704052882245847,34.252621961221365,-4.46748349240076,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark63(17.809990763454493,-26.178246687932074,-23.082705347419008,1.67285218783762,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark63(17.827777384599088,-5.176152725762336,87.42573789623606,-24.394768349009382,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark63(17.861810599999245,-15.833019005911382,29.114413966500592,-96.6496407614807,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark63(17.96293290916185,-5.7258856336907655,22.02989325142451,29.73515363056663,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark63(18.009061659077858,-7.612199020908122,41.36697978262413,-90.02912847414994,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark63(18.10177391200567,-16.910835419783155,-62.237652579842106,-71.97036699364216,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark63(18.105693332770628,-13.335217820947022,29.281237773595933,-79.42686965015412,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark63(18.235309212339374,81.48073100804245,-61.09441083824081,-17.07710452132929,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark63(18.274291149776303,-14.44298404661501,32.93009801647173,86.64941723629548,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark63(18.546734606579946,-11.479722997742712,12.92417857081682,96.01747943061349,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark63(18.602751311126255,-16.759655389058707,64.39620305062508,-8.489174202627098,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark63(18.635215797038327,-13.20254930032634,-43.330581840545726,-30.842478943120938,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark63(18.708658611253398,-15.813630844833696,-46.966731595069476,-63.10930331670339,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark63(18.857623229619747,-12.295998350791919,85.79831178736461,31.37123539992055,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark63(18.870891821179356,-12.65606359781502,70.32327611872401,-10.889725165215495,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark63(18.93699552310551,-0.6115769997990554,86.71558904905976,-84.74589969309754,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark63(19.031774379366723,-6.112255455718781,82.61345409480205,-82.07782045861552,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark63(19.331139980365037,-11.726334023119534,-26.050545274065612,46.009790568660236,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark63(20.024146787416996,-4.446635958953522,48.187978077955904,-53.89352575785254,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark63(20.052323866331335,-44.19258316758958,57.6715584524878,-2.078870227694239,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark63(20.12399140999746,-21.22516556246876,54.43263897111237,-9.675130646850505,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark63(20.227836656357482,-51.43653002073756,85.05831123950378,-2.183484315479518,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark63(20.5931586636473,-15.023202193057017,50.18466819589588,-8.20029429227236,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark63(20.622035325387003,-4.769352212970674,49.0817565631483,80.32620886410172,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark63(20.77552114975603,-9.92077456628921,55.08963360289695,16.77080894320457,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark63(20.8757440880093,-9.642072891428583,98.21406958158337,20.535393196136283,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark63(20.938638415672074,-6.458897851416623,69.6443090946517,84.53798914276737,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark63(21.106947528327026,-8.136665959155337,98.6754161038553,27.769478205086884,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark63(21.178689617890228,-14.047191286711907,-14.08159110328944,10.821916824847804,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark63(21.33788555107961,-19.978555785242193,4.850826285267161,-20.443517150338337,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark63(21.372308543670513,-0.2319264408132966,95.33346086283734,10.900352385579708,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark63(21.398053599615267,-8.096693841380471,-2.328908045608884,31.26680716201119,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark63(21.563274578421513,-16.657377982533305,96.25210657539591,-29.978336605485765,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark63(21.73847777102786,-14.077540742033847,78.7748047398558,-63.91700428082396,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark63(21.785249874201142,-18.033348872868203,88.27259169103246,-30.99595519731521,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark63(21.821318491027725,-10.191612358605994,96.25692180616215,-65.12704387143604,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark63(21.92665392086414,-17.668992385918727,-34.664964316826314,71.00444009572752,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark63(22.13930024609094,-10.661485978355586,22.741260436351496,-12.732707159269978,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark63(22.248589367551702,-17.74314420624468,-11.526700037465403,-73.30677289023487,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark63(22.312680180686158,-19.879826103141298,-12.574561512843928,-91.54785787575297,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark63(22.405889320031847,-4.818415916277033,45.36982741310652,50.93086388327194,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark63(22.513426887698103,-4.08870483413925,55.62637719260846,-57.74643118005025,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark63(22.516030682772012,-17.297605908724904,-4.545007553590267,66.60442082761455,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark63(22.644718529489836,-22.0723859205236,-6.227456733059427,-16.016579993127507,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark63(22.671244655525086,-11.890571694350214,18.766932780903844,59.643941430441885,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark63(22.771837107374182,-1.6515334149384415,16.084313846724115,-80.03276213025086,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark63(22.826963244060636,-13.162756666873051,34.10634288219012,-23.961822875138196,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark63(22.837214616591027,-1.7451323993696803,35.33408710632074,7.630009264882688,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark63(22.857322054467005,-1.5080913137340985,65.343716513597,-41.88027362496025,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark63(23.183508072113185,-14.159571556858367,56.60155085107456,-65.6623197298811,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark63(23.202600346505477,-17.068804062836392,92.52480904971247,76.23675591530002,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark63(23.244552874613262,-0.04163981553648455,19.72860452945322,-18.819887746119292,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark63(23.361032178411918,-21.569861110294,7.963856641799509,-4.059653876075203,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark63(23.389399457268183,-15.00689987060224,-1.284694254176074,93.55499439100896,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark63(23.41698088874405,-8.906878978116907,96.97411113252468,97.22815464930582,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark63(23.449250661894112,-7.159777606463564,26.545686271332585,-31.612860347433426,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark63(23.555678136755944,-18.007642392128048,-61.30616713693715,-61.15352741691711,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark63(23.819747254690867,-9.891011269479662,53.97154313516336,57.31570639929029,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark63(23.84972018595188,-17.712583940909354,-85.17969120848407,-81.1951420037282,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark63(23.85061359252991,-7.703575950072874,-35.472044662945464,-52.42513208232587,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark63(23.873173588334765,-22.98547641679764,-35.11281898986654,81.27700085086903,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark63(23.900442682085085,-45.20496478155107,-97.7243048646123,3.514923317563216,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark63(23.909656208785336,-25.839816497150153,-89.09764737104445,18.2088827865432,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark63(23.967011478046985,-13.713551299300164,73.20206540249092,-78.23847976452198,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark63(23.976574289780103,-18.964813165460058,57.13675920250307,41.51004738252263,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark63(23.98787602637566,-5.223831850423679,91.17880986949066,-41.62361705321484,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark63(23.989144790735324,-16.987964190991107,-15.719935196430427,17.27854811558997,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark63(24.022087548675387,-25.156781515471323,-96.39701166622324,2.09145038677876,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark63(24.072246724637836,-20.92028362475584,-16.56510809250659,-76.87370339510346,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark63(24.16281939346146,-5.218436949195265,15.463446742030513,61.265242527857595,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark63(24.168932423979612,-16.589551676583596,-79.99435742530471,-42.40726667128038,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark63(24.260282579913465,-21.18619531169479,13.556431814799524,-57.70522803141809,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark63(24.420259846872057,-8.505561767583785,60.153952742752324,44.69430168513662,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark63(24.568038767362395,-14.009168259445133,43.98202425467403,-69.02277823336509,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark63(24.585730944434104,-21.474994526152912,-71.31683042877629,49.849613273819784,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark63(24.594295235168545,-0.972128467421058,49.20839597171502,-62.46901810950158,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark63(24.617603188237652,-24.642074354108573,86.94257900712438,-26.534742939780045,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark63(24.640158121575112,-1.1493979074931815,65.1099076737778,-79.93226494464116,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark63(24.76477166498337,-4.541216938746089,7.38203578117222,-93.55720853049976,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark63(24.928553771176894,-9.449046296772792,17.63226679429455,-94.3844476219938,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark63(25.073009391911242,-18.81261279917439,41.625973808326165,-61.77761843963956,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark63(25.12827125287677,-17.355542343601442,-23.218424725408866,-22.534455325457415,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark63(25.150368113932828,-2.2032048818332157,22.600882400436845,39.23646553278871,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark63(25.18347389419435,-24.31145578516407,-20.047331236224323,98.57348289863708,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark63(25.197174096745755,-4.1001852795312175,68.00658845797562,-52.956561423000224,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark63(2.521189735057855,-9.860761315262648E-32,43.09221247034728,95.21571948024496,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark63(25.23641044089085,-7.483085549549173,-12.020851972797516,10.283157117175222,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark63(25.243952960925654,-20.18034355549736,3.637333833836891,-93.55121658122061,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark63(25.350132489429285,-15.54696658468771,72.56569716874355,25.131783107186692,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark63(25.427514435496576,-9.90820741288907,22.696100813174837,86.10808316471434,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark63(25.49598999024498,-22.99055115458239,-53.590963217667365,-22.7383093107413,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark63(25.530605698120496,-14.78359869345394,84.92627818159684,-45.87435261458539,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark63(25.556689688360294,-24.132697034576523,-20.98388050045355,53.152365443960264,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark63(25.56965463610193,-25.131314742644378,52.66722723342633,-88.90148221615846,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark63(25.626147282088056,-6.2559412415956075,-6.813792264329052,-87.13207389538091,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark63(25.660485120415302,-21.25431742546155,-60.94829888628701,-59.53614841848327,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark63(25.693505851615384,-28.920266276328576,-73.28931640053058,19.570847754158052,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark63(25.755470402669317,-11.11996791980117,8.305685065255574,-86.9629290690294,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark63(25.79653363011063,-7.8668605373392495,-36.76097321176557,14.765488009839316,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark63(25.80007260151247,-25.44989910153754,91.81879044033394,-40.997699300247746,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark63(25.873620340364,-30.054608192285855,-96.08537698808375,10.587416662192894,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark63(26.111280288772747,-78.81810361652741,75.7042553751113,-1.3026845135893694,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark63(26.143118463638615,-1.0418839499773895,37.75793054287544,-36.83307122864947,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark63(26.2042159373173,-14.950326383982059,70.56437985649924,-86.14092165927521,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark63(26.233671416353005,-0.041388207776307695,29.19042489230671,-43.62578285709222,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark63(26.26710245737523,-15.240184327489885,11.825868984486547,-69.43675561139335,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark63(26.301694182708403,-15.376967664274318,93.70391530772397,-71.70408024235363,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark63(26.35519787949731,-11.237044129477283,12.054075309714278,37.133519547600486,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark63(26.467149409446165,-2.7801442934305243,16.155466450452806,-87.72870283210901,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark63(26.485207290954378,-15.873040698793204,-26.790351542264418,-94.83124426987068,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark63(26.703132278974493,-16.940497162642316,95.66960262771153,-16.440708210267175,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark63(26.75147086481803,-14.244441721328798,8.507430984044689,90.61262539401679,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark63(26.752563046174032,-3.0848133144131964,7.416992965557114,93.78076326765816,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark63(26.834529988166793,-14.503968366209278,87.58234785695714,89.99466086587239,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark63(26.94700122056564,-26.975750659228254,-53.89468684427221,18.66476028565299,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark63(27.161430245310683,-15.713134654346206,-76.75517287176861,56.97910878368421,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark63(27.266035971461733,-15.466872173007019,-74.92421497872412,84.91622332865666,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark63(27.386416205633623,-2.570805112024061,72.28881782396255,-42.26880245320499,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark63(27.460346898995127,-7.84315197678896,93.87344826580647,-57.086655214013234,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark63(27.575849606697673,-1.1587973764576134,39.92525369673393,-3.0950014069198772,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark63(27.715689098249,-1.074390056727566,93.3679492851708,53.875402893092456,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark63(27.761576077981516,-0.3430637920239974,57.02415755020829,-72.3736477014332,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark63(27.82033996846458,-5.644364757405555,89.76100397492974,32.18377271479912,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark63(27.97547014917987,-24.257248151478876,41.69009132587047,-66.49981858694616,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark63(28.01169280271165,-16.944641230871184,68.23383184505579,27.31503452598487,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark63(28.09172588404641,-23.14359611180727,-46.85065102017645,35.48551124139425,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark63(28.118385282517295,-5.896207923801924,51.419989507387044,-98.74863032809466,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark63(28.20821204056017,-5.76915215578633,3.162714098421148,-54.226796726693664,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark63(28.239562611658442,-22.459513125459793,-56.57568541061486,90.56754326928399,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark63(28.271713632657224,-16.84298513381121,59.31422045364002,-36.8387486486206,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark63(28.301096084716022,-8.423556583297483,31.691342693392244,-69.5796082693396,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark63(28.320046668398703,-23.332241002501064,18.607946040316122,59.41257458509756,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark63(28.366104180254126,-25.317889369194063,5.255116503221771,-97.13655784390573,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark63(28.37336923714483,-26.88364045222403,-4.370175126307217,-96.223782978424,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark63(28.476445364742375,-20.87506431743816,-58.377501645021844,-48.59571831683287,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark63(28.483288681551613,-16.260245958431057,-37.429127435992584,17.935086232954944,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark63(28.557811428830604,-18.606370870016548,16.877299828347958,21.23133108210918,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark63(28.566632544338574,-11.192834841197637,41.829657193457194,27.493418971532165,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark63(28.588363877201033,-22.21197665853832,29.764718561108197,91.22317157123305,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark63(28.643322304649786,-28.961635797424606,-64.22660147553623,66.88522798781551,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark63(28.64535076998763,-16.405450814129523,-5.538926781190526,-44.59349096167375,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark63(28.689951953923696,-6.233255344766462,91.16756151859079,68.26893161517319,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark63(28.869664889922603,-20.290642143280778,84.51821200709998,-7.030917124150605,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark63(28.922873370063854,-16.894877059748453,-70.18345920220443,6.186676582626433,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark63(28.956656993738306,-20.090269161632463,-46.406296433970425,97.9389506907927,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark63(29.08138163328931,-0.7116325926735954,83.70406865819277,16.615106628135862,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark63(29.232161352597842,-6.969871442594425,6.64991322635484,-52.06190519001539,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark63(29.358829440214834,-3.8083452650781453,-4.403329849238261,56.172981386069125,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark63(29.381586593333225,-24.63840783525535,-41.864301668356575,-42.74188895147528,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark63(29.39809509724779,-12.229648467630597,68.9297331882571,-55.2228957058023,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark63(29.48746076896063,-3.194315232712384,29.34362681300263,-22.412113738808515,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark63(29.521977350581494,-14.60665259866498,-3.608623833959655,44.30460404094086,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark63(29.55760134585651,-16.35393508146059,86.65376248603553,83.33502792827167,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark63(29.5869546224597,-14.1242647162438,5.630604508958342,-5.416163261008293,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark63(29.63913515851715,-7.240356082436051,48.51791830413558,40.314579486922725,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark63(29.696984530121767,-17.82250047766867,47.167607387258414,83.26511147120954,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark63(29.75779626916335,-22.844189164814992,-59.836708373804285,-70.18426092915306,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark63(29.837206446025533,-7.994973469967874,60.800948918247855,-82.63763154065148,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark63(29.89138947154538,-0.6997113154079102,1.0297452439573362,-66.58362621984276,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark63(29.901036197188205,-10.018366742959373,-42.303517726976246,-66.21927733487603,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark63(29.943836914520972,-27.882417919151806,31.709809520777497,-81.78525431949868,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark63(29.95598428725728,-7.935918387644719,40.22428306445539,41.83390111640037,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark63(29.95823438237494,-29.298863844975443,45.373576303122945,-69.97288131349626,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark63(29.964210525837245,-11.722115967683067,74.58034164718671,-28.025335204757184,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark63(30.027469015977317,-21.13762142921449,-44.988210095337,22.822425446714888,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark63(30.082272993027885,-4.924049298482032,-20.905642670969854,-94.1112325014786,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark63(30.087193091798127,-13.65506918109405,21.10893650996495,-40.204114944143264,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark63(30.20834328034229,-5.807830442930339,45.214158110542115,48.88921454021758,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark63(30.231148096369367,-6.800552664534166,-13.652615954848898,82.23702936587028,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark63(30.28661607370333,-25.333941820623295,-5.361516919198621,-91.29106715140989,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark63(30.351142745550618,-19.675203101414326,27.366748014906676,31.561898674806343,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark63(30.379563084115745,-14.272940829529318,-51.31760557892886,7.895235174161712,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark63(30.491429265498,-19.492294213703914,-48.114546571649775,72.542150946965,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark63(30.51901594355175,-19.53836344935054,13.750370823319315,12.85682181112577,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark63(30.595864555501294,-26.73075336713262,-7.952457494539459,-85.87745965566805,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark63(30.631081298958804,-16.57726671531394,15.865975193458496,-67.88780895916247,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark63(30.632192349790245,-12.124119495258029,10.119198621843523,37.43749943367624,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark63(30.676421008603796,-31.33722854810246,70.25828573611793,-8.258779424081226,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark63(30.7442107845348,-7.853951599292188,73.40886612562002,24.1294852345234,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark63(30.74864545398347,-20.215921014135432,78.10008830403993,38.83572288140377,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark63(30.751214660734973,-29.91389658375634,34.60679316044079,67.33981736386895,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark63(30.786029605065266,-2.189067760602285,43.79006850060068,28.156121256949575,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark63(30.791610902607886,-27.115997849093205,-62.149291855288254,-42.304425172822135,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark63(30.823431753804613,-19.621728185659066,-54.37237678143065,-20.825342108849938,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark63(30.836633142250093,-14.899993312822986,-0.3313261643134666,10.490040850399268,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark63(30.863024537228142,-18.912739480236198,-41.06215469681198,41.752399554084974,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark63(30.986361906553412,-21.051803815483126,47.73372495010668,47.83910824731336,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark63(31.106198409763067,-13.713814419698167,17.063940968547996,64.05876817814112,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark63(31.11963677231796,-13.796485914483327,-24.53512690713258,-49.51975008999736,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark63(31.183040199713872,-11.848727409021762,-26.28332773137612,-35.56280745228439,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark63(31.260752666121988,-20.30370064390887,10.75860631885108,49.442870310013404,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark63(31.290980995117252,-27.205215050719886,46.88426304428225,-43.609160749667986,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark63(31.4099124318478,-17.034337160511498,-12.73646153169959,-24.043403271284475,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark63(31.460717481439474,-10.646111280773766,44.65304845688422,-9.608749813158141,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark63(31.502391708459356,-11.349390391014836,-26.81114347965348,45.008506144989866,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark63(31.587818639180455,-7.299369378678762,45.976665158055084,92.68138186322895,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark63(31.639534579807815,-3.6739938535697405,34.07215945482463,51.758299870348935,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark63(31.655438888475572,-20.18377783307797,54.98470049664462,31.924918558681583,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark63(31.718693543180166,-25.120815128648317,-7.255069369040129,62.673654992190365,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark63(31.751733073127127,-26.628298476251274,-33.56399886759567,28.796437602360413,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark63(31.779026812408063,-7.336776809217071,-31.443090149455145,82.23198437945118,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark63(31.83477035596306,-29.064306903268488,-47.59783101879529,-39.735634270307884,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark63(31.86786311995661,-13.624775494668654,99.24861831984475,32.45901112293171,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark63(31.88300673009806,-30.861087400178462,27.19595179429801,-13.806962535524974,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark63(31.907739298115416,-17.207323613479943,35.635841632511244,-83.36844732985557,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark63(31.92628362932882,-12.167743016232919,22.145109091362343,-59.470516885329026,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark63(32.094306054187086,-23.977428414798354,-31.81674268263906,-25.187782196455103,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark63(32.124471140210886,-10.197177885243747,52.906552366762924,35.23529186706642,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark63(32.12915074449538,-11.977969859139861,55.04921023291743,78.89439976891418,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark63(32.154066740634306,-2.2140048827840673,-11.943869886956548,-39.13530883253118,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark63(32.27826460737896,-33.82976276152934,-96.26153434298945,50.97337890238907,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark63(32.33971195454956,-20.53983828010557,26.809645635880287,-30.89083693935335,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark63(32.46191418544194,-30.798571609981295,83.4522316013011,80.35389084342876,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark63(32.504296467023806,-8.396163273613098,12.505275769162978,25.33029424539717,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark63(32.59644085971772,-10.991186894293548,-37.09072777137317,23.822172564994972,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark63(32.655244367709685,-22.808964569699782,88.22779470260394,70.91630649999226,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark63(32.69912069350539,-26.949321617305657,96.85662879295148,22.48390907454136,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark63(32.7331880974468,-18.50750707824635,43.99925953200216,39.90210424655754,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark63(32.75437023761154,-18.25392562043477,-98.48832754753094,-29.834489082285216,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark63(32.77568006329642,-10.992201288603894,13.000125763542698,-68.90242739960118,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark63(32.83472726865182,-7.6216316878374215,-43.45100816851512,92.13455990663286,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark63(32.86710425675611,-26.60588742860935,61.722242030323116,41.39520667589511,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark63(32.8673213411154,-7.154489982951603,6.3408451214263835,-17.045513451012255,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark63(32.931245619243356,-32.04252140939785,-65.94019738218819,-80.66377530127859,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark63(33.01142180231622,-7.674682988597326,5.660104810351328,-98.74481848236461,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark63(33.20653072149747,-30.672051030863926,-48.975983636843566,-62.1273600803893,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark63(33.26658451264274,-1.7850063250176618,39.34861577272798,12.831905981238975,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark63(33.27315215518581,-16.020191140841987,82.03876568409291,53.725668690298136,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark63(33.308627129039735,-16.38276124361191,-6.495114707869163,32.16627348037977,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark63(33.335590997636444,-23.250756832063587,-70.98768840271214,-39.55898295967233,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark63(33.4066447767305,-18.68284818749426,5.5362074718278365,-86.81233837188458,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark63(33.413553268846016,-16.99464634599188,-54.92409371719762,44.38256017602055,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark63(33.41558932539729,-26.260174490553894,-75.52947789671045,74.24303296978266,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark63(33.45531279156614,-28.252123926348276,53.951265522580826,-16.1624700107144,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark63(33.51765732827164,-33.47951309417192,-50.25955878335433,18.543253030445257,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark63(33.55820281654576,-28.83801703350892,40.36231156983783,-87.94216938470987,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark63(33.5783521769805,-37.29899225570805,-83.1485162122921,13.335891654945641,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark63(33.6240610926117,-18.39781886658926,-10.94800691555919,2.582506741977909,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark63(33.62558967131892,-27.312591794425913,60.49868792215972,41.70746510152955,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark63(33.62915447499765,-27.258634085875215,-76.22638183321607,29.30650723792766,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark63(33.72596592418748,-15.191014187831726,16.320722387474106,-44.521863592882106,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark63(33.74140913541717,-3.8770813822124808,17.851041536815586,70.97064647094447,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark63(33.77067892364809,-20.873195722550037,-56.26555116283516,85.32621450174071,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark63(33.84219876780725,-31.350224726687046,-86.11841216442626,56.46869554774898,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark63(33.87010747416778,-11.45658489330718,2.6839827590846994,-60.62990654027169,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark63(33.87607931587863,-14.702435518008244,37.04948890929518,98.72622736869806,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark63(33.8905178405995,-24.935818990031876,-24.00129051413826,98.17819261923805,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark63(33.96741608133581,-34.06372854519155,57.5823944447618,-72.37993703694434,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark63(34.034372693421574,-26.43965170323625,-58.66755763519544,42.39767961537575,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark63(34.03816455246141,-6.434559743743591,17.951846383670514,27.718264642816237,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark63(34.05892743375736,-10.612190874525268,-16.007089450921256,-7.951164359213877,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark63(34.13926907869376,-1.1596678579938242,32.699054483747204,-57.25559101053393,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark63(34.237350533882704,-17.711266265246323,-45.70291474583805,-36.20969807799401,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark63(34.278037470575555,-8.724229802512824,35.08006919199207,-4.118969848524827,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark63(34.28344515029991,-1.6410169053854133,18.280566396726798,-92.25028957156928,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark63(34.30729400484995,-9.697705740331727,50.654077974770075,-19.944869063742104,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark63(34.310158284974136,-4.288009899459652,-14.858118301809583,-94.56834734331605,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark63(34.3189766053618,-23.38427789191597,97.91313511528435,79.57978548452417,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark63(34.36936969952035,-19.88674891062918,-25.94085171168726,7.085530564763658,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark63(34.40739851682366,-24.97967964616285,77.66979803364492,-88.5577868292008,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark63(34.464823211754236,-24.955742614432268,-67.55096832283141,-56.29014053321861,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark63(34.47000406472054,-4.42722801931987,80.02543683730764,53.45877245324792,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark63(34.48560912414075,-5.337482817656536,11.380897754421298,42.73469451712458,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark63(34.50778734056158,-9.20515066124527,20.675513798516647,-33.16929730545863,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark63(34.58099234270412,-15.345630768278369,-10.775935485420732,11.210336739921175,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark63(34.58443722703012,-10.732447592450868,2.0365542801331173,33.964368652163955,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark63(34.59195104185963,-30.670318565315455,4.667348141771583,-76.30377238759473,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark63(34.61819626804942,-30.27707256664533,47.17780897024201,48.943589639974675,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark63(34.640580750506246,-20.484185283043985,48.5727274852963,21.359332295887867,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark63(34.669607410900056,-24.920809729940004,40.10671184091771,99.10808306709012,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark63(34.70887940503445,-13.720420927744456,-75.27877041574612,-24.001834999935866,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark63(34.71357637531642,-30.227828737965837,-74.90229944692553,52.16077940001182,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark63(34.80174699628023,-7.625106893993845,40.06160332444773,16.617626215990768,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark63(34.93541204983953,-4.092068278571006,50.262482702781,35.453390654931894,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark63(34.94381126664675,-32.073756208135464,67.5651809849168,62.48119377714559,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark63(3.5042191856738327,-1.135403294916543,10.561918433616142,-3.8325400328293284,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark63(35.05833755523139,-21.671613576036535,-86.260201189442,-88.81302541124356,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark63(35.07067677237933,-5.410066345044967,-3.4887966088921587,67.70106206573195,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark63(35.07791191424292,-26.56204120985906,32.723308375507685,8.36001012008532,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark63(35.08447842120208,-30.055658239076763,-11.277332979277716,-33.65870051918034,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark63(35.0861257546259,-24.99383515279368,61.43110798372095,-33.47558451895618,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark63(35.12105292374946,-14.653281530829915,49.12973591737972,-58.647722094161246,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark63(35.138051462419185,-11.530650780030726,-45.68426040397628,72.48681195043216,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark63(35.15504974059789,-15.560146838573715,7.636925952956048,65.95216351485166,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark63(35.23698188064333,-41.06368787177015,-29.098573658731226,2.4134106467646745,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark63(35.26350078389001,-21.52681879532858,3.659330088857928,-80.31148990807715,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark63(35.2650032608677,-0.8171739100858417,47.59177933409495,16.652321394875486,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark63(35.288221495928724,-33.9948972242037,-49.60517824925537,-38.9840554612142,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark63(35.42164863686534,-22.39267652732373,-30.49704352057543,80.72868577211528,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark63(35.46585405178149,-31.76758449013448,33.33945016411079,81.45097270350871,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark63(35.47231453639816,-21.89987441154595,80.31121123441736,22.125321195357927,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark63(35.50221090406197,-24.659183216918095,-69.49008187612309,3.3920640971555827,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark63(35.59363823873949,-21.00437758814637,-17.28423975990023,40.08754845606924,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark63(35.70210102684419,-28.286039504502966,41.042700468108706,91.10649797460596,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark63(35.703653143626326,-26.516669108707177,-74.8493081786326,77.64008897638232,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark63(35.737650855466796,-5.217636078307336,85.45229265149658,4.219405861546548,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark63(35.7813144145606,-29.81541183268976,65.15730963809276,-67.33088943444073,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark63(35.797700335257986,-19.928766596443467,78.64417466757487,39.89878165386543,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark63(35.83201556688593,-0.04908746549804732,10.024341324056579,-19.595237471532315,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark63(35.886723325032335,-26.900240114831547,-92.64795489562701,86.6038644631366,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark63(35.90216651083807,-21.933614416074377,-17.133899867685457,-41.84749065306199,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark63(35.945988407882226,-32.42123140679645,10.527821707115038,-35.80825899585443,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark63(36.03461555315582,-23.919433080441905,12.104695103850105,-9.733820500476128,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark63(36.09683440444306,-3.190514932263838,35.859218194436835,97.40850408425186,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark63(36.13896802777191,-20.915296255531572,-41.0249889694287,-61.4437239440486,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark63(36.15366138837567,-25.064069340593846,-33.07793968971342,-48.97818942936196,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark63(36.169042741429934,-18.65184745203807,-29.47521198917225,-45.57122349015494,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark63(36.1742977273496,-21.54814761263613,-93.7389345585238,-34.25803072358728,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark63(36.22691284749837,-25.062688828272073,-43.73498093432657,-70.60833912391038,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark63(36.240856278939816,-21.263128225698452,8.47846303079271,-7.428099526054368,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark63(36.27077538452119,-18.66368215833984,66.46254099411541,-87.60986888108027,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark63(36.283031199355236,-24.26724250133681,56.545317731637766,-53.97295733159031,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark63(36.33163786068167,-0.3500485543597449,24.436944620584015,65.1092436955723,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark63(36.3523035698079,-16.594096647876256,45.97753811380494,-89.14813005381075,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark63(36.491781445973885,-31.894926308823017,23.43676792459506,74.82699816459518,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark63(36.56650204299845,-28.460562811768213,68.81028026161178,24.309404488993636,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark63(36.569208053804516,-22.09680782182069,-79.91462354349713,-39.61101313527375,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark63(3.6570035301945865,-2.4439180578727218,6.294439504699298,-83.45187512140288,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark63(36.580238728179154,-15.95691670856732,-28.840809371398663,83.32869721807967,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark63(36.596176285717064,-31.376433039260547,11.213571093079196,28.45923949898119,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark63(36.60138640473818,-6.117136857051307,71.9321284320859,11.062648431320923,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark63(36.69635793108844,-33.126489923920005,-54.84755319035213,96.98937969162918,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark63(36.74035386817073,-11.184144382104108,37.057136604314394,-60.13405892596426,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark63(36.747245117067905,-23.962241654475292,-18.429222661103452,34.924283622598864,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark63(36.7920927692486,-27.9091962616734,-26.301667193185224,71.7304466194768,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark63(36.89396097151632,-32.43470708573403,34.06959650501119,73.92661360105686,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark63(36.89796115135519,-1.3381045155642681,50.68382534430853,97.77835678258236,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark63(36.91216751555618,-4.473835069023366,86.87942664821728,-60.723389079471836,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark63(37.00094330601112,-34.8663448281237,49.60870759430151,-63.84039396839747,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark63(37.017307581573334,-7.76917235394788,29.913213414989798,-57.46549420644236,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark63(37.02035204282592,-13.378209726744046,75.40178504994725,50.19166712077231,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark63(37.03198155681764,-15.983285161666757,-76.98938067914543,27.476666996145,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark63(37.18025972820402,-18.846958448744616,-68.44645900247855,65.7257092775505,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark63(37.25186264861205,-14.995424794868455,-17.914730576358437,18.187406909346706,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark63(37.374350355062546,-8.345416865093,2.665053780498056,-21.12477752347175,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark63(37.43059073391032,-8.300568278928793,-8.681707158503343,32.97835420017029,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark63(37.451307817609546,-7.150320537090195,-28.9308576012085,89.55565182498722,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark63(37.46637434984157,-10.715222126717961,-30.25544174504735,-29.7941265440642,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark63(37.493766097143435,-15.280427345947118,-92.91480383257027,13.700770888411327,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark63(37.50418500067789,-11.67055264659244,-36.03582458760164,70.34255014875731,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark63(37.505878428425575,-5.282701637180523,60.94056538555458,-54.59018548737902,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark63(37.59416623297486,-7.868577222582559,21.602808981012373,14.897361578777307,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark63(37.66177334389613,-32.53616618044339,-86.69525756287912,68.15756195085694,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark63(37.78106086979008,-0.4014264800117644,77.06867199731388,2.1111814252421084,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark63(37.81936479067156,-14.267913307211472,-52.201432055804005,-17.4695682548261,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark63(37.88951823594215,-21.960017305422184,-73.96470003019724,-14.871293902027617,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark63(37.9393807491285,-14.420136364800356,72.36954025687672,96.58100646242175,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark63(38.028765290557146,-37.43246811512017,-39.019892317952554,86.00643344093123,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark63(38.094346932049405,-32.66224760426002,-42.29990551814973,-34.15094284594862,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark63(38.147680492213254,-35.94108800509348,-69.0455178332356,95.10927725645351,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark63(38.179153660895935,-8.952267320168005,-6.056997795599045,96.22016024081813,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark63(38.180021309709616,-10.407688308604392,89.05463812813693,-78.96527825652109,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark63(38.21432825196908,-11.73951598926675,26.93553955913488,88.88885244486943,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark63(38.32082143803734,-25.4753605949044,-25.01200409493225,-24.139815630650546,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark63(38.35409451967945,-13.75442989807452,-14.375619225111592,-31.4008904952709,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark63(38.38723691285281,-14.704702800139714,-29.518828068189194,68.4681829709894,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark63(38.39845141734989,-11.824212703583385,-40.70561760055118,40.23834356728787,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark63(38.423923674865875,-32.17798535279515,26.561094149023162,-14.50643437901536,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark63(38.449839917689246,-9.835882405554258,-52.866342978295,-87.25985190157365,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark63(38.45782294133204,-16.6631341258809,41.844728640898296,55.51705135705038,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark63(38.48861071475079,-37.87488094817384,19.296327860086976,-38.21839868261734,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark63(38.51540459602606,-29.791029150784198,37.67734959782558,-48.87558199195552,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark63(38.520047370291394,-25.41584052384154,38.66354146494527,99.95600627379972,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark63(38.58023799555815,-4.531704787395128,-22.311452513661308,-54.992704085411305,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark63(38.64619450938932,-37.561051652341895,-23.992920165843785,-51.99121480533648,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark63(38.64675757424561,-18.811467157290423,-15.154519952446321,21.564715590032037,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark63(38.71753536190789,-32.6717884339583,94.53471528198656,-98.29982485544598,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark63(38.71911751515157,-15.499202780568197,-0.4575155253838261,69.5555776780395,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark63(38.75941027241592,-15.985451481739517,-61.566087582128645,64.61189366366952,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark63(38.79153530005425,-13.987777958232712,98.04889382096528,-59.86699207673605,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark63(38.87906508731126,-33.42514302969006,39.80382361811397,63.93310644206386,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark63(38.92679633793006,-14.26520196305674,-79.41436666590396,92.32638213856288,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark63(39.00564931649012,-35.69266632132786,39.24623784412216,-22.864170923007137,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark63(39.02210711613981,-17.436608470297244,25.66083580401397,-69.75638505924641,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark63(39.09064178062451,-16.351153955981147,51.49552440963265,89.07710612118899,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark63(39.09110737798943,-23.576226663041027,-88.66608479661697,45.90710725801509,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark63(39.158632982747406,-22.82944547991373,-92.99529880681841,96.37632395765499,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark63(39.295137006710945,-34.75732902942745,-42.67742041222837,-23.127795683773698,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark63(39.30467053081111,-34.560916056445464,-92.75590128870877,-20.408578819054227,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark63(39.352333773378774,-10.023539278864149,88.95792833736382,-53.322679784283025,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark63(39.42323322042276,-23.661597379168114,-46.30903408587417,21.164133216091585,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark63(39.46091671151885,-27.493344529777858,-27.019872577139765,53.97502348969027,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark63(39.46261520942943,-14.47166620761,-30.321794713354947,-80.38009512911246,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark63(39.485187677558656,-15.154975560103438,7.943647537824617,52.84332262195349,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark63(39.4906219714791,-41.16140841356175,-38.149507917771494,20.945855160685966,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark63(39.50377003065705,-14.244974290233841,-39.53951364522936,39.28413653498919,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark63(39.627460799184405,-29.316164867060564,46.72251303557883,78.23933860145888,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark63(39.70153237912126,-35.196847093147966,69.97296373122063,-82.105489375462,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark63(39.743484806100156,-19.57117855908173,-69.74553675665338,54.23989596121643,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark63(39.75960242878881,-9.293419922713426,92.89566257464824,-56.087636444689835,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark63(39.8371028537446,-16.397288681283754,43.662420170043816,-6.7945338124115295,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark63(39.85901164384035,-31.238522238000527,-1.1311294692642377,-69.27745253248052,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark63(39.878250430223545,-12.31665691243198,81.61875197731422,9.218941380136897,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark63(39.92737954537546,-6.603527145759088,58.819063812472564,23.2870887955295,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark63(39.92755740352126,-32.08061975040198,90.31200544047235,94.28731736492219,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark63(39.953199982024216,-10.809934833772289,-33.70128368103882,-15.107583744184637,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark63(39.96514037219279,-36.55487742545633,42.539826520757,-49.7331566537428,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark63(39.99853785316773,-40.53491324736378,-58.08127625646078,91.065557790881,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark63(40.01727465793198,-37.359503332593434,-83.97032469997205,51.38412692185406,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark63(40.09878411420311,-26.324153514529527,94.85502571678961,-34.9970979590487,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark63(40.223018332341695,-25.781169022188948,-55.6373669408788,-97.60978785786567,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark63(40.34278093257623,-12.539535691728148,-7.9037458600671755,33.75707608839457,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark63(40.44788570468785,-38.24625065406675,-85.00439714890516,75.29886747407198,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark63(40.50327390047647,-16.97927652983921,11.835404132166076,-66.18880997145843,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark63(40.50477270721663,-33.75964146037671,16.563166862446593,-96.38342054733316,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark63(40.607490319379394,-35.31306543890567,-32.114915622276314,-53.5106146297208,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark63(40.662193912031,-12.594207067908997,-32.33539864428023,66.28779397669916,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark63(40.75746529972662,-26.009194603025392,-25.038019973930986,50.93187269165642,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark63(40.76152797384768,-30.45096158455425,-76.77718014129499,88.53349207989453,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark63(40.79669581932575,-26.124348684574628,52.90059765181422,-20.86879594562963,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark63(40.829792887520966,-40.43177949474457,12.55508656018938,-69.31572521492255,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark63(40.883119965933616,-24.76460491876655,62.57390397544174,-81.72070207636379,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark63(40.90913513826192,-28.970998997576828,-58.007238873272215,-94.40001724516122,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark63(40.94478428277071,-7.978029766264811,84.98408194673513,35.208395289697165,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark63(41.07150263303677,-2.0224018105140544,63.7273820552665,97.18779035933741,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark63(41.10210209040699,-19.607108516491166,-41.18065445504826,77.32972459413912,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark63(41.110037130154296,-17.8425963562169,22.029802038286064,-7.307508989182736,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark63(41.139812588205245,-23.303889736414106,5.175086224379683,84.40449858248309,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark63(41.16089920562206,-35.454360648443625,2.0402071082126696,-63.65197301431482,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark63(41.19640725210053,-9.720443738408719,55.21517634987532,-26.746016619796094,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark63(41.20310322150098,-28.654949374198196,-87.97740916033644,-10.607322025955028,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark63(41.20666076348712,-22.890342567843945,-85.7011702902067,-90.37652960612428,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark63(41.34011579260644,-17.18646612023815,53.28942803312634,-28.961223570901012,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark63(41.46583410674711,-25.69630541658961,66.9067541270216,-17.09438169218143,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark63(41.52539543467017,-13.816087338249417,-5.400203383958683,-72.98855556560554,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark63(41.539426753297704,-28.514069117287647,66.01473739175225,76.85971770501322,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark63(41.54908832331975,-36.866123979116416,87.89926533226247,96.42978110535495,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark63(41.59324239183405,-21.374747894889538,71.19248890840373,55.159715292608894,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark63(41.60231032918179,-26.270733888169474,15.657288561043288,-78.11254899440654,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark63(41.66735957446309,-9.569999299990599,73.34126700970322,25.539043349251386,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark63(41.703510961383756,-16.052363781060137,86.04497413445719,-38.39353091511639,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark63(41.71717329516932,-38.10080732273258,-87.32558286780309,72.43266949364093,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark63(41.7260542268246,-0.3977253084120207,91.27041976430411,70.57403414182036,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark63(41.73694441800285,-14.379030889539578,39.01629312855215,-42.0402442839259,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark63(41.76374738535037,-18.287370869129077,-49.163949327278985,-3.7039035894792534,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark63(41.81767267301504,-8.696286438357632,26.089774163180522,-5.03400870179604,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark63(41.96138876323542,-10.878032256592633,92.38984998892238,71.64385160736413,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark63(41.9650891946294,-37.52683363930964,10.052051137754717,-10.635996394177184,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark63(41.993444027156755,-2.7758510142015496,97.38761433330006,65.49682890575414,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark63(42.02441774016549,-21.157360932948222,23.560842154696402,-2.970337536947639,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark63(42.0530741098801,-12.504478322782603,-73.696294745771,8.694941662931583,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark63(42.056455832610624,-1.8963561566708904,-6.22027576015401,62.145444021773045,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark63(42.117839236098234,-1.0595109603683994,32.80785960594028,97.52122669960005,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark63(42.12923232053217,-18.479537239361335,57.761983343438175,63.01911193942135,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark63(42.18615912543987,-3.883200695272677,82.35733464743785,51.649686188979615,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark63(42.18864867504831,-42.66423799146302,46.08299402665344,-87.19855697276012,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark63(42.20755107870323,-16.11797856221304,-92.68595639513677,-40.98506498196757,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark63(42.22514405607453,-18.717236603209557,-40.782489196960235,-70.2975758523297,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark63(42.235290798353645,-15.744162035965829,85.5941235941471,-6.442156443443594,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark63(42.244849256154424,-48.08451465817149,84.58603623028256,-0.24761056689376915,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark63(42.264472803424155,-4.484905740483953,57.44707853500336,10.921428529520497,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark63(42.294562552167264,-41.24944032650906,-47.23339347179585,65.22477260027583,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark63(42.33417165415224,-23.96249274834517,-74.01707430750815,47.65237785300246,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark63(42.37245982193775,-20.549935318399193,41.15248975147753,80.86315782947389,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark63(42.40823766422878,-9.219985795110716,-56.73399293703163,-59.14179420585282,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark63(42.44192627675952,-22.28627478949467,54.338814421986655,11.761505818563052,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark63(42.45886872567192,-31.140027840859446,77.17405155847615,-85.53284052754032,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark63(42.46559252781273,-17.88410638996379,18.924222682871658,50.09006867913371,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark63(42.468012772505006,-18.793483754402402,-52.8628633961234,49.98719927062376,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark63(42.481722984369384,-35.884681580428676,-95.92622711112196,-90.93303789144227,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark63(42.50016084554338,-40.34060846285068,-6.325871190721742,-77.82186066142364,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark63(42.612876954138414,-12.98675566354919,14.662272228578942,94.01441922381184,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark63(42.622972217113926,-25.23305566275762,24.484222504826562,82.03532213123054,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark63(42.64260307137363,-12.694480327313798,-79.11373047329647,-34.61861818837005,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark63(42.72095172884619,-32.34674374224991,-10.312222636503137,12.450983685484005,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark63(42.732870263205456,-1.2917508842205052,32.19266706142918,-62.29091876181778,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark63(42.748988631924306,-12.687701088516803,-37.25638358022596,-21.760275895752173,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark63(42.75429185565872,-24.848937171880678,34.776930091252325,82.69244301511719,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark63(42.789558133964135,-39.922085858149536,-52.7278629793281,-33.02072268069993,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark63(42.79181799132951,-29.418769692691882,73.18461880345907,19.792979107583548,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark63(42.80677591666762,-25.34558933388047,96.5086975984471,-4.971621016551779,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark63(42.84036594442264,-34.099112974439066,70.0069199209101,-51.75351339056042,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark63(42.84142247558657,-15.37424487224645,28.675615441738756,-24.098958645739387,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark63(42.87031298221942,-38.97435951302928,-8.444372523751682,77.38950633963492,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark63(42.93699522084776,-13.847487083080438,0.6496140858071016,-67.85876153434,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark63(42.96276309050353,-18.73452439796901,-58.51284372809391,-35.53210642930958,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark63(42.97725057409758,-35.203135448185876,36.21858225357815,13.484176285973803,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark63(42.99147539532734,-14.199484719958264,77.80869128109171,38.49876721278747,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark63(42.99390993151147,-4.803680478645191,2.709564110634034,59.14403900976134,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark63(43.053398609633064,-1.7616501129662225,89.34248427525227,42.33803329172164,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark63(43.091014754346475,-9.707812909407679,-35.01132490413825,-12.563466366986404,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark63(43.13490302904532,-24.942491061335502,-96.1476843974915,19.72369721284133,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark63(43.16402152386064,-15.684927381165608,-86.38250181436517,-23.18851619184892,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark63(43.20249696960684,-13.353441408857478,-56.00320332265187,-17.282325029729734,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark63(43.25501074805916,-44.772739411239385,76.8936956224226,-4.240138089859016,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark63(43.316971402736726,-20.534522945937468,-6.458883795180583,-98.53786002776049,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark63(43.37802015304709,-39.260232107822965,8.476485450681224,10.695997629674835,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark63(43.40459325515596,-21.850350912884807,-34.35207624651994,-11.615458040278412,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark63(43.51246040451764,-13.553377501955083,7.404462609518063,77.81076836211426,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark63(43.5411657358523,-34.86874821566445,10.308810443158706,-12.38417953710244,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark63(43.54208261206486,-2.023688377109224,24.917068988537466,-41.24282373796899,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark63(43.70962403817842,-44.81715951504655,-97.44749329298365,46.574747820238855,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark63(43.719488475416,-39.240538157302176,-95.34892843594567,84.0006096838624,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark63(43.76951194084154,-1.2994801792104482,-8.595801579662336,67.22882371076125,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark63(43.79699342724385,-41.01773125629422,1.577561885595216,-88.65832602489922,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark63(43.83017923673728,-13.304023168165727,-37.581887966591324,-10.248345255401276,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark63(4.387719089439685,-2.2961795660355904,1.8709167287718884,-20.803922877905137,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark63(43.907630390622614,-27.72444443003633,51.39983638903854,23.740297785819337,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark63(43.93870259704829,-7.826053385848525,-28.84152477954393,-42.32800542374415,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark63(43.94694634979777,-18.964173267721023,-32.228399967689654,-28.030931662241684,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark63(44.06906375936711,-5.629996238308976,44.31939031681745,-87.97817486681485,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark63(44.146738252120485,-29.79647967522878,57.62274725616311,46.481787392721145,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark63(44.15566344308439,-46.61107030505438,77.39689123683908,-23.72873979404912,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark63(44.193316286978444,-29.14317097945822,-29.348097317634966,-53.816730061056404,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark63(44.32147580298479,-4.463884592904392,77.89077579216325,-30.478894440384067,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark63(44.35443840718639,-42.63021752790856,89.99335018645499,88.06195085173675,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark63(44.38611959340486,-27.492007968844703,-95.00999011988536,-33.75797410613421,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark63(4.449951297649292,-78.4771627299607,38.26029544455676,-0.04078186576361986,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark63(44.557037987782394,-41.015406690626335,-93.87294974648377,-75.48705390062473,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark63(44.57447228455857,-37.290507712293255,27.392550151494333,-21.312032069901605,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark63(44.64042754425495,-26.988856963224436,55.974232676065014,-54.07906864282197,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark63(44.66332044933671,-38.62454592431217,40.08220662091455,-32.701515821152256,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark63(44.67652515796928,-42.72677996102119,-40.96248163760081,67.42584499618206,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark63(44.70260384084105,-34.61649791782742,-68.73803870701612,78.44488873952486,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark63(44.71635156060327,-42.311090802162376,83.12836168221367,-70.09226000137043,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark63(44.72246398078846,-14.726629403874085,-41.68820578786017,-61.219378458795525,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark63(44.72919180469418,-29.689299755754007,12.666856023298863,-95.85156807790666,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark63(44.77114780811871,-24.653139012740994,4.930642421156733,-23.69236943211557,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark63(44.795332511729015,-3.6478579103399937,-2.4631995069015744,-95.26537704714299,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark63(44.80128014549359,-16.56306638914286,-41.16799279206123,97.31480483423417,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark63(44.809648001185906,-37.376543147298676,33.37627962523527,72.08823494247471,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark63(44.896021807849735,-16.151189535600636,30.75924959838551,-29.541131290878837,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark63(44.91845624413065,-1.2296506762388617,7.287606498057713,-84.99413779972045,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark63(44.96019863257919,-22.348258542562107,32.481297216090354,62.935840322162534,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark63(44.97824910525429,-37.33077150076698,20.040486032816958,12.955303599568907,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark63(45.04628951741404,-15.93614909788208,72.05791613313727,-14.768267722894308,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark63(45.047930403899954,-9.079012767059496,73.06537864334211,-58.834857138693295,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark63(45.048340281948214,-44.16237719523277,-15.953019701521825,14.520791200147997,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark63(45.054990882605125,-45.30820245409666,-6.254491621547984,12.827921072351558,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark63(45.08174447174048,-18.141021052123946,95.9671581327105,-99.76391250713934,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark63(45.08516947689131,-34.11335884378286,-10.275522198455803,80.93268211988928,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark63(45.113110026220255,-2.1881430572396,12.882776046999538,-1.2017246357060714,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark63(45.11733383293816,-47.4613574537706,-88.91039318509675,2.3325208864292506,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark63(45.18404337274765,-16.593466722714624,-19.776571015368404,96.03933162257275,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark63(45.251905621087246,-0.270006746565258,24.268118133964876,-63.37709349416942,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark63(45.31514530104849,-46.11271588354202,-81.63927721877565,47.64531345571814,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark63(45.333165539919804,-27.715905059745324,90.20518359225503,56.43571530962993,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark63(45.39414645968998,-10.389663891073369,15.456034787091284,42.60730571690371,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark63(45.462371420065494,-33.7654797844547,78.51391539736122,-54.984486910254546,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark63(45.55883654755215,-31.509709671455994,4.743742396805189,-8.814193409296905,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark63(45.72392201195598,-29.76491256452249,90.78198126300944,45.689624423744476,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark63(45.76456098764467,-20.813059453379395,-24.78733942026234,33.03707122059046,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark63(45.82914184841579,-17.148298843144573,50.314359997773636,-9.161894032014487,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark63(45.887433750691144,-40.14012106868723,43.42676116939995,33.189961312378614,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark63(45.8919023364069,-17.54565341125823,87.74505070623374,-6.065933916283981,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark63(45.944507409790106,-27.045737370939136,4.564553575038261,47.864057133310666,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark63(45.95283754155207,-8.465801780946862,94.63820129843583,-33.04937393917274,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark63(45.95545594424212,-35.62399996288204,-82.963310611442,-51.43791100041164,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark63(45.97375014275406,-42.60145331745839,34.286860200951566,-59.04978206953868,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark63(46.045065640774055,-3.3626742758144275,50.06765765990869,82.32405346965552,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark63(46.176811901248726,-47.2049939232394,-83.85099439797182,75.72296927325638,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark63(46.18758977473689,-49.31972052042386,65.79650869486233,-14.840715841102295,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark63(46.24452855968258,-7.23370333149893,39.71936747030742,65.08705660815747,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark63(46.26740049955933,-55.506022233995765,-56.46858990687284,2.2650022825036586,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark63(46.34699968233858,-36.497632633997526,-51.676669973702815,-27.712135467570718,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark63(46.40173788087279,-43.687148254506745,63.46611527111307,-20.734689283915316,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark63(46.46280552244403,-39.41617964491424,-89.75987217456778,48.35311312068481,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark63(46.47373770262172,-4.191773401513487,-8.564539445833773,74.47543042116584,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark63(46.484053688501405,-38.87953136591691,-50.04436193950905,-65.43599869079743,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark63(46.56822553693158,-41.530954258935935,34.12546056808489,-32.47781594361055,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark63(46.66478881057182,-22.00326176120369,41.58974832746708,68.48328564227143,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark63(46.67571141871014,-40.698064235434536,84.78666018898988,-57.64632548532804,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark63(46.76283862178951,-18.18740062790407,-22.035921779625994,30.589612938609548,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark63(46.77452169827012,-26.355135621050877,22.177532768001385,-78.93443335598032,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark63(46.79991131306332,-36.31953313671647,93.18026016217874,57.47357789837196,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark63(46.80321539068828,-9.713978604938262,-1.921684555330657,-11.829883394537589,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark63(46.820680257656306,-30.5283925565855,71.59182312775519,-10.905812870568113,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark63(46.83853093604665,-21.94145255410453,-35.82177550756862,-29.917012609568246,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark63(46.86421558275117,-34.19786941873495,45.883778932059954,67.16153071804845,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark63(46.904224825205716,-29.161387271830534,57.10249238711606,80.10498731627791,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark63(46.92392144172109,-25.3070164787716,47.72574918369807,-75.01513167841591,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark63(46.95626791737908,-28.270963614347494,-3.5596099304054434,43.507096788019425,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark63(47.00389269069174,-42.3357976241614,-10.71856880075947,-11.337965780507744,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark63(47.022255298812894,-45.839567774159896,8.529462340548207,-44.367089578074626,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark63(47.0517997109836,-36.22896401698876,-14.440329631255011,88.10902077541095,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark63(47.0530800342392,-39.4542586479882,35.981661909052406,56.099453899020546,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark63(47.14745067688298,-0.9292074150522183,2.092100976520328,-62.21208187401779,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark63(47.219381104554714,-12.324708715913161,-58.260242685111585,35.33284872174599,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark63(47.28811177398089,-18.389616500996596,2.4367616656351316,7.495408047369764,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark63(47.332792468961884,-12.187859023730013,94.71283017484731,-93.98670194084704,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark63(47.382176561107485,-24.700942775389507,98.39984114842116,-4.454709877722934,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark63(47.42812548417723,-21.236656841191916,-44.9831740248994,3.3338066050365285,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark63(47.50603781918247,-31.290982033443953,-51.22184828053058,25.139707835921172,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark63(47.55399322530502,-17.823001981486144,-85.63575377605943,-32.78307821960789,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark63(47.56303681756728,-45.20315675547035,9.014522287888084,77.61312322936041,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark63(47.664755242266494,-25.688712630370844,-98.24889927410352,87.06053748637808,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark63(47.68401880714998,-5.553382426783045,82.22073766700748,59.26940356879129,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark63(47.7101761870712,-28.707385091163644,7.167961754145381,64.00657925520966,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark63(47.7506658283456,-10.551765680255471,31.458044678465967,-69.55444206008141,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark63(47.75771073817393,-19.399847900206964,93.43183070215792,-94.05630625789985,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark63(47.791496609017884,-32.37465224566371,-89.29853968450954,-52.73382662619346,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark63(47.79352178914738,-45.22937568772585,19.7759768745982,-82.68352694475584,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark63(47.794936565620446,-31.07571292502618,24.330811340322867,-79.77158643640271,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark63(47.82820738793342,-45.623086074705,-79.88618701980963,-38.6616555065232,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark63(47.894410354131026,-7.6531932481951515,81.28475716150035,-15.487042156686044,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark63(47.92511055187805,-30.26213749105355,-20.53502907231848,-82.95761502131978,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark63(47.96544802165144,-16.065051865951645,-13.107814579003303,99.80839132248673,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark63(48.10971258572505,-15.314617170844144,-50.389347638564175,54.454388821681334,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark63(48.13440054257342,-5.2289659439041,80.86029578216335,53.51660238780997,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark63(48.14979889525935,-28.54761972860635,70.1063519633,-23.73764477255125,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark63(48.18455055410266,-37.979407985695545,-18.18949893632704,-89.96545734327113,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark63(48.19403506551873,-46.135772223870354,22.13155871736481,-27.469280449990308,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark63(48.21447379327191,-15.99431325646296,20.108851173274786,-56.579141537441345,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark63(48.274311730141534,-33.316800672595065,76.67742294885622,-31.426950415563667,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark63(48.2784061355633,-39.37559723077988,57.22616633367991,63.47541079786288,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark63(48.286201033847846,-27.046691442926345,-16.05094950224219,64.23240082742046,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark63(48.29454079793763,-6.718325970905255,6.410202723347027,24.66541356594459,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark63(48.30046291467468,-17.75525815569496,-0.49627406151779496,-25.825381549945163,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark63(48.34730911028518,-29.824068479359724,88.74876798941804,95.4239571879042,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark63(48.377102358041725,-50.97040780163804,98.89265754032519,-11.529434513211129,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark63(48.377249344137084,-43.53515070168923,84.86940455558235,18.091565812850405,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark63(48.399386494380764,-7.968570592069568,4.916201215123948,-88.54004379068496,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark63(48.4215876119176,-21.90698037907373,92.20657306725971,-91.29365311136772,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark63(4.842255978438629,-1.5025569832958894,68.68188112028065,50.22577342374274,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark63(48.495260447003034,-28.481124476035617,-24.74981762787307,86.02582740801603,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark63(48.512623628201965,-19.202378133052562,34.33812951347889,10.913030147270291,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark63(48.563824640472376,-40.99178462635085,80.93034316912755,87.64173764879158,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark63(48.567798250707966,-43.07132831529885,-49.44083505818158,-82.12130146726378,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark63(48.61133973495086,-27.53055921637386,-8.8967593901788,44.9024998975743,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark63(48.64702619465865,-35.65682930130403,-95.17576433462676,76.77417392246468,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark63(48.663793586590714,-31.381656151150978,74.35961496700253,-32.55218091122185,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark63(48.68331771548742,-15.83847664712195,-22.786105346688032,-25.653596538003768,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark63(48.69055041605935,-27.643030662054997,4.407780325196484,81.75036591663525,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark63(48.7188027603373,-23.558872171113563,11.30381345233478,37.477985241917224,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark63(48.73126386948533,-40.02344078804783,21.44393465762478,-3.726584879935686,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark63(48.827000860438574,-32.784249797961934,-89.06710123874761,-93.79388992996778,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark63(48.8660428109427,-29.628508060281987,-92.42658295076237,39.26735604741418,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark63(48.93836581265839,-15.118461476688339,49.59133253100762,8.494286251112186,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark63(48.94954826177016,-38.180609082941515,-2.38697776292139,63.29462536353151,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark63(49.05130867824147,-22.311651781708136,-11.900652257326612,-70.77660698064732,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark63(49.07921951423336,-85.83274505666665,-52.942602966396166,0.32049411361182933,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark63(49.10822905008055,-21.966589547526212,-60.991392300154935,2.311563099132428,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark63(49.109791174758016,-10.530176925921069,33.591283893275545,-3.9356201341867063,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark63(49.212822650256896,-16.83073586598975,48.08030900007901,-3.9052883779559124,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark63(49.32255067849104,-17.130465633912763,28.819591998411283,31.579973649583962,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark63(49.46214076567182,-46.20433193074258,8.345298687332004,91.26403809953158,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark63(49.50754394235662,-86.38038056482279,21.121304502531757,-0.44108485746066606,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark63(49.52494868911387,-26.901140601959938,-92.70285182904834,28.618425716381154,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark63(49.53740890049565,-16.90138176622081,97.51575180322081,-58.623050041237626,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark63(49.54911951777058,-44.60032152927553,0.39347863645392067,21.138684012552616,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark63(49.5906681185769,-12.384422705871074,26.539447766305344,80.73525426091587,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark63(49.626401174101176,-40.58271243161475,-39.40446368586667,-86.27868113403542,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark63(49.815417603160995,-36.91052474315233,-14.476280507091047,13.613144301790456,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark63(49.8156591334689,-34.43249069960295,87.4590886193308,-80.03825157635258,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark63(49.85044010756678,-32.24842436832259,14.396200760737912,53.0412535009348,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark63(49.86328112709816,-9.65317219439467,-53.74421861954881,51.97770511300908,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark63(49.90070666211065,-24.378982309853598,82.20531438969729,80.6925568273819,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark63(49.96557280824476,-16.088284404639026,-73.29752831618237,13.915780367907544,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark63(49.97264403454548,-16.100348406088784,17.29976383368617,-86.52286251655225,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark63(49.97746654510385,-12.43301973920812,-33.067362344954006,32.96256597183475,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark63(49.97781177767368,-13.509251381815872,-52.284950639410695,-46.72102299520886,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark63(49.9833042915844,-3.4123930265181173,99.55805916752968,-1.7211546755270462,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark63(50.00218834772764,-31.906328803422838,-88.38734894003102,-7.538440464453686,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark63(50.034647301763584,-21.482824868487896,-60.70184817785111,-65.60607662627774,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark63(50.04275497721764,-14.020473901098455,-33.53203700943115,0.46372673371104156,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark63(50.04989247900704,-6.09895457835475,78.20864911938648,-71.62037761364994,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark63(50.05231385268601,-20.02217382478635,-82.74736607446044,78.6275935845797,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark63(50.0671128287222,-32.20130363763107,-16.268417521210907,74.42654647142902,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark63(50.07120426242756,-18.800709638976215,-55.09882706194502,97.8718332852929,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark63(50.09846032399477,-12.359369065669881,-9.557860437739237,-28.392611491252936,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark63(50.116976130528,-3.5213685019495244,29.595097222781874,-77.50345877273944,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark63(50.14888298376877,-10.740291959273705,83.56410463077106,-9.611617842656386,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark63(50.20410075149863,-22.298479703335758,-14.938700982241343,-66.05528848690332,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark63(50.25720750537022,-25.769875511134728,31.913358144442668,-57.65012492684409,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark63(50.266789356648644,-30.992726159946855,18.30249027195346,-55.32868653002343,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark63(50.30634655751351,-42.12456344271334,96.96496234161157,-44.27745972382373,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark63(50.314976186059226,-44.254473809000515,98.74513783863173,68.92644494489781,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark63(50.32285148537662,-46.321410470318725,44.476408297583674,-7.697094098529817,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark63(50.341383388069005,-32.59286792636837,18.99055344898271,57.71297653921772,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark63(50.35169593065618,-17.354957949094413,-61.23649822437438,-92.3453462850631,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark63(50.35370369785147,-23.3476625440272,53.70334640396419,88.57529173063062,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark63(50.411063316249795,-29.743410278770995,74.32621435069152,96.1171215197898,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark63(50.43497898337972,-40.54859087453417,67.37882291023462,-30.81039276726611,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark63(50.43954092142042,-11.684561020810676,-49.848859487242095,98.10929710587999,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark63(50.44077074772363,-26.678916003690205,-38.57679454300516,-94.71790796207537,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark63(50.451988564232266,-17.34741916895284,-71.24052828093778,-80.46642128790575,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark63(50.47090932669528,-30.529304379200028,-53.859807027961295,-8.056659793427528,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark63(50.47231309809666,-32.325778308700265,-3.7988326193726323,-32.28877257394322,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark63(50.49801592486034,-37.435481301472386,57.92254622933433,99.11203813267241,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark63(50.49887759520226,-35.093829335233636,-95.80023696450364,74.06778565174469,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark63(50.50284661375929,-40.17727314218207,-24.530732504594994,50.622660891040255,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark63(50.54320855118394,-21.239004142009676,82.60767692324643,-77.2755276096667,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark63(50.55642716164931,-21.273628977547546,-18.958877586139252,-72.7283383228871,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark63(50.586382539932885,-21.01004567609459,30.28257352382937,35.302268106793804,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark63(50.608114310874385,-44.985007903033505,3.996415004192812,-54.297198723481934,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark63(50.642230045898344,-6.593269136302766,-6.621382781495427,49.73360671626935,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark63(50.64548392555503,-26.487116393297242,78.10195464906221,-35.253681976965126,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark63(50.68840359793563,-22.448478296604563,-9.583240511089357,-25.54847471638206,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark63(50.731517041531134,-9.462421638471113,-67.25275461508286,-20.0191210642364,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark63(50.82163442631159,-43.88953008959056,96.02471305874408,60.53045302619179,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark63(50.859791086814084,-39.70246170649254,95.96195421326843,-47.11662377521999,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark63(50.91913895968568,-31.027828642129336,31.736601906757613,-54.74877475639923,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark63(50.938246614997354,-25.873701035512482,37.82767283864311,69.59928604615598,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark63(50.96806919274823,-34.84359982237363,65.79534128330383,90.42580763139111,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark63(51.01616709360371,-32.32237774662738,61.749630220083134,-87.10072658376428,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark63(51.02154054600956,-42.68487630632978,51.75931378941664,62.048960857604754,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark63(51.032407141070706,-33.50450193981436,88.82168113156061,-33.562208408004,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark63(51.12279244945523,-31.555084441684173,-11.004764423439411,85.87657689472493,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark63(51.191088227126784,-40.55296433349085,69.56901449754216,-77.79919689686605,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark63(51.22408562035767,-38.945925334666676,-19.443269783315117,91.6987151360297,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark63(51.234288825542876,-36.94814076284292,86.99822707199579,-75.1327821240333,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark63(51.3161099080686,-9.233298774329214,82.73751861274832,13.890413634601572,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark63(51.36798766283121,-51.6260600977297,63.1790795940295,-22.381948088203245,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark63(51.373313410911834,-49.28125417854896,-99.33922791886474,76.62031579168001,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark63(51.51326576445456,-23.57285778417119,50.286976523884846,-36.400225218428936,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark63(51.57152406820171,-40.325052836794775,-45.01525866806271,96.06424033504905,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark63(51.60319807955656,-27.646996970718817,-5.67900760168169,84.8925939178697,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark63(51.63030572723605,-44.79860508836986,-95.30013129601498,-24.85956626383974,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark63(51.64121369194581,-36.79516955088915,98.4567725958805,-19.769981526470986,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark63(51.75385389219002,-21.319957027077763,-85.85526328923756,14.252645989224646,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark63(51.83229069785773,-27.425317750671212,26.022621076513275,-45.08920158431171,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark63(51.856917321858305,-2.533062415425391,75.77434148969215,-43.9724726276548,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark63(51.88540766579405,-27.359106420531944,46.912454704103624,-14.606583488723217,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark63(51.8999173694005,-27.656864932490393,-61.67656930953629,63.521991725560184,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark63(51.90970831637617,-46.23665095858618,-58.4715657217229,42.03730445627019,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark63(51.96147107191916,-47.97576668457757,8.934808179830142,27.02990659526489,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark63(51.97487699630156,-43.18261000643054,58.905775996884955,-12.300282480330793,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark63(52.00435377381365,-10.921152914799606,15.539052426430104,-66.93021967024393,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark63(52.00479794557771,-21.13087864653329,18.472708209175707,50.197431866707916,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark63(52.01753892010291,-40.663692375401524,-14.998906018806295,-28.755877778847733,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark63(52.02778291829662,-28.424075321424127,-99.21493911064346,35.72357036386194,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark63(52.13113319234989,-40.59072213893924,-29.077672231470714,-27.44190678615223,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark63(52.156234569942285,-14.805160995631255,81.64208508861861,-1.4671510727166037,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark63(52.16750673604244,-33.29840038859105,32.37389584173289,15.968920125727522,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark63(52.24256840431599,-6.3011456608606125,71.50740045788137,-52.86386193040844,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark63(52.3331554263292,-34.46632854391669,67.21956321938177,22.70178663928992,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark63(52.35264018048406,-23.86285245441313,-6.896698021632403,89.59229359732217,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark63(52.363478787239615,-24.075360716962166,-80.8650391107985,-6.8152753246601065,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark63(52.387740703901386,-28.81262327863081,60.08237255691196,36.51804431501921,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark63(52.39292922705886,-42.262358104811625,-1.597533120498241,74.79049378487781,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark63(52.39868288990658,-29.27458479651432,55.069238409334986,11.087843477842313,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark63(52.40022632762833,-50.874320653082506,-33.06621479806297,43.500916829352434,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark63(52.41457240472184,-30.04712515720047,95.95690391423346,67.86310268593726,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark63(52.41821374812207,-23.184801302227953,67.34297724191725,-13.231378051754447,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark63(52.45573447007081,-33.87071801265374,46.038202461677656,-8.790515598516805,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark63(52.45959318466441,-51.23407417553274,-16.500765834479353,-88.0679585893056,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark63(52.466206747677916,-50.157044385247815,70.44313288189429,-15.60294435113994,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark63(52.46744180795619,-29.62962686109347,-46.72541641919483,-30.6206390195928,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark63(52.49670244030463,-48.93130562122554,28.970163616324868,-66.94062054183733,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark63(52.51796096346544,-18.168199314164625,-63.82204217684628,-25.389356632580174,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark63(52.52784440693475,-27.07728367796905,-29.446952693765226,0.8586626898899254,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark63(52.56439049837957,-24.490687631250168,89.95566943497047,-79.94048110394525,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark63(52.56846509250457,-50.0925372243183,52.78721643305951,-47.38706026111594,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark63(52.59466458607275,-16.712881650076895,86.14381701383672,-28.9549223574799,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark63(52.60631180899338,-13.578966071067839,45.63425569374567,-14.495200326653034,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark63(52.61872208558202,-21.102264634233833,67.53329775405146,77.64612929707445,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark63(52.635181739955925,-34.33981512778817,-98.92179161185757,-45.174011168067274,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark63(52.64221660335667,-15.274713448807702,48.114182004394024,-32.47766824705816,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark63(52.655891359518364,-1.4335072080067732,22.604130781428793,-9.528663709115534,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark63(52.66907414470131,-32.267771375445164,0.33985988661055444,15.025444033848444,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark63(52.67228188299441,-47.6786887143539,-32.3441288180981,67.95209161352346,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark63(52.70250327086009,-22.72656711548875,84.15846678260502,-66.3421357780347,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark63(52.764704845236906,-15.793695397360281,85.58379266172216,-84.12945698752459,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark63(52.77268962467838,-48.337278207578734,70.5229609739815,82.54700143199403,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark63(52.77734692150477,-6.627971024509918,0.44041534705201,-80.49752403187615,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark63(52.79755964733354,-13.400884578495422,-90.8669013426879,17.500995393749832,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark63(52.81543623394947,-27.07978977696935,52.561669453747015,55.80170992970193,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark63(52.87548145726717,-29.163983428424217,57.98852072942145,-95.25943151150129,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark63(52.973828918942075,-29.296571131249422,17.688250991115282,-23.79255596515229,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark63(52.99150301518665,-14.115679429610779,-83.10921213617914,98.17078231290495,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark63(52.992607069616355,-51.260849969002024,85.64837382306786,93.69367566508947,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark63(53.01494244164914,-14.967723961563735,-14.646238117715967,-96.33040542380571,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark63(53.01549446879207,-32.57627128353664,2.1050164985119153,-99.17948122681875,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark63(53.04481542979883,-43.10802447486475,98.69019736095206,-67.92405385932345,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark63(53.103370481491055,-11.852412168200914,-84.66676289530534,-82.01430659764395,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark63(53.11917683801465,-36.260258778718814,-29.93804941132467,-68.82111944480651,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark63(53.15468554504477,-17.298340171196827,13.892498020268235,-11.274355458858707,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark63(53.17829180975505,-24.792116241374345,-12.18640704726657,-58.27936854086082,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark63(53.20637021052107,-48.67912704689328,-95.42066090181827,-73.60295741041058,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark63(53.22315265117922,-33.20537439070188,23.74511983489495,-41.53265235269852,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark63(53.2462140143258,-38.80071635420555,-28.45247770127257,-8.504663567247064,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark63(53.251047497933826,-36.288198638245284,8.769893004329049,-27.50610205370019,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark63(53.25394949392191,-41.65426557901566,61.53086110248236,29.269136170890874,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark63(53.28737597242409,-50.54215466770926,-31.519590894908504,-63.22082514084715,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark63(53.290354852728825,-48.46205067494998,91.81359713501502,-91.48735783514937,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark63(53.345795583481674,-5.178001984171729,16.76261399285275,-49.611597708937126,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark63(53.380449464750086,-46.62476981702552,-32.6293471800752,-96.55913694058158,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark63(53.39233397017588,-5.746804990825737,16.93377162582408,98.36100491786075,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark63(53.482535867678166,-0.8307420917889203,96.95741800850186,-14.118417565619595,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark63(53.5444651582487,-21.42180981008488,-91.2649127152554,-30.45143334067903,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark63(53.591268388383156,-28.80384063020138,38.979833762571246,76.40969107409197,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark63(53.598660310299664,-33.93587437507716,-98.39113462260893,39.513498902785955,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark63(53.60472131138309,-30.752334381009746,-26.552995340631824,-21.30338071013989,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark63(53.63527791315707,-11.716297978756415,-22.704564610376394,79.15662777952329,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark63(53.6419136034867,-22.048539581231225,40.59625501808384,-96.90263643590606,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark63(53.646973117035344,-22.548762593821905,52.24225679479602,61.58158879358788,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark63(53.679660352317825,-6.616387090553033,-7.558510934422884,-27.498661150398917,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark63(53.68660677973011,-16.449932427148568,-10.711162952151625,-3.660347141101667,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark63(53.70051145394217,-8.729063316110313,85.22013613998945,-5.793818214430942,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark63(53.70514271002739,-12.498948482575116,-20.74660826837615,-8.46250006343206,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark63(5.383828963337308,-8.325888591397756,81.88486853209861,-13.820626254785154,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark63(53.84003591508625,-49.94770329480536,-94.43643987646962,25.009839589549514,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark63(53.85472019102329,-52.92265978757427,32.9892374767978,-39.34925171395112,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark63(54.03004249584458,-42.426976090239506,-34.70540199259608,-98.01990908110001,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark63(54.033822676061675,-15.881329499202181,-97.01349462363645,-12.390881687969909,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark63(54.04280884646391,-18.478902768367547,68.45447923998981,96.1977586623299,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark63(54.045355043260514,-56.570211889263724,-44.805556057937814,3.839534439325149,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark63(54.056188799522005,-7.617802211485937,-55.66299984550671,46.053185400626774,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark63(54.08842391595516,-34.993998437592566,87.7579991003017,30.544706720618677,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark63(54.092539560522994,-22.39985991972395,1.9596177097881622,-81.66187466851558,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark63(54.105260256930734,-4.6256928805364055,69.63424175456424,36.43087045723124,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark63(54.164132248134536,-46.823867459869064,-85.97553881236635,54.89304837702721,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark63(54.188839759327664,-51.94196598521661,-93.1184056535358,-71.00671918273831,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark63(54.18908301295659,-27.320417469598368,-73.84699429993778,-70.88317265769916,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark63(54.19073179591339,-15.100941550612035,-21.182458521398573,-13.561311376948154,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark63(54.19221916409791,-43.85804310506507,36.9056517859639,-13.744275206438019,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark63(54.31085549286695,-47.55635515227476,45.57080313632548,54.21399608549842,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark63(54.31978763414196,-5.310329550102793,35.24679534732908,-36.69717887837791,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark63(54.500869995668666,-32.89236037642951,-90.13236899051593,2.9032375888792927,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark63(54.501150186573454,-13.354876828952484,7.078107434901597,7.269529563440599,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark63(54.5183546853651,-23.566025054482736,72.59043248444814,-45.848895432277146,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark63(54.522720749507556,-31.907393124032552,-71.68530658632972,67.09654596038231,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark63(5.452457429806941,-14.408011887706195,76.61490552758659,-7.018087437880311,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark63(54.57650719447395,-29.82840719098317,48.80990484288537,-41.95636514031425,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark63(54.60251546970619,-14.403500437390832,-91.03863703320268,31.981267403258215,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark63(54.662813508333045,-39.207058743320204,-32.468609488368756,12.2217981635292,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark63(54.68395113307264,-49.180077987785545,98.9114817398289,-67.48141298340298,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark63(54.69019109247856,-26.428967367222242,59.531327584491436,-93.36802800931932,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark63(54.69677561331389,-52.624914271271805,61.070386324339154,30.837088495711924,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark63(54.72505385587826,-44.94264234113332,34.49035872176151,-47.90335568749467,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark63(54.766065805929344,-43.278204796396146,2.819716326729548,38.837346741073816,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark63(54.779167759550376,-2.101367412795213,99.35409790845003,63.68651135447482,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark63(54.78063417582163,-33.82192361625076,76.44207849905331,82.93716313282812,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark63(54.79148354046629,-45.604985662810684,-22.71152308751772,93.38872082141486,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark63(54.79254377685072,-38.81406648883035,49.675000359430015,25.988602032281662,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark63(54.85865698534366,-49.08187769173844,-31.290435632342025,-9.990264394450946,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark63(54.878921944008,-17.202291857046475,-77.64441847079308,-4.540396856583428,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark63(54.89170702887111,-24.736925311599506,16.338787813454587,-52.38954388188508,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark63(54.905226479418104,-44.480367130640275,-88.20391081060663,44.03485213469244,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark63(54.950213663191505,-5.486002296199246,55.24168122441765,57.35400933153434,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark63(54.99529755602347,-15.470436742679738,-31.823655570854186,-5.230285494070941,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark63(54.99618960337767,-16.376773488010897,-1.0906092893581132,67.09316314534792,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark63(55.05991891717278,-20.52899773362462,88.75478892261225,54.79157603802253,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark63(5.512022903874424,-1.3606627711380241,44.19313764427406,22.17637009989437,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark63(55.1805721047254,-49.462624919376495,62.653877321989114,-98.36407957077031,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark63(55.197322656767255,-17.25893545351414,22.849009342635313,37.32250545888067,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark63(55.22896106907339,-4.668623118262232,64.39827679016531,46.24723284932239,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark63(55.272088208201694,-52.140637666127446,-4.913629795736725,-90.62770467452283,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark63(55.3342073997197,-10.544597997066148,66.57229224466775,-1.4466646539861046,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark63(55.33711232157512,-34.16601692843817,-89.22844955544991,-74.99387722358193,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark63(55.44882567800886,-37.42129497423532,77.49200554268972,-81.75498415958327,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark63(55.482893819203724,-40.77799148468948,-14.355319432505297,-77.60473923804707,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark63(55.491623675399154,-32.948238539980835,-43.49971777870869,-50.58572626919873,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark63(55.52101355768957,-23.592358220668785,24.356193206907207,60.28852387592926,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark63(55.582164227932594,-54.444130209484264,62.63262240706922,76.84459277528839,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark63(55.646050019099135,-7.624063497092109,-28.51145754302155,-98.53500732594269,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark63(55.670914253986865,-52.52493751305938,-37.23018266255407,1.3591458404832508,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark63(55.71560273354129,-12.629171850630925,15.88682125483119,12.608167418160193,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark63(55.72207688250887,-45.816486763440565,81.98583017658291,-30.343580320098297,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark63(55.723253639004895,-36.83953210923867,-50.46349693209227,1.4321932454014075,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark63(55.73821138827398,-8.937416690610121,-13.624525532940538,-71.04538655383155,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark63(55.76447526295334,-11.617845963087731,58.7491285361165,-93.20928055938553,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark63(55.76718114672991,-50.13053036297879,-88.68439277700915,60.659224532627434,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark63(55.79705310730097,-51.84392794227819,-51.665006540095405,81.08625522628651,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark63(55.838548579160374,-51.465930933356915,92.06123132198377,-58.76648888605691,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark63(55.84576376477216,-15.738917503405787,36.9506400695457,81.9140349687465,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark63(55.85882404107306,-39.44428277016805,-19.356941331828608,-45.15893506364932,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark63(55.89052611140082,-36.441396709222865,-90.67005343942893,-39.36131209268567,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark63(56.01713520533963,-43.24180848271353,9.756140517370525,90.81396180409473,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark63(56.02257980819866,-6.346984488757101,90.01690447133973,94.87832787514122,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark63(56.0748047597626,-48.72900380115799,-13.920513993355655,0.62562985594991,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark63(56.07729245026434,-35.197125151463766,-20.002321805430228,-30.67066538978149,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark63(56.07862360500914,-47.11360137598213,4.129752501949795,47.872123117757496,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark63(56.078923373494916,-41.969901689171586,43.37647661588147,86.52916812809178,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark63(56.11435751198914,-41.64208282440824,-75.2112465921599,-57.69268809464761,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark63(56.12554282131643,-7.300012701332875,-17.110384338166256,-90.29331671037642,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark63(56.147482022441665,-18.31187720481053,-99.15257613799622,12.169069869289345,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark63(5.616681345291852,-6.233182571751712,58.61851849168255,-40.59695906430094,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark63(56.171468590941004,-29.027509570606668,-29.643046457089014,-52.576793506246624,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark63(56.173017671976055,-51.81373726399359,52.197586227345084,51.27789975406267,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark63(56.228690848363954,-18.007957801479563,-14.426274608286732,-29.683997408168267,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark63(56.33630991068662,-38.04625391084164,-5.417477790059706,96.81750561046485,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark63(56.34633506384614,-45.84081458841971,53.86670239718316,20.99936558181767,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark63(56.357990627329116,-21.857455853511425,-1.3884833311877713,-75.64370806500204,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark63(56.362567040413495,-28.252357074460832,-97.56417659710577,-95.34924637675057,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark63(56.40579197526628,-41.32857915000865,-40.085860460467075,-35.37018138001524,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark63(56.42126691934922,-43.16938249609357,-59.90343571742645,-91.71821821814612,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark63(56.42178061874242,-15.257036462679793,54.76336758849618,-74.19902244365768,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark63(56.43050356650389,-26.905850654997636,29.28134676640505,80.79120656332131,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark63(56.44301259674529,-40.14910207102338,77.13953992840956,86.89484289736694,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark63(56.451616137484706,-1.4401081669770832,76.72046348177182,75.72064829635704,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark63(56.45784425392836,-7.262120488851139,43.0166321318446,33.958025494223165,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark63(56.46582256455005,-34.52239846188657,-25.214016526102156,-65.043422487999,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark63(56.60510250989083,-12.24802615454405,83.48599303099172,-58.35730882794685,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark63(56.647799931648734,-50.433541894923394,-33.84664387717811,91.07068511952383,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark63(56.67592604905795,-22.57543274202078,-32.44574914660416,-3.6008313015724696,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark63(56.69529744873296,-25.109826827689787,-82.88162575261822,23.771858088368788,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark63(56.700149822163695,-19.308637953221236,-80.8591056056011,96.20204974157454,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark63(56.72196006580708,-35.116447822295854,-10.309176069539234,-72.11911085655984,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark63(56.724539417857386,-74.51912551303943,-92.63369323252076,3.201726753477601,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark63(56.7298124316398,-4.330952200016668,97.40498314006788,83.1604488702007,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark63(56.732243763304155,-35.27927287397236,51.37799753099375,-37.346895536969505,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark63(56.76714991839245,-49.26305889352358,-51.01272647546702,-97.27020263415453,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark63(56.77944567380678,-15.860460335064829,-32.27910506517114,-1.0586673109289393,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark63(56.78507425197111,-29.59305790653363,28.232787457177864,-86.34819406124473,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark63(56.79445067666606,-22.045229734071597,-52.87639501647581,98.18382212863406,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark63(56.796137243711485,-1.4071272522116658,53.33657906199326,-9.286907849481807,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark63(56.79939233184223,-51.41293554807551,92.41076831397817,-66.84267582886388,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark63(56.80568686152699,-44.61333443784057,-30.466043303353302,-92.5920635961046,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark63(56.80911772766274,-1.0399998023277135,77.96105786770414,-44.86670014674357,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark63(56.84692693224878,-6.482966160603553,7.7342844284560215,-72.52723493619284,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark63(56.89965288368657,-43.973239326233646,-86.21624729456998,39.19219508510457,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark63(56.92394019457993,-11.96022868034747,-63.18209646378035,-19.995962276668806,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark63(56.94274567780718,-43.36694745388192,-72.91256502119863,-84.85914691826918,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark63(56.94945712626753,-16.13709473663971,-54.21286093457744,-96.26576637376303,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark63(56.950461152296526,-49.745622289601535,-23.075301369269724,-62.1125046441529,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark63(56.96021106299793,-21.902116103588526,22.20852329660572,-46.79559704840548,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark63(56.97372559039496,-38.61124742712991,-71.23609749360156,33.48838227932583,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark63(56.98251989870039,-19.03908642111311,-97.84209333798826,-10.673620999936446,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark63(56.99894638921103,-11.691358218028896,-3.601315663402289,-23.86743108936298,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark63(57.03730433873514,-14.020368935433169,-92.31403581471835,56.09000642579693,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark63(57.038489727352186,-31.74211934673643,52.34334303744973,-63.94500191986494,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark63(57.079451766249974,-23.992982485521665,6.08536240881881,-90.49154646217083,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark63(57.08091649533159,-49.01656575711713,58.040834459905994,-0.9104664092143082,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark63(57.088828918907154,-22.80523535258132,60.59940941016876,50.66415555734895,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark63(57.10813115492442,-39.918301620115535,-14.264104453555504,99.52758923658428,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark63(57.127823998421746,-35.95171667942367,52.11668881273965,-74.61295053993396,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark63(57.143337298924166,-54.80025867362646,87.04117107366835,-28.815752234369768,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark63(57.14383441576956,-10.932296507899224,-63.19909661671916,79.43252444664421,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark63(57.14616526153989,-50.524468801793596,-57.238378757538875,55.732555136002674,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark63(57.181666447920634,-39.94262630500203,-0.5181116459706487,45.908476105451825,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark63(57.19272252442295,-21.614048810605297,17.33867571509859,28.958637313395684,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark63(57.193373419057764,-40.961812120134724,97.45294146585738,40.62991099615385,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark63(57.227944998868765,-36.813502974278634,95.82979952771194,-37.24367492537319,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark63(57.244493122346796,-46.75883604504569,-3.932010091592744,-81.95745693251435,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark63(57.25929486082063,-53.388934804649594,3.64219490679875,-18.960691440836214,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark63(57.373422378736336,-31.26677919755778,-54.090670455404364,-10.979722026678544,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark63(57.37707002334324,-20.5219799225123,-95.59366052124028,-36.53839387384274,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark63(57.404268549116324,-50.343795613749755,-35.36551505551195,81.56546344591254,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark63(57.41934035737941,-15.5310535617148,63.47616516806599,29.595953002133058,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark63(57.444128674837316,-38.379630439083854,-35.147549059443435,-7.472940778548008,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark63(57.471733853912696,-47.67608525297027,76.3038369938755,86.47143371529594,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark63(57.52505223195007,-61.56027618155746,-80.28074056406604,0.5011800557188195,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark63(57.55457339810195,-13.019786894779457,21.467427575603452,65.05553169955482,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark63(57.56513835423854,-12.984698190210949,-26.885192365333737,-48.47688514511024,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark63(57.574253993457916,-20.57748460734868,50.78936724773948,9.985519199698302,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark63(57.62062513029548,-23.827267453107055,-46.87486112764576,93.3114329571869,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark63(57.67564220764223,-36.20577702243377,-2.531153788161177,-54.88429048520103,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark63(57.69185463123725,-15.32085093547009,-89.63408951898064,41.935578959582415,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark63(57.72365560514086,-28.403460640023766,-40.238607031352934,-42.23100657308496,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark63(57.816271092258006,-22.082471966129646,14.136967461393397,36.20220494143447,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark63(57.82372966189021,-7.444379695189582,-21.23534732348196,-89.19690927511512,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark63(57.82920292352162,-18.028744923725498,23.630504713336563,-63.26189922322207,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark63(57.843313809156314,-55.92092342881361,-10.403898200170374,91.93030830968661,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark63(57.84582330805671,-46.751707357719184,36.896144682985465,-35.30719772139854,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark63(57.88509733516375,-46.080901905678104,36.632038100949956,-88.81467347878704,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark63(57.910336646679895,-36.423985302751596,10.852791235983617,30.725333898907678,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark63(58.068913515424725,-10.74988926443794,-20.670459889466144,54.011702195902245,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark63(58.086842902431954,-31.061520080217647,3.639349671225503,97.03272324464541,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark63(58.092076930472246,-37.26917908841823,-40.22975647534044,-5.515630319322781,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark63(58.15287491301842,-56.63200382160301,-47.78275380563524,-68.08607622007155,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark63(58.15861359021329,-83.72824046940687,90.21649495609304,-90.7696096254468,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark63(58.17792178473405,-15.818905408144772,-66.55085677716899,23.570846368013036,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark63(58.20460557804921,-4.773851844828343,-15.996843084998602,27.522207043865365,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark63(58.21561397363217,-38.38741526160607,69.55699808952042,-0.7828117120492379,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark63(58.216448909919166,-56.395372519221574,-38.17816004848977,89.41129270828134,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark63(58.217173138421686,-6.490828568952651,-12.134465985438837,60.44136241081881,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark63(58.22256046884431,-16.370326364733216,-8.177690310844781,-91.32495734523414,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark63(58.22482369791996,-0.7186773452163351,51.092348121039805,89.12292566644041,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark63(58.225887446529924,-19.89515083730538,71.48366419001871,23.10838437588332,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark63(58.23496325686409,-24.56126887173056,31.37333564596841,-68.67962069835589,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark63(58.27953419509163,-56.55792498105359,32.947605729113604,-20.160417824724462,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark63(58.322816105887085,-13.890458175512194,-97.41557397039433,-83.90157994043199,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark63(58.35389381873563,-43.76316112447842,66.72098923461581,23.144939065450828,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark63(58.369583069918576,-33.70215524592142,-7.6290932868822665,90.05763147564616,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark63(58.379671298392225,-1.3174740244339347,16.977718644875495,-23.09441899122882,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark63(58.43376986102123,-60.00524038623691,-64.2594394700301,16.766692393746112,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark63(58.47006145322601,-60.36114906354937,64.42225491394063,-11.307723954277307,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark63(58.47592591863102,-37.99915427251832,7.261894744160074,9.317089922821992,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark63(58.4836691748977,-48.917629679098006,-10.71368461929319,-78.06169380536727,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark63(58.51635505218479,-44.89711311236029,-0.058915766498529365,24.977715926250085,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark63(58.5855183558711,-47.550797903356276,-76.94758584141172,85.85467075695084,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark63(58.60787334818653,-45.01954817202771,-44.35420017365399,23.934526482768945,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark63(58.610054020376,-30.75862832775313,-53.64267150240845,79.89028592812829,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark63(58.64282179037582,-13.010285575048883,75.83766915560818,30.080576852967113,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark63(58.70851613834637,-5.261640975074528,34.06045589010998,-22.57118013840507,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark63(58.733908236175466,-52.808314760648535,-84.66079414001103,-57.25357544055561,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark63(58.76307618786623,-31.821421261861943,-11.52932276845992,86.87699795126608,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark63(58.765121063722745,-28.7082817912045,56.223674495514786,80.13477908807414,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark63(58.785401358437156,-2.127602580294493,58.76117730215566,49.27589856829849,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark63(58.80038469907913,-53.605628548360684,51.35556196964032,-87.25910965823238,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark63(58.803355255079936,-50.19321241218193,30.263400889984013,-40.37288637403562,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark63(58.812754345992886,-52.77105457195488,57.17189984365734,-1.1682407390734966,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark63(58.83037114585784,-41.14837495615329,-27.668729164091616,-98.0369621791133,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark63(58.85067211455467,-21.382123610243028,-39.61803067352163,15.04809500259519,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark63(58.86175190408818,-29.961783255476433,5.79901015662962,-93.04467166984145,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark63(58.86213455100744,-49.445006110219715,62.8013856253682,-13.04982678655115,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark63(58.88402969713792,-46.187188137936964,73.11511393299497,-37.66618893495741,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark63(58.8860817593266,-62.686384649182344,-68.47203420980723,9.262829327251694,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark63(58.91385217078255,-50.79183476617446,4.585663059325313,-51.80366418338382,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark63(58.93059862318003,-10.870526737521445,-58.67928711470447,-88.00719165197782,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark63(58.94435542657567,-55.74826642472848,29.608936991255007,-56.22520965588418,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark63(58.96182811186321,-17.24546342851238,-39.1516985178163,66.6484818144425,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark63(58.9754121859641,-39.255497913712524,-3.522274340655997,13.865466949128958,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark63(58.9894546372837,-33.753500191095284,-70.0701690957425,35.68367703224476,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark63(59.00986909449085,-56.243538121964875,-38.28804421346259,-50.10163844493398,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark63(59.04459091398081,-49.04703672672643,74.38708409838043,-45.667952540739165,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark63(59.04655511780658,-40.773517773733126,-58.39569767286916,-18.70256768533585,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark63(59.09151702547547,-39.775285458094565,-63.102477237794254,-7.323163384274039,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark63(59.130764953563386,-32.164332126525125,99.33988277635984,-61.12551619710496,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark63(59.21465599548506,-17.738884680648525,-11.64437101486044,23.075686964761147,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark63(59.24591599907873,-13.76777623212682,41.45685313957091,-54.681535090934716,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark63(59.255094728562,-53.33630940671612,-5.882984378309047,30.849312718409635,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark63(59.25715313558331,-57.30334182463761,-47.20403823375854,-89.12671663062066,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark63(59.273898180650065,-26.8429256019093,-12.53428941492865,-49.13894454827601,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark63(59.2789713980431,-51.544036960876525,43.57935467566753,-90.34886194476269,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark63(59.29431370999302,-29.644998590320483,-26.398641040942323,18.64235235450751,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark63(59.3121897384398,-30.535432320875614,38.413871091332936,75.93219252631613,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark63(59.332561496152124,-34.828172616387064,6.96635472048537,40.61923838359837,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark63(59.36032003255929,-57.27844484252924,-3.790374255739181,1.473876464825068,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark63(59.372460758179415,-26.53710158531632,-93.9779532637373,11.354093408236295,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark63(59.37647169319243,-58.831331729005434,-52.47105165613826,97.97295038340178,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark63(59.39471890086253,-6.234645444994854,25.63065281484637,65.74264577086012,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark63(59.40610762268079,-50.28716515767855,-92.59942214167978,20.111921746124352,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark63(59.44701337587247,-13.294793244258216,-25.685815701866815,20.518051551933183,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark63(59.51768752983057,-19.275713096996256,59.194589266666156,-94.1993570040879,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark63(59.52459527844778,-26.330957837796333,-37.53842912174981,-77.18371892868996,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark63(59.52825082747742,-47.63616186428179,-93.91491987557366,64.19599851891732,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark63(59.52866419830315,-11.371608127102888,94.16163063749178,-55.390175086351114,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark63(59.534665910717536,-36.74566534789208,23.041420973709464,-63.45862979096617,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark63(59.543054356630336,-1.6135465820778165,83.88176327246646,5.160968697783659,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark63(59.548821207316365,-22.853009125599428,-39.239767799715366,48.20086410965459,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark63(59.559314487759934,-17.046310305999185,-1.392721228730423,38.191540825685706,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark63(59.62415162778112,-26.742477272253723,6.5141981209141875,-91.47304126829847,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark63(59.6245516220352,-16.258293177489975,-85.59498877886402,-52.08425862863615,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark63(59.65310814513316,-5.009759408012158,33.39646351529632,53.064714453636014,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark63(59.66041536290351,-51.469477363531844,-99.63384877186184,-39.99085014564274,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark63(59.667284040417826,-50.161569305829154,88.46855350235018,-73.65083570058432,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark63(59.691656079341755,-20.26871846593062,-44.05393224924321,-26.15120973463611,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark63(59.716003407038016,-55.744844093792544,-7.448105369181263,0.9267174881855738,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark63(59.72767356873763,-26.045518446279075,-42.84524735022581,-48.12855770450566,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark63(59.73009117607819,-32.14131770184123,36.97222763811169,21.6620123463031,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark63(59.76244902600254,-23.840747167012054,-46.81208350905231,-32.987184484571074,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark63(59.779425828018816,-52.35026105256928,81.61734450151565,-85.51435307204792,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark63(59.78866182690598,-26.1140192556158,-74.56085259491134,-30.2101319857246,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark63(59.789021848641,-4.73048971875518,-14.102503202912644,-44.85156333079239,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark63(59.82085699719758,-25.589219363435788,57.085762113327206,-59.01206734995266,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark63(59.89537401179564,-17.653295373364728,-15.363693823570415,-42.10045903034229,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark63(59.89868324563088,-47.35147672717503,23.84927189467956,66.77688204115367,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark63(59.901643712928205,-22.30045686985565,62.09755659112983,92.74051793565664,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark63(59.91228656955815,-27.950425803894547,-85.3652053917234,-48.417783800764916,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark63(59.93762333502224,-46.358994631159604,43.10457892010069,31.739159680291067,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark63(59.98312843217673,-30.91425691381903,19.826225636572346,18.75855547003988,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark63(59.9931178429309,-17.870220620942703,71.08057063753418,-70.78540003087483,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark63(60.008319571150224,-30.02182083857383,-70.0364147848485,76.38205980102663,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark63(60.047182794421246,-50.35807480355157,-65.95916993445638,-50.57082896142306,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark63(60.05881186702425,-37.58362245426987,-75.07514654189156,18.872659678637604,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark63(60.08580663392962,-64.4363508523017,-79.5897645456312,5.7151732067258365,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark63(60.10063424274733,-41.53426999658236,-30.092649744127485,-18.56417712693758,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark63(60.119623948409355,-15.566207877581832,-4.47641781201969,-94.98580128405767,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark63(60.17237714807007,-31.126713019391943,-70.72227837097202,-3.4811049908408194,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark63(60.185115514550915,-3.2072802597959367,31.74003274926872,46.399376964787706,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark63(60.19990815453539,-57.456862118931994,70.91114075549177,-90.99547650041401,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark63(60.219442215958196,-38.4493924282677,8.759002311601606,71.39818817913655,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark63(60.26318137505942,-27.05273962731205,-50.17236459981873,-23.14686323250892,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark63(60.26803736299712,-79.48720149440445,-80.84500666529976,2.051437357027112,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark63(60.281374935090184,-25.365822741868357,19.917673636945892,-20.680013758097033,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark63(60.292377132557306,-48.89612516487918,66.34978804227333,33.48754781717827,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark63(60.29678568539512,-3.7684343833738865,51.528261613257285,86.51163898784057,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark63(60.32705640559914,-33.968426488855926,26.036537239854283,-5.142019271501553,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark63(60.387937592744095,-23.184992947270985,25.754244601912717,1.6110933541920502,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark63(60.393193849499056,-41.35439320719041,2.639356118820487,19.775743126314012,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark63(60.40080679567242,-30.686660642662503,-37.40045160161567,-44.10696080073411,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark63(60.422729026212494,-33.98102606468201,-65.08231036427699,85.94225870468847,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark63(60.42597660264181,-34.07457126215154,-54.65354556882751,25.07960992877763,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark63(60.53693216957788,-20.786566949119617,53.578038082894324,46.14834388834973,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark63(6.054920015242331,-23.08084074987937,78.5163931379183,-0.7711819983137644,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark63(60.578565166103374,-32.32771435600985,-29.417571229792784,53.03797012368807,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark63(60.58299529472217,-21.32232703751697,31.79896503136726,30.36475484494676,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark63(60.58617677332231,-28.85519038269338,-95.49278746425603,4.214723803849552,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark63(60.612976056364715,-45.57187884310827,-79.1635085497827,27.129450048394844,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark63(60.62512374584966,-7.580911933635477,-41.129119961328065,-28.19270868565225,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark63(60.645554924019365,-19.703008113503856,11.788346117001552,-51.69562701232273,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark63(60.6534874349139,-48.184245332304585,45.4919538532086,-3.9433393389897873,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark63(60.68845704168021,-1.2054754519776907,56.99072878868208,-26.04507802143084,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark63(60.6898421028726,-15.755578992591794,-77.75219516587457,44.86554710566858,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark63(60.74487057826909,-2.5572340788073404,97.7433927852386,16.780619477490674,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark63(60.76864211710301,-11.321854217620754,59.54578995936143,-49.26685813301614,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark63(60.82756385813536,-20.248953879140586,92.37077317687778,94.32205376912293,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark63(60.833774960390684,-58.85926544635356,42.288655725143855,39.97419431978315,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark63(60.859947141972725,-54.285369967932255,4.098876866964105,29.38574650922041,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark63(60.87991217917684,-50.92483030970074,21.715421867845166,-12.07099133686205,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark63(60.88023774899375,-19.56642017957219,95.16038146787747,-76.30400724578104,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark63(60.88952766819099,-46.919872033972965,97.92198090844965,-89.26240858728913,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark63(60.910332284725484,-42.8531282975686,-92.47172504958161,68.63420751945696,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark63(60.94955055044164,-40.83140323036956,54.76526224670272,62.12739207352922,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark63(60.95054044087178,-25.343947448779687,77.73377783520903,45.45984191319491,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark63(60.953701512648735,-56.82551265794329,67.67293848904768,-83.78143378337589,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark63(60.97927752181141,-27.00163762390595,-13.44624560808903,-67.6311714360869,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark63(60.98201223670429,-16.971523030454506,36.897331339085184,-8.981815250693927,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark63(61.09230518644216,-41.82525002527186,-9.694647504200148,-66.41474837607865,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark63(61.09439579732452,-37.66862711798458,-20.00013261503031,96.7370425611987,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark63(61.13935840574902,-18.36939107699898,87.33266976554052,64.26392262721308,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark63(61.13995225660224,-36.82234701282372,43.014836567997236,-52.73847769394769,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark63(61.17825712091184,-55.24442011895272,86.6571097745707,-81.94890292894814,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark63(61.18538693934903,-60.50870015550112,-13.153597182064658,-93.26490550523118,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark63(61.22466403043174,-2.8644673632713875,40.43727170170368,94.30480957667388,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark63(61.24682633550535,-38.60099116084743,-2.593624851660593,-74.40436183796638,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark63(61.2572320011206,-20.051836510988934,95.1337574887933,89.08518495545647,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark63(61.265418742287835,-16.378262011306347,83.48794491434012,69.10718075556537,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark63(61.27653728906975,-43.73775270889675,-71.6413323680718,75.15433761964806,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark63(61.29058528660303,-39.89623129119004,-3.973752433929718,10.822832382884641,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark63(61.30692782613687,-5.96353482065814,80.19901889584688,34.54284879465669,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark63(61.332473402334216,-51.13641059102114,-55.924605077502676,49.03161406883768,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark63(61.33877028166063,-33.887518398971565,-25.101973505840533,-41.84837371725547,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark63(61.381461351724,-36.92920757051412,24.22369250022409,-92.5408730278881,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark63(61.39643284525141,-39.27181989766824,38.28348519424384,-41.65954043287938,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark63(61.398023618390425,-42.61156384489257,-14.435764685182264,-8.027735233115905,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark63(61.398638557856316,-2.616180455240851,19.086841015132876,47.535844436505585,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark63(61.41323276684645,-50.91828958889397,-45.2792250339217,-58.42419388760334,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark63(61.42624399744477,-29.311401088680356,78.21980493898175,75.52115519968183,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark63(61.49178285666085,-3.0441833101957627,-16.73603984258483,58.798814515975295,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark63(61.50116214817348,-61.81143436187999,-72.6212634142489,82.40981523271606,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark63(61.50940876724576,-41.69561183399133,-15.929920519349963,-35.448416075485596,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark63(61.52575382351114,-16.66235005895949,-63.54357396830896,-50.04298301326886,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark63(61.5660588928863,-10.060811796851425,73.44461346595645,-78.72757223415286,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark63(61.57656151887193,-58.450928003491455,-30.997142941913253,36.344555173958895,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark63(61.59219171958583,-5.623206961161969,88.25905998040594,57.85780297704207,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark63(61.64871617097273,-44.83779857084096,58.4859890796084,-15.798048655307667,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark63(61.6744632820911,-40.102134018914114,-87.99191364359373,-49.3708229625865,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark63(61.67724220947247,-52.45831154039023,92.97202965511661,74.92335316272346,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark63(61.706454633272955,-50.1334062717792,-27.368902900623638,32.999209027531094,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark63(61.71811564965125,-40.18848851502484,33.84655101943855,-2.018423595681071,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark63(61.74116913738138,-38.42785041496495,-90.70190810644239,-10.570464461402622,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark63(61.74156075294192,-59.769114594705705,-26.956721126322364,55.52059442596385,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark63(61.79802273043953,-45.51763575129897,-10.701464485597342,-29.234709544527988,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark63(61.81528557148144,-14.923827070086304,21.005359912675758,-97.97579994604415,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark63(61.8262124073197,-18.86050177123795,85.06454586194457,51.38989821837657,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark63(61.82904016332748,-55.99537367687197,22.393326929149595,-23.259684610851707,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark63(61.84177985033398,-55.5638006569539,-88.72484723439338,23.464018324877458,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark63(61.84747153435336,-30.64318563114945,83.86314740908713,-32.81303255341332,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark63(61.86413779770305,-32.1749869824816,-97.97029835581617,-8.806045790698434,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark63(61.90266749675121,-25.709026983878644,38.34452311180823,-94.07591505583362,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark63(61.92334586047687,-0.41280740895008705,53.67928751817752,-7.042528790356911,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark63(61.96595715222631,-9.74850198024923,-62.35134229975636,-3.3420329159639977,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark63(61.97326337483534,-56.35722086588737,14.23117909649487,-37.16549369314534,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark63(62.00134818333672,-42.860531090117334,-71.71518041571265,-91.27779974968067,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark63(62.00931019036412,-17.079051843767814,7.119145974112968,-43.770469880088704,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark63(62.03682365754662,-49.67472865418085,12.640074445466382,-42.74230671513586,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark63(62.05263270032438,-54.00244976288047,-40.29649762067482,-5.078806586601246,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark63(62.06142848939331,-54.910809523520186,-40.52587213381575,-63.44968975594247,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark63(62.08303138192261,-2.3717896850089772,55.30092182564519,6.226112482250471,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark63(62.084700783902974,-38.95473523436013,-12.468234168885004,28.721506597567554,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark63(62.12291624188944,-20.813135561993164,-43.03304299517043,21.524725532893214,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark63(62.131595752616704,-42.321350637258035,-46.57308120043198,-33.138235521681196,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark63(62.13896296060318,-14.893084585002072,64.40026764006225,-61.79812100423592,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark63(62.14893309318094,-43.48585275390262,50.08457168986385,4.682256135165929,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark63(62.177681329200766,-44.056291476191255,11.410520415349737,52.146643885168004,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark63(62.1828346562659,-12.445043590266309,-56.252518393513796,26.149424809626368,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark63(62.18482096911876,-14.78288233814476,-50.30326367776124,-54.41158147485419,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark63(62.20162582884612,-61.33809356708439,40.854745134957085,-49.50263217071278,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark63(62.24954085143807,-11.740013217393638,40.970456944369715,-87.13871670680695,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark63(62.25507971252097,-16.28558175329043,64.48605000575384,-62.86114250918122,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark63(62.2745812817478,-18.053540972915144,88.46934108964601,-14.127496795424108,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark63(62.291890658861945,-23.945748029976798,57.051259869855016,37.562529166055214,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark63(62.36628900024766,-49.639233155332185,-15.019104780231714,-4.894066446821128,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark63(62.40576478419919,-27.164672265584173,-39.34024683532451,28.647876763869363,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark63(62.412682097635354,-14.934002374540299,-72.09692408375787,-61.510899241676206,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark63(62.42204348613831,-8.366986736789414,-4.189341611791875,67.22279777064867,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark63(62.42501848047638,-58.63277560906903,58.03027314005806,-24.082159232386473,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark63(62.4320352499945,-8.260416916019466,50.18971670968614,86.53846217780622,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark63(62.432859615556566,-53.164446704895155,11.758697785938566,16.572062584679756,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark63(62.43485536948654,-53.21180556119201,-16.370661292897395,-18.93931712870085,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark63(62.44235004782226,-45.71147966985987,53.11188930503795,79.76288160986331,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark63(6.245997434348951,-1.5965496150758298,69.80851749402899,41.02951591253617,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark63(62.506318867906685,-58.60105141170733,-83.90131524347304,76.3442239437183,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark63(62.55670906194965,-27.890060633183623,-51.55811591005659,-67.10275068605536,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark63(62.55958970072379,-58.89625148012803,63.774596454964836,19.429737442980482,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark63(62.60581204539511,-41.08316996346832,-20.71961252246834,31.797911754339054,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark63(62.66260884191769,-19.069699044485347,56.796966376964576,-36.88367072707426,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark63(62.66904004658636,-9.205198082196446,41.65903926062518,88.20705708793514,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark63(62.670228879224254,-42.18028725242418,-28.49025403489979,-42.091646534657826,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark63(62.698673103343026,-15.889196196658872,-4.383464784492006,21.935760480911526,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark63(62.712416441882425,-18.018026070860827,70.34592571426592,13.894149602828108,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark63(62.71424594551624,-2.1499630308215814,57.791713796272234,47.98166080507045,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark63(62.722856094383076,-15.409879004213693,45.909029126939515,-59.01935747365916,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark63(62.73640586709999,-61.40509993404919,76.14817641192022,83.59370494573349,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark63(6.275294538650016,-0.7408368891234289,42.77515803995121,-19.1076316072498,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark63(62.75537694124935,-19.67523595794512,-50.39219235049175,57.574601143149295,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark63(62.82525539812721,-59.89646642400794,27.672998253394,62.38123646027955,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark63(62.86367713229083,-72.26333553505913,65.2993171423636,-2.8470320402651055,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark63(62.87303600498967,-57.46726107063962,-97.48093008457823,-34.41710166091711,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark63(62.891791860715244,-16.98892996497304,50.231925024421145,92.5131487839044,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark63(62.92292402985723,-58.22552170434465,-53.27111528659791,66.58105992416455,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark63(62.95792211637931,-44.16908961869821,19.703160434962143,79.7642553465679,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark63(62.96232962675748,-19.589954004991412,-63.25561451136665,54.49320126750453,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark63(62.962455006217226,-51.774389171668034,32.269555121753456,42.14955592052513,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark63(62.97637399688776,-12.99743273145107,-34.87732818374927,-91.20816212471794,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark63(63.026891360901004,-61.525015663835305,-35.6399612392661,52.872751310417186,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark63(63.03684857375143,-41.53893739465659,46.271048946237556,86.9093773215838,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark63(63.071065816733125,-44.8802475721791,80.5052535871315,95.5324569394812,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark63(63.118638351827,-1.059296632062086,58.83850578981031,-35.4218059990846,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark63(63.13093255382881,-3.4921738358843157,41.60282718055646,10.867460936083816,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark63(63.13230293371399,-30.322576126872036,40.830579566409966,55.92303601325568,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark63(63.14294786413771,-6.696887739179431,-12.571546131881789,15.648199684309844,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark63(63.14971100405987,-48.774116070005924,38.318128547791275,49.59297595232911,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark63(63.16075599274134,-16.51320729566612,4.039098929953951,8.480304354674814,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark63(63.18770943569667,-63.850390915715735,-52.24241085615033,78.83487381395835,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark63(63.197997103287946,-4.749142714535907,6.469352413387014,-78.11159311860459,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark63(63.21249707499962,-50.82516430993347,-47.81330406502606,67.91290387866712,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark63(63.240212878786025,-44.75611877640158,-70.00394763832081,28.851488798464345,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark63(63.38800136566641,-14.553312341373697,-22.791814415393375,-77.83293659905172,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark63(63.39043316964657,-59.104991341954396,-37.3526573285073,14.828191848011627,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark63(63.39841964294328,-48.27641706889765,15.133805308989395,24.929547785014677,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark63(63.40191596624513,-48.75524121792494,-86.75272684279065,-54.40064307557875,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark63(63.42347791365762,-33.99822670529302,-89.16408691144457,79.79992819652256,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark63(63.51188601022193,-16.55975203640942,-37.16442151732446,-99.19133859855698,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark63(63.51393614364707,-19.767779232292824,-85.29324805749675,55.32199638965997,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark63(63.514976197296846,-55.089066064921724,80.37887039038122,-46.391195237049175,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark63(63.527968226176,-37.597462078912415,-0.3748758285884435,-12.333039508826388,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark63(63.53211589558259,-44.92386909587482,37.85148280055671,19.971377413077818,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark63(63.553482514870154,-46.45670151809287,-17.14845490383763,-65.283545057075,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark63(63.55813125880505,-11.747185116451789,-78.3736252136953,-78.90518778010099,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark63(63.563627635470596,-52.682324429866554,-71.11327955815582,4.069914179944618,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark63(63.582473234555295,-14.860643199183826,13.815974738080001,-8.523405831106274,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark63(63.59595607685887,-40.244943598884156,-33.7266514049835,30.68619571234359,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark63(63.60146147645881,-46.543356336096984,74.209041254581,-63.14781101154732,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark63(63.60914165958167,-18.901493021789165,-89.40331718876861,-90.0120454004675,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark63(63.615167327203494,-20.182931678352702,0.5322211832707211,-55.36118594290866,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark63(63.63129594161211,-39.91839731582936,-42.98591801805705,71.97479072519278,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark63(63.661798850626894,-22.082840660499485,82.4164134343824,64.00634606822723,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark63(63.697190119477426,-17.666389183267768,99.50404555920295,-83.55820984502313,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark63(63.69816237619102,-47.99493645312547,77.41382464661567,51.50782087467459,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark63(63.70216177149371,-15.199311820356513,31.24090889696177,-58.333770987345154,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark63(63.77215365651443,-35.20457172319395,-9.788055410117153,-37.195712199529616,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark63(63.846042806945036,-51.4242160650076,-87.91851462597452,31.591751717970226,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark63(63.87192892461249,-23.40210403142639,84.78360101539394,-19.365851733794088,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark63(63.89057871174393,-40.26282944040871,29.150602361325753,47.32531636428041,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark63(63.89526944806158,-23.72208383092334,89.1283101489777,20.10479452680552,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark63(63.896793701802125,-42.827234875945884,-65.28274563696759,68.61531849468571,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark63(63.92101593586591,-20.08982242868072,48.70505520625565,-68.50696887098515,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark63(63.93029624901638,-24.668931649149712,-37.75379745292793,-76.2343563439598,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark63(63.93767624586556,-40.58016659438734,-96.34531999655552,14.140209733885854,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark63(63.95818088507255,-68.45067674804422,-63.88026632481583,9.610266044989132,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark63(63.97160830919535,-9.983140536329827,34.17148244031395,-31.99482829800806,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark63(63.98662547131363,-32.67185858932453,61.328443947431026,92.73894876477911,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark63(64.05633536607135,-45.04805950091573,12.615576154140001,-56.88605609541819,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark63(64.07573578483235,-31.29704427518601,68.07962998403343,-59.54339161684401,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark63(64.08318248359467,-39.15981926417857,76.59510652051725,-12.720280214724895,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark63(64.10906188564101,-39.83791899807074,-34.07347817694166,4.718075663564818,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark63(64.11833770801013,-27.28671132650298,27.392436822324512,61.82899862514586,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark63(64.13538396093583,-13.424411198170233,-89.6150133167119,-98.62089039124852,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark63(64.15879758543909,-27.01163394451666,-84.67579813822786,11.60538779008111,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark63(64.17171046423132,-31.0021724600485,-11.956621212306189,28.933392747642955,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark63(64.22707139443699,-40.79123410496916,-76.22429090160772,27.68466095197637,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark63(64.24007872778174,-46.039644623013,-34.846935450585065,43.97958273583333,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark63(64.25247312281292,-17.55289442583232,-20.14950114896878,-72.8575674035917,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark63(64.25829050036413,-31.677690368631062,82.26143368219823,-17.30213468387187,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark63(64.29393498119623,-15.25764317834259,-77.12539022813674,23.974726048918683,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark63(64.3132056172237,-9.825681558366227,-21.701885196358674,35.49342272572591,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark63(64.35347047743562,-12.307919713940535,-70.81606350536276,-76.34656092807217,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark63(64.37287936188812,-24.355693939992378,-64.92930248126856,-98.27104157669675,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark63(64.38839611528954,-17.399045515996406,78.71767299141524,-36.77204155982841,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark63(64.44083438387108,-42.7683220112463,-83.13359350931151,-30.163971871684808,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark63(64.4475931807518,-2.4066432042047126,20.151786438065415,-94.09750606844634,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark63(64.46580634633571,-61.61055770897021,2.6901825355108997,55.029656558026545,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark63(64.47884744632927,-59.29369288490203,-72.38698134538274,64.55082489039438,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark63(64.48286806641389,-63.25158749511917,-47.58955939472007,-63.97050316736641,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark63(64.49539720372684,-18.88956069707524,21.493039555234134,-6.73007164159722,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark63(64.57957210847283,-20.975532315754293,-98.56298218373742,-4.026382736551355,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark63(64.58054970438499,-65.41251858151685,-83.97633977614109,58.336120484643885,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark63(64.5899189892354,-40.14260339644742,32.40205021186961,-34.78337397027191,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark63(64.59352769551276,-34.13880252777817,-78.60965062218438,-46.40189561794441,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark63(64.60015008120078,-29.366913241156098,17.15657606762369,-67.90276278935224,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark63(64.61215374980833,-55.39724601920428,22.445569810531808,57.735877938203174,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark63(64.61809160274339,-11.032700631690261,90.50167412605262,-98.1122246536887,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark63(64.62581711811382,-59.30602559211249,92.56075213698566,22.457291840506215,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark63(64.63877851644625,-28.244708255720766,-17.890075148684687,7.306199533681308,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark63(64.64705206548322,-32.75488783054466,-84.55600981960043,6.20082113377309,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark63(64.65867807322459,-52.50249195164398,30.828126649423524,69.88508618587073,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark63(64.66690393955659,-22.026703511693597,0.4463214723005251,-70.95419488504359,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark63(64.678156817245,-45.195930393889896,-84.0206595968316,-45.211261708206194,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark63(64.69285181521545,-22.94716935111451,34.83121753485233,-1.0830074352121954,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark63(64.70757874951482,-52.67402067973408,33.96574176464841,73.3239549551792,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark63(64.71505939440829,-40.346487131659245,93.17642318199606,81.87419994626126,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark63(64.73572276034889,-44.46071695174745,-46.609342605375616,60.65429540404037,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark63(64.75562896061811,-23.59253469002995,-83.68894784247722,85.36620523094106,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark63(64.75740163845228,-31.93049236808865,-9.962358246294272,-85.15392689937067,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark63(64.78212117567378,-31.884427502578802,-3.627531596478022,51.59153355634231,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark63(64.8016226055357,-33.541548190603066,-66.6815525111365,70.60443297939099,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark63(64.81044917428383,-59.37704500068224,41.66901289388062,69.26353405443265,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark63(64.82103951260524,-54.49969945356399,4.391372686018457,82.04924170613944,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark63(64.82676500775429,-80.51741792683003,-93.17385357510875,5.336213692655207,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark63(64.82697397678209,-39.90892734632092,-79.8564969633918,-14.97436543991904,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark63(64.8672137505749,-36.00621598516387,-19.148462855824235,84.19750813768638,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark63(64.87777908889976,-13.02653866581845,-82.46103546652051,93.90252224043479,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark63(64.87807026597883,-28.49902331810374,4.85086520707587,-79.1832803047837,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark63(64.88111484724749,-29.68312331925587,-53.545423706448034,-61.28820166639357,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark63(64.9137063724497,-19.40291007554606,68.64482351573963,-67.8224246655111,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark63(64.93271345657342,-20.100288954071104,-94.53723927875926,-24.806713799037155,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark63(64.94194656480565,-7.601964128821777,83.77593059117095,-49.07047163659097,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark63(64.95779159762441,-7.20082078575652,16.098601720388842,-45.032275927403134,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark63(64.96414434709058,-15.767755149901092,-11.430021102136038,86.98852552873049,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark63(64.97641184015643,-30.2425813799522,-79.01696293772261,19.916305953733257,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark63(64.9780673761403,-35.196750576697795,53.38864053105715,75.9908456803476,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark63(65.00229527874197,-9.199718962624274,48.04521738240396,39.39531602635324,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark63(65.00517244396454,-56.126971113282174,-84.94397821078579,54.598203580751544,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark63(65.1022566184165,-28.76251268776771,43.555750751388075,36.067568637935665,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark63(65.11349062899282,-42.759592477011466,86.43945084939452,55.28040778675904,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark63(65.14125325253039,-33.46338199102405,-47.68174596447832,27.718859744001307,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark63(65.14914986851372,-4.844525758311249,95.6299722846513,-21.511991836271932,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark63(65.17164005429976,-37.377907158786215,25.450818616790954,46.29277050317549,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark63(65.18089117030834,-12.890169297888065,-90.54003257317493,1.236475623644239,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark63(65.18090198151381,-53.727471865052735,-67.19447349615426,-67.54453903144031,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark63(65.19107591797518,-54.00364522055321,-21.261798272278256,49.72301666977239,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark63(65.20953134480271,-43.067998420789166,-7.4607466759443355,83.2817354177927,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark63(65.24606595334703,-15.126428399694603,56.90715310980289,89.25462545413635,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark63(65.24754213834129,-11.82684686048701,-73.13097238094423,24.56243360866972,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark63(65.27979723957569,-7.486416138442436,90.89649565632632,51.8503206028748,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark63(65.29456349425914,-49.16017427698731,21.50046264225061,13.575226147152435,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark63(65.33774323876912,-60.2425377716913,62.63919373800974,30.099869913889705,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark63(65.34154075407596,-12.322399867878175,31.709757196485526,-20.135041249978116,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark63(65.34570045247193,-25.667073671431794,35.80510685047054,-48.433615271287536,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark63(65.36438169893518,-35.75567777592765,-76.88071807265624,38.390858150702854,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark63(65.39749002350354,-14.320085590909486,-63.226434838015976,-90.05547838023433,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark63(65.40670498411822,-15.810966383862208,61.77372307248041,33.14866652728958,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark63(65.42262350677242,-55.82308555450726,-47.36829564213885,33.47555477127756,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark63(65.43513471144661,-56.965252864742524,75.42908068154168,-26.258941090513872,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark63(65.43589270167243,-74.82841298930188,-30.052596883437644,0.48311941665521374,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark63(65.45864004700499,-48.01590495986608,71.22448122401082,94.12221108749642,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark63(65.51519083922653,-3.0828859011985656,-24.873001090337084,-63.11342666165469,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark63(65.53505173013605,-54.8118789725124,66.73333914174896,-90.12085342014215,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark63(65.55969724629108,-20.261998045316943,69.81881116724978,28.21108529198699,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark63(65.56126144944895,-60.12508699747809,-58.20238986647457,-98.55608365636863,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark63(65.57792442961713,-46.82419364918034,15.100219215041989,83.59081168223162,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark63(65.57817310052724,-7.236189874769067,57.5441036127514,-81.63900630025995,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark63(65.58689410443719,-59.88289621284763,-42.21890874822019,-40.195040662769486,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark63(65.61836218526955,-54.82877652544518,3.0369850934602027,3.4208194955862297,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark63(65.6334396378235,-59.92906549813319,-75.75191061673951,87.85599845895095,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark63(65.63821040081004,-52.26442954124704,-92.3691332975993,-56.39279641926769,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark63(65.64339526225831,-61.942510953335116,38.83548506326224,-64.27383238136423,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark63(65.68302640991837,-50.60872013536928,-25.194203338621975,34.659442500457146,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark63(65.69120066221836,-8.463143900451925,-31.32488062663718,34.31262426486282,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark63(65.7339583411956,-31.682500385798434,99.91376592818247,55.54689534364044,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark63(65.78480100329182,-15.855351864100811,88.04240922319116,41.18452810482043,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark63(65.78483314021486,-54.20923046738779,45.3420577533563,-90.40857258773174,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark63(65.79497337979282,-30.192668977451945,49.281591826410335,7.74975823911133,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark63(65.80048933340512,-36.72103228311219,8.35121352946453,-48.97574094201684,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark63(65.82106937500507,-60.03930864467062,-16.019025417094724,97.87471331456882,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark63(65.84722101149231,-59.53942317526732,-58.612160856410014,36.612901461022574,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark63(65.88216106934098,-0.9470200889840612,33.73800307313809,-69.82643381535927,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark63(65.88830551655232,-22.041499783323744,-7.145420798509065,52.01323853466454,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark63(65.92128195992706,-42.322655307488866,40.23089601543535,68.84050619391738,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark63(65.93072587098558,-16.428215739408046,-4.832894189931267,-91.0471090282183,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark63(66.01531520339293,-11.367779430760834,8.027176419307366,-64.10903876696082,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark63(66.06054005777037,-55.70446265498488,-59.63050002911474,13.982140668260627,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark63(66.0744195495866,-11.220473972030746,-48.47110806793518,-5.759556639533429,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark63(66.10131827201243,-66.16930699148531,-19.56812303672764,12.231699412286588,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark63(66.10633265264678,-60.63040923693559,92.38325671232909,95.82989479654435,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark63(66.11300620854573,-17.798352313571158,-74.01883618975609,-13.214872498386839,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark63(66.13141090706904,-35.080104529351246,47.599187743096394,-87.44759143638862,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark63(66.17106271826773,-29.039487459554252,-20.62062318344364,66.25281529678088,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark63(66.20526467482756,-64.16009094261221,57.772396571203245,59.989649616156385,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark63(66.22361921718345,-16.516905949311507,14.8379315695433,78.08119097091287,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark63(66.22905554364021,-23.452463746346126,0.7571987992800473,-88.36188990111151,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark63(66.23400792135027,-21.597406783485923,-2.615867628082043,-53.960677532740405,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark63(66.24518855048726,-56.65403645677438,-36.261311855883235,-19.14909921784873,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark63(66.2513623088673,-52.43377343334841,67.52852621162248,-40.52924392487463,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark63(66.25485796600233,-4.934862969077656,87.05392628457227,4.036462404925672,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark63(66.26554907660818,-51.15558159685529,-82.06607812371054,36.73485255909782,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark63(66.28583814998487,-1.1632184810862896,49.99111792570014,79.76191092968259,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark63(66.29360250375748,-52.10063388067236,-8.074419278639382,74.65222913237736,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark63(66.29768372429245,-66.14747621254647,-87.89824426833883,16.77095435913421,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark63(66.33457361422518,-49.21894931988922,-8.82958037604449,-96.80912136185198,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark63(66.3387732101967,-45.8347324214768,51.805174887222506,-13.046674693230415,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark63(66.41633174893786,-16.71322737170064,-57.49348163442329,-50.420258702869326,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark63(66.42350640006836,-30.099016153355933,0.24012575837464567,94.36138515852198,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark63(66.42530547734472,-65.15267158067735,-77.30661390937038,24.273721482677743,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark63(66.42796289874448,-16.619178743273636,50.453879971142186,72.6277222812052,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark63(66.43286304375147,-35.9268555643591,-44.64360350772083,-77.46184984465974,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark63(66.46514853264858,-13.259659068590608,40.747330097671295,25.719369307535842,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark63(66.50020672654807,-0.011830152254461268,13.204682340767818,-57.204248244346175,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark63(66.53667684154942,-28.2430968093869,-11.470782886585695,27.687376037340243,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark63(66.53771184664748,-25.405381470611644,1.7082021285867768,56.90029013650408,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark63(66.61036934464906,-18.345449513061766,14.710614627454603,77.15707260207668,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark63(66.61591952862204,-20.6514540275259,98.68596899209015,36.59081959168873,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark63(66.63969643034758,-33.63197173022631,-46.153056451719564,-24.560733019480736,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark63(66.66623682283497,-50.41752405541846,85.48944156688478,-59.353905250123496,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark63(66.68666375117479,-22.49784976169221,-12.89622355752229,-68.10028028893278,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark63(66.73712892609728,-30.58165757902222,50.809783012777984,15.313945460301554,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark63(66.7389526530801,-12.258851940126746,-97.67804924736726,-21.47607153526161,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark63(66.77286438252091,-30.64942010753957,-27.7042757912144,96.08106488859167,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark63(66.77976447138013,-46.67054307184206,-0.6824011508561796,53.04624231840006,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark63(66.8214388539748,-35.86083815036464,90.69847735128198,-7.516125377699495,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark63(66.85586912683249,-18.848435547896102,67.12731536080958,-74.10892653745074,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark63(66.87219226077536,-19.77624609019948,-34.99872426411794,-76.19910376760029,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark63(66.90354757786429,-3.927465958729897,88.17299999610066,-15.253997395210234,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark63(66.92369398056545,-52.41280230064254,-87.76344216472185,92.60198745658619,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark63(66.9444485337408,-64.63152924361319,-8.116453734552962,23.847473974885006,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark63(66.94559037700841,-41.51032271357413,72.23884268504725,31.602146242201428,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark63(66.96212873020104,-47.57509984895578,-76.82118577511783,84.81960875016205,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark63(66.9822509751996,-39.958496979435495,27.086560499446023,97.8354135885788,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark63(6.701389008675648,-4.0252141926729905,47.41038065004267,-69.24932901802947,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark63(67.0187251019147,-63.07008167537567,-73.90376805984955,46.996384454370514,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark63(67.05494539571916,-32.3846132311904,97.11779811864761,-64.90149717130646,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark63(67.0866819920723,-27.29360440772632,63.282656757896206,-11.327342858476698,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark63(67.13430921228152,-31.465165388980097,-79.3987238658977,-22.756109040470434,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark63(67.14260199260818,-61.271291877728196,95.71826829895099,98.03978446041438,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark63(67.14312452060136,-19.980299916104855,-48.23233417447137,96.7791595164826,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark63(67.14329021234587,-14.076885875124418,-22.589122353344976,34.20405334199202,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark63(67.16360307976743,-44.506387649655686,18.578511962735973,88.29507148343367,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark63(67.22313053984556,-39.05805434689456,99.26929700988345,89.02795291036222,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark63(67.22933384226178,-48.355659441383935,68.84213841440024,-36.028058405756916,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark63(67.2299343007939,-39.37824329143249,79.11616356102346,42.79898110178962,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark63(67.25309959384933,-30.47443172117164,69.44839724935804,78.06138975595891,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark63(67.25460851107428,-18.68738211904369,-3.717832362030137,5.481208750682882,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark63(67.26143773957804,-62.7690385984478,57.79814564021217,-22.942377187951536,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark63(67.39279826513976,-0.44027988480739566,26.645882903321038,-25.456830079065966,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark63(67.39472016494042,-0.7512668098447364,95.5699217295643,93.52754613175088,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark63(67.41247021080312,-40.959008023718745,-56.41464800466309,88.52795037068515,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark63(67.44376942292558,-62.39213210142254,15.244509070327481,21.117888727763017,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark63(67.52477259918882,-32.12439721427344,18.70991088744161,52.095237074383675,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark63(67.5309443218334,-9.34330874237041,92.48022309907972,26.660744551486857,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark63(67.56086161248854,-5.241431364438512,68.37414259971709,-87.74535209052512,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark63(67.56445651080392,-62.013218438831984,-86.18756395514471,-99.66081289179454,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark63(67.57744052896024,-22.315842385279282,4.028550297060136,91.91557378228407,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark63(67.59857694765702,-25.403722428644457,73.40409400731428,75.91145253701052,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark63(67.61121232153317,-8.74542150883822,87.50200214296663,78.58844305038863,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark63(67.61527846684373,-59.4366669940855,-12.108773687556322,-79.11429423434404,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark63(67.6213662815614,-73.93265707903842,-3.0116107094608253,0.4197087251149867,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark63(67.63152274356355,-27.141169322420723,-17.28261864955458,-6.603038914686962,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark63(67.6789603953367,-59.848772763676486,-93.20186678312223,72.92048512969825,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark63(67.70174701994065,-35.658760296282495,63.810716124709614,7.796654444826487,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark63(67.7175673349353,-2.223856900746739,68.25277153317134,-73.4292275951095,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark63(67.73003495934202,-66.06078470831545,50.523740843629014,69.98917561501182,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark63(67.73049767369656,-26.433884356117957,35.56596307623349,-32.300674583678756,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark63(67.74347101905079,-34.29323026752422,7.1866844571404584,73.33467927674272,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark63(67.74871499111106,-44.74425418484722,95.73348347937437,92.43061091124764,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark63(67.76504413654152,-26.87031942905456,41.91067200027646,44.274498930851394,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark63(67.76980288249928,-58.94001351311022,91.65015783404456,-18.453125493313834,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark63(67.77374280492211,-48.75158191455211,75.59194057706128,-55.45927185821955,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark63(67.85154050776438,-48.31898879590886,4.848582305155034,-8.630307977849782,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark63(67.85521942709087,-40.6310559027675,48.33598228675555,-30.147142200030075,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark63(67.8829461803912,-7.7446732142024075,69.43614888544246,47.110320327686,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark63(67.90354401584909,-45.6105090927779,-66.36554712357284,15.10942636233412,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark63(67.92668304446411,-48.79962424998945,44.85779326303381,-77.25608196359109,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark63(67.9412816299699,-62.17188779630995,57.87526529188091,20.779428145724694,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark63(67.94493817668169,-33.53979650782178,82.6220176160765,45.93726846316676,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark63(67.95928703001678,-31.745711667065365,-4.974859009622136,9.301117704469902,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark63(67.99577871686066,-40.96915036203519,57.88782635809011,68.45801351496311,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark63(68.02057780917542,-3.0827203832550936,8.721747761241815,37.132173702508595,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark63(68.05390293539674,-40.349703305513465,-47.02115804036333,48.44291091076494,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark63(68.06264940265365,-49.87058181106865,-73.29503363206102,-49.57250768351371,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark63(68.13555482012052,-51.0054620011722,-73.53732061353028,-18.54856941024785,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark63(68.18101142066186,-44.055746753310856,41.50407088685927,-39.40073564006479,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark63(68.22495704199318,-27.624834833155873,-8.712171968844217,95.38542465878993,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark63(68.25854947672872,-65.27513270161327,64.30232704201975,96.6716833689139,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark63(68.26063010588712,-9.17516904452711,-18.725307262722907,-69.6296843156411,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark63(68.29585861660766,-33.32916881729405,67.39506084078351,-6.36621345853483,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark63(68.30574517647051,-17.72019007119401,41.42962423214266,64.14058071604015,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark63(68.38885083591128,-22.50663068338848,78.08450412914257,-32.693491844549044,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark63(68.39769721176475,-28.98370521825808,25.99134578851121,-37.9167925988499,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark63(68.41065190342704,-19.779529246200582,-72.94325059629507,-56.378564329685844,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark63(68.44584096105538,-36.311890276097756,-30.06845126594129,74.83686022003664,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark63(68.46678285483446,-36.66602260392617,51.123433271595616,-77.84461562519711,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark63(68.47839356852606,-41.88514048924681,98.38354094853153,-57.77610965469373,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark63(68.4982832432263,-57.1695964575276,-96.60759535882015,24.988079770313604,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark63(68.51795903722984,-42.17921652045425,-3.8911272669507753,39.126302039569765,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark63(68.52125015906554,-31.643339639973107,8.773702394168993,7.307173033435333,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark63(68.55808724530482,-2.1633114410543897,-7.028709562147625,88.09040936755582,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark63(68.56745842754239,-56.518536918025355,-61.724876824299166,-77.5528422790023,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark63(68.60792075385064,-30.349420596313422,42.53502665791271,-54.81862820375309,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark63(6.8615349681190025,-3.220332761257879,77.67063108052056,-75.54040421709487,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark63(68.62492486047847,-52.04885283251694,10.981938731424208,39.97875260726107,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark63(68.65922649870657,-10.344089057621204,-6.949216499458373,-13.619428919483354,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark63(68.67470566201504,-35.30925383334326,-61.007278321983826,25.87038901383731,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark63(68.68722465668796,-24.47874264036885,-21.912402067030172,4.507265726333728,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark63(68.71203067617142,-7.393065265885568,-34.13794707085427,6.526688007547747,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark63(68.71848578119454,-19.053377624120643,-18.409370152037226,-45.118664096357094,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark63(68.73237651993696,-7.228624683144119,9.437149299767484,-78.55946386737989,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark63(68.73857665402866,-39.905469921115014,67.87932410721208,22.66086739922561,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark63(68.75008735580391,-5.569370312343565,34.854564903826855,22.695683104434792,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark63(68.78794489453145,-6.153609313548387,89.31089537979443,43.16542030922645,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark63(68.81912742701394,-16.42027553320105,23.438683516347297,-42.79838782465413,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark63(68.83986031370122,-40.20748798944713,-4.103485361334762,-4.8250999434737025,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark63(68.84019917957173,-26.764703481983616,-95.75486033603535,38.70300530313625,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark63(68.85062672829366,-79.28812529955636,-69.97195709939783,1.0929799890768663,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark63(68.85150648655895,-7.20985026777106,-25.842972602882213,80.18691210933758,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark63(68.900848765874,-63.846584795513465,-47.274522981158995,-26.21757963703824,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark63(68.90211335683367,-18.2776043587849,21.456084282166273,-90.54174752825467,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark63(68.90938482651819,-54.785339389895206,85.52941990367083,56.72998328313324,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark63(68.91566244550648,-66.53415680434034,-92.1277266168066,39.98240120939022,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark63(68.95993658236466,-53.11638522963238,66.40907854700691,47.15722940221866,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark63(68.96794681277618,-47.683546116833675,-29.6253044430473,-45.97630507068495,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark63(68.97576118014572,-15.678339231017532,-9.737619606514741,69.58041891689177,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark63(68.98500346356303,-6.678755557657951,-53.64657802398738,-68.71972723096668,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark63(68.99713566057329,-42.254209896808526,29.944595760543592,-11.107550884021933,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark63(69.00589504404633,-20.769397947610926,63.23459915182866,46.60921908066851,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark63(69.01448116040461,-9.782182870595875,-74.65071516960845,45.06892808919008,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark63(69.08351162517903,-62.48335732569799,5.60881584686301,-16.07448049496014,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark63(69.12951633818724,-21.774789916593733,32.69583343129153,-97.70632784694504,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark63(69.14717728340275,-15.995889828395349,22.15061691299387,-91.75776407540326,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark63(69.16917426479023,-11.651910127230963,-12.51400116650862,-0.5154001941801312,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark63(69.18268262134904,-46.03007829689276,24.749339704761937,80.41456967052102,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark63(69.19147099442932,-28.33880502410409,-99.91427068216791,28.40022131209392,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark63(69.21231366902728,-18.306635957297374,42.882248334477566,-81.93563453085375,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark63(69.21821940027849,-57.59360760493688,28.619863035425624,3.6153019952812144,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark63(69.23448198316979,-70.61625014230471,94.12782260921887,-60.50068645638029,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark63(69.24131584580357,-53.15803810072766,-42.659124104596756,16.140189338128692,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark63(69.26188087491323,-27.071276649055292,-34.33104201857071,-21.127172774905986,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark63(69.29022362964409,-65.18220100260426,36.97454703482788,83.89887733965233,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark63(69.29969108781819,-51.859238426789325,24.0423398123111,91.69918525849812,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark63(69.36915250852945,-62.32876543271042,-18.15412296478229,68.9839621941531,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark63(69.37433038968851,-71.31493543971476,85.37588190953676,-23.830274189682285,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark63(69.37600158185322,-13.155552397627986,7.79647589854801,56.85613582062109,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark63(69.38937235993015,-39.276061915264805,-24.503954270278783,-96.50950101930643,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark63(69.48106042401213,-25.644330033662513,-24.387141864590234,-83.36599763837941,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark63(69.48866686931635,-17.009252082257348,-97.62990482742782,-60.65317434711106,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark63(69.55668384081679,-31.45401238748275,-50.06109227416702,-83.34439848986077,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark63(69.56476871789846,-58.202767927595445,56.40565893804043,69.88761347257099,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark63(69.57632187707091,-54.57568228861367,41.64434343722414,78.24375410477867,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark63(69.58243293674062,-24.27447999348304,72.54465682278177,-96.74753438396489,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark63(69.6307835134769,-32.41776826316057,-55.88165420713038,-29.117895170476956,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark63(69.64113297745527,-30.90377454306787,47.00998286388466,-46.90098745887561,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark63(69.69043122693296,-10.864337235325337,4.185274387551203,-12.084796234738548,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark63(69.71758279600215,-8.348971447029712,-3.263646629657373,84.54558548428997,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark63(69.71823277323892,-45.34893405026208,-50.7595658485394,22.90299223425623,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark63(69.72259113698121,-14.764051573320486,42.474337492828596,-3.5011222234845576,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark63(69.74295892108591,-23.837857792345574,-26.409696962665464,-6.5890192173093425,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark63(69.74810639355792,-50.070827773810954,74.04357732776029,-95.9005460061144,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark63(69.74869119386037,-64.74981201686907,71.51945894836666,36.64130583403548,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark63(69.75216094314538,-60.40722448866127,-7.001752647347502,23.970682115527396,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark63(69.81389255646087,-27.26687376781838,-66.85902971718691,-87.12241709911666,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark63(69.81647732427027,-38.485761288384055,13.086791129598012,94.53063890338015,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark63(69.82481375944218,-71.04617710844357,46.44899409327752,-12.012015641156438,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark63(69.85113076167696,-61.200304084630794,-84.51367069420353,-15.051372076207485,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark63(69.85621150144152,-11.89722185512683,38.84531521452931,76.04409319196847,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark63(69.88361412880556,-1.3992224736155947,11.42939438562631,-72.21397178653814,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark63(69.88745115413516,-15.914266512764996,-43.04985052114223,73.35908168693956,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark63(69.8991413551027,-22.189198945381477,-88.75582968868852,-38.323761970801876,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark63(69.9017932418746,-4.537040132752296,-22.123108359184698,-24.9937111453562,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark63(69.9049327522518,-64.25221370481876,97.82512464761754,95.39890759641355,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark63(69.91836057695056,-61.318255613296955,69.94349278834366,34.30045575117876,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark63(69.93048051936282,-60.589068422084225,-2.4108116938437547,-16.623896502216525,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark63(69.95233844631272,-14.363970631869293,-57.92788763871046,81.14812621822321,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark63(69.95624005793161,-14.68127315017702,33.804009302517045,37.06462072195552,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark63(69.96035473972623,-45.23596282613633,-78.33480410099789,93.06040678253507,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark63(69.96896386502357,-11.249838511509452,19.181112515188033,7.400918840820793,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark63(69.9858498432771,-4.048717421982715,92.22175875647613,28.424749775192453,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark63(70.0024888160174,-65.79566939853459,63.20045133745526,68.15731016251237,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark63(70.0146743391827,-37.880431991574895,38.3586533945477,84.60783108391166,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark63(70.04062483743493,-9.891429701875794,-46.984514714165826,44.0419557920018,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark63(70.05940747202558,-24.08829771158514,57.04297584437077,-7.497945623605801,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark63(70.06948147924837,-48.14814371986673,-99.19537071214128,80.64830037590812,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark63(70.07348768596316,-43.94113874473948,-98.42942028948043,-76.64629376681833,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark63(70.10566656918255,-29.765172931989127,-36.92196369421541,88.52800698763966,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark63(70.10566759465954,-26.15464724902961,39.03646043737669,58.44441609801132,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark63(70.11603761642704,-82.56778049670072,-85.14067843455662,2.505631645474125,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark63(70.11632945427579,-21.132907374657833,92.81707384346245,-39.14362773353035,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark63(70.15069762932399,-41.244268494936456,71.80788251626936,-56.37798635323386,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark63(70.15810777136679,-15.6973796615667,61.770321774767666,43.00963377844113,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark63(70.20260736874943,-3.517137942632644,77.91656380084456,21.277913795766707,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark63(70.21825871238624,-1.86314069964682,-2.5677779518640733,-31.97936461803259,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark63(70.23470344639082,-60.75889173332823,25.617309616030326,42.491561972942094,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark63(70.24467455098835,-18.957109921085504,-19.96411079193922,-48.409907523968656,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark63(70.2519990575801,-12.705593505795548,76.02459232241154,-87.17155314696056,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark63(70.25783427421251,-13.569549308718052,-55.69927862653432,-46.78027659974659,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark63(70.26471459899352,-1.0574495476734427,-0.13783658783970054,-54.71968416115074,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark63(70.32050946935351,-26.09159874723383,-65.71183966269388,61.095253410497804,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark63(70.33816789944959,-31.904805472763158,-42.41971772216251,-21.904872075597908,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark63(70.43550505241032,-38.747129646891395,16.01257145694484,16.06794735175501,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark63(70.44920554820877,-56.30813035497781,-57.877634204677555,16.872702337762362,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark63(70.45078401974231,-56.01762508375976,-1.7628597356906823,-72.24341319049546,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark63(70.45316891227685,-14.945118768834803,-82.07440431190376,74.71713288600702,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark63(70.4581173976087,-47.323220811969755,-92.02429583045296,-59.889395225104415,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark63(70.46287007695253,-22.661045815901716,53.62816960007319,2.7555407480436713,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark63(70.51408486378517,-46.329968484179474,72.47999067018029,-46.56079091853223,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark63(70.58724930324979,-12.222711339982212,-70.16646200148315,-33.50334055085335,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark63(70.60003039227095,-56.45803824625703,96.4091494645804,86.29650905704474,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark63(70.62117398090209,-11.141888620284135,-2.6439773962388955,-38.829694954329064,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark63(70.65703865092553,-61.182425029900585,-68.7261144054699,13.141226634528039,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark63(70.65723510299392,-13.376149515310615,17.99717984430194,72.20647194178406,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark63(70.67829914053107,-4.2903313646449135,73.20362149262127,-36.431769859331276,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark63(70.6933549037538,-19.002853237435204,47.19504044499746,-31.023596516970713,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark63(70.74875633120996,-8.125473670799323,28.83989045818379,-98.22676836273945,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark63(70.75279929279188,-28.45111702261711,-64.95160748570079,-91.2171783907769,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark63(70.78978939838896,-60.97982390391117,-8.166755850767785,57.83276052657553,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark63(70.79589452461161,-69.85525900674898,-31.3231225593901,-59.64497849262034,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark63(70.79599200238317,-68.82835964170707,63.835388295734106,-7.370716268179891,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark63(70.79947110921114,-17.11303214337012,33.91520060816404,70.49100002778295,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark63(70.80734997889499,-60.030394864521085,24.8587017068664,99.41751921720262,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark63(70.86114700958316,-32.418488171451344,81.05734653583039,7.105275361689991,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark63(70.86283956927801,-58.94279457238596,-40.645562848910835,27.494548936498717,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark63(70.86410354208655,-5.397432650876738,-45.240733275564196,-90.01675558886402,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark63(70.88830974607035,-19.58993384981231,91.19264555787686,-21.657606926975845,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark63(70.89171992803003,-53.35735906763155,-11.265985260137597,43.25929537528236,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark63(70.91139257353265,-17.7726109946217,-81.18596108826665,84.09102429259846,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark63(70.92558364266037,-54.71174429867496,7.324461109461055,-3.698702795104154,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark63(70.97696336383348,-6.1703528968993595,-10.235845960525296,-37.78696338217182,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark63(71.01298585497841,-42.08743501919581,14.102556411487768,71.44462989878798,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark63(71.02865933507567,-66.77529195788286,-20.568620053820226,52.77680426159526,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark63(71.03996134074106,-30.039049466158232,-66.30833598491341,30.391673467752213,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark63(71.06278848849416,-14.684138929183632,-37.45008482329102,-84.75565012046113,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark63(71.08315035754109,-50.0359673161455,68.7368912551155,-68.0359545664998,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark63(71.10417457640787,-62.21693886417587,-24.628220297367065,-98.32806076081795,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark63(71.1405774802073,-29.462765971235513,-39.02559822310852,-81.66628113047065,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark63(71.16495310056166,-58.44234124784364,95.78980197280174,76.53762143380226,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark63(71.1655396053884,-11.896801727238326,9.735228302916553,-59.23734370025209,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark63(71.18869229889478,-19.172970307179753,22.121208731676404,60.78075939261609,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark63(71.19341660785832,-1.2466480122877783,97.14545330232832,52.8677429759837,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark63(71.23404311302727,-70.50322847204787,-57.27373546053529,70.9885463916948,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark63(71.25046684768387,-20.17389253972297,-38.08797808254369,-96.63323055929709,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark63(71.2573181636572,-47.710447919555435,-25.853580921263756,81.3827068187712,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark63(71.26024180825641,-47.146325841679705,17.307549773974202,29.459266535191546,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark63(71.35913065405688,-25.307296853701814,-98.14331641590942,-5.450944867862617,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark63(71.36017498915217,-72.25935845631514,-96.32412981160094,95.01654626456488,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark63(71.36620870349304,-6.070799330878842,76.31399825350422,-61.39305690472978,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark63(71.4086117074543,-8.947837842292316,0.026577198158193482,75.77431208944824,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark63(71.41686644008954,-31.408277974436928,37.31511961849671,51.45678689648804,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark63(71.46603419205232,-5.732370560674482,-14.274816779672506,-19.046428166125963,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark63(71.47452740916194,-3.762295067099643,73.90244026187437,8.696925501780811,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark63(71.48156391580466,-26.068669828796715,-68.26174744711943,70.07798979317684,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark63(71.48614360362879,-63.233013831332485,-20.134457833143586,-62.11176508297569,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark63(71.49932225098149,-27.778250823276537,-47.78576217237567,73.48237803438812,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark63(71.50611098602977,-16.937978482161668,-74.02561252390383,-87.08857944025164,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark63(71.51319668247291,-69.16100214429392,-10.777167563950712,-45.54136787978076,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark63(71.53913737417474,-19.758198506193608,-44.66183396827332,96.28319676969073,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark63(71.57206262875562,-10.840523812387758,-41.1472483113974,-76.05425372515748,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark63(71.58733141753262,-50.152167656010135,29.07191595782504,-67.59135948742465,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark63(71.6224364663178,-1.1590104459098285,56.04712302226119,51.357436899181494,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark63(7.168174154131776,-2.864423899262647,-5.99555666783111,48.624850437531364,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark63(71.6876858793953,-69.01673477660202,-27.10701379099602,68.83668848715155,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark63(71.69348249794015,-28.524881853270585,-1.9108136967423377,7.89090142125184,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark63(71.72664663080889,-44.330355741858774,63.93275623017601,50.15411433187569,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark63(71.7389123678258,-61.57799213784998,66.38137646253176,-55.881308675633726,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark63(71.74588726644123,-58.90723178785899,-86.22117999041244,5.600835953862827,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark63(71.75150558746475,-11.35238044481828,35.23710940268475,-39.63540329114517,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark63(71.75526424129845,-19.634558506840193,-63.03889185164706,95.19509938991933,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark63(71.7630176927556,-61.24735848638962,96.47027872455175,74.94901494661141,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark63(71.7683968621582,-3.127353920413725,24.492206735619163,70.5068761408308,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark63(71.7808865895527,-16.4334794828125,-55.94126925519558,24.379307941623466,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark63(71.78664835757559,-69.69409341467043,-33.91434915917601,4.210221517264841,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark63(71.79783764090081,-8.429188426457614,45.06897333951605,-56.688316585100004,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark63(71.82259294901633,-43.77950482413113,15.895530969674581,58.99965704011953,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark63(71.84943579873448,-30.952902472889647,-22.914243721873078,-79.39138585244383,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark63(71.88373201704616,-7.494563880369597,53.36172742857087,-68.46691682057028,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark63(71.9239964030256,-7.599235711846731,57.52933980824639,-16.531488109658326,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark63(71.94275088112704,-16.137196545436723,-41.0973163817149,-80.28600298502172,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark63(71.97518525956005,-58.59370260317007,-0.4205323993399901,-23.811886379559695,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark63(71.98501206512182,-46.8716228640222,54.66976882557145,12.112743307989746,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark63(71.9962175259567,1.6520443346725386,69.8405550097965,-71.8613388139989,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark63(72.0161617159234,-65.15623901513032,-36.71075778065918,-66.61339208514397,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark63(72.10175715610984,-24.47689948985503,10.376777137768585,-93.47052146306866,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark63(72.10305256243313,-5.281496302673517,-28.34721490165974,-20.768942291057414,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark63(72.11747181054068,-16.274500795307574,1.8765438210595562,-25.113396677525486,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark63(72.14311265285588,-73.33547404974026,-70.10527502793589,24.448142689324115,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark63(72.15764548950173,-53.48866793110074,92.82263639458,28.4428759892929,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark63(72.16737686353162,-57.73030682255709,37.506129050438346,-69.17999720291903,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark63(72.1796126986282,-20.702997582613264,-28.411112433469057,-9.908328499025899,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark63(72.24474625728854,-13.829344978414525,3.5899715159045655,31.814973845393723,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark63(72.2506445775449,-31.509790169516364,-79.71541260070873,-8.925888542996091,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark63(72.25195457982753,-81.72198893733994,98.16492836944474,-3.3886579478869407,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark63(72.25420754864336,-41.6524438647824,-9.952366643675475,-47.19288823479842,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark63(72.26705721520452,-36.8636272941856,10.378429176406371,74.82425889244115,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark63(72.3141449619742,-28.148204892146538,-98.2189294581199,75.39052611996351,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark63(72.34633483681438,-44.88115663906302,10.038998758440428,21.498177514428534,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark63(72.35366321712849,-23.321777496227213,39.913718289594215,3.090735930091199,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark63(72.38473189936076,-3.7939659013387796,63.35493523142409,-4.346499421542234,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark63(72.40064357994765,-24.584463214136008,30.05209913703186,-14.092236653049525,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark63(72.40716726461426,-50.39754820339619,-19.4813830346545,95.03693174153952,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark63(72.42342310261495,-29.857666875798188,20.053040554737194,-86.16184428625442,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark63(72.429507303865,-35.23309494000206,-23.409288906615757,-29.834234716068494,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark63(72.44528829233633,-64.10303553838676,-77.5949019445171,50.28738721830635,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark63(72.45626438624572,-36.56026301834687,-3.326784680786133,-32.34188264785689,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark63(72.46734257241846,-18.039430442949865,-35.26311671130473,65.02645375014507,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark63(72.48169034197764,-68.66252104630301,55.18771234195202,78.21069635964261,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark63(72.51652423868663,-44.81082684560897,-16.891023496163896,72.41192497170871,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark63(72.52363447944376,-57.275174857874475,-85.7731198377762,-80.27716563094056,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark63(72.545365139473,-71.59291070178531,66.64348634897317,-26.36403881090179,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark63(72.59517923794817,-0.721290392350312,62.34934321390156,77.70054617998892,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark63(72.59808393427122,-38.0605051255001,35.49711379193761,-73.50562867901216,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark63(72.60886779915447,-4.86487150043709,60.76832944812486,93.80643548623507,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark63(72.61617148610645,-42.63408061683196,-39.79632316439752,-62.76570219127089,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark63(72.64435067119464,-35.24780425757169,-81.85300837047443,64.5226627624765,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark63(72.64724886849916,-41.09066964482038,-99.41986873012188,5.8555906103255495,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark63(72.6595776931023,-0.9619627065059859,4.814667389913765,86.42975889568325,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark63(72.66908519532188,-70.7060518236067,-52.74214971030546,72.2866897769301,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark63(72.67417026384277,-39.79242647758119,28.561344016504535,-61.92679170563296,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark63(72.67680249950791,-9.862706961921333,66.85717499927617,28.270256494125988,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark63(72.68206729627957,-16.117961896783967,88.34792234823973,-88.22090468962172,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark63(72.74222362357378,-10.234809464233933,94.36238910149686,80.83324507223719,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark63(72.7683439383222,-69.57090034843901,-57.73049664842893,37.536633730184036,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark63(72.77450395804618,-42.22279029299965,63.2242688687239,10.596527926490793,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark63(72.78472980543543,-32.90681584894939,21.897091377885786,45.29063441969063,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark63(72.81517527953005,-44.791653696727906,39.22688197217559,-47.78488589074455,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark63(72.81574135234587,-11.266299921941012,10.814770711797792,-13.695717597364634,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark63(72.82423160593123,-26.89294724040468,-35.9266855160072,-11.896184301559416,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark63(72.82651078859396,-38.36614958314737,65.35413998851666,62.85115917030592,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark63(72.82895117688068,-19.497672645052134,-9.106061782654606,-40.43407289864604,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark63(72.83212386552171,-26.724591301744624,-13.734186264752537,1.342727712433927,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark63(72.85584330108978,-54.91904073736149,43.893724333546885,59.12437457990501,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark63(72.87517733063459,-4.682832622674681,96.47793569384868,3.240668673283409,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark63(72.88147029418448,-10.96839132354512,11.591457576846878,81.49101599414348,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark63(72.8919506336594,-15.566649198074927,-37.75462220101016,-30.504354108890922,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark63(72.91864182649402,-54.61042320133862,82.32636371271539,26.140489995108254,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark63(72.92464535268016,-43.381477820388234,69.49915518183062,66.66974667885285,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark63(72.92563707672846,-66.92680911543962,95.56491407466612,75.85696505703999,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark63(72.92926625665623,-64.29261488247701,22.932936725731892,-42.07875074104184,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark63(72.94116024888217,-53.07322550132354,48.99361409805735,-49.624377456782256,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark63(72.9582389508848,-40.99350173525096,83.404963372536,84.73314714430319,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark63(72.9708966842351,-55.53667959255799,-62.4887434921225,-39.73283493174024,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark63(72.99698307983303,-19.943616107758515,88.3820112505893,-11.37146547189964,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark63(72.99795704551599,-46.022161491930305,3.3760603248310446,15.060085398272506,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark63(73.00491342802906,-50.79462255410676,-27.243729108463597,-62.67185101128885,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark63(73.02631484601505,-9.962667250380036,34.70030166344108,90.93898960135067,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark63(73.05321384146629,-42.853082573663734,14.50886205887241,66.2529923959872,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark63(73.08871420515041,-56.86035212480658,-59.901463530320974,33.292696378425916,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark63(73.11167394767469,-24.425903970806957,-90.88386740868106,-54.75600720595031,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark63(73.12160540937126,-49.42061712127783,87.06009080669682,95.55424461649145,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark63(73.17313643436168,-54.404290534182806,-90.98733247518875,18.587222129399763,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark63(73.22461183330938,-40.58938706543598,-1.9299183791971188,-22.089787290358373,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark63(73.23598513318973,-39.42874981047786,-65.19479624006107,-75.84995540603441,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark63(73.24722292361454,-52.78695795565553,-4.4150057872995205,35.78651302144897,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark63(73.32650382169817,-41.84178362371122,-17.452300519666352,-13.699226682709181,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark63(73.36272269926266,-59.89795352567917,-86.80724959445865,15.519919640629752,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark63(73.42134858211762,-43.660761483054934,-73.81400010450142,55.300389875268394,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark63(73.44585031633886,-0.16835183869116577,44.233908404350274,-77.27505097169725,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark63(73.47184623601538,-2.1889225588960386,86.36638187887371,-23.51317114532756,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark63(73.47930846539953,-39.641566566710054,88.63710029571507,-54.29397588788161,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark63(73.49554982693093,-44.538842804182856,-13.163837400051051,-96.14713097045441,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark63(73.50965021884593,-27.897073926700685,-24.4052326113175,71.3565687264853,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark63(73.51738199049063,-42.89966886502437,-76.28254551295586,17.114230653167596,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark63(73.52280595833537,-36.60000040381994,-32.932381259582016,8.800694658674743,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark63(73.53289427876445,-34.79844895602595,95.08192468869657,60.1125987771062,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark63(73.53621837296421,-56.6881708807786,-62.64827092897234,-75.16781305003859,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark63(73.54455988269672,-61.84096588493557,62.390021450249066,-26.15976460071674,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark63(73.55279877422115,-67.81261464151629,-51.20289179504227,88.15399254104634,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark63(73.56481522358496,-43.45170612323852,53.018258495449544,-54.398429001698844,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark63(73.59621895768876,-26.059018395671217,-67.1718838370036,79.59817136406647,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark63(73.59721390903309,-35.83833696836642,-55.394687346250706,-15.239060485659223,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark63(73.61019145323556,-42.076643796330785,67.19689640104934,-83.46119548647437,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark63(73.70599960691516,-44.816711393217126,47.66868750048897,-27.49456295697516,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark63(73.71172087359255,-37.76861047855697,24.674446790169284,-48.50788249551965,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark63(73.75869815075089,-45.90910812859968,-21.522301672404282,-31.262293432703387,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark63(73.76885658803934,-60.26993046429811,88.93224073747825,-39.2790522130267,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark63(73.77190166294673,-17.365317208801898,55.7889622095426,-82.6008502871685,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark63(73.78112764609955,-14.20607417073208,-47.98236842065593,28.02608468110185,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark63(73.7897503318462,-40.747536799772476,-71.5386621724128,22.30718963025457,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark63(73.79629439798418,-42.231890252637136,16.83893485940122,51.45380002258807,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark63(73.79952950334004,-30.761450084524824,1.3417575940745365,-76.28863382283666,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark63(73.80877336758033,-21.754113828138458,25.730421811953292,-37.7769904583932,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark63(73.82786031215386,-63.02765071619718,-93.04402241827619,63.34930551869212,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark63(73.83037897217591,-41.976252645956905,-98.839158608929,-99.84500067885931,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark63(73.88271560206036,-69.85804583274309,69.31782042440054,-38.848247907242374,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark63(73.9173079254218,-57.23412905316418,38.17962835393385,-54.353956061913536,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark63(73.91769436654187,-26.83919141200404,16.33727532423022,-48.97115262872747,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark63(73.93550217993982,-40.49406672307341,9.728537787696226,-91.87062644465004,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark63(73.9433811072785,-60.70647860881267,73.13114173167773,-86.49063938476363,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark63(73.96755695358223,-21.74011620757952,-49.88944128383783,-39.672698357573054,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark63(73.96829763467582,-19.800471538966335,-88.42895362775174,-92.35070694193917,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark63(74.00957658691271,-12.434669179067043,61.137829441515436,44.50038572610762,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark63(74.02067859834526,-49.350696805916236,-28.75298649584255,4.5061775016451975,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark63(74.0494208237252,-28.988329465108677,52.28161084136639,77.71600997619532,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark63(74.09835191180483,-51.46376844230889,-23.96847661825403,9.312868970353932,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark63(74.10071135281672,-46.6647227341704,-65.09478684978455,-88.09565065359324,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark63(74.1311935469189,-48.98045986336514,15.405915584990737,9.94022529711556,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark63(74.13355901886416,-65.53901417215661,90.0738287691999,-37.588103629024296,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark63(74.1760114384848,-22.98534702365278,-86.5008599494087,62.97391216540311,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark63(74.20566208681652,-44.93028512046351,-26.584232446181815,35.94501065421932,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark63(74.20842006269731,-62.78554862400965,4.874462965754333,-55.20896348255058,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark63(74.20859811812909,-19.430451643762538,16.820066316297925,95.58516298751002,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark63(74.22937579909706,-29.854079378903762,-90.00537077102722,18.996800037944595,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark63(74.23430867638066,-42.21050212601132,16.242519449822225,95.78433333959742,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark63(74.26247286176854,-62.436024924846166,-52.71951417724783,58.54476416398498,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark63(74.2672298547956,-3.302491811551022,53.003353154148186,-76.92181290899165,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark63(74.29249384378002,-25.55069873005256,-97.07168980364817,0.6895567461233156,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark63(74.29327097880619,-67.1412473692319,47.42913902497813,79.06834761057792,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark63(74.3012308582563,-20.610321556078986,-32.80726399276142,-31.540969226516523,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark63(74.34962828800792,-65.77851348187559,-23.238912314150255,-77.77886826888172,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark63(74.37019436423961,-65.81096458971483,-58.515269226418944,-24.249641609688695,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark63(74.41296357427314,-66.65554110004945,-88.97169781433756,83.46915944701362,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark63(74.41708021774755,-49.59347108356202,90.25005850478104,-18.912353216561357,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark63(74.43009128625673,-65.57470433055002,47.21436557675901,94.99441992344563,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark63(74.46696114752444,-60.7862243620727,-60.8197454983737,-71.12667889547477,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark63(74.4686127125822,-7.038992476967792,-18.78136405805968,19.579575754239258,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark63(74.49156045459623,-27.783143901117185,65.4083240753366,77.56978466603385,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark63(74.51364187545423,-43.67963332503988,-38.04063678011407,36.433492135805324,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark63(74.51982215853619,-66.8396583428778,46.22619194580025,31.043503673973447,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark63(74.54156784848757,-82.89048808667823,11.066981706934385,-0.18349278837726501,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark63(74.54880602873689,-29.795104912948418,-39.16758551777606,-73.96081207559793,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark63(74.60082478289442,-29.329677032606625,5.113950798234711,53.8994272894268,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark63(74.60189434820063,-57.56095036614899,-18.465038641026226,-3.801743073363923,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark63(74.60984816104144,-39.0343116476054,96.62484270434325,93.04768720589979,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark63(74.64195478407723,-18.165595957486858,25.080095632620484,87.35084939883967,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark63(74.64936406364592,-13.139687642678481,58.31669044424794,-17.28634424100673,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark63(74.65573319953981,-61.36388947306142,5.5789432649166315,66.74097457743068,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark63(74.66365993745106,-53.51762131626643,66.00991416072216,93.35455066615023,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark63(74.73603699011326,-66.27035516889839,59.81395122569836,42.31817589275869,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark63(74.78187477632102,-68.17468083653134,-10.438404096160411,-69.93664572494937,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark63(74.79268562582885,-67.41971238921852,-66.29486067841816,-90.8060582056337,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark63(74.79934401290674,-32.93026906237448,-90.42369548644653,-92.61980661334775,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark63(74.86873744930082,-60.80647778423531,-2.7460604504722568,-15.889442798513542,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark63(74.90571091442715,-20.714059962550976,34.52445489770733,-57.31784369276496,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark63(74.90892741961295,-28.089809349964284,27.513484511019342,-1.0125491233401647,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark63(74.94127893276513,-13.35241637667825,-86.92430001926104,-22.757079388734766,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark63(74.94896656692723,-72.20839060175845,-20.750898148388686,-61.926833503699456,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark63(74.9913775054651,-17.367156609086365,-17.405111376719802,25.62731337378588,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark63(75.02717894441966,-28.59141121927165,27.309634714237063,-92.2404711852897,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark63(75.03021785240225,-1.476885495756818,-3.786454131118262,3.798506669469063,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark63(75.09059585599795,-32.43933306544979,85.97623492285456,-4.283048620064676,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark63(75.09324228760124,-71.66439728097278,30.716620153414027,-16.53996606595345,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark63(75.0961820440024,-62.69669809067544,-54.60386314023504,-34.17562064182198,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark63(75.0978789996993,-16.224181661662357,-81.28195380539952,-91.16851746570387,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark63(75.10604698240832,-35.93100463390748,58.64568542446139,79.0618020220142,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark63(75.12936886264609,-17.16302626435629,-77.43563162882623,-51.32883307573282,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark63(75.14842496694891,-37.68253820255991,36.37129352533407,1.7257725628454779,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark63(75.15829070027485,-29.961021654042213,77.43297904255189,-59.77478729511658,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark63(75.17703892775972,-39.659646409805546,-44.61657252810021,83.301676078121,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark63(75.18286148570724,-75.05975492815828,-12.490989807835163,58.42650277604693,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark63(75.23066131816373,-54.6063246272787,-63.788682832972235,-3.463805962930323,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark63(75.23856872266018,-28.973149988444376,19.958500151322127,79.25080253912566,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark63(75.24043415115557,-30.94249169613886,-51.33220233657554,-14.42122675876449,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark63(75.25499915780708,-47.855890150187676,15.96532748956703,-82.25480777408241,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark63(75.27220844920137,-74.30748573562471,-20.831163198979993,67.90819708269925,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark63(75.27684405938416,-56.174582871423965,75.53095009793657,-99.24485365383082,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark63(75.291358791759,-34.68084697950333,-57.781866254787985,-36.76463190691464,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark63(75.30069550858013,-33.86993744179554,-21.39173012446524,85.93102120439107,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark63(75.30269991243017,-73.35525079759091,30.76608486828357,25.77454913889332,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark63(75.30807295991329,-35.64566332942691,20.865712797509644,75.88588128617661,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark63(75.33089142841874,-65.96929524098631,-23.467538324856662,-69.95887823953541,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark63(75.36187140292489,-21.814402376621686,-66.53705646238922,86.51419239006563,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark63(75.36221504172943,-49.95571846102314,-57.88004176474444,-2.7376214280588442,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark63(75.369729954467,-36.93489725912429,-56.384858779726855,-90.83292068296609,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark63(75.37815499265915,-3.174675042842921,-17.599665745786794,-29.468316159826458,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark63(75.39411153368175,-25.839465404675394,-77.26721666264888,-18.69413722997757,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark63(75.39434917810007,-26.52920301923747,-58.77092759609648,61.02938640024962,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark63(75.39478736351421,-3.34357711570577,0.3212214450289679,-4.901733897684537,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark63(75.42969089807923,-44.24062989564683,56.926020645303055,-16.12315006065856,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark63(75.44695898970284,-21.196182193539997,-15.74023620297136,-19.40250641448482,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark63(75.45973268213328,-43.6497846504972,44.390464082030576,-73.47484413652452,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark63(75.46681814710351,-6.563838715535169,17.57275463777131,-90.99373851779451,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark63(75.46721871016425,-9.068561925017775,-62.650305995109726,45.33134422228301,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark63(75.49203817018511,-23.941859643913517,-80.96659818377381,43.48205949543339,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark63(75.50700365674757,-57.97175361427418,-73.81287477043571,-47.385390269794755,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark63(75.51649269957318,-49.81581720124246,99.00433976624811,24.851919357899817,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark63(75.52466302183575,-64.80191554388207,19.098854464730962,75.35709503998066,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark63(75.56050994323184,-3.6914789739755633,61.18152120288218,19.406621572078777,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark63(75.56943217884512,-54.979304723504654,-40.03977806215353,-54.6328001821023,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark63(75.57696005607838,-18.956123162725106,-89.86649579932002,88.96697731420784,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark63(75.60497809911863,-13.578008557626916,-8.090871824458134,71.86656490556177,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark63(75.64163156138665,-20.698041496294422,-1.5868998533106833,-76.86187601126313,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark63(75.64226920828355,-8.026396164620238,35.92416452970309,-78.34050447258363,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark63(75.66316949665048,-15.11441670964308,40.714962860887056,43.11041534952662,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark63(75.67901398509079,-57.99109766922326,-41.42069297826261,73.74473420677779,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark63(75.68255844409487,-69.16110055171134,-90.49440359159648,90.34487214908378,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark63(75.70613618288354,-48.904355875021444,-83.46975262443218,45.79961884792115,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark63(75.71152811488292,-52.583138494466716,-23.50520301578743,-40.98307019244049,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark63(75.7301976249552,-67.00610357514722,-95.95397294125303,-68.222807871975,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark63(75.74748810534408,-11.104595922027613,-1.0583741959632817,-92.2537285259314,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark63(75.77262875818425,-1.3666990417478644,50.65004559218917,52.96931920842829,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark63(75.77484417314716,-70.64119368813506,-63.34393591850689,60.69728598143237,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark63(75.7823568998669,-65.15290706206676,84.92414421778699,97.19298841873746,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark63(75.79094124933212,-73.08596727474159,-54.67918624510746,32.40716714800027,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark63(75.79153744265022,-39.35389876882762,-17.868135179923456,18.612122086330317,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark63(75.7973195992225,-28.836230593210658,-33.71188179919757,69.45943586702413,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark63(75.82096101455272,-36.901979330210445,4.720363105561717,-75.31299045794051,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark63(75.84500239337666,-15.069433895519268,96.34001853450539,80.54594338588018,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark63(75.86450503874542,-4.64975850076226,-39.533229968167284,-29.319937829642086,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark63(75.87286003533382,-76.5280474194491,68.65227979392427,-50.22979647769314,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark63(75.9002275922378,-25.74527389908677,82.51807132682677,-18.71494223112093,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark63(75.92439123127329,-11.025804608603167,49.571624751691076,-47.294404382339096,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark63(75.92649247276844,-58.185930371630576,-87.56231993834878,-26.727092153344117,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark63(75.9507435713005,-38.823873978627965,15.27092170772633,-88.31618905066001,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark63(75.96819716338689,-18.42898606049637,0.7322407546161713,-76.54439572792518,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark63(75.9747805083363,-3.2095187897048305,8.73660193908745,50.33438297027243,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark63(76.01879016822178,-0.2525315422159622,25.429558164449602,12.955017920041428,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark63(76.05053302213167,-22.12366935814441,47.236311699444286,68.31838832460423,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark63(76.05335055247292,-36.125434784260555,-36.73566802916586,41.03192517428516,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark63(76.07169308364305,-40.06461675881461,83.08125144975648,-43.38407342078372,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark63(76.09627703916101,-39.85546365830246,86.6903937175523,66.99238931316788,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark63(76.16266184214643,-51.451311796996514,44.09040157620805,-8.654886456570111,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark63(76.18780144768843,-32.77080936682253,-98.3494060469879,-21.19155349108061,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark63(76.19305020060949,-41.539977546119175,85.31847847678333,96.55770023623467,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark63(76.20492835767126,-42.38198000132422,1.2251473582190187,-42.48441446827975,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark63(76.30217059623018,-49.08630778202286,-98.92288402985245,90.56949910981064,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark63(76.35334714468075,-19.270705893419063,68.12184485256017,20.782262221277392,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark63(76.3569739071022,-49.074001706044726,26.983898867520708,67.78062049020917,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark63(76.37960501152548,-21.14928344186265,11.787331788458872,24.004280320921254,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark63(76.38532163548001,-7.803423254689818,70.08602872464022,16.84373985908678,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark63(76.39227185059923,-15.109289409272876,-16.82421617467007,17.044116126412405,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark63(76.40044439206522,-72.47679007298004,-0.3205644165565644,-32.03534631128247,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark63(76.40405736847339,-54.1056182503729,37.19626944721,-44.98198974086209,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark63(76.42711477384472,-57.26388271957281,-82.7976858019976,95.06650837783695,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark63(76.44192156096557,-79.06836235051821,38.21287601974305,-13.837109517229962,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark63(76.45833172336526,-54.05935380731612,64.59914264519207,96.51035804859868,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark63(76.46716983088879,-27.730508958942153,-61.799716733778396,-7.11355031677445,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark63(76.49717890570946,-17.63194415796076,-71.72496678202096,40.70976026888732,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark63(76.65806291774732,-17.986937151842938,68.09959025720741,-82.31309619014186,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark63(76.65826155474096,-5.480743621903457,99.19222147057681,-94.27962450954549,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark63(76.69507914500275,-69.6641921133855,-11.098558849799446,-12.983819265536937,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark63(76.73171486009633,-58.62833153562443,-50.88663756093015,97.78162605117711,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark63(76.73619504845553,-23.588578009986776,-0.28803150597460103,-48.73520016047064,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark63(76.75476840481707,-20.480657285477946,-69.23803485571334,-42.553806266308044,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark63(76.76677453179309,-46.83567573886618,74.46602558401935,-45.19690892889145,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark63(76.78535171897255,-18.982718957491045,-14.56162882372682,-54.14779340841076,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark63(76.79240971698414,-34.02705141303825,-44.107943500049764,56.34074897344644,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark63(76.82104157405251,-60.701460090184376,48.00839538996783,-92.25494512232764,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark63(76.85229127307039,-5.1044285814164425,14.436416415401737,70.00705377872376,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark63(76.87709472905158,-36.7112366967415,-62.06739716844156,79.99342160175934,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark63(76.88860067671459,-17.882160997954387,57.6898224945723,87.21089909165318,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark63(76.89121641105629,-11.133904852377412,-68.8420382427667,37.48062979611797,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark63(76.91235475848052,-13.257676416582271,48.1595020120657,-65.86656955066582,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark63(76.92956533722483,-37.141967037500166,89.60136664704993,69.457094218165,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark63(76.94163630934023,-53.025289446094746,-96.69436754432392,94.97047225174757,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark63(76.94791792782866,-10.59383247531835,77.92384337112733,-71.29854314948577,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark63(76.95361644215143,-24.904278993551102,-89.26719893355796,-45.63513612491097,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark63(77.06785675857714,-70.30252286365015,-91.10597597090452,-74.2835609094614,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark63(77.06801892204021,-10.976409445236925,-5.796320369635438,-72.72707286804626,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark63(77.0720613320187,-66.72223880873089,12.475531608519816,-23.26421864280354,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark63(77.07901981194144,-76.66409471189101,-93.20939668325533,9.829431677902733,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark63(77.08377593501717,-49.38440838529272,28.286741626326034,-56.00029614092736,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark63(77.08987548188006,-66.9313690693607,-46.61966272434726,27.16374723945016,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark63(77.09015860222348,-47.938737499531925,-51.11316832872652,-36.301296424095966,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark63(77.09225182060183,-28.363306597125955,68.74579368881479,5.4927063339747235,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark63(77.09533968229053,-37.16624921954062,-68.85761799840986,1.2025180175750876,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark63(77.09545800722856,-57.92981157884931,55.04047102629778,91.68967000352427,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark63(77.10139603654059,-58.47201423403838,-5.6478916225970295,57.12853522979324,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark63(77.10313902013252,-19.909124402032276,-89.04847839893029,93.34705382466217,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark63(77.11694619014602,-30.50896629806516,16.40970474591134,66.5918492548087,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark63(77.14201493167238,-13.309738872935355,-48.76380990194882,-68.9409797018495,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark63(77.15345587806797,-23.914682262635978,-85.6037280109536,48.98002480404898,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark63(77.16257431966531,-66.57954648563182,80.63820259487912,81.42825868785977,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark63(77.18718905004138,-42.695287221989034,21.228572627232097,-33.6131261135115,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark63(77.19860146505667,-73.17433892947334,94.42134417682499,-84.24746721983271,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark63(77.20444398757883,-36.27084018196467,-98.02202968269928,-32.760536892825655,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark63(77.25088842871159,-41.90901091995236,95.22339602846947,99.97250010887583,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark63(77.31424884922592,-32.102208986203706,94.28634630913143,-48.97372707427547,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark63(77.31972789084537,-70.21223861680886,-67.09249258827,-32.73026358505679,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark63(77.326279155696,-65.27994205541793,-27.605056264507084,36.10750816740881,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark63(77.34012209227154,-72.84267938323279,46.22858899071821,73.30339600936074,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark63(77.3547028374114,-27.4815385155093,70.11273425867876,-92.65933558632686,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark63(77.38567818752622,-47.55305384662325,-20.786435988140028,32.20638248303749,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark63(77.39118818734144,-75.25519687683106,57.067499539498016,28.814218263049185,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark63(77.40410088658115,-19.91289146077493,-32.80680278590988,29.36759061712101,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark63(77.41829280781891,-63.7723543944146,-94.08773216425519,2.3555325530792572,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark63(77.47711951838144,-4.689232141287533,19.46712141466236,67.75800493760147,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark63(77.5398931913524,-61.2584959335281,-82.4054100944011,-99.8507595908092,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark63(77.5718406854156,-76.11293558604355,-32.99739570708317,38.58696688047337,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark63(77.59643766578114,-36.151173001622695,-89.72718914308946,-81.29331648794943,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark63(77.59734204372276,-4.921615833936244,10.885143723091574,-42.87218839611453,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark63(77.63757111585684,-68.93783419095081,49.68304018146276,75.71183698972709,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark63(77.66267571763308,-30.644836132178924,77.09810633565581,-0.11333571133150144,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark63(77.66931180519029,-30.743446717753642,18.89882525124345,5.1394189843731795,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark63(77.72194463502186,-47.02474574254112,-64.07017533403157,-12.719462784389762,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark63(77.76904380974301,-20.673889989702516,-88.13402083747673,-19.824222894862785,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark63(77.78037877839051,-9.352910226659517,76.88090673491917,-24.122979083238192,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark63(77.81850079082818,-39.85729668336233,6.190438837922272,-33.42585866763359,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark63(77.81878720656783,-27.956684717455005,60.19807200899879,-0.26472849559384315,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark63(77.85276061078832,-10.088180357398358,-32.994081201483056,88.51876055547203,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark63(77.86999606570751,-41.73846348844923,-51.045070921410705,55.81175056408452,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark63(77.88286595046216,-71.0077455849802,23.467938637313495,-5.674496002883259,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark63(77.89875714293728,-74.54425843102585,63.42602729601816,82.46967306595042,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark63(77.9108368400974,-11.376529988233727,-74.67371634305448,-2.6853469422660083,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark63(77.94730286649562,-35.21477017224505,-9.212118607979676,-54.34416234217334,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark63(77.95435601893638,-48.55927558929327,-23.684198691687584,-71.3519887796015,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark63(77.97738765890549,-22.325009476112243,32.09449823599928,-69.1609529022943,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark63(77.9843856289157,-49.82833475735675,53.193803455937825,-34.15414775496701,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark63(78.0083995060806,-45.05403449066845,70.70013401068124,-54.29445273836053,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark63(78.01661532215704,-10.718699124335856,36.59173257956982,-71.83525998480793,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark63(78.03046503004632,-50.166457232037146,59.48139141886966,30.238385027707494,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark63(78.03228895920981,-20.10019138681949,-55.36671373776705,-45.29682482211841,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark63(7.804156686828435,-5.165506229923736,-8.136085481446798,-65.3305884223444,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark63(78.04270646427682,-61.23408968911559,30.162994996860732,-46.23721197975177,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark63(78.04309663905943,-64.53868008819214,98.45781410504756,-96.25849097060231,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark63(78.0657200474825,-24.970057038391232,6.497358655104819,-18.95659177717026,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark63(78.07660911406111,-48.968422661717504,3.35923608890522,-69.39731916875805,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark63(78.10972083136721,-36.582278183071956,-33.485286552045864,-29.411107260534635,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark63(78.13365019190974,-10.50309889850898,90.87985792827803,40.37647283001414,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark63(78.13807967229945,-25.381803244369408,11.380957392555246,-34.81053027264424,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark63(78.13926357491908,-61.90364550959728,-95.9134639276321,-91.7555270760877,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark63(78.15489551974179,-38.675424686620886,-82.1801263802104,28.171048215495233,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark63(78.16865486426374,-26.039856443848592,-41.315444631581364,23.506321328160283,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark63(78.17065872443294,-42.62650578284508,87.73144404296792,36.694198790325174,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark63(78.17586368263915,-52.42000009882677,-25.6690510688816,-80.1164683582539,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark63(78.19155961296966,-44.69967891905733,-38.42686126598276,-96.71513709906532,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark63(78.20428733123353,-46.609640644213115,26.276986752379642,52.75125146303321,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark63(78.23780388836718,-63.565929539508836,-1.8263490059971161,98.3290666691882,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark63(78.29083635497801,-58.931398092528276,-77.2708795670627,52.81733402339063,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark63(78.29220389539947,-62.32825921855636,-73.8092567052403,-90.26114730323272,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark63(78.30434705662694,-55.59887495613138,93.67115818707438,19.455043745800026,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark63(78.32515926033005,-2.8120543207804047,-16.29021209422578,-41.35192834605574,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark63(78.34922363181104,-47.34093936390846,10.572753861679246,69.03809255944253,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark63(78.39165421223356,-47.16239499059001,74.31197061098976,30.195481509476082,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark63(78.39831271078279,-22.608118309920158,-58.03414452046933,-60.34786352159431,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark63(78.40117716454625,-72.97001994288223,-2.010106381280579,-72.36927934943651,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark63(78.4274493992626,-38.035945575666766,-69.76233238153264,64.9226713248427,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark63(78.44424960327916,-17.32198037681654,1.9568015709168236,-49.56461186361971,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark63(78.50670028300698,-5.66556399691585,-39.89018580948478,-34.002059568039854,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark63(78.50827608935978,-20.202638817136005,-51.025658365164375,-27.62552904162385,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark63(78.52450559673957,-29.1301085890928,7.639102566944672,58.96922220484586,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark63(78.52453680098512,-58.97404897620202,-8.271554850631617,-40.371722673827,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark63(78.56781933764893,-53.65350107600486,-8.822217459128638,-14.615403342757418,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark63(78.5809543362964,-32.733905922522766,-87.09756663024496,51.18949440240118,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark63(78.58328081279544,-33.00484913391564,-36.00331468454259,-6.206574282575517,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark63(78.61090777472316,-45.10982265932177,-57.73477887818288,64.76566732065311,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark63(78.62010283467419,-57.181679115546366,43.47269109303534,-1.4656532454642388,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark63(78.62433071649994,-66.33555616090933,98.37355856358337,31.524326229300897,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark63(78.70469426547743,-35.94753955767462,-45.733313650159516,-22.83221287411969,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark63(78.7048986763422,-13.48537866713653,-0.747704919140773,89.62849116389137,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark63(78.73020932464095,-26.904200267136673,-75.7532972942821,-13.69547062673,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark63(78.73530234593295,-27.909172408256808,-46.4336978959285,60.95552406820025,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark63(78.74131370701676,-53.186960134899564,-21.517500921585935,19.80920118543621,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark63(78.7674040302987,-19.80658643847147,13.628921174867543,-24.460755767976664,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark63(78.7789858755489,-42.70194993682668,94.84149206768785,-46.74069801155105,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark63(7.885219747938805,-0.24662904006960673,20.594070340113177,13.037212778384927,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark63(78.9198456196103,-48.502777850909865,-66.14534665116886,-54.15310601422081,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark63(78.94704072677507,-67.66400210714751,2.8937353834984236,80.72365077184634,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark63(78.98953859180992,-56.87996713537908,-10.878347064343075,33.185494068488396,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark63(79.02536766666779,-20.616875414617027,12.3416596153983,-51.877767398029206,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark63(79.03080717316098,-32.912377038537485,-93.8723666060204,79.25757315632794,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark63(79.0360212144275,-45.80346156127963,-67.80812424016902,92.702398064162,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark63(79.04620270988289,-55.41183387107607,6.5016693551021945,44.377595811436066,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark63(79.05158241153396,-53.300424837377115,-14.446574000609829,-72.82762806304346,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark63(79.05443821486617,-41.79720603298938,62.59165086830669,47.94069509114513,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark63(79.06291457765536,-34.23030618157077,-95.79830034790275,-70.09434343335421,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark63(79.09385539127209,-10.602424616844047,12.53898543654364,-72.7778086179997,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark63(79.11689450771544,-45.65967608147461,-6.283342632219842,88.68073413809458,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark63(79.15361434290176,-45.72539285132269,-51.180151629141136,-44.683546327598165,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark63(79.17088772711983,-21.798681052873818,-70.69832313507042,39.311678196876045,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark63(79.18827668075267,-73.2020988368493,34.268040455022685,-8.877415043580328,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark63(79.19458190607133,-12.171792363128247,-2.1293292867506466,-54.553349313872786,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark63(79.1946282420173,-59.60826638076806,-69.22306260949549,81.14081844298931,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark63(79.21669149936625,-49.64285682688052,92.96453069910987,-82.67130114121457,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark63(79.2211694195851,-74.83670378382017,73.0717876388972,-26.69823364314945,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark63(79.24414185650718,-28.478021369575842,-4.649212766966031,-1.7267258885625552,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark63(79.25083028243796,-73.09065554773035,-23.625638558260675,44.25988383474575,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark63(79.26483769201863,-76.96822529310117,28.735073810015223,-61.79631741424085,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark63(79.27863132440271,-1.7995079147496966,31.218984180854676,-7.997248505640869,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark63(79.31625018778229,-78.22755634162408,-8.751285593416782,30.527988626669753,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark63(79.38481354227682,-47.60779843892633,-74.7972222794593,80.18968980622736,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark63(79.38526410147148,-62.48459920657255,-49.2181064880413,68.61054200740338,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark63(79.38530432280535,-27.96522066542626,86.54314600648027,-37.779672818771125,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark63(79.42434271176722,-48.666400051980574,38.23552053399649,74.6532736167585,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark63(79.42923559826744,-23.89465061608584,-49.66704062171379,87.62170729303094,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark63(79.42993596897509,-21.923447059676732,8.353818724764949,41.135139335061666,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark63(79.4346924770949,-27.718675223983368,-95.41140179593926,59.95522110196646,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark63(79.44312751473305,-75.84947641228223,-33.169925960571916,26.336964691264228,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark63(79.48431372643239,-40.527670008666526,50.14076181198183,-49.94103084510275,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark63(79.51260756265651,-54.71561262610854,-26.51000951465194,-69.69872193821033,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark63(79.52330278543624,-96.95084661004145,93.83566743880107,-2.7804155277462144,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark63(79.5551905526803,-7.690360365487535,98.5819284836189,83.22176776699231,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark63(79.56421081642262,-11.32212845104749,43.900124618052615,24.42490902371712,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark63(79.57154273142558,-40.49293164485761,-59.37190895408635,-49.51515658164529,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark63(79.57919313396337,-59.13210402942719,-17.315341177156384,-55.63781305740538,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark63(79.5848580822971,-51.330767909278265,46.21576530084292,-5.111127887191728,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark63(79.58503371801078,-24.375602042375277,-60.31979908762868,-48.873269803260435,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark63(79.5968736349219,-72.33305982321491,39.72348663261002,-34.03475088110525,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark63(79.60362595876057,-79.94468372807242,-58.402716506780415,84.47964689891563,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark63(79.62430243088409,-45.66354272717461,-16.221426654702924,-37.01934429499107,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark63(79.62555981449978,-48.59714397188508,-23.31562364867675,-52.4403192834566,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark63(79.63908554763094,-32.318969492947744,32.71669441758348,-8.893191391896679,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark63(79.64845472915209,-3.7641645672862154,40.19610349319032,-28.200855739841302,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark63(79.65517774099987,-7.111018548846886,48.9747051150413,-51.494199697325605,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark63(79.66763308815607,-13.453550653012485,43.62083584897846,22.165273657160853,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark63(79.67715156133704,-8.337285770068178,-70.48032331692636,32.70099206549753,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark63(79.6827990373173,-10.487357133729233,-10.647903670707606,-42.3107868961931,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark63(79.69391636443851,-47.01906578012554,70.69007974678075,-34.965454719625555,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark63(79.70502899296005,-8.369554184399192,69.1656729739795,32.71514082020491,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark63(79.72020878596058,-47.33736741409174,-47.064425129722224,-24.87762960036389,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark63(79.83209687860506,-56.161085519712394,-65.965401993276,-87.15448901402246,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark63(79.83356607234828,-19.592519803743684,21.85635939997607,-26.85607758100666,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark63(79.8503484801843,-55.996110488021046,-28.147990126611063,16.199379062827205,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark63(79.86043448739593,-12.600499139372332,-81.76545855974264,-19.272428441425717,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark63(79.89591409964879,-33.23230075820378,65.58548329325305,-52.00820932147152,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark63(79.91325451208661,-74.06570361255662,93.9445748324473,94.96499619735985,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark63(79.91982972772124,-53.44903335071392,-67.97885254107756,67.17036003729936,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark63(79.92362328698374,-60.25448297128264,-55.49662203543764,42.45053422585846,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark63(79.96868791027973,-4.83486985364469,-17.4703885248137,-37.30092946468715,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark63(80.04167081079373,-15.818137677146439,-21.127625946004102,-43.72119138555368,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark63(80.05497212800654,-19.347671910866126,-11.675714326041174,11.249598875521698,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark63(80.08921309135911,-50.06967319638094,5.871896362807334,26.407434204356562,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark63(80.09885351558455,-66.65348849587447,-90.6573731407404,-81.35460856819974,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark63(80.09998157218308,-35.85287357637415,-4.719094259025212,-43.80636820609516,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark63(80.11320173534708,-8.819593425576926,44.630051366497554,34.46197160391466,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark63(80.12516800958122,-63.403100495914885,63.003390418753554,39.171243309511766,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark63(80.15081375908034,-43.354916011725365,-57.35010265298091,0.18400519612380606,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark63(80.15138424644579,-59.6792519097878,-65.15830568301962,-61.34526983705517,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark63(80.17344653149476,-66.52224239392226,36.825303583207244,-19.93440640339992,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark63(80.18206107380445,-42.87690084163369,31.946067177985213,98.37852950555958,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark63(80.20561224589008,-71.61735068184129,-49.05150059655872,34.81177487242607,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark63(80.21958781358387,-49.66486014089999,-96.1477331850021,11.758177951560526,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark63(80.21981945670669,-40.92126375783731,10.38587957471593,48.38394815010139,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark63(80.24667754146213,-31.48437155169124,97.71525240999063,62.59603214991901,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark63(80.25584768991726,-29.453147141790282,33.894199674005534,-60.2961666348935,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark63(80.27719227494313,-2.5549281518398885,73.31691563968928,-13.380935764100514,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark63(80.29687612211751,-77.9289906641094,16.71552839859291,40.454048353180184,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark63(80.31019057025509,-52.85750705381764,73.74119805907344,-40.374210098374874,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark63(80.31658966781023,-72.77923332425735,-68.35862746009948,83.37138008329003,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark63(80.32564304338948,-15.32958525873444,18.476879745169754,50.07570364286218,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark63(80.36672231487125,-22.297113030974373,94.90232841312053,56.487469816054386,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark63(8.041899118330889,-2.2945259626554417,2.5319474992586066,-29.113689056680997,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark63(80.42089679807191,-9.361605298802004,22.73248608311343,-59.6948341215698,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark63(80.44116646904757,-75.49689830361028,-42.794450227216416,-93.30781725157074,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark63(80.44481812388028,-42.052064804771305,23.51964034720382,-33.45083522240529,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark63(80.44762812082888,-7.223232259824869,80.93437604006581,92.46330033975318,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark63(80.48247066519156,-75.37119676981413,30.972268817360174,-63.53698540360357,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark63(80.49713259196844,-38.887678764047195,-22.467873448280898,35.2131908760112,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark63(80.50370043703478,-78.00093746484877,78.1606855708007,62.36683863396112,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark63(80.51497120101422,-25.866435052514618,-5.985369704849646,12.531939828537901,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark63(80.54486466411802,-26.616974311501835,-91.51730662351889,38.846801020436516,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark63(80.57819203553674,-59.89518052414851,83.59663824510721,51.04717023060675,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark63(80.60547964010127,-18.34362684778384,-35.68190635250059,17.648015080960306,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark63(80.6272245085606,-13.481100226561438,25.59297476533216,6.987248437284663,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark63(80.6412298254661,-25.446459459400444,-73.23842419816455,-63.47189141795915,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark63(80.66239640455393,-82.89471627868315,73.11214245214322,-22.004522018723776,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark63(80.67382006880098,-31.408822255684427,-43.25331666335692,33.2728218723922,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark63(80.68180007339859,-68.24036166050138,35.93107919816907,3.577199828189066,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark63(80.68453651487926,-61.68019954100077,94.75514120673603,5.484363514931317,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark63(80.71442058666477,-48.95376108376253,48.14831815160801,33.83993768470722,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark63(80.74168570710339,-71.1547941833876,20.80619861609803,81.5277302247614,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark63(80.75634651125725,-15.59645613788227,62.49577421325429,47.30798963679982,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark63(80.77968979686213,-72.81315282314674,6.195488073731042,16.93686010425924,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark63(80.7822067826593,-21.99998792416386,16.562502594425936,86.61218498357573,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark63(80.79534593914747,-41.53335334861139,14.191800650315002,-34.29957044500111,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark63(80.81033288420883,-32.66952937323333,-53.42360865394098,32.72983156311085,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark63(80.81888691252911,-74.29013558735207,35.03768250316989,27.478123585443655,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark63(80.86420571417506,-9.08337665053611,7.678576176655994,-15.037594581835023,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark63(80.86552197771746,-27.289660913107355,17.363368417368676,55.60612519089736,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark63(80.88987393134883,-34.84652507924288,40.12797662774901,62.571957711541245,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark63(80.92204722521046,-76.49959724930133,47.72051972513887,-10.036135782195771,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark63(80.94667775855703,-28.453371392758854,-42.89252109290344,-44.942372976927935,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark63(80.95434142623577,-22.786184533682174,50.037461611703094,-54.339476538474266,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark63(80.98092591229644,-31.251926835393704,-39.09665239086466,15.117151952988706,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark63(81.01020863947645,-71.43689240643285,-72.15650245529221,-76.53550457178066,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark63(81.0369093836029,-32.72125857481052,71.01170372337938,-0.6206588919661016,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark63(81.0370577768619,-8.370673011363422,76.1822047024072,-29.715927584105344,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark63(81.0571381075558,-68.61998617207507,-18.543970699218093,75.85204525794202,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark63(81.08315959540246,-43.771775911972746,-60.02361293233338,-23.90093284997556,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark63(81.11466921665738,-58.375417202172784,81.7096118293316,-4.051244950990224,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark63(81.14102732674976,-15.2197039892297,-76.51896040026185,9.520657525514608,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark63(81.16224864843377,-18.568093155956376,90.05441251258677,-64.27299011127533,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark63(81.17122760813874,-17.18813622913082,54.789870572926844,-98.53008322287664,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark63(81.17730654558875,17.445943329377343,75.40913601224077,-46.352929225701466,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark63(81.18997382515758,-70.07982158665106,65.51080428482436,-92.10725061936931,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark63(81.19369416006577,-60.71791574357208,-45.882236554704804,18.49163650092271,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark63(81.21534379470108,-35.67711099577322,-86.09016203936955,49.939385688003654,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark63(81.22638973129344,-10.778422909148674,58.206101128681894,-15.999209506053631,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark63(81.264229335344,-16.843700804711673,-2.459621102932587,-60.2436403433489,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark63(81.29107213658543,-15.154225410310374,52.776713878021894,33.50651376363297,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark63(81.31361120375755,-19.33880452375685,40.07765509263902,89.12287445581015,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark63(81.3140159521364,-37.96559259500434,24.493922327991243,-67.83669707443751,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark63(81.31449070518704,-36.14496939528049,31.509067071097235,38.25685688091201,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark63(81.31857627289304,-21.937407838798563,46.680607987565764,-4.447251350027926,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark63(81.32070396728807,-59.02125750276075,-92.33214387804773,-46.100316698505736,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark63(81.33208457643735,-13.597482744715549,-62.08461103905181,-98.93575007322603,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark63(81.33798322643372,-11.36594029315134,-7.667350436694704,15.657692616302413,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark63(81.3411720261513,-30.42666942305968,19.219188353923826,-33.11812533533302,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark63(81.36291328047014,-55.587017321464096,-36.89673753033287,-13.37445607647119,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark63(81.38645089723704,-13.645129670648643,73.46242708301799,-62.47717113619058,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark63(81.3896230783605,-18.381006100462557,30.807450225374197,95.90898937596955,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark63(81.43770464983021,-60.83150057667805,57.480520012397704,-59.04944749271006,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark63(81.4550031733072,-62.813270399807664,25.39822527627335,-6.098629114075038,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark63(81.50185781111409,-46.27795007661428,25.502580558274616,43.13504396190092,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark63(81.53354574449793,-73.00271311218714,87.86703584404134,95.46344116554374,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark63(81.56329978726887,-51.482785793178735,-19.827432498094225,40.43497394897844,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark63(81.56412617625446,-44.5609498888121,-86.16324843212766,31.66713100541091,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark63(81.57469491266755,-63.73776052364393,29.073127783622,14.931886995133553,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark63(81.58466691894705,-32.31783424845548,-89.69188346469838,-19.714472499257326,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark63(81.5912247541969,-58.180988378827195,31.503135886061614,27.260787439619506,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark63(81.62346641117298,-23.720322428438408,76.52514545526157,70.47333837441215,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark63(81.62826317269233,-30.452444186613107,76.29552458644378,83.06798307575153,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark63(81.66682065439846,-39.88627449756119,-84.73680092314191,-31.37519369749542,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark63(81.66982384152536,-7.612736269112872,18.814006746119887,0.33753342773937334,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark63(81.68607804634323,-80.86684750047084,-50.32272307615104,-80.09339751452391,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark63(81.69019705085745,-42.81737610528966,20.741762637672892,3.9695341040667955,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark63(81.70656683671234,-15.750766178195647,-74.29047293674995,-94.18548632435193,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark63(81.71785500014829,-52.804243348993474,-9.297363711726717,69.53746040389152,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark63(81.75985740043083,-6.22864102816267,-5.012159902552497,-89.57882417119802,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark63(81.76973292285373,-31.006339258882235,55.212338205078254,-17.593762079046456,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark63(81.7893089219024,-14.547247649553057,13.038577668684752,42.75418314217262,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark63(81.7972450396847,-59.83986431847745,44.61260035179308,38.55064619527471,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark63(81.7976414226085,-46.66463441212374,-84.54647020429402,71.27024860450666,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark63(81.79995958645549,-30.79749732440237,-22.317556925463336,-29.430402560044456,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark63(81.81054885835874,-16.376630990645396,-39.11993644598621,-68.08363048174627,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark63(81.83055929106567,-46.25244182368442,-0.31836883961506146,-65.73815212329328,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark63(81.84174301730422,-34.5001655766267,66.4870357533076,-25.430742034432456,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark63(81.84842331584937,-32.82520153308484,63.615406165511814,97.18479946167881,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark63(81.8574047434609,-24.296391557373596,-66.34918168394302,-72.6816572536384,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark63(81.90171816781802,-14.561261814758325,69.23449627318087,-27.08550809266039,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark63(81.90534491327355,-45.23584381905452,17.80049797631669,-1.1626675580582884,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark63(81.92368517660898,-76.21237369948754,23.308490819156475,6.915120742544943,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark63(81.95858431447508,-40.2648689050755,10.418570368480175,8.10923809003097,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark63(82.00075202456992,-71.15115078599479,68.43739402048399,-98.49062561789046,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark63(82.00864386505165,-43.08005648844932,-74.21880807165009,78.08805596145456,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark63(82.04461247624732,-68.14044368784383,36.797092422114076,3.0613110200469436,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark63(82.04939034852046,-3.3769690982704077,9.671601627870487,-55.40982904846017,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark63(82.0786007570209,-38.4017342420715,92.46902278061359,-5.551383812579928,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark63(82.10163939207285,-56.064696439999565,-0.6995964597089426,88.00981693768765,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark63(82.11874619459604,-68.60716850046724,50.52681580244044,76.7789587647772,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark63(82.12811383314019,-34.48132145999013,-51.7030783340295,40.84051747376688,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark63(82.1341437419504,-29.096719467157556,92.36892301626995,40.23142312777651,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark63(82.17531015925502,-41.48727805289263,-54.5494389836138,88.55347655030138,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark63(82.2356581017076,-58.22038171980546,-12.125831997955913,-27.773943410580728,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark63(82.32017422914285,-24.899128433311745,-81.274726531555,40.29330813262516,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark63(82.32301439970357,-30.656184725644067,-60.78191365254935,43.01675761387065,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark63(82.34058291802145,-28.659338597761774,33.61268999647493,-81.49940680274813,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark63(82.34919624711043,-33.43196195842093,-95.87155098271025,-62.051969809360166,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark63(82.37974357774354,-55.70891282945141,-69.65179710389066,82.36936067029933,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark63(82.38011216820652,-74.2615632053988,97.16235700986186,-91.31504994243203,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark63(82.39054824039135,-73.00567566420777,-22.133965529294272,-29.489092336631458,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark63(82.3931157743493,-54.600363769749485,-31.754313036437054,-20.464952171932296,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark63(82.41429892650373,-11.013144213947186,21.700332010490158,-7.5982003009338825,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark63(82.44980164655885,-12.96961216773127,85.33383277235811,1.9570814235719212,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark63(82.44982310962212,-31.71445206732497,-63.14649571928675,67.94854204943846,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark63(82.46642720917094,-30.017268114008914,-26.748564513120314,-70.84702348102485,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark63(82.4737137994376,-22.60745574580703,-96.03898400572311,-95.06772297444539,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark63(82.48707444706181,-16.82961824660903,43.31025770612709,-10.51545881493459,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark63(82.48946918380221,-5.659607885982609,78.9685820443666,-88.11023663087651,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark63(82.50045494296754,-62.79003243457664,-3.7079077774985905,-40.226663297127985,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark63(82.54219602956067,-26.603018550118904,90.83941521030616,-23.157073615379375,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark63(82.54663382483167,-74.81033470081478,-39.6434786682744,-57.16640806347859,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark63(82.58690480808033,-22.107850757096713,34.62160475092267,52.319317314390446,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark63(82.60451261522024,-60.88337237426069,42.8675156208939,-71.38440508167034,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark63(82.61104552572161,-10.436110908457835,24.3290851359001,63.06828530109982,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark63(82.62633769420944,-51.0245322332936,78.19503654992656,38.72750810403991,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark63(82.66626624933181,-73.01705719381486,-30.49112909624492,69.49599267094294,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark63(82.70898307849481,-74.89681302988217,-72.07853157717672,65.34142464450349,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark63(82.74359558212555,-81.37366311674384,10.147649933674558,-67.51885248832235,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark63(82.75672048482139,-60.30375564482326,-13.282238668069496,-0.6497011803168249,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark63(82.80375507543914,-20.15204657617589,-8.735688088609635,70.38375183585939,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark63(82.81984200699372,-2.056346877546659,36.05067634537866,-15.735521008236404,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark63(82.82112239185977,-61.33813216758992,12.007995402949788,-79.79929772703144,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark63(82.8341083545576,-66.24593286383345,91.5709227058505,50.60504850591599,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark63(82.8501039616076,-38.62867914050347,-57.856448874995635,-8.304670926790266,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark63(82.86581472695582,-42.87884415173644,-19.422114739948995,-5.17512485608691,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark63(82.86981683608306,-66.25757587666669,-43.989450270752805,-4.1298607350660745,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark63(82.90364119525137,-44.192009718300575,18.382341783179612,17.89014410482406,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark63(82.90673946025726,-74.23432223306887,37.08096540427462,-84.20843881832204,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark63(82.91528427260442,-70.54435124708618,32.05112973734157,86.56250795718861,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark63(82.93569505145123,-28.458422671624575,-42.89552738906748,-30.32528563360988,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark63(83.07000547328187,-79.24004566010211,-11.252597417419665,16.193905481001906,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark63(83.10098852214185,-1.1359142286126342,89.06394590823083,-39.83908808443897,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark63(83.10155832468922,-55.88647693137246,-81.21265936975158,16.914366814053537,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark63(83.10735559855488,-39.73468921060541,48.98324224320339,-68.07226545720322,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark63(83.11942811603407,-19.455832264132766,45.43348784421252,16.349676133353256,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark63(83.1451019688154,-10.64351210043992,91.59495476121936,71.54462157954202,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark63(83.1716613554178,-40.53132981196088,-66.96969442484294,89.20565848966504,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark63(83.18647986545719,-6.878495049994115,54.43464395073471,-83.82585922355237,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark63(83.19232257668875,-69.08874415650277,-24.62041583667356,-68.99987562157096,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark63(83.19803247428624,-74.14334274421186,-75.50851280518799,-58.36484726139959,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark63(83.20160719521093,-14.251298930566875,-73.37669628144918,-93.81020752043467,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark63(83.22569418706951,-42.34345144880929,44.38773644478658,-60.56964630799251,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark63(83.28698587246805,-24.928295599249466,-66.06275873754078,77.7583972686086,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark63(83.30644110262187,-72.82691154074388,30.993216109869422,11.13911566809827,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark63(83.31465565526236,-49.39707109374864,-75.93613842431168,-60.77148768088851,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark63(83.36142832853884,-14.517425376346836,-61.5669177708984,12.430758894957151,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark63(83.37079906855527,-48.04871444388785,58.98609432689196,-54.996561679816566,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark63(83.37764248149955,-15.774846878116833,-89.81523655717949,-83.77473859630598,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark63(83.39811926323796,-29.360279368654133,-7.025556633181495,59.40182689009694,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark63(83.42621660432178,-14.30833769299089,26.171978301745355,67.66804460555335,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark63(83.44124423266686,-71.05861743240851,-87.41259151482548,-86.0683629805714,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark63(83.4520179811326,-44.45756960283029,34.47839253540678,-89.31895398094831,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark63(83.46182897674538,-75.76187787856416,56.11356451765809,-72.86029442771145,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark63(83.48748329048672,-8.560941178734566,29.932665388980382,44.9361536614158,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark63(83.4991348112654,-5.663520454685681,20.88165730922765,-70.4119120557633,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark63(83.5007486300452,-45.899942408287785,9.19271130412649,82.38990853316176,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark63(83.54284867241742,-15.147606915652048,-48.8600825937789,-93.3297336197128,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark63(83.57155806739988,-41.92701479561087,17.50217235274482,-50.06086934851914,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark63(83.58250388408271,-82.4915749573023,81.40686496471878,-69.5925251301075,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark63(83.59259460359814,-79.77517719597188,10.749570586026366,11.774195966776361,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark63(83.60438603578538,-22.203228939385312,-80.07340869345904,43.63241721501143,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark63(83.60857723767498,-62.747886430492585,44.58713591481862,22.416594273872775,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark63(83.62172490432147,-68.40881067055392,-13.523777773689588,-90.46328458172212,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark63(83.65278094226824,-50.590883625091564,-44.20745431948647,-28.630941972891648,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark63(83.65513740553044,-54.56033711853123,4.911300760876983,-20.000523475152022,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark63(83.67316348027413,-31.052743848104342,-16.888500719356898,50.577777686980056,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark63(83.68295074626269,-13.56946567123991,-90.9638842163237,24.189115729683834,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark63(83.70597051637853,-82.01566571620687,3.542355370681747,57.34083922169725,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark63(83.77469665800069,-57.26065070948694,82.4761699856839,39.37986696681054,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark63(83.78009763410509,-48.011305817820826,-19.71961355879077,79.00301590046502,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark63(83.78686614676579,-65.14339125038057,-43.11873819816672,-81.53093175409686,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark63(83.7869074496661,-75.4411275847935,18.99640211532416,-13.70162936401698,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark63(83.86076778125653,-44.903808250681166,22.242280148423262,52.52916949681031,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark63(83.86715957719574,-31.584000174398014,11.136939085470445,51.34585344799035,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark63(83.87789343782458,-35.812338820199386,-26.803869322238654,-36.607639963345996,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark63(83.88871104679114,-2.930980509758058,38.11341019228428,-39.55709253000275,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark63(83.88954636545475,-45.26710531045828,19.871867713065,15.629694791409761,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark63(83.89432798701989,-22.448448225248896,64.24380040487762,27.233344166752843,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark63(83.94053942504905,-13.568905649935985,39.99329189036135,43.77450023959349,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark63(83.96265892430455,-60.85165861789772,10.755294166509444,-75.24390657178033,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark63(83.97162242623034,-14.471156462513463,-60.14565054960632,-39.31559533287805,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark63(84.01015013504696,-58.409243605381576,40.94521145196032,-69.56313321741692,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark63(84.01622492531504,-80.73037378830142,-48.85824855428134,98.45909604886114,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark63(84.01774443815111,-30.17998479481669,60.30029959189065,-12.258212568028256,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark63(84.04071245599525,-79.87082748498452,-82.92942596690713,68.47531527370242,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark63(84.04289016026024,-54.59417768357857,-91.57254354991267,13.342690190800838,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark63(84.06352822286237,-19.622409628273402,37.91422817575955,-24.39857712089068,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark63(84.11043381553577,-35.25442044116774,34.30827745830945,-1.2149937830339752,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark63(84.11283510048955,-71.67618217507759,59.25789152950776,-7.895139173591502,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark63(84.11891042107948,-14.875262778926299,1.6894977898406864,84.921966963166,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark63(84.12999507553923,-79.36493068901936,-31.892481313514125,33.20394373100416,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark63(84.13497746832678,-57.910454301385016,-15.448000866267208,-96.90256011199303,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark63(84.13867346726602,-15.885291022435894,47.84469700021083,-19.747321537940692,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark63(84.14180156757052,-7.043872180884094,-29.964193203119407,16.34452231660994,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark63(84.148702604916,-23.10576332757104,-35.43002928340428,54.88965838391451,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark63(84.14904680815462,-30.25267046431,39.65590546013166,62.75534740622152,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark63(84.15676048111652,-14.501018202242165,-3.8941355106944116,83.40107608032105,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark63(84.1577251704677,-15.127740869873136,-56.026779852948685,-63.69712166398529,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark63(84.158657128541,-47.546467749791745,82.13033277892487,-67.01562211283922,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark63(84.17038631265464,-65.89938419925075,-73.0405460554847,55.43534278470244,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark63(84.1746423783045,-32.404550363455556,-4.598033534174206,17.51285387286434,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark63(84.17863959175159,-73.19388450145665,70.52760515152053,-73.31847155217157,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark63(84.18271167417845,-42.16662463618328,-99.0185517396749,-23.62022346642358,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark63(84.18758161280968,-26.56763105163607,-13.288132783687786,39.77875159038206,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark63(84.20978427116461,-53.260490793171854,8.97877653333552,33.113778778973824,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark63(84.24353526616397,-15.1498628812639,31.3789370199608,-0.8455744940345795,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark63(84.25230376842842,-12.139222071740647,-25.280144288504047,12.916476356252787,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark63(84.25612655607597,-67.45166167054677,23.72361509598649,47.48031671257215,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark63(84.25769807621305,-16.336248084951848,-48.38921433958107,78.97163418281127,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark63(84.25972532119218,-45.77360953873064,-57.99762237725044,88.4064232985393,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark63(84.26038275516154,-35.15935907121843,23.724520528384446,17.469466166893227,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark63(84.26674314565236,-68.26789736329235,83.5970684568918,28.03507183526571,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark63(84.26949207368827,-33.49151913994557,54.429123717978314,21.838057878318736,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark63(84.27217126912686,-77.7483843215317,87.059922394202,-8.897668048314216,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark63(84.27957442356782,-6.35951953671352,-15.36508299521671,-61.3125218572947,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark63(84.29421352003084,-26.951961598795876,-37.46759298193001,-31.103776602928306,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark63(84.29757776750955,-80.800701061908,-38.011161665240365,-39.51156426888935,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark63(84.3189171470467,-10.566146310329543,-81.91762509806145,-68.72690031083013,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark63(84.3447387351288,-64.48627300592602,31.866043712755186,13.900623701315766,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark63(84.35223358881501,-16.412341715066844,-76.43892391595209,-57.56276277816541,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark63(84.35880423491085,-67.47558237699528,-14.517289088314982,44.08906377878537,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark63(84.38639621934746,-44.51428204382477,-38.92921957355486,72.06576239893315,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark63(84.40403398327553,-81.81825124330338,38.29408737087198,-51.25784551530459,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark63(84.41533450188132,-59.969415920327386,-80.02059874953787,27.835701778967945,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark63(84.44284976163073,-50.052870057673246,14.674245350227793,4.187057361154828,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark63(84.45123183592284,-74.90935053497545,-16.532108149425866,21.092026527638822,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark63(84.46408890752403,-55.66678916381515,6.491797989594133,28.44302852493206,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark63(84.50822118408686,-41.27869670660509,-9.180544550972215,25.875007383580865,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark63(84.53331307335179,-11.703619601326935,75.7933845574309,54.44025681803271,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark63(84.53852546986641,-23.751249729569793,62.47671785534749,17.453255564452135,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark63(84.55155803707277,-7.252604035927618,19.186057055105096,33.885830636136546,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark63(84.57792779778177,-63.77773950549377,-81.46817847331374,83.26540202324253,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark63(84.57824351265509,-2.63993877296393,23.129546260149752,41.264035706158694,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark63(84.58621474837648,-53.82869123537355,-18.078912400210072,38.65874210046283,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark63(84.5882758362506,-73.41415790367483,9.910110354353293,46.41380249713367,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark63(84.59554549166586,-18.369467072694462,28.19660684021909,37.36073366854342,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark63(84.59676329784557,-37.370294914586346,-60.09997075873237,-75.39805769570464,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark63(84.6073669751828,-26.305159668227745,4.035811799594427,27.625316948874598,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark63(84.61567850395983,-9.015857245483232,93.88602758731489,-84.39081186052341,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark63(84.6190297870746,-14.848628108437396,-84.23743092025155,22.20740242906139,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark63(84.63407208080721,-78.22208897321636,-78.02366772298245,-79.4577304331832,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark63(84.6365611897204,-81.90264852942171,-94.13517539679661,32.680082396551256,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark63(84.64891294351423,-9.167288888549763,-14.315189770367141,-7.210807671613949,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark63(84.6861215356275,-6.063849425066081,92.43405233159018,83.20985120450607,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark63(84.68742873172616,-50.202313993225836,14.843411414905063,-88.44231479215476,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark63(84.69022123170771,-91.92777814965652,-96.52595635738138,9.629364499325249,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark63(84.69930642153017,-79.82559504210624,26.972474726204013,-7.254311994509166,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark63(84.7287819644834,-9.626503153843615,14.298297272302293,-57.45430298338683,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark63(84.73462423972003,-55.017822894821286,-36.7285750350119,-4.45728706615003,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark63(84.75222656616222,-9.735142065214973,9.421650995864184,77.32438978778981,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark63(84.75493428532201,-0.6464244579744474,77.4705680998704,63.71808983362419,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark63(84.75550682940599,-74.61853177407028,-49.75208980532611,20.033726743108332,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark63(84.75750854993478,-33.361790096848054,38.956853410768105,-59.50883018250115,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark63(84.7839617473376,-39.437406746043926,62.409409916028295,19.243998644017807,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark63(84.82591118349225,-84.72607710690392,-56.58152190723753,57.03058336779256,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark63(84.85183949943382,-23.422507314513098,17.4865672702267,-38.967678316131924,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark63(84.85641701903924,-23.84973417521448,-26.256512478837223,-88.97731480425102,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark63(84.85834169878001,-45.37943960138009,-39.37126903036648,53.048705955407996,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark63(84.87495967287228,-81.01559039702727,23.475604021556478,-87.39555498841638,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark63(84.88862121170934,-76.55802624423877,3.348950267822204,26.681692839896826,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark63(84.9135281236498,-80.93872707078052,-78.52078483675811,96.87972024796014,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark63(84.92564914768431,-22.026708325598676,-7.1913797986707095,-37.730800968031474,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark63(84.9504676142368,-15.86727653402562,-14.694682699201977,-18.26585585559897,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark63(84.95066240202058,-77.10619944383592,-21.64459933769804,33.43377642977882,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark63(84.96941333274984,-17.161861778352545,-36.44617535278798,-40.51523282289613,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark63(85.00204592111692,-29.8815866430665,3.2420054460079655,-9.48794247052109,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark63(85.0067780701969,-60.94198177588473,42.543179934856255,-8.471991654422112,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark63(85.01807240710363,-42.82709064404728,49.674830917655214,34.499717416833164,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark63(85.02811582541491,-52.142159016245635,-84.0055985412464,-97.06461284804216,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark63(85.05387992101964,-84.43518820993626,46.98235888818755,86.30852196066178,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark63(85.11595148546914,-71.95171886117026,9.461905571701749,61.97519879222949,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark63(85.12872076605225,-7.223600801166683,46.30012236159999,-75.02191227677856,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark63(85.13777581490513,-12.260048373480132,-28.802757197921494,-15.095967698167428,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark63(85.14475799804217,-22.667591823156855,-10.319683102143955,-71.64041780193607,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark63(85.16209347301529,-81.4261605324489,-9.949265352003692,59.78609464608712,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark63(85.17558008770158,-82.4954685191432,-9.004188875740283,38.100708804402785,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark63(85.18310663991696,-15.131435571700223,89.92875957575609,11.471742186796789,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark63(85.19657572039213,-18.82485537549114,51.68736247304392,28.960757763570996,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark63(85.2243679824683,-71.08821479132845,60.33022364598588,-3.9950121464595014,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark63(85.24463492799342,-10.708395234870551,-38.88873108908966,17.970243974613084,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark63(85.24725273059497,-53.834173365643714,-97.32846387938866,69.6489893117099,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark63(85.25404114949308,-8.340105285302286,13.18509065599352,-86.19153610238703,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark63(85.2693152988922,-36.40995863622554,-48.96451219816369,33.50981687456621,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark63(85.30933525180612,-31.54615570013455,-33.10744376471497,66.18825041964104,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark63(85.32106587116834,-63.59820917880017,44.255107447752266,-4.382941156800243,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark63(85.3255178943231,-20.1004895483496,65.46298800600258,-75.01235203866503,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark63(85.32726530643242,-36.00902240869277,-91.77253845242757,96.35250239057359,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark63(85.37700330131653,-55.47545370609035,48.1026251945479,-41.406064486217396,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark63(85.39309856375675,-53.924474668862764,46.3100093994436,87.78324784689167,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark63(85.40436167412014,-4.859027009968628,-27.14602167902906,-0.6381092031700035,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark63(85.40830102594501,-22.58780800497253,-99.24294105986465,-85.76394950298858,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark63(85.49120538436699,-70.06617221345728,-19.73483761883223,-71.40884612542762,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark63(85.4915943999197,-16.10035085392147,-96.67854754548972,-11.511037882236892,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark63(8.5531742494029,-0.35903718100107085,72.39167259633007,41.32325049469182,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark63(85.55053591008644,-25.02880067003555,89.23790044682303,92.01318816865302,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark63(85.55870766778827,-35.81132976808814,34.76406558377468,-55.55198143364712,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark63(85.57631572808558,-59.00144441230122,-62.62328166981692,-67.31038177563111,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark63(85.60847241365485,-66.89719283036399,38.56549030446334,-69.13181776642952,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark63(85.61975210265223,-36.5593250677468,-86.22043289513394,56.577317402119434,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark63(85.62737321016502,-38.30051488042068,19.685485749839657,-81.46305178434021,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark63(85.65124456234159,-55.202795231352184,69.79022563593159,48.791531981136956,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark63(8.566002794845133,-6.032784938474194,55.05417897654843,-10.9826632071359,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark63(85.66181790565227,-10.330654710889448,57.6566807001814,75.1930965195096,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark63(85.66371801001145,-54.62700253267716,-9.6144900874162,-11.167511183065557,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark63(85.680221523748,-39.799577323854216,-20.736075821336456,47.43445008936209,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark63(85.6829719873324,-10.599334237426163,73.47202972484203,-67.76097285616247,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark63(85.68733787831934,-23.44594960953981,75.07174971511833,-47.76637949015081,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark63(85.69325338844575,-72.24251310431754,85.22525324411609,-84.1895101315405,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark63(85.7147423328197,-66.81993890061979,51.034917830835525,23.419979632050314,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark63(85.7268137298569,-10.413974723463156,70.92267284304438,-93.56021641625021,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark63(85.73572054703945,-45.66830735340397,2.1721093833410237,-88.28518048085263,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark63(85.78376841320184,-16.028127987094607,-60.468071763206964,81.11392880716932,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark63(85.7932667269769,-79.00743508510537,-36.511175472681856,-79.6704417211338,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark63(85.79907368071136,-51.72337439557846,-1.6597700744394643,97.84690528810904,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark63(85.81864002132957,-20.361053952681644,-6.570435035351238,-3.1597939500617116,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark63(85.82204102460622,-37.1007625058964,59.190871267441025,-28.15493094813874,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark63(85.82300549430494,-46.63974259701278,-33.47411484443259,28.707331917095217,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark63(85.82659254048139,-65.58386831688094,-68.42972304494381,-76.41644427423691,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark63(85.8567046140802,-65.90477664386106,-46.0481338871384,56.78979090592185,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark63(85.85836174497015,-56.570806343649906,24.906513495696373,-65.20577457997561,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark63(85.88254725264446,-27.82405432306409,86.2775884090236,-38.85890019265725,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark63(85.8843477867544,-36.17869084742744,-99.3175674377725,26.30123256982597,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark63(85.894280419603,-51.53554036571653,6.937286176703353,54.83894191903471,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark63(85.8975940880542,-82.40536954571516,-25.936782797783138,-52.27288142905895,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark63(85.9116789412148,-31.686551427578166,-19.95205947602821,79.39845816318316,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark63(85.91805799235826,-24.875232476733245,3.142542057811795,-94.05352701857686,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark63(85.92663868095772,-54.220097052614236,-39.83451816180348,8.361790520959204,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark63(85.92887680960482,-81.98000848797231,97.79403619737269,36.43806444584072,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark63(85.9510117008748,-39.174100799767444,-55.73677653489357,85.72437728453542,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark63(85.962718102069,-68.19630718352245,-70.00456221893145,-84.81959643622989,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark63(85.97236537806162,-65.19004677248472,71.50600818380272,45.6646109092126,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark63(85.99403047657512,-13.822366389939944,82.72766039293828,17.35164692837384,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark63(85.99665117512859,-31.47882058531779,-65.60787074131517,-93.3563531925052,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark63(86.00096648235089,-48.21943943808593,0.8517285282718206,61.60850684632203,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark63(86.0013654057311,-31.152548137350536,-85.45865982844572,-40.725879404192945,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark63(86.01021696357847,-42.55248418077555,28.46568715669514,69.08117159090838,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark63(86.04227118158704,-79.47317181278699,10.360510825936785,54.75658938045265,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark63(86.04969159060045,-12.888596554765058,-65.1221251230344,-1.5066166451167362,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark63(86.06863865831693,-28.920796605579994,-33.88080440655416,-74.5280419097472,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark63(86.09806333119786,-47.42529453989908,96.96499919689023,-93.41126556600263,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark63(86.09812601961434,-60.91195563797438,-97.4759774354814,6.925672963755062,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark63(86.11093953825116,-10.604173204372842,96.2938559534397,-52.57998836210387,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark63(86.11773414828849,-64.12477510557828,-86.86470222026672,-7.638716666712611,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark63(86.11898252299139,-70.8177980377238,-50.000483451763735,-57.527523076580756,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark63(86.1631031863613,-74.46317708560011,-79.47620845864047,-61.12213326710574,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark63(86.18843043184393,-64.70615607432995,13.725816257013989,-80.502516213425,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark63(86.2288861576352,-69.20641284887242,-77.48537467881943,-19.20744468334783,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark63(86.22975915515062,-58.56529393406002,-57.965753987568604,1.275912946189763,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark63(86.24542448072137,-25.332885557675127,-32.99070140554244,-2.9125454755593267,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark63(86.27078411974821,-38.9084869466382,-44.73194566502507,21.201983965712373,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark63(86.28773118929689,-34.17441223849961,-37.465724367292744,-33.8987468527973,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark63(86.30834405671891,-58.08210573566057,-14.910311878507414,-36.55811383171632,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark63(86.31113209222764,-34.64567868736242,-25.38904052147541,-18.84349687219384,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark63(86.32764981200935,-15.474291929624144,99.62583187438292,-48.812908819614485,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark63(86.33459486942999,-22.65399654611535,-39.70359686072846,-14.478636590825204,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark63(86.33958380571579,-47.67641201972703,-61.77706498327837,-82.6840931755028,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark63(86.36637334836209,-18.483165629003693,-68.67165096415843,55.216951431335104,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark63(86.37338993562676,-42.01157096763393,49.94717567925312,-22.696327525777704,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark63(86.39480647747033,-20.599896462050893,-17.9850574026877,13.815691264166105,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark63(86.40214027048415,-46.2589056018361,-28.23020498510047,15.629591674533017,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark63(86.41837462999521,-76.61184105467711,60.92853961902989,-68.63716760778985,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark63(86.42715455332987,-7.90728030193857,-13.692307844119057,37.148504522278614,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark63(86.45038659670342,-26.3626601978185,59.200079050392105,14.71624384735486,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark63(86.4561333140968,-75.24382041801235,-98.4207787799875,11.526302196458275,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark63(86.4776268637278,-52.206829658728495,-81.53085383547815,42.14456688889382,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark63(86.50330693700931,-74.987361823356,-9.456711966601162,2.354556872267864,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark63(86.5136583724084,-1.8345097726211463,93.67330234963919,81.99173965336831,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark63(86.51634430667244,-69.89411082630686,69.84043848569442,-29.09722705484458,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark63(86.516417258702,-37.60093402120852,-86.75445500024603,-53.6612391801589,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark63(86.5248161948046,-85.74022299390982,-0.37913534298384377,-67.07946435163339,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark63(86.52650873405187,-8.709745657129758,22.321013772563305,-81.30220220908082,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark63(86.53390731114459,-75.98016692434315,-16.880499294039893,39.05888075146751,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark63(86.547105425576,-21.637739056665424,9.520705024727334,-17.211298728720138,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark63(86.55460715579571,-71.68085616982675,58.02188743850044,7.68459704682931,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark63(86.57531568929716,-11.310584265705415,-18.369863670397237,-96.47356447856275,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark63(86.57656811017227,-75.7100001286333,4.981211862055645,-30.157284746230914,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark63(86.58101996447814,-37.41261536579972,-74.80909753500637,71.40248243816319,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark63(86.5972612108583,-75.89226761586502,99.64815697562588,83.64518958132706,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark63(86.60298867598038,-70.16514874249194,-79.59068572880966,-67.9294706306452,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark63(86.60306760522016,-3.8196911374561466,43.47618849681223,-83.82035823473373,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark63(86.60832402764507,-41.80466813559616,10.799129110244039,24.27243803678529,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark63(86.61223847752774,-35.48969002108623,-49.02622895760096,30.796931823899172,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark63(86.61679275384711,-45.15163711331142,-73.61944003637421,13.3156311992268,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark63(86.62235284962904,-36.41612896676831,-47.651175411004075,-91.44355456211946,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark63(86.63725514960566,-19.900421716364164,36.25082771373346,65.30306882005169,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark63(86.66507500501828,-21.17596336449658,99.81204219821345,66.48622740062646,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark63(86.66526954017135,-36.715647030224744,-27.730874564498748,-70.37272413765547,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark63(86.66705186203117,-65.26964590900624,-69.26538336292056,-12.15002760198594,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark63(86.67512799483578,-13.39963573287389,14.809559385888775,-72.07083414578399,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark63(86.68610865653181,-39.79310478437832,-50.61500185216499,-27.05730545858394,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark63(86.71193650490065,-20.66969036801045,16.63317118569057,56.71218951208607,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark63(86.7219158545958,-12.612067103244499,23.882031114505864,47.46313679811573,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark63(86.74440406733689,-3.3869395591318323,62.7335756473407,-93.64360880697392,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark63(86.7563856379669,-12.6517313227954,99.19569938574546,-40.87373646096217,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark63(86.77409014478258,-16.455856735198097,-64.68149522782517,-17.99350311355667,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark63(86.7953012596588,-39.76468400964694,-35.93645420981075,-62.00591516957677,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark63(86.79982431265222,-65.21463475909037,-31.32049610757896,99.69801458853581,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark63(86.8130899274806,-6.99045208734681,-59.37351301205589,-59.40529642896644,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark63(86.82200201110328,-51.534526229476185,50.06512221035675,-31.989256856549474,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark63(86.82946830604087,-84.04998464855336,59.89131807643051,74.73004481248583,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark63(86.87112920788658,-26.280017444509383,-77.75558389951907,37.37032405630262,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark63(86.87680019181175,-17.701334714927228,-12.31079869597255,17.78569742972816,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark63(86.88854968371598,-44.08366485527071,-8.565636048801565,-31.273364045401777,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark63(86.90725174863664,-8.607591842239714,4.414687584568796,-38.701367880193715,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark63(86.91375857444243,-3.650166153525376,51.615117519681746,-20.105724659374317,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark63(86.9379394487633,-50.42504440912796,57.67375991883222,84.1116373583398,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark63(86.94438500615823,-40.88899831491026,57.58149073758176,-28.838599199430547,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark63(86.96916236900009,-12.152555244829216,-87.17652787092032,82.50896820576915,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark63(86.98922931808363,-26.289348074824275,-91.17976667955219,-20.331369835474163,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark63(86.99634143430154,-77.42902931903993,-66.71641978938456,-55.62703325720746,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark63(87.01656874582505,-53.84354611885893,76.29898003105123,19.47025232518807,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark63(87.01825482709776,-28.609934178680604,36.95530785990036,1.696195341083424,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark63(87.03037210665417,-9.453230259437717,-69.57470554716,-99.01637758523995,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark63(87.03340039780974,-21.62388961722435,-47.49845357981211,-44.843896459211365,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark63(87.0354430903281,-36.567287451926056,6.213405162132972,-23.393638860174264,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark63(87.03641436654414,-57.31259871067414,6.521501205817756,96.14616900976131,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark63(87.04320617364448,-11.637079133616709,32.550973475628666,95.94930152960956,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark63(87.04569470791441,-61.213844146767094,-70.45730144236155,20.143173824746356,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark63(87.05115134136767,-32.793315905474,41.49177497634267,97.2810013302593,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark63(87.08379384264464,-38.152075295234546,-46.734660339674946,-53.87468629803263,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark63(87.0842182218403,-43.75006573661273,10.003760622781883,-28.713110206417042,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark63(87.10402324849679,-83.15290489346903,64.54672526151967,-56.94625304589556,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark63(87.11100975398739,-43.93722719037807,-84.25004341800198,-48.49284555896811,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark63(87.12269606602152,-13.428689625801084,44.60667663701,-87.8599450103833,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark63(87.1307226630588,-15.36695616153294,-7.68200364214735,19.922410701306674,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark63(87.13414513805122,-78.37640957228831,84.29738517211752,-67.6488752021834,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark63(87.13622384408521,-60.393785370145416,46.403469495249595,-35.9432499163411,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark63(87.174938694838,-90.45783891050219,74.34835404461538,-8.319717907936976,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark63(87.23389510492842,-35.01197532843163,-27.25048250237903,55.443279964201025,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark63(87.23631740645047,-0.6705365992889227,69.82893520925379,1.3076950745768414,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark63(87.25373216333833,-43.02736501008886,-98.52582302489887,-90.61499453617681,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark63(87.25908440840286,-35.89769401395313,44.05280790281424,-99.79354202845524,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark63(87.2779898133152,-79.82998413703694,72.52162610610048,28.913792707850234,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark63(87.28162267457225,-73.95059081066245,-44.95108514342936,67.6878345439755,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark63(87.30133762175228,-8.706612181655231,91.00562014187247,18.390762368953645,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark63(87.30443189236772,-23.825684684262697,39.25854575686293,15.129431997127327,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark63(87.30635573612656,-63.48881771680968,92.60462428549567,-48.163666779736715,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark63(87.36852272121786,-84.7327008653521,-22.100412632040275,-91.00003963875476,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark63(87.37213004921176,-71.63898870918675,-92.47258679232722,-33.99830363536698,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark63(87.38217374559028,-8.4950061450199,8.39069758677222,-30.31973544157718,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark63(87.40685520854916,-68.29285663853362,-89.50874119460319,-64.99461538866876,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark63(87.4111342321101,-91.45238348792064,80.32979216397567,-15.597991874087725,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark63(87.41750304786822,-2.9530934190414797,92.8353714080524,70.92396012978048,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark63(87.45275415676693,-6.504759625605303,92.84942069212983,34.56842895160281,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark63(87.45657338775632,-57.94524561766623,-77.05371664598232,47.34074975530794,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark63(87.46575903796563,-31.33395775240517,-51.881545567002064,82.74212975011582,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark63(87.46725307735767,-76.90844460683726,-65.84031824348276,8.090349389114905,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark63(87.49997646650775,-8.471094089621303,-43.19492598183543,-16.896431500811303,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark63(87.50815433845935,-15.884489614003328,46.82293288229437,-18.803698769608815,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark63(87.53388833364215,-38.258108524445575,91.1926334178076,17.01538526511588,0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark63(87.53880684440728,-87.11695977363776,-13.166773329762307,18.170959100079173,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark63(87.53921645640173,-13.475844155171359,64.68766020786035,54.49053708070579,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark63(87.57543272056537,-33.54846120025607,39.0420741181982,54.187667637379775,0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark63(87.57786747367979,-56.295592406312565,77.36544188425637,-99.98160975695538,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark63(87.57836568276528,-0.7076071753740791,64.9948178086799,-11.907022150109611,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark63(87.58336339616017,-33.810884888514224,17.85949064795109,33.15483966572603,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark63(87.59012005679284,-16.012856301219955,65.64328831802362,9.681516529346212,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark63(87.59450238790026,-51.591260257074524,-9.544687376882393,44.098619763155256,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark63(87.59882066905195,-39.99874334529672,-50.8764949051552,-89.59157120570835,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark63(87.63560939692502,-62.225394867910296,-85.7713990070481,0.8545551143556338,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark63(87.63958712301707,-62.125531869373575,48.9347645388757,72.50350675115061,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark63(87.639748573724,-32.69765820062007,94.66923851651109,60.84363303055602,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark63(87.64785272506373,-44.11319805563565,85.21795292349347,48.211934974116275,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark63(87.67181689911314,-65.08280735654654,-65.06267505075058,-68.19253600283997,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark63(87.67295864394131,-52.069194455369306,-1.4176730472633636,-15.0433258996312,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark63(87.68437118767221,-54.8991728293873,-75.0197303865245,77.56659112760721,0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark63(87.69454406026676,-53.48462967594345,-93.37880370028917,-57.81963805965988,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark63(87.74630500264067,-83.24472855421303,76.10340808818884,-55.64993179403419,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark63(87.74688484764476,-81.15419069573997,8.229098868508672,-99.58944339882139,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark63(87.77553947288109,-29.140102577151566,-12.221596855473123,-90.77095720422992,0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark63(87.78190549202981,-8.559909351577843,-60.1486953273904,-50.05970585116226,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark63(87.79950847462783,-82.95461828557175,25.160726767414474,-49.26175912265358,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark63(87.83316150515552,-74.6192398502612,-9.765491434252965,47.99359600194987,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark63(87.87660478620978,-28.64898758722599,26.12467422736418,-14.797492247614642,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark63(87.8848889269023,-44.90714911891005,88.93531434992417,2.559794787466359,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark63(87.90847340728826,-54.159452589435396,88.60388088110409,-7.477436161472056,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark63(87.93832338945424,-7.742909485730465,-50.38014774366009,-45.9548840500966,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark63(87.96533417357975,-46.41028273840793,-60.09971903547762,19.044220690419507,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark63(87.96686276674379,-49.448342009866565,-43.63805490135362,-1.142186381066736,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark63(87.97955343354354,-52.33613670207116,-51.937063828626684,-1.6022476967835644,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark63(87.98190291015703,-42.86424361725847,-55.618820722308904,48.538419463690076,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark63(88.00949695076645,-6.7103509055336445,6.472288340768031,-40.911548166506215,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark63(88.0105206157449,-56.85007991393931,97.3248590158887,64.61490863106252,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark63(88.01596825458986,-72.01658787666949,-99.69625136964318,-86.29909702418026,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark63(88.02710278317412,-44.27143089632934,-85.39720973140005,-95.29215519708538,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark63(88.0326165808317,-37.08410123931174,74.98361965462448,-0.8412870379585797,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark63(88.03657954736076,-14.17708960441226,84.30424803426854,4.452575039994059,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark63(88.04260020618779,-29.503156171854698,53.698289604417056,-61.75378686845634,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark63(88.0506322935525,-75.77672982331663,70.59321186270603,92.82540590580393,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark63(88.05881859823336,-9.265031142013271,11.218090819282935,-1.9107538969487194,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark63(88.0682614758125,-82.641495393242,-48.83669361281251,-97.54309178427725,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark63(88.07523524760893,-45.91957302793273,-40.08685476203016,70.25056641015232,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark63(88.08291122330357,-16.61480623364777,28.38273279238919,-73.79760266717412,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark63(88.10886361127936,-10.216411955599966,64.70737368160587,89.74988178734716,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark63(88.13903205883432,-69.08945346230112,-56.678670959412926,13.880194443629975,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark63(88.14459470551878,-26.96690189805409,54.19012562912508,-17.708319125542687,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark63(88.15646874070069,-19.495990974511727,52.17716232296533,-41.9934063157331,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark63(88.17691913607854,-45.92072714301079,-80.94433971952813,-76.20334640365907,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark63(88.18351676508897,-26.705605013568004,-35.8032927146607,-25.33782693683328,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark63(88.22726815058556,-55.47169914201504,68.28965078580711,88.98274842634768,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark63(88.22821948956258,-8.95843413679411,-13.743824454994552,-66.43204194065946,0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark63(88.28776805174752,-1.0863410100539,28.85562846157262,-80.99853690814885,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark63(88.30250454906806,-32.550837397955746,-83.08342472696924,-60.10063241418955,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark63(88.3258853135911,-42.61515127092934,26.49421428992227,-31.10197945720634,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark63(88.32918845136487,-35.2974807094143,93.34124964718751,-72.92193575044837,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark63(88.33788826858273,-24.320519852340652,-89.14343485795106,-66.82088288290207,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark63(88.35062962987189,-4.204562118711564,70.77619966546561,68.22473405960153,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark63(88.3763450075397,-41.56862187283949,0.24325538499176957,-5.224651525370973,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark63(88.39714148300158,-48.8083433597247,53.61493471335109,-14.372569581080867,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark63(88.40027395824879,-83.52336418821646,-45.14909234753246,-36.04908499378359,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark63(88.40544341426667,-77.43862415839162,-57.80870032562506,68.40321143060922,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark63(88.43216372491614,-46.2183119935899,-44.37104203190005,35.753214677371545,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark63(88.44287518905537,-26.01829461575295,-81.56929028706521,-95.64842558739693,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark63(88.44720049050343,-69.9250595044887,-87.78179832063707,25.583103404961577,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark63(88.51258010917607,-13.87351514166042,26.574539985094248,-10.121712144036962,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark63(88.52100518828954,-78.18369697145731,-97.55701036148,-97.48753704613901,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark63(88.52449759755453,-79.24813638713017,-57.53274984228363,46.74371748743937,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark63(88.52454607405164,-16.879310595660257,39.01246067195052,-37.54080565136766,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark63(88.58933406649436,-34.43110342336446,-99.80873897643238,-34.65684817040436,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark63(88.59135896156187,-87.4477317401741,-57.306158785307915,37.342106582923265,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark63(88.62345500793666,-81.29880100707737,81.4733381080452,97.35737868077848,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark63(88.65876564347667,-47.35658195892414,-65.95106148875816,-25.518578757283322,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark63(88.67663767873796,-83.10563478392876,20.918896210458755,-59.54378771060396,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark63(88.71298497850384,-36.88212254104193,63.57204905676474,-25.663305142160226,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark63(88.71331798118487,-2.1629650712942095,88.25065987132112,-5.677824516046726,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark63(88.7488848185854,-65.00861410551069,73.50846810024368,41.772141080417356,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark63(88.75376986298954,-49.238547233718634,2.7856499752928983,1.3095109519640147,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark63(88.82280309068008,-38.477185546663996,-21.148467795000656,94.2578242330454,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark63(88.83602288077353,-33.30659686717708,65.76855653895328,52.41506711809464,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark63(88.89735909735163,-61.40041731983199,-32.186548988976654,69.2566772371712,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark63(88.90144306205079,-35.451498456499706,-97.29964854989903,29.81887494051253,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark63(88.9252298474448,-41.05108768689543,-33.46942575202793,-78.93151120861339,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark63(88.92841809472006,-9.884054551540089,-83.20246566710591,21.59862990332438,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark63(88.93173333610244,-68.05769314740688,-1.9857728477415009,93.388972199986,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark63(88.97802734600131,-88.57449038427447,-3.0200443410939926,97.24561308858992,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark63(89.00315817757715,-51.480804948361936,-28.080694083382156,5.734093077932883,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark63(89.01657005130085,-45.18061068987538,-46.57220593531588,46.673273685216856,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark63(89.05094819201548,-28.62415702243584,52.63085610019286,-83.69179463449538,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark63(89.06397944494248,-69.80657995488696,-56.23781022918246,25.763010928949143,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark63(89.0831317917847,-49.45743574163759,96.29649188223561,-83.61674279780743,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark63(89.11175529036555,-39.34145428259046,23.974268566848096,7.2052391374522955,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark63(89.13901685107484,-10.387484507184425,83.37067061918148,71.53627167944052,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark63(89.17344838612101,-42.99781045330376,-65.89169795694252,-61.730084633665804,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark63(89.19618475151648,-34.72367114399586,-75.83389323605223,74.53093343765985,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark63(89.2043067814133,-78.43664529555399,-36.79465753232456,10.250775101153991,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark63(89.20486876453111,-53.471207616064945,80.6892668023404,20.70669666490437,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark63(89.20915043616523,-21.115548574864377,-88.08654237043028,60.94737106109375,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark63(89.22497306370778,-86.73324960419137,91.98059479557179,-98.2552754225926,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark63(89.23720827166005,-83.91418466905318,25.384305953473714,51.62763825460851,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark63(89.24005567660535,-68.4203480550288,72.12440559706067,-34.258237035048936,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark63(89.24339427348909,-80.2685140827296,73.49592389490431,19.289511183266157,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark63(89.25100343708996,-37.546814365795925,-9.460326252365107,-85.99350444968044,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark63(89.25456144542358,-53.13130382715101,-13.380992473590709,-3.7785123695425824,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark63(89.27224947477862,-85.56199312559383,12.803846505749178,46.67970926063069,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark63(89.27495634564616,-16.956669672710987,-30.230144345239253,-45.25897615493479,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark63(89.28319753447863,-65.83964190555858,10.038116989216931,50.35966024429732,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark63(89.28519599593213,-69.94342191104738,63.25911417434958,94.68550395252655,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark63(89.28663693776889,-36.195954333672105,54.40022560352122,93.9081295070304,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark63(89.28820154257787,-87.75000701447489,60.7818752689096,-2.5293285955210365,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark63(89.29422071302028,-36.27859601793666,-35.79955794545097,-21.7281255943073,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark63(89.29832623372434,-50.247449952242526,-54.174363176676636,-79.32463586404165,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark63(89.30025173069583,-51.103893004079715,32.274589120206144,44.80686626178405,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark63(89.3146194783337,-10.441210048325942,6.619683560649918,-11.499753557427184,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark63(89.36602317811179,-49.44072004174349,-79.10622343153975,79.3408084471128,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark63(89.37199936502805,-71.45005712753927,95.12274127765701,-16.707705127464195,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark63(89.37725490838392,-25.092039485798878,-52.01684293451145,-33.794572750959745,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark63(89.3807480661707,-85.52214508306122,-58.66001109800072,17.06413022278126,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark63(89.39325909873793,-56.67278402342013,-60.85205635626028,-62.49071424724648,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark63(89.3964204379867,-45.39885970248791,98.48134293559565,59.45288114476489,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark63(89.41041911293891,-41.94224872941206,27.25988766287219,-76.47640763247081,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark63(89.41532406295582,-32.42872455020465,45.14382957541929,89.92196794025949,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark63(89.42357082038214,-27.422746360262877,-21.158650051697947,-27.486954969661554,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark63(89.4238017976271,-71.21854666185556,-31.263468695290413,-25.679460354780062,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark63(89.43620191539136,-6.907272907457568,8.609783265192021,-16.157910368795342,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark63(89.44564550765429,-62.62193162708216,27.560348682768932,-7.297057889985098,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark63(89.44972482513114,-69.94596838731937,-35.68988502112191,-4.197073059335722,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark63(89.45610533483412,-56.18817056683947,90.97591806149904,62.31502733469546,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark63(89.46453925984957,-25.94018153616031,-35.09961377271654,-39.7882215280257,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark63(89.46504182560048,-29.908058501880745,-31.422734852238676,-54.81353747702611,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark63(89.47596442568363,-29.330043661208236,-82.84893620860028,-68.5756425297439,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark63(89.49640842405785,-11.971830430455128,-97.89311452374847,-5.8164964563650585,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark63(89.5038500442945,-18.11275748789474,-58.389551469732325,-74.54216806823028,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark63(89.53057794381428,-56.10720351741918,35.76619375461152,37.88428793370818,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark63(89.55248281199309,-88.70377769966609,54.02689266139268,-76.40170945923896,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark63(89.5588817482558,-71.10187309378517,-8.180012542850747,96.41650137917182,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark63(89.60981431050453,-29.930875716732544,33.508802654523265,-59.16201475112213,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark63(89.63301614577745,-69.53788775751555,-24.920462650055057,62.93401050000236,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark63(89.65942704125183,-51.45818353398055,82.42913586937686,3.2941075225644028,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark63(89.66613197981874,-46.37429387984231,79.34553318353349,-51.29432220457184,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark63(89.6792184549731,-10.547016020660465,77.9432626716092,55.29998604623208,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark63(89.68114117284719,-42.48998035180405,-1.556715989550355,34.84727691020328,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark63(89.72791725281425,-71.11011987483576,-26.406106746811346,-44.115174303030294,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark63(89.75639477966754,-84.0706884082139,-14.45758519657059,-91.04705139293918,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark63(89.76009837134765,-7.365958516990801,99.61708832339028,-17.964165273928828,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark63(8.977274449765375,-0.710792652021027,85.4148656511264,-1.3066331208481046,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark63(89.78579286681403,-28.64581291702038,-90.59666304596516,78.23776644558538,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark63(89.78711875228825,-66.4224752499617,41.52265145488573,89.6467158147702,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark63(89.7937103061663,-58.16199679378939,-64.1140774084812,5.590396057908833,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark63(89.79416436209215,-50.01389451241474,76.32624011052002,11.204993870525698,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark63(89.80169365756788,-12.14263830543058,-92.78505536482191,68.53707105167621,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark63(89.83143143220263,-17.689139764188468,13.062024844883908,-26.92211470550201,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark63(89.84065809185711,-43.31735614194836,5.019697900102614,28.739878426740802,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark63(89.84803651845505,-22.753904866626414,44.54979589275871,59.26912920198316,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark63(89.8492740086993,-63.47885501153216,44.875089882224955,-7.342912398096075,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark63(89.87403011398001,-79.27906927428538,5.659079076021584,76.976785284899,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark63(89.88384700405109,-69.53277161295011,-32.9772729669352,48.763972434517626,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark63(89.8922597070569,-13.855753666862242,-2.364209261844337,-75.8380133938693,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark63(89.90340232937746,-28.64831864417792,34.556414359569175,-88.1586545748353,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark63(89.92775458983738,-52.57396796881109,-39.39818449827621,-23.064677951902013,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark63(89.96754130296324,-28.161710731512784,39.761423913935545,-65.539028577957,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark63(89.97792613653087,-71.01474840424878,-2.8785451818918375,-69.69219740688936,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark63(89.9799765172404,-45.868230897348525,-51.804042315008836,-9.940609875866798,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark63(89.98889759725247,-31.221038416705937,-54.870347229226304,72.71146417432846,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark63(89.9944811862897,-0.37182302065626516,74.09392281134603,-28.696924646114795,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark63(90.00583037268598,-46.89695675840393,-21.064141243919465,-58.33668059037858,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark63(90.0259898559307,-60.689583897380636,-18.771071521567023,68.20850775765214,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark63(90.04865191103428,-42.61339036541478,11.162079503512828,16.763093435495094,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark63(90.05006449005828,-72.88902758496216,-42.182801048537044,-27.644758429190674,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark63(90.05963453181101,-60.91151767701366,64.91401335830938,-6.885134332739156,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark63(90.06652039835376,-82.02106823153471,52.75760574054033,-29.874041273041342,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark63(90.09540918940701,-48.95555786647998,-47.1633091320117,-43.264055086317455,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark63(90.11453600439776,-88.38560914634365,29.34024436839863,81.81685292813162,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark63(90.11940977489772,-42.81916180958347,77.08721673523982,97.2179103037906,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark63(90.12456488876114,-4.988093042703738,-21.581938918900633,-89.84919632777111,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark63(90.12681441113818,-63.01916389138525,-60.2777269976597,14.414597142822146,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark63(90.1643842881619,-56.74531784576659,26.398047291595446,-14.481692532897597,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark63(90.186291126133,-83.02494217458536,74.21719231657983,21.05459822587845,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark63(90.18819716959507,-9.323684051343477,-71.13388551874273,11.05055512898494,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark63(90.19467001924636,-77.28859549158807,56.94142624607852,-37.75975896026074,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark63(90.23282417104096,-88.2132183793964,-20.897575293861408,77.35443955629856,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark63(90.2429237646515,-76.52078571866727,20.316564863632294,-92.12064658550507,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark63(90.27857260600896,-44.80100134250071,77.14652446644342,61.83323679976377,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark63(90.29920300956903,-58.41312616490482,-50.84803466789574,-98.19584990735886,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark63(90.31548161589106,-2.2738897183331943,29.13857618932724,9.154091627936523,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark63(90.34779678124227,-19.644452420849262,-10.862259775186445,-19.054868536151616,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark63(90.36055171432466,-72.92416673290654,-40.20974807756503,37.713394579600646,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark63(90.36388001964443,-66.89658691922584,64.0094897522535,25.912802453487032,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark63(90.38265236529708,-88.84829886440465,-18.13974917027285,88.04638518536782,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark63(90.38457029059089,-58.39764210795742,-1.4882698113213735,-23.30199737186534,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark63(90.39737344883437,-77.72238512338237,87.69333476981569,92.2332568810103,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark63(90.41041949614137,-58.44594757968811,50.813379462417146,64.77932660735794,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark63(90.4271692349632,-44.07187363264522,66.90416134120093,20.482780192756707,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark63(90.42953116699098,-79.1566667041267,95.97036903779312,-65.31356682185488,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark63(90.4391326025106,-63.914506618712075,88.94614877262708,67.641692819587,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark63(90.44123129054586,-12.101071436084254,66.98799355099055,21.973822971582166,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark63(90.44812201250326,-4.541166328918706,24.500421593516307,39.04166394553232,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark63(90.45193036493518,-26.74224229961264,-72.0909392124068,-21.016585876490495,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark63(90.47411980031495,-40.86417362887644,-19.447240789910936,-0.5933388778920801,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark63(90.47668292597945,-51.1932171853885,23.07329852295868,-50.230134208865394,0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark63(90.49338353287771,-24.19968121995977,67.82484053619905,68.54712560808628,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark63(90.49824931182562,-16.88227338008845,-16.01960687922643,-24.754180714862002,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark63(90.50848415380301,-90.07725999615846,2.680415457939816,-30.88345070177138,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark63(90.5137528093903,-54.48260271351104,98.07510299673442,6.147090109252673,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark63(90.51703502480692,-72.52022980718851,23.87841368292591,-36.63133460714183,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark63(90.52692678209121,-73.31460382150397,58.47325808401746,-63.90977848805666,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark63(90.58795632183813,-20.19191460095513,-42.10001267719126,13.250691235139229,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark63(90.59989534315886,-62.8033875345855,72.21312754434263,3.7561169604703792,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark63(90.62532520832264,-40.799649372000935,34.96071883743866,-61.076990646081654,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark63(90.6268550722319,-56.46269000179982,-65.92438715203906,70.75753792662914,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark63(90.65036201364464,-6.896948188773777,19.080314752243993,91.96263348468497,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark63(90.67199039430494,-75.3471560820695,-49.396882178064,70.94349824054046,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark63(90.67975714121036,-50.704609452416264,-56.485219015051705,-2.2290636175193157,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark63(90.68572030792504,-71.22839816833064,17.655449877842415,-44.92444507667381,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark63(90.68766860053307,-7.834726414022214,-48.2950878461317,-35.277881780459026,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark63(90.69909044449733,-65.8876637979954,-21.500782679737213,47.47298671270681,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark63(90.72241175455943,-82.52720631462714,-42.708925221942984,-76.59127528438718,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark63(90.73544189417026,-38.07536763609563,-79.71770594447898,81.56708938186492,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark63(90.73592014358567,-21.628029517636477,8.575963985431173,28.677230273002777,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark63(90.75241081586049,-20.129736046252873,-87.38589475534894,20.372183140900276,0 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark63(90.76221997810384,-36.323526668683485,15.509543127177324,33.04587662395613,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark63(90.78682693321488,-22.331470971893495,-97.09366650657796,-77.86619488828362,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark63(90.83373082965264,-85.45438394248768,38.903490209448364,92.17235301299385,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark63(90.86154633701926,-38.001057689403275,6.401491663353738,48.32036659284714,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark63(90.86257289663294,-70.76581741671114,0.147852714429348,-55.13931605418485,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark63(90.87051688958945,-54.674271083652705,-7.598860088885189,-87.98244650525886,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark63(90.8727550037197,-4.164912578570565,-26.370916311529243,51.5959275321284,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark63(90.8866775973031,-52.54333470092298,-57.3397612997963,93.55344083610038,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark63(90.9042932880464,-31.238386470973126,58.13148181472607,-56.07113006862523,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark63(90.90579070285366,-46.31983208244921,96.7375634464295,74.38751935949946,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark63(90.9292403936231,-43.231065594591975,-39.47426673728462,-44.677931626819856,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark63(90.95247752576944,-11.373028991935442,55.5234404787447,-44.810556793300506,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark63(90.96031874805871,-38.61881086329868,-66.69117675223677,86.20447004380065,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark63(90.96303837237718,-42.608387509663736,29.301321186038365,-9.785612577082546,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark63(90.9705455425784,-75.29487016554717,-54.24856929621218,2.368573855607096,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark63(90.97937565553721,-37.724400528475456,81.4716153686856,-86.73754653185308,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark63(90.98099623582755,-42.353090474082336,44.96076678668604,55.436825609407094,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark63(90.98636100859687,-97.5876169048323,88.04140094769156,-3.02863854948734,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark63(90.98800806126442,-81.34532400561471,-19.16126282164683,-56.13150752732066,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark63(90.99579168398026,-82.69875537210942,84.22134098735668,20.32444096256023,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark63(91.0006499898775,-45.72885039463179,8.767239898847706,27.591621635279367,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark63(91.02077475136792,-65.34115974266905,44.65870202222692,48.562054629778544,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark63(91.07111166510848,-87.23666283786524,19.924439062891096,31.24549809772813,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark63(91.11264129783706,-33.37607577746023,34.62478498634184,-40.13906505110945,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark63(91.14289829951358,-21.737619123978007,-24.284314420293356,12.03624497486122,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark63(91.14370921609424,-21.338434455171736,-22.331070097581858,11.137548402931955,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark63(91.17648928580871,-12.079113457953923,-40.49895915992128,-75.49065507872467,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark63(91.18362161514227,-73.21605887929073,14.718035817001905,-49.44035261668795,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark63(91.19082684730188,-92.35933808171295,72.46941389690525,-51.58316983476807,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark63(91.20704216688677,-50.90187138591826,74.15214069312421,-22.409803871505616,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark63(91.2206962345978,-55.485728287442896,60.420223425925315,-39.56132809123534,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark63(91.2236838822111,-15.559940670591345,-0.5871947821682255,86.8493012842024,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark63(91.22997781404953,-28.75050673410628,23.27956882150221,-80.05722233869284,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark63(91.23740632202788,-72.74923113277168,-7.821893101141853,93.24292954891524,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark63(91.26016566527198,-39.063889756377336,-79.42015385060701,-86.35443550769662,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark63(91.26480660364854,-65.44554937405967,-8.881977836608158,54.20705299037357,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark63(91.26916430997144,-87.9743463074388,56.4605503710076,-57.06265068371241,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark63(91.30469975842655,-32.44754128828072,-23.063747298879832,-44.29289586667791,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark63(91.32946200946716,-11.208940731726642,-73.70952012219927,43.24925133600246,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark63(91.34914522335686,-66.05535193239388,74.05002423652334,-17.419884552207947,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark63(91.36347530728179,-3.899347803685771,29.135501545692307,-18.290647912389986,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark63(91.36642592053514,-22.87720980547587,-5.305406383466263,88.18914019601866,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark63(91.37759211884006,-5.380006715229285,37.74758193397457,-64.29021404142333,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark63(91.40786548854635,-73.96449566112082,-91.47756068218914,-24.663461938537324,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark63(91.41376789465295,-21.529530632151392,85.12430863317664,55.77118055941662,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark63(91.42627394981699,-82.52605493538124,-20.174716970537744,44.916001593301075,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark63(91.43600450367717,-28.465630181188843,-86.0432817769784,6.123822939359343,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark63(91.4502712168318,-16.48567534588085,-79.19424652013967,31.209626750137232,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark63(91.48412913134095,-42.84202961189087,-50.52650152556335,-79.73434416373593,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark63(91.52594595077227,-24.66121622901926,74.83475063840831,-53.4934758709209,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark63(91.55146733241443,-15.12661951621888,-16.22696272762572,85.54908212703253,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark63(91.57133099222628,-20.099415922071344,37.34047770034607,34.817109595982174,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark63(91.58082227125459,-15.512889726169774,31.55779825642125,-61.94989820525871,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark63(91.59122506820202,-73.03362436304045,-97.46699302681998,18.970775557465245,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark63(91.59703192733912,-23.35302523112,51.00456017370547,-49.77167391476216,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark63(91.59878989251743,-27.67954288632967,46.36824555403257,24.35675998782058,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark63(91.6016871330007,-18.303201554183218,-0.08436149715167574,-62.67153720831495,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark63(91.60471456012016,-75.1173674861055,50.17540374127597,-78.62748769560537,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark63(91.60712113593215,-64.04210533091081,97.32171118633363,33.50808005135579,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark63(91.61614527687547,-33.9634796725846,-71.08185400384737,-92.33699172412638,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark63(91.61917689324929,-75.35751044740245,12.843159515479059,85.67244664878822,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark63(91.6390538716438,-5.631441058805422,-27.22015109404468,88.41242996597137,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark63(91.65877490873007,-60.03830268522985,2.494722298434567,68.40373519041282,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark63(91.66798150359426,-59.14604465730844,5.788723193938907,3.1241124069529462,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark63(91.67212359169633,-72.90754795574676,36.11295277833659,-28.994136289640664,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark63(91.69229999007328,-18.203648688167817,-31.51410254551969,46.51099933779733,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark63(91.70077166750056,-52.78941609414609,-12.43064762292623,70.41083073443195,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark63(91.74152497154628,-80.8257687595411,-6.822995791117691,20.894598240130918,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark63(91.74918952897261,-30.257110505594852,47.46233759979236,-37.02763983665407,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark63(91.76634444103124,-77.24228204251924,-90.36534335547539,-41.26450282659875,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark63(91.78843767190327,-16.50014309718439,27.377856691136387,44.67780511086397,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark63(91.78918943238205,-59.03124172689667,14.83586753371415,35.227604368001494,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark63(91.79242607371668,-57.97278853873906,-19.63824487608106,50.74720336026121,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark63(91.79892978533493,-17.870037038844416,-85.58180051622381,-83.56255056305332,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark63(91.82675303400475,-56.637109911207936,-71.10406789792361,61.70485395482433,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark63(91.85539511100174,-83.61118801314633,-78.69377567322874,-31.679905999298796,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark63(91.88264607844187,-78.68195281866517,-23.83619173039986,57.19037751126422,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark63(91.8875923967125,-13.358488200882263,41.50986378743687,2.2656260889354343,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark63(91.90008578854179,-54.55529218908877,-42.13120254631366,55.69776473333559,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark63(91.91150461453827,-43.33866832956588,-73.81181632455534,40.52229096353554,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark63(91.92251984373087,-23.516722454404373,-45.491632441984756,25.415773760596267,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark63(91.96456066398815,-91.5291741744877,73.92587886036264,-59.64827885086152,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark63(91.96836751190617,-0.8086203644280374,21.214441248014765,40.995569140354576,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark63(91.97491772482476,-88.99704065205125,-5.12796200656274,-50.21988388404712,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark63(91.97510448286522,-35.512524333720165,63.16889603077948,-33.10057098422392,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark63(91.98906643698655,-86.21625222962315,57.58308550144463,63.10600882907829,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark63(91.99584351817995,-55.53128898867574,-67.71224944802243,-46.421530144411484,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark63(92.0058776931183,-32.256133129550975,-81.92924738732401,93.8100523661839,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark63(92.00768643507561,-47.771573803390766,91.55967677330423,-96.77063861289375,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark63(92.01597371430105,-82.50824780613375,-37.36836040041067,-75.54748731727743,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark63(9.201697447478224,-7.162945724528626,65.63968528024202,-29.867783728127066,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark63(92.02192650127537,-18.948861537516407,-3.7238447852661523,30.230539520936873,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark63(92.0274903913884,-41.649543018240706,-41.85688084945769,23.118981363526487,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark63(92.03618758860438,-88.80398894206809,67.56165200976142,42.94042932953349,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark63(92.04824467371665,-10.172264397214576,34.874370764250074,-7.176537871948668,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark63(92.05654565361044,-46.40115760040655,-82.04140625069152,93.90877842294924,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark63(92.09560543353155,-69.08956810062128,-77.8946338029062,38.388885435012895,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark63(92.11955396041378,-56.9446480512015,92.35192357933798,-20.906733172311505,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark63(92.12167907537699,-15.904563914019903,93.19381958603466,-7.057545331574232,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark63(92.13496464563991,-73.68573075720593,-87.6529433080141,78.05846611897886,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark63(92.13873217806668,-13.237316333435928,26.63270393008787,67.71252279618622,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark63(92.16671981268598,-78.56152706911914,24.05952638914212,79.07357340507221,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark63(92.17159927041766,-87.64136626656993,90.57035764232714,88.47441005806627,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark63(92.18825827300671,-0.5876010315348594,37.92441068990334,57.727652459272036,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark63(92.20436288643742,-36.82269477583186,-72.11002644957833,28.41948743558271,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark63(92.20440925934952,-78.71819766528037,-48.36049359071788,86.50613603915622,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark63(92.21474817023457,-68.31103646790122,-6.464067004079638,-82.03249201130555,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark63(92.25968859082329,-4.981567001322091,49.9582696598122,65.8380324792031,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark63(92.28318182018117,-0.09776986713188762,25.154755624644338,16.15102120514402,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark63(9.228388990443065,-7.638858931695623,98.08386873376244,89.11524443330518,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark63(92.30329120968199,-85.12568929567826,-65.35668727181292,16.74488589037304,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark63(92.30653686108315,-56.73182199694049,72.16357439175752,-85.98677538199075,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark63(92.32495163655216,-21.28434125919962,-95.83438006066378,43.24064951251623,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark63(92.34499306041556,-92.50200356167288,98.02795646777378,-91.09168433015553,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark63(92.34645781659626,-77.05097060279446,-68.13719686294897,36.0988031419854,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark63(92.34668863230766,-73.68737672266448,-31.34685592028164,-37.05108842865226,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark63(92.35644852775215,-75.20424264361414,-95.3797226186025,7.984551777507761,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark63(92.35809541941245,-33.85577481494093,76.31818645629264,-39.271257176480454,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark63(92.39776726064969,-19.07715363444933,64.50051332609092,66.25712834937445,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark63(92.40259100220612,-42.1719406427034,49.817439510883275,-57.44167276146723,0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark63(92.40474892567727,-18.92709526191196,-92.41990074296969,-32.33779753853929,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark63(92.42448815995263,-83.94587821687011,44.96982452536889,-53.47119919222747,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark63(92.44490286866179,-73.35958372615139,-86.83533167350255,-74.36039106129353,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark63(92.44806773759106,-51.61278666815878,-63.644778244785606,43.20634710085619,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark63(92.47582851715512,-29.114838872951935,63.050956310729845,-80.11619078108758,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark63(92.48833779503411,-59.483934975262784,77.24194850018435,-52.97436754552409,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark63(92.49517586163384,-48.98688912159841,-65.12310182092509,-69.46140892898138,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark63(92.50001847789389,-48.1915289539411,7.495833247480249,-63.3395075458846,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark63(92.50823496822534,-16.4607055401069,57.22111847401911,-30.211442917875203,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark63(92.5136684161427,-58.26819887833312,-41.83656999268941,-56.12848825458636,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark63(92.5209525030235,-75.48725629474218,20.738784336604255,-35.01718726937422,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark63(92.52424113654038,-44.291809773519205,63.14902163153732,-64.8440192707052,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark63(92.54187796925834,-82.49504501548171,7.711984745840255,74.56181610900248,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark63(92.57703603676691,-93.20286247226039,-51.64295148206519,26.752403282260275,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark63(92.59512914903755,-16.962823842743063,54.23499172823023,-64.96993197853848,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark63(92.60840209280613,-55.56742668875594,0.17623528931505916,30.61393046477994,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark63(92.62244749304088,-34.368268903888406,71.21085903318104,-42.39140245937865,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark63(92.62909262555874,-22.544747154313157,47.73161113142859,44.80284244635857,0 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark63(92.65561669976378,-29.844139218709785,94.43240684014697,55.34326762868284,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark63(92.6564949406883,-57.4709661375782,-27.99772987801674,-21.1239421602327,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark63(92.6764820562837,-68.81822269062798,-21.463119091617557,20.816942977863718,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark63(92.69089045966757,-25.699016954446478,-24.475875546411842,46.6016631229119,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark63(92.7107747343153,-25.34707527354658,78.87009156458947,30.64476269223516,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark63(92.74313698196397,-76.64885468168129,-10.438184106254454,-54.525179963834724,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark63(92.75737746723604,-71.12072556601356,-34.710875087523846,-22.149846212046896,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark63(92.76801199093762,-27.316958407977125,-23.07671362916473,-15.73192396900916,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark63(92.79019998700235,-65.10149729780034,-88.91277523259299,-32.142484009762654,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark63(92.79155645679975,-75.16099287538643,97.95224316795378,-99.19533959311029,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark63(92.82933376538494,-6.940148637491191,-52.15759452871769,-99.66060431774847,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark63(92.8352054174984,-37.23028671909589,-28.523605680194336,18.318920482603247,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark63(92.85960274924855,-47.06298379797511,-66.68481489882211,-74.12618228552824,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark63(92.8704025500713,-42.85758824695478,-20.7907476404543,-31.582181483817976,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark63(92.87911120669378,-18.42485603854425,-46.87500944768801,73.10213733827368,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark63(92.90302989042692,-30.13928608858643,18.131579065469253,5.0987801822489445,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark63(9.29384484760601,-1.760788523748829,20.259473096056112,-7.211253862139586,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark63(92.93874810754343,-68.73655934427576,-38.13436812161044,-45.59795274562015,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark63(92.95894465881975,-37.09736080466146,70.73438287379423,52.13105104977839,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark63(92.98230540079658,-78.87101852640133,-61.9888355017441,47.53097048764363,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark63(92.98975216353068,-92.44999766964337,-59.634549363285785,71.39574069377977,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark63(93.00775705384677,-50.092454536320986,-80.7562220505635,54.41929657986893,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark63(93.00832062120017,-29.074846492934526,57.611760890638664,-18.850951203711077,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark63(93.03241250681961,-76.74627655032724,-75.43784070506563,-34.372133408832255,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark63(93.03919694286748,-14.714515699594429,95.22238051293021,17.569693506854463,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark63(93.07359439801823,-22.063772927106527,7.700944453145681,93.39388681306721,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark63(93.08365073194412,-61.60600492862993,-20.84204854724574,-71.10368694525832,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark63(93.0890986027907,-70.45196883494044,18.63710342096141,-64.04598700422932,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark63(93.09571064277876,-35.96734121601253,-73.53991421808973,60.66128579671519,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark63(9.309921274577064,-11.972599594139012,84.89311362420202,-19.121246745317563,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark63(93.10259678311749,-51.476413688520275,-98.34992056878646,57.154552839177285,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark63(93.11509819860626,-11.665903780996373,36.60665844525596,-58.395067108899944,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark63(93.11858512173302,-17.989073180795927,-81.3713532408382,-54.938458070686934,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark63(93.13163814669747,-19.434434500989155,-88.17559677058613,-31.436135120213578,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark63(93.1607559907749,-80.7136480077449,52.972717816361154,-74.88975150640613,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark63(93.16512462190778,-43.54613917745369,-52.01053035427079,97.52046128114776,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark63(93.16677007541583,-19.09256048547003,21.045482529595972,-59.3062354684545,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark63(93.1906857403925,-68.16869161144842,-58.09722080087902,20.24390613809372,0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark63(93.19630119205925,-56.22372878554551,-9.50462139355335,-84.7651868644341,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark63(93.2004678875276,-1.8138320708970213,35.544163938562434,82.95667526245944,0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark63(93.2226738281154,-77.90785004788974,-53.185688120048354,-96.88628531706445,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark63(93.22707231969133,-34.58256711351919,14.539977172100762,79.45776582930569,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark63(9.322861310422596,-8.495225079308952,-1.9443268550753459,46.75304019516901,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark63(93.23738238022469,-29.366564589429927,-74.19966257796233,15.475385106799664,0 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark63(93.25723608661815,-72.95400995508518,36.95460285550138,-4.226234008294028,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark63(93.26131520688307,-41.67239089763566,77.42132777070574,68.14756028878429,0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark63(93.27559007167721,-19.488406235410793,-45.21599278564741,76.65173617472288,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark63(93.27792798292054,-72.8114992876101,-31.012369328595184,-12.89743996757204,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark63(93.2810302140075,-58.999312508197455,-72.96457552392715,-40.98915014442197,0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark63(93.29850698900447,-24.217308106389794,74.83775785603385,-90.1523678391144,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark63(93.29992060798546,-50.065390658422615,-10.968622994198071,-17.689318650484424,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark63(93.30022064180042,-41.39315606723342,54.501660546093376,-12.175301805371163,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark63(93.35925885026663,-47.136547650911666,-34.044982043562186,-62.162807691366616,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark63(93.37536605682155,-74.65705191402398,29.547804044172466,-93.75946765477559,0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark63(93.37572361428661,-68.43341662000509,-70.03420057135034,62.544608163749615,0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark63(93.38957373507785,-42.86213344375778,34.94849373272194,32.89576577989317,0 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark63(93.39815713375282,-43.25632287453729,20.59400052520266,-38.90491398546967,0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark63(93.40086421731485,-77.7419347912553,15.99413327245911,87.89435186791104,0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark63(93.40164207290653,-57.26715711083261,-54.424877868898825,-61.3572972826498,0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark63(93.40873698785964,-21.863732252764905,86.02461291308262,-71.72099965631975,0 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark63(93.41101170391596,-66.62504129866487,-79.22322966425494,41.07094681523469,0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark63(93.41193070520919,-18.065505738615144,11.689102052493581,-39.56663849499702,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark63(93.41353323469798,-31.804213782997934,40.59953988568731,96.24637388699739,0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark63(93.41474050868425,-41.103028884964175,10.98187190996856,20.379924717684574,0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark63(93.4166628563311,-14.958368059898234,32.16579617728368,-95.2347912360648,0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark63(93.43381757675274,-86.83147485846301,-0.4443367023278455,54.69331330589415,0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark63(93.47036569614292,-11.895814052418615,-97.88762727460971,13.34679188042756,0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark63(93.5059643245049,-21.063825100647264,-75.71605082114581,1.5123860963714293,0 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark63(93.51382045934992,-88.14708188278948,75.33837909991189,-85.3989845555129,0 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark63(93.51510182132452,-81.4859168801042,83.43726664587706,12.0159713920376,0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark63(93.51755015443166,-69.6191403461414,-83.05950415529702,-75.68854477375112,0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark63(93.52913534102748,-32.550579220385046,-14.972915359997714,39.659088910899925,0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark63(93.53380312249001,-93.21788207526853,96.40177978664843,-51.50518489553284,0 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark63(93.53490675843673,-92.42196487272443,85.20982386527811,-91.59744086481663,0 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark63(93.56277730369655,-74.85431654749493,-66.10174331704911,18.20328609030149,0 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark63(93.5628355041564,-35.29427915703678,-91.91725275642656,-39.39150219577867,0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark63(93.62402642254494,-43.19679928940781,75.23873157915978,-88.18605934556183,0 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark63(93.65885030573779,-4.778886792051296,-16.716409530392724,64.52098412358558,0 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark63(93.67675106252617,-81.53259708119487,69.40618482707052,18.23982856990783,0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark63(93.7006937612004,-7.465566521302151,18.95868767230826,-14.440438652291917,0 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark63(93.70657064163385,-73.7838913330103,86.99229209391379,30.615037925555413,0 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark63(93.72417676800214,-47.495949568984884,20.157777111940376,-23.92599145388155,0 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark63(93.74183527897247,-11.7721605622598,66.83767619820046,83.44626846374044,0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark63(93.74369839609417,-32.37051571344864,54.62470166693902,-58.702495768357,0 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark63(93.75229630025385,-66.27966297960874,60.22849314019726,-74.56800010226581,0 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark63(93.75234437538623,-67.14815384478462,-49.39875710610395,-91.86898189116674,0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark63(93.79292151280094,-48.573875000319575,-51.69874981800709,-45.36107706821839,0 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark63(93.79834592772895,-77.18014269445646,-92.67171427919322,-16.703764417629202,0 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark63(93.81069453476798,-55.58619773260178,10.212122642390113,-72.31434222175,0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark63(93.82518071503125,-28.866633701606318,-86.98634155339538,31.7593921820812,0 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark63(93.83931971724473,-37.58807253420207,-73.41300766954754,37.2302781774097,0 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark63(93.84167989026486,-58.295735747637025,29.368894561793496,-78.47493660836034,0 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark63(93.8502696174146,-33.63022686996102,-84.47757964430667,-78.36155344151787,0 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark63(93.87893953617731,-8.941871341668957,70.22912891453234,-17.29388120208681,0 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark63(93.90219920208003,-77.60223174742535,4.9595278807063465,30.648160069193807,0 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark63(93.90563243092959,-41.73458343161842,-66.23356256326261,36.61986326603554,0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark63(93.90955157348074,-60.85757032757657,-12.501197606962307,92.36823827926995,0 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark63(93.91635849858275,-17.96719958404192,89.98631546774993,87.64559375750781,0 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark63(93.92642847053247,-6.998305668932829,85.58164550261816,-95.23768841386861,0 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark63(93.93940743925944,-98.93203066239182,-72.69673135105263,4.131491974478678,0 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark63(93.9559515170642,-65.61220169753625,67.54360109911931,41.57760511935032,0 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark63(93.97170219792073,-78.1170053062265,-17.839298884718772,28.52503556139706,0 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark63(93.99501748311471,-29.65917950851187,-20.243830032300508,-2.268067081851939,0 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark63(94.00726158565601,-18.22152440981573,99.0258734681824,77.11012634404594,0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark63(94.04585727334893,-49.82090137185207,30.647485338961985,82.29654700178108,0 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark63(94.07978488621981,-46.43732723854701,42.642318086260076,-1.7595047564692692,0 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark63(94.08096434042216,-12.580468930251755,39.22334233435018,-59.84197290191284,0 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark63(94.15196594063087,-7.204608681893916,29.452355036927656,-41.984725862883735,0 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark63(94.1565969112014,-0.7203224330911411,22.816348868128273,-90.88070954799184,0 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark63(94.16317049269966,-49.20556775448475,93.7769414626884,72.64181015342155,0 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark63(94.168932847495,-19.340780565269228,-80.21783586685117,-71.17514473501635,0 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark63(94.21923816255631,-19.411612225363342,-94.5817546569643,-40.85076251437278,0 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark63(94.25141426386494,-77.00652324926358,50.018835644180996,58.23975860850908,0 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark63(94.25392719512934,-67.26584983303472,-48.17330206117036,-34.512766466846045,0 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark63(94.25817303075124,-87.00894985973116,-14.099842991213222,27.224921279601617,0 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark63(94.26127814871222,-62.88882622670457,-87.01918742516011,18.043387596955114,0 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark63(94.27591421320454,-64.68931410958663,60.06560930404291,-9.901336876707134,0 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark63(94.28016031255336,-23.472524641668826,-45.503475598531566,-63.35684897217495,0 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark63(94.29238210984226,-14.577277012828688,20.8316352631675,-77.65225203236024,0 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark63(94.32928576775709,-32.37752445847978,3.5030242943518317,38.831830576268686,0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark63(94.35919502966118,-28.418353168487272,-5.251542519340163,-6.570872624990585,0 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark63(94.36001716918113,-84.57692044048008,-12.441993320295879,-78.23705436771257,0 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark63(94.36950072441587,-81.50519065063912,18.480313369623076,-42.74042605657233,0 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark63(94.37630814318359,-66.10267267045802,31.754230379332256,21.16622284311819,0 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark63(94.3828453655145,-54.36604788757153,-55.269898428436306,41.28073485587447,0 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark63(94.38658555184821,-84.53023989780235,-69.78611679539175,-45.90108045352581,0 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark63(94.4046763710615,-44.360552998572224,-50.05988754813857,-53.60285121697616,0 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark63(94.43695587867887,-28.886465613604926,66.29725586828113,50.444705455174756,0 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark63(94.44215491456276,-11.687707150055644,-53.26822465577366,-63.09044994752069,0 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark63(94.44530718876106,-12.780020881158151,-59.7458194635641,4.794130503258387,0 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark63(94.48173069613227,-58.407356400110054,89.87435941358768,-89.43457375843062,0 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark63(94.52604559709371,-68.31154822885262,22.628820162226674,98.62886817098394,0 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark63(94.53647379969908,-79.52034690964551,-16.552108479365145,-78.1562893373595,0 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark63(94.53672091689816,-88.76327232728734,-79.24627888278579,26.125188601478328,0 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark63(94.54070535634534,-26.278245546870394,91.53449240928103,-52.330268494092145,0 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark63(94.56487477757486,-5.27699425862464,57.84655409167135,-93.0598201587701,0 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark63(94.57670502380557,-41.87358424012297,71.90624433720737,-51.27334955833116,0 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark63(94.58019736558751,-44.886943440114926,51.537570731116176,84.34040373915263,0 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark63(94.60910295394328,-28.937053368086765,-20.266133171794777,-29.27056905538703,0 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark63(94.61707688991729,-37.26075391295933,-71.96015236814443,54.472400233283025,0 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark63(94.62631752693525,-94.4348146518462,51.848957513119984,-50.71869035415122,0 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark63(9.462718437248554,-3.9069476640406435,24.03615000029626,46.279920872062206,0 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark63(94.66155460148477,-64.5741313630266,-30.684437151547783,-69.8500046075369,0 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark63(94.69910147933734,-47.40498285770363,-10.09238035283883,-81.57653895568713,0 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark63(94.70786704302037,-91.94616044558437,-58.20651546606375,42.471690691738985,0 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark63(94.72183363613607,-9.414179708521672,-12.50056421040837,5.968037054531379,0 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark63(94.77206323383828,-54.75191991653043,-71.78137396954816,-41.48104511439716,0 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark63(94.77576383874396,-77.31176608750026,65.7049716362178,-35.608340350053936,0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark63(94.77650397064562,-41.32946043938679,-99.07474885004879,90.26741509909687,0 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark63(94.80538372496355,-93.82617323166713,82.61093516500986,98.24696561678527,0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark63(94.8458599876889,-38.57836588211314,81.38827143319156,39.22199393077605,0 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark63(94.86294033824561,-69.0321874186252,-12.964679817771739,-10.44691723811431,0 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark63(94.87200519910189,-72.76312978302013,22.19346614197005,-98.4670293502348,0 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark63(94.87810714371133,-37.17068896516842,-24.954883896500064,48.81227695013385,0 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark63(94.89041567023787,-87.36346760922189,-4.813391912715474,30.017158911817234,0 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark63(94.90903794572361,-38.17835731696364,-54.42956365799567,33.222848246652035,0 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark63(94.91916450627286,-32.94936828442904,76.44660495401118,72.95557162835806,0 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark63(94.92581308589988,-71.85760623554032,-33.59869516860667,-46.303459641117286,0 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark63(94.93563074054799,-18.755282237524256,24.58481632706153,55.72688464047397,0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark63(94.94141306554232,-66.203015837604,-48.57921206096385,-64.89600416226078,0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark63(94.94335082834604,-52.566045354063306,-15.544764346993546,45.30486443775959,0 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark63(94.94713237322028,-65.64439879757273,53.382515715866504,-68.73133684096342,0 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark63(94.95386437436915,-28.783145681076633,68.3786828076602,-58.935733299616786,0 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark63(94.95533282987194,-31.969168205211403,-69.08627924290766,32.54528326189893,0 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark63(94.95821219718079,-37.00624255125915,-2.6462247907731893,-39.335954292592554,0 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark63(94.99384031790277,-22.219343743226432,-78.77354088173334,32.72895965671938,0 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark63(95.00383712589255,-70.66791241444186,-74.22424215901987,85.96256940276191,0 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark63(95.01463549600408,-24.6891918048006,78.43338548689042,74.59416076117625,0 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark63(95.01535732265671,-51.51486165644057,71.12104644779504,17.09281484063021,0 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark63(95.01547014099029,-29.016538714397782,-71.34191904245827,-93.12264455498153,0 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark63(95.0163826691682,-18.511396882884796,41.62253327416937,-18.933090871021278,0 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark63(95.02986442082025,-38.70611026998816,-18.697568491750104,78.30789531046912,0 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark63(95.04443917423308,-80.37769728385331,-69.78983660019524,-22.097329235622325,0 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark63(95.04883002290688,-12.955920320163727,87.09069503058578,-69.67393645558191,0 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark63(95.05181142617809,-22.925402578300407,-74.37072531351825,1.4518310464464435,0 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark63(95.05579130585124,-78.32296256965357,46.932162463168595,-56.0798049630888,0 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark63(95.09574185036143,-64.04070600040896,-75.77928895300701,-86.2229222874629,0 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark63(95.1023918159772,-13.506869205147495,59.925842731296115,-7.7649960636946105,0 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark63(95.1192898718339,-16.006841788788506,9.174168729793351,-59.459510231925684,0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark63(95.13015092946605,-7.16408746576424,66.62476084720106,35.66148289822809,0 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark63(95.14180035528531,-4.421790820063933,18.930916554214193,41.32007931474476,0 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark63(95.16377307563982,-5.343263854510582,66.09366661758799,-51.560850632496155,0 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark63(95.16973876341947,-66.86286657956111,-18.60688777076338,74.27018205549047,0 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark63(95.17714119144728,-68.34882571886183,-90.99299344601283,72.60501919850375,0 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark63(95.17773637355904,-11.397326236562932,49.20685242556914,50.259900238843045,0 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark63(95.20131512267756,-24.70609501544652,37.5153260909924,-60.97217180129837,0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark63(95.20677125462987,-27.174886669327464,99.76112206748354,-33.945456756668364,0 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark63(95.22145986103217,-33.35861429767324,-66.4833988354238,85.35364583272337,0 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark63(95.22323197528175,-55.63124114306199,-88.74371287305627,-10.951597455885988,0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark63(95.22972940809595,-11.471434321274216,-35.47905210932602,-55.43268143180926,0 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark63(95.24422102176175,-19.79685311111841,77.70010927955505,-27.028122272626035,0 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark63(95.2576985814787,-57.73899686320942,82.24713084360394,-36.046724866641064,0 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark63(95.26217375974548,-33.24789442718661,7.507656095578724,-78.04912847478482,0 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark63(95.26806340365295,-31.506320144478025,27.390039000146587,85.56952342725762,0 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark63(95.28647438845363,-31.297170914107483,87.41315831157567,61.41691131035634,0 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark63(95.28883106717839,-91.71421014681616,13.011047708063515,-47.51736684653933,0 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark63(95.30310171835032,-58.33384397900829,-76.85172399897596,-22.760498773128333,0 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark63(95.30627106048667,-92.52183736228352,-68.53389713106108,26.649396525451778,0 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark63(95.30782777917938,-40.79144842651381,1.8471575626011827,85.62382139273745,0 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark63(95.33412273891918,-83.95390746814564,30.82833617738646,63.994940987450235,0 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark63(95.33720539011586,-95.48882330790458,43.670987774605095,-5.030953577426757,0 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark63(95.34190106240158,-74.12590843400648,38.564145420698964,52.003919330765,0 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark63(95.36083097392995,-51.88769075648314,68.6928682403773,12.483498963621258,0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark63(95.40724558049553,-94.74796086722053,-14.925139979212048,-78.66549260933493,0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark63(95.40983143489834,-53.01152680798962,-33.3293267601002,-92.48768664555041,0 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark63(95.4135227932459,-45.3805222018612,15.330521047859207,76.87040442216525,0 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark63(95.42144455204806,-45.58706942291182,-52.91781194721108,-78.60532491719363,0 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark63(95.43230914006409,-61.59716836477496,-48.403018455820465,51.74218128128837,0 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark63(95.43344583964299,-9.47053618689111,-44.38676800140551,62.93928160218499,0 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark63(95.45421487559508,-64.01851445178147,-17.127743940122215,17.93483523369919,0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark63(95.4624908714838,-74.55783499077198,18.61710335886424,29.204879079893743,0 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark63(95.47224370845245,-11.484755780069108,-43.504197644061435,-26.258258637159557,0 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark63(95.51173254067498,-32.009584767246395,52.81626564541628,-6.86899228695188,0 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark63(95.51697670694472,-14.051225886501257,-2.819193172027724,62.02793323483746,0 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark63(95.54631992054868,-12.815814260266038,-98.08874452551753,46.424623974172135,0 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark63(95.55071754145294,-14.22852647755073,-25.421993347791044,16.922382924244104,0 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark63(95.5901269455768,-82.95149394431118,-16.1799757215108,8.009845405704112,0 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark63(95.60850132722936,-68.15866665439758,48.76692214687472,-52.22866795109087,0 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark63(95.61218651910292,-22.084565865335918,75.38224324377072,77.45483373233725,0 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark63(95.66490398540918,-41.77712258119439,57.55386125558553,60.81036751598663,0 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark63(95.67062176843746,-24.77389386003,-1.676764017114209,-60.77308630828817,0 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark63(95.67704282908676,-72.09206544993707,69.42380392401486,-49.72975992321167,0 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark63(95.67780105598374,-7.5361011360069625,-26.054283981167387,65.51642744236406,0 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark63(95.68407701442345,-83.05637712263574,95.17504851213715,45.30557435053157,0 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark63(95.69958957200939,-21.39691270136437,-16.733558758518228,34.81620664212562,0 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark63(95.71870343662664,-50.342451326376114,37.37855327839071,-66.8061496472214,0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark63(95.73769296480239,-9.732121734061522,-19.631898214045833,46.57237643848981,0 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark63(95.74942678964399,-30.31889730661574,0.28647320732129344,-41.88065197939923,0 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark63(95.75970269898494,-92.42436239811245,53.18697688015817,73.40454562229257,0 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark63(95.78339128604071,-9.857216307527423,36.050049813891604,-32.04597487435467,0 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark63(95.80095043331124,-46.778491816307444,-8.84398480434956,-62.60066422854902,0 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark63(95.8165682918823,-57.62151053971771,-29.24108507051504,27.34867318976886,0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark63(95.81697524637636,-77.55812594206013,-29.538590540841753,-96.83968978091626,0 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark63(95.83712870623674,-14.785753265253703,-39.59207051150246,-57.904314642338825,0 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark63(95.84404090522699,-57.26092678150594,41.58886294915695,45.09895127346252,0 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark63(95.8701783439418,-11.34480795626527,22.267888605141934,59.69723031764744,0 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark63(95.87357440685577,-16.410936031749742,-29.83358174331174,-84.71003065639573,0 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark63(95.88041496629918,-63.62506562664392,40.14968229101464,76.38219794416963,0 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark63(95.88428619076316,-56.07756563124258,98.22686596012412,-80.7145835461158,0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark63(95.89729829373908,-83.15472615349398,-56.42354787378237,73.77778175628737,0 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark63(95.94742128576402,-12.463348015651192,80.07433785300512,-23.402870892929116,0 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark63(95.95025626614768,-65.5425930346473,55.44072749596248,-95.59365398522787,0 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark63(95.95332531675373,-69.5361731287302,7.1091572825435065,62.92458005040763,0 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark63(95.957919081397,-76.88307579651905,-93.87318366149786,-97.2878294701217,0 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark63(95.95845023396828,-90.04999756755616,22.521248971833316,-64.87544635999056,0 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark63(95.96970976210795,-89.85112779725549,99.36019116732544,-25.729911659889382,0 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark63(95.98368750826566,-21.115385763117487,67.03510811101773,-10.926998619348964,0 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark63(95.9850578861392,-30.34210804645636,-29.954806486241026,18.139314280832124,0 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark63(95.99773924633516,-44.668459132349334,-23.551714651701985,-74.79314792327385,0 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark63(96.05437952255343,-90.47489518468824,-99.29325201964095,-35.870662443244754,0 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark63(96.1636296529094,-36.63376518078272,67.17790608251224,54.23901600086873,0 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark63(96.16726639297582,-2.839470141762007,33.3758879961062,-37.72941576127491,0 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark63(96.18156023000304,-85.06874935539909,44.99028061637122,93.99401894587513,0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark63(96.24731979771809,-18.26408087000955,11.993063030347912,87.80591865952226,0 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark63(96.29454694038103,-85.9829879401901,62.30809004300707,33.67350766379275,0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark63(96.326975142863,-44.62877046839364,88.17841133168014,-43.919146997179695,0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark63(96.35528146547529,-48.02725259955374,-98.27754296890289,57.2350431783054,0 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark63(96.3729556429002,-4.078766448799669,-35.41747422742108,-46.33601696608763,0 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark63(96.42605181859633,-72.03653725366877,20.618520193874957,16.47552189700218,0 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark63(96.43439514021051,-25.970843139157125,-75.33292101072072,-80.6271853113879,0 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark63(96.44001108900184,-16.500146740363846,14.254510418336892,-41.77462227281015,0 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark63(96.44313835578188,-20.307182164102215,-22.704126172055084,-68.78926822357492,0 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark63(96.44831634524436,-71.91222456924359,-89.44335367365125,-56.10857046068085,0 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark63(96.44983715722248,-64.51884447225922,-5.585340188514891,-49.97733813086687,0 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark63(96.46086272186486,-34.33390502647275,53.45340206813228,-7.924005122790703,0 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark63(96.48125326564832,-83.11183234021627,81.74050927173761,99.37577100507252,0 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark63(96.4929766811106,-81.72842561710297,-40.8934786844227,4.606916273638177,0 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark63(96.50441670551336,-61.713168074014455,-46.4155041597649,88.20768102323143,0 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark63(96.53542665708471,-43.7383399460723,64.49859607769415,79.7171327621582,0 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark63(96.53848299161794,-78.62764682156643,-56.35376318372223,-26.862296454922713,0 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark63(96.55004016195116,-65.15100097536985,-18.67235782616548,5.264700359414064,0 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark63(96.55536762518565,-62.98092824790245,94.79271978478067,27.549059468657177,0 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark63(96.56162092490769,-92.05116407440006,24.360374150605196,-82.8822627025055,0 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark63(96.56956676765074,-5.080591338261087,72.25512829894137,-42.74085461906951,0 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark63(96.57400792751827,-21.030132013030766,-85.61058283853038,43.475302393588606,0 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark63(96.59410047792903,-87.73757113035938,-26.663575184154183,6.440449688803241,0 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark63(96.60980342050726,-25.36145885133496,29.567213701319048,83.18180378434562,0 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark63(96.61341570626877,-87.46702727375752,-79.45171281137205,-86.72543379315462,0 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark63(96.6240858050648,-84.41984189379492,64.90651351155924,15.342018014279304,0 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark63(96.62542261989319,-7.727938502636775,88.02400839997838,19.12317349881789,0 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark63(96.65391153328187,-28.281040313359497,18.231893636663884,97.39245698259035,0 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark63(96.65476406827128,-32.175900280822816,-45.568335349744274,-14.579287592829118,0 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark63(96.68288663271173,-51.001004973311126,40.69928806408453,8.276902166744165,0 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark63(96.69753218537161,-30.581497382689733,85.62743355528457,91.30100630477736,0 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark63(96.70975177632201,-20.14749536462206,-30.764224859280347,94.7209039607047,0 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark63(96.72947288320793,-48.86092351478204,67.12427566686821,78.07402571157155,0 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark63(96.74479039917367,-86.25749913966311,4.166319888096865,-8.446460937727323,0 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark63(96.74510057354718,-73.41235023278884,-48.50088790181597,28.312454799169416,0 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark63(96.77978342206094,-28.690036345329943,-96.3553032600961,-97.54753219801626,0 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark63(96.78005755663926,-11.622308310823868,99.93012536447901,35.08730221599578,0 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark63(96.78505299971127,-11.310470802612627,-79.66451326571968,30.60657021226706,0 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark63(96.79808903159835,-14.194562473349265,-58.86112277475499,26.802194203286575,0 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark63(96.83590168902714,-81.03280828911417,71.48515606330469,10.185993926336678,0 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark63(96.85444842233079,-88.03478232855309,69.37049421146787,-94.55841269092733,0 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark63(96.88822626165904,-18.500660739383434,-38.71930980354574,-43.59748734354088,0 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark63(96.92512940522323,-67.74977014785455,35.52374040232081,-40.636189287789605,0 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark63(96.95635223139698,-26.168619491552263,-1.4845842326465402,-71.57215437046523,0 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark63(96.97634655810515,-67.26449226535283,56.04862175414479,-46.74195362392959,0 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark63(96.99295798953196,-40.6681947607469,96.35766863391103,-8.680312493307696,0 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark63(96.99662660647007,-86.71568001750072,-72.04002509469032,96.06456732288694,0 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark63(97.02854164205382,-75.82837591523419,41.80939441137656,-0.14101673952120564,0 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark63(97.04955447334166,-74.59688521511032,-92.23690396610067,79.73274309970887,0 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark63(97.11124219318953,-36.549582068429686,77.25740257064848,-33.77094734690216,0 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark63(97.13042420600709,-62.07771872650611,-30.98457373335883,-92.41899837413341,0 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark63(97.18260260414104,-76.65174214323653,-9.899955359583728,79.90802748019402,0 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark63(97.18757749953818,-19.080248529957842,30.271506599470342,73.72459004813663,0 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark63(97.19066666628564,-45.95190059205625,61.37654026213579,94.91838813559744,0 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark63(97.20300484251803,-18.627187873266678,-86.96473009537789,-85.18151084286106,0 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark63(97.21156010161351,-23.290266275261033,51.98185450427724,-7.902086460234827,0 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark63(97.2249564215347,-71.29098953925244,-45.740583672533845,-5.558941848682906,0 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark63(97.23727141258215,-73.14385876617236,-88.45710357616773,-71.62344402267371,0 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark63(97.23907738244907,-36.10718051945785,20.4778679402649,-6.103758237096628,0 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark63(97.24707881117556,-12.94336580220363,83.38941264996706,-14.282944181174571,0 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark63(97.24767312733192,-95.21048520224792,66.668723029447,-4.444667080739876,0 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark63(97.24874089834594,-75.44476013656028,28.439261234292644,24.951861204475406,0 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark63(97.26708881232963,-61.41074024872295,-55.836463010417845,-81.29400832783813,0 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark63(97.27086864672492,-9.4934991219084,-74.5334962792679,-93.37502485455218,0 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark63(97.27779090476758,-78.76005648425328,-21.76230980649494,32.54681026045381,0 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark63(97.29965639158002,-73.50865780203418,-52.88503087039291,8.28702514318607,0 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark63(97.30226262790643,-64.71330822314877,-46.44859175882958,-46.938687471697826,0 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark63(97.3030020579508,-68.48835973526357,-98.49659458588644,35.688516877529025,0 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark63(97.30923305177905,-78.35603741190408,-98.1339594392173,-71.50496830774864,0 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark63(97.32620496670049,-53.47183956051913,26.920767143169513,-97.19925645518668,0 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark63(97.33185008829093,-5.191164779686773,-7.7372457696382355,61.46596663457987,0 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark63(97.34134519607395,-57.06297045507267,-17.25845133949126,74.8570124587522,0 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark63(97.34251151070345,-22.805622965083657,26.61019131576097,73.09924460753936,0 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark63(9.735782806529642,-3.9030261235264447,63.39801264444384,-87.92164926718429,0 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark63(97.38166886984064,-72.99055049605157,39.57418864147775,-60.254098192953954,0 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark63(97.38741507665256,-61.86596362911849,-35.444792210762216,15.870435205147388,0 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark63(97.38984937971176,-25.85301087391983,-2.0893207619758556,-31.303111977287585,0 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark63(97.39947459156261,-91.87154599438941,0.7777736896377831,-78.61773388137021,0 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark63(9.740371802481633,-7.22848126768254,71.43976679998573,32.120216492756384,0 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark63(97.40817039129928,-3.0121003204497896,44.75613550860399,-69.90856805078067,0 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark63(97.40975207823314,-64.63094988159469,-18.657336783250187,-69.7865372646296,0 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark63(97.42273628060056,-68.750213192291,85.45575270033379,41.0431057329796,0 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark63(97.47369301534786,-29.379570017074144,-38.246481727441825,-95.12021330361473,0 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark63(97.49997494339786,-34.66397533157999,-15.637496137953804,57.387663475097526,0 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark63(97.50845316856879,-10.877993509699223,-90.14240396433028,-10.85711318771503,0 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark63(97.51242284250358,-82.04399025828775,-80.66377914852924,-97.41970791995904,0 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark63(97.52197202189447,-87.91349922739764,77.16657153795893,-2.3467750422670832,0 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark63(97.53847699080688,-10.576784546863237,98.41445725991471,-19.449081948013685,0 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark63(97.54742750476805,-21.81068544202907,-10.958584464662422,14.359846541971251,0 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark63(97.55261572467171,-64.53049528454962,62.1672709761539,41.07134060897474,0 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark63(97.55657355441801,-57.43890012665518,-95.50386907564071,20.24351518523015,0 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark63(97.56908806660925,-10.878897865998184,15.694779416932676,-12.316237069738435,0 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark63(97.59110970330698,-68.01277468821185,-15.311144672891785,-13.429481587062526,0 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark63(97.60086421050195,-94.77945527321046,-17.57262930109296,-57.50525516419631,0 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark63(97.60102980410102,-0.4765825813359328,19.815330269125496,-54.99898901805316,0 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark63(97.62285291692501,-51.23248154734941,-73.17008482233493,5.89548426786952,0 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark63(97.62987720264965,-77.90642135025658,-46.33387813473424,-17.576685871749476,0 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark63(97.63960205147751,-42.91674537954331,-70.10058556944912,-80.06002421899856,0 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark63(97.64414037334319,-44.085889116495224,76.23170262992085,-85.73229506145232,0 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark63(97.64517581486874,-72.53911411451249,-19.24173080327934,71.79012840406708,0 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark63(97.66529914331545,-24.03681843708381,69.67638294255806,-92.77014772238033,0 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark63(97.66572222876667,-70.12703366161377,-32.49353951697742,83.80004277344514,0 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark63(97.67145392145926,-90.67554719758843,64.88547381534491,64.45453450795665,0 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark63(97.67647491686193,-82.47926239582972,84.68050033578277,-21.583189150619603,0 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark63(97.68181935261794,-59.70431617770762,81.99636026688398,-3.3564185441143906,0 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark63(97.6937263781632,-72.20854383073231,-28.226294494066664,50.59107593148758,0 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark63(97.70707818263159,-62.17630841198656,-99.70104218202214,63.09799289047328,0 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark63(97.70839931215517,-65.44151358221002,69.54775066381836,-6.290945271024256,0 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark63(97.73572398502591,-61.08193802108794,-83.39220293249184,4.441574583358388,0 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark63(97.75104498336736,-71.92461023875111,-98.95079347635796,-23.59154156608672,0 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark63(97.79092862723678,-39.45990564070145,-98.77289543424554,12.244177036537309,0 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark63(97.79587605889648,-89.34265969630542,-1.1909418552899638,-29.050089272713024,0 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark63(97.83339293389724,-29.659963296476292,-72.16001248285653,-79.7105642252284,0 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark63(97.85664214556493,-1.4413711747569096,3.032715714759675,71.9902284687042,0 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark63(97.86884473757743,-57.94570533305401,-56.30323425829329,78.75617735852691,0 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark63(97.89510906700136,-56.67315566297015,59.425620811735,7.18702818778074,0 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark63(97.89982856410865,-55.19961257254869,84.69447652717872,14.849815905669004,0 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark63(97.91068021551266,-59.61637033401854,-70.19966841596985,-57.09241418654021,0 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark63(97.93386156197349,-8.065459382040217,34.75159531989598,36.91518645743889,0 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark63(97.94610728392016,-14.315294558729548,-7.837341786890988,-33.11030485660366,0 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark63(97.97359973433348,-55.08581407973108,-22.802915395567,-60.556736057837554,0 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark63(97.98213558058495,-25.82970298244902,1.3764544886242476,81.45935257515666,0 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark63(97.99023362277464,-87.87792542901202,18.746146313129543,52.78067269428385,0 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark63(97.99258345295635,-66.74776991347446,56.0319295518843,46.76473077055866,0 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark63(98.01179754028857,-12.11872417413818,-76.53067098665562,95.553914083119,0 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark63(98.01556992967718,-91.3728362837046,48.7706786408107,-47.56639170202652,0 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark63(98.03493670117535,-99.27001049366902,-79.42825330681998,13.610876952505933,0 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark63(98.0468458150498,-85.16300862682169,70.36360379328897,29.42291804406605,0 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark63(98.04981400779184,-18.06165785642044,0.12438043689473943,54.670325867877324,0 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark63(98.0548807809243,-91.31171607317243,-9.26899755998869,-99.56744996432454,0 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark63(98.06141407825271,-8.521832214802487,-2.819733055459423,99.8426768393258,0 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark63(98.06533597465923,-10.797390754999853,-81.99420527458858,-6.2770418273630355,0 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark63(98.10656160420606,-10.390304746991717,59.28226521048046,62.00046618782022,0 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark63(98.13809656691356,-76.56310573364682,68.21690900231818,-14.718290212941525,0 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark63(98.17887240316702,-9.248168459154925,82.61187629149063,-74.9501328303936,0 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark63(98.17927598273991,-26.561271307118915,-52.06234648541952,-17.40358370001509,0 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark63(98.20412276101075,-93.8543105759313,-76.24779985223289,-79.8371539867987,0 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark63(98.22529456063535,-91.86164393800473,-93.21888897724544,96.49412415411732,0 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark63(98.23621961706812,-45.344476506242735,-57.05969596937881,-57.7469397074392,0 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark63(98.23733526613549,-77.439519072988,35.25190534915984,-49.58117758333358,0 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark63(98.24831070869797,-36.98973505754564,-40.08647444941198,32.76388979913128,0 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark63(98.25942172489138,-85.15838446054427,8.625627027016392,-35.213643167343434,0 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark63(98.2609990816,-94.01319182602244,71.55041261225065,-41.12766104320642,0 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark63(98.26600300257746,-48.54925157965431,40.11533350802651,97.79049307543599,0 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark63(98.27624107105146,-72.56611330145628,-29.811103109348934,-61.654537102519626,0 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark63(98.27887062922161,-4.927428102367799,-46.83577687632934,-71.10853194869571,0 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark63(98.30827854572297,-58.46336811265396,0.350360501214908,74.91923702465624,0 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark63(98.31317694725567,-71.1770884716017,46.73234078876027,-20.285537279964515,0 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark63(98.34808453004254,-87.40678453381909,-87.81699175777815,11.804406266784383,0 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark63(98.3695441795187,-40.285374303726606,-55.50076308200895,-65.46378800533097,0 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark63(98.38878331839271,-33.438444431938194,-4.535482167443689,35.7176641890411,0 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark63(98.39163954405146,-51.5141986666366,-85.06537031063138,91.21510597366526,0 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark63(98.40741863977215,-41.01834284291077,39.339547075551764,-7.630578365583432,0 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark63(98.41334374581172,-40.12202823270306,-36.86367059307396,-53.43320541286896,0 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark63(98.4163459687507,-73.15502546429553,86.14984722110316,15.356728387298688,0 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark63(98.4253814866909,-12.929295176424077,-48.460579530668355,-22.788132839457404,0 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark63(98.47515500862903,-92.93856118999769,-10.795781850950604,71.92610762422058,0 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark63(98.49742439792206,-34.16021088088206,-38.19387175529969,88.44603306938973,0 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark63(98.5363837508435,-87.49670980451918,-57.20418873420441,-78.77743196611212,0 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark63(98.5426510923144,-46.296148116087444,-13.09104483321579,88.5027947438349,0 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark63(98.54522264076516,-40.11631583265354,-0.6247786525942871,92.73157776961324,0 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark63(98.58815078859647,-19.075090365269176,-86.27667950458664,-14.866816511900183,0 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark63(98.61473084108209,-44.604103665424354,-65.21760256810384,45.682314843357574,0 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark63(98.63333204876238,-70.97641371341348,87.56819069250375,12.459358242888328,0 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark63(98.63414461505539,-22.713284576525155,63.27322845116001,-57.34577382521924,0 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark63(98.64121384329658,-61.39833023418917,-40.37267901074102,-57.188744691563656,0 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark63(98.65442865412106,-76.76293555729987,-34.66188942417223,97.32838742981176,0 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark63(98.68883148092223,-31.921697749855454,-62.1551105540693,76.72619906558566,0 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark63(98.69508086098318,-72.79435030060957,44.04354479056019,-88.1350100682055,0 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark63(98.70063886716639,-60.224674742314185,-99.31423992782742,20.227737729571672,0 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark63(98.70212128702008,-11.402491148361932,70.11934517370184,-68.03552629277343,0 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark63(98.72155032985307,-59.70106858908637,28.466155969938825,94.21446315800083,0 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark63(98.73351794550854,-90.39548941601356,51.36760139496798,96.87660172682357,0 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark63(98.74137165287769,-33.00686822638713,-73.09306066214249,-36.77446815318135,0 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark63(98.76583309912999,-17.946442716703487,-92.65201206897866,11.222415678384905,0 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark63(98.78824373072516,-88.10635809119847,62.09320910401894,-12.188840315512621,0 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark63(98.79047695032176,-12.793241727356516,-51.17239517461505,6.283779178953736,0 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark63(98.80390593801118,-58.44344095161649,-95.45433869247833,-43.70979139396456,0 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark63(98.81248757405595,-29.362699460976515,85.11374310287906,60.922927100031245,0 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark63(98.82348471263342,-82.80560093290342,78.66555535251806,-99.76418662466932,0 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark63(98.8475334985284,-82.43593840448997,40.16818509948499,20.24462933125865,0 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark63(98.87074798060502,-25.880529940801395,78.76149665740851,-74.51422374490042,0 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark63(98.88373502806769,-32.59388767670647,-14.224304199756773,-95.78643068123074,0 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark63(98.90712022737719,-37.04631307841553,-37.60964080699385,-94.32970679831038,0 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark63(98.920806700497,-13.885365054099168,61.00852618241166,23.942971883542683,0 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark63(98.92649202805919,-28.51150319259584,4.592087308502897,-89.2840704374324,0 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark63(98.93212347830925,-44.55847742949231,-93.65075866127101,15.174891639156257,0 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark63(98.93861019627133,-31.22673165935501,27.138401302038446,73.92756007557401,0 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark63(98.94749298821819,-45.06431524152858,88.93994398322832,4.878642257099088,0 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark63(98.94984103722848,-59.30326338972905,94.52972285199817,48.04574978557261,0 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark63(98.95418514105202,-12.820649321202524,-79.56767911326945,-69.92962344490232,0 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark63(98.95522668808067,-43.63168332716174,-51.5487990610223,29.266910590256032,0 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark63(98.97681970801005,-52.820115371742915,-68.23593389455385,55.24381898462141,0 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark63(98.97765409169747,-61.0877449889667,71.2400143823264,-75.26348503153068,0 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark63(98.99152386396614,-59.918061247755496,66.41601944314087,-11.073083511440672,0 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark63(99.00998698551066,-14.854601780901916,81.48676024374674,8.879016545745657,0 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark63(99.02484838988403,-53.11699336219586,62.11116583765053,84.99390796730887,0 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark63(99.02628737721736,-85.32134405221245,-58.011866271604106,30.658245869137772,0 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark63(99.02724655759246,-55.19882645040013,39.30508873938652,-96.56602922992073,0 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark63(99.03331197772007,-88.90047355851615,-70.19680969397284,53.306561839404,0 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark63(99.0862229015435,-58.03106252093257,70.8844937477935,52.36432114774547,0 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark63(99.12390015621932,-77.33866946945122,-3.556621280140021,32.543297585070746,0 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark63(99.12632081375733,-56.885500267850134,-82.68845430854424,25.813522636259023,0 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark63(99.14133546149941,-52.240403125697284,-31.50843357241409,-55.86842384990307,0 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark63(99.1918756611455,-26.895512930139958,-68.43151752278153,76.71221826120836,0 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark63(9.919426065213273,-1.4720391302287084,94.43931763568202,84.19817863808586,0 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark63(99.23160832333167,-92.9694077268714,-53.22965089838545,-61.039407800296,0 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark63(99.23505744894248,-3.348827110540526,5.515588470940003,9.738232661253662,0 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark63(99.24233298115303,-55.70085084329976,-74.51054863332054,57.917748974987774,0 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark63(99.2475892411002,-95.0708701032722,-58.571878370617235,72.33053962620392,0 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark63(99.25776145898763,-59.93739232464523,-74.80484440692206,25.096386258017446,0 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark63(99.26790035562786,-41.2428093763316,-12.248319136255546,-16.386172109305463,0 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark63(99.2700053296048,-19.107295323938843,80.1305578807686,-4.7350800244426665,0 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark63(99.27117596107678,-32.8825890820512,58.77339387256728,-27.29355856047151,0 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark63(99.277831836417,-46.74753325689402,-64.84782147205901,-14.182943715753055,0 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark63(99.30528014278119,-4.411742492188367,13.280039512497169,53.20656762433808,0 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark63(99.31368068976732,-4.962194604653774,63.64197943634011,1.620779643538242,0 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark63(99.32741838041349,-77.57642898513689,72.02919517661797,53.302190652819775,0 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark63(99.32753263586747,-22.516545533021272,-86.64520752529761,5.090770591761128,0 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark63(99.32802580911903,-22.24694676729166,-79.56952561351436,60.08458327078361,0 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark63(99.34186635882861,-25.73673570270722,-42.77094843459419,-25.53448149304502,0 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark63(99.34744052118788,-53.72760008169575,-33.645087124233996,-60.90037093569451,0 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark63(99.37011248257784,-53.478492993607254,-81.31369060825818,-61.33988533473151,0 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark63(99.38435919389167,-31.012189774660115,-57.01699531151056,59.08140469040421,0 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark63(99.39001418651245,-59.2596240407121,63.53549299712998,-44.41207381148147,0 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark63(99.39636575221007,-23.17007963055255,42.57893029112839,91.50288302854753,0 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark63(99.4307824560407,-76.02280767257255,81.67998063636443,79.65670390807452,0 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark63(99.43146651594392,-26.458921141537743,-1.087919372178959,27.797068691052075,0 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark63(99.44000297911802,-2.619252601792482,80.11902667851882,83.60691330178898,0 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark63(99.4534847443359,-60.703009527531,63.61268033944768,-66.49238055263478,0 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark63(99.45371001710569,-32.51350133607008,-9.03457345738768,-74.91175242827033,0 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark63(99.45550633463583,-52.192059770478096,14.489559057647313,5.092503630733418,0 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark63(99.45639320307481,-21.241850207751042,-41.0633479073669,-15.76605780143727,0 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark63(99.46180973967546,-86.88181989998675,65.07461642582194,96.80079639564286,0 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark63(99.48811974173742,-3.8139023548844335,75.29076155221097,23.595196488518837,0 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark63(99.49617366035861,-9.71997326535552,-60.68018500476116,-68.52577544002081,0 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark63(99.50707840860284,-71.665087260224,-75.75946006826854,-25.188590771521845,0 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark63(99.51184772790018,-18.87198395129745,-90.77238014517579,-48.589609644822794,0 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark63(99.52245279306766,-62.620996768660774,-9.773261714747065,61.91561507696866,0 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark63(99.52504506814165,-75.457545440259,26.993754874086264,-65.26976897322254,0 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark63(99.55958552693139,-97.8495912457691,50.20858968041472,37.10323046969995,0 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark63(99.5845042874561,-97.8288777538416,-1.6346802127390987,89.89455477034326,0 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark63(99.5881824821171,-28.707370924160315,-4.797111209478189,-59.379457639227674,0 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark63(99.5933378023725,-42.54095835735365,-70.2625585939762,7.651118909777054,0 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark63(99.59472772069117,-12.443378074141734,41.09041477274374,-35.15147874392824,0 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark63(99.62174411720628,-54.459171931909054,-82.51173714316518,-80.22775826937216,0 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark63(99.62407026321486,-46.004146962079595,16.470161371198614,82.76064526725091,0 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark63(99.67512346755535,-82.67999173197826,-68.78514068066251,90.16870929055631,0 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark63(99.68010302305063,-53.220414154910436,-80.90977659772638,92.76637741309335,0 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark63(99.70657530980503,-85.63479492631221,-39.96855831840751,78.70504019863316,0 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark63(99.71409457922059,-11.014924687121791,70.32296601819348,64.12533463284694,0 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark63(99.73954182663417,-66.45713091970927,26.479131972034622,-65.54630268705918,0 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark63(99.76772691684255,-74.5003019256422,63.740510476099985,48.61226210905227,0 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark63(99.76888448335447,-43.089183091892316,74.08699730199157,-82.66531144993534,0 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark63(99.79262771068844,-61.69942128586254,47.26606640173466,40.76486811712249,0 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark63(99.81376035865412,-31.452798411499288,-57.56996871818221,-68.28786301068666,0 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark63(99.8265531371128,-75.31971052439623,-85.48977953383306,83.55170140128587,0 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark63(99.85864118452824,-3.6185559690115525,-13.86810839020525,-24.93946104631621,0 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark63(99.86375356067984,-65.94318542651949,-32.69463996459466,7.3645795656850765,0 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark63(99.87821028212647,-8.34695811535191,95.49193744601976,-81.15961564438038,0 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark63(99.88162216343616,-7.73256218795693,-5.779321475797957,-76.35756759350716,0 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark63(99.89634686455119,-40.53163972496843,-3.878152883075444,0.13918592212145597,0 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark63(99.89740079259826,-79.19627790001616,32.884105864822146,95.8137917787812,0 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark63(99.90150299934405,-58.35471947952704,59.25271536186992,63.925038518938294,0 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark63(99.9159833136076,-21.088322193978385,40.72959159260773,34.803229413256815,0 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark63(99.93852458984497,-49.11804461589215,-94.77264570852182,-54.3112709643353,0 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark63(99.95110034203546,-83.92702579540116,-38.57335245383937,19.467573032281862,0 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark63(99.96405905843505,55.27012809011035,4.793327673232724,-54.83268617135961,0 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark63(99.97342355269853,-11.986027272705499,13.576305979900923,-71.81351233104587,0 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark63(99.9773270510986,-4.4984753275243605,91.75917366408228,-90.93614587073489,0 ) ;
  }
}
