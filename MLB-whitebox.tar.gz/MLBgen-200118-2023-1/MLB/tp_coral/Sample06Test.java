import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
//    0.6793306999309466;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-0.052506930037083066,-33.89264971772381,-70.3482895163562 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-0.2618923269151878,40.38017086230238,-57.172130278104106 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark06(0.34705023523096656,85.92095181417591,27.110473368456184 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark06(0.40700503101172103,-99.15915331308337,-95.61175570180687 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark06(-0.46755172062596273,72.15420212684955,85.10350668492288 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark06(0.515905675403161,-96.7506729749912,81.01697145657681 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark06(-0.5704636364650147,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark06(-0.9050725744681927,31.2407285938084,35.17673634632129 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark06(-1.0218324653337472E-15,-0.5512304733070392,0.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark06(-10.28655955159941,-71.00455895391617,7.573243748458694 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark06(10.487323585383152,46.07226142223104,46.744468577638486 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark06(-1.055689876496255E-15,-1.5707963267948966,2.615622739739919 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark06(-1.0587911840678754E-22,-1.2365420770410367,-100.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark06(1.0712699198165566E-16,-1.570796326794892,-1.5707963267948966 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark06(10.765398504541793,46.77764773442456,-48.48826077027428 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark06(-1.0842021724855044E-19,-0.040024644902516976,56.471090370858406 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark06(1.0842021724855044E-19,-0.6393115150379117,-18.59052184638237 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark06(-1.0842021724855044E-19,-0.688163597091662,1.5707963267948966 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark06(1.0842021724855044E-19,-1.3792658625997947,100.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark06(1.0842021724855044E-19,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark06(1.0842021724855044E-19,-1.5707963267948966,17.474859856267614 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark06(-1.0842021724855044E-19,-39.23096045197817,-32.51366919987672 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark06(-10.925290356557738,-73.31119794106253,-30.154128664926333 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark06(10.992655820587345,-53.048982922110376,-67.31052913856423 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-1.253558895468805,0.9352966659569847 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-1.5707963267948966,1.5707963267948841 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-1.5707963267948966,79.04592849009802 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-1.5707963267948966,-88.10004004942739 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark06(-1.1375205008331675E-16,-1.1591345860269417,0.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark06(-1.15195942983147E-16,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark06(-1.1554025005182038E-16,-1.5707963267948966,3.247576713704973 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark06(11.658405850066316,-74.84244199124366,-42.56587393588429 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark06(1.1663859295828192E-13,-1.5632025519323984,164.95573335063563 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark06(-11.882645176202004,-62.6587120523046,-99.63564371032622 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark06(11.88636425418936,70.53340334998,82.90459229322758 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark06(11.901610066216776,71.97016602433513,-79.41071651442728 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark06(-12.096398259598786,48.70377982322941,-16.490310332151097 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark06(-1.232595164407831E-32,-31.959574466957918,83.842094970961 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark06(-1.232595164407831E-32,-45.43600210240035,0.2514139246429652 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark06(1.2621774483536189E-29,-1.5707963267948966,-38.515715161405595 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark06(-12.673496795557185,-91.14212343958543,60.33301210062007 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark06(-1.267994807713993E-13,-45.41199735793492,-54.81366143603725 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark06(-12.779933787064323,-61.87629979450946,-22.93610812099874 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark06(-1.279588348912867,75.1442718689575,56.882257638790094 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark06(-1.2818893323174672E-17,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark06(12.856561592719444,-25.125783120270896,8.477476974393312 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark06(-1.287576747202897E-15,-1.5707963267948912,-70.79328665043431 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark06(-1.2941633369271116E-16,-1.1094263617257292,-3.8826111010949282 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark06(-13.04359840384555,80.18619589820227,-81.49573916390173 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark06(-1.3234889800848443E-23,-1.5707963267948966,1.1673218749878334 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark06(1.3262738094853148,-87.77666059288067,-12.930304183964921 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark06(1.3388967829292255,-35.63622145546188,75.83750757867992 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark06(-13.480623111845503,-98.77542694948811,40.965470149430956 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark06(-1.3552527156068805E-20,-1.3470627287383472,-100.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark06(-1.3552527156068805E-20,-1.5707963267948912,88.51673570817982 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark06(-1.3552527156068805E-20,-1.5707963267948966,-0.48919106137529 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark06(-1.3552527156068805E-20,-1.5707963267948966,-0.9360160211216595 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark06(1.3552527156068805E-20,-1.5707963267948966,10.69426722577688 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark06(-1.3552527156068805E-20,-1.5707963267948966,9.263179872494874 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark06(1.3552527156068805E-20,-94.31016150638693,60.162737355497484 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark06(13.849639825124598,6.329987070656969,-81.64421915567495 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-0.007198825388149938,0.0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-1.5707963267948966,28.88990140983455 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-1.5707963267948966,32.524794844857375 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-1.5707963267948966,-38.48996832555538 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-1.5707963267948966,9.74194004012679 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-88.34223211396339,-70.84507247884635 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-88.42160961697249,-53.769063533238636 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark06(14.163516922035768,-66.65330440607485,-33.78417328031817 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark06(-1.4252534410703985E-16,-88.38415380396845,32.98027353146034 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark06(-1.4491155933724813E-15,-1.5707963267948966,-41.41356343633575 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark06(1.452727987649453E-14,-1.5585281826360418,-4.184915335835935 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark06(-14.55953944810733,-75.45150562058936,-6.4064354333862354 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark06(-14.751109285896831,-10.11481542562791,-38.91782820375944 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark06(-1.4795903122428537E-16,-0.0639185410615575,-86.76021731945957 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark06(-15.253496446210903,63.021332379554025,-21.02893707290812 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark06(-15.299042336911995,-99.18982845448316,87.17366793851096 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark06(-1.5529216692986915E-7,-1.5708920480951878,-145.02749379663217 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark06(-15.598466463648663,39.25375671166299,31.944114822085567 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark06(-1.5697190468996753,-227.76546738428226,-0.036111326642476405 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark06(-1.5697305794234673,-1.5707963267948963,-127.987726588616 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark06(-1.570779934944371,-31.416512891876494,-121.13803171630289 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707859403178206,-31.54137870855442,-143.07975162823976 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707885751380488,2.7766556579517787E-9,-100.8888456032862 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707894114371432,-0.5153309875826895,136.65875078616835 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707898664867246,5.141603097276317,136.31245541906478 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707924893413379,-5.504478884008336E-8,184.95728797813405 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707926414451594,5.141592653590431,-171.76560877913667 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796110342058,-1.1091985718008743,510.6713472466296 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707961453834791,-100.53097142126936,-134.60930136727717 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962901567292,-31.547958140221127,-1.5747740791717735 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796324358788,6.713403791099989,-148.72328428126278 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963253138164,-100.95130504482528,1.4270310800923465 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267213556,-0.5707358843143272,-0.2251633308023632 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267515845,-102.09179790501459,-100.80319941293403 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267685938,-0.5626074935383142,-1.5707963267948983 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267916811,-101.6322086845091,-101.17062958963356 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326793488,-101.89086431650999,-32.65454355592807 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326793807,-19.38008036414594,-142.83469862366607 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267939273,-0.8402807498542355,44.559055862655086 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267945129,-157.51644578334782,9.407651588684554E-4 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946394,-95.34862258770534,-178.90383550215384 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947838,25.13274122871904,-74.16845061899132 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948435,-88.37223250036303,-100.77176238140089 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948495,6.712388980386397,-7.729269327117923E-9 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948541,-1.5707963267948972,-125.52286463810908 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948557,-32.81009200768279,-2353.0757784266552 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948866,-1.5707963267948966,0.05732283125444713 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-1.5707963267447875,1.5707963267948966 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948886,-8.881784197001252E-16,23.14345575463399 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948888,-101.94425413355985,-152.83310139993552 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948892,-1.3739754026643995,191.5229164476869 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948906,-0.7529271413535756,184.65891524410932 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.0715024305679181,23.968702500122106 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.10383332129739493,10.612078399827059 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.32679256785452343,-1.5707963267948966 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.8603202086486057,-31.658122131885392 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-101.9008128280179,3.1415927823224883 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.216437732709096,2.220446049250313E-16 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.2770842006542733,78.87305525506565 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.4158697222455316,-357.57066351933827 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-18.79116741843842 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,2.6492219185882823E-16 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-85.07943952668448 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-8.612671843173112 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-9.478644380685196 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948983,31.497186595989746 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948983,42.580664881107495 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948983,84.5936613960049 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-157.34867516047288,181.64079912042962 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.8375259586718823E-12,123.6708244348761 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.51097574772418,43.96204116292155 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.1548354760627,-100.0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.464787992435944,-3.1415926535897953 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,6.7123889804079795,-181.0522015149856 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.40055178712569,1.5707963267948983 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948917,-1.5707963267948957,-31.415938821725877 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948917,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948923,-101.92830407598228,-1.5707963267948983 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948923,-1.5707963267948966,-856.0763633642331 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-1.5689022949279166,-61.85202381975273 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-1.5707963267948948,-23.89488468735898 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-164.53996955859034,-1.5707963267948983 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948937,-1.5707963267948966,-20.57169338661421 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948941,-1.5707963267948943,-1.5707963267948966 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948941,-1.5707963267948966,56.872886096187564 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948943,-45.55309347672114,53.007980174102876 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948946,-1.5707963267948963,-3.272786712253174E-4 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.22145088935190418,2422.139362046925 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.29558897026520903,0.39748810017153874 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.64585266719991,-11.607650673271237 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.7445696333979606,-572.5083635565719 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.3093704088494615,2.7964418024657482 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948912,-36.96560378195818 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948912,-95.64837393435613 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948948,77.84449192362695 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-1.1325965454941045 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-23.340275225722266 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,24.959323036979875 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,25.392214626808528 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,30.99679741504662 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-4.71245002841678 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-73.34572069331998 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-87.72791297364077 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948983,-22.209469859544154 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267949019,-100.0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.41592653606415,1.5707963267949066 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.653604450896367,-100.0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-3.552713678800501E-15,19.37323338152813 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-38.792861300605615,2.837820525643764 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-43.982972815360505,-135.07629681600886 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.04548532303896,-57.04857514640631 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.44595687995614,-1.5707963267948966 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.54860041096465,-59.84158496495356 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.55216518402271,-0.7546126966258684 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-1.5707963267948957,-80.25142784736151 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-1.5707963267948983,-49.644735250856485 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-157.60110833429462,8.454677678665622 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-89.94133276581901,1.5707963267948966 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-31.41592653590626,-9.077154945797528 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707963267948963,-33.57524500800374 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707963267948966,-66.08338786878817 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707963267948974,9.6259494445285 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-31.41592653604022,-0.6659473633893561 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.5798952501107344,43.169063189875374 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.1111107523651076,1.5707963267948966 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.268757031908418,19.972733005703546 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963260213398,46.00377486959123 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948963,-64.40314773051986 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,89.17069015934656 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948983,1.5707963267948983 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948983,32.967345324506084 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-19.34990601156133,-91.84424270540333 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-39.092627975288494,-2423.698046112205 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-44.41630638071181,-85.66612549665889 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.0931302972337707,-1.5707963267948983 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.8739205498754199,1.5707963267948966 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-100.85909539551254,-1.5707911858041705 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.1102230246251565E-16,5.212388980731391 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.3487576058787138,53.31203906810793 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5257341660890076E-15,55.71329229771385 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948961,10.889465147005769 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-45.82003311548169 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-69.17416138411875 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948974,1.5707963267948963 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.9055322168347075E-9,-163.41886453998043 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-32.559023697548945,1.5717728900097352 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.570796320805873,10.82535759955843 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,15.707963267949292 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,95.66842915371993 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-8.103981634233577,33.121267548425664 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-89.8852888366763,-1.5707963267948966 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.034707023361216116,-135.09163190207624 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.3745918546269449,-1.5707963267948966 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5392438860813622,-3.2665926536779635 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.570421237124292,342.4335976588502 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-179.61576020835122 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-95.43485777303619 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948983,81.5299960186502 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-157.56381365143147,-60.20812424135978 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-157.6443431145618,-1.6501173704826897 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-32.82207008459338,-96.69838928495702 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-44.01646934700289,-60.93598567726474 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-45.53980449799387,0.0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,6.712388980384691,-100.0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,6.712388980384691,82.99213775859371 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-88.22566769018025,-1.5707963267948983 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0.0,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0010890415065050313,41.0476372013714 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0011843663331387172,16.779116835317723 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.001303592783196254,334.57591226087413 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0013193188079364641,-0.24853451745024913 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0023522482970382824,33.42756519339369 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.002764135932608033,99.89034549720152 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0029413867313471337,31.785259663714562 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0030918810564096078,43.47213697609013 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0.003752053256067673,-29.957011999621443 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0038346719970793544,-53.88385052364337 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.003907948764990454,53.15402147007588 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.004839680555717292,-0.32443978156139774 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0050474582200440675,56.548667764616276 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.005709007196829445,78.41267356978997 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.006321148841964197,4.1281588705399436E-8 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.006379179661853057,-19.349566907263394 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.007533576677972558,-0.16159503610526663 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.007541394725691219,28.019091844984928 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.009383620191395067,-1.5707963267948966 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.00962703253365856,-41.27879792578102 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.00978076500195106,-97.50173943495591 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.01194664779816607,45.0161753621563 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0.013314114852921808,-52.23867451550784 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.014557279545074244,62.83185307179586 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.01489025989818616,1.5750032094299948 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.01702487790076563,-14.281715831936765 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.017090103805984802,100.0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.017513751320101086,72.15357530790351 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.017852881308278376,-6.917841334875561 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.01824960605937606,-1.5707963267948983 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.018358008137318624,1.5707963267948966 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.01852986749329664,-99.6992854899463 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.01998825086073419,44.18976743259081 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0209029854782697,66.18355521431303 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.020910704532084972,-93.31858088763008 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0214523266116632,-1.570796326794896 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.02237839909874709,-52.656315026998556 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.022886632348352875,-1.5707963267948966 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.02318573584065426,10.484847236374245 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.024517141205633745,-1.570796326794897 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.025216979960451667,-80.87355865952496 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.027924003571632744,2.465190328815662E-32 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.03203597548192816,-73.56272536549099 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.032066403290989275,-1.5707963267948966 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.032154503806154894,83.67746632686996 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.033094499552929806,-9.731825132080271 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.03353538560881299,2.5707962502143613 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.03429997136148111,-100.0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.034339227073622226,-1.570796326794897 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.034535267843869254,-40.17140642611532 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.038368861830097814,13.344937653968254 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.040742670328875796,-1.608611746708759E-86 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.04297571725847016,-3.1415926535897922 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.04606646347350442,4.849722774825433 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.04639496758435291,-4.712450015541119 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.046758423925157847,40.70527838942127 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.04788410399661967,-30.657266976520738 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.048838523987838486,2.6745290937382347 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.050786686806818686,-1.7587943013779788 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.05273575025680666,-467.7395266605436 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.05466059867271208,1.5217520915780962 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.05548290967039452,11.646817143190995 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.05894511084722143,-0.6716356716375316 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.05956541571910676,4.712397514329895 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.06005921351705838,74.29648124558719 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.06265875249203072,0.4222031605585138 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.06801668124816022,10.967674236190158 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.06944421062038886,-87.07177081003204 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.06972494084966954,58.99376005518916 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0765404028801716,2279.9948737264367 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.07720434318533828,-1.1355755072144143E-13 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.07753716010855022,6.561566954209923 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.07796562376256305,-43.69636493055442 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.07798734536151164,1.5707963267948966 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.08035387856563422,-67.04465711762337 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.08142054834246977,-0.5706423090645012 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0823044425780417,-90.9336097462972 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.08483093160046568,19.33872227912829 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.08615171642732489,71.73572649094999 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.08678833094849003,-16.669118923299326 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0879670173031567,-41.70468943410751 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.08933822589993516,74.87116171241087 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.09023827677156028,-22.32740400744231 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.090252217097352,-72.35301851182108 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.09208323161453777,1.5707963267948961 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.09258540387473588,-4.714346031491282 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.09685769821912751,39.640989716349 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0971109937208477,-4.714342202895735 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0974375206321918,67.0240843731361 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0981373165014884,51.46303075792213 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.0998147102276213,37.50049123354165 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.10389550966359332,-57.378245654754046 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.10525770312497944,-71.4205001800112 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.10711206388195056,52.490670176755955 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.10789551131785215,-56.55473906718276 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.10816256948641012,67.16007616914183 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.10930278218437983,-112.60268130706145 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.11096593882990632,-60.26621151535037 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.11156983707329715,89.00309580167733 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.11370176331163712,0.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.11452034590404664,1.4057731680498815 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.11542720679102159,38.14077543302772 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.11543413348912246,81.69614583812461 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1167081936847949,-53.28448721229325 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.11821648081324009,-38.25708967245563 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.11957545677537951,-948.3898666634901 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.12000366985272527,1.5707963267948968 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.12051316394125866,67.35174834418717 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0.12067207740491692,92.34599546644745 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.12272187911550725,0.0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.12719466273029556,78.3209015349357 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.13247842841884339,4.128526522334493 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1333425561479078,-24.484855259902243 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.13462869697144111,42.73537553822603 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.13561301010434018,38.12449083961667 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.13613002163371565,100.0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1367683224660068,-38.91099168957249 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.13717041223885484,-0.26988537929263434 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1376130322109903,-78.13927308238628 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1383744913853745,20.833177702948902 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1386093243917701,-55.467938893165005 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.13929475606490724,9.42477834452117 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1397427427322493,100.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.14323913337472582,-12.01674783632225 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.14463699537478358,20.124882496594893 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0.14463848395274626,22.565540195074647 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1453132489560005,-77.27737644705147 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1460551462154976,1.570800040048401 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.14813312226476347,-1.5707963267948966 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1492728267709307,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.15008128468726423,-18.133628422426018 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.15129416582737718,44.3726715983683 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.15291398763528355,3.1415929991986546 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.15428952834502024,99.74752684729276 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.15805939291226356,0.0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.16377886955727797,33.985344362242614 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1659011558501245,0.0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1677089720655207,30.109350100155364 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.16893250512032404,-21.064030537581246 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.17015683395849757,4.6784802883122225 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.17309471651852532,-3.1415926535897967 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.17465202983652972,69.51144718590791 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.17481355443329794,66.43195870602435 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.17512300194843744,-71.3045249068237 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.17620595948216078,-0.6237376007612182 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.17935994181210857,-88.53688499302244 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.17969606496863091,-1.5707963267948966 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.17979172887091155,65.16512029753139 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1811950375157848,-110.70748101210677 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1817645843255659,3.8736067906130365 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.18388287494223965,-59.641665741537665 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.18682392541687165,1.5707963267948966 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1882154873087809,-73.9027440434041 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.1934044034521678,-73.93884953164817 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.19568198941716775,-86.47030881271421 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.19629416140371905,-28.969122939696447 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.19726734099329435,1072.0421031624674 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.20544020346729322,73.57176612430806 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2109580156572159,3.1415926535897967 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.21225835418371974,-52.62498384991581 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.21561677118698694,0.0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.21761382653992162,94.39305328452818 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.22216894084140507,99.09184808333335 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0.2257203597277734,100.0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.22648375494759593,3.8184626927892964 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2264928252784031,0.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2292016088731747,3.538527404272214 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.23086751889809123,1.5719057590489152 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.23478026120279513,1.5707963267948966 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.23597391591303207,42.57506672446087 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.23637131088087537,117.08531585415409 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2418488616418064,-3.267338029272149 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.24373572156199083,-4.743638980384691 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.24786529787960232,34.72508996569232 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.24787972689981436,31.455754410558782 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.24915017153732885,690.6986188861745 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2498647631075282,1.5707963267948968 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.25284054747730283,88.1808227369126 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2550767311699454,0.0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2581093783049335,1.5707963267948966 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2619583918440058,-0.7403903635012047 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.26393732892700233,-22.477606421306206 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2698831316178794,0.9359083894706297 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2723555422628231,16.612825275215393 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.27317818024485424,53.834576566978626 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2736548583959866,3.141592653589793 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.274894314363344,-15.744571900835538 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.27733408058482123,-19.278887159509562 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2787185020824392,1.5707963267948983 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2827455847634184,-1.5707963267948966 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2846744543581059,1.3458400899446277 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2859630826878927,-3.490728885671501 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2860082254706917,-85.75160512351354 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2863026709796806,54.22143595769552 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.2872837036325505,-1.5707963267948966 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.28805126058645125,1.5707963267951577 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.29264211137244944,-34.67679509362844 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.29267994558325217,0.0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.3021325594463686,-1.5707973664344377 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.303216493190512,-31.549861979225323 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.30345162854110086,3.141592653589794 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.3068533868435135,-66.4661291801688 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.31022652673540974,73.58655030009764 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.3120322333059197,1.2369445758407278 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.3135124576941144,20.454317610504674 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.31550015295492173,-53.8373853488219 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.3179850798221592,-39.20828328585171 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.31938760890280804,-1.5707963267948963 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.32309065040361395,-85.66119909462368 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.32547851224433944,-6.289976644112855 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0.3276270500759567,1.5707963267948966 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.32849207055502855,39.24305699922999 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.32888904189622564,27.27407799182042 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.32916518103236947,1.5707963267948966 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.32926181546996525,83.70507376995181 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.3294280818764928,-6.1947900237943685 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.33779340450253303,0.0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.3428536796538797,68.70384163297595 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.34338323890502376,-2275.7944635654558 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.34504564290291534,-67.40966986339205 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.35429629698064247,-11.786361517803968 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.3710182657430283,9.995574287566036 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.373088118022386,19.384431562000117 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.3746466321864745,1.5707963267948963 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.38036041236635465,124.34584290093659 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.3822753981997381,-72.70891733706915 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.3849719266543812,68.44684264150855 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.38745869278922274,56.392940126238116 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.3875001467739219,13.63416681865499 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.39658437622844,-1.5707963267948966 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.39674892606926615,-126.36663963590345 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4001432145989412,44.057111310118266 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4013785725188856,1.5707963267948966 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4048769993426275,-59.59144130066921 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4057880895283963,89.11419802581027 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4066297217851921,51.740266642460405 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4071304218626881,0.9821102848576881 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.40903459614272014,-6.2831853077 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4118983198229291,8.881784197001252E-16 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4137141934050896,0.0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4150609070675776,-99.57065152041551 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4180742364195064,1.5707963267948966 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4194868863260756,-39.775474903657184 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.42421177141033456,-1.056861965053663E-16 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4260307537460809,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.43116039568055775,3.1415926535897936 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.43338268917534384,-82.81379095127738 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4345118346041802,-50.667209137024315 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.43880014191398287,58.64246883811282 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.44327156359391673,-5.697479059468549 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4444486280991808,32.65273894126706 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.44952725261915233,4.209535821754037 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4525151203609912,1.5707963267948974 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0.45543176847720473,-93.62779917874522 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4572044711813803,-25.291625616142085 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.45745295160761035,-44.44716190756059 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4592769303103235,-10.622400832825827 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4642420910310868,-84.62487719818213 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.46831521255005204,-1.5707963267948977 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4700816938586786,67.18635004556121 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4703610625597231,50.03295606424831 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.47176933033617274,-18.425462596310005 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.47244309006272994,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4778399562558435,3.20783085544538 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.47882513362840484,153.18811857125976 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.48135272792728534,3.4735557509863285E-15 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4832757949520418,-1.5707963267948966 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4835750788630951,-98.95791935486437 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4840355944493072,9.642372774195879 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.48653105703146293,-1.570796326794898 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.48988356130104593,-1.5707963267948966 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4903438582977018,27.182072497926995 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.49045711870143727,-61.56429240383978 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.49228706244609055,-60.934148379568114 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.49494763323068514,-39.89345846349449 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.495551417170936,-84.25547969077643 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4968546558517265,-4.714342113964167 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.4995245720586449,-71.00276193014766 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5012554629495992,75.52229088116007 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5028194142650704,-5.28187916197923 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5031090455884424,31.903030572965527 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5039057010594001,-37.90820046447078 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5043943770784616,1.8810390481340635 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5060587258543523,1.052270915076469E-6 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5066091703260683,14.444377770491993 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5088589497920162,2.254591452197019 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5089040294280958,52.05220014363099 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5112782219690056,-4.743638980766878 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5138060971672167,-8.470329472543003E-22 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5187716888477161,0.0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5219248999444845,44.3681013267963 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5224350327931623,64.94070645927947 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5252367526970004,-96.75377198713689 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5266458285069449,95.39808405610319 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.539597619282727,-17.27414414573655 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5413754441117019,-84.38694607546378 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.543883264951549,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5439282932382926,-69.65491959259616 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5443956388091484,29.190134416197118 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5494466206224784,73.53017863063988 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5496049795328437,23.67888889513381 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5523953332995707,-58.64040286757562 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5533646762722401,67.28977162781968 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5534796811009864,32.49045505243144 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5549514722608939,91.63898726628145 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5572515772267348,-3.1415926535897936 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5623047103784703,-94.74485724215181 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5637355739109917,-67.27822750754726 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5691160402495389,45.04776849662656 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5705102536495313,72.37727061946435 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.570659712903904,95.36612181795782 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.570747135529393,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5710028178980623,-1.5707963267948983 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5719093856734698,69.35426026750203 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5724321623673418,18.663318155179205 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5725427291983545,3.141592653589793 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5815675050132874,-1.4412623485433966 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5825999218454183,579.599342070088 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5858501656835102,58.25070484590969 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5861657276365708,21.198463546671164 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.59730322902697,16.41740935716588 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5976412571289147,-71.19366673582718 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.5977955070410953,-2.493949115043229 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6015032311106552,12.7544853491097 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6062330895964164,-22.54851123413637 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6070705729691255,-1.5707963267948948 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6075985531001331,-1.5707963267948992 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6100292760898641,-1.5707940605660105 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6114291653348427,3.1415914699376764 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.614805509600431,34.55751918948773 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6151721614120406,0.0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6156017686451977,8.280918994786028 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6230146226563994,81.34883719782917 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6248865313631462,-32.783694209843034 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6257832759256803,21.94154860756523 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6260594236861862,39.420381883494514 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6284948122158056,-6.879996360295237 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6314061672967952,-2.511308524381114 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6320051572387794,-0.9359308474360736 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.634655678273548,-129.83125694537065 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6386772222636853,-81.26526397478298 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.639285492202653,15.32735290035642 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6395342969150317,0.0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6469832254586834,89.21068931092056 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6482255500930642,-57.52360527771217 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6484925313585286,-15.707963267948967 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.648789790560338,-45.67507139874124 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6488149303674385,25.999696027041686 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6509882317788565,58.37555085052185 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6560932901461091,-1.1789042235511697 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6575086255145415,-15.648153965475984 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.658849647475244,8.417547578491584 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6597311530739022,-10.492568634804691 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6611651170727937,-6.712389370977584 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6629969193479432,-9.575628028442978 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6633730371655631,43.982297150257104 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6682831091001016,-50.485411305514404 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6702488241912512,-64.68528676482316 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6718834076195241,23.434811734348344 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.67624035095075,45.41596608282008 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6764437732853604,-36.53003039754288 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.6831447061637288,56.69214090667442 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.695750361956371,557.9811624872688 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.69906967779337,-32.18232823673137 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.701213961875895,43.43443489948006 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7082098775740718,37.16458034099779 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7105132927805108,49.99646151215834 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7136287395116767,39.04463635492553 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7151894211297218,-1.5707963267948966 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7168597906590434,71.64503735768704 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7183614524171138,-69.85586295589556 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7265489206433208,-1.5707963267948966 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7299722902340637,0.44544869674265897 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7308657838995885,1.5707963267948966 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7309243481240877,127.28113656489555 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7360364031960123,-74.5897240043269 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7361911644514478,51.93082263789168 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7362582722510642,1.5707963267948974 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.737262910566654,-0.41677524254086423 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7453938286376107,9.779635796543499 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7455896090781702,13.748700621050205 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7494688649580463,1.5707963267948974 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7494688649580471,1.5707963267948966 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7531241767007415,58.34220784732003 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7550092685891907,-329.84245901563827 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7572879554207788,11.227793046523976 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7602179908894495,-1.5707963267948966 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7613246415371862,-136.57584593748732 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7647069750271472,-10.685511029003175 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7647822986007898,37.742443384801696 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7696334260620187,-48.18831884493717 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7722468665932335,-98.18162045162313 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7752885588691186,-1.5707963267948966 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.781235774776441,3.141592722748519 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7832465949746562,-20.380825060552567 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7844065755127023,-5.666171683235731 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.784735499862555,-12.068671409781617 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7854569092412726,100.70930280893819 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7875923034147098,-3.141592653589793 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7877515674869466,-70.87678563282874 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7886690001817346,99.61658777378867 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7900286024123064,-5.882705547116544 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7911241821970534,3.266592965310899 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7911974700869094,-20.352656711701073 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7925192170501282,-41.748903880282185 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7936787873508658,2.465190328815662E-32 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.7977901854332601,-3.2665926535898215 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.799668817125759,66.45501523127862 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.800214207983549,1.6582110732041517 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8004957216187936,56.548667764616276 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8129418130564527,78.23559993738044 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8136627585690414,1.5707963267948966 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8159982162692485,1.5707963267948963 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8197546576330185,-6.88276828469908 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8199322713083238,-4.5522099189454387E-159 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8280216725558793,9.653470683681421 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8363336421777398,3.2665926535908554 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8372399795065393,1.2947965616824575 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8401613998499278,3.141593452678792 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8410314403846293,-3.868266973333493 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.842797466550631,-14.726109456157772 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8447255714701034,-25.39020757303483 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8448168594637888,538.7817658897787 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8463310841216901,1.570796276568904 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8476875377700819,6.283185307179586 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.851934634391025,-86.70940322094313 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8624036211211612,53.93625643300395 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8640200397051727,-1.5747025790061797 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8653378628536643,17.443760360109536 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8709641105631785,4.309812971821037 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8713083704057203,-3.141592914965942 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8747804524897509,-18.444356484569273 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8826182729792533,1.5707963267948957 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8867528947512224,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0.8872348290681068,-1.5707963267948966 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8872884497329246,-4.155262971910858 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8873490195255308,100.0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8881921273363506,31.41593779780222 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8884305811725117,-87.94202614750624 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8900064710600146,168.92477787717328 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.8963130014475653,-44.65391878194583 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9025043241998052,22.089912643709354 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9039857540622702,-0.47839406387964717 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9069692448610188,-55.606681017873875 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9084776312523762,39.08911715154257 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9089465796706622,-8.33306601245878 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9110057956384536,39.35769033659932 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.913656705427881,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9149711882320903,56.548667764616276 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9159970707203394,48.29400867387796 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.916566588036777,72.25762893842034 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9208395422679279,-91.75395310110044 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9214512301305895,21.96631319174426 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9219152670095183,-78.14766124126265 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9237265007272908,0.0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9317802666870634,-59.41964850680668 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9381468919215887,-90.44184575190297 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9403338418232989,67.61535484540492 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9540788405939358,103.56558004591054 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9564432766811948,-67.56138090899745 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9648245865034001,-1.5707963267948966 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9666584225791282,0.3004344724026424 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9668953168527301,51.592160127371365 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9691315497006797,-9.270296707881284 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9700270688510493,151.7231161957344 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9782988545893563,1.5707963267948966 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9787756129113054,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9806639822536442,47.01691923534955 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9819729056378222,1.5707963267948963 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9842017484774428,-5.206584785022509 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9842315868582859,-3.156649674923121 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9865400599389571,-3.141592653589796 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.988393714592112,7.7167110948039355 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9894957736645287,0.0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.990161944320183,93.50205050375459 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9913527003189401,-0.23033717854725339 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9970801897400084,-72.73773722581296 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-0.9993431907478152,-1.1505837217593262 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.000258592249471,59.61821027394623 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0010415475915505E-146,47.82249290049313 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-100.53097775403182,1.5707963267948966 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-100.81754015189222,-43.87309580697952 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-100.87825037503148,-32.63841230512361 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-101.09569253908316,-61.02136885533748 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0156255785241979,99.34265697365545 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0162268645943513,-66.88038201118903 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-101.69058522031351,-39.45678154378738 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-101.73339271411818,-0.9058524039048343 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-101.76720919923832,1.5707963267948966 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-101.84434875167406,-47.1238898038469 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-101.90704470926231,0.005448890457954474 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-101.91121523324553,-1.5707963267949054 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-101.9749099168196,-8.775504771742789 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0200174038743626E-15,38.72662413628469 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-102.09746881425424,1.5707963267948966 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-102.1017611513237,-1.5707963267948983 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.022791511977129,-4.712866625282516 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.02283870087384,8.673617379884035E-19 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0230043593342488,691.1257485552006 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0232878483713446,-87.09364950658409 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0250665447337477E-143,-50.103705384600666 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0258880809765831E-15,-57.52470400466303 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0317587652242863,58.39892965179988 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0349499164975684,39.40224390040922 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0406904001664534,-12.131669543116672 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0414622317408295,-1.5707963267949019 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0415153656565,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.046267529568111,-94.51705332835643 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0483462589797363,-41.944735022198685 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0502148182334077,1.5707963267948966 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0529946061624131,-1.5707963267948948 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.053535375996037,1.5707963267948966 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0541180008133122,-4.712633122087515 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0542018485159745,-48.220924296197744 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0547148347917101,60.7935636443802 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0551969356590678,-1.0047662260987854E-17 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.058609239240634,43.16925483569334 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.0587911840678754E-22,-7.21046066829912 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0613197034999419E-13,58.76286784862512 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0641360285617303,1.5707963267948966 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0644436881634332,-1.5707963267948966 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0645118228145796,1.5707963267948966 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0646737232830854,93.39020840060284 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0652750522307033,-21.250059580383773 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0657184921610441E-7,-16.209887617111743 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.06704549719899,0.30625882048220876 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0696218109529114,5.998787255582524E-241 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0708708055283283,36.52791872489232 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0715675430965188,-41.46111118467735 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0722433613102038,-82.69613906337925 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0729018852851482,12.566370614359172 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0765932046668785,-90.67553673438233 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0782822692389744E-14,0.0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0788333730307296,59.98608707831624 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0814294252227223,13.643064058764608 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0826738478267087E-11,72.2567357380892 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.084105053201204,67.79800716303254 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0865775415221381,4.714342105444799 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0874147800038358,3.141592653589793 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0875941052617755,-9.74324057988748 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.091011597999437,-3.141592709048809 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.0926472978668032E-16,0.0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0942998287421475,28.431636293706013 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0956704381609503,-66.5836621644911 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0959633998178513,71.19603615720658 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.097067399571685,31.44696178338456 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.0970771936668107,1.5707963267948974 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1000777405628346,39.357694373173366 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1012282820379402,37.93037707969483 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1013767496818074,0.0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1050516317467716,64.16398648036085 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.107697230280266,-72.68478768795563 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1102230246251565E-16,1.5707963267949054 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.1102230246251565E-16,44.547588331349644 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.1102230246251565E-16,47.2484098564309 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1102230246251565E-16,-80.9832584004913 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1146307873775876,-21.984625568230296 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1156903822104138,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1160154279545234,9.171474709597476 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1167153919310397,-31.416072261206548 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1211483702128884,-3.266592653617369 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.121541523112262,5.212411654842699 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.122415005912547,-4.712450015596776 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.122573365234325,-61.66690633543858 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1228071978734537,87.04687487183816 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1263080364626879E-15,100.0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1270725851789228E-131,0.06779037064886495 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1279658701148776,0.0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1293870907019226,7.86179421270135 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1298230624062964,1.5707963267948966 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1334799657385093,143.21655427401606 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1353231046082253,-27.397274178599517 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1361514293865864,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.13681882001634,34.94954761347668 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1409788272246217,24.10998592343974 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1439386971872914,8.575405472893706 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1450147025167179,1.5707963267948966 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1486018511311866,72.84225822098458 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1537468699520608E-15,8.41887983978937 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.155897046131555,-193.2044834446856 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1588433635275204,56.04635401991388 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.159055836321362,-4.712633144353502 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.174402108496171,-44.11696629986699 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1756662880967332,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.178512463317721E-13,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.179422258196341,1.5707963267948966 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.182230256245961,66.33184554311336 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.183115628344042,-1.5707962791974643 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.183904359990923,30.989410855762614 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1850339568260084,-13.381850318974784 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1878076150076602,51.36989017447706 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1890490571258565,1.5707963267948983 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1915269124299925,12.121170032183176 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1938399043563863,-1.5707963267948966 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.195128058008545,-48.30953628108646 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.1974598062654807,32.95653224795086 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2002407190456155,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2056543505178572,88.47270858856794 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2069433644652623,89.97408680529993 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2101015362387577,-32.10283947300026 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2103840889135813,1.5707963267955982 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2133938373162492,-4.6049867239538145 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2197192299590072,0.0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.223631718426157,-24.00625871928836 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2251496544092046,-0.4220663990292972 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2254950949885062,33.22619297844119 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2308181737014798,549.291522282464 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2315512533389144,-119.57968610416506 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2338789709326767E-178,32.73369225706533 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2343220350141257,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2359473059475623,-68.39297877917292 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2390703823278078,-1.574707372764166 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2392125608047477,-66.90147299819714 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2399792318883354,-8.104009940832261 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2417224538213034,-90.65647101307184 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2454725473356731,42.83223508622399 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.245899368887196E-206,20.20579606003205 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2462100945721488,0.0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2471075721189215,21.44892081148492 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.247215504407235,89.00679888304742 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2487186862411008,66.17991278286425 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2488104840421006,28.70353757305703 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2489579852942128,-3.141592653589793 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2543765336767325,13.766353397968812 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2552081170769802,-17.279247876027412 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.255308456945685,1.570796326794898 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.256727927116218E-88,-1.5707963267948966 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2568342807053914,-41.45631857493116 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2590033901163955,95.44126856074799 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2591654515364097,-80.7275017426542 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2611726994456707,30.3871129073392 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.262107898843734,-184.5437863831804 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2625735436760135,23.56975740192534 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2634920662350609E-175,1.5707963267948966 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.267506538433349,-1.5707963267948966 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2677574607144309,62.83185307179586 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2691809650674886,6.712389024853286 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2693085880673936,-100.0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2695135470277296E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2728114472076653,-4.712396609872162 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2742767994905326,1.5707963267948983 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2788705657454034,36.17479922002446 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2805484833409355,100.0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.28290975545515,3.209522066925741 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2872894832631752,-1.5707963267948968 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2885581469838658,-30.45873063118154 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.294923690017442,-82.79653082664915 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.297379001006003,-1.5707963267948961 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2978106333548616,-92.79401242814865 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.2984298982334845,-3.141592653592046 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3003298423802634,-52.03144698496234 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3004370204368285,-80.60818090313445 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.301278611719542,29.821582983266484 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.303265364544815,51.11031521665633 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3033946065034705,4.712633122647107 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3047300394122525,-68.84018713203282 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.306840310970175,-2.669028136728045 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3104206737124338,2.0707963267952083 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3117639997242319,-40.77871194352311 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.315139107170154,44.13138443695806 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.321967610237784,-839.1425154477124 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3222925160169074,-4.61396283856314 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.3234889800848443E-23,-39.63212071280788 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.3234889800848443E-23,-73.69989611209766 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3243115778695544,-40.58263446315187 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3244052435708762,3.266592734631168 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.326971123354103,-24.964483838918426 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3318416409086893,6.712390938792007 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3364037343957191,-69.22018949522314 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3394432648859569,-1.5707963267948974 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3398212127437934,-37.889039808273765 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3399184430655404,-9.37689674318365 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.341500310545273,-0.3661564845944273 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.346707682244638,3.1415926535897936 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3518294713153742,-78.41857355987503 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3520970916381883,1.5707963267948966 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.352565742314738,-87.18206047611818 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.3552527156068805E-20,20.416675658633608 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3583805988673618,-6.1499484449573565 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3589658159136513,66.53438693879521 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3608965954770462,1.5329366109645104 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3616544608527736,72.26717619320068 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3625094317280286,41.39107324328906 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3637344824499085,-1.5707963267948966 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3669896114118365,-14.137324108012209 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3682843718495339,62.29868815194797 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3689352635119005,-45.31050384920091 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3716766816574366,6.879856011708856 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3794669481479729,43.047178174231504 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.380055767373974,-34.94221076518158 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3830980832019333,84.47716724125105 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3832261657045163E-222,-3.141592653589793 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.383468873076211,87.10080906838306 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3837411048152275,-70.43747860792901 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3851421307288792,-44.60579794227564 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.385922725153709,1.2738127728479973 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3877787807814457E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.3877787807814457E-17,44.26542054834227 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.387887323437545,186.769692138075 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3888992231602308,1.570796326794885 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3896189443376104,-2.0064851478251597 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3901346751161121E-14,59.89021564846153 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3909476375911896,0.6397393600377391 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3945614235729116,62.83185307179586 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3974811655840336,-35.05396921672042 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.3982588858053693,-9.650324993367741 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4059815380818732,0.026187749420935554 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.407357776682204,1.6016664761464807E-145 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4104998351108775,-669.0837801804189 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4122581739079987,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4128778500951016,61.30544188022559 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.41309360577132,3.4134275072800477 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4143039613644157,-1.5707963267948977 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4145934681840198,65.88696365624781 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4179097615067309,-1.5707963267948977 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4190837804745657,-0.02100100214886567 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4197174424918637,4.7123889822982035 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4203035659138734E-16,63.93973610457127 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4229070716055219,-46.40820234835572 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4246698009094347,-2.5707957998335043 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4295178502330734,-34.40849640347865 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.43274783907982,-3.141592724238005 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4354365198729109,4.14159265360413 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4375511814061306,93.50344681220739 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4432828771343962,60.147398517770675 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.443359065062026,52.808765184068136 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.443517395898844,-42.93319631910067 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4465715551113193E-12,-9.764952979109333 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4471225472578833E-15,-9.646075493650704 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4475750379289374,24.861801834660383 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4507169996507532,-65.57306029517547 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-145.08376791506555,-11.862720147464529 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-145.08389938182472,-50.1278637546648 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4529729183925268,1.0650916170727158 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4566837958257703,4.188045978328803 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.456684113051765,-89.70522847101479 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4581521149732481,-3.807402753685218E-16 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4583504241332417,-18.434446863798804 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.458437182625442,54.146411530956655 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4595960667753456,-25.132741235213995 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.463391921050608E-15,-31.75408238558012 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4637238477937018,-833.1651977550239 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4642077521668149,6.712388980849248 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4657894624244205,-1.5707963267948966 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4689134025960549,40.29293980695556 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4732085740825183,-131.27833322932207 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4738534961903434E-13,-57.46822486663619 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4743841366515635,1.5710479010123102 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4748124606733888,0.7924484206946687 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4763412467483412,7.861794134094923 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.482413065006795,-40.379602112997716 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4831712380244373,-82.16084545670141 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.483472632920391,0.0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4840609548157664,-94.24512289346663 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.484707405119556,1.570796326794898 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4850647386072278,123.29209332555023 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4868685688365884,-3.14262747153954 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4880315493559593,-2.364626916161936 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4939878312065322,-47.12218943960717 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.495439585043032,12.411754191235557 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4961150908925565,-44.1391233883605 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.4978861053746058,-95.63074213564042 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.497916286681739,48.84721381016823 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.499696813895631E-241,53.869066000442764 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.499696813895631E-241,64.04343052266071 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.501415938204218,-2402.128591851847 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.505627951823188,73.60011913154963 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5096059593128006,9.502722156572972 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5116230041751215,99.58857430840261 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5133981547922901,93.4614474662889 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.513455056202849,-1.5707963267948948 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5140170489486913,80.30150070674469 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5144769353468943,-1.570794771583809 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.515305917157544,-2.7016136048916335E-225 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5153248970830004,1.5707963267948966 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.518804146986207,1.5707963267948983 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5208429494051774,-78.59618120475548 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5210577284190396,0.0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5213611900954278,-11.876872234185075 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5231979551879857,0.8378235459157468 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5234365300448218,-1.5747025772074712 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5245219385776012,-80.27406165813129 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.5247340033825677E-17,-37.14000473975507 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5292925762436582,1.5707963267948966 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5295963864993232,3.141592653616365 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5302652262065843,1.5707963267948966 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5317817747712437,66.00533195596512 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5318323425670044,-49.46714481133742 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5326496989339817,-3.2665926535992003 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5327956836096097,-43.1552674001864 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5328853877766257E-15,-64.89420644997784 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5332268960951845,52.815114803734716 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5341778774727208,-90.60872177211611 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5356895374291261E-238,94.08764063430883 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-15.36717235779021,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5373313012054102,97.12197770995061 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5373593537333503,16.000395527503965 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5385233602445112,-1.2236064156835256 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5422010771171395,-70.30166189947529 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.542591759484117,12.56637601222762 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5431118513803115,59.40864354255283 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5433265685601438,1.5707963267949019 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5434271763341578,0.0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5451451572602808,-66.27517008322883 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5472792668015318,68.02170348504731 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5475451213296498,41.30199661790489 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.54847038353812E-14,-44.16579263512731 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5499122511892052,-2.249699936123407 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5500210265085803,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5513537505886763,-3.9161543144224282 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5515129309187188,-15.020444007062473 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5516288927100892,1.5707963267948966 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.552138535396585,3.1415926544932864 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5528347207760893,1.5707963267948966 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5530758271359577,0.0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5556527526619712,-97.5843547197276 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5574638076704335,4.712396609779236 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5584989228018367,1.4702119756712344E-16 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.55924906108772,18.042946365558755 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5596127296709774,-8.047660916696522 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5602030332129355,-6.283185317169241 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5602619539474751,0.7584164624320975 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.560344637223773,-57.30701384370683 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.561071876224436,0.0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5619986013407172,36.95895819740122 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5630128865825677,21.389414456324857 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.563852449891554,19.682097491190603 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.564063249340642,1.5707963267948966 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5641274181117976E-148,-100.0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5644457088643833,-37.28944069464792 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5645349484689766,-36.65050436500534 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5649661918850601,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5656675765638466,87.20485384480611 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5658469565882909,-48.572781966985715 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5659242226852652,-1.5707963267948966 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5663632879081406,72.8345752698765 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5666168400240958,32.58524127242197 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5667478473661558,45.45045430179563 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5672925096864232,147.1214774684461 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5673425790456827,-1.5707960343239216 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5686532163592946,52.79248431577227 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.568714287269272,-157.1027319390618 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.569588198596556,-1.5707963267948968 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5696969486149042,-10.838367292594128 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5699087403539516,-64.6476456332841 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5699304559628395,-53.40707511102649 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570185290553191,-143.76752770420867 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5701871826252891,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5706421130572406,-4.141593046377819 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5706986974377197,99.95755697382246 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707372236283035,-0.37104453909758234 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707914799799727,-112.50707835883384 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707955211335913,-12.691370698591953 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707959661907163,68.36556920841016 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796081323294,43.41150103677619 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707961013775003,81.68140899333461 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707962319164415,56.548667764616276 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707962544533562,0.9695675578707732 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963146493877,-1.5707963267948966 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963243451952,31.415935232458903 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963257048905,19.408131607242435 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963257275586,-1.5707963267950191 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963262798668,7.086076633148664 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326310169,-1.5707963267948966 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326326138,0.8371575478499267 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963264397038,-31.770228724570774 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963264490312,-13.60866823164349 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326470753,31.123322583766285 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963264762683,-1.5707963267948966 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326481115,-66.86353170036908 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326491671,-52.012057592974294 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963265093305,36.86133269499929 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963266116478,-21.02784983930003 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963266804459,-1.3138105913755826 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326684133,80.33033148377187 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267020268,-100.0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267124865,-44.8525453034116 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326746085,-1.570826846883012 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267610046,-36.41389979681976 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326769617,0.0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267768903,-82.74233197746128 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326781243,0.0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267936058,-79.58916416447084 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267941238,-58.40907156134188 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267942375,2.1222143966836597 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267945568,3.78667044936023 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267946499,-90.21774226528471 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267946543,18.184546457954184 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267947362,-95.48179392003762 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267947704,28.049618444610275 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267947713,-1.5707963267950105 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267947818,50.81663888205671 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794806,0.0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948282,-1.5707963267948966 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948335,-1.5707963267948966 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794837,1.5707963267948974 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948373,94.31960310852935 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794839,-56.548642271814465 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948415,-74.79648855680104 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948466,-72.68111248380323 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794856,-14.260526426231365 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948664,-82.49793790013472 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948668,1.5710404674249436 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948715,-100.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948715,72.49636329529616 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.57079632679487,42.220141835976705 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948755,-11.729482502956651 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794877,31.82153001687658 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948806,-62.45817639794511 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948815,4.724333300425366 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948841,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948863,-14.320290762740512 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794887,-61.42976662040549 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948877,-11.37935145197182 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948888,-3.141592653589793 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948901,81.42270129947528 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948908,227.74042182947287 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-100.0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,1.071196412357358 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-11.550647896781399 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,1.5707963267948963 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,1.5707963267949054 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-1.5736228403889398 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,21.98313311928159 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,25.00815003946117 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,2.6343796047740184 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,26.96507769744369 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-27.51032612202819 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,3.141592653604712 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-315.7277301106334 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-33.00184220246075 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,45.41800790622905 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,45.46318100756228 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,46.73267708814657 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,4.712633211124708 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-48.856775501728976 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-49.05083131465069 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-51.879327143214546 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-54.50835750099157 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,55.79038273673086 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-56.496167869174414 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-57.62078781490694 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-58.505558230220274 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,65.93080651898015 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-68.19624424389316 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,79.37658747682917 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-7.992653770700855 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-90.57631670139247 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,9.068045442595135 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,-93.8405738507673 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948912,95.17081114092346 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948915,-61.07825954744261 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948915,-72.40047481488344 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948921,-10.42779640861069 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794892,-1.5707963267948952 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948923,1.5707963254268265 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948923,32.90731705429798 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948923,-75.3982239248903 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794892,41.505720908764864 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794892,-62.508790105493745 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794893,-15.634995133215753 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794893,-20.290291283570532 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794893,24.08368932804295 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948932,-56.548666639276874 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948934,-74.64875482119699 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948941,-62.340554066586165 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948941,89.84367257763806 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948943,100.0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948943,-89.69379775308244 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948946,0.0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,100.0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,10.553737224558233 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-108.81415126697256 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,114.3222164686081 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-12.653377670032016 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-12.857179936281213 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,135.14597652846348 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,14.563612884387437 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,146.32929895151597 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-1.5707963267948963 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-179.25685697374655 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-24.728440309434767 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,27.36333434791994 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-28.549374200767197 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,28.93770302790591 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-3.2621874581027592 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-379.47978093843716 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-4.294036528251738 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,43.23282828529906 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-45.70041476810749 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,4.71238902411797 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-47.58921604816332 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-52.952123960418135 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-53.92691068092547 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-57.5996553380498 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,59.961026699294315 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-64.10578689538336 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,68.04537030650391 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-71.26299109198176 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-7.1738426002561 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,73.75025753796317 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-75.78463936093127 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,77.36315509413129 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-789.5867713932608 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,81.03226734094159 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,81.09944488372776 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-84.11211418164766 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-85.25385495146618 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,87.96459352641314 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-87.96465553038709 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,9.342164999766183 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948948,-99.41722780961825 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794895,-18.376107544991918 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948952,78.74494772026112 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948954,-2.864889104136399E-6 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948954,-53.930219347088915 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948954,62.716874931920046 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948954,-88.17632967864118 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948957,-1.5707963267948966 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948957,1.5707963267948968 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948957,1.5707963267948977 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948957,-34.03244293483536 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948957,40.32248662393688 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948957,42.89908733559748 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948957,52.60561095677665 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948957,-71.50557298709546 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948957,78.86058987082497 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948957,79.38713339074278 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948957,92.75768221634226 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794896,100.0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794896,100.53096478284839 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,-0.9817426887766323 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,1.0702194086955093E-196 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,13.50454046296781 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,-1.542289740235049 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,1.5707963267948966 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,181.22334973230988 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,22.75222649402077 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,-2.4502363204541058 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,31.769443259391693 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,-43.98229713206006 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,-44.168731426491505 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,-45.07508960192639 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,548.0386202552778 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794896,1.570796296983896 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,5.715234190078513 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,60.54076785697426 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,62.663902585633025 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,-67.2610142534691 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,71.97979239253546 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,-87.01918643803221 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948961,99.96016551845017 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,0.21170431920022392 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-108.51314020363525 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-112.13138518428812 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-112.50643260561785 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-1.570796326794897 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-16.82327469863928 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,20.217592743157407 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,22.93053401087164 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,26.185322850825095 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-3.1415923337635987 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-37.746817098376255 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,39.69487444507774 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-39.71518511718812 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-4.417119313450784 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-45.00104115417414 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,5.384249958041111 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-53.92976781193271 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,6.283185307179586 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,63.075019363388236 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,65.40362028349139 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-69.11503836067571 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-71.06047903773246 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-73.53676968885101 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-89.38122978333229 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,-90.17163347613537 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948963,9.432675353246868 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794896,-43.982288742832175 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794896,-56.43724668830648 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.011610043464012886 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.017305900983825513 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.02787957137732001 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.029298416663798336 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.031305853629763625 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.037638106237940755 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.03969464399243341 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.060611966959911 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.06788395944026765 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.13644431926152495 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.13759450749415544 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.1413173365372034 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.16896007797384036 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.21726662070666927 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.22448933192018217 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.2968022806534602 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.30182870700000713 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.3293801467794263 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.36811684594337835 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.41116559467094993 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.4730190789427717 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.5216791245824504 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.5301034598438554 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.5460058971262072 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.5538239156241176 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.559125238787438 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.5637317319417036 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.5671100086065533 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.5671391184850681 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.7048501903288402 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.749468864958047 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.756431598678068 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.7726829266761382 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-0.7788330118355447 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.785621320198404 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,0.9585882058021186 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-10.047203495952633 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,100.53096489059803 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,100.53096489972755 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,10.078992062113969 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-100.99544520021507 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,101.12355196609764 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,10.144835759387846 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.0211680762517152 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.0218386392095198 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-10.295472524738305 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,10.424777960787099 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,10.424777961033534 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,10.46998722867673 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-10.556348687244494 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,10.706601071522684 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.0797633330076761 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-10.834343381495643 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-10.836828582456604 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,10.980234956798993 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-10.99557421666979 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,10.995574278161383 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-10.995574287411017 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,10.995574287557929 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-10.99557443411746 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-10.995696362607925 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,10.99762065472258 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,11.148062748551983 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,112.16703259519988 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-11.217201364514096 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-11.233651755852662 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,11.408296649469428 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.143050176552908E-31 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-11.439100681616404 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.1454472754844407 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-115.13212750574827 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-116.23892766661507 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-116.65732336338127 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,11.70911204965823 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-11.754662662586384 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.2145304677578859 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,122.51575708358612 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.2309261203411666 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,123.72890448219476 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,12.399790099549794 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,12.658577131692184 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-12.695502830871506 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.270801734072126 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-12.81692150309653 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.2994262207056124E-113 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-129.96670457932618 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-13.006143900935175 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.3083999483761144 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-13.282809280563592 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.3390406953263763 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.3497510825350618 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,13.717732949862837 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,13.913180481611136 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-14.075240401927957 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-14.116381465653433 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-14.210814833209497 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-14.320936828685689 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.482107182357237 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.4997817864416254 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5025376224000036E-16 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5055685447279785 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-15.137166936737609 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,15.137166943181446 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,15.443673141156678 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,15.489614525679858 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,154.93593593294662 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-15.534033556362232 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,15.655083795474546 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.570564782497533 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707902518721093 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707960159350283 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707963184758746 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707963234152014 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-15.707963244238625 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707963252415766 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.570796325372239 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707963267801799 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.570796326781394 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.570796326789473 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707963267938732 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707963267948912 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707963267948928 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707963267948957 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-15.707963267948966 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.570796326794897 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707963267948972 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.570796326794898 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.570796326794898 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707963267948986 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707963267949019 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.570796326794908 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.570796326794941 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5707963267950156 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,15.707963267950833 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5708007887112683 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5708658718736528 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.571040564058789 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5710409517837929 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5711072026819026 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5712716976935202 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.5717728892954812 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,15.788685194208753 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5793650827938261E-176 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-158.55888846918054 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,15.86733063717733 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.5902396466448558 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,15.937581308934696 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.6139078697529499 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-16.151324820340797 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,16.245448906149825 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.6332963274750212 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-16.69252201116555 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,17.04118265079177 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,17.26365136729595 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,17.279247875994155 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.7556664516314964 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-1.784860482711124E-20 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-179.0705616893633 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,17.927209028386642 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-17.93320614440499 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-17.986761532398006 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,18.02050535666551 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,18.17627808644933 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-18.242768300660032 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,18.37401584324985 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,18.453150201780566 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,18.52272760533373 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,18.647713919917003 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,18.84955592158132 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,18.85630382849606 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-18.857368421538762 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,19.110656750898272 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-19.174058293155113 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-19.34955592154654 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,19.349562365344465 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-19.377961565439925 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-19.41783572772559 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,1.9699202479296356 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-19.814147287895295 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,20.006906590141572 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-20.058993635847756 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-20.12585317404097 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-20.27791915425985 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-20.420359877728217 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-20.422305378890847 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-20.517816107538685 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-20.661643382758108 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-2.070796326797668 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-2.0707963475355218 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-21.23339194373696 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-21.236333690299375 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,21.238022406087882 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,2.191809349008403E-193 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-21.991152538400033 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,22.245400522341573 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,2.2314122789064544E-16 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-2.281489334250191 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,22.901708729224133 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-2.292501967995271 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,2.296035032238123 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-23.268858422037624 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-2353.126604374536 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-23.617291410018094 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,23.932193030983445 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-23.936885158151952 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-23.99766262980436 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-24.01225505685644 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-24.100064780596817 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,24.148950485690747 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,24.227538686650682 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-24.475671231920202 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,2.465190328815662E-32 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-25.016116249462925 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-25.132741228718345 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-25.13514828806521 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-25.493991132911464 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-2.5527400846272457 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-25.545659932666045 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-2.5707959976150043 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-2.5707963254379815 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-2.5707963267877227 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-25.866718008827924 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,25.95205724010467 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-2.6097930989877938 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-2.6178510226909424 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,2.636323671979827 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-26.84002864293464 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-26.870540856198716 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,2.710505431213761E-20 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,27.420259684795397 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,27.64198233157779 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-27.768941455230717 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-27.92177004640598 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-28.031214357132384 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-28.16032766567359 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-28.27433358359613 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-28.275200902645583 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-29.085237026131875 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,29.295880702894646 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-29.299520592919716 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,29.32290557270025 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-29.333283300407516 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-29.579980015048108 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,29.60022123970628 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,29.789098151130855 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-29.96141613434098 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,29.96357316816158 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-30.01726563621601 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,30.132256659329183 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,30.207093403796105 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-30.5102829581036 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,30.53389182181525 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-30.657443282707455 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.0789154260550378 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,30.798065359434354 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.0801176221472932 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-30.804357061713702 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-30.825640356855832 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-31.408993930045302 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-314.15675541376163 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.1415883881524573 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.1415922389684785 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.1415925650541454 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.141592653580768 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.1415926535897922 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.1415926535897927 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.1415926535897936 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.141592653589794 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.1415926535897953 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.1415926535897967 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.141592653590904 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.1415926535935728 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.1415926535940986 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.141592653754731 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,31.41592653886209 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.141592654032205 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.141592654777983 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.1415928920089433 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,31.41604981532633 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,31.43526206511595 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.1472322123392997 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-31.490590412401033 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-31.54995836938295 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,31.57942615421499 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,31.64501963592062 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-31.654807903316566 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,31.71290538451497 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,31.885300493139965 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-31.88717072544111 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-31.953844743209842 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,31.98672286269283 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-32.025359578218385 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,32.050180945241024 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,32.06866489228864 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,32.42477591284464 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.266592653591555 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.26659265359212 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.2665926535928578 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.2665926536166734 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.2665926560071075 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.2665926671497463 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.266592712283262 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.267078602380848 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-32.681142600957784 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-32.7412441850001 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-32.77437920259738 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-32.816892761001036 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,32.99539846273674 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,33.06783310928312 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-33.08181070755586 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-33.21535372042605 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-33.289893581372745 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-33.29115726096343 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-33.40927760303498 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.361947940158039E-18 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,33.87325384097258 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.415966131372784 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,34.55751922105802 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,35.12875266075162 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.522101828684134E-133 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-35.395712302556646 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-3.5400092223294135 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.5410067000898224 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,35.67127880066231 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-35.861245747710406 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,36.01363519379318 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-360.14349416542746 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,36.03013693417436 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-36.12831551555603 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,36.23343056553074 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,36.61092748467408 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-36.800671277661976 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-36.83274913041048 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-36.87273592619336 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-37.13219871212728 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,37.64584049652491 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,3.7687479583827095 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,37.69911065030282 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,37.699111841708316 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,37.71418674976024 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-37.71640360137473 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,37.71941473633203 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-37.74231005919937 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-37.8739304166718 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,38.189009226049514 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-38.30164801227257 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-38.4362021383654 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,38.44608502459096 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,38.452533220416186 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,38.66321343625615 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,38.699111890603604 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,38.73749596180888 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,38.75435067206499 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,38.84653087982434 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,38.874701780169374 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,38.91622473130222 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-39.05294069343495 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,39.16340476538095 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,39.277720669872416 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-39.66550084982316 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-39.90193262594292 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-40.24414919510326 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.0298858450171024E-19 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-40.320586299636304 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-40.638027443177194 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,40.87222329046215 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.141592653519263 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.141592653590514 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.141592653595531 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.141592655772099 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.141592676465607 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.141592678167168 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-41.54305835266929 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,41.98229713003503 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,41.982297150253096 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,42.41150082309626 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-42.503797183994834 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.259519048283104 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,428.513194527831 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-42.97161545857204 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.315022925083191 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-43.30614865424419 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-433.52449838948405 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,43.41150082426478 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.341153955802923 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-43.45840861977564 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.3761901237684455 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-43.866691724073824 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-43.98229695346611 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-43.982297150257104 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,43.9822971503985 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,43.982643006498144 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-44.159033025398166 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-44.17668896298826 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-44.184129410637695 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.425272287751883 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,44.34598065498108 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-44.357900394436285 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,44.3649820639325 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,44.368368373866936 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-44.40346493128471 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-44.403963738582405 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,44.426609026867894 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-44.481443226356056 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.450956682876841 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-44.55309336622197 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-44.604016536459646 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.471440791034581 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-44.764259731901504 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,44.957024044018794 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,44.990628979535074 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,45.06511946308436 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-45.081210536628575 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.5082903407156913E-131 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,45.13708736457419 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-45.258797374691746 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,45.293869727333686 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-45.375113805277955 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-45.453198494246564 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-45.536771343137474 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-45.55309347894094 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-45.55309349904181 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-45.554633687983056 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.5708187208679085 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-46.053307247583845 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.638586089041951 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.668946690596137 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.6825208198913595 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,47.08342601623611 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.712388980852942 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.712389218803611 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.7123966097792245 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.712401963017651 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.7130034612086025 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.714326665748167 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.7143421054374635 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.714342120264776 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.7143425767622675 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.714372240630628 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,4.715106552662526 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-47.31061878092841 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.743638980455319 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.7436389934724055 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-4.743893956594186 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-47.701169791636985 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-47.78752768396929 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,47.8593539616173 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-48.6946861301643 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,49.38399472906312 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-49.44057189805741 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-49.51601359247864 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,49.66649272563188 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-5.0052077379577523E-147 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-50.09500091551169 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-50.26557901797596 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,50.36316985087893 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,50.54062498162596 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,50.95386496311442 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-50.95474925454169 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,51.01495132239474 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,51.41941743183285 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,51.85190378424015 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-52.040743128634844 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,52.26548245743691 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,52.52275797135357 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,52.9090469604358 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-53.024723912508186 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-53.20613373711059 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,53.28832127276968 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-53.39309438630033 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-53.40707511429458 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-53.40707511725304 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,53.49011076698878 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-53.61593969221574 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-53.61674101035566 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,53.66486178627981 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,53.66863186978176 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,5.3822513166026 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,53.849726463672056 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-53.87695460369126 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,53.9906096460842 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,54.00428513719006 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-54.12524345536841 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,54.25936661525241 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-55.21818554516369 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,55.26345106061107 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,55.40866266230304 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,55.441545235747576 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,55.548477558737794 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,55.65220800632757 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,55.65700723210512 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-55.758898391304605 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-55.770005890975085 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,55.79919889965823 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,55.87058714079923 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-56.15705894377527 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-56.15949888227123 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-56.1964262319794 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-56.286907447031794 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,56.54869828222431 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,56.68488228122111 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-5.708446505292905 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,57.19754705550062 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-57.83910410196863 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,57.851146148249256 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-5.809771956024828E-16 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-58.15357005303936 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,5.819157966025834 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,58.21871960042478 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-58.43459705730114 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-58.57516495174223 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,58.63706855828015 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-58.748848046360195 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-58.75677198827489 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-59.143154815754485 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-59.175331275176354 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-59.25522788851048 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-59.270809642482966 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,59.541640495439715 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,59.552335072942846 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,59.69025766363352 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,59.724360957311795 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,59.72437780159699 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,60.04515222224458 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,60.07155242891557 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,60.095153634566486 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-60.15545959556208 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-60.19671029278939 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,60.854165089195824 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-61.414967373470496 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-61.55015772060346 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,61.88770762776675 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-62.049221396046555 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-62.05480986143989 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-62.486258939033036 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-626.7469446661034 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,62.72639248788542 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-62.77459262098258 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-6.278741272416692 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,62.8318556037215 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,62.863489696125185 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,6.2988103072668 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-63.036445413605534 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-63.322716206575855 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,63.5622321531946 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-63.809916253219676 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,63.829250065922764 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,638.4360443145814 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-6.406665904585923E-145 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-64.46391214563745 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,64.56558637706352 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-64.70607211204484 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-64.76388796834695 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-65.43690681581766 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-6.567707997221228E-16 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-65.74650582240231 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-65.91756597736457 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-65.92355471855653 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,65.96818520163697 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-65.98125822538569 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-65.98143191414763 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,66.10990176699377 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-66.11006276883093 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,66.16888721623636 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-66.18191225601244 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,66.4083871125217 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-66.51956335015711 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,66.63032997407117 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-6.668192050208761E-4 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-66.69677995310523 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-66.73957212365629 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-66.99659368680041 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-67.04944663951464 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-6.712388980384692 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-6.712388980384697 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-6.7123889803864785 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-6.712388980473641 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,6.712388981150256 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-6.712388993797405 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,6.712435639839914 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-67.16381564013246 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,67.20173029403321 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-67.20198218431221 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-67.22835169564212 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,67.2898024015685 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-67.35106097986292 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,67.450907451106 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-67.51899586772127 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,67.9334985799076 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,6.808351250975885E-15 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-68.24814117165069 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-68.27948333321822 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-68.34655582001295 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-68.4653708881003 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-68.67746783275729 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,6.86995327770515 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-69.04854822532391 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-69.11503837851741 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-69.11524433288207 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-69.63538786388115 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-69.75675570121344 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,70.42152062332144 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,70.67706242046017 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-70.68583820550947 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,70.84461938779401 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,70.84971408979918 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-71.18476802809411 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-71.42369695277445 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-71.42765691535996 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-71.44935508578328 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,71.85100426209954 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-71.9167119341858 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,72.25663100243774 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-72.26493878936607 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-72.30911102965116 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-72.36231535969571 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,72.45049581634994 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-72.49929179928543 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,7.265771866523876 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,72.75287198224189 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-73.2415637158445 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-73.34252688526828 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-73.40448698325143 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-73.467429632667 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,73.47604826945562 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-73.49646229627412 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-73.56272068905174 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,73.666450567348 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-73.78619027360924 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-7.427156990422215 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,7.43920262916022 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,74.43308959308689 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-74.44544174439929 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,74.47390691157887 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-74.64875482119699 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,74.94729356400458 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-75.01853586755308 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,75.18734423052072 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,75.20836110875352 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-75.24164530407043 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,75.3881120345836 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,75.39822368615503 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-75.42947368617806 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,75.56412854353117 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,75.85646098258371 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,76.14769255111308 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-7.625528459812443 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,76.30152225624693 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-7.643092389532356 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-76.46117678545875 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-76.57117611445688 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,76.72152561286366 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-76.7838826221212 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,76.87032729724302 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,77.0188897738781 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-77.10217245606114 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,77.59403695257836 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-77.75167461659929 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,7.786871055544975E-208 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-77.88096872996249 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-77.8820825007323 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,77.9467144951758 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-77.95798299469888 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-78.41413914131425 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-78.5398161762155 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-78.53981635173373 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-7.854042675264372 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,7.861794133974498 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,7.861794134118868 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-78.90320425062087 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,79.73680130761346 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,79.83275343696391 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-80.09454750240626 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,80.14418751416467 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,80.18718746425708 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-80.22625749514101 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,80.52181405021217 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,8.104122411369232 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,81.16047209800817 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,82.02093266061614 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,82.04504180378865 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-82.09580042016476 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,82.35453914773001 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-82.43087785829267 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,82.86763653102075 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-83.0601845736677 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,83.17464015625492 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-83.56579798014009 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-8.358948324661067E-15 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,83.80915640939318 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-83.86507120122457 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,84.08733535112503 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-84.18751911719623 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-84.45288620421343 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-84.4694234345297 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-8.470329472543003E-22 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,84.82300166241721 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,84.8820965589999 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-84.88571404188659 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,85.1162063145201 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,85.17473880045031 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-85.48984808427983 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-85.56382773020034 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,85.6452958369525 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,85.73456027245953 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-8.609139787121796 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-86.28484315205714 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,86.30315560818089 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-8.670343319780741 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-87.16042923573914 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-87.21256107442998 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-87.23312994609827 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-87.34931168277106 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,87.57430540993958 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-87.96459441999262 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-87.96462358668653 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,88.03700392758824 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-8.805296180684902 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-88.14885624032384 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,88.16085961790604 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-88.20346800420677 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,88.24352947567384 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-88.2625257522961 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,88.2729393373561 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,88.28487146095569 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,88.3468868940507 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,88.39462655666091 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-88.41324542897917 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,88.45410049794786 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-8.853990594814924 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-88.68114960755938 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-88.82835943367503 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-89.13335009990723 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-90.10035035445507 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-90.36573192881984 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-90.39625402203305 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-91.09477037907583 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-91.10618689186951 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,91.106186954104 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-91.11009320411665 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-91.31337769967926 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-9.194693602980289 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-9.21836595846446E-17 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-92.602435554143 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-92.68609365476324 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,93.39500877941086 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-93.57410609864269 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,93.67708322340181 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,9.385961429833952 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,93.94140017568864 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-94.24372092888628 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,9.424777945064253 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,9.42477796077184 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-9.424777960783707 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-94.26448010257793 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,94.27213079219953 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-94.29788469599636 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-94.31351573287722 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-95.41285408596232 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,95.62500395449962 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,95.66504163325394 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,95.68687577956223 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-95.8185911932979 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-96.02403519116324 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,96.13891466843512 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-96.2697966192438 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-97.20615874624544 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,97.38937227536469 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,97.4154290464632 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-97.64440903085199 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,979.0311883233063 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,9.845770283655497 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,98.59559820513151 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-99.35402818176115 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,99.35966984260855 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-99.42235590961656 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-99.46581384812917 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,99.50597259100965 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,9.969373067534956E-17 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-99.78149604991533 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-99.80773226246887 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948966,-99.96016858818203 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948968,0.0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948968,-102.10176103162638 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948968,1.5707963267948966 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948968,1.5707963267948983 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948968,69.10502253654613 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948968,73.66151627621775 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794897,1.1956257940887063 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794897,25.335780411724638 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948972,6.712389251386033 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948972,-9.424777960971486 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948974,-10.12264881833207 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948974,1.5707963267948966 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948974,20.521278692582285 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948974,23.86210611525594 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948974,443.3068664767917 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948974,45.09404785825356 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794897,45.419825205237046 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948974,-6.712388980387655 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794897,-4.7242068453163 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948974,-73.44382610784243 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948974,98.9121442664063 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794897,50.55510684259753 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.570796326794897,52.753456240857986 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948977,-15.707963268759494 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948977,-70.65584716694433 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948981,119.38066249897449 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948981,-1.5747025767951597 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,0.02462012054370913 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,0.8423807113172501 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,-154.17405184910047 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,15.502762454731045 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,2382.6871460727257 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,24.086115446872867 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,-29.959156629577578 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,44.37146232600867 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,-52.336806769452146 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,53.19283584909941 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,-53.81590869534676 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,58.771228688808236 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,59.15778948182339 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,-61.9997020955551 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,-72.34770001155994 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,72.45326619926233 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,79.24443444912558 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,83.74640651872772 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948983,86.713474598576 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948986,-100.0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267948994,-1.2145223259752025 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267949017,-36.89019803037995 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267949019,-1.5707963267948966 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267949019,-4.365398519773683 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267949019,66.04166404198419 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267949023,-85.20744498295069 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267949034,-165.58910443150364 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5707963267949854,21.991212749382125 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-157.13315293076292,67.54116734900245 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-157.15427268099825,-92.43907198296954 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-157.20125314618173,100.0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5733851786576756E-30,-15.707963278601579 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-157.3770793000847,-2.6657528287739915E-5 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-157.56479274729185,11.120574636829257 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.5793650827938261E-176,34.42624263012813 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-158.1016128506717,-20.314779328788532 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-158.5423787812287,-99.78917436999325 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-158.61700291970195,-6.878668755436061E-8 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.6016664761464807E-145,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.6042523511641854E-10,-92.69260918917541 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.6155871338926322E-27,-15.707963267947875 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-16.171580197544262,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.6322835863254284E-5,-40.850004322506905 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-163.7332082642449,-63.71619070011992 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-164.71417167116445,4.2753486562714755 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-164.87561271050913,-62.75542263940592 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-164.93113750166032,-68.4304084526594 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.6543612251060553E-24,-1.5707963267948966 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.6748964744250855E-161,3.141592653589793 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.6940658945086007E-21,-5.895635656659522 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-16.96485038523323,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.7188641056942146E-12,30.196286630371056 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.734723475976807E-18,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.734723475976807E-18,37.6357869763453 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.734723475976807E-18,9.897324042030633 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.761050914342067E-133,45.41514096392033 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.7613257252713056E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.7763568394002505E-15,1.5707963267948837 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.7763568394002505E-15,-1.5707963267948957 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.7763568394002505E-15,26.285514493850897 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.7763568394002505E-15,72.29216814138263 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.7763568394002505E-15,9.48082261169165 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.7763580401781002E-15,53.865445150119015 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.7836202271052415E-12,-15.22184440808661 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.8367099231598242E-40,45.553093477027716 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.85893602083382E-16,3.1415926535897927 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.8597990311250788E-14,3.141592653589793 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.8726705418768793E-96,-72.67743066821886 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,18.84955592153876,-80.2885677957256 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.9131231555192685E-15,8.056722450736473 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.924098859583136E-9,-91.10612511632533 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.34955592157739,9.776496047008237 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.349555922201073,-0.6134497013067176 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.349555922210467,-1.5707963267948966 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.349555922222354,28.553398075501498 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.34955592744151,-0.5337685590130723 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.34955632330872,-72.25619788867603 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.34955756410439,-1.5707963267948966 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.353988097022476,-33.16417986377192 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.35417067027197,-1.5707963267948983 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.357040357952876,-1.5707963267948966 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.358704683520646,-31.244350692757052 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.363291851094957,-66.45073090911193 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.364583492064853,-60.66924294979499 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.366807825633586,-60.493313988229744 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.373976262101316,-11.377272669290114 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.374807130453206,-1.5707963267948961 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.37794464144912,-0.461381245624807 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.385273821095126,-96.83819157328028 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.391811717307167,-4.712396609810086 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.393087774791205,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.40028813851956,8.101811127221447 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-19.405279059788953,-1.1667998420256427 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.9636373861190906E-90,90.93481351216622 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.969883673502778E-12,0.0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-1.9721522630525295E-31,1.5641274181117976E-148 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.9721522630525295E-31,-1.5707963267948966 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,1.9721522630525295E-31,57.19670770529336 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.002083095183101E-146,23.89602247425667 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.0303534698525194E-115,-84.84401086601017 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.0507952149895153E-11,4.721834244448388 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.0549830558524387E-5,-2.970582354224856 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.0679515313825692E-25,-0.07244846082481989 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-20.74379571306234,-41.683056255622475 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.0863432363472874E-8,-65.97260327604626 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.1021360348161034E-19,-28.274301487345515 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.1550132019693006E-15,30.70149587607138 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.1684043449710089E-19,36.132221789837246 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.1684043449710089E-19,-43.41712598444269 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.1684043449710089E-19,48.37231085983875 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.1684043449710089E-19,93.60506979884379 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.220446049250313E-16,-100.0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.220446049250313E-16,-1.570796326358897 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.220446049250313E-16,1.5707963267948948 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.220446049250313E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.220446049250313E-16,-19.570872131504288 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.220446049250313E-16,-3.141592597401193 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.220446049250313E-16,4.7446551960259 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.220446049250313E-16,-66.72106542196325 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.2227587494850775E-162,79.71575276874529 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-227.76542032938193,-17.181365527268902 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-227.76546732115327,9.78844354296919 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.28597478256455E-100,30.284051731668082 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.2945673549830077E-13,-41.20281630408309 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.3694487388569243E-4,59.5483603695308 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.3800009343120166E-17,22.145487863953477 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.465190328815662E-32,0.0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.465190328815662E-32,-1.36256522405708 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.465190328815662E-32,1.5707963267948966 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.465190328815662E-32,1.5707963267949054 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.465190328815662E-32,-19.91904567393098 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.465190328815662E-32,-23.718293151265488 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.465190328815662E-32,2.9584133757822286 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.465190328815662E-32,45.490240310919006 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.465190328815662E-32,-45.9058575701057 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.465190328815662E-32,49.869548637554246 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.465190328815662E-32,-73.45628496773651 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.465190328815662E-32,-77.43335315970498 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.465190328815662E-32,9.525190288549865 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.5113541083686828E-17,65.98266752528 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,25.13282205954129,1.5707963267948983 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.515261661068048E-16,0.34941765896461857 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,25.20180412822053,66.24028399072297 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2546.4407147948473,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.564144751902096E-15,98.9644534389515 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.572184188700974E-14,-28.0473209259179 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.5731176380965507E-15,106.39975067135259 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.607310436113954E-9,-92.67749112562952 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2622.2368936033704,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.6469779601696886E-23,-14.76238532357511 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.6469779601696886E-23,-2.567702616156161 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,26.703537555513236,99.2394039859524 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.7098503081087525E-16,48.21699242856687 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.710505431213761E-20,1.5707963267948966 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.710505431213761E-20,-26.497430581546993 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.710505431213761E-20,-3.1415926535897896 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.710505431213761E-20,-39.04598761126567 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.710505431213761E-20,56.12135997393917 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-27.195815034908264,73.62410386446913 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.7262213742365655,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.76505623426072E-17,36.4374261589817 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-27.738892406525338,-3.1832880899758145E-14 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.7755575615628914E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.7755575615628914E-17,25.398119023397495 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,2.7755575615628914E-17,95.5425995592322 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-27.848365783173993,-4.337035230283586E-16 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.8298997121333476E-73,-13.659983015906533 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-283.31408736595756,-97.53030847763273 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-28.366604623126946,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-284.1624969087014,1.5707963267948966 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.8978020841157E-16,-93.6436318805201 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-2.977444202356098E-16,-1.5707963267948968 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.009265538105056E-36,-3.141404877944537 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.023995231294639E-17,0.0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.0417465060722557E-210,-79.11787232398258 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.0473108693652343E-16,-100.0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,3.059261789687307E-20,-1.5707963267948966 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.0978858000775307E-9,72.25686824676622 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1282548362235952E-148,-1.5707963267949026 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1282548362235952E-148,-44.36808411676253 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1312619674294135E-7,-3.266592763036488 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.41592653589793,100.0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.41592653589793,-1.3167433156329853 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.41592653589793,-16.95870506041692 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.41592653589793,3.1415926535897896 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.41592653589793,-5.802908066994007 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535897936,0.0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535897936,-0.43320518625912996 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535897936,-1.5707963267948966 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535897936,1.5707963267948966 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535897936,-36.95675760981533 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535897936,42.544771944043134 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535897936,44.36540600512643 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535897936,-44.678379447089924 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535897936,-52.53295095321884 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535897936,6.024393642444153 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535897936,66.75081122260127 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535897936,-8.217023769365557 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.141592653589794,-1.5707963267948966 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.141592653589795,-19.383179902182164 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.141592653589795,-48.49530840770835 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535897967,14.370297797020427 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.141592653589799,82.21778343872234 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.141592653589809,100.0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.141592653589822,0.0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535898,24.293072472629945 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.14159265358989,-98.48379644123578 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535899033,-100.0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535899374,-61.89255120525043 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535899734,59.417604285717545 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.415926535900535,100.0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.141592653590604,-0.010794780571901419 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535906875,4.235898841679763 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.141592653591148,73.48557451970234 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535932766,88.12141558610824 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.141592653593442,-100.0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535941257,-77.61576337912686 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.41592653596257,1.5707963267948966 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926535967245,-10.49056818932587 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.41592653608729,1.5707963267948961 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926536119057,1.5707963267948983 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.415926536239144,31.177467228345844 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.41592653636688,53.40679277088232 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926537058496,0.002000565041206453 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926537084045,76.62068053760427 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.141592653717597,-67.25624700407344 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.141592653796812,-75.42728111375192 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.415926538284424,30.374422996175387 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.415926539152537,-50.26661484788528 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.415926541873056,-0.8450943645792819 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.141592654238415,-39.684391738059816 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.141592654377965,47.91670282664159 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.1415926622224437,0.02002747558980955 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.415926650217518,-141.27675839252058 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.41593369251181,-43.582604172170214 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.415938015826384,-1.5707963267948966 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.41594706608983,-59.69025866995531 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.416108807145307,-53.61625364686272 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.416179449954562,-20.507117409759662 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.423784760762672,53.358387658476325 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.426243656212776,1.5707963267948966 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.43235964381938,-46.42552678119291 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.433822875990366,-20.99540158349609 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.44055251481329,1.0908679475418407E-15 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.441088039909573,-1.5707963267948966 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.442102555674616,93.14887862422987 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.45052021862438,-3.266593268666844 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.46335428118878,-3.266592663648159 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.46548350769818,-1.5707963267948966 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.47014907155797,-1.5707963267948983 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.47136031947704,9.644468877640278 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.484492841744526,1.5707963267948966 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.498078794268945,-4.933019680155691 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.498974545047524,-91.88636630366867 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.50962004373369,4.743638980384856 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.53688529074683,-55.268377355440755 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.54876943669364,0.9269125931184106 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.55034018529254,-85.908373533054 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.57077902994308,-57.99957717818916 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.58180020329143,-36.73452460503601 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.592308500209906,65.59892647814307 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.596178070183292,-1.414624275319158 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.59694313843753,-9.995721145002248 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.608103556019493,-77.56399546878374 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.61351311930263,-60.9199330383546 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.619326663976985,-33.37611671778469 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.621897350309823,65.55697992667203 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.623326710625697,8.085384690045476 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.627390142959726,-1.5707963267948966 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.628930036871814,100.0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.636036013015705,-3.825303004293573 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.641696002221625,-23.23792101793437 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.64369828231171,100.0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.644491396851258,18.078158106770232 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.652003309127437,3.1415926535897922 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.655540830009357,-0.6359800329556586 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.65895883486074,17.519190867457326 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.661851738661056,-97.40293545553742 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,3.166427046872987E-28,1.2237665044201593 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.66549159033594,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.67865573663711,-65.42394790385572 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.680174820485814,-5.770611636116085E-129 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.688158193474614,1.523918498029926 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.70610540842781,-14.42770826991029 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.70723541455655,99.99999999999997 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.712817347600947,-47.58580176659152 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.714711711976733,-1.5707963267948966 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.715016727511546,1.3234889800848443E-23 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.72415010360055,-98.97851459927293 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.733598313058064,-75.99707058172535 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.73615260555152,1.5707963267948966 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.738331015829942,-83.88604936384085 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.73994067463745,80.11141201472438 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,3.174068673683343E-17,91.03462399433468 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.76403721012428,-3.0134065085406796 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.77991887675259,-1.5707963267948966 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.787346242836257,96.26255712092876 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.788979765195982,27.86226208860248 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.790800839648412,0.0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.794459142877734,0.0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.7956760644866,71.93539504613045 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.800561925522693,-48.75003826846395 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.802414614285684,1.5707963267948974 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.804993350743015,-16.231822170573423 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.81682709211971,-3.3330974556646505E-14 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.816843691004653,-1.5707963267948966 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.83444771524454,77.0610104065872 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.836705218476812,100.0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.839436721375204,-94.35863201400207 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.841302303206678,-41.954617065793855 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.85237198109566,-40.840704496667314 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.85341859264941,-1.5707963267949197 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.858280727899388,-1.570836803681247 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.867061554045364,-88.57932885486899 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.87129140690395,-1.5707963267948966 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.876324333531727,2.856790517139757 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.883210366355897,60.26505436629223 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.886457674956844,71.94154995637315 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.88839629463446,-94.60757812484538 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.896887155756872,-0.7845382455480521 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.90398828667841,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.908572462144537,4.080349282895902 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.91174438226451,60.274491494577894 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.93478529515921,8.281384013773242E-32 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.939281855805966,-23.090818535848246 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.940722539725,100.0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.94516383752815,-3.2665926536169207 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.948541796387772,16.96018270862058 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.95660969101203,-889.4648236052809 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.963808851006604,53.216635590271196 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.974246624802017,-52.54873754621838 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.975542540256868,0.0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-31.97974962277816,3.1415926535897825 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.2311742677852644E-27,31.848105977365464 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.2311742677852644E-27,59.69026041820369 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.237199584545505E-15,-53.798402039456235 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.41623019512245,1.5707963267948966 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.41696429025576,72.58151299969288 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.42831820964884,24.43067793254407 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.436776513124094,72.4630898901485 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.44590630581311,-1.5707963267948948 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.45760405341665,-61.26269416734422 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.46248574247519,-1.3262159716431574 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.464423769707935,4.962388980393143 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.47326012536652,-53.39281390227782 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.4775092373532,67.94745134374061 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.4803332633017,1.5707963267948983 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.482666421246364,5.876146829170577 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.49008564508324,-1.5707963267948948 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.490688599199615,-1.5707963267948966 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.499147214559244,-1.5707963267948983 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.50663558355196,1.5707963267948966 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.520583114817015,-1.5707963267948966 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.52098195695113,3.1415926433137296 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.53014260830866,-55.43158518640248 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.53709014443137,100.0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.54349299323956,-37.636285920639274 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.5494108126007,3.1415926535897953 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.56150068407582,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.5638927836149,-1.5707963267948966 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.57013396753968,74.85115994807816 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.580013781687796,-480.5523135468916 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,32.58472785038546,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.587223531114006,9.926139633623123 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.594509101457064,-1.5707963267948963 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.59491815506502,-0.0731061944158713 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.596931191548734,53.08726090468699 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.600260603276745,-160.56172258725817 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.60070772801511,52.124156272785825 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.601475703488376,-39.71116750714036 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.6085868350816,-92.7392630486025 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.638952098158484,-0.06623460849605345 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.65924305537321,-50.791827751112706 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.669056249440594,1.5707963267949054 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.68504780083033,78.98960723246746 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.7073526337978,1.5707963267948966 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.72682972974729,9.532669829972903 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.74712415660679,1.5707963267948966 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.748238251358224,97.9515218813232 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.75146293047681,-0.35794937230146656 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.751538661943975,-13.432086847729842 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.75524210433624,-1.794965501747905 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.755905168275554,-3.6335432962276215 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.76090947530091,-2.8002340952209153 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.76621515829466,-38.453139081650036 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.77584735252941,-18.01956045842421 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.78652656842442,1.5707963267948966 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.786565939734594,-63.18282551576142 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.80761756932792,-1.5707963267948966 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.80855955579337,1.5707963267948966 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.81501814136159,15.309555843808525 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.816919690725484,-1.5720344490091938 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.817584518127774,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.82299937338871,39.424542516046095 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.828195068958166,3.1415926535897936 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.83708667147777,-33.44747033428834 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.845182254621726,26.3674954357408 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.862050189771395,67.18847636209496 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.86438785332623,15.599819577798431 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.86503573668796,32.60139417028206 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.86568496676301,16.383185165743505 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.86822333510213,1.8932781107806372E-15 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.87932078191483,1.5707963267948966 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.88278669253823,-59.53648840504592 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.95899244131702,53.22107779190674 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.96394632412036,1.5707963267948966 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.975764327593836,-44.30386275477119 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.97710018224487,-27.105455189998338 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.97905804844882,2.7250474869603636 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-32.98349783327183,1.5707963267948966 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.302582133060514E-15,-28.65303438311889 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.3087224502121107E-24,-53.65707599001514 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.326895348786563E-15,-20.8541906162929 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.3364458639749756E-16,0.1673284032805346 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.3836725072179935E-11,2.220446049250313E-16 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.418027039727464E-15,36.97123584795739 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.4342178524994237E-15,31.41602427526667 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.4565669339458427E-25,-40.8404936336429 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,3.469446951953614E-18,21.03663081357543 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.469446951953614E-18,-32.835237542070644 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,3.469446951953614E-18,-53.24412804403802 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.504175027642598E-16,-71.52334171174195 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.552713678800501E-15,-100.0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.552713678800501E-15,100.0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.552713678800501E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.552713678800501E-15,21.052698149363465 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.552713678800501E-15,-33.0282240120154 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.552713678800501E-15,36.03913392071768 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.552713678800501E-15,-8.411715660510609 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.552713678800501E-15,93.09546276592891 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.556413999176124E-161,-67.51856889735163 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-35.89751243959039,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.5910604374153675E-189,-14.875042704844269 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.619712502661651E-30,72.71802225458865 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.664353621793551E-16,-74.97289496456862 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.696576527903426E-15,16.938972612830796 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.730770949927058E-88,-3.141592653590715 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.7362322029720306E-8,-67.03648348932536 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.75412479607006E-13,-87.2174564781263 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.69911184307752,100.0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.71659829049316,-70.91081559897829 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.72023011233715,-1.3240223892107092 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.74022951815203,4.191270475601283 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.742449576831945,1.5707963267948966 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.744605912016894,9.72515436907888 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.75006861226721,-9.081836579850965 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.764521595674026,-1.5707963267948912 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.76497843567527,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.799396134024434,-83.99143880215875 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.825990623329815,83.51806057351143 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.841924297393426,-35.962411239777964 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.86609874444836,64.81296414673389 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.89515755258615,1.5707963267948992 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.89889217730878,-100.0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.90688141948959,-66.346063711552 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.912410278363296,9.466128973845883 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.91624637943124,1.5707963267948966 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.917421501614825,-100.0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.94141218148685,-8.811845824876858E-15 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.94196677592004,-12.714242880679791 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.94569333110643,-1.5707963267949028 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-37.94790013056189,72.727943644026 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.34357068290246,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.708662255839286,-1.5707963267948966 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.71350676014697,3.1415926544543753 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.74992977412512,-1.5707963267948966 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.75213190414522,-0.8662140778514473 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.75630374215149,-74.82955108928968 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.76742433696731,53.85761793146412 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.77205112628845,-1.5707963267948966 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.77915070783289,-6.36575636625281 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.77923196769271,-41.08985328028855 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.790781524702126,-12.45316027558539 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.803538868803436,-1.570796326794898 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.8104052023126,100.0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.831596086805185,-100.0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.83563544475986,-71.53235122346031 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.86977983380722,1.5707963267948966 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.905366051874935,1.5707963267948966 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.90579745193743,-1.5707963267948966 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.91191504899938,-87.76858363624201 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.9224767151471,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.96195719337529,-3.2665926536190035 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.9798178754126,-54.570752179673974 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.98784816999475,-0.037129748399204646 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.98805637793966,9.188478917437408 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.991561792879814,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.992870566141434,-0.1889534610480868 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.99377377853466,1.5707963267948966 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-38.99735610568537,-0.37997656222525844 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.01231989329833,-80.86506135595579 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.01307593027594,-56.29948378692168 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.01942257731374,1.5707963267948963 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.04527854467713,87.66550315988223 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.04791075601393,-5.852095443365248E-98 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.054513043064816,1.5707963267948966 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.07571168355695,-1.5707963267948977 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.07852921514778,-1.5707963267948983 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.083518750516454,-0.48657440536924945 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.909188933792873E-17,84.14467435017694 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.09201387582031,-1.5707963267948966 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.096319941730656,73.624553253637 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.111609626405695,9.814038660947897 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.1122967453485,-1.5707963267948977 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.12440812213373,47.47962375526031 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.133819700376975,-1.5707963267948948 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.13574431440073,-17.37732921126846 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.16651504418176,1.5707963267948966 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.18414787072101,-5.566865103005576 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.1869803721769,16.741124935816835 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.25103568316918,-67.87439326967542 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-39.266625674993755,8.097160773522248 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,3.944304526105059E-31,-12.055610572244241 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,3.944304526105059E-31,33.86874192049504 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-3.965534120805702E-118,-0.7840804609233656 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.0209751137233455E-17,67.06890695778162 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.0806227658457795E-16,-1.5707963267948963 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,4.086276345412611E-30,1.5707963267948963 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,4.148851944256286E-18,0.0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,4.163674130042716E-17,31.667604364875878 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,4.2351647362715017E-22,1.5707963267948966 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,4.2351647362715017E-22,-96.94458419682014 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.307356087989045E-34,-53.657075153382685 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,4.3368086899420177E-19,-41.31009185111423 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.3368086899420177E-19,45.55308506665048 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.3368086899420177E-19,-47.08235373682014 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.3368086899420177E-19,-4.710855854947407 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,4.345498733342683E-19,26.556475607168778 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.379168224980197E-15,-50.20425313479524 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-43.982297150257104,-100.0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-43.982297150257104,-1.5707963267948966 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-43.982297150257104,-1.5707963267948983 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-43.982297150273006,3.1415926535897922 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-43.98230402108779,-1.462352202707782 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-43.98230548821704,15.707881381329855 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-43.982523556582684,-0.1662560801977821 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-43.98264534181773,1.5707963267948966 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-43.98271230790464,77.18868633911836 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-43.98272590295202,-49.93299261842242 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-43.98306916589743,1.5707963267948966 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-43.985812102380486,-1.5707963267948966 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-43.99385442267267,5.058534537802014 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.00622353519172,-1.5707963267949197 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.033745986396696,53.33503957198309 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.051645793536984,8.470329472543003E-22 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.054393530395785,-90.11823559253199 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.07197467205426,83.58705528090545 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.09875120420237,-1.0671261188230469E-14 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.099958402983404,1.5707963267948963 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.10212162247142,-1.5707963267948966 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.10363125945188,-1.6791276808955047 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.10755565232127,-28.178855615918707 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.10847986420943,-31.271989957374398 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.109428187413315,-1.5707963267948966 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.115109394237976,24.33018344357232 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.12351280287754,21.14276520339884 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.12829848636193,4.528975903341177 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.130136312965284,-1.5707963267948966 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.138150740339526,1.7866889807219621 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.13835820009069,1.5707963267948966 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.15757028754121,1.5707963267948966 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.15765479601454,66.08424000464262 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.162733332424324,-27.719353020794223 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.17149391318535,-1.2149741174204107 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.17911638432862,1.5707963267948966 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.226619820323336,-4.712633593213268 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.23424775735477,-41.98754262179174 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.24907471213101,55.173564193265946 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.249777114507175,16.129364348841037 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.263632429589826,-3.2665926535899272 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.28547276380405,1.5707963267948966 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.29353438906338,1.5707963267948983 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.2985304488078,-1.5707963267948983 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.29982493786454,1.5707963267948966 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.31309514570052,-12.041610419210548 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.31938829774629,-72.21186819813715 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.33779616466642,-20.506681039134566 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.3444395637755,-2.3213340099367134E-17 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.35181555397496,1.5707963267948966 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.35532668717224,-1.5707963267948966 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.360879742572806,-74.95266789226064 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.36757529369126,4.61626705072251E-15 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.36781415068084,-3.266730020143068 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.396269234062274,-35.347480359729374 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.440892098500626E-16,-59.7783906784127 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.42178007811641,124.25084578525042 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.430203764709354,-1.5707963267948966 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.433914398853084,64.67069268611203 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.44185434149616,61.28546536707782 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.445462388333695,4.743638980469584 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.44961103487783,55.83395076332385 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.449848395763595,5.072452438674063 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.454053640731686,1.5707963267948966 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.463167888886325,-4.712401659504142 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.48173041838886,-1.8878491181167751 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.48955349914817,-29.536958702028492 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.49109395928341,58.869173546487744 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.49266290483007,-100.0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.50776735636675,-90.46169839012987 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.51117248615815,1.5708001414930541 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.511882170327965,9.981118520524184 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.51731623756814,-34.71270085471366 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.519287957318035,-127.97269340270174 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.51946892741669,-3.2665996663341916 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.52512963664828,-1.5707963267948983 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.527801459612505,-3.2666030404722073 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.52997396871619,1.5707963267948966 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.53892918036361,-3.2680167643089417 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.5390219493436,-97.58847239288917 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.53949094522082,-48.144375472985296 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.5479161690844,93.79090965131441 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.466792678881544E-16,-71.261674348521 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.983149136330304,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.984577711220595,80.56624516860713 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.984600286768085,-35.21701346047112 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.98529696414252,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.988797945778,-1.5707963267931988 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.99318388769721,-49.03887231882331 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.99609412463856,-9.317647080012193 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-44.99792808066276,-78.28257002362216 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.002362529450565,-91.7778972661022 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.00689337537881,49.53959467216117 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.033620859178654,1.5707963267948966 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.03727080036857,-1.5707963267948966 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.04333515995455,1.2709902300929223 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.063178313756616,-4.7123893409914075 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.09217660618223,-1.5707963267948948 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.09319676817608,52.639136037359776 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.09461706917362,-18.4245616215928 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.09971320590527,-1.2785952037321011 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.10903074397142,-83.60034016797793 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.10932486182594,-4.712396609780546 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.11848066027304,-98.92050488832662 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.13023081003826,1.5707963267948983 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.13461524912955,0.21794497927988932 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.1442535740064,247.82172529519386 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.16089122055986,1.5707963267948966 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.16918814165484,-55.14520394640916 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.180278508720775,59.475505944092326 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.20610689950328,-28.199726267644095 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.20699982559372,20.88299554591073 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.215521615228596,-1.5707963267948948 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.219996881347434,-69.10851316923423 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.22021049211115,66.41995120186813 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.524370030471582E-15,65.42724541840893 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.258671099791115,-49.90656638313326 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.27331101022534,1.5707963267948966 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.276122039048396,-14.446818685680281 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.29299038797656,-40.175118014042795 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.29887972130497,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.3181381555022,1.5707963267948966 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.32459066850887,1.5707963267948983 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.32698585149108,-62.96572925211563 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.3272962698431,-1.5707963267948912 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.33792240494061,-3.1415925705012455 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.338550165076406,-1.315797915244333 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.34100903080971,-5.248340709036788E-141 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.37388523768642,-0.04151754143108809 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.37469606397194,-53.065801639048814 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.37645532040096,5.293955920339377E-23 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.37897778673027,90.06118559769479 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.4008958829117,59.5343283832147 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.40138151927131,-0.8821253542707939 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.414229153109844,-90.04636506017303 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.41750658607572,9.913556707208294 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.44110759326084,-17.702501962300445 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.44925471723681,-83.2650466042406 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.45813619074761,-93.5192928042384 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.46098822495767,1.5707963267948966 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.48195112687954,-1.5707963267949054 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.48545902403327,-31.022082253337047 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.49679705666626,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.513438515156544,140.37481095850347 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.52212659023767,-66.68481229228456 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.540995566254274,-4.938299120771099 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.550143983924045,-5.455549640456073 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.55309347670558,-0.7270659676917602 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.5530934767248,-70.99679273800852 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.553093476879006,48.98743500702181 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-45.5530934769024,55.09440575757757 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.561816081569358E-14,-103.67255970484676 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.563373359881659E-15,29.71988539210261 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.578059132842013E-14,36.12880386293444 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.73515224053035E-15,41.661185384753935 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.9174654257559707E-17,64.1128946757114 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.921294469867605E-14,31.625638939356328 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,4.930380657631324E-32,1.5707963267948948 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,4.930380657631324E-32,-44.84530203551754 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,4.930380657631324E-32,-56.59893696387919 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,4.930380657631324E-32,-72.35613963611199 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,4.930380657631324E-32,-90.30176536586116 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.9355158837307067E-178,-1.5707963267948966 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-4.969915671667799E-9,59.690139314375784 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,5.141592653589798,1.5707963267948983 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,5.141592653600499,-1.3121017881659427 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,5.143598321440256,-1.570796326794896 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.15442274765351E-7,160.31384481915967 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.293955920339377E-23,-1.5707963267948963 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.293955920339377E-23,-65.97344572537686 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,5.293955920339377E-23,97.62226508032889 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.323445298469577E-13,1.5976518313123051 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.351881368358884E-5,3.2665926536281393 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.382858070931019E-15,5.49248976392589 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.421010862427522E-20,-47.386058605909355 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,5.421010862427522E-20,-99.99989917189144 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.4266571032350524E-166,-2.426529808840614E-180 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.436778584284399E-10,-1.5707963267948966 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.4795233725210076E-194,-5.116224130669404E-279 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,5.551115123125783E-17,41.18625948051002 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.551115123125783E-17,55.81011036524515 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.551115123125783E-17,84.82300164722766 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,5.551115123125783E-17,-9.792588452083834 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.57317256428759E-16,56.37932041118532 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.611031933461512E-191,-62.048126242182974 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-57.978199757330685,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-5.998787255582524E-241,1.5707963267948966 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.0087337469170356E-15,-43.18269282732621 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.012497869181594E-23,-3.1415926535901058 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.022166590976672E-17,-3.141592653589793 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.106724116542066E-15,56.463673162492285 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.1098727269992094E-151,27.559271462085334 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.169394854663383E-179,-7.691032581805693 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.281108957353538E-21,-87.28531167072482 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.3108872417680944E-30,-29.149265192562638 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.3205108257818484E-15,-3.141592653589817 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.376760388117256E-14,-4.9355158837307067E-178 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.505249847750281E-18,71.87939307653195 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.6174449004242214E-24,1.5707963267948966 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.6174449004242214E-24,4.688483490476592 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.6174449004242214E-24,-65.4026493985878 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.63361490323907E-17,4.180520852326181 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.69334069234538E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980384691,-100.0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980384691,36.612710516834206 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980384691,-38.59407472201661 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.7123889803846915,1.5707963267948966 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.7123889803846915,3.238090767213904 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.7123889803846915,-50.67717817820701 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980384691,84.11456846025698 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980384694,-21.748490321805832 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980384696,-1.5707963267948968 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980384697,1.5707963267948966 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980384699,1.5707963267948966 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980384726,-1.5707963267948988 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980384728,-62.20260714712494 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.7123889803851275,67.45695541109912 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980385308,1.5707963267948966 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980385531,81.185700100334 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980385731,-47.83496539921614 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980391206,-8.093144785944986 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980397601,-60.72937057040592 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.71238898041981,-98.65549158105019 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980473685,-38.41746825578873 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980496447,-5.478852451038653 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980521179,-86.12047481446028 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.7123889809472885,2.7445927710678273 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712388980998576,41.641703289882095 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.7123890078115345,-1.3131831168861379 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712389027959785,-17.940325718057867 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.712394131185801,-83.60014527072678 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.754034012229084E-226,-52.38283223132923 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.776263578034403E-21,1.5707963267948966 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.776263578034403E-21,21.99109958721659 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.776263578034403E-21,25.013984004094226 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.776263578034403E-21,68.91569407340246 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.876994468399003E-15,77.97126576496312 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.938893903907228E-18,-2.570796208958606 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.938893903907228E-18,-29.207977376306047 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.938893903907228E-18,-42.17906629130235 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.938893903907228E-18,-45.334444036558324 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.938893903907228E-18,-49.39564634852851 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.938893903907228E-18,-56.05877573012419 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,6.938893903907228E-18,67.11918010265589 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-6.990010737668685E-7,36.19081851912391 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-7.01378991682689E-192,87.56101863903108 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,7.048502129032737,5.046574748890944 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-7.099747671446209E-15,-28.679647836015576 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-7.105427357601002E-15,164.81538022619242 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-7.112794327571963E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-7.470895192715073E-16,96.58801698792134 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-7.494377759601657E-4,-44.08155395538428 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-7.498484069478155E-242,0.09450164357736139 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-7.57550211531956E-18,-55.811809684301515 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-7.598528409219259E-17,-4.363064144379763 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-7.604366265180639E-211,-58.28672362079145 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-7.650578451021058E-16,47.05362739012624 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-76.90347911548209,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-7.788663020396097E-14,44.37118856975238 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,7.8539816339270825,-29.829852999826322 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,7.853981633974471,-86.06258400321684 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-7.870922637762077E-15,100.0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,7.888609052210118E-31,1.5707963267948983 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.231261469754608,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.258117374795985E-16,94.72093382159278 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.264763275066699,53.302701631331075 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,8.271806125530277E-25,-1.5707963267948966 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.271806125530277E-25,84.82288375490404 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.328960400422052E-17,-93.36626218725567 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.410319241806417E-17,19.384273713741496 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-84.27718323709763,-98.31135189172494 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-84.48959097239845,-114.86474309740424 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-84.588801464186,-1.2551244140216238 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-84.62974580905086,67.223243569405 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,8.470329472543003E-22,1.5707963267948961 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.470329472543003E-22,47.12145508037168 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-86.22470383995582,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,8.658011773596307E-19,0.0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,8.673617379884035E-19,100.0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,8.673617379884035E-19,-1.5707963267949 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.673617379884035E-19,24.580185092790046 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,8.673617379884035E-19,25.991963592539747 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,8.673617379884035E-19,-32.73305209999186 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.715254460556086E-17,-50.08799556572825 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.08959430051422,53.77962490695819 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.10625422387665,-1.5707963267948961 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.16684872762988,-52.50943002183828 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.16950167241639,2.465190328815662E-32 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.17081635951689,-0.02683182917626392 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.17525224667213,-99.5351896192856 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.1804593982127,0.4303858998288233 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.18215894496096,-41.321556766156256 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.20856846940147,-37.45991036961627 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.20994536392081,-12.231653544458965 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.21790494258302,-67.84599652005745 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.22201580216142,0.0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.22891397799944,-96.62350741730748 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.2332430967059,-0.3608199914887602 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.243517220082,-74.16023647369579 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.2437653415937,-1.5707963267948966 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.25815027164407,87.17249903351285 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.25948536015665,2.547535345416468 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.826695451255986E-19,-29.845130229987788 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.27402023395656,-14.429203844461853 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.28598639299608,53.799920226643586 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.28922510027766,8.032879922189636 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.31720382734173,1.5707963267948983 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.31958372880078,4.389336143168293 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.33394409367718,34.579167154722775 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.34768226311785,0.012608830719284966 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.3597169775587,0.14732917132010354 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.37044996641886,61.58059249876544 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.37453714868788,73.74723608770722 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.37771101935891,65.14579286860229 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.37829165491391,20.797761957549014 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.39695355699708,8.067401386991339 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.40012384357719,-0.7517042229712172 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.40238357480672,1.5707963267948961 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.40607475967347,-63.98095705527367 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.41154293754872,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.41502818376377,67.37283450304815 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.4161826005229,78.20191504106134 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.41981581116794,-92.16674502456277 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.44366480818258,4.4240898303837755 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.4438192121448,-1.5390853204717812E-15 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.44902544952741,-1.5707963267948966 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.45928002455585,-1.5707963267948966 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.46034831173237,-1.5707963267948966 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.46668015700683,-97.98392291293082 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.47899319098421,-16.484361761853318 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.47938292610863,-1.4803529817620997 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.49159490067079,-1.5707963267948966 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.5064693126786,-80.88297202444826 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.5184375590556,100.0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.52263127888115,-77.22709151408402 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-88.52409236774066,32.672087069221185 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.852640726374122E-17,-53.407075110923365 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.854274943395011E-26,-83.4270751648573 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.881784197001252E-16,-0.2874557267840408 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.881784197001252E-16,-1.137099868076418 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.881784197001252E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.881784197001252E-16,-39.00463781172432 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.881784197001252E-16,-4.391828616118055 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.881784197001252E-16,55.424456655924445 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-8.881784197001252E-16,-75.7746780535081 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-89.67765719985401,-3.11645438155125 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,9.421407228902094E-17,-93.44166014421327 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.2477796076938,15.506533456083375 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.2477796076938,-3.2665928648081928 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.2477796076938,-47.44670039411953 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.24778609509823,-1.5707963267948966 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.24778636262941,116.21519943594507 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.24988647271054,1.5707963267948966 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.25120880527054,-0.28548489555601736 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.26117411966908,-1.5708001414922785 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.26822220390079,-1.5707963267948966 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.26976548483245,1.5707963267948983 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.27049983671563,59.436092709277446 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.2755825660302,642.6978236364865 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.28693779760214,81.44865815385089 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.29412910649549,-1.5707963267948966 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.29735801904049,53.091965898984 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.31459597504895,-1.534456095309937 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.32985682625757,-1.5707963267948966 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.33118125738588,-100.0 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.34300919465298,-59.123992784032495 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-94.35531766621233,-0.05986393317195748 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-9.464417489334198E-271,-99.99999999999989 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-9.479652699814495E-21,-3.141592653589793 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-9.48923988750392E-18,3.141592653589793 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.24777960769413,-72.24133904560155 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.24901847118372,70.77509963885826 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.25118058584084,100.0 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.25584090232509,53.80783023570458 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.26022318429338,-3.2665926535898095 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.26471527760813,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.28976256417178,1.5707963267948966 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.29723988462608,96.11552822065794 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.30507730325695,-0.8226118826852468 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.30786162216063,-56.35010390209015 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.31911054348569,-74.39749692713579 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.32356112234613,69.8307464349844 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.3319948466224,-20.781679586657855 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.3425111479639,10.539029664011565 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.3505647004809,53.66217827718705 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.35498874174401,-3.266592654091938 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.37445597859224,-1.5707963267948966 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.37547613351651,4.930380657631324E-32 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.41114999208727,1.5707963267948977 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.41799236490374,-98.68686254787536 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.41957737034195,-448.65744494707127 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.4273428590661,2268.3576568675826 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.43039049105245,59.59712011576059 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.435705245341,-95.33754641666532 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.4371883513619,-72.20532935622957 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.44509627409191,80.1524305939815 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.45805481254091,-59.49706664953398 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.46638295358234,-1.5707963267948983 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.47354746317325,-71.12502281719107 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.49009065930514,1.570796326794898 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.51411978280274,-85.50256389504297 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.54204210779666,-1.5707963267948983 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.5504827455907,-64.86332093770977 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.55152419525967,-94.4661083984555 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.57178081597128,-1.5707963267948966 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.57281061048872,82.2352794391694 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.57291666388525,-49.736685419652346 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.57738006207755,-21.49571941169569 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.59875018394405,-72.04541667294944 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.61956187510334,-89.62417035663941 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.62415498266175,-1.6332963268717635 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.64465085248041,-1.5707963267948983 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.64492742033529,28.61293587025827 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.66895055865747,1.5707963267948968 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.67656293268345,1.5707963267948966 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.69104189289304,-1.5707963267948966 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.69104549870224,4.839778029402148 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.69564720685783,1.5707963267948983 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.72163452718179,-1.6332963273283947 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.74956097643057,-3.1415926535897913 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.75626536957635,44.1056699358051 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.75646880057872,-63.16708702587915 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.76468220690222,76.5891344704956 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.79755636462355,-3.141592653589831 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-95.81612562243036,-1.5707963267948966 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-9.598059608932038E-240,52.254698195675346 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-9.73551111018142E-15,97.3893722602719 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,-9.801133046325211E-7,109.95295618945639 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-0.5379508328675255,-179.5603557914981 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-0.7440037350402787,-185.4700998861381 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-0.7561359614460561,0.26390000126917623 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-0.7958524180901851,-1.5766272972744133 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-0.8998215553059246,-88.5560678586374 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.024313125181382,-6.712388981104087 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.556972962106919,-1.5707963267948966 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948912,45.99791306492668 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948963,1.5707963204560582 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948966,-10.001904425662005 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948966,1.035265667777564 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948966,-123.22099250063798 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948966,15.722850602920445 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948966,-3.2665926563167607 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948966,-40.369375396377194 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948966,4.712388980385827 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948966,53.89429103738154 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948966,-54.095514722760086 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948966,-55.39986113631308 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948966,59.67518378832918 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-1.5707963267948966,72.32271122041286 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-221.04857791767137,4.858806515477172 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-2.465190328815662E-32,1.734723475976807E-18 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-31.41592653641037,-17.279761618889538 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-31.415927305846413,-1.5707963267948961 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-44.40906361079989,27.35460015266331 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-45.09565198836829,9.517587433765556 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,-45.11013111632458,-1.3632271911360228 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,6.712388980385226,-1.5707963267948961 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948968,6.71238898039639,1.5707963267948954 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794897,-0.12368246201768274,28.476136559895203 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794897,-0.4181354710059111,100.0 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794897,-0.5439249245894617,-4.743640350185281 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794897,-0.7317416473220406,-0.09279667103886398 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794897,-0.9686872641644092,-30.137115916628222 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794897,-1.0979812060408871,16.8094082929604 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794897,-1.5707963267948952,72.9126326764095 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794897,-1.5707963267948957,70.59990793997693 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794897,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794897,-158.6329536821785,79.40172897321344 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948972,-0.7959584878142696,-6.712388980386016 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948972,-101.75010966816286,-1.5707963267948966 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948972,-88.28426807855143,0.0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794897,-39.161859864812264,123.89845766177262 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948974,-0.3978132182372033,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948974,-0.5131212164813108,-86.09986273672546 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948974,-1.2572960570395297,123.06244501336667 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948974,-1.5707963267948966,-0.8692294865174958 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948974,-1.5707963267948966,22.034159489834565 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948974,-1.5707963267948966,-83.26601322243226 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948974,-1.5707963267948966,-98.92850956113463 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948974,-1.5707963267949019,52.74917780446347 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948974,-2.220446049250313E-16,-372.2711524657005 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948974,-32.70213069859652,1.5707963267948966 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948974,-77.13528825753437,-62.16336386846156 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948977,-0.09528557555306984,-123.18048664079419 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948977,-0.4004653723934468,-260.721923680992 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948977,-1.1102230246251565E-16,1.5707963267949157 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948977,-1.5707963267948966,-119.38027815913986 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948977,-1.5707963267948983,134.05790150671237 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948977,-3.1415926655518818,-39.08134777983355 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948977,6.712389001733671,-1.3896467789875946 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794897,-95.29126731149194,73.75196084788442 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794898,-100.72056167602129,-23.517933013592113 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948981,-1.5707963267948968,-9.904982476703205 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794898,-1.5707963267948957,-2352.714161506292 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794898,-1.5707963267948966,73.50949515431489 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.004678874118853167,1.5707963267948948 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.015014358728358053,-101.65059261029718 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.03426854485140951,-76.08057092789873 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.042961238027057425,-442.87825603468764 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.06948540124351332,0.0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.06988958085736385,-172.1799995798887 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.07296299876643886,44.362636260681825 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.0748111285458461,13.960577702631042 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.09444714389141616,-22.006720074347104 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.1757205993040465,51.79514262899462 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.22821937687049854,78.23963188277659 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.23954555984439185,-1.5707963267949054 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.24853974922399402,-24.58759265530331 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.3072550555582714,42.925259462426745 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.31495500555018563,-1.5707963267948966 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.4204207658576901,254.38030694984474 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.44175692201875083,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.4960298392002009,-357.8294603043574 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.5321490727927856,8.892170846930156 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.5758416984662524,-73.40659199174448 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.5972530151370936,30.51876096088222 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.6665264290625572,0.0 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.6666047842425256,666.0068126593126 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.6820938438596961,1.5707963267948966 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.695576165146019,-25.73399003203616 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.7062849101972795,-100.0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.7514697716819967,4.896777894964809E-15 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.7752829386105904,67.59204356413437 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.8111948862828773,93.89348162167198 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.824468800190566,75.19849148465997 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.8874728468345241,-17.27925030315964 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.9452047450143031,38.81504141720101 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.9458390639440263,-77.50828441978297 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.9763343059975131,110.21033245963524 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.9818555013214576,99.13758858949873 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.9915875912444294,-46.44665153184479 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-0.9971602236092565,32.89970908239667 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.0004212678553976,-37.585410219825086 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.002189014122953,66.06244647461543 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.0078846071492895E-14,-156.8209761339234 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-100.83356204931141,-0.545608415051352 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-101.7273685607448,-95.83117793024189 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-102.03061517212704,9.705675033272954 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.0622033242034778,28.60385698019963 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.1256489938958651,-11.851468633544911 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.1292128879172978,-45.324349437445164 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.1350233890833141,-0.06430138253310265 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.1635318731377051,-41.32950581823391 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.2044324624769036,-39.339832397372795 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.213460432166757,4.685328983803499 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.2460171303387964,-89.89951401552905 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.2527617397748294,227.7654434597906 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.2657714863742626,-3.4156039310622646 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.3194981499377007E-15,-45.92446085489736 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.3477701029133078,49.226268837997736 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.432919291040423,1.4992699952932607 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.4486385415100154,-3.1415926535897953 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.4697190482766547,-122.66177555151415 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5093096169620437,21.76245587238921 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5310671001369083,-58.17404018052051 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5310966771619647,-1.5707963267948966 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5375101691371371,-546.1399146467162 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5694539127155922,132.48573808192646 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.570796262909253,-1.5707963267948963 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963262919153,-63.235354710847176 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963266726437,0.0 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948521,-71.85460948398963 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948841,-1.5707963267949054 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.570796326794885,9.40499179167481 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948912,-123.62438743857581 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948912,1.9136082888621555 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948912,-30.530822450295474 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948912,5.9449788482946175 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948912,-59.73189139979627 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948912,-93.40199519328345 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948948,1.5707963267948968 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948948,32.89635874540255 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948948,-5.366009157950387 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948948,82.40188033858496 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948948,-98.27456868458475 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948957,-74.54408102294202 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.570796326794896,-0.8197003931821598 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948961,1.5707963267948983 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948963,-4.205588551855474 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948963,56.014026721260336 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-0.34247494263098355 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,102.10176118291245 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-12.56340313995975 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-12.764085717056844 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,1.3251370976390848 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-1.4734840500958981 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,1.5707963063230137 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-157.64840244311873 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,186.89964262138813 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,21.2170409913157 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,26.1170405130464 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-34.97515373627881 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-35.96329147031926 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,397.91121565793384 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,4.459691697881851 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-45.02366850582719 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-45.44386238146231 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,58.720584901424445 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-58.917802083057836 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-60.376401812235365 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,68.39294915803055 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-69.12351961681227 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,69.39488904603178 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-74.05094948612602 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,74.61896914584598 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-7.666866863140626 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-77.13113345478438 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,809.172976774819 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-88.23503162926842 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-88.41594825547587 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948966,-90.0917821254619 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.570796326794897,-1.5707963267948966 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948983,1.5707963267949019 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948983,-16.645843467905095 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948983,-23.53468644248686 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948983,29.60194586575379 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948983,32.966023127442554 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948983,91.26930653398134 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948983,-9.579357058395772 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948983,99.50404625750215 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267948999,3.229161082164797 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267949019,11.587143149881513 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267949019,31.907362341375862 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267949019,71.91332901989635 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-1.5707963267960228,586.3400340402375 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-157.22251585740364,-24.325518083627145 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-157.64922002485434,24.35462484312523 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-163.56443292836744,-36.07463233213038 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-163.65313133730263,-77.31381916652862 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-164.53452536010914,-1.5707963267949054 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-31.415926535900503,-71.37328087675496 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-31.458104563183966,-12.10704065760791 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-31.468804154839088,758.7838096252094 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-31.514423181573655,60.75128792152529 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-31.57464775029334,33.250549977217325 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-31.593453888836947,-99.73324115357933 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-31.84958351550827,25.088535451793888 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-327.2531000922579,20.444044121787513 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-32.81499016910885,2450.37771211423 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-38.72166525626889,-31.21848633462763 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-39.13011263982844,-52.16845395057056 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-39.26904444056751,-74.4848977936762 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-39.26990816978507,-1.5707963267948983 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-44.211218520980275,1.5707963267948966 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-44.24948211406943,7.105427357601002E-15 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-44.36406750207142,-123.782348555353 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-44.373526281436206,52.29368073823045 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-44.50922448177185,-1.5707963267948966 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-45.2707201403985,100.0 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-45.55309347582507,-100.0 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,6.7123889805666845,53.730678394376476 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-83.37067221294711,1.5707963267948966 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-84.3578449171406,-1.5707963267948966 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-88.08959430088404,129.0403151858685 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-88.3690237122966,-3.8038887260747085 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-8.881784197001252E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-94.32719765476601,1.7563559944145055 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-95.29478381139637,-21.05687348973305 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-95.47973192756346,72.11317075382425 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-95.78808736522777,-100.0 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948983,-95.79463135779993,-77.94053487294445 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948986,0.272574198883348,-64.65624712050972 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948986,-0.877070083877849,31.415963785786033 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948986,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948986,-1.5707963267948966,292.73889807029724 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948986,-1.5707963267948966,33.43139459756266 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948986,-1.5707963267948966,-87.72674421047263 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948986,-1.5707963267948966,-9.560232508557817 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948988,-0.327350917512025,55.46570227143606 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794899,-157.57191811154732,-1.5707963267949268 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948992,-83.28845816928212,3.469446951953614E-18 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948994,-0.45357377454135417,190.37717003221167 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948994,-1.5707963267948946,-835.5027763901223 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948997,-1.5707963267948966,-0.5129094438343269 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794899,-88.27073039436479,-1.5707963267948966 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949003,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949019,-0.19534787259349057,30.143400736477243 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949019,-1.4186679839381444,94.31977320112907 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949019,-1.5517663072138344,-3.141592653648001 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949019,-1.5707962893935383,-38.87051937181856 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949019,-1.5707963266389129,-23.049447715687506 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949019,-1.5707963267948806,-93.52205628593806 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949019,-1.5707963267948966,-1.262322582683463 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949019,-44.22140254988023,-84.51555104554402 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949028,-1.5707963267948948,92.76087621688083 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949039,-1.5707963267948966,14.42950117604451 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949,-0.4692191771454973,123.59937476134542 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949048,-1.294108112566832,-172.65565852568807 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949048,-44.03295541161053,-16.39228388340112 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-0.18224147441285976,-66.50721517213789 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-0.5265395940363262,65.86392598829352 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-101.5382393631208,-57.68458501259189 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-102.09952200760195,-114.90754455900304 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-1.5707963267948912,-86.96902484703762 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-1.5707963267948966,17.549983209670913 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-1.5707963267948966,-545.1354020058601 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-1.5707963267948966,-88.26879357150857 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-1.5707963267948983,-102.10176121067833 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-1.5707963267949054,-24.675801448139765 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-31.75470668197147,-68.52034326357821 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-32.68894675911376,-1.5707963267948966 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-44.268272683820186,-4.904495154311147 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949054,-95.66694795000008,0.4814294107192554 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794906,-101.89697217830869,-1.1497583782208665 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949072,-1.5707963267948966,2330.330944816484 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949,-102.03606713766068,59.19659701516301 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949,-1.2508747208888353,347.1290715337198 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949163,-31.558496410300585,9.424777973931018 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949212,-0.02161459750290229,129.90920046128934 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949316,-3.1415926535898766,1.5707963267948966 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267949623,6.71238898181349,-153.1945334189517 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326795009,-31.545645678204338,-148.4153269832155 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267950926,-1.5702289934724212,100.64397396333423 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267953595,-1.5707963268150005,-31.415943297666864 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267955731,6.712388980385594,9.779167236884858 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267967244,-1.5707963267948961,163.39028122495887 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267968434,-0.39216689439951385,127.83801314445105 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267979486,-0.8550910898881325,260.88846567328346 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963268133955,-100.53229695374627,-35.725209284061506 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963339100206,-1.570796326709575,-108.16039061957937 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963361640902,-1.5707963267948966,1.57079645330933 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963398633744,-282.74618698842323,90.53538674085767 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963418335789,-1.5707963267948966,-354.99917133645846 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707964746860106,-1.077452302272423,101.85438466355622 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796595129501,-1.57123784547891,112.845152163011 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark06(-1.570797340534136,-1.5707963260769153,-226.6498529812052 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079753494761,-1.5707927162539528,-178.07119996309208 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707988397076258,-1.5707945363275257,110.4535566535131 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark06(-1.5708111804211733,-270.61336737115306,-89.99493383553083 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark06(-1.5708163910276236,-0.6761617195779388,-318.8748591153957 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark06(-1.5708166565438797,-1.5717319209182983,-318.4562133056619 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark06(-1.570831041459912,-157.42555924178697,17.28769126863599 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark06(-1.5708351401342542,-31.977169185945833,-732.9395864221983 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark06(-1.5712684721033192,-0.2905518809013846,10.707442729613092 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark06(-1.5714873521352143E-16,-88.2310503860095,-80.2378294529871 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark06(-1.571493210625709,0.0,-11.346363273857122 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark06(-1.5907767780211585E-9,-32.62156711300191,-198.485273299488 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark06(16.171863256073664,33.29570587725223,14.820020555337237 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark06(-16.433063317753565,-46.915531685121124,42.90228803885597 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark06(-16.604069731147277,0,0 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark06(-1.6623847952375027E-16,-31.82822042863195,-1.3501226855758746 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark06(-1.6940658945086007E-21,-0.18555789580486567,1.5707963267948966 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark06(-1.6940658945086007E-21,-1.5707963267948966,-65.96452739235927 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark06(1.6940658945086007E-21,-1.5707963267948966,66.02097581808192 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark06(-1.6940658945086007E-21,-3.469446951953614E-18,33.05166785839356 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark06(-16.958796664957816,-78.48403450533037,-25.85632862286053 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark06(-16.98341129677368,65.31557401975962,97.45086048615138 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark06(17.161038125424312,-66.02589218299494,-12.329658740926774 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark06(17.322682735042633,89.81414493575392,-94.41489793657726 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark06(-1.734723475976807E-18,-0.03379841307220448,-60.64967838714996 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark06(-1.734723475976807E-18,-0.09707939302097579,-69.93179611254668 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.47486991625492,-53.910762025024184 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948966,-3.5252914137906252E-15 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948966,-55.50848024383337 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-32.48817466631118,-0.6356877396498859 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-38.91138531322968,-1.5707963267948912 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark06(-1.734723475976807E-18,-44.225103806943345,-14.42921543734851 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-44.252666750538225,70.73486759312385 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-45.06814919204053,-64.80659598514305 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark06(-17.658827651392883,-82.22700680818491,78.134139602 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark06(-1.7712893440387232E-15,-1.380407854097187,65.19760630244505 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-0.6342210346130214,76.81248692924488 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark06(17.839833071880776,70.39733459671729,-23.25978967912583 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark06(-1.7941755315560926,0,0 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark06(-17.96760634887795,19.819803854230372,-38.76823863035837 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark06(-1.8188946371115664,-88.46241077350312,-69.09423589375191 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark06(18.695658085792388,46.13704537141618,-35.44084060229655 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark06(18.74013340644838,-47.03770122460962,19.135118751790586 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark06(-1.8858208753717207,-77.7664109532221,-41.25613795212833 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark06(-1.898427258237362,-91.30648820773297,-73.80556604674865 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark06(-19.07039957474761,30.906820570926698,69.98861890469675 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark06(-1.9242345664787024,10.454547578651542,20.305457314905937 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark06(-19.265169605228905,-68.16304218239111,-65.4286580119608 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark06(-19.67217352936548,7.562953908298354,-22.960222215195913 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark06(1.9721522630525295E-31,-1.0211788286643255,-20.85430091310443 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark06(-2.005424085516751E-10,-101.00988456972325,16.065462196171936 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark06(-2.0140131221633766,-30.226143146962215,-89.56776454910731 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark06(20.580992265727247,58.448038450088575,-26.648463515805673 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark06(-2.0679515313825692E-25,-1.5707963267948966,39.1799513748708 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark06(2.082230589322779E-18,-1.5707963267948966,-10.515852413095487 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark06(-20.861341133985235,-67.38243199841506,-30.196072672824243 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark06(-2.1007711646096424E-19,-31.764025953720616,1.5707963267948966 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark06(-21.13087404821681,-86.9792078767689,-82.96427464568355 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark06(21.156127251421978,25.384245721676876,-67.62206943384442 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark06(-2.1175823681357508E-22,-1.5707963267948912,4.399777938041211 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark06(-2.1175823681357508E-22,-1.5707963267948966,-62.652669265814815 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark06(2.1175823681357508E-22,-88.4428341106293,-100.0 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark06(21.181746552491035,13.408626720918804,75.27759146629819 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark06(-2.164072971879321,96.20976028182332,50.997629918445455 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-0.16936870448647298,23.844426539061597 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark06(-2.1684043449710089E-19,-0.7665793358136528,-6.826345101706252 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-1.5707963267948968,0.23959639669235674 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-32.46558750661423,-24.82083855707118 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark06(2.220446049250313E-16,-0.21951308749668488,30.934491418548646 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark06(2.220446049250313E-16,-1.0744535698514766,-3.910234019910179E-15 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.1689941866633842,-1.5707963267948966 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.56980421461075,54.78150495871684 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,32.936391581016125 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark06(2.220446049250313E-16,-39.02122083993809,-14.429220017475586 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-45.503401235912406,-10.906822340405313 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark06(-22.918388541008255,0,0 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark06(-23.368443065732265,-96.97532732795536,19.561944867768304 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark06(-2.356996830241852E-15,-1.5707963267948966,14.429249179193135 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark06(23.782397280807615,58.2008420510864,-5.74618832672445 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark06(23.9016911906494,-92.68680419780357,60.920194672419484 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark06(-2.396582080884141E-18,-1.5707963267948966,89.99427018849136 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark06(24.305854991673172,91.09560431034015,22.545796170093112 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark06(-24.327873619511337,-75.37728969002026,0.4506500432343614 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-0.008996857739626468,0.07673952980456603 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-0.16053941350083367,1.5707963267948963 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-0.3111672808905377,-1.5707963267948963 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-0.3671753998555832,-45.43128403318185 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-0.41700230184975523,69.03317001731074 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-0.6643206891709267,78.38183345563382 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.2192172197870731E-4,9.920531027231277 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.3802874993634358,-16.555893129472572 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.4407093805924982,60.10748961628275 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5025941241862733,-40.038179974729104 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,-0.3604910436856482 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,0.9945355495883302 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,13.895939279180304 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,27.88333879064277 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,-29.327631021471888 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,-30.0938086593641 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,31.66550380182136 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,44.62773763657939 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,-45.996813810316986 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,95.89097801179085 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948968,0.7200412939981877 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-31.734401887552735,-17.27115481507701 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-38.810678874711314,-89.17298157719452 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-44.053587872339186,67.03331513127748 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-44.14238869090804,-1.5707963267948966 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-45.08558756440503,-68.2914798533549 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-45.2082909384509,100.0 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-95.50485743875812,0.6771005097821055 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-95.5535633238196,88.24510735364672 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark06(2.470302005708448E-20,-1.5707963267948966,14.317835995010524 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark06(-24.718316055276674,31.770091526845192,-12.245130788011664 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark06(-24.808847644391392,82.93500063881714,-0.5246916384724898 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark06(24.864362596488476,84.76868572895344,-12.989138557034835 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark06(24.8853672036838,-12.458380977522793,89.71411694893214 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark06(-24.911664087176888,-1.5704205241263196,-27.776840805293986 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark06(2.5018481184441498E-12,-1.5707963267949,-14.849411579519481 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark06(2.5243548967072378E-29,-1.5707963267948966,-88.24392145103117 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark06(2.5849394142282115E-26,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark06(-2.6061948595121436,65.39064309908599,60.7243950508512 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark06(2.6469779601696886E-23,-39.08973450132294,1.5707963267948966 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark06(2.6469779601696886E-23,-44.98952106752599,-31.45962037655223 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark06(26.496709434852605,91.60541041867535,-51.39970628817441 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark06(2.6911440050348716,-79.12863108440649,-35.40841781949548 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark06(-26.937800258423138,73.96709374098134,19.416079363768787 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark06(26.972828387452964,-60.5467640547902,64.4271446701427 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark06(-2.710505431213761E-20,-1.5707963267948966,-70.64743686289579 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark06(-2.710505431213761E-20,-1.5707963267948966,7.638820976534742 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-19.360676118628,-96.89110241099168 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-39.017315640601005,3.7649149065184204 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark06(-2715.0309244414007,0,0 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark06(27.29242132902165,-83.46848892826748,-41.30027308063544 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark06(-27.33120912557135,92.11953482140561,0 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark06(-2739.7540458757853,0,0 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark06(27.582011687412503,-11.994724662940428,-46.97334423310937 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-0.05573576053304911,74.95791783097629 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-1.1754414722233835,1.8999070799766784 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-1.5707963267948912,2.4583977234961747 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-1.5707963267948912,60.2223960371946 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-1.5707963267948966,-29.922333218985557 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-44.21865069398169,-31.54783466394389 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-45.140727864472915,4.804675802551884 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-88.37424400384175,-0.8545491050941185 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark06(28.12344210968004,-9.388350387734931,0.20782863917976613 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark06(-28.58461583407859,0,0 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark06(28.77768289936273,-69.36391340606576,-4.708586391062553 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark06(-28.95930287689859,31.87797259811896,15.935174515337962 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark06(-29.060475646739434,-39.58121703369388,53.057660166913166 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark06(-29.54505836918166,33.387361734210145,70.93802582142666 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark06(-29.701798265588693,29.86006342346738,-45.707300784604875 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark06(-29.781600140553195,-5.054743396250998,-20.761425100179224 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark06(-29.83409186134473,10.11678376699723,-0.9939040955403868 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark06(29.919769285751073,43.52812693868054,59.48605392288982 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark06(-3.016542201278681E-14,-163.79914858258363,49.4807377166386 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark06(-3.027648788268822E-15,-1.1379734547156835,-1.5707963267948983 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark06(-3.0292196545326295E-17,-0.4985627741690881,36.4091317536905 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark06(30.4571931233165,52.281548816687376,-14.40460247515864 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark06(30.9531326723517,28.750411511111963,-91.22384007028685 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark06(31.32303885190001,-16.09364484342761,-65.5218316913045 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark06(-31.342940586077077,26.62613960399429,-86.92356689235517 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark06(31.36237705856601,56.71528574727205,0 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-0.20450815243817533,-86.71205880746872 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-0.8410527886497366,-96.57072509628301 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-0.9937865247480273,-19.28301432151718 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.4724479385517237,-17.78255625836995 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-24.536571754632497 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,32.09718167281764 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-44.23865801368403 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-59.663584355559365 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-72.32843073127586 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,99.99999999522164 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-32.71254647824756,-1.570796326795076 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-45.53821116509462,-1.5707963267948966 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-95.44204575305764,-1.5707963267948912 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589794,-0.050321907644107815,36.773843049761474 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589795,-1.5707963267948521,40.16177364802385 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589795,-44.528583020488796,-26.696850739463862 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589795,-88.39641423910349,-91.84936779174373 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589795,-8.881784197001252E-16,-1.2711662727026054 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897967,-0.4386678016447635,-97.90764988302239 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897967,-0.9079857663657919,-1.5707963267948966 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589798,-31.981903140688065,-50.16076770027624 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589798,-95.80220436409743,1.5707963267948983 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535898007,-1.5707963267948966,50.14903638680394 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535898,-1.289847626913024,-102.0146428265654 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535898233,-1.1747913418090121,32.598695067238324 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589834,-0.6332979691764843,-59.05756228268446 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535898344,-0.8698913404848094,67.37047410776793 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535898993,-158.21746831534801,-49.458778196742784 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark06(-3.14159265358991,-0.1750038269376436,7.3126332143119015 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535899397,-1.5707963267948966,-75.28787496248323 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535901795,-1.1187437172667738,-72.35637396090881 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653590218,-0.8378137266900663,98.72710494274367 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653590387,-1.5707963267948966,22.63927854102743 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535911516,-1.5707963267949834,1.5707963267948966 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535916467,-88.13088517521963,1.5707963267948966 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535951133,-1.5707963267948966,-70.19576150341786 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535961276,-45.227054665349236,36.41578633755941 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535965686,-44.986244983671575,-9.401335587037588 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653603472,-1.5707963267948966,53.77348498185677 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926536088596,-0.026228946003776045,42.51407422228421 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653610598,-0.36058542311432507,1.5707963267948966 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926536128014,-1.4854500243403739,9.29621678590451 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653615355,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653618096,-1.5707963267948966,1.5707963267949285 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653671213,-1.5707963267948966,-79.51966212946162 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark06(-3.14159265372195,-1.5707963267948966,0.5366787960583741 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark06(-3.14159265377357,-1.5707963267948966,31.460402026618098 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653836494,-95.67181346304422,72.74706999296473 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653836863,-1.5707963267948966,-40.52516875359427 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653887456,-1.5707963267948948,0.28753184004786486 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926560916096,-221.34346112926212,60.634435340588965 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592671234894,-0.07799837759046287,0.0 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark06(31.67005373981047,45.03275530189549,95.05114671101225 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark06(31.96324764122909,45.65360212924142,-91.41609108685512 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark06(32.26610259897612,54.749133770366626,-0.2586376405969446 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark06(3.2311742677852644E-27,-95.76759430099982,-70.42733034718131 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark06(3.2719590247584914E-9,-95.71203774933899,122.67388634736866 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark06(-32.99225782630711,38.041630586048115,24.590051445836906 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark06(3.3087224502121107E-24,-1.5707963267948963,-49.77044689378765 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark06(3.3087224502121107E-24,-1.5707963267948966,-93.23665482590498 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark06(-33.25658236545175,54.64061311874963,78.51167413216436 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark06(-33.70273694359108,26.216870921281725,-74.9467270657904 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark06(-3.3881317890172014E-21,-1.5707963267948966,-47.0431972972348 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark06(-3.3881317890172014E-21,-1.5707963267948966,57.99722776162062 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark06(3.3881317890172014E-21,-1.5707963267948966,-86.35593743974195 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark06(3.4237600675052077E-12,-101.59090037838943,118.72342988943981 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark06(34.53391731674324,-60.00752321483276,96.45801670438257 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-0.49607261362760935,51.251605667472546 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark06(-3.469446951953614E-18,-1.5707963267948966,-38.837303905944815 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark06(-3.469446951953614E-18,-1.5707963267948966,96.04591865903893 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark06(-3.469446951953614E-18,-38.9410984424743,85.35198343435704 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-44.077476864350224,51.612061237183816 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark06(-3.469446951953614E-18,-44.25061589680964,6.721091657422203 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark06(-3.469446951953614E-18,-45.29517277301055,-1.5707963267948966 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark06(-3.4698965102123225,0,0 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark06(-34.70331861569649,66.76836276822098,91.03066050232599 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark06(34.74267913128105,15.223701163912466,16.57118543906681 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark06(-3.4837590459272482E-15,-4.614616837241298E-16,9.587361628217053 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark06(-35.13066795525859,-19.59201916132791,11.315514321107884 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark06(3.5756651922132476E-6,-163.63081427071742,1.570796483907167 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark06(-35.81696187642895,-27.736112259307035,-22.487056541134493 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark06(-36.1179271528645,-27.93299496236841,-25.960867667928355 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark06(-36.1937247667593,-44.309293500380065,57.21004051679509 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark06(-36.71985776069868,99.46251971062671,-56.31022129381529 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark06(-36.917274256106694,-12.994600760300614,-88.24077768422114 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark06(-37.18002088961092,-43.97522811831382,-48.55212117383412 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark06(37.257655300532804,-28.8653364109434,13.797485871221966 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark06(-37.265681829867134,-25.63611345001806,-36.031689058074036 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark06(-37.41513574189423,-53.05979833882799,90.22896944929826 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark06(37.46362772651756,81.33519581586785,88.9771947567584 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark06(-3.7758642893582106,0,0 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark06(38.72500985865241,-57.785324051292065,15.181735091858272 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark06(-38.74363974920758,2.9912316320076684,96.7441437143178 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark06(-3.8949610706288376E-15,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark06(3.9374653506132375E-16,-0.34035675157694417,-0.2355242450316276 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark06(-3.939415606537549E-15,-0.21744968656232136,58.02561524360985 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark06(3.944304526105059E-31,-1.5707963267948966,-33.173293069550425 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark06(3.9772292875191795,-75.46597113977106,36.69274666740321 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark06(39.960235129483266,-61.11392396876221,81.56635234851478 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark06(40.391762089304336,-86.67626404206706,-11.931154397581238 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark06(40.53582566718515,-28.510086874446827,-56.020669569940026 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark06(40.692347022946535,-44.81596249206217,-61.15020196891565 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark06(41.29379043302123,-41.49068023403293,83.96206496778424 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark06(41.317604215353384,64.95399179310076,-65.99993923348603 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark06(4.135487254580411,-38.07452333866856,-83.4395183871624 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark06(4.1359030627651384E-25,-31.60697893293701,95.45831452009193 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark06(4.1359030627651384E-25,-95.79033850354188,0.6496629096674411 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark06(41.361316934849754,-71.92941417433434,77.42665774303885 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark06(41.408555183476324,-96.53962024483198,-67.42640568171265 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark06(41.573219464126765,51.675056162466205,-5.555212956624246 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark06(-4.1579056323581523E-16,-95.75469410938189,-39.577452168540034 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark06(41.9330408808224,-59.075894399883325,-8.374462663206074 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark06(-42.12314596635909,20.359496272947382,35.40678375595013 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark06(-42.16036821293878,23.245447398280405,51.124717127010484 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark06(42.35044056650753,-70.97828928079728,26.674264454849947 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark06(-42.36683571821895,-89.25632874509857,-92.54898363671433 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark06(42.71253903127635,-26.909376239615597,72.96648835488426 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark06(-42.829001593568435,-28.447576970763762,-26.46565251397466 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark06(-4.3156881646911247E-16,-44.465170967057965,-1.5707963267948983 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark06(43.23992582064653,-93.2370562434669,-26.087922627203568 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-0.039024982436074655,38.71229198239513 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark06(-4.3368086899420177E-19,-0.1655689262051923,4.024038922421035 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-1.017069917059014,-39.283404911008454 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark06(43.572671462606536,72.04433581273588,-90.60808032169625 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark06(-44.081391188292905,19.690516083031923,-53.717265241342396 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark06(-44.086592214246956,-38.11568599764019,-69.36988598406057 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark06(44.41843298327498,-50.143277038790714,52.57032817354769 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark06(4.448063089517504,94.36058320316391,71.6919372609054 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark06(44.55761329094872,69.52429301090115,16.393619134787116 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark06(4.4998942915200075,24.614732014009874,34.442955755815206 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark06(-45.063189025263895,19.052818203709904,-78.59596019032548 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark06(45.15773149592485,-39.161724384793374,-97.04012907287938 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark06(45.65036071669047,51.38966382940529,63.82758650909372 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark06(45.861688650871656,48.69096838807482,1.9744637346074114 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark06(-46.13893948511443,77.34281094091736,-25.663164452219476 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark06(-46.477548561533055,0.4874461717172096,1.5244599218240182 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark06(4.694429304837216E-18,-1.5707963267948966,-76.2088401835846 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark06(-47.018689934848254,98.29731723648115,7.62546289110999 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark06(-4.710763213592639E-18,-1.5707963267948966,-6.4563157207500526 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark06(-47.27872337446779,-74.79516770828062,-99.14887919774525 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark06(47.63378969928431,-69.5640766938066,-77.12049934648206 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark06(-47.799890804382336,-74.93930769364576,80.26646177076455 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark06(-47.82040760475403,53.453707594885884,65.05266342395134 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark06(48.067067266501965,-2.316073178886512,-78.32493543942314 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark06(-48.20441541772771,15.802155498851647,-44.28165525037162 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark06(48.68901715322602,-8.733304705199288,-43.07864432483901 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark06(4.912099754875072,-41.69487049201604,35.28859108471494 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark06(49.191968858092764,71.54674347563727,44.79504649532964 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark06(-4.9298836843360137E-11,-164.69825733541168,-63.26620875624622 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark06(4.930380657631324E-32,-1.4909304806268746,-1.5707963267948966 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark06(4.930380657631324E-32,-31.49219789291879,1.5707963267948983 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark06(4.930380657631324E-32,-39.21482764712247,-95.75143118134098 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark06(-50.18717991319568,-68.19781405848535,-22.592285094576255 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark06(-50.21956420020772,-31.416612065855446,-97.4477560843625 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark06(50.232877377435216,0.6413334278994114,-64.4623548941812 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark06(50.26917683063422,59.23088024051469,-12.194748066869707 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark06(50.30691392913752,78.20005726718912,63.65113978060654 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark06(50.35431247775924,57.98037018462071,-51.53329355294984 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark06(-50.674070483935395,-90.48674772089385,-79.25777322683538 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark06(-50.6850421511154,-66.28625521141676,-97.43725349000802 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark06(-51.0487354019723,2.7139426008416194,9.776157543883983 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark06(51.33132371315821,-55.03268028560107,31.88302683777914 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark06(-5.134264921337845,-75.19584641764405,-63.979909352726416 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark06(-51.61958620610485,0,0 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark06(-5.236840920435412,-48.99801556317189,42.56346592715852 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark06(52.9129365171967,-84.46459529033454,-47.52829396334466 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark06(5.293955920339377E-23,-1.5707963267948966,41.228231505843084 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark06(-53.268622662897336,-41.95355343546792,-40.4675799509348 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark06(-53.64897775480404,0,0 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark06(53.69536390402706,-86.52074895001611,55.054405241816994 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark06(53.74252065374648,64.04131920178676,-77.36034492388441 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark06(-53.93919192453511,-0.06754688659644614,23.89754256424652 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark06(-5.421010862427522E-20,-44.2122784765717,9.57440522841378 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark06(54.29956359203737,77.06225560093861,-54.180607494487056 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark06(-54.5857963739907,-30.426916605149955,26.69043507899383 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark06(54.6767024003893,52.855760089927855,-98.64766817225296 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark06(5.501537491793982,-73.15935398838296,-98.97432957401635 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark06(-5.507327185828487,76.62337421238237,1.3472457945435536 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark06(-55.46131279685626,35.641739219701805,7.892594582899832 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-0.14776742380566416,32.68973734526042 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-0.4705582686947576,-44.04201265424348 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-1.3692319254663583,-69.82525966578174 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-1.5707963267948966,12.278455297928598 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-1.5707963267948966,16.935734730109232 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-1.5707963267948966,-83.60330152022941 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-31.782520282083194,69.73983304455744 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-37.714231252056685,-9.867640407753584 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-44.12392080527518,33.881242450855 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark06(5.552904269537962,-14.402514218598796,98.33666174566355 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark06(56.02203963288284,-46.10213157252263,-45.966889082290784 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark06(-5.603517625983501E-16,-0.3782615570542221,-56.40769851407536 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark06(57.70592998603544,-30.345411066525685,3.5928185440869527 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark06(57.727627567561825,-64.46734765082553,75.10454220885245 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark06(-58.027995503527464,15.059707214847123,36.17188084794958 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark06(58.06724238289874,-14.429423380658932,21.21727504505371 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark06(-58.272031700788986,-88.02435541814089,-8.121781029308721 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark06(-58.34050977965983,-49.7851482402593,74.14178377121735 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark06(-5.843558035029517E-16,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark06(-58.47036119397051,32.783092345664016,-62.469725241735304 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark06(-5.865397129090942E-16,-0.25963600227173345,-2.6995425606331196 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark06(59.401818368121525,64.90155779527515,58.20752702415393 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark06(-59.54554204700187,9.531703261059036,0.5033078105120836 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark06(-5.957247186985057E-16,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark06(-60.119351279001165,51.94208395270675,-40.75870115040156 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark06(6.017006013234066E-12,-1.012683565872706,100.78604605100458 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark06(60.17466204416323,0.24853686549413112,-50.0093732221488 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark06(-6.017710229016283E-16,-88.0964655227144,1.3263746785968564 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark06(60.23857522537725,-51.74349818785902,26.355425001654126 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark06(60.29396060434132,-9.26343499970443,10.789183858624625 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark06(60.62036939883828,44.328185662940655,83.52932774040966 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark06(60.632257934749475,-67.00627201831472,70.04791993134205 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark06(-60.657995521576424,-66.43547860861273,-92.06258042119886 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark06(60.909026210746276,96.64266055622181,-87.7687656729738 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark06(-61.1294126530525,25.33454393135905,-5.0382620733291645 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark06(61.40736658366765,33.833995280773394,4.465190916789481 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark06(61.901985954404694,36.273683293037095,-1.1976337290047212 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark06(-62.08301186330631,18.78347650860954,63.2977133307358 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark06(62.249111201559856,32.654190658331146,90.59990644937884 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark06(62.308452993857514,75.02566434237261,92.2036173984146 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark06(-62.468717868202894,-70.42798064699736,-88.31494451247721 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark06(62.582064772757406,-77.03372442059431,-76.45536687735006 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark06(-62.83050082689461,25.37341542419651,9.122691767038262 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark06(63.44482356779375,-66.24577332077064,-72.48410075105855 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark06(63.46121331590487,-74.65820880956358,23.277155269052514 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark06(-6.445649433568931,-79.20903443532922,50.62219164666294 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark06(-64.76030579286916,-50.96243911319509,-75.62926379794402 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark06(-6.4880568743734415,33.604383126856106,-31.67763730768567 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark06(-65.00788592619624,39.39449815395534,-4.5517237010771225 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark06(65.2682335906023,0,0 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark06(-65.38946371602586,-62.26726290656322,-2.5573085104091433 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark06(-6.583027089517965E-7,-32.98424487771919,123.7356911312044 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark06(66.33458547493069,93.67300455768273,3.0555037061394046 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark06(-66.96287919410616,89.92336026399059,-1.5551248871179553 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark06(-67.00021384555276,-79.28117559467036,-21.20294061705019 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark06(-67.00199703782565,71.79545594000331,-70.25128812295974 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark06(-67.22425920773716,-50.23509993693207,-17.477419495089606 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark06(-67.40381222513659,-88.78546681493069,46.996099070181884 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark06(-67.48977187734715,-33.759078858278386,54.96167308070736 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark06(6.776263578034403E-21,-0.25340856035748527,50.582636142617616 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark06(-68.20514343583261,75.773300820711,-64.47503628641235 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark06(-68.61389847523344,12.26314922919569,63.64348573989079 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark06(-68.65275929733363,-67.61128602034863,99.17126888013968 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark06(-68.7091133581162,64.97772365806824,-57.16414558576383 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark06(-69.00888940414623,93.6250704430106,55.32166904704013 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-0.23708632624289602,1.26309571180947 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-0.5244113654010647,0.0 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-0.8315567829833106,-14.95804929549929 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-0.9489045775207036,-51.7178350752347 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-0.9500774845757078,1.5707963267948966 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-1.5707963267948966,-10.604099499808243 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-39.21462415836408,-14.980856450834224 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-88.4859041652995,1.5707963267948966 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark06(69.45811048219676,-90.763843644008,38.28727083542586 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark06(-6.960274828742996,-56.655183035525326,-9.208588347873643 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark06(-69.78830695056588,-72.74612260319111,-25.57862814941312 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark06(69.91871679300527,11.669861455299312,15.5720148612792 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark06(70.04515613739554,-46.508461553410015,79.4072441057225 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark06(-70.11146343653692,-84.71611486765904,27.188435654203857 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark06(-7.048448116004585E-19,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark06(70.8799791877855,84.31743041210737,-44.21649072486413 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark06(71.33098904179954,37.98469887569692,-37.0234891146993 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark06(-71.34201911965891,17.734238671948034,-33.80573409195236 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark06(71.74503114914,-30.462812487445646,9.636718169750665 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark06(71.82107362718418,-31.87251353844647,6.493959891654583 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark06(7.1983183632788155,16.67110293797454,-13.47186837583179 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark06(72.08965319679527,-20.2276205576905,-43.48715774918295 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark06(-72.24237673085503,-60.886109870946605,61.03198092572336 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark06(7.246293592424081,-99.32997816968027,-98.48657671145719 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark06(-72.64801211340055,-64.1894295015824,52.24043450095678 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark06(-7.291117012631233,-30.80033708175391,65.79612757103078 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark06(-73.01348518682525,-72.84164858499904,-78.67279452704503 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark06(73.51235584133627,8.004011684704395,-74.7415350355773 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark06(73.92326740613916,20.707401089846215,55.44581659218434 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark06(-73.98064815095522,55.35129454556079,-75.65827504898606 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark06(-74.18723295679995,84.53799787864676,-70.90443169735245 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark06(7.420276114169596,-28.252985477576132,-83.86733302665732 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark06(-74.53414334501242,0,0 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark06(-74.65089248739554,86.50638711700955,-86.23545683762524 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark06(-75.00246077573765,90.92944592286364,-89.49590847432358 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark06(-75.087297993762,57.86002570362646,73.66541249814853 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark06(-75.47620126603178,38.133807871511266,-3.1028428719519496 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark06(-76.19331471418639,-99.59494523490848,-83.9565845030398 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark06(76.30305601419062,0,0 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark06(7.631426726305316E-17,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark06(76.44023584132111,6.785806381272124,86.26515397816578 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark06(76.54169433076657,57.66914942254175,-38.847696989650316 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark06(-76.6858858688644,-66.1130906469636,94.03474225114505 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark06(-7.712133802267575E-15,-32.424438032585236,-1.5707963267948966 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark06(77.76461769236548,55.394206378911605,94.3120832069564 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark06(78.04704811355998,88.76007722222937,53.02430222239096 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark06(78.2047489932861,-10.68657228327288,-3.4509400858217703 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark06(-78.45521983009935,-77.34738989647431,94.45638859777173 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark06(7.888609052210118E-31,-44.12003807922885,97.07374605687943 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark06(-78.9892417122543,86.2534432905884,-18.387896555301353 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark06(79.16186671012315,57.880782347147544,-53.01728131875478 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark06(-79.6805701711115,84.94310201752882,99.31399240525818 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark06(-7.975390052699903E-16,-1.378772833860765,-1.5707963267948966 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark06(-79.9487854201391,1.5934321671254423,-11.912306782930997 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark06(-79.9583757185747,-74.82343083224862,69.72202087303546 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark06(79.98754012786088,77.51784114514618,-21.821153867082145 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark06(-80.56031624408621,61.317671303542284,29.357910028171005 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark06(-80.57402279511747,57.87496613703928,31.921670769945536 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark06(80.72696211149693,67.1774618265654,-40.27047399593495 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark06(-8.077935669463161E-28,-1.200842730296813,-59.76020597479448 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark06(-8.163035198326355,-93.56389660610932,23.513508663645794 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark06(81.80339267488966,-42.63129067052671,-26.468440871216387 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark06(-8.2162901317273E-16,-1.569817432513585,24.23702840122111 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark06(8.271806125530277E-25,-1.5707963267948966,24.02248322777109 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark06(-82.90021975766851,-54.68658966671109,92.27125472866913 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark06(83.51116645553017,99.87208555247926,36.217971388112744 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark06(83.90809521109958,-79.3251825094666,-36.882421662508506 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark06(84.45827729267896,-97.02825544759128,-91.79097186432905 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark06(84.65148343056663,91.3237041749345,59.80764179318541 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark06(8.470329472543003E-22,-0.789103397282701,-42.87811010291759 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark06(8.470329472543003E-22,-1.5707963267948966,-4.27585517055044 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark06(-8.470329472543003E-22,-38.76504786797334,32.51118028662323 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark06(8.470329472543003E-22,-45.51888172764732,-41.459168730770195 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark06(-84.78517196831972,2.3297738589461687,-26.438726312165485 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark06(84.82701839375196,-98.20245655785635,-94.83974416133603 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark06(-85.010181927178,67.34580817423367,88.81933260955515 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark06(-85.14086620058225,41.57829930888596,-90.48514599772595 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark06(85.69269128678235,-56.95617253930627,-80.12508176990218 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark06(85.7006406553115,91.9540615976741,43.40884079693126 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark06(86.15309022462978,-54.20926706666043,12.317083738925973 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-0.03253475718092114,-60.71215728486714 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-0.43129052448037497,-37.46003162540699 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-0.5549406797055273,66.54287463608811 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark06(-8.673617379884035E-19,-0.8830437465886556,-95.3976019049721 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark06(-8.673617379884035E-19,-1.3950080492589658,-67.26151556902533 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.5707963267948966,43.24986968855899 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark06(-8.673617379884035E-19,-31.637224763090572,-49.03161360488924 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-38.889609163259756,-80.30360891927752 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-44.098658980247784,-4.181712465565795 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark06(-8.673617379884035E-19,-45.00388695538935,20.733814000734014 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-45.50614200932009,6.45870430220661 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark06(-87.1236248929673,33.324465504101425,-78.05116343651443 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark06(87.16251948841719,58.72449507743994,-67.75049773643366 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark06(87.50255327872478,65.32197862745704,-30.93019995462302 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark06(-87.72890450974866,17.38519027462273,-15.97375953283398 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark06(-87.79266010655383,31.277779088243676,-49.47439357124417 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark06(-88.00694228449439,38.19223966643156,-27.568754862691776 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark06(-8.815993099013554,31.2900827448816,-91.36253188576208 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark06(-88.16822844015329,-23.98373831261482,-71.97614686755118 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark06(88.46931394876344,16.202180901532998,72.39833456853114 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark06(88.55568859843132,-30.687951452619018,-52.26355116527961 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-0.5488993134352,-65.09764138040998 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-157.0880188912131,-43.43849678430547 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark06(89.54815398836402,-64.07618957693404,-92.75186979363606 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark06(89.70971799421622,-32.33092398087447,-93.21279094926321 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark06(90.11991025097137,-1.534754132416282,86.89372195814619 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark06(90.54658844169975,-28.034708487573127,30.447896147436637 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark06(-9.078148051109493E-15,-1.5707963267948966,-20.971998746093163 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark06(9.090896206563869,8.214525940173445,17.496385093321607 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark06(-90.92360041775467,-30.827285284052095,67.68837488287068 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark06(-91.82026054420133,38.3397371409701,33.71124017431444 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark06(9.221532848569097,-75.58334745947633,-77.71679188252597 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark06(92.39060212403137,-64.53279695612326,21.302133957801146 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark06(-92.43912761228677,-61.04504646593567,-9.732814618898828 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark06(-92.60217990872226,-33.12691929963229,75.19761646415665 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark06(92.78034116807979,-10.994648861337609,-8.54280156177036 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark06(93.0160736711384,87.23119582363105,99.56899746257696 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark06(93.34399133814401,-63.07071060985378,9.13282959749624 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark06(-93.44696750038182,-78.24319617731544,82.64363285835265 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark06(93.48007327329873,-16.705336823133266,-18.392761257858197 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark06(93.51287110106853,-13.20354550826859,0.6743926836410878 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark06(-9.375152173430507,7.122058516479754,-14.618015404205934 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark06(94.05344441739786,-38.85821543668355,45.061061078131786 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark06(-94.15821705268736,-66.70904645443194,84.93153728545474 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark06(9.446426787050882,97.69706243520119,15.405379390096556 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark06(-94.55243046318076,-17.69983440895531,71.6414491081548 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark06(-94.7718465223786,-55.83964436977284,6.974164760504479 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark06(-9.528641821896812,82.43504527287604,19.006869593268434 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark06(-95.49079997035174,57.03285969138216,-63.12711140145244 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark06(95.5046335956018,13.17720617257035,45.1282918161057 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark06(-96.34479613440891,-33.0343874976536,50.265926928029955 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark06(96.53171653983648,0,0 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark06(97.23253807043508,67.427619089254,-26.70580528972792 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark06(97.47757951977471,-53.086990703245476,10.41292658894264 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark06(-98.05943546657588,-53.6196851869648,11.859597847267423 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark06(-98.22465816790447,-71.66627785807036,29.330996338485022 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark06(-98.45044011209794,-30.95412255049088,94.40544154864821 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark06(98.47648718666423,-57.01356528246562,51.05946149688293 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark06(9.860761315262648E-32,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark06(9.860761315262648E-32,-1.5707963267948966,-1.5707963267948912 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark06(9.860761315262648E-32,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark06(9.860761315262648E-32,-6.898592116555166E-15,20.43743679061774 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark06(9.860761315262648E-32,-95.36690912917967,-1.5707963267948966 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark06(-98.81053578266335,71.97601183338566,90.05235642767164 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark06(-99.1905656580722,-48.01273476115328,13.909011820514536 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark06(99.2112862234629,-0.5326114934129009,6.7728787907992825 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark06(99.25185680962002,26.866773177125395,-6.549652381858493 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark06(99.93151231143173,-99.77912267922065,-92.04736344122924 ) ;
  }

  @Test
  public void test3984() {
//    	UnSolved;
  }
}
