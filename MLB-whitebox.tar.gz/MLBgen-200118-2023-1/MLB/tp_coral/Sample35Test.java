import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(0.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-0.5446117655500728,-21.11935240257283 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-0.7853935225644193,75.88259846629774 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,0.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-40.19140624999995 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-53.558848854864515 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.1076514482126 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.4785574969952 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.4996027363616 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.648302050416 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.6944325101448 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.7839147177001 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.9582683560465 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-711.8729364900231 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-720.6118910668081 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,724.5995386088455 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-728.6107607100614 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-728.8744589029573 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-735.0444887366494 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,737.6786268315464 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-739.6197649907292 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-741.1519322428248 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-746.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,758.6459546982205 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark35(-10.037551149419421,0.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark35(-10.225968682282797,0.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark35(-10.229021659048414,0.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark35(-10.306425647014052,98.74023565148303 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark35(-10.445902172790582,-58.51476246321992 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark35(-105.24012295239392,-709.8616039202767 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark35(-10.588481251135967,-745.9993009916872 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark35(10.759313395565798,71.46953848683202 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark35(-10.784468403771612,-746.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark35(-10.830147973906577,-709.8578232350455 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark35(-10.991845015055135,-41.02888664446842 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark35(-10.993204477302092,-709.7920979442529 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark35(-10.998204128203149,-764.8982491952622 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark35(-10.999303560073391,0.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark35(-11.119730901510188,-747.191447037673 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark35(-111.23968637502583,-745.9509133957969 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark35(-111.52390936191169,-797.7584415062313 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark35(-111.63257925903213,-91.27819591092415 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark35(-111.93719784783906,-709.7148549302804 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark35(-112.66629483439348,-709.1086594753884 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark35(-112.68989103131449,-709.9409064572912 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark35(-11.389590253677568,742.7652511804108 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark35(-11.44799687953973,84.37954356860396 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark35(-11.703224878936823,-746.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark35(-11.739623213841497,-100.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark35(-11.807260129085662,13.106243070670388 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark35(-118.08320358160455,-709.7856166134599 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark35(-118.91274946635912,-709.3264367733818 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark35(-118.96932906358595,-708.647131983726 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark35(-11.898779826547818,0.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark35(-12.118605621290143,-709.3696625133794 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark35(12.167626568171784,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark35(-12.20322999251222,-746.0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark35(-12.205152313232375,-709.1663948745893 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark35(-12.39838893785938,-746.0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark35(-12.424988334471436,-754.8175583052575 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark35(12.566370629260335,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark35(-129.7038532038102,-746.0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark35(-137.7572182109579,-709.3894320181637 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark35(-141.42514076272707,-709.9652057456453 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark35(-154.62789632249053,-745.9999985463884 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark35(-156.06082444655084,-711.5819657622912 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark35(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark35(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark35(-15.750717018103614,40.03734740166087 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark35(-15.862952525027678,-711.1888214508159 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark35(-15.901693697140118,43.06620207207288 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark35(-15.90257591324831,0.0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark35(-15.95725096975842,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark35(-160.82908203261846,-745.9506748911634 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark35(-16.088299281371008,-746.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark35(-16.159122134949484,-709.0449867067175 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark35(-161.7943629703077,-762.7901205220328 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark35(-16.354850255298302,-726.3040699813853 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark35(-16.40609804514608,-745.3589064030147 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark35(-16.411389883942377,0.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark35(-16.45148696859878,-747.1914064973267 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark35(-16.576784661276605,82.33396617969916 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark35(-16.64669465685671,83.2457564287418 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark35(-16.67013134646366,-709.7869582025296 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark35(-16.7781898176825,-745.9999992962884 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark35(-16.8052942838313,-709.4763957981555 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark35(-168.07511222704858,-827.1325044021935 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark35(-16.843831949123114,-740.1262503170971 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark35(-168.47017852608664,-709.6117505271948 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark35(-168.61202068703616,-709.9355480796846 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark35(-16.867761520542544,-42.62553287553344 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark35(-16.9462099929725,-746.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark35(-169.4779041455139,-743.3924755108313 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark35(-17.0101856541733,20.41925614413293 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark35(-17.03706091254908,-95.06608791452764 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark35(-17.192605353308267,-82.88709178521174 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark35(-17.31277816909946,-86.99641895626036 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark35(-17.346060219171132,50.37747560224426 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark35(-17.41973874792461,-1.4941406249999998 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark35(-17.684104043046716,0.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark35(-180.3843676097048,-715.7397553069233 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark35(-18.39928696582109,0.0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark35(-18.40128768305005,-746.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark35(-18.42516302533849,-746.0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark35(-18.46382065451732,1.5270861050142202 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark35(-18.84955592153876,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark35(-20.837081415755705,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark35(-21.991148694337845,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark35(-22.030614676074762,-712.6607113231768 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark35(-22.032667385993662,-746.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark35(-22.267704820927605,0.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark35(-22.33955025349563,79.4612875040304 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark35(-22.578313278453436,-746.0000000000014 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark35(-22.617997212953412,-746.0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark35(-22.62867206913441,-746.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark35(-22.79274776403355,-709.9792585017718 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark35(-22.794123675937243,74.90560452387439 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark35(-22.99566398208046,5.935739717077752 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark35(-23.096915102144848,-757.7515402513648 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark35(-23.10772659473891,80.80221887129429 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark35(-23.122863073974116,-737.1674978284603 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark35(-23.28364977430358,-746.0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark35(-23.383687907386587,-69.5514166730517 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark35(-23.51348397001675,46.22097181010139 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark35(-23.53229080337789,5.401404344912891 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark35(-23.558476723502167,-727.4839322684123 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark35(-2.362750786737891,-32.71977976207023 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark35(-237.66335223590926,-712.5207403771674 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark35(-23.79340560711519,63.728225121415846 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark35(-23.998510340407606,-745.434484255117 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark35(-24.048939233955963,-746.0000003530033 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark35(-24.267287213956763,34.23675986349886 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark35(-24.6045884758681,-722.8559916430721 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark35(-24.774583809371126,-40.19140625 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark35(-24.85391339358165,-99.58762705946273 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark35(-2.6018188244667044,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark35(-2615.926593952408,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark35(-2627.0453964018097,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark35(-26.52982128106312,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark35(-28.33305765562271,-746.0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark35(-28.366231815163715,33.173825098681505 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark35(-28.380319969577968,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark35(-28.40786170308654,-35.270748673893166 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark35(-28.43222191434846,-85.14844341587799 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark35(-28.54885050077676,0.0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark35(-28.60856443659287,28.226929187879364 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark35(-28.614321572892294,-36.9828959175208 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark35(-28.619816589300967,-746.0000077385014 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark35(-28.65834851367582,67.51932937826354 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark35(-28.83269724623041,-52.92001007855196 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark35(-28.85222167196647,-739.5838867345947 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark35(-28.887717151522324,-746.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark35(-29.038918238878182,-711.9615971019952 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark35(-29.051683681385725,9.729450489751514 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark35(-29.228230046216467,0.0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark35(-29.2402275042364,0.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark35(-29.244631399300914,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark35(-29.40980033927407,0.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark35(-29.49725549422395,-709.3299376359327 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark35(-29.603962566387693,89.65320250547256 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark35(-29.62922099603506,-40.04409236096934 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark35(-29.75483876720216,26.430282582464983 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark35(-29.84140093659391,-709.8135285901508 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark35(-29.844267265669988,-100.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark35(-29.84885948161208,-26.316149647089045 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark35(-29.938155720601813,-731.22391543165 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark35(-29.942635552575354,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark35(-30.035987205123863,-1.5839376561475547 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark35(-30.09214584525232,-722.2173503457774 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark35(-30.292879637353735,-709.1105688503943 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark35(-30.554113182015257,-46.81993186163136 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark35(-30.598157949584404,-100.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark35(-31.37026439398811,-746.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark35(-3.148681737176485,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark35(-3.1486879005738784,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark35(-32.24564478342995,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark35(-32.498856975963776,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark35(-32.6792016372531,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark35(-34.557519189806236,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark35(-34.57369339502246,-746.000014150356 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark35(-34.58120419498381,-747.1914066294889 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark35(-34.587253793486965,0.0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark35(-34.71722834827861,-746.0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark35(-34.82377437389066,-1.494140625 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark35(-34.87182511792672,-709.2164231530057 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark35(-35.04572275947386,-75.86991554771257 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark35(-35.07234545691999,-724.5358523008963 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark35(-35.13294118887471,-28.435814962061585 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark35(-3.5254872797382006,-709.3084367903593 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark35(-3.5305894154107165,-89.22174055408965 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark35(-35.32951227121913,19.106615057937205 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark35(-35.45189691467716,-709.4615081169379 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark35(-35.465691663318566,25.120772830267995 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark35(-3.547697555696308,0.0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark35(-35.50892652337261,728.9612489468917 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark35(-35.51528329927666,-746.0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark35(-35.606897586994464,-746.0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark35(-35.64165705102879,-709.2097124091498 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark35(-35.65812778505794,-730.424268921938 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark35(-35.75547828417895,-13.700135166240358 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark35(-35.76854071386467,-40.07917061095905 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark35(-35.77824131768625,-709.5534761879451 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark35(-35.79360732023824,-709.0438538690743 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark35(-35.87145107005537,0.0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark35(-35.896808655948504,-709.6808388176331 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark35(-35.959179404674984,-746.0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark35(-36.00556044904497,-77.90066354310252 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark35(-36.069014472352,0.0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark35(-36.124586243773514,0.0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark35(-36.124869745332624,0.0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark35(-3.6127570493629553,-729.170673713202 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark35(-36.12974947544626,-746.0000000618428 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark35(-36.137614867225686,11.517483355420552 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark35(-36.33182430403865,-8.641683600195222 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark35(-36.44215922422409,27.491533191076 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark35(-36.47410395602666,-709.8510377044904 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark35(-3.66005650837344,-4.61841427890343 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark35(-36.69374504999927,-0.8511358355444543 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark35(-36.6944501914159,-709.1333623270369 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark35(-36.70151912971167,-32.46765251789169 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark35(-36.758508266110155,-745.9829043678776 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark35(-36.80611985037909,56.08924279093927 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark35(-36.835677762090114,-746.1933424217201 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark35(-37.21691781018555,48.685819925738116 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark35(-37.30707082798905,-40.19140625 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark35(-37.471119517537986,-743.5842989152856 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark35(-3.7531632709845866,-709.994783880869 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark35(-37.55932152453938,-746.0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark35(-38.40008575346614,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark35(-39.08154024226786,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark35(-3.9131630239178037,-713.2387489040049 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark35(-3.938969916602974,-709.9988119373219 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark35(-3.9747094018574387,0.0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark35(-40.52971521594768,-61.332551022141146 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark35(-4.078793445600297,-746.0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark35(-41.056453194765716,79.70557397780118 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark35(-41.18294808944329,-40.19140625 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark35(-41.25029537160423,-746.0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark35(-41.30178876865165,-709.9955734279663 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark35(-41.387130411237294,-745.5007831183104 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark35(-41.504739608505695,-724.9522841519091 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark35(-41.513577322759346,-40.191406249999964 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark35(-41.539642528499996,-746.0000001005247 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark35(-41.59713490495079,-746.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark35(-4.191041358275694,-717.7982501282763 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark35(-42.04986731858611,-727.769230788174 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark35(-42.05502345831928,0.0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark35(-42.152026178169535,-715.1764696305447 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark35(-42.18229269485041,-89.19406063748856 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark35(-42.18549484544441,-40.19140625 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark35(-42.259582029005585,-709.0357590696 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark35(-42.35914045616973,-717.6696999452936 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark35(-42.40777155095311,71.69736452874415 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark35(-42.41042216009294,-716.9075086302533 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark35(-42.48165628351423,57.87822700187877 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark35(-42.53650082348252,-743.8357281628223 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark35(-42.57239702963008,-749.3949635250718 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark35(-42.60992691496441,-735.1862168423762 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark35(-42.648106851272864,-734.2554815701245 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark35(-42.670676275065844,-709.8990676640391 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark35(-42.675072992998174,-734.5332676654731 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark35(-42.68666842563793,-713.7698077024669 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark35(-42.71504602456447,-746.0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark35(-42.72063540130122,-1.1200850264068318 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark35(-42.763596426869725,-47.47185060458594 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark35(-42.78237690697995,-32.003400161312356 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark35(-42.78648044345023,-34.92850943024502 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark35(-42.79426573105541,-743.478301338847 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark35(-42.799100093156916,-728.4796906692343 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark35(-42.82411374866942,-709.3106850738152 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark35(-42.824936104384456,-1.494140625 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark35(-42.825774440907836,-746.0000000000008 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark35(-42.94286170457307,-716.7650118893702 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark35(-42.945784621766876,-88.53161579665347 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark35(-42.952321044233315,-709.9900785040845 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark35(-43.18031875928654,-40.7749811496249 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark35(-43.29449420104139,-709.440551917426 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark35(-43.310028104894016,-746.0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark35(-43.366322374877875,-746.0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark35(-4.345369310568685,-746.0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark35(-43.50084730662041,-745.9264588130499 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark35(-43.64127572789571,-707.4044080281204 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark35(-43.73075834449595,0.0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark35(43.735299058163065,40.34331118131644 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark35(-4.4253901312551776,0.0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark35(-4.427259483572229,-11.223323079150745 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark35(-4.431101483465909,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark35(4.496755655358498,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark35(-4.503383941660104,30.891901911773715 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark35(-4.507551240526979,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark35(-4.560935117419618,-710.7074537929622 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark35(-45.81327024490687,-86.72260171810946 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark35(-4.6298843079370755,-709.5709480601146 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark35(-4.632646892319229,-746.0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark35(-46.34738389532065,-47.36302859487742 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark35(-4.684989976401852,-746.0000000000009 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark35(-4.6931235401303155,-746.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark35(-4.69578197781648,-722.3223792568276 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark35(-4.7086597078757,-720.5991024385356 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark35(-4.7129889063725106,0.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark35(-47.164197862695346,-1.3011742933982855 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark35(-47.164891150198486,-746.0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark35(-47.419844426692336,721.3862567471489 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark35(-47.47486175004481,-26.34929984656182 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark35(-47.578248442163165,-14.146197021597587 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark35(-47.73704771487348,-745.9190535580378 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark35(-47.850551538995816,-709.3978282102072 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark35(-47.94179515579335,728.3302473372422 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark35(-48.06369393679231,-746.033660649499 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark35(-4.818560597772176,-709.7196213064166 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark35(-48.207786426413904,-45.40502621063853 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark35(-48.31384382750285,-709.5044983557623 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark35(-48.57107694875222,0.0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark35(-48.69096012458392,-727.2133602793883 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark35(-48.691893906792366,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark35(-48.692924975055426,27.50773870724928 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark35(-48.692970853658906,-746.0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark35(-48.694794053405346,-750.5968306157348 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark35(-48.705458966655634,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark35(-48.70771471523755,-709.8374661912613 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark35(-48.745808180619285,-40.19140624998217 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark35(-48.75197220560825,-745.9353626484088 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark35(-48.777425643227424,-40.19140624999999 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark35(-48.783865830215184,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark35(-48.78401349763977,-724.1211608505477 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark35(-48.99810215290215,-88.69257921072466 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark35(-49.09804957018804,-48.08416593996443 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark35(-4.921636345569648,-746.0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark35(-49.22752585422418,-709.8174652480941 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark35(-49.48385299704816,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark35(-4.966962647152059,-74.27472909745075 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark35(-49.72423228461563,-715.6661478821753 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark35(-49.73771093901203,-55.77628657455283 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark35(-49.775633550770415,-51.87619205019618 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark35(-49.8217409194823,-709.6009138037637 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark35(-49.89210918014291,-40.72111511855001 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark35(-49.905236141098186,-100.0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark35(-49.91468962323253,-29.87838601622694 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark35(-49.93525056899566,-709.0955491991268 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark35(-49.94856935053,-738.2511335824648 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark35(-49.99952555897368,35.64114181021873 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark35(-50.058170393723486,-709.9783180846971 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark35(-50.11020768756212,-40.19140625 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark35(-50.19644784426514,-25.859535299467737 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark35(-50.23887789695324,712.6958252631091 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark35(-5.0256687052804505,-715.5251323788796 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark35(-5.155944443515111,-730.3589045275426 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark35(5.201206433326604,50.292038016636724 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark35(-53.38429968335434,-60.19307283666117 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark35(-53.5996974694976,-709.1460990065481 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark35(-53.60431736405032,0.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark35(-53.63424060386899,-746.0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark35(-53.655657511802,-752.0869955590844 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark35(-53.66698161230951,-59.611848852469926 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark35(-53.74396330564182,-736.4912598502355 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark35(-53.77753612838249,-735.6623414782867 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark35(-53.78443095393769,-709.992828792857 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark35(-53.974035279423795,-40.19140625 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark35(-54.25528878363757,50.809432141869706 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark35(-54.436818648829835,-715.5656688118858 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark35(-54.44744571286889,-746.0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark35(-54.467091161599846,-709.6142300710025 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark35(-54.5384392998864,-738.476910126166 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark35(-5.4575718571298495,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark35(-54.64507681506687,-728.276917035535 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark35(-54.6575393449206,11.83272423985649 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark35(-54.67657503596327,-11.093375108874497 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark35(-54.73950766891977,-87.21881374795134 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark35(-54.75150149673219,-709.5365423528297 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark35(-54.76850698471429,-40.19140625 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark35(-54.931620261977244,-89.31051032920136 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark35(-54.96864304914955,53.120308862363714 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark35(-54.97414216531232,-709.0233809765223 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark35(-54.97958093957445,-30.504393606851583 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark35(-54.9805012784602,-749.3669021040333 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark35(-54.981600710330476,-19.55510138071593 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark35(-55.050207653071695,-714.5221439313304 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark35(-55.06737052361795,39.8710353862067 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark35(-55.131330100719595,-19.380524651376092 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark35(-55.14479142594651,-32.985275097252014 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark35(-55.155031730760705,6.729430543311741 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark35(-55.17412740083877,-12.228813194011881 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark35(-55.17412989574511,-709.9949029280923 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark35(-55.1835201921192,-739.4843472540027 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark35(-55.2178816876673,-746.0000000003878 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark35(-55.21887708834661,31.452005778141768 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark35(-55.24255459368843,-709.0704732535588 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark35(-55.31680608134717,-1.3921132163515102 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark35(-55.36416529672133,-709.0825472113734 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark35(-55.48697118637431,-76.13943831055701 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark35(-55.49093897741893,-80.98075170506178 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark35(-55.50514337969632,-727.0421081046154 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark35(-55.536634029530944,-59.91455524604194 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark35(-55.54794457535725,-709.8600415611616 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark35(-55.878819169136726,-717.236352764984 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark35(-55.90811460453071,-746.0000024993126 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark35(-55.968722129320895,-87.30983183861036 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark35(-56.040290076428214,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark35(-56.085829127511055,-710.7848278695418 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark35(-56.12615257113549,-100.0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark35(-56.156023986874395,-709.1753949029488 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark35(-56.17817923219003,-745.9998368236106 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark35(-56.18739036336109,-745.2249478043035 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark35(-56.285940484675976,-745.999999999582 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark35(-56.30501222933505,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark35(-56.30894652053098,-746.0000018092015 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark35(-56.3338809365533,-713.7383427168998 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark35(-56.34926878884498,-709.2838617175626 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark35(-56.38825418696263,-40.19140625 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark35(-56.43184769097058,-746.000000000001 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark35(-56.43834445501855,-759.3706777202144 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark35(-56.450931577400596,-100.0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark35(-56.480757983248374,-733.2492443758435 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark35(-56.50275563592634,-709.946925018931 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark35(-56.50328874194241,-746.0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark35(-56.54866776461627,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark35(57.460862885652745,-94.02073252535712 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark35(-5.906301349445542,93.42863040688877 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark35(-59.1352860295604,50.914512901055986 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark35(-5.945921897200794,0.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark35(-59.71563890414604,57.29741965098779 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark35(-59.73112697284251,88.60759556755545 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark35(-59.73329822008533,-726.706076598167 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark35(-59.850268241668125,-709.1070461787781 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark35(-59.87989833826106,5.551115123125783E-17 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark35(-59.89808729717241,-20.548846356624267 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark35(-59.91858664580907,-746.0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark35(-59.92186551065266,-31.248763141311215 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark35(-59.990872430808075,732.8210455610981 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark35(-60.03809159969635,-719.4337583210717 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark35(-60.14108224165802,-746.0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark35(-60.32637047884211,-709.3401058045632 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark35(-60.59593274680015,4.730008325286278 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark35(-6.059848762677518,-745.6606646020891 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark35(-60.95494425023887,-714.1379393063908 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark35(-60.99968569325953,-48.99099439161421 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark35(-61.23407238422156,-746.0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark35(-61.257327472491944,-746.0010930674717 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark35(-61.26478601751009,15.156872042517747 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark35(-61.26478604975216,-745.999983233332 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark35(-61.373066659497795,-721.1512828113556 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark35(-61.53883038629186,38.78226323167138 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark35(-61.698053512016536,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark35(-61.73242697522963,-41.303715119700634 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark35(-61.862826557031724,-721.8861040687722 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark35(-61.93693928310977,55.239806621011326 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark35(-62.071401337283994,-746.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark35(-62.22600084065088,0.0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark35(-62.226968870948234,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark35(-62.57074256545838,-746.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark35(-62.594884868798076,69.47087548259145 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark35(6.2831853071795924,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark35(6.283185307179718,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark35(6.284161869679587,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark35(63.17828224667451,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark35(64.22939824611572,14.898284949655903 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark35(64.23599054876013,85.53760379964444 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark35(-6.4256105484393515,-55.952949012435774 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark35(-65.29780396931159,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark35(-65.97344596382052,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark35(-66.08383887942625,-709.7236896799104 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark35(-66.24247476465999,-746.0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark35(-66.34677263847493,-746.0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark35(-66.35961099589076,-709.6457218004067 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark35(-66.38590419960997,769.2720938670318 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark35(-66.41411233510522,44.943103015518375 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark35(-66.45359586420814,-100.0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark35(-66.51275217386151,-715.6084694438903 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark35(-66.53730524187576,-746.0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark35(-66.57714779249281,-740.5600673763406 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark35(-66.66034473065432,44.98201977028853 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark35(-66.73885245200432,-746.0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark35(-66.80059029883678,66.70041532652499 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark35(-66.80164796580831,-34.68245946167907 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark35(-66.80663621774258,-712.0689360701857 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark35(-66.90396572035681,-746.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark35(-67.08432655204697,-734.6457818243421 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark35(-67.25978367680727,-709.2535033767574 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark35(-67.40022969492313,-709.7109607362794 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark35(-67.4187829504906,0.0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark35(-67.52079035080575,-62.62030421756499 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark35(-67.54289009763013,85.7668073188459 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark35(-67.6481829090984,24.236794383584098 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark35(-67.9581248613798,-49.09890871991385 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark35(-68.19945653348447,92.14529512816759 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark35(-68.58533342103357,-746.0000020745189 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark35(-68.60118518649263,-709.8253144987858 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark35(-68.70521733506135,-26.603878409960416 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark35(-68.73251973088387,0.0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark35(-68.96434738833763,-709.4053007538603 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark35(-68.98789719048406,63.049595031868165 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark35(-69.07530385495394,-94.364603194652 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark35(-71.86359064819845,-49.03611495329252 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark35(-72.29511952633348,-709.5271080945242 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark35(-72.31079096300505,-709.8909955853143 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark35(-72.32414721057705,-711.184995040258 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark35(-72.36611304596235,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark35(-72.44307033762678,0.0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark35(-72.47725968950229,-747.1914062505331 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark35(-72.77656798735865,0.0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark35(-72.88302340651877,-746.0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark35(-72.99277856169823,100.0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark35(-73.05938419103066,-746.0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark35(-73.09717105218405,-746.0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark35(-73.14865050633364,-718.0149326262831 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark35(-73.1574277732665,-717.5467674240289 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark35(-73.20332926320188,12.70519211429837 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark35(-73.24218666214492,-41.07039871122027 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark35(-73.35244883998979,-36.426585510744204 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark35(-73.39231214412531,-709.2916122468114 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark35(-73.57367491957626,24.227840303468746 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark35(-73.5829646927103,0.0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark35(-73.63709597788493,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark35(-73.64892399503407,751.0577548405714 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark35(-73.6620436038833,0.0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark35(-73.74682950768481,-25.744282540472724 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark35(-73.79919798226754,-709.3783329220457 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark35(-73.80366237447555,0.0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark35(-73.82711987980777,-783.1389618908637 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark35(-73.90214038397103,-747.1914070872494 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark35(-74.49031419355354,0.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark35(-74.74688268708036,7.105427357601002E-15 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark35(-74.84018594890873,-9.636170956951176 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark35(-74.86975874112572,-746.0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark35(-75.14552006031207,-709.882924739543 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark35(-75.14888242780214,0.0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark35(-75.22350017079127,-746.0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark35(-75.38103510387762,-71.02187791259715 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark35(7.571962611880863,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark35(-77.1742122392298,87.919082756004 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark35(-77.32379869323991,-68.4461771976939 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark35(7.853981633974483,100.0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark35(7.853981633974511,-723.6357135639629 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark35(7.853981633975571,0.0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark35(-78.56446610634846,-709.9209612012461 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark35(-78.58174758890526,-60.629447571011276 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark35(-78.64734612354718,-709.8101004964795 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark35(-78.74314082560525,-778.478222060883 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark35(-78.76601231349184,-746.0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark35(-78.86534491185475,-746.0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark35(78.88520072577194,-3.7668175944608464 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark35(78.92113566500765,-46.89218676264437 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark35(-78.9781472046438,737.0550232434448 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark35(-79.04493817236707,-709.6490714946511 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark35(-79.05025114654367,-745.8271750821883 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark35(-79.11848276136702,-1.494140625 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark35(-79.34164966764055,-73.63165750489387 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark35(-79.39810619827689,0.0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark35(-79.4071394371991,-709.5578178439092 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark35(-79.4623859808917,-746.0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark35(-79.50128999343626,-709.4101293661442 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark35(-79.53936251202305,0.0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark35(-79.62361954502603,0.0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark35(-79.69445596353128,-12.67990590135814 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark35(-79.9141425668189,0.0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark35(-79.93235155195862,-746.0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark35(-80.06297103728777,-747.1914162186858 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark35(-80.10798282590093,-769.2453232898046 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark35(-80.30156594966607,49.29314694899699 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark35(-80.34166341846596,63.27590505875463 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark35(-80.44642442516391,-40.121532519743816 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark35(-80.70533237682007,-709.5520542821388 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark35(-80.76510437234512,-746.0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark35(-80.93141675333875,-710.2487038499498 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark35(-80.9362431745472,0.0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark35(-81.08233335454067,-718.3524709244889 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark35(-81.1608868752164,-746.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark35(-81.25320860266865,-746.0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark35(-81.25931017799105,0.0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark35(-81.45295824610297,-734.4980084099197 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark35(-82.88243464597775,95.63356511688929 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark35(-83.42829302007871,-78.40660481337892 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark35(-84.89634844762209,-709.1702043487631 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark35(-84.9566962256036,-739.1243459915463 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark35(-85.01147077586411,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark35(-85.04251859037912,0.0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark35(-85.12596028089506,-709.1342725906104 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark35(-85.23536041144875,0.0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark35(-85.26381226296573,-88.05245304959473 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark35(-85.41932452506906,0.0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark35(-85.64797075176558,-746.0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark35(-85.88662867001014,-746.0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark35(-85.92738630040829,-5.205709863774061 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark35(-86.04521186815661,-709.9218934441566 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark35(-86.04537037013371,-739.7195434169433 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark35(-86.08872037873903,-746.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark35(-86.39006870121024,16.16694417979709 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark35(-86.39121148972545,0.0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark35(-86.3947000325165,-713.1764460198849 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark35(-8.653967938905822,-5.447598445669826 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark35(-86.54903427229155,-745.0266549925342 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark35(-8.663429769784997,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark35(-86.81047597539299,-20.831795208853208 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark35(-87.14496965916656,2.220446049250313E-16 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark35(-87.16244417205681,-710.1777067738797 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark35(-87.4133059567819,-60.684401565850756 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark35(-87.64276186267095,-1.494140625 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark35(-87.96274589438642,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark35(-89.72721183979404,-20.174731523795785 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark35(-89.79785077777423,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark35(90.40301786378441,83.33862341605811 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark35(-91.5131597901717,-709.1999849676733 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark35(-91.59603839404173,742.0028863205991 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark35(-91.90444268478103,-709.455555616847 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark35(-91.93692936005378,0.0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark35(-91.9770859046988,-67.76295230607283 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark35(-92.02483270248759,-73.33172263927523 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark35(-92.05525331329834,-709.0336240203021 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark35(-92.17752664989531,-718.4273316510878 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark35(-92.21391476948891,-725.133235370341 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark35(-92.2662406694705,-725.2938071721542 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark35(-92.31296943451422,73.49994312460095 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark35(-92.3436802651309,-738.2534444208817 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark35(-92.40421915925393,12.273047777724358 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark35(9.241798233667865,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark35(-92.62106029637485,-735.7414534586854 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark35(-92.67325400838983,0.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark35(-92.71365454011863,0.0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark35(-92.75077823757027,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark35(-92.77557105781231,0.0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark35(-92.83821317624295,68.15507261687321 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark35(-92.95795717015692,0.0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark35(-93.0010360462461,-58.928019326290304 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark35(-93.14677562762958,-709.9711829884595 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark35(-93.21627795835722,56.88463827511322 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark35(-93.43855102450078,-746.0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark35(-94.24777960769377,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark35(-9.471724308420718,-711.5942474941102 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark35(-94.95513830700229,19.602787760145674 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark35(-9.50915137843593,-746.0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark35(-9.509839267398405,60.61931765889926 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark35(-95.4757772043904,-57.84555792948747 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark35(-9.587528069682321,55.8922275245078 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark35(-9.599094653407931,-11.404910269287754 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark35(-9.622158837560264,-709.2681568922735 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark35(-9.632627170032123,26.856319250623656 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark35(96.66620244025961,62.46170196581099 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark35(-96.91886209434453,-72.58585745478541 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark35(-97.40075677945347,-746.0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark35(-97.43737512944695,-746.0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark35(-97.45260786857277,-0.42335900451135444 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark35(-97.52133778748488,-56.96044079627778 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark35(-97.6141047608676,-40.19140624999951 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark35(-97.6427949473176,-712.2916655690827 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark35(-97.67289539447397,-55.06831416393923 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark35(-97.79317411484955,-709.7425647377947 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark35(-98.1704089792206,-709.7717083855301 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark35(-98.30540099847013,0.0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark35(-9.831573899748719,0.0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark35(-98.32415926962936,0.0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark35(-98.49239465889187,-1.0348714843259414 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark35(-98.5033985835584,-709.394150682549 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark35(-98.51715994078394,-709.0449773833737 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark35(-98.51786943762993,-709.0315559816469 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark35(-98.53309767104285,-100.0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark35(-98.56824338796832,0.0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark35(9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark35(-98.63300126560219,-709.0472670246131 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark35(-98.64056676099528,0.0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark35(-98.67859713969115,74.00689425087629 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark35(-9.88532707126717,60.49683502377263 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark35(-98.9564393155694,-23.608296917353925 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark35(-98.96086119527357,57.91661112188702 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark35(-98.96240078881495,-13.302631277839845 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark35(-98.96389786058758,-740.4810836929983 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark35(-9.902187516551493,-709.3148380913523 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark35(-99.03475655117066,-718.0038428313177 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark35(-99.24391308341079,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark35(-99.35550072479148,-709.0733236725391 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark35(-99.48407086550765,-712.1844609420464 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark35(-99.49648404100067,-711.9365628080037 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark35(-99.50301909846375,-716.798627641998 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark35(-99.51804529872892,-709.397714741683 ) ;
  }
}
