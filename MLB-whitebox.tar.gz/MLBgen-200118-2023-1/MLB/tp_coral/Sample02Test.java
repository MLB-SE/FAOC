import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(0.0,-0.019932261173945306 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(-0.003475609014178996,-53.421683962217145 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(-0.010864152824055007,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark02(-0.016741280289401705,1.5707963267940241 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark02(0.017953685719547252,-85.79697895804286 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark02(0.018583418270480934,-88.3521265121385 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark02(0.01975978163929258,-1.5707963267948968 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark02(-0.01986524016200643,3.141592653589794 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark02(0.026222777556952792,-43.609680008469006 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark02(-0.031212656405203862,1.570796326794897 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark02(-0.03404726959740145,37.788012880489255 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark02(-0.039808208133514406,97.59702939267865 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark02(-0.0487661263754714,43.982297150257104 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark02(-0.05520902755276169,25.366914787334323 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark02(0.0607431996395178,93.21809998243731 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark02(-0.07732769920604987,-50.1087012885749 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark02(-0.08403014870716441,-83.58947963066466 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark02(-0.09009498493870377,-21.650743506542952 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark02(-0.09786574486846264,-1.5707963267948966 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark02(0.1041197702275592,0.052470036275089726 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark02(0.10744268430596304,4.440892098500626E-16 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark02(-0.10895617404455366,-10.995574287564276 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark02(0.12289373823174372,83.6895316770862 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark02(0.1284905820929342,90.76128027237748 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark02(-0.13996821548220129,-62.21057438839689 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark02(-0.15882032981769034,0.2768731845319614 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark02(-0.1590969471528726,30.233233970586124 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark02(0.16487158666194812,0.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark02(0.17510526614096178,1.5707963267948966 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark02(0.17882428556060628,90.96314267191136 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark02(0.2128833932714207,-4.411390629602467 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark02(0.22296241924501142,0.2332972451758691 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark02(-0.23751646459604567,58.35698055611011 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark02(0.24211262294906533,0.8020634449416821 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark02(0.25139231727204797,-1.5707963267948966 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark02(-0.25232703698170583,-0.44434486466342005 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark02(0.28859280145915095,-45.356601920907785 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark02(-0.29032399391003383,4.422064986370288 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark02(0.2921465091741945,-28.058200214238617 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark02(-0.29284726128747174,-68.73876188944897 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark02(-0.30148766290618423,1.5707963267948974 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark02(-0.3055324863739128,-44.82905167873211 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark02(0.3085940976361429,-0.5314141959375506 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark02(0.32225512485036206,-57.79720896666624 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark02(0.34710292668252557,108.26911272982605 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark02(0.3817246400098927,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark02(-0.3836487122303783,1.9544450391331143 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark02(0.3868014853723063,82.82895214293387 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark02(-0.3881881970114709,70.91097467859456 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark02(-0.40847544509351474,4.295370929471698 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark02(-0.40962106904419726,28.89091711371754 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark02(0.4138757996657416,91.70069051626467 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark02(0.41595217496362125,-87.23135318250918 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark02(-0.4232255929732978,-44.53713018697552 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark02(-0.4311542058919027,96.33935604783497 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark02(0.4311702058107142,5.479863706004721 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark02(-0.43305684632888086,-0.8898791022824923 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark02(-0.4419019219247957,71.12740644441564 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark02(-0.4652478830327585,0.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark02(-0.46604846387247534,-1.5707963267949054 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark02(0.5028828111360619,-1.5707963267948966 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark02(-0.5051482852295806,11.12659588680431 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark02(0.5268893318983103,0.0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark02(0.54355410914342,91.66294548488 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark02(-0.5924973685988671,40.69092929543018 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark02(-0.6134798813683764,-67.25741946362645 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark02(-0.6181392528106251,-40.06223420999853 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark02(0.6275323852671062,1.210801016314667 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark02(0.6314054126868838,-7.827763962761086 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark02(-0.6366476354438197,-48.62798683400743 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark02(0.6451481047403035,-5.33581860179914 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark02(-0.6451930749086476,0.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark02(-0.6459819464155214,0.0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark02(0.653872644783104,0.31504786901834697 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark02(-0.6728643756348908,79.43774829077697 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark02(-0.681589783987902,-72.02387179934108 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark02(-0.7165625734363207,0.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark02(-0.7279048731658655,1.5707963267948966 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark02(0.7404449164222129,-35.35659107855831 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark02(0.7443835631602786,49.43906969366611 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark02(0.7544040621474384,1.5707963267948966 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark02(0.7633025103037454,-40.23584612586768 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark02(0.7721841731274978,-56.354900888958866 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark02(0.7818137934907483,1.5707963267948966 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark02(0.807355544135067,0.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark02(0.8174370181513408,43.22893784146737 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark02(-0.8174871500337932,45.057056594770316 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark02(-0.8265736258979581,1.5707963267948966 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark02(-0.8446715328640508,-79.18009527709383 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark02(0.8715536889048963,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark02(0.8724342416104857,12.831925523959637 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark02(0.8746777618122588,15.818754558016192 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark02(0.8840929988551789,15.95286429328992 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark02(-0.8845535873970175,-16.615299099424533 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark02(-0.9286504750402926,-0.3101197874307829 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark02(0.9379530390441494,0.632843287919826 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark02(0.9381466741348468,6.91583496000876 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark02(0.9387742427242642,53.821896686482766 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark02(-0.9951477908045661,35.14192840323892 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,0.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark02(1.0000006123233996E-10,-1.5707963267948966 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark02(1.0000006123233996E-10,1.5707963267948966 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,0.017764755817005207 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark02(1.0000028327694488E-10,-1.5707963267948963 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,0.030364577567211733 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,0.03593139451194727 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,0.5702643860488156 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,0.724590898196066 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,100.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,1.0398314120374792 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,1.4937927365503036 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,1.5707963267948966 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-16.17991481326464 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-16.35222833057501 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,2634.7882360113986 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-26.967287120653037 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,4.432750397100563 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-44.409977615197405 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,58.69572172635969 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-6.36294889954798 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-6.648422671061876E-4 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark02(-1.0006817653843378,-28.84444844353342 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,72.43124874049734 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark02(-100.52926601595549,17.2787595947301 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark02(-100.53011873541021,5.222671901329185 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark02(-100.5318011035655,42.41150466035736 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark02(-100.53971963483055,1.6332963271634033 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark02(-10.175911780039229,0.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark02(-1.0266548729362848,1.5707963267948966 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark02(1.0297293824111757,-52.43507199996198 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark02(1.0301948074263265,1.5707963267948966 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark02(1.0304402244507376,-31.956282638436477 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark02(10.30974612014947,11.618455632641584 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark02(-10.331750039456338,26.561751201953427 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark02(-10.34902564507087,3.552713678800501E-15 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark02(-10.371480224696157,0.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark02(-10.377687944620202,1.5707963267949125 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark02(-10.385499622349073,0.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark02(1.0398314121189987,-100.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark02(-10.398429302710426,-15.869751724702482 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark02(-104.02634579155628,0.5409960135701798 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark02(-104.23168659954665,1.0116672958293944 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark02(-104.40569849659722,-1.5707963267948968 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark02(-1.0444144517120417,-1.2410006931944922E-4 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark02(-104.82416620883154,-48.875144244512605 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark02(-1.0504117115443716,-31.770757073190453 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark02(-10.512058488742753,-122.63866170680899 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark02(-1.0547764515416134,48.389867819522635 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark02(-10.550966454285264,-0.5702288858473731 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark02(-10.654545013729527,-51.183659081462764 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark02(-10.656175894869218,-88.32558151571955 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark02(-106.81415648395365,-164.93355146429798 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark02(-106.8702445556774,46.562161498662654 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark02(107.25498291496395,33.408353793355644 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark02(-10.728816345001963,-88.23135224345587 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark02(-1.0770878490791438,-54.977871437821385 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark02(-10.790152622145683,10.47092974642058 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark02(-10.899863055677713,3.5920215509784015 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark02(-1.0930102413940572,32.60787941870845 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark02(-10.951438593441349,-1.5707963267948983 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark02(-10.963914843154754,82.49164319091392 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark02(-109.95450077617414,-45.55309347630575 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark02(-110.2362848714063,-4.992930976044156 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark02(1.1034521169521598,-1.5707963267948966 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark02(-1.1043410507611846,0.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark02(-1.1102230246251565E-16,0.39605454988262145 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark02(-1.1102230246251565E-16,32.839868914500194 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark02(-11.144059039829983,-1.5707963267948961 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark02(-111.52653858041005,-9.1024906616828E-25 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark02(-1.1163522330207385,0.0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark02(-111.64335626568162,94.36459667179567 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark02(-111.69386161011197,119.93968521744966 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark02(-111.78762371479368,0.1513939421291191 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark02(-1.1196746340932435,-70.68583470577035 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark02(-112.73812000808418,0.0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark02(-112.87919546609487,53.626641180328505 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark02(-11.353727127497848,-1.5707963267948966 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark02(-113.55279761537344,45.375702523913986 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark02(-114.49641508115019,-64.82141294805079 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark02(-1.1598341521668425,0.0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark02(-116.23791371321006,45.553065319042595 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark02(-116.23892870860227,1.5707963267948974 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark02(-11.704294359463674,-60.458059738847105 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark02(-1.1754943508222875E-38,-17.278759594743864 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark02(-117.57662454868529,0.0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark02(-118.81695504173084,76.11605162524404 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark02(-119.10304020393747,45.491518019198566 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark02(1.191873417259595,44.361220060062735 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark02(119.3815249779879,1.5707963267948966 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark02(119.38212173348722,58.119952437226964 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark02(-11.973482416402348,0.0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark02(-11.98321948652574,57.66911830915521 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark02(120.0622219194806,-22.98318272776045 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark02(1.2048619351806198,-100.0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark02(-120.85860538552434,1.5707963267948968 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark02(1.2150069267550525,-17.32082292897147 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark02(-12.275683512521908,0.0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark02(1.228074513153917,0.0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark02(1.2394579839915192,-14.429485493480279 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark02(12.407935059648594,-84.5597066079361 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark02(12.4180767892434,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark02(1.2434515210094397,-9.176207633544452E-11 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark02(1.2471661089710189,18.525119965784864 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark02(-125.0773309847985,-90.06310949754011 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark02(1.2560462484936719,0.0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark02(-12.564862074516356,-4.837388980384693 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark02(-12.566366640882375,-124.09290981678892 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark02(-12.56637061426343,1.5707963267948966 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark02(-125.66370614328076,-1.5707963267949054 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark02(-12.566370614359181,0.0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark02(-12.566370614359181,1.5707963267948966 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark02(-12.566370673981284,1.5707963267948966 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark02(-12.566370870625764,92.67910889907068 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark02(-12.566401131946277,-1.5707963267948966 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark02(-12.566493311429719,1.570796326794824 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark02(-12.570400787433007,-32.9907530357839 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark02(-12.591317309037672,-1.5707963267948966 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark02(-12.600177433785065,-70.7196415252963 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark02(12.607333083354364,-86.43476044261442 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark02(-12.621829681983012,-73.827427359351 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark02(12.647003504150987,0.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark02(126.59153124557884,-50.62555414285157 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark02(-12.660149789683032,94.94319364554872 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark02(12.674431405168384,1.5707963267948966 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark02(12.691370631923103,-32.98672273495379 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark02(127.03285384591271,-9.618288931758695 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark02(12.729874557769149,-1.5707963267948966 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark02(-12.73497848416621,2.8794662089407126 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark02(-12.747700079032239,0.765399048306147 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark02(12.771097224485183,-1.5707963267948968 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark02(-12.77174466175127,-34.16988311466418 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark02(-12.779768470665417,-57.700542631494805 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark02(-12.873678799810524,-48.38737794508564 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark02(-12.931968890634229,98.96016858807849 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark02(12.936197985354553,6.195295356429526 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark02(1.2939462446315164,-0.13495406609056998 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark02(1.2964703950383694,-20.973439696333145 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark02(-13.029612777155577,59.09911307234964 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark02(-130.3760951239468,0.0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark02(-130.48655586795633,68.23422379774078 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark02(1.3087482676357576,0.5707333375521332 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark02(-1.3125250124387955,-15.723443419096297 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark02(13.135876892990195,0.5018984753345483 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark02(-1.3162756331054117,-53.66159580431881 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark02(1.3201461848072007,4.434754592327743 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark02(13.217376545084505,-31.952035138715402 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark02(-1.3286137780230203,-0.5707960399205324 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark02(-1.329335230456528,-0.4997894993103718 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark02(1.3301061947805266,-35.605932237213494 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark02(13.316826398303029,83.83461478597414 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark02(1.3325191890774588,-1.5707963267948966 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark02(-1.3349907228356495,-122.69992800505935 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark02(-13.353923259400077,-75.19382012130357 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark02(-133.6427724103023,191.76255029014473 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark02(-133.69323227887773,-0.7700301550456246 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark02(-1.3384874933182793,-95.63009525633844 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark02(-133.9375771803835,8.044136135055314 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark02(1.3403922415531397,-61.48562976990151 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark02(13.425733913511067,39.42006697324824 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark02(-13.457527094179511,20.621701850065122 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark02(-134.6767766352302,-92.26527581165887 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark02(13.484770582045456,0.5707913139588136 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark02(13.531490647836918,-67.29552561147335 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark02(-1.3552527156068805E-20,14.137166941091007 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark02(13.579450682005891,-0.27501344685224327 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark02(-13.590294658593862,-43.81166560034355 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark02(-1.3618389617232365,-46.91493243925729 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark02(-13.629221717331703,0.0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark02(13.689697553396696,-88.4120636885027 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark02(13.69551830106839,-57.743672456702264 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark02(13.70818989249662,-73.94459424554533 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark02(-13.728316692215898,84.8046832595945 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark02(-13.72956496626567,95.09876823029626 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark02(-1.3737229950596093,0.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark02(1.374284765992789,29.845130209644676 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark02(-137.64002833631147,-88.26949034186433 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark02(-1.384908625505608,0.0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark02(-1.3877787807814457E-17,0.0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark02(-13.886342394638348,53.65789965713932 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark02(138.94485283387007,-31.64563262350549 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark02(-13.94451425492096,-0.880102997551476 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark02(-13.949730873347903,-0.4040002471010567 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark02(-139.8548267721488,-32.979979252666446 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark02(-1.3990244723070369,68.95518386986637 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark02(-140.1832506503973,24.10141726895678 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark02(14.034291668035507,0.0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark02(-14.041776606950929,-51.261876854455515 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark02(-1.4052895119146547,-92.70475486686829 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark02(-1.4062126536073318,2416.041522348761 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark02(-141.0917761760433,8.133874869575925 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark02(-1.4114785791327458,-92.56943928518906 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark02(-141.16936855981743,-33.18902371451818 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark02(-141.170236585575,-29.862746506424216 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark02(-141.37035118297052,-80.11085680716474 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark02(14.137166941134703,0.0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark02(14.137166941154069,-100.0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark02(-141.3755756621593,1.5707963267948628 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark02(-14.223208241435799,73.87094361862216 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark02(-14.235268186905966,-1.5102360533761006E-4 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark02(-14.253430332626209,0.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark02(-1.4294552135187841,-15.566622155382674 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark02(-14.298435458878089,-37.86071225133811 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark02(-14.325466589168371,101.72978366692158 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark02(-143.31718248779066,69.95208546852703 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark02(-14.348051018325066,-37.84318808489691 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark02(1.4367149318075314,-0.041369878316130974 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark02(-1.4413115355464505,-7.938074252424542 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark02(-144.49556942509508,-4.743638980674765 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark02(-1.4505439923353887,-1.5707963267948966 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark02(-1.458070629937946,2.570796326794898 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark02(14.595273808736636,78.33116449749033 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark02(-146.403311124793,45.359926529680266 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark02(-1.4667354048723844,-52.358895951071815 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark02(1.4698151432931255,44.03597415443769 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark02(-147.55345471345228,-29.408104026004295 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark02(-147.6008671848221,1.031442375520642 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark02(-14.76300053005879,-44.23156306329736 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark02(-148.83708728217073,6.435114470886348 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark02(-1.4951572888351787,64.76745592317286 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark02(1.495762248628631,1.5707963267949197 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark02(-15.044665227519971,2603.6327872407 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark02(150.79840073222545,42.41150082341385 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark02(-1.5084025715024558,-52.01222406041469 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark02(-1.5099416867515423,57.08966393790599 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark02(1.5206904347453616,-0.2284862401061929 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark02(-152.0806146047678,-76.61556697945528 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark02(-1.5224052679204125E-15,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark02(-1.5240233928958982E-7,-164.933604724233 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark02(-1.5280436682646297,-44.193834763121636 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark02(-15.304231450113619,0.0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark02(1.5311186956819824,76.7696895367915 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark02(-15.370415525834723,0.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark02(1.5405631783764901,0.0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark02(1.5414116451784257,0.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark02(-15.471454136120897,34.22410902558505 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark02(-1.5484460990763012,-59.69026041820607 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark02(-1.5489506882048274,2.1415926678261354 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark02(-15.498442208242352,92.46836759420185 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark02(-155.28311525686033,15.922474460321794 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark02(-155.73110287389687,-55.33344914156943 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark02(-1.5611251764530607,-91.6505769751601 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark02(-1.5640629963226638,49.71379228388515 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark02(-1.5640654841925672,-11.205016492079947 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark02(-1.5654437028210992,96.28551796515146 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark02(1.566505129709386,99.93291825611135 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark02(1.5685239104113717,-6.429203795653032 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark02(1.5685924685810693,-0.2577388845443841 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark02(1.569781152862219,6.429211320185236 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark02(-1.570795279496785,-6.429217733776711 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark02(1.570795566056654,-1.6239461294115384E-10 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark02(-15.707958045673937,54.977875252575565 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark02(1.570796110865065,10.293132524312938 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963264841398,-53.9768537134634 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark02(-1.570796326747981,34.88340410762765 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267888585,0.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267930911,0.0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267947136,-1.5707963267948966 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267947218,-1.5707963267948966 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267947882,-82.4651365169591 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267947882,-87.91049904401451 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948237,-50.265478684799554 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark02(-1.570796326794838,1.5707963267948966 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948415,1.5707963267948966 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948766,-0.0173318812515314 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948806,-1.5707963267948966 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948877,9.444507305266752E-15 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948895,0.0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark02(-15.707963267948905,0.0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948912,0.0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948912,1.5707963267948983 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948912,-29.803355257263235 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948912,-31.809619372051827 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948912,49.48352541594643 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,100.0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,15.590571749050582 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,1.5707963267948968 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,-2632.0231812549496 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-2641.609987088815 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,-30.706073732317954 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,-32.5433490551754 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,-50.76075859284028 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-51.722577227395504 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,53.88380879155844 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,59.196064409522705 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,5.929736944485471 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-61.26105674500097 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,-87.5373801228523 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,93.41404471913467 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark02(1.570796326794894,-97.893892151459 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948957,-0.5578833074468759 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948957,-10.723883781245831 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,-11.754778426727649 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,-14.89253069057413 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,-2608.90525822245 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948957,2624.747857511808 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948957,-2632.4053009830336 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,3.1947384127852416 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948957,47.96183348879072 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,53.659657543602435 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,-73.82397043009829 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,89.4264963419437 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,98.97198367265537 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948961,-0.23600506118789133 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948961,-0.48481908567713583 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948961,1.1034971743328241 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948961,-38.150546845569934 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark02(1.570796326794896,163.8520911695999 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948961,66.10220335290441 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948961,78.22420626799426 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,0.04930828124311432 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,13.734206831714005 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,1.5707963267948963 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,1.5707963267948968 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,1.5707963267949057 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,15.761367830384444 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,164.50103593677363 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,-16.956703418405873 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,2453.3872786075603 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,-2501.845396033713 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,-2538.719573008947 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,-37.03999811215337 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,-4.4031627926949 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,5.118995611635016 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,-5.856089863391336E-7 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,5.95574385183851 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,65.5052937831594 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,78.05135683423111 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,-8.22907314348322 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,0.009738725312230362 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,0.012426966915215602 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.02866580705321829 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.03482094257074426 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.04777953088792519 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,0.05145531619014416 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.06675220255914906 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.13751254410479774 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-0.1546217201515851 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-0.16964088743487724 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.31387049177814774 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-0.33652683817897433 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,0.3725222999291762 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-0.3966635447779457 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.4710859259967351 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.4825983776236034 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.4951949048473133 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.49941533387955556 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.5707957107193026 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.6800434289133896 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-1.0147625553454525 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,10.339987578535702 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-10.846151917236995 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-10.995574287563278 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-1.1147299195928272E-6 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.1411326368710788 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-114.66813185600681 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-11.976854567328246 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,12.091110199771052 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,1.2146804703953663E-16 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-122.58342296752069 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-12.566366841735885 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-12.566369534924322 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,12.609482904164203 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,12.85509054538555 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-12.909829326780738 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,134.5127492185315 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,135.08848410403843 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-135.08848410436363 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,13.54327150147092 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,14.137166941154064 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,14.137166941154184 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-142.9850997543692 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-14.429203678289504 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,14.430764859158337 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-14.441021086153192 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.4509000224897243E-15 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,14.677495207806864 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-150.7964439136314 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,1.5241683987049974 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,15.282632254791379 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5537018045570261 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-155.50883635269201 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5573198554558827 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948024 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,1.5707963267948806 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-15.707963267952078 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267968734 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-15.725873601914104 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-16.10193668942202 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,17.004482860086945 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,17.12309994049555 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,17.278759594743857 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-17.29143717825079 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,18.638600070952535 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,1.9188595364210197E-14 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-19.201165051505438 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-19.313127304929793 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-1.9333222218617152 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-20.458278182785985 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-22.165712764739908 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-2.258699386861011 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-226.33503918703624 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-2.269679634774368E-15 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,23.19075146010131 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,23.225429946564056 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-2446.284234431894 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-25.15744738286739 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,2557.0283021426485 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,2571.8971314029372 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,2622.918803447305 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-26.246452666823302 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,2632.775677046195 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-27.864432556369337 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-28.27433388230619 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-28.274333882308365 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-28.39923398389906 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,28.670972317926896 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-2.88382221860498E-6 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-3.069341640357796 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-31.415922763265456 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-3.141592653589793 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,31.415929023354447 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,31.61337785790448 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-32.882996165715085 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,33.02734422104645 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,33.14243566228185 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-33.533488115959244 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,34.01733160064068 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-34.0843449528048 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,34.557519189481596 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,3.469446951953614E-18 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-36.1272008244158 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-36.128315516283074 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,37.69910989232271 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-37.69911309977112 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,3.7726268162960956E-6 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-3.77263354420452E-6 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,3.7726361424640594E-6 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,37.90798468337136 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-39.166987713683625 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,39.269908169872075 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-39.26990816987241 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,39.26990816987241 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-39.35574719502302 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-40.840704496662426 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,41.46654530782237 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,4.170655301892406 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-4.207086118248078E-6 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,42.551635754960294 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-42.63885242108723 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-42.980913976312 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-4.350943006292269 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-43.98230092289134 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-44.1078008648058 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,44.30097645131981 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-44.3084886512922 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,45.17545185937044 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-45.237460090436706 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,45.332238046862926 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-45.553093479297054 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-45.5530935975259 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,4.713532409317898 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-4.714084543358026 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-47.74564029368249 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-48.69468613064176 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,48.694686130641784 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,48.69859368869748 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-48.81374126136715 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,48.940666552379476 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-4.9997804856358075 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-50.20706475678651 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,50.26548622596602 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-50.66464379051172 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,51.836278784209206 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,51.8362788140449 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,56.49474007925092 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,56.54866399198687 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-57.870298392169914 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-58.012743758713796 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,58.49445238588944 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,59.14086239372614 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,60.096089083244294 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,60.14246261772698 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,60.19895248852344 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,61.11743960641019 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-6.123233995736766E-17 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,6.123233995736767E-17 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,61.730207655084584 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,62.33089994509959 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,62.41568675797233 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-62.83185684443508 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-6.283186030885863 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-64.58791912947486 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,64.78594948779501 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,65.97344572538901 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,66.16738752836821 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-66.905635547348 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-67.01955005426416 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,67.45829460144066 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-67.46108757493369 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,67.54424205215675 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-67.54424205218054 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,67.5442420521842 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,67.54424205963115 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,6.789165418597625 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-6.837663643776411 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,69.20822610130026 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,70.07709826829918 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-70.68583364109745 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-72.25663103256757 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-73.23767676556459 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,73.28602335871108 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,73.84305235936014 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-73.84305235936046 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,7.435663139486841 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,75.09066079214148 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-75.20946093850137 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,75.39822353897767 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-75.44089435440347 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-7.653976702285367 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,78.53981633979001 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-79.27034799665462 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-79.52912761788893 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-79.53315570458368 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,80.16544099026427 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,81.68140522070426 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,81.68141276596172 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-83.04962420192912 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,8.336997829946611 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,84.1962769483552 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-84.40771734533922 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,85.90409109456235 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-86.05842431088604 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-8.627339309406987E-4 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-86.39379797372008 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-86.4469519497288 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-86.67166719193314 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-87.12281548119523 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,88.08959430051422 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,88.33571282490847 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-89.83014865133438 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,90.00896911517759 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,91.10618695410432 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,-92.62433088528856 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,92.85897380955844 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-9.424777960597606 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,9.424777960767614 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,9.424777968152847 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,95.27335438976351 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-95.81857593448868 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,96.20554708567133 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,97.38937226127915 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,9.935894931149775 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,99.99999999999999 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948968,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948968,0.0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948968,-96.45576724040814 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark02(-1.570796326794897,42.12047276478976 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-10.955427304744 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948983,136.65928043104637 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-1.5707963267948968 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,1.5707963267948968 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,37.566246204781976 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,44.45804731733587 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,81.22947321734291 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948983,92.53989478486943 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-9.349585246303985 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949037,-2543.6115642891846 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949054,66.23740973507623 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949197,-85.20320014333235 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949268,-109.9557428756374 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark02(-15.707963268044972,-1.5707963267948966 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963268924974,-14.429211488109118 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark02(-1.5708001129693674,40.84070448105719 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark02(-1.5708042666948676,-14.4292645478872 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark02(-157.08571890421226,-1.5707963267948954 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark02(157.24276261168367,-81.87092966130194 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark02(15.73726575897209,183.81247272612552 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark02(1.5789058935523457,-8.05147566381315 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark02(-15.81056093044711,-19.980522998214994 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark02(-158.3303296032621,-1.591262088490201 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark02(-15.854142004687109,0.0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark02(-1.5904520332547232,-97.36971655990605 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark02(-15.914927324092693,20.04519553641115 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark02(-15.926827785550866,79.772092896913 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark02(-15.932548788728306,1.3203655698824344 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark02(-15.959082224510531,-45.23800282280871 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark02(-160.2171340794752,-39.26990816849849 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark02(-1.6367971466718299,84.88900246528549 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark02(-16.387082173222545,50.553020648041326 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark02(-16.425129631777153,1.5707963267948966 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark02(-16.448081230207023,71.91072775241483 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark02(-16.476970126830686,0.0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark02(-16.581360473933724,-0.36586167873287884 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark02(-16.63911186891542,1.5707963267948966 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark02(-16.724653705234186,6.12358209225452E-17 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark02(-167.36652340884783,-0.028289881902056377 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark02(-16.82363448365091,-1.5707963267948966 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark02(-16.911774831639477,-100.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark02(-1.6940658945086007E-21,-23.56194490192345 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark02(-169.54185222853198,1.5707963267949054 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark02(-17.038866537206005,-55.387446461136605 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark02(-17.110974769585994,0.3357793461281383 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark02(-17.175740218053676,69.10651445183183 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark02(-17.21191751987425,1.2710911838671959 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark02(-17.226116031635158,-16.65990693400813 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark02(-17.26069486079422,-15.892251954921207 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark02(-172.78477414746573,0.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark02(-17.31201592192187,11.7708210318918 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark02(1.734723475976807E-18,-1.5707963267948966 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark02(1.734723475976807E-18,1.5707963267948983 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark02(-1.734723475976807E-18,32.98672286269282 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark02(-1.734723475976807E-18,-36.128315516284445 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark02(1.734723475976807E-18,-67.54424205209182 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark02(-1.734723475976807E-18,-80.11061266654106 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark02(-17.415560518427235,-0.21643910635747604 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark02(-174.15920582345785,68.97119669250773 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark02(-17.430789969203218,0.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark02(-1.7574991495670673,86.42063377022089 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark02(-17.582027513647077,0.0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark02(-175.92950443591744,1.5707963267948963 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark02(-17.687570495400955,-28.838741099372164 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark02(176.9303324648622,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark02(-1.772267810901114,0.0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark02(177.29159129659965,-0.24294254981114316 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark02(1.7763568394002505E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark02(1.7763568394002505E-15,-59.12610825113828 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark02(1.7763568394002505E-15,59.502480879290296 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark02(-1.7763568394002505E-15,73.84973261155719 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark02(-1.7763568394002505E-15,-94.23472309784285 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark02(-1.7889935690883711,2.9233954117582646 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark02(-1.7911616247799569,-16.9790569990734 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark02(-17.97507376389467,4.440892098500626E-16 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark02(-180.16099972181473,-75.7912897706463 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark02(-180.67052095119627,-5.0643462184432834E-15 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark02(-181.6577189475785,227.34918942190967 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark02(-182.00626159182406,37.609912932020904 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark02(-182.0794370668533,70.2974122188439 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark02(-182.150635192491,-11.057313003181099 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark02(-18.253974912864578,24.15752591047683 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark02(-1.845620339271425,-53.68189912313453 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark02(-18.47291189879401,1.5707963267948966 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark02(-18.52228561530221,0.0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark02(-186.18776105646663,44.16140484479977 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark02(-18.746695268512042,-59.997749410453885 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark02(-18.849551373858606,54.977871124347395 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark02(-18.849555921467864,-1.5707963268240015 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark02(-188.49555921528759,1.5707963267948966 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark02(-18.84958681123793,-1.5707962921667167 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark02(-189.275283914474,0.0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark02(189.6704931660911,-46.88952038115839 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark02(-18.974555921538762,1.5707963267948963 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark02(18.974555921538762,-1.5707963267948966 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark02(-1.8990648177103966,53.73534360163182 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark02(19.0041234587776,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark02(19.01830135401799,0.4318038935352023 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark02(-19.042157868727585,86.2011960264286 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark02(-19.045418296718083,-1.5707963267948961 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark02(19.23428808789758,-56.44616597035244 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark02(19.294059865061996,-1.569815403387638 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark02(-19.331424210369036,-3.1555169924733377 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark02(19.34453701744894,169.90205095271443 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark02(19.34955592158328,-26.203573607507785 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark02(-19.395843917241237,-18.634042675875598 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark02(19.40704407045989,-114.32413841661615 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark02(-19.41001492488003,0.0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark02(-19.42709233629081,45.553093477052 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark02(-194.77901615823458,0.5680839630977107 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark02(19.518218962949447,-0.49212678776326746 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark02(-19.597927709710333,1.4212112467963818 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark02(-19.621014486607173,0.028122321107385884 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark02(-19.628692485474428,1.0513971593642726 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark02(-1.9644906561100584,88.96234362792154 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark02(-19.659690882932356,30.518916616042617 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark02(-19.686536169952177,-75.73882637058982 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark02(-19.700933349800017,85.12605973859328 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark02(-1.9721522630525295E-31,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark02(-19.784114523851116,16.99004127976394 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark02(-197.91898906181214,0.3667039924929184 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark02(19.919525200592858,1.5707963267948966 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark02(20.050730494248256,-2.9576177436551347 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark02(20.069010572613166,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark02(-20.09769248510172,-73.82748711705125 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark02(-20.100492724171392,88.7975768509312 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark02(-201.0931804907349,-95.81857406304167 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark02(-20.11963367913827,1.5707963267948968 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark02(20.197712045581454,45.04207564461339 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark02(20.278801026725034,-82.79294637098333 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark02(20.293018217487887,14.157324598808543 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark02(-20.29435676395876,1.5707963267949743 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark02(-20.315050331401252,47.01858788786579 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark02(-2.0325381846072457,-35.49559906235601 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark02(20.376483351572517,-0.08367625293174197 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark02(-20.47811594982892,-68.40996380778458 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark02(-20.49975762704088,-42.10069732534644 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark02(-20.52249690049439,-82.29864302038155 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark02(-20.522821445733385,0.29588743268655865 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark02(-20.525163343774057,-1.5707963267948966 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark02(-20.643779813473387,31.654563553102975 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark02(-20.6591245844816,-60.66471031414971 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark02(-20.692578712781927,-69.11316645247392 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark02(-20.734849285609048,59.37576338125395 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark02(-20.83591284966539,-63.819778055710785 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark02(-20.854845520720215,1.5707963267949125 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark02(-20.96269635918742,-85.36534575758444 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark02(-20.96535338319037,70.33065203010001 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark02(-20.97684349934949,66.48376989232867 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark02(-20.985078140690916,0.0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark02(-210.25517666765504,-58.4161178736785 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark02(-2.127644756963148E-6,-2.6673593161786724 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark02(-21.34223282894321,6.090566715570972 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark02(-21.368027260148168,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark02(-21.447567820665384,-2601.7144808453827 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark02(-21.56553013386838,-1.5707963267948983 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark02(-21.5822635489382,6.376008160579269E-15 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark02(-21.666880138155438,-1.5707963267948966 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark02(-21.671762917892607,73.6480313497279 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark02(-21.699949923911177,-1.5707963267948966 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark02(-21.7607758833353,85.7551725378998 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark02(21.839728301806076,97.02078814414031 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark02(-21.843567958296177,33.58315259060791 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark02(-21.909552765360758,93.94590400935607 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark02(-21.981058588687617,135.21139746266167 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark02(-21.99090534349544,1.5707963267938942 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark02(-21.99110963328584,-32.98672286059971 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark02(-21.991122692463946,1.5707963267948948 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark02(-21.991143783351387,45.553093476569856 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark02(-21.991146003711275,-73.82754942974806 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark02(-21.991148575128502,-1.5707963267948966 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark02(-21.99114857512855,0.0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark02(-21.99114857512855,1.5707963267948961 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark02(-21.99114857512855,1.5707963267948966 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark02(-21.991148575215323,1.5707963267948966 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark02(-21.991148575228554,-1.5707963267948966 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark02(-21.99366326512437,-7.500803769994752 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark02(-22.0825263863768,-54.97787184369776 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark02(2.2156814866546633E-14,42.41150046876532 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark02(2.220446049250313E-16,10.995574287466988 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark02(2.220446049250313E-16,2427.2479780095287 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark02(-2.220446049250313E-16,-31.41592653589793 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark02(2.220446049250313E-16,4.919869733366361 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark02(2.220446049250313E-16,63.08046452453382 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark02(-22.250196078659826,0.0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark02(-22.344017924676635,-1.5707963267948966 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark02(-22.385656897233837,-36.82612250331638 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark02(-22.392033463204246,-1.5707963267948966 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark02(-22.494033538582173,0.0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark02(-22.577185012449917,-42.51957999767362 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark02(-2.279611199373363,72.74513874555623 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark02(-23.001823305417183,1.5707963267948983 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark02(-23.09605937696358,135.44093275049278 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark02(-23.123526557790797,46.56491369381703 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark02(-23.209965811529628,7.752999408027776 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark02(-23.288247743449816,9.654298262071762 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark02(-23.414509466814465,-45.493681701533134 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark02(-2.350988701644575E-38,14.13716694114925 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark02(-23.599267179868285,0.10262390755430684 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark02(-23.83286959457435,56.81959245764084 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark02(-24.065154984139483,70.52693972472574 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark02(2.4074124304840448E-35,17.278759594643862 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark02(-24.076605243549334,-0.001047870405508963 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark02(-24.20394747179408,-52.03520911890169 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark02(-24.277830130349813,-44.467894898733995 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark02(-24.45816114777908,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark02(2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark02(-2.465190328815662E-32,1.5707963267948963 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark02(-2.465190328815662E-32,-1.5707963267948966 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark02(-2.465190328815662E-32,1.5707963267948966 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark02(-24.78904597559523,1.8767616275759522 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark02(-25.088151880422814,11.018964582473604 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark02(25.13274125853688,-1.5707963267948966 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark02(-25.13274125862783,42.4115008235939 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark02(-25.132743136565747,0.5684822629995648 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark02(-25.132743156453696,186.93275406625818 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark02(-25.13298536934335,1.5707963267948948 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark02(-25.13298536934335,1.5707963267948966 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark02(-25.13664796973322,158.65042900456862 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark02(25.14836622871835,-1.5707963267948966 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark02(-25.158982183532675,14.429204474285271 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark02(-25.178235038878604,1.2100956810507082 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark02(25.194381699309577,-17.403759622588797 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark02(-25.276721246929302,-67.21314648578428 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark02(-253.27344595998778,-39.45044250216934 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark02(25.35400676811009,-1.3495307875056521 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark02(-25.35985210158921,69.58122232315884 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark02(-25.362242809276275,31.37888488389469 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark02(-25.411540371470792,-72.70779048993745 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark02(-25.415813656692805,26.895235306639535 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark02(-25.492271956232145,0.0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark02(-25.512561413248875,14.471283945338335 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark02(-25.558783031766886,3.2020398316156427E-9 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark02(-25.60720879436119,-32.59548554754786 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark02(-25.609904689171927,-30.002491183975657 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark02(-25.82281949076011,2.5707964247393456 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark02(-25.830450474077498,52.533988029721236 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark02(25.845180373981318,-100.85097796657965 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark02(-25.888065202537916,-17.27875966812657 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark02(-25.90108516507942,0.3887138759184908 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark02(-25.97454736953091,-0.11938764655470033 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark02(-2.6010428619592907,14.429397540630347 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark02(-26.048567350254615,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark02(-26.09639920566225,2469.6342737208165 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark02(26.130052431084245,-0.20475673665933694 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark02(26.152301450429192,-89.43410692576136 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark02(26.19806115532364,-99.11888178711932 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark02(-26.24929755250578,-54.03613252060428 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark02(-2626.69391903563,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark02(26.28162317054516,107.20566339022035 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark02(2629.221835446862,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark02(26.293240039395698,-100.0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark02(-2637.0798069619386,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark02(-26.40249132514296,16.460225094509685 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark02(-26.41149111216943,0.0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark02(-26.501320925902647,2668.9364749750653 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark02(2.6738954223972697E-8,86.57773044455294 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark02(-26.7878842995387,-36.17321329437928 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark02(-26.882682274916675,0.1683834263729781 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark02(2.689802892869043E-15,-38.00995510450426 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark02(-26.96659496799474,49.62753825051743 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark02(-26.967568979088114,-0.6075608023677137 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark02(-27.15651643529202,2711.809617609864 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark02(-27.24970606835535,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark02(-27.33970320359809,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark02(2735.8639701218417,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark02(-27.53890100288095,-125.15402276167187 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark02(-2.7566147671678216,0.05308434180229932 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark02(-27.799984663181203,-1.570796326794897 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark02(-27.862461914116082,-1.5707963267948912 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark02(-27.93882964804219,-226.21176316354874 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark02(-2.797650025981507,-77.36050553060521 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark02(-27.97943306391614,1.5707963267948966 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark02(-27.979759918756614,4.291143392456905 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark02(-27.993107299426796,1.5707963267948966 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark02(-28.020563082321196,91.09993725186993 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark02(-28.048788937552942,43.66670136817699 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark02(-28.073630402803154,1.5707963267948948 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark02(-28.097290452284863,-0.5707586030254835 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark02(-28.179953249143082,-42.405040843295836 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark02(-28.19497627856982,-32.98672279385662 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark02(-28.222688824190442,0.0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark02(-28.22422425445975,0.0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark02(-28.247308813494982,-1.5707963267949197 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark02(-28.274310995373444,-64.40264939859074 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882308113,0.0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882399326,36.12831551627381 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark02(-28.27433412083695,89.53563504766018 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark02(-28.274394917464395,-42.41150081277356 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark02(-28.27639847663642,-14.137404269324255 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark02(-28.35665574180115,-1.5707963267948983 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark02(-28.368141749160564,1.5707963267948972 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark02(-28.405397999870658,-15.281751681835622 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark02(-28.451663847953128,-1.5707963267948966 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark02(-28.48889149136117,0.25446567171914963 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark02(-28.518144577392405,35.10960095217342 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark02(-28.621368808587548,100.0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark02(-28.934085863776303,-25.576071314102023 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark02(-28.956616497189838,-0.03390355651225268 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark02(-28.99843629550881,-0.324730298190396 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark02(-29.045797531767974,23.56194500734311 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark02(-29.06319140797153,68.48102467410922 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark02(29.27624708322719,-54.49502204286336 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark02(-29.449038898624735,-11.717122593373276 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark02(-29.515725520059988,71.74256338376546 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark02(-29.625294519169174,81.5672103110597 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark02(-29.6544032650664,-0.1907269445641194 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark02(-29.77874193831198,99.88408149055093 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark02(-29.801154252492168,0.0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark02(-29.95061777357472,-66.87382124202068 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark02(-30.018512898691128,-1.5707963267948966 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark02(-30.18861731628381,55.57125968319336 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark02(-30.26098914126134,-1.5707963267948966 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark02(-30.278763356740996,-69.54867152685141 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark02(-30.28017272291204,-17.679872078046955 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark02(-3.0447287213794354,2.070796326794897 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark02(-3.0814879110195774E-33,1.5707963267948963 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark02(-30.818397004782856,-7.257293338231165 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark02(-30.885739015983724,38.56889784462322 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark02(-31.124806313203106,-32.69560264010239 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark02(-31.17674669937891,0.0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark02(-31.178053332312203,52.900593814481056 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark02(-3.130765148980828,0.0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark02(-31.415926536829257,-1.5707963267948963 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark02(-3.141592654055455,-1.5707963267948966 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark02(3.14159266875996,-1.5707963267948983 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark02(-31.41680313624948,64.40264939480085 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark02(-31.4190268451203,-84.96598600843375 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark02(-31.445096175470475,0.0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark02(31.44717653615417,-1.5707963267948992 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark02(-31.447178021573695,-29.845618490353036 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark02(3.1455006110466854,-83.25611233923071 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark02(31.459049159460506,53.70953481052777 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark02(31.470090858883346,-16.556905769073268 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark02(3.149405153589797,-1.5747240968646734 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark02(-31.51019625886616,-19.434136876446544 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark02(-31.564901421240098,168.0885868827261 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark02(3.1572187714014013,7.86657621560178 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark02(31.622847158310464,-15.820423214622338 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark02(-31.6270282643339,-38.55587687984293 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark02(3.1632749984335646,-10.973891942620485 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark02(31.638020918597018,-111.74863358503423 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark02(-31.676668760953696,0.17210376725924012 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark02(3.1728426563790473,-42.395756007894036 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark02(-31.751752208871167,0.0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark02(3.1760996946351305,58.15397113255656 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark02(31.765128017667124,11.543645506744156 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark02(31.779805088387548,88.72889198668099 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark02(31.818425065881,0.0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark02(31.937320964098724,41.181355920870004 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark02(31.948529240756358,0.0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark02(-31.995634802223066,0.0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark02(-32.01993904039953,1.5707963267948966 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark02(-32.102249996495786,0.0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark02(-32.13407397374533,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark02(-32.138168050895715,80.7271939375974 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark02(32.28540976668225,1.570796326794897 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark02(-32.44576985116963,0.0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark02(-32.55635309558691,44.48395054985175 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark02(32.636177195916275,-1.5707963267955982 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark02(3.2665926535902106,-42.32960541686049 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark02(3.2665926537073386,105.1672044647917 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark02(-32.70856856925482,63.680265528500655 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark02(32.71095208229819,-1.5707963267948966 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark02(-32.726914947533835,1.5707963267948966 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark02(32.79202821446936,-2556.814254024908 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark02(32.83143279536932,-91.83009416267987 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark02(-32.86424374941393,32.34864940579999 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark02(-3.287899995531566E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark02(-32.97505027830199,0.0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark02(-32.98122983590215,1.5707963267948966 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark02(-33.043978886172084,-43.75431525279294 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark02(-33.381854011660224,7.287402501599801E-10 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark02(-33.397588572386255,-15.99013989034421 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark02(-33.51974380719757,-78.23000593945694 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark02(-33.623856667359505,-2538.8967568233797 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark02(-33.813586644297544,1.5707963267948966 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark02(3.3833693174130475,-20.662128912259906 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark02(-33.90247465526551,-23.67860101693838 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark02(-3.41864600040455,-19.75060224571343 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark02(-34.31206244076267,1.5707963267948968 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark02(-34.347131341405216,0.5281961906591757 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark02(-34.55739280459028,0.5707764226334532 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark02(-34.55751890562108,1.5707962540237554 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark02(-34.5575191031389,-1.5707963267948961 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark02(-34.55963421562174,5.091017973257377 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark02(-34.57482297091032,-85.78343443924463 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark02(-34.63900112655392,-2620.640555984727 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark02(-34.63979143451734,-1.5707963267948966 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark02(-34.68058701125739,14.71430037662445 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark02(3.469446951953614E-18,-89.53539062740909 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark02(-34.74264768204152,-90.72659305230108 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark02(-3.4754905702946886,60.87929128343782 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark02(3.476678531640338E-11,89.53539062737434 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark02(-34.78645918163551,-87.92900992634848 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark02(-34.84224471787928,1.5707963267948966 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark02(-34.88581347342897,-2602.96124913829 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark02(-35.05849219273753,-65.94197487702593 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark02(-35.084240292990366,-9.725657052417901 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark02(-35.18839665332103,-18.260633198514654 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark02(-35.308798574937185,20.59275871625026 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark02(-3.535014537577169,80.11061266653972 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark02(-35.51588162609367,-57.161101654979184 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark02(-3.552713678800501E-15,-37.939156944058546 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark02(-35.56862637715636,0.0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark02(-35.57133281369309,0.37875981489276295 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark02(-35.618511009080365,-0.4420339359896951 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark02(-35.66543908624739,-66.07191860043444 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark02(-35.834939737862115,-59.58515029807585 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark02(-35.91258735313406,88.93849763292957 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark02(-35.929384452438605,1.5707963267948966 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark02(-36.0000502349045,-0.12826528215983368 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark02(-36.04913382898558,22.54802714385397 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark02(-36.11083252631866,-141.76097751962033 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark02(-36.128317134529546,-7.975114041952968E-8 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark02(-36.35080196452286,0.0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark02(-36.408244769575816,0.2799292536551313 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark02(-36.463134478953755,-88.97542429251376 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark02(-36.485601156445924,-88.38581313790226 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark02(3.660924963387174,73.67784573103287 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark02(-36.62876939240958,1.5707963267948966 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark02(36.652524153058664,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark02(-36.75678084342762,-69.7384613549384 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark02(-3.687397798037665,-96.11869056379506 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark02(-36.87514955534783,93.37144315845538 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark02(-36.988831528486415,87.41948678923654 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark02(-3.76158192263132E-37,-1.5707963267948963 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark02(-37.6991118430775,-80.11061266643975 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark02(-37.69911375177758,-1.5707963267948966 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark02(-37.69960980727952,0.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark02(-37.70106496815648,48.69502831362442 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark02(-37.714736843077524,-1.5707963267948966 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark02(-37.83784234741508,0.0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark02(-37.87413791688148,0.0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark02(37.928051193405224,-51.01972933556578 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark02(37.949111843077524,1.5707963267948966 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark02(-37.969931335857936,-1.5707963267943463 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark02(37.991309770660195,1.5707963267948974 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark02(38.01985385926207,-0.03755607497532159 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark02(38.04841585854683,-84.81357765733155 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark02(-38.070245352659015,83.62333882981832 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark02(-38.076006316804,-98.94299075291171 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark02(38.127629341614494,-1.5707963267948948 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark02(-38.13116676297689,0.0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark02(-38.17675323068005,1.570796326794897 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark02(-38.18523204478104,-37.845007605207826 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark02(38.229831870297886,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark02(-38.29395800269051,0.25774113104775165 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark02(-38.36971607274844,-40.5366487016297 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark02(38.42328790335458,0.0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark02(38.47185612111913,-1.5707963267948966 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark02(-38.47324891896322,-40.21433442029802 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark02(-38.47807262387937,-1.5707963267948972 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark02(-38.49665306799312,7.320017179201889 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark02(-3.8528084409726375,-6.61520668772742 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark02(-38.57109284686713,-17.69301503546916 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark02(38.64618480771034,-13.806549671213446 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark02(38.64997031146473,36.12831552204051 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark02(-38.68517318268021,-12.437345621867422 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark02(-38.723123727860596,82.62205899876005 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark02(-38.825153846999605,-1.5707963267948966 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark02(-38.838140204558044,-1.5707963267948966 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark02(-38.839467859331876,-58.61254440168302 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark02(-38.85692708243791,2612.4675513257 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark02(-38.878109681444805,1.5707963267948966 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark02(-38.88419159137502,-57.22480990300487 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark02(-39.06902242998351,-1.5707963267948966 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark02(-39.19482682858744,-53.74910649042127 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark02(-39.195065909148184,-2.0219698492442504 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark02(-39.23439796888247,191.6726620671522 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark02(-39.23581850375893,-1.5707963267948966 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark02(-39.504786635904345,0.0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark02(-3.9722179905745385E-15,9.860761315262648E-32 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark02(-39.72772108792086,94.46633261509875 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark02(-39.77105412793305,-18.830604537787735 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark02(-39.817484810494136,2.5940160131601515 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark02(-40.1099314809972,1.1297633490748344 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark02(-40.15789524746276,-94.8635627812936 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark02(-40.35436214790842,-10.977982907695925 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark02(-40.578388381285,-1.5707963267948966 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark02(-40.71797710401561,-51.19159944556595 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark02(-40.84070041663253,45.55309347705166 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark02(-40.86608747521343,-88.72894483240769 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark02(40.94420786392038,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark02(41.16732647985154,-98.81934329082962 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark02(-41.322220125990356,-1.0892806975846825 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark02(-41.40987923548318,-53.40185157039365 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark02(4.1415925210586195,-9.995553701050104 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark02(4.141592653589795,22.76644266821444 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark02(4.1415926625211865,-2.0255880556191626 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark02(4.141624716781487,10.799296601868184 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark02(4.14786714160373,-53.97159694962066 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark02(-41.52098160254405,27.22827555295729 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark02(-41.55516624884608,74.01683785584513 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark02(-41.65276395231098,-43.22356027896053 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark02(-41.717747970768706,-1.5707963267948912 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark02(-41.975076193756145,17.83737765688197 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark02(-42.02840813360946,2612.7116511318295 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark02(-42.11157184013674,-1.5707963267948912 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark02(-42.28266791038025,1.5707963267948966 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark02(-42.288734785187465,44.37636736119383 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark02(-4.2351647362715017E-22,-51.836278781673755 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark02(-42.35483246857334,129.05139934680855 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark02(-42.36342161490663,-94.25582548213033 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark02(4.250122335214033,97.85163890623002 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark02(-42.581314775159726,0.16981395228920895 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark02(-42.62572378325011,17.036824208526838 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark02(-42.647176344482915,0.02212750499885991 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark02(-42.68962742861051,-40.39780124713842 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark02(-42.698989523512445,0.5424791569829229 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark02(-42.71815642371588,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark02(-42.73162650624758,-29.125357476821897 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark02(-42.73978544834626,35.87132179738981 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark02(-42.75423445079003,81.99282331116198 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark02(-42.777589543367455,80.58826426870718 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark02(-42.79892527140524,77.89983144130159 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark02(-42.80024549675076,50.65422713098908 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark02(-42.81445019186574,0.0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark02(-42.84714186688805,24.4669511942163 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark02(-42.8492523577637,1.5707963267948968 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark02(-42.85200190549541,99.80794588834003 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark02(-42.87527930766392,32.971629820546674 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark02(-42.88516909957315,1.5707963267948966 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark02(-42.96778674623899,2531.2564807936556 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark02(-42.96899736294363,-2583.539514992444 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark02(4.305756462673261,-72.66326355002384 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark02(-4.333961640861645,51.35661115853665 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark02(4.3350152710174475E-11,95.63279956279035 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark02(4.3368086899420177E-19,-1.5707963267948983 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark02(-4.3368086899420177E-19,4.712877261649998 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark02(-4.3368086899420177E-19,73.84305235936014 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark02(-4.356883097167896,24.62731422502715 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark02(-43.78189731480102,-68.30551518482446 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark02(-43.81730923995344,-49.69559309831671 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark02(-43.85559749291667,76.79512390852256 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark02(-43.897045736103465,-81.6260853403399 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark02(-43.96891468205495,52.401458317195974 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark02(-43.9822971501571,-1.5707963267948966 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark02(43.98230576076785,-10.995375378345205 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark02(-43.98278544523696,1.5707963267948966 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark02(43.99110218987542,-1.4713215247452844 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark02(-44.08398810728264,-42.90032385588691 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark02(-44.11038278927404,0.0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark02(-44.13701394685486,14.736698561644129 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark02(-44.18737082945806,-0.034600652383022394 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark02(-44.3200555481824,37.337734761786706 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark02(-44.36934864309154,-1.5707963267948968 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark02(-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark02(4.440892098500626E-16,0.02672835425696169 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark02(4.440892098500626E-16,-1.5707963267949054 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark02(-4.446008625541481,-0.25155136112611054 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark02(44.48580783603447,28.498663883713505 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark02(44.59010537702772,-0.025330780898954797 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark02(44.614933142822125,-45.94755937189288 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark02(44.68459507160279,55.32118201233976 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark02(-44.74665841517107,-18.033064847295805 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark02(-44.85499347869176,9.383995238020084 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark02(-44.85684878180414,1.5707963267948966 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark02(-4.488682957042016,-0.22577970621411225 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark02(44.95503660118273,-2550.5597946660623 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark02(44.95563930350069,-100.0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark02(-4.500948392970829,-44.92945883690021 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark02(-45.03970444889549,-1.5281383436085627 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark02(-45.177411375060615,1.5707963267948968 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark02(45.27237939488211,-90.56166947764953 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark02(-4.527843205727789,-100.0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark02(45.348082238039396,-31.620937775401735 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark02(-45.39717963599018,-1.5339003917552319 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark02(45.426667804519944,-1.6906796068084162 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark02(-45.45262705572978,-87.92333509155623 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark02(-45.581520237306464,136.4295592327436 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark02(-45.63757586280399,-0.24149729994498342 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark02(-45.64135062808374,47.56457677684645 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark02(-45.853015102610684,-1.100792790715957 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark02(-45.93226475799514,-0.131122602704977 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark02(-46.24123658951815,1.5707963267948968 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark02(-46.26619869388996,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark02(-46.3250763386506,-92.31819373578954 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark02(-46.489411503267554,-14.221354753618655 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark02(-46.507328884241346,-0.35487250400661463 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark02(-46.70234346293187,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark02(-46.79026894495013,0.0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark02(-46.91370068136903,-2.0707963269777028 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark02(-46.9352569475447,-1.5707963267948966 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark02(-4.696274861226748,-169.62988916849343 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark02(-47.04682066838188,0.0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark02(-4.71238898038599,0.0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark02(-47.123889803946405,-1.5707963267948966 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark02(-47.26579108695263,-36.77873814231929 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark02(-47.355477396470306,18.493343593057034 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark02(-47.36148380601426,1.5707963267948966 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark02(-47.44867366283134,-74.20386874147685 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark02(-47.45472112425948,-36.16460589319091 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark02(-47.51327394093416,83.50143346555302 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark02(-47.762904897788815,60.04071443293195 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark02(-47.79076119595639,-0.34677491392779103 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark02(-47.83205324852527,0.0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark02(-47.850853164136865,49.09696179533145 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark02(-47.94815452965962,-87.79849092613111 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark02(-47.96524016614582,-1.5707963267948966 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark02(-48.06201042226472,-75.3319795278313 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark02(-48.07004989993702,0.6246362308757749 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark02(-48.09006665677144,-1.0688374800798748 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark02(-48.09663916470526,45.21534781000383 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark02(-4.8148248609680896E-35,-1.5707963267948966 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark02(-48.54671693019724,-93.22477677794272 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark02(-48.55963807957204,34.487605272965084 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark02(-48.58116738591099,39.0921531541637 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark02(-48.60057663762569,62.69181488671866 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark02(-48.67453651956151,0.0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark02(-48.69468613071013,0.0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark02(-48.70252314559086,4.712388980384799 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark02(-48.75741529673742,0.4116433761101512 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark02(-48.75919393617288,1.5707963267948966 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark02(-48.76604696133677,0.0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark02(-48.789041439756524,37.52390154845858 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark02(-48.81673181297686,0.5938518048676666 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark02(-49.128507693611496,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark02(-49.282634176662924,8.157542942377447 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark02(-49.290892850584235,-1.5707963267949054 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark02(-4.92978384739093,1.5707963267948968 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark02(-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark02(-49.5697015706998,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark02(-49.60894828502326,-0.44678041710154026 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark02(-49.706822382564035,0.0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark02(-49.761739880089614,85.8271967540988 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark02(-49.7818827976586,1.5707963267948966 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark02(-49.8200563172282,2.8358924804253434 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark02(-49.90215206353842,0.0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark02(-49.94836561307756,-0.31222911776665885 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark02(-49.95412070391772,35.97942286529798 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark02(-49.987415138320635,1.5707963267948877 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark02(-50.008939442023404,0.0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark02(-50.01042875020409,96.3136201734222 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark02(-50.021284831744,-92.57795500080354 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark02(-50.037185760910305,135.09091309061083 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark02(-50.07230919145227,129.32678245086132 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark02(-50.13780836772587,72.52847743283891 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark02(-50.13894799475271,-4.962388980384698 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark02(-50.152140508764944,-4.837388980384693 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark02(-50.160665408900485,51.05446272738824 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark02(-50.22271876873443,-2548.669716560454 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548244479844,64.40313773106169 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark02(-50.265482457336695,1.5707963267948966 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548901288176,-0.5668509730139123 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark02(-50.265506254568194,161.80273230339057 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark02(50.293538740829554,-19.349065309095124 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark02(-50.29673245743707,29.84712600427762 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark02(-50.301955020763685,-1.5707963267948966 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark02(-50.3273488432578,-2678.4011687001366 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark02(50.37486879168996,-70.93417728181223 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark02(-50.430515871440825,-96.00507557354312 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark02(-50.46353526875215,-15.397649079780432 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark02(50.51291809662834,53.346760628279355 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark02(5.063011283709557,39.86277703186903 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark02(-50.65502555493492,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark02(-50.77267625234057,79.62153797337061 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark02(-50.77523371651351,-1.5707963267949054 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark02(-50.80376876603727,-1.5707963267948843 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark02(-50.816097487503264,71.79735478687209 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark02(-50.888579492175424,-35.36124596749429 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark02(-50.89851567511417,44.49478322346005 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark02(-50.91472492356737,1.5707963267948983 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark02(-50.95111321706041,4.047413704350663 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark02(-50.95164949069304,-44.26783079730022 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark02(50.96301975366876,-1.5707963267948966 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark02(51.06650914394902,-3.199763160196369 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark02(-51.083405051189914,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark02(-51.089915314525186,-10.405229209667322 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark02(-51.10123440688269,1.5707963267948966 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark02(-51.153732035923085,1.5707963267948966 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark02(-51.17191569429151,-2637.0548140397186 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark02(-51.19417452419297,-4.712388980384689 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark02(-51.266452148840784,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark02(51.38501184469047,-84.83474842953433 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark02(51.39303088859453,-26.461525117477898 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark02(5.1415926577673146,13.186861049828273 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark02(-51.49351822017601,-4.447380973739939 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark02(-51.63325432623861,-1.231000161200227 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark02(-51.6535963456261,46.94120736579184 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark02(51.7506692705565,-88.05020381535863 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark02(-51.90623579221241,33.83957154735717 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark02(-51.95118786057877,40.80439156202806 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark02(-51.95788999901738,42.57680029220262 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark02(-51.964290218573424,-96.08061549238802 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark02(-52.270695468990105,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark02(-52.49525485103841,-2607.9487985253936 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark02(-5.2560059258220284E-21,-45.553093465924064 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark02(-52.57825236193947,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark02(-52.60485442644756,2635.731787216716 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark02(-52.64318090007314,-117.91627898015201 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark02(-52.80206365277806,-0.046770424328802615 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark02(-53.200476516428736,0.0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark02(-53.40707490210317,51.83627878420901 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark02(-53.40707506318352,1.5707963267948966 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark02(-53.40707510873328,-36.128437586596334 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark02(-53.40707511099012,-1.5707963267948966 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark02(-53.40708120690834,73.82727805689996 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark02(-53.476746414499246,-24.514337173306004 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark02(-53.47780258920714,-73.24660019556606 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark02(-53.511772681288214,-46.50936295818988 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark02(-53.581019731463385,32.34347296862444 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark02(-53.65104056245541,0.0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark02(-53.84677604515247,-142.02271678729196 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark02(-53.87947693534551,45.444460863130445 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark02(-54.039319750478185,61.997415511232134 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark02(-54.12028481712663,0.0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark02(-54.163482228242735,2612.900173189717 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark02(-54.18393449815451,-1.570796326794897 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark02(-54.23804459994683,-81.81171220354445 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark02(-54.3678109329935,-5.13444421294426 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark02(-54.416859423014046,43.42128513526181 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark02(-54.49180586710292,0.0197277534913572 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark02(-54.587362021417405,135.49796309581257 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark02(-54.774789663187455,-31.769259030305435 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark02(-54.862794333837805,-0.01715905498900372 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark02(-54.9458029003697,-135.5282748023187 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark02(-54.97787143781541,0.0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark02(-54.977871437823325,0.0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark02(-55.045235921739504,97.38274078092931 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark02(-55.05470024508272,0.528701624882928 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark02(-55.057735918814444,14.966734727573098 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark02(-55.09935667277219,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark02(-55.09959172340761,83.4834889204206 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark02(-55.1015681130705,11.934337013863768 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark02(-55.123538361165274,4.717998064782812 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark02(-55.12800798817108,169.52876791138257 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark02(-55.12860305121548,1.5707963267948966 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark02(-55.17956446593672,0.0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark02(-55.17966780362406,40.13311246660223 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark02(-55.23031669283813,-46.59251320903897 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark02(-55.2607764002631,-69.59315717850953 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark02(-55.366343600567006,49.87701029442706 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark02(-55.40866322145865,3.196030932059551E-7 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark02(5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark02(5.551115123125783E-17,-23.56194490186149 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark02(-55.560887641568094,-1.5379806807681278E-11 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark02(-55.56110166631957,1.5707963267948966 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark02(-55.7946195401895,-70.9923313985751 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark02(-55.931782575043435,74.44431254881039 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark02(-56.02578508819002,0.09482498842009433 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark02(-56.057149980007985,143.43398352283046 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark02(-56.10786771931669,0.0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark02(-56.13650760625583,45.25795616160019 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark02(-56.234975450514746,1.5707963267948966 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark02(-56.25331922390912,1.570796326794897 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark02(-56.26755562974846,0.0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark02(-56.344529161797304,2523.606469344912 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark02(-56.36371742628712,18.157809022033675 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark02(-56.42198402590005,0.0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark02(-56.4351197359494,17.183606273264388 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark02(-56.48035548407571,80.35747376683332 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark02(-56.53652436534016,0.03389169263154343 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776461415,117.80709041868283 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark02(-56.548667768357966,0.0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866824145344,0.0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark02(56.54870270328375,-124.09290832679092 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark02(-56.569242516233885,-127.23450247001865 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark02(-56.61493859120193,26.633639450711357 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark02(-56.63150597806839,0.0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark02(-56.66716988609384,11.70758235864011 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark02(56.75628916844821,32.77910145896309 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark02(56.79256034842008,-63.59658384020783 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark02(-56.9404894850946,-79.23874210152293 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark02(57.0381069546701,-73.31799227329881 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark02(57.091871614662324,0.0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark02(-57.168555692489264,86.00157039796096 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark02(-57.329421648018844,50.26548245743669 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark02(57.376011608182594,-1.5707963267948966 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark02(57.3948750883568,-2510.0028477771402 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark02(-57.3970748670769,67.28330454280191 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark02(-57.53440651304265,38.67337356765624 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark02(-57.610853402331855,-100.0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark02(57.68139483590164,-25.646586536426682 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark02(57.68352098421182,-15.881172086729627 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark02(57.706980246819626,-1.5707963267948963 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark02(-57.75536497375977,1.5707963267948948 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark02(-57.78358155647926,-0.42649894747405226 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark02(-57.83374066498159,-53.692798537101275 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark02(57.86363829967067,6.027359515043899 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark02(57.86917074587653,-0.2502933459383706 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark02(-57.941929454952536,26.482928281057724 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark02(-58.00406598848669,47.239287905902984 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark02(-58.068301119081525,-8.270334028616169 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark02(-5.826199619940326,-51.83627878423159 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark02(-58.4661559227093,95.80948980471612 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark02(-58.727963271969585,45.444161670347164 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark02(-58.746607262419786,97.58465665091566 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark02(-58.767868894005204,0.25434596970914974 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark02(-58.80246267644422,-84.39212066724318 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark02(-5.880527563340962,13.464836186528998 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark02(-58.886423366961886,-1.5707963267948966 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark02(-59.315889933151226,71.89321096121088 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark02(-59.3223441831558,14.4300496089255 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark02(-5.955784315536789,39.51803258936607 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark02(-59.69025945141287,-14.137166941154064 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark02(-59.71823313696304,-37.94179230356616 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark02(59.888682560622016,44.928121074447404 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark02(-60.15334453878077,-1.444574590773012 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark02(-6.018531076210112E-36,29.84513021003436 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark02(-60.414838525808555,-82.52762721266059 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark02(-60.42600797880142,44.989668571002426 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark02(-60.463558264601566,-74.89948240339567 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark02(-60.57944585817556,0.0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark02(-60.61905236392521,102.62650114410218 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark02(-60.87170206716176,1.5707963267948966 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark02(-60.966736893949495,-99.97858537302787 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark02(-60.97095638317101,63.87710540772835 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark02(-61.027435634563055,-31.499284827854694 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark02(-61.13108024696765,44.112273649061905 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark02(-61.156898287150284,-1.5707963267948966 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark02(-61.200230766436356,-94.27881753388773 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark02(-61.20188246260903,2557.85832736933 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark02(6.123187395210333,142.77850165437485 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark02(-61.252330478831176,-0.4073498109791577 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark02(-61.26105674500277,0.0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark02(-6.130865264044404E-10,53.00546806918211 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark02(61.414415108643226,20.84731183736433 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark02(-6.144604015814766E-10,-83.25213268636699 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark02(-61.64442784667501,-0.3833711019413832 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark02(-61.65433244711656,2627.8547574586664 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark02(-61.72976857778005,-1.5707963267948912 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark02(-61.750817306751,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark02(-61.810431901483284,-43.43292199358328 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark02(-62.11589882132226,63.78213502080692 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark02(-62.323833301842555,14.610740160415673 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark02(62.55944126278081,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark02(-62.57969555001177,-83.7896726437776 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark02(-62.588753763942925,0.2505325234749654 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark02(-62.606655729906045,-30.83669456007702 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark02(-62.648041216601854,-88.51668759489613 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark02(-62.770210911961016,0.0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark02(-62.78274847170358,85.93737355358621 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark02(-62.83185112025578,-221.49810134114225 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark02(-62.83185307172919,120.95229456043673 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark02(-62.8318530717605,-1.5707963268595304 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark02(-6.283185336982028,-1.5707963267949734 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark02(-6.283185785107346,0.5707955846745248 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark02(6.283185928946861,48.6946861306418 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark02(62.83192504690365,-14.137167731746175 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark02(-6.283192712391315,1.5707963267949125 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark02(-62.83283371647951,-48.69859241785023 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark02(6.2841619117694085,45.553091505210276 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark02(-62.89435307179587,1.5707963267948963 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark02(6.293294128743411,51.82616996276777 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark02(6.294035864068983,32.97872812180829 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark02(62.97006681676416,68.23222991177644 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark02(63.01890611407606,84.38699582075036 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark02(-63.06567517733583,-0.5642276132607577 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark02(63.072651798567954,-1.5707963267948966 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark02(-63.11050207667108,30.215168943587475 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark02(-6.313066831138443,-23.992345453126788 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark02(-63.15203920158613,-2570.2447384367015 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark02(6.319564229066113,-64.36753693279888 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark02(-63.23348221763938,-96.39962128805257 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark02(-63.23976248837162,0.0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark02(-63.3295320280024,68.95254492785617 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark02(-63.34038590882578,54.14115076841051 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark02(-63.34356921176732,0.0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark02(-63.415571585985944,0.1601398907507237 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark02(63.45870218410173,5.339238092567082 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark02(-63.461325029359486,-72.1700394116072 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark02(-63.54140856643254,-15.462970149452559 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark02(63.57949231337918,-157.56761296882334 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark02(-6.374587140823695,18.693898804580705 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark02(63.79080894570569,45.10113320973815 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark02(63.79346569022319,1.5707963267948966 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark02(-63.9305089311627,-17.22475542879893 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark02(63.943052168092294,29.239961678589253 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark02(-63.99316822136143,87.96459430051421 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark02(-63.997216046633596,0.0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark02(64.01621912033048,5.020347775242797 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark02(64.01710978797173,0.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark02(64.03023842857317,-0.0022059079258869908 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark02(-64.04185768400927,100.0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark02(-64.09022999663709,8.84848067427772 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark02(64.1392000825756,-95.80587232056907 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark02(-64.16338241686881,-1.5707963267948983 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark02(64.17712121603239,-42.963584741232786 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark02(64.23586882101083,-27.620080669945082 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark02(64.24896421894056,-80.75396074584573 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark02(64.25298806766483,0.0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark02(-6.433677750797161,0.0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark02(64.35745778002965,57.00694320583227 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark02(64.3614324192468,1.372798746359287 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark02(-64.45338202883107,74.0225334538907 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark02(6.452878211309461,-1.5707963267948966 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark02(-6.469381261752943,-68.36905712706157 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark02(-64.99646904823548,67.2387982910268 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark02(-65.09102141815096,-84.13462962752163 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark02(-65.3147438171248,70.86638859465938 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark02(6.533185307179587,55.08907757999917 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark02(6.533185307179588,1.5707963267948974 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark02(6.533185307179588,-45.41293323280718 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark02(6.533185307750888,86.49795782911947 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark02(-6.53318530983969,-42.247526018182235 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark02(-6.533683920582231,-67.45851307104073 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark02(6.533887443847902,9.291971194168553 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark02(-65.35927896383532,-69.29472917841157 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark02(-65.53382625274169,0.0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark02(6.557569295815497,2630.1992961611827 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark02(-65.88677444222613,-53.21854307355676 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark02(-65.96593228402769,-1.5786088268225227 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark02(-65.97344572531057,-80.11085680732468 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark02(-65.97344572538564,-1.5707963267948966 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark02(-65.97344596891693,-48.69468601308631 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark02(-66.02877841166469,1.5707963267948966 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark02(6.609387840101034,-5.03859151320057 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark02(-6.61140966286402,54.8572377696147 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark02(-66.11875082416427,1.5707963267948968 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark02(66.26483290671092,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark02(-66.29157998499855,81.98271700993149 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark02(-66.39280028520902,16.72721909740652 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark02(-66.40058733204498,-1.5707963267948966 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark02(-66.42371978203842,0.0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark02(66.5714573256653,-89.062967864395 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark02(-66.61171048273224,43.04976558068427 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark02(-66.66017993454213,-66.06161538049835 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark02(-6.666911863076265E-15,-1.5707963267948815 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark02(-66.7092639276747,-0.492056129494263 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark02(-66.78180164815967,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark02(-6.679691722857591,-146.4805648077118 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark02(-66.83888647990932,-13.984379723437169 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark02(6.693382518993473,-1.5707963267948968 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark02(-67.01875805480718,-2566.9399310614685 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark02(-67.07287397163873,68.98354692701758 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark02(6.709553511774274,89.08770837531301 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark02(-67.1904530064257,1.5707963267948966 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark02(-67.20897930139346,83.82748604814249 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark02(-67.2229227083878,-44.23768250545439 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark02(-67.25284136452726,-2586.5513326513737 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark02(6.734148287502649,-97.35810596688994 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark02(-67.54424205217985,0.0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark02(-67.63970802619359,-30.71794895423517 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark02(-67.73644902642721,-42.684351593408735 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark02(-6.774905778668395,-0.001966573762042368 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark02(-67.82352040156532,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark02(6.783368658516686,-61.76124009622411 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark02(-67.94109735827156,99.96318327066976 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark02(-67.99123350954412,44.98841808816715 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark02(-6.809553492263271,-71.2116660263473 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark02(-68.25675767848679,-1.5707963267948966 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark02(-6.8310694096619216,-0.08025371005700961 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark02(-68.44008114282153,-1.5707963267948966 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark02(-68.49027523493604,-10.462894772312922 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark02(-68.54467228223623,-76.94917097469744 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark02(-68.66388543804123,-0.2537140912384826 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark02(-68.72755861578926,-20.27417409682893 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark02(-68.84544679153679,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark02(-68.88088517912414,5.972376466852339 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark02(-69.03837150532799,47.22815042935517 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark02(-69.11503885584308,95.81857185244112 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark02(-69.115307579637,0.5449135829531341 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark02(69.11550647185746,-0.010540281325595318 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark02(69.11699200744627,-17.278759594743857 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark02(69.11699274628708,80.11061096801134 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark02(-69.1170798367417,-1.5707963267948966 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark02(69.11937067634224,-14.13716730284235 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark02(-69.13990340161187,48.25840858553829 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark02(-69.27318610413897,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark02(-69.3151592072363,-0.039114233149811266 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark02(69.34494677818847,0.0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark02(-69.35495816670209,44.11856704900209 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark02(-6.935842354321622,-16.75932792965159 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark02(-6.938893903907228E-18,0.0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark02(69.4008887120255,-84.75259889045212 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark02(-6.940347069575111,42.369283560318124 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark02(-69.41178507772784,172.7822385020479 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark02(-69.43204687568837,14.454175437972234 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark02(-69.46093764643847,0.0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark02(-69.50421879270598,-77.931010260226 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark02(-69.61626802121742,2574.639208384066 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark02(69.61872599222733,43.85630787653632 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark02(6.962322230831191,2594.2397825473267 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark02(69.68693634148906,1.5707963267948966 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark02(6.970032707439387,17.18917442294874 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark02(-69.71403503026448,90.06630028295228 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark02(69.717794856246,-44.17920247948104 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark02(-69.73296131136081,-27.321460488021287 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark02(69.79109908403238,55.653932142750115 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark02(-69.92506702433839,-1.5707963267948966 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark02(-69.9414181497006,-1.183077736106668 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark02(69.98407943157628,-1.5707963267948966 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark02(70.22326784814595,82.40318726073912 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark02(-70.22554705571504,0.10077056964033204 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark02(-7.029224655127826,0.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark02(-7.030569876663293,-22.814560332303405 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark02(70.39781931778099,67.2090730264868 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark02(70.41178989346042,-4.424008134626178E-6 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark02(70.42941222840687,0.25642247775775473 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark02(70.55014765278162,-25.268428282446276 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark02(70.55852960990555,0.0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark02(70.58474651341209,-22.439738165685384 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark02(70.5950892450343,-27.671443889484152 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark02(70.59776469002136,0.12525707572765754 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark02(70.62308362908121,58.71286323983754 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark02(70.64347048710638,-0.042364221024107855 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark02(-70.67288826137701,26.764196719816425 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark02(-70.68239699609443,-44.47800638579653 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark02(70.6858347057652,0.0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark02(7.080709043679363,-83.95316797302635 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark02(-70.8134396032405,-67.16641905139397 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark02(-7.083599000153912,-1.5707963267948966 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark02(-70.91806326448355,46.76403387721814 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark02(-70.97244534133675,27.555469503399507 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark02(-7.105427357601002E-15,0.3595507924497513 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark02(7.105427357601002E-15,81.11684085420819 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark02(7.112097704764114,-1.5707963267948966 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark02(-71.29319866990627,33.816622818247964 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark02(7.134953386875299,-36.20647210224601 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark02(7.142302573588664,0.0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark02(-71.56774496590668,-9.559385834006505 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark02(-71.58633442270761,1.2401589499058803 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark02(-71.65483189475145,80.2143197012923 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark02(71.73811529159215,7.2176436288931 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark02(-71.88099979790444,-95.02569373771661 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark02(71.93237065878782,-84.23340295258002 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark02(-71.95684593683977,91.51108114046899 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark02(71.99710254425975,95.88327757846002 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark02(-72.00308207115897,1.5707963267948966 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark02(-72.16943383160998,91.27151128341438 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark02(-72.18925375124168,77.21558270810917 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark02(-72.25663103256451,1.5707963267948966 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark02(-72.25663103258357,1.570796326876571 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark02(-72.27662118357938,61.59536721585772 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark02(-72.34490773999991,0.0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark02(-72.46181609589192,-78.79414811010072 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark02(-72.46880764820057,-1.5707963267949054 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark02(-72.53687622833226,45.23086932635222 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark02(7.259970291850942,-30.821915274617414 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark02(-7.260939190049937,-70.73401374716173 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark02(-72.62896903666905,41.28041788099116 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark02(-7.263518323045448E-4,0.4648971287091457 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark02(-72.6544041993862,-43.912460702056386 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark02(-72.72582001420325,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark02(-72.7497459732739,-26.944490223063937 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark02(-72.8573266494891,-0.9701007099922658 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark02(-72.87371740732206,80.52342089573504 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark02(72.97739825363126,-78.36837543150943 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark02(7.300056064700485,0.5424683909239169 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark02(-73.02220742325203,-6.353405169034283 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark02(-73.05348010611199,205.8399177655626 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark02(-73.21289438478011,97.67344686212192 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark02(-73.23470308819472,56.847910221034425 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark02(73.36792068354643,30.13272658814205 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark02(-73.4152070161926,-53.69747058443051 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark02(-73.5198330218337,-0.43762887924481875 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark02(-73.64920266285074,1.570796326794897 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark02(7.36659847958922,38.70213297475122 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark02(-73.7539980121102,-25.292251340050868 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark02(-73.77516380008927,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark02(-73.79661069503219,-1.5707963267948968 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark02(7.381030413611339,0.0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark02(-74.01155433730399,53.88059732948983 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark02(-74.07027868905851,-23.562424193727693 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark02(7.423417896582301,-74.87201053633785 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark02(-74.26083207283345,16.325989436254204 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark02(7.430299725436342,0.0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark02(74.47818566656801,-20.232991350850924 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark02(7.451501305774828,59.37213653898933 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark02(74.5320266361928,41.49573230624796 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark02(-74.70528437774058,78.33469403778616 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark02(-74.79215171266414,-53.69162526679261 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark02(7.480489494184255,-107.2154208851037 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark02(-74.99248814756707,-3.9180332305073193 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark02(-75.39822368612194,10.995574287542016 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark02(-75.39822368615562,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark02(75.39822369146007,-1.5707963267948966 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark02(-75.39920162592774,-1.5707963251216102 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark02(75.39921782186238,67.54420287594915 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark02(-75.49232002230991,11.368634793511916 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark02(75.49902967166565,-73.65334759812481 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark02(-75.52462783261335,2.0707963268202754 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark02(-75.58160892276497,0.0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark02(-75.5919550829975,-2627.2198651544695 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark02(-75.7344559380053,-25.71904955040263 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark02(-75.7455966466182,-79.76323970597022 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark02(75.76011600998088,-1.2089040030759834 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark02(75.780237393411,-1.5707963267948974 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark02(75.80439014110789,-1.5707963267948966 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark02(-75.82415503370723,136.23964398312208 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark02(75.91542586543528,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark02(7.5917836684566735,-24.870543262814746 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark02(-75.9227881697622,-29.047495655560773 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark02(-75.93056388033916,0.0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark02(-75.93299709028452,9.912722121691871 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark02(-75.94106569778376,1.5707963267948966 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark02(7.59484050472113,-1.5707963267948966 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark02(75.95819545841132,-16.18112627898705 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark02(-75.9608181220878,14.785785729428463 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark02(-76.01765815006516,-90.21528903852061 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark02(-76.04299358636335,0.042825891658099406 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark02(76.05550943267107,-2.303656983597449 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark02(-76.12219645406482,-88.29709720928055 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark02(76.17419735564471,23.724276058913453 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark02(76.1992688099092,-72.57200800029094 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark02(-7.623526055814351,1.5707963267948966 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark02(-76.29858411505406,-0.338131994234494 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark02(76.36869990077236,-1.5707963267948806 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark02(76.3976970906136,88.53591722303547 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark02(76.43794989164167,-38.783656541765076 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark02(-76.62591792112835,10.51321262736926 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark02(76.69660301431583,43.01018170050085 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark02(76.83118923912522,-2610.808121740777 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark02(76.93777706145536,1.22864449940392 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark02(76.95018240772487,0.18736172428028347 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark02(-77.02236855538922,-127.623644640505 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark02(-7.703719777548943E-34,23.570683640530387 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark02(-7.703719777548943E-34,-48.69468613064183 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark02(-77.08827257013903,4.4911065815435975 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark02(-77.10426082258887,-54.977899730230945 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark02(-77.12898564131238,1.5707963267948966 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark02(-77.12931226190953,87.49705399318539 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark02(-77.14033865660686,-73.5544871915267 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark02(-77.1721615250257,0.0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark02(-77.1838959551513,1.5707963267949197 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark02(-77.21169668199724,-48.68711504548521 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark02(-77.2323427274556,1.5069290458023262E-5 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark02(-77.30867049408664,19.403321463608926 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark02(-77.37378914698692,0.0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark02(-77.44957643387961,17.278759596194792 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark02(-77.48511653936208,0.0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark02(7.748694614769192,29.517388332980005 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark02(-77.51435264991689,0.0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark02(-77.52620159957175,-97.59060268043194 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark02(-7.756661963916713,92.3522367605739 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark02(77.62703079699665,-40.6832291957449 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark02(-77.68348564925695,1.5707963267948966 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark02(-77.76248158016783,14.15444807076969 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark02(-7.777451148360067,1.5707963267948966 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark02(-77.80682944424922,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark02(77.83799890515888,17.496654953806612 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark02(-77.956053148416,72.55210612247528 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark02(-7.797807696120614,88.74265231240645 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark02(-77.9781801799793,55.07701720233124 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark02(-78.0117878026555,-38.979473185151264 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark02(-78.03958732882283,-35.17511423970841 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark02(-78.06574293985491,1.5707963267948966 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark02(-78.22868257720452,-64.40604018248703 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark02(-78.26038435896024,-9.860316914300384 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark02(-78.27888974503153,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark02(-78.41595109314562,58.32833445111882 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark02(-78.4674593011666,-83.32456235880801 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark02(-78.47306310199023,93.71780181681788 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark02(-78.48030428211494,-0.4469527822555688 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark02(-78.53981603789643,7.853981633974482 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark02(-78.53981633974396,-1.5707963267948966 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark02(7.853981633974506,9.90426914211216E-4 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark02(7.8539816339745885,1.5707963267948948 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark02(7.853981633974616,91.7021437030699 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark02(-78.55548137455452,-1.57082780997292 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark02(7.865225451663294,37.71030638220332 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark02(78.7007875627479,-70.73479469492875 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark02(-78.73200083664767,89.46018418350144 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark02(-78.84062610654703,1.5707963267948968 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark02(-78.8833415192307,0.9282951655266527 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark02(-78.93751993181333,0.0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark02(-78.96443526232876,57.694845168936986 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark02(-79.0011274179667,0.5704800140124219 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark02(-79.03981633981677,93.17698328085689 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark02(-79.04031356499996,1.5707963267948941 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark02(-79.22312815302726,0.8527054991846864 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark02(-79.59593427746648,94.41116252334159 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark02(-79.6227107697171,67.8583258356424 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark02(-79.63449378347067,-1.5707963267948966 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark02(-79.70392316186332,-41.881851590264404 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark02(-79.70971845340685,1.5707963267949054 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark02(-80.00917860475236,2681.4097876213154 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark02(-80.11060980977305,-0.02634906164117622 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark02(-80.11061266669563,-3.772748980426579E-6 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark02(8.016876381134943E-15,-67.54424205208056 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark02(-80.22495909220105,-44.16337796524772 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark02(-80.32881742154201,-0.008056385129817151 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark02(-80.48975740845343,-6.123233995736766E-17 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark02(-80.56677305870882,0.0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark02(-80.72111975191677,31.815639237923452 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark02(-8.074113990551098,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark02(-8.076152108787884,-1.5707963267948972 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark02(8.106852384302139E-13,73.82742735926095 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark02(8.109879885900234E-8,89.53545485293405 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark02(-81.36638441057613,-134.93766441134284 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark02(-81.43559058879518,17.146960586881008 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark02(-81.43701426553093,-65.27959387859565 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark02(-81.46348031956092,73.84053601233404 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark02(-81.56666286176464,-24.50254530824961 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark02(-81.60716679946871,-73.95737553744914 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark02(-81.68140899081632,-67.54416654459973 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark02(-81.68140899323463,1.5707963267948988 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark02(-81.68143951231849,1.570796320227365 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark02(-81.68923223296441,-1.5707963263111875 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark02(-81.72291428154182,16.519137820271375 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark02(-81.76617236608796,-33.519099556500294 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark02(-81.8167293753252,100.0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark02(81.81839372520645,-0.5450538024970403 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark02(-8.190643555125462,15.637631988465927 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark02(-81.92257316583246,0.40565766323483593 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark02(-81.93016789732599,46.34514359027321 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark02(-81.93315993428676,11.541472016219473 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark02(-81.96336298944999,-111.73348985175166 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark02(-8.197719072033863,-73.71713924316086 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark02(81.98195769519933,7.455353325078069 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark02(-82.07081648013225,-1.6081478115687986 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark02(-82.11552378450541,-41.258869650838 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark02(82.20376526300602,-45.152896610618114 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark02(-82.22354256621708,1.5707963267949099 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark02(82.23401843829228,73.97677619496457 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark02(-82.28356604676648,-12.77099344963356 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark02(-82.2852523817712,94.39401785962777 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark02(-82.30718715414058,1.9771086731136691 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark02(82.42637178172834,-35.70978695616358 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark02(-82.45062101424779,-46.36374361559308 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark02(82.46952586510784,-39.147756281667505 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark02(-82.5443725010897,74.45676170957734 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark02(82.57942744819084,-94.73981979427317 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark02(-8.262560411224083,-1.5707963267948966 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark02(-8.271806125530277E-25,-98.96407484144862 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark02(-82.72910487882392,75.44149569755851 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark02(82.79654517343853,0.45566014691823364 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark02(-82.84586025578086,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark02(-82.89002266843843,-87.35882883397252 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark02(-82.90993181359718,-31.964522052739454 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark02(-8.295400598965415,0.0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark02(82.95896722065382,94.68308988834316 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark02(-82.97946218807128,-1.5707963267948966 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark02(83.05836561511188,1.5707963267948966 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark02(-83.11288803447545,88.17299823056251 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark02(83.12345281278016,-17.286450837699313 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark02(-83.12543958998569,16.834150292473165 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark02(83.12576982444037,1.5707963267948968 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark02(83.15140149716436,1.5707963247452772 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark02(83.17718140948864,-71.74849577276699 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark02(-83.27093105506556,85.26460853128538 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark02(-8.327385484048037,-24.552414757888414 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark02(-83.33554425752604,1.5707963267948974 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark02(-83.3492855997768,-16.26497373111348 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark02(-83.42452684692634,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark02(-83.42599543828388,1.5707963267944898 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark02(-83.45782915792752,43.20848275034831 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark02(-83.46172488349985,-1.5707963267948966 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark02(-8.354388465870574,1.5707963267948966 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark02(-83.69355683728585,1.1809452087975759E-16 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark02(-8.413028399508434,40.78068171087696 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark02(-8.424777880362315,65.40264939859071 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark02(-84.26216390850824,27.50563568306559 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark02(-84.37927646935464,-34.91368819250684 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark02(-84.52542146929562,0.0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark02(-84.58833600242748,-0.7466321990082188 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark02(-84.62167589288481,-21.363925082413616 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark02(-84.63836551354007,-100.0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark02(-84.69756834817926,1.570796326794897 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark02(-84.7539331069758,-10.926505747515414 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark02(-84.76876612738305,-89.4157034407881 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark02(-84.82038080575076,-7.861794133974525 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark02(-84.82188391434951,43.756974070793845 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark02(-84.82300160188697,23.561945087524926 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark02(-84.8230016469244,-1.5707963267948963 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark02(-84.82300164702441,-1.5707963267949017 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark02(-84.84368073580998,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark02(-84.97552086700239,-1.5708000647150184 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark02(-85.03006108899935,-45.346034035079256 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark02(-85.32064862321833,83.45708134287915 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark02(-85.37020990781555,95.27136767371466 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark02(-85.49384282669807,1.5707963267948966 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark02(-85.63330814237513,-40.39700272058337 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark02(-85.87493973186366,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark02(-85.95747787253565,31.86907030744092 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark02(-86.22182340355285,-1.5707963267948966 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark02(-86.25030677718894,-100.0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark02(-86.28653223005784,0.0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark02(-86.38983564608259,1.5707963267949054 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark02(-86.47768135507792,-82.53617649252875 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark02(-86.95432867736459,-74.83769298232167 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark02(-87.00144536887811,60.56573007564873 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark02(-87.09027100979876,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark02(-87.2701228765878,10.31546134325319 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark02(-87.60501945749039,76.96910500703925 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark02(-87.61987791740715,37.80094585538095 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark02(-87.83158506816272,-2593.852605813319 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark02(-87.87948769772098,25.466583320972887 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark02(-87.9129408526696,-38.68057324134044 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark02(-87.96459429990948,-86.39379794843747 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark02(87.96459430127209,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark02(87.96465584429488,67.5442420470045 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark02(-87.98607286938056,-20.432691343149887 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark02(-88.30736773618182,-94.35876545688508 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark02(-88.47182137256408,-66.00222420017766 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark02(-88.5594801861235,-26.9018228506144 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark02(88.56052375550851,-17.940647165213235 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark02(88.78084107439977,-56.87716440432702 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark02(-88.81113504904377,-73.3104452075289 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark02(8.881784197001252E-16,0.7704068935868367 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark02(-8.881784197001252E-16,-1.5707963267948968 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark02(-8.881784197001252E-16,-61.120259550574495 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark02(8.881784197001252E-16,-65.53324180249948 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark02(-88.85346304088807,17.278759594743864 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark02(88.88191374818656,-0.5342999942662825 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark02(-88.90516415385565,32.94325938716989 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark02(-88.9293926361131,-61.169389862608625 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark02(-8.893208758178247,-1.5707963267948957 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark02(-88.93538452628107,-91.35939866628442 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark02(-88.94907394666058,74.46135402830322 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark02(-88.9523701756097,-32.43951270281762 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark02(-88.9732424105788,-60.31392744440587 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark02(-88.97832658418724,-20.420352248333657 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark02(-88.99081213867956,43.10594878423055 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark02(88.99147307512212,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark02(89.07145791996297,89.78623910232446 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark02(-89.19748359015298,-72.59453806941973 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark02(-89.21806153771601,-73.39904501376532 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark02(-89.36227554146623,-49.0827319289561 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark02(-8.939002451175735,0.564581719614449 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark02(-89.44772044463836,28.00432667868452 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark02(-89.54853567758936,1.5707963267948968 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark02(-89.64203796283644,42.86693215706632 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark02(-89.64554571773868,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark02(-89.65469879248948,-94.31579319136974 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark02(-89.65921213733209,-0.025109225944592577 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark02(-89.66775353951533,-44.191210266399246 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark02(-8.98141142539292,26.239619318667124 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark02(-89.91714069786514,-78.36051352966125 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark02(-8.991949227668378,-8.702330160644703 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark02(-89.93665060823845,139.12575491967317 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark02(-89.94857143075217,-16.61740546908557 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark02(-89.95098936891017,-0.05265395270665391 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark02(-8.996526013514334,-2.248603956461043 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark02(-90.01470577236029,70.28088166855504 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark02(-90.05392124974144,51.68693683544339 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark02(-90.09596873191488,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark02(-90.16614173438988,-0.8486234243255604 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark02(-90.16809008712336,-52.60457775606574 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark02(-90.52453326406254,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark02(-90.54070546839068,35.495851677612194 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark02(-90.60379349852859,-46.67641073636239 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark02(-90.62278083664205,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark02(-90.6827547640484,0.0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark02(-90.73964472038435,40.545462759904105 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark02(-90.78559639337365,56.83913695561293 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark02(-90.80636357058138,2.220446049250313E-16 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark02(-90.82670005348561,-1.5707963267948968 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark02(-90.88052745595294,2623.494182688017 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark02(90.88075485334011,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark02(-90.95776567348608,-2387.67180480154 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark02(-91.03073942634401,92.29928753392761 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark02(-91.05563941925365,16.847494571967744 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark02(-91.10307866144892,1.5786088267949159 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark02(-91.10336043838427,-1.5747026490361424 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark02(-91.10600036060586,-1.5707959452147127 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark02(-91.10617194173136,-1.5707963265430018 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark02(-91.10618581811704,80.11062792532886 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark02(-91.10618695410399,32.98672235078898 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark02(-91.10667523535412,10.99557428731726 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark02(-91.17363719544835,0.0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark02(-91.24425293126814,0.0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark02(-91.55890291159375,-86.79484708871688 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark02(-91.70367290994969,0.0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark02(9.175487743845405E-12,-29.84513020901221 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark02(-91.85463516880019,-80.11258116654467 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark02(-92.03534573657014,88.60623184501006 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark02(-92.45824475547633,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark02(-92.92413271244986,0.19081308167155137 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark02(-93.05179945736273,-39.331035069827756 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark02(-93.34133383211417,-36.15248783668714 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark02(-93.55080011938655,-2628.882268224384 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark02(-93.5722755588993,45.553093477052 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark02(-93.73353456162157,1.5707963267948966 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark02(-9.380493961476724,65.99818961633896 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark02(-93.92157182441471,-74.16614823615654 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark02(-9.424739491817983,-0.5707959701867448 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark02(-9.424763659307075,-1.5707963267217204 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark02(9.424777960655508,4.712388847276733 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark02(-94.24777960769376,4.712388980285741 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark02(94.26710782325031,-52.68877249873212 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark02(-94.27920802702405,0.552820737730341 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark02(94.28064388917247,-91.13459678587053 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark02(-9.42868421496294,1.5707963267948983 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark02(-9.431813513588665,-57.686422134310384 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark02(-94.42767018014806,85.7237914212316 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark02(-94.43471648004306,-74.14274624556303 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark02(94.51144212513427,5.2123889803846915 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark02(94.53268882984904,-23.81817336065791 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark02(94.64915291131649,9.77475416626968 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark02(94.92844937875824,30.964780871321842 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark02(-94.93338757643501,55.906683279379365 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark02(95.01068576117595,80.30808247987532 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark02(-95.08633913731204,-4.45059232143916 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark02(95.13021228816206,44.225375788967 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark02(95.35016553480227,-2.867569896604085 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark02(-95.3724835374254,122.85083505092152 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark02(95.38001165617254,-0.5293058535065143 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark02(-9.539136084553306,-0.22442604638214245 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark02(-95.49377443818146,-46.799088307853026 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark02(95.60915437691841,-20.124165790828187 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark02(95.68907779968319,-15.129028487579689 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark02(-95.7909646647902,-1.5707963267948966 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark02(-9.58047077192339,21.8068938782817 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark02(-95.84316020590215,-1.5707963267948966 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark02(-95.9291207020108,-9.211691196312714 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark02(-9.629649721936179E-35,45.553093477051995 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark02(-9.630570386837562,12.380830859600268 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark02(-96.3993410274012,-60.63508346097288 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark02(-96.56390670391761,-32.36620059212778 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark02(-96.62956253931291,-80.11061266653972 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark02(9.674777960770019,70.90862582195061 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark02(-96.9084663246252,78.2612333518409 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark02(-96.9137909423943,-10.603056129587994 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark02(-97.38932346598632,-58.11946409141116 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark02(-97.38932666912349,1.570796003992244 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark02(-97.38937225049332,80.11062792532883 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark02(-97.38937226123002,7.853981633486322 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark02(-97.38937232088824,1.5707963267948966 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark02(-9.748849689218458,-17.60283132308745 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark02(97.55189826579641,3.8916479026284776 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark02(-9.769389965160883,13.785233770852983 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark02(-97.74413908951668,95.8050507607982 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark02(9.7941918762506E-11,1.5707963267948966 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark02(-97.97229442187042,1.5707831118449829 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark02(-97.97305343646123,4.4516001134400085 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark02(-9.803464025276128,23.940630966322573 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark02(98.03881422795715,-37.1216159895523 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark02(-98.38867029406988,-53.659051349314524 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark02(-98.39658444947064,-100.0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark02(-98.47056542827204,6.94107736876556E-17 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark02(-98.50399389087893,0.0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark02(-98.52364415775467,-24.696216798158012 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark02(-98.96049490199246,-0.002885745357542005 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark02(-9.92926092559157,-34.3496658830406 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark02(-9.936612448808148,-1.5707963267948912 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark02(-99.74448413258574,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark02(9.980310766777145E-11,-1.5707963267950935 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark02(-99.84331522892691,85.60298688089239 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark02(9.998407402078536E-11,-1.5707963267949125 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark02(9.999828487550056E-11,1.5707963267948983 ) ;
  }
}
