import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.07750430764190241 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.10925244287980718 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.26736790626841866 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.2740377755426664 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.28946003924610864 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.3031057919782256 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.34953446815737266 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.3608859929557582 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.38475195246429905 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.39193984715420527 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.4076890986339805 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.42498107508967564 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.48911544564464293 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.5300524675735829 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.5327908743592644 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.6186028206574719 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.6511196548325131 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.6740456196849891 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.6862970323993522 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.7110598959128964 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.7309395518038286 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.7729056660674871 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.7731586819528502 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.7776629247571378 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.817688247467089 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.8216778829411595 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.8516273148143796 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.8603581883374716 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.9161632759339113 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.004499182375156 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.001543380483966 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.103373809787783 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.113987062223728 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.0146819950298749 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.162908003568731 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.19513251058062 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.214059057622208 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.02377949458932 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.290658080642629 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.383607785609712 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.388477133155476 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.421258539921013 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.467656630903832 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.481455663588406 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.0522674058950514 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.559920802647156 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.609741184375991 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.0650176554699584 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.6737093257576 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.68272301017221 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.686424371333487 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.767600962560621 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.0770515842835096 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.820224551265838 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.878076445061808 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.913131758931357 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.94728949984733 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.957590694821079 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.973979496292017 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.99170515905385 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.011464220717286 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.042238201307583 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.044115170578578 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.054120376710316 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.057138156409422 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.059498092644063 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.125899987815075 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.16053662267818 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.276792999525995 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.286892576408334 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.290264326812903 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.306652618201014 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.392138882821271 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.412039767234077 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.43638201596309 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.471670799214522 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.505019676587708 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.526471899300233 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.5401530512313 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.551322832190621 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.553275558070283 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.59179279580718 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.630550055173998 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.642510171648055 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.672451587073908 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.796396982484808 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.81135649045703 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.823805831668338 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.860816447946448 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.899622181333186 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.967354698373157 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.06954410399932 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.077818879789447 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.097313279811473 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.139693664082145 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.161092084640927 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.172533611449495 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.178120896620342 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.196196482036271 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.243414061293294 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.264047627806931 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.310163188117215 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.344854739864019 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.37767341619329 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.379519040640787 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.422338492499918 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.505364008003312 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.55087257815913 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.581837094758157 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.604092472900177 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.622669301795568 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.740174985763986 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.78424774392218 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.810898380035525 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.884264593940188 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.894779067895243 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.927565761652616 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.989768657580441 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.069555626451617 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.114924694442507 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.13670813789723 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.15051158761284 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.151723412262228 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.202921211828226 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.21629491782663 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.270383667276462 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.281181915910636 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.323236461758242 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.381034492464124 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.39773974454124 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.412474591805747 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.487907927615097 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.562631356823289 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.573549158224907 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.63705862925238 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.65315220165131 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.67496597886064 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.681177665641783 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.701182241593159 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.753359122138349 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.753455402909665 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.864256501136538 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.869218830949805 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.008322846286276 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.014818779184736 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.017035110147873 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.02951003281379 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.043405196751763 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.079218915585187 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.099009374613033 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.138762266274 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.138874310045807 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.162922073769252 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.181777277278712 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.313713879388203 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.317334729395697 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.347147305955914 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.35857559054341 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.37121738624792 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.378730768861885 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.490874794951765 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.543349760746409 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.629557353593697 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.658383528597312 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.760743861702522 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.779882945468586 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.781432169995838 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.482852243762565 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.882658184333934 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.913958669804998 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.92712136804839 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.050143547402328 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.057990938227377 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.067022155525393 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.074537917648215 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.128629934602529 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.146298844563773 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.14783355385407 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5173334656703048 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.19688331933287 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.219547762044854 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.276084822498845 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.285990385132678 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.364731007041229 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.370270493195633 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.426569532957117 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.42996429797168 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.457475145895103 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5538936354563475 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5542380064353978 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.635596082505373 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.649580761308755 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.662416230253513 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.569893451120592 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.71398485162159 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.794692461759354 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.80316900350256 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.817010277780781 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5843051790880338 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.865406777058723 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.891436003498654 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5911173147322444 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.9201099014944 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.928615027222676 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.936512500329258 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.952632278824126 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.977693385816778 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.007507444495147 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.022051440319984 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.062339116657043 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.073924869498057 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.075415381156574 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.134160457794195 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.6164301411489674 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.236289805833565 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.259483730166608 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.31262254179589 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.36898755339915 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.375371576338992 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.39541493059589 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.419078747614705 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.6453781420640894 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.6466723917862396 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.497136974132502 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.545173189818414 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.55052447403733 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.6781583835061 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.69336294758483 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.705234614010152 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.77222626035966 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.80372373300483 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.80395729159912 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.925528687602593 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.93176485653167 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.93622337045089 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.96022820290652 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.147052234670127 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.19779183851098 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.7231863143960027 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.240694901288762 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.244043980754498 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.258836645854174 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.26850138789129 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.30276704247511 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.361825327896156 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.373618655159362 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.7421806216449909 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.7429673321728103 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.431130349993907 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.442283823187694 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.480401253776193 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.52805202209629 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.534621166733416 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.602413856555472 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.615553778583063 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.626025993365218 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.67245985030783 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.6745170991436 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.678022841424166 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.704287834976725 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.70804490880424 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.754843737289974 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.76563493716641 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.784476959914855 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.814262274572016 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.839054049336795 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.851040903131405 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.85854446163131 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.93795699846956 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.951111681385484 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.96450864417693 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.966973978643708 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.978179527454756 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.011411890972155 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.05413110025998 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.8134450440867624 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.178289728060264 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.17832672840754 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.1891668144182 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.217934715790875 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.219430861405357 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.264512653862084 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.32028735046498 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.33440185911033 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.495491860351592 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.617349297688165 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.647015257321883 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.658383718778566 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.868535927997101 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.68865576571585 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.717338229684017 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.788827698356457 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.790856580765663 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.81321953792441 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.889337135861027 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.919385435896913 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.922492464385215 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.94945932114554 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.958869253269 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.994861903507015 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.02372978153089 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.03296441100059 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.062956432216566 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.065377370554955 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.075095092710256 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.079926064000745 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.081655127074754 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.9240692177335745 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.299014860329322 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.318936235443857 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.325755630476223 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.333055842853938 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.467742652254657 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.520947759177986 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.540995948600965 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.5461500234386 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.555716377943426 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.596224585424252 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.741736758715362 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.75006263513744 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.80606037508541 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.817774026150147 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.852722004774506 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.9870571808636726 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.871787428765103 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.8924558815432 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.893165758463297 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.90036070803272 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.9702371892988 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.00700514607044 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.016610963744824 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.043657390968477 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.067258119392847 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.095196956105184 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.009776749543832 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.12623775942555 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.1572173222944 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.161426032515777 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.0205696094614183 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.21438633420955 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.283131059171836 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.324569926723626 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.325228509295542 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.405741121013037 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.407438896747124 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.4165613577332 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.0460106840897225 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.48288870452386 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.050159445009456 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.508510825379233 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.54899460609596 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.057868848584093 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.611962827591128 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.616913537096266 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.655350137212622 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.655603219031633 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.66321180193657 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.695089194396957 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.703589430371608 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.70387468199766 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.722880506784563 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.76311738541692 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.78574088437162 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.80650907655061 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.80974207604558 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.862162877733923 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.86954807862864 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.0883014320802573 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.901012779277835 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.970071566983492 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.977698090063228 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.978521511904688 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.980919832580412 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.00598188355262 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.00755245985937 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.034513404528525 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.057218059439606 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.05730301998328 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.16371542338034 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.1178003005366293 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.334983831882354 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.387789592371348 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.411257946318415 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.411709903418455 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.505717999751 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.51923247430294 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.562192589198872 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.651435646894598 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.665732145852942 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.69017699458111 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.69230594124714 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.696754311370285 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.745058545077953 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.74725821009433 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.1769877167366474 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.77604433203311 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.786712486941553 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.802993506196103 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.816861271986184 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.86310656484285 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.950173736272504 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.99729578942913 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.028896666267002 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.0968351129184 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.136715892266608 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.19857783156843 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.211603453053883 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.21514525898553 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.244078536393516 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.27762648106561 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.299553379550872 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.2329236138169932 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.2337894994038265 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.234428358979116 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.404525775436014 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.437678462751578 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.449628781754583 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.57368027583763 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.65930059611962 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.699999775953472 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.705438163965397 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.74746871363446 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.763159056447194 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.7934369279631 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.860348492004263 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.927604506851765 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.935966772362676 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.2941728064327833 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.944978022043344 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.980407643094253 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.010270615090647 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.02495984705142 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.303749506975578 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.057675273036637 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.160047917113786 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.16853427267729 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.175838200225286 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.219438625284113 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.24239484871866 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.244294122309327 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.31998999674343 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.33219546423446 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.347862621327465 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.405143373152626 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.44120188343257 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.441528399090643 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.478330388868713 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.49044873862944 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.495682956023572 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.554431858702827 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.571334934143366 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.638724626108527 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.68440314847895 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.790436642892686 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.80664394913319 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.90900323202476 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.98644912985371 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.991189965178435 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.031815794809148 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.033157220529148 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.096436559811153 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.11306396405206 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.41312388857709 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.19874790313385 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.215515960033045 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.259520595261492 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.26789712392707 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.271150625803386 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.278652712470645 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.282091136989692 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.31824266838423 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.35497405533988 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.35724697486303 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.36028400114607 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.36490399883364 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.372430075715968 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.439480032723381 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.40312961286881 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.446183500188326 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.47677987427528 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.521763610146593 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.560396431580344 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.58394922146124 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.625878175468642 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.635387655253908 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.686347424304074 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.698371170435365 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.702948321699793 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.77449267122597 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.783302039537205 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.84707942320574 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.861811315279112 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.862351053158065 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.87626847956514 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.925625439770457 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.94086999618274 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.03767097105913 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.083102139932194 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.16479634880129 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.199436259452696 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.201355248005726 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.205627877100227 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.253407188257853 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.335231669993604 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.5351442829319097 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.354022566604442 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.39422120599302 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.40469686311036 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.5436531791755783 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.442679592044783 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.443134199582815 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.584197391588035 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.652855604659976 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.68643536281006 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.694825229594386 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.730867055092517 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.5889308510686817 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.909094373001523 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.988279802034995 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.604617234957331 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.087173820158753 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.114548675724066 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.16851003541703 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.251452778247824 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.3376671414359 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.34224256317856 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.34604726595566 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.426875802462547 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.54109298639493 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.55243029912549 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.555871104460522 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.6567082860575795 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.589970205014012 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.594815387758658 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.615478434010043 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.68935456819807 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.851657566814183 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.93122330906435 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.061841531408277 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.062956543154854 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.066136557536225 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.075655265513802 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.08079291425713 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.082558244565092 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.087914264675987 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.092187369010063 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.10527772949804 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.109869746850862 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.111892026741742 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.122668122171405 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.145587466124226 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.715106438941305 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.166147751424276 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.19378420490412 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.204038063261308 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.20421945586577 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.22888541679896 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.261475295227072 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.31595328349401 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.33902579399225 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.3436725443363 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.380516652594622 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.405911536667134 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.432238092332526 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.50097352408669 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.502834098454016 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.583740968967433 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.602396010301206 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.64850620823526 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.657434582724477 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.665307746104133 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.7793974591211708 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.871066224876344 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.875743235493204 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.792162081623843 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.00236886311953 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.031474998646445 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.03285741133385 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.03694177768446 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.05789592497206 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.06899636665699 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.07782306910174 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.10618461006669 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.136861718936927 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.14865996026721 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.8162267027327346 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.167277483920472 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.279634275046277 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.285964260566374 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.350179368963097 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.41055280451279 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.482984272330313 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.491296351073615 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.511909423275867 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.56053420445423 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.597683943428848 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.613481034796308 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.625511917655416 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.62975916838215 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.635997523563717 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.8653927071342906 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.679225187557677 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.68018537944785 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.692129110409837 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.716064479581433 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.724500959205557 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.79265437676959 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.810019420420204 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.859570562943688 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.86273630899609 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.864584800303405 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.868839044057665 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.880620895591022 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.909295417625373 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.92896814397261 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.06775736226453 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.070371186205392 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.118964934778077 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.164213667818387 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.209906321104782 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.221778176421424 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.265126478413947 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.268596271525865 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.294510858649886 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.328150886032688 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.336901503769724 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.356579848916226 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.35823539805655 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.36204250072278 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.36458961179582 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.366382712675815 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.37841073937615 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.38895726944071 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.939618416878247 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.405314543142083 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.9423610384576477 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.43851474431554 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.44905063279488 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.52380915953789 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.529301191653914 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.558461899196686 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.565854781416462 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.60941368829542 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.720693091398573 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.723406143835746 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.9759726062303287 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.765378942759995 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.801973941543068 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.823091168422607 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.984849912334383 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.915794756694808 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.92201870601943 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.923540319518978 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.957452210027014 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.013351125064688 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.019451792929402 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.03891395580105 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.049497585518566 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.12624620266422 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.131727498141927 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.136670921661434 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.13821476498073 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.205942403608006 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.02309622802872 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.279076893121044 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.285502277340612 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.29146194072952 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.363149170197204 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.467954510831305 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.0481346136219685 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.527797754075053 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.53157338836965 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.545740089976235 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.580352371878732 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.590139717732526 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.618210846577412 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.63389622030637 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.069493167719557 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.69756638807739 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.699383185689967 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.731508513286926 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.74618390946617 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.076089101446456 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.781372169812713 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.79984114026537 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.806369081774136 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.835128079043557 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.8911287983116 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.897205890427728 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.943202087211688 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.991231626483895 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.01075410414576 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.018162080160366 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.01822704074722 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.037702068586782 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.1049667513958923 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.051992547893462 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.05270263644428 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.067518673615126 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.158075061231145 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.198237544584842 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.27938250611824 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.296380327362613 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.1320598842501397 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.33653895352613 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.352867148248748 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.38318455071729 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.433329647045014 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.49315441658804 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.58159079214613 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.633937589379514 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.1717080259449233 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.1796183861903415 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.825588602884764 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.830098567310557 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.863930549092984 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.869374371066428 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.904777190753634 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.921626731765954 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.951577877990985 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.1958798773998467 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.02245209248092 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.03409339023442 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.05281880268636 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.06104464532005 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.07494554237343 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.09393895110652 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.094405115827044 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.11527291594376 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.1252572175281 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.12707177325865 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.15172494081418 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.167890591514634 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.278793695063456 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.28653094022805 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.29158591033024 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.31278469053048 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.365705166619406 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.36605514715161 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.42721555638002 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.51523304162869 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.58458928069372 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.70412980719864 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.2749252455569433 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.76749146009459 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.783649420470766 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.79717485904774 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.815622505691564 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.84872431203448 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.86181006662629 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.290300096444824 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.923644983814484 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.939128885198144 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.96351285898314 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.98413284252064 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.00136305068273 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.10020186836644 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.10977506411834 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.14296993026571 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.15640439424273 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.176193997297545 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.20682826438541 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.321400749851165 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.22268098525443 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.26220984860748 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.34099122151525 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.3352920619752666 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.3416818867671623 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.50463949029745 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.352896825809637 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.608041231995614 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.624075708063515 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.65027103861371 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.66889523746846 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.67915981504839 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.701618724014736 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.3701857921457474 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.836247802801495 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.85203143379461 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.3887065949901825 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.90656358722171 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.93334022062962 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.02213757994903 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.05613006198196 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.05681542612244 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.060822156250524 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.09739790647488 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.14302079372166 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.143757550181505 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.17255652204997 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.17435517928446 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.239976874310216 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.24638713019597 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.25161241851629 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.263069499103494 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.268151699212495 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.31052235111403 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.32259840664791 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.32687167974436 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.35433619681898 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.36944663429044 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.44066171968443 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.47419643726401 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.47997471240582 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.48243946645087 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.501178880735566 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.51462549902213 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.524189629696195 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.53619225703048 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.454391032398192 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.4700501324509645 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.718042173666134 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.748048915325796 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.4817872229222075 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.83498778684036 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.86733257257558 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.487128400709153 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.877248832877214 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.88399579165929 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.936809501524266 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.948385775220416 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.95180724382534 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.98658332927323 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.998687697843195 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.074757890986376 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.116334754750994 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.12668538517015 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.13701414184038 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.20370837135883 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.2325991490074 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.28752479324426 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.30609899989376 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.308923173103906 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.330931929746896 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.402787212964284 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.44707739381279 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.45764913497031 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.47719011637065 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.491546893361175 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.555074206158082 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.560437199336306 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.614158352265065 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.62058330438953 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.5658166963103497 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.67799472669972 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.7295463266305 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.772414489644746 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.78664594842593 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.79144487064892 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.84229165411233 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.85269594975149 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.86041922088951 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.90602925437982 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.97124935708837 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.99219994651514 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.00930203470889 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.048065281929496 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.072604890539736 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.102260498251496 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.10537889509475 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.118627963913454 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.12876563202476 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.17184008253045 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.62138365690123 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.21670181868388 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.23884882955277 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.25103531852905 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.2684858866607 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.27059778863006 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.296165313744645 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.330938219625054 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.4289455403473 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.46133128149054 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.46930085671662 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.496910585315476 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.54353606217637 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.6546929687610685 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.57514046750996 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.59425315165645 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.6484753545832 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.668999398694183 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.72476510596554 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.735467883402386 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.77783336281546 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.82367111356588 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.83090193018288 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.883292830456305 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.922955905279366 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.92355739915818 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.950849335279834 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.00148831479666 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.06233806451458 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.075469514806315 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.09335761709627 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.109014652988705 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.13913859754325 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.18951521137666 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.19278007492448 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.20713044517196 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.26698747774917 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.30503379978298 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.308997432082776 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.37472849246335 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.411178112220256 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.41458778028242 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.44936899564695 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.56742337042891 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.57313045406106 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.584521277985175 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.635219922391386 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.676768062823115 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.67754669876755 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.72250360746385 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.742652160434616 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.774422435854774 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.820285163691224 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.9202316835747 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.94655581914566 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.976975725268325 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.02331054520278 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.043731735242694 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.04603921506518 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.0549203982578 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.05530815177172 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.130484350772505 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.2382456015401 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.2383743340573 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.26578874304663 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.378264702497255 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.403432587757266 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.455052799621534 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.4606680619519 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.50792741684097 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.859525656962745 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.6438876627194 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.69063489067668 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.71013917774977 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.72190936198046 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.73958515355904 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.74039230633697 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.77410616065955 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.79343514165035 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.82875078160832 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.8853734323481603 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.860930810221994 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.884969580035886 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.98338413353357 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.10065712650028 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.22630546882162 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.9318250239303865 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.39435688495016 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.9439086530742173 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.46924164432251 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.946989885940738 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.6543874661049 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.65860313848981 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.7027249464273 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.71143667205765 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.73664053545498 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.75866506169308 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.76323000071549 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.8277752564961 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.87340393551955 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.88330479740463 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.910094854820734 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.91195748058382 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.914989400912845 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.93950027810052 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.9425105877081 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.96208882772812 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.964720601646974 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.97644597362091 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark36(0,0,40.00314999407223 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.01887029068967 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.12366312534026 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.014764109950491 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.182218905009904 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.024134666164002 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.25410872257209 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.2616400416669 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.264702771962746 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.342516336232784 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.349942482826464 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.36340740400568 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.41009864587064 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.413388774693296 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.41454356627454 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.445491267085785 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.483114338042505 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.57811448224313 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.75670122603228 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.76661768918912 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.778302023412664 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.804097376897985 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.880439138864745 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.91581113878424 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.076558289845686 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.13799349089062 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.15912947125806 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.18905684514927 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.21746424180055 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.229570987505085 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.123137169389452 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.28824636070048 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.30348718684882 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.43867822050093 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.144575457984374 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.45486499151707 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.47772122501476 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.50935765074038 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.51617086186761 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.51747673801136 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.519130954420014 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.525447608326616 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.52665436924477 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.53755018322385 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.53813880123216 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.55007951752463 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.62332957495991 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.62952521307584 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.164837230077694 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.669947748649825 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.67430786728925 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.75957267991186 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.180941919512264 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.81538924658006 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.8270187747213 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.82769418780292 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.88008342941944 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.90660305348 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.908107719522356 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.939896377743494 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.95741762968004 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.96616345458535 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.2082146331386525 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.211082847256236 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.115352793456125 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.118508142031 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.163615097335615 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.17594359282917 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.18866109834496 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.199408889246314 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.24299230278081 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.246794138889854 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.31379806123019 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.4824081614745 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.255815623407017 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.592207399401396 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.64574726273096 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.70350878206634 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.706083639744286 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.713427123228385 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.735604515113 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.75843749645152 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.77808428740266 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.82559729817559 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.85052500552153 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.288390428009748 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.291224228188511 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.91706975756304 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.933180334325115 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.94572718549063 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.95895494296582 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.97940814688408 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.99165532333671 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.02502024411996 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.065256352036776 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.07036170645724 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.10979758724427 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.20092143534229 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.20138368097584 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.203333430715944 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.22887666327608 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.24493102520373 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.26035977128413 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.28297890053232 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.30433457948484 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.387302275909676 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.39556975955858 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.40599769959142 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.4675374670161 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.520889534048024 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.57850016937705 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.58454543437873 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.59251598413898 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.61447081116583 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.64744641179546 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.6719438567132 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.68530365269299 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.6921810293222 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.74243050574884 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.754284321424386 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.769384955052004 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.788294420114916 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.80280688129838 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.85840231664808 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.91550148090126 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.924857207147205 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.02513089536373 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.025201606553324 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.2045555603914 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.422020526910416 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.344831170308055 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.37683100451335 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.39997665165218 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.422317343057685 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.426875138709846 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.49882865084134 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.57032043421187 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.573222035100926 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.5822430539448 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.594520599149504 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.60211403541299 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.463946784087653 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.646889602410475 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.661150409724115 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.669767581541485 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.69980087653953 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.72122634447877 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.738803861192736 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.7480634567526 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.82696214896615 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.900949461579366 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.9076312259687 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.95841329343637 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.98354226890182 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.00748802826637 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.507921834636193 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.091131505857106 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.509327886085401 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.110500858960464 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.12500743758998 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.142195894300706 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.16505351919089 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.517692647674792 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,45.191254780796385 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.21109220876782 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.231909669651 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.23797314716971 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.43386860775147 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.544038491369122 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.48260360135603 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.527579678378174 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.53978754651678 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.56832421375776 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.61988749564885 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.73354939316596 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.74393747006962 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.764417389453804 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.78364314755596 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.582222668512998 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.85952303581471 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.860078497720224 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.882766462149235 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.96375177879673 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.96990555479956 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.98913599938579 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.027929100602584 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.080898573216686 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.12571338238312 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.13569045227497 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.625047813039004 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.29414724188301 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.358325302554015 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.36263810989567 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.641804331366799 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.41822864493097 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.437970839745276 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.44024200354644 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.44310724883678 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.47678430009918 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.519964309239995 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.521501637109196 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.6537971949426975 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.53856403143857 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.64244721079829 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.67737854510419 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.776934255459764 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.77974448856232 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.788718647738925 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.681193310689878 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.88253196389282 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.88332215242041 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.88904320479583 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.89530847796621 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.692278693910083 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.93228800824172 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.94720772697634 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.97535798893773 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.985205976505725 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.00836576738172 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.01445375349691 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.02232070091266 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.05538823909898 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.09296728675094 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.09701391429966 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.15802779156928 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.196934470476435 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.20158267977874 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.244017960400456 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.267300638889424 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.278480947876965 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.29724996035236 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.733521413191923 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.441283338237824 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.45702202275619 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.545231107634734 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.55946217451941 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.57985647775658 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.58025324275583 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.58988362164705 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.6287304622663 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.67295451144273 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.675705270357916 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.72620776162899 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.73527286502453 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.73573129198534 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.740505804778444 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.74153336939617 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.74985655430477 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.77199965925081 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.819876255461466 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.92935728007293 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.931838341579706 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.794296410144966 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.950267110213304 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.0609267107996 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.062850422142446 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.06600753917956 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.07000053324193 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.144809799936894 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.15094892731189 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.818104415907328 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.82090647242714 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.21034062272547 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.24397026574543 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.27261113453758 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.29583240159292 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.296980449719086 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.83034054579241 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.372149141199294 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.38953759334219 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.39604452296551 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.408286715515715 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.471776201048925 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.49383174409076 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.4966282147592 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.5150004534385 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.56057990258395 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.586100067698055 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.58795101545679 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.61275954997617 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.64494486370066 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.67182738883131 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.72494002280811 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.78683874579652 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.837268544080636 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.86091373627328 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.89571857839605 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.898504705767664 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.930587865073136 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.93666347896448 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.9592591778677 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.974168609914834 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.98418690354707 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.99640915221888 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.01308435322724 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.01759385048226 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.01908978003953 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.08604991205392 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.09918147597176 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.161595931446044 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.24967618952139 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.925529323653464 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.31363731717722 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.34997200498372 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.39394411644502 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.40351154294478 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.48202925013614 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.56200038409795 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.58272917478166 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.62572575805477 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.750962677239755 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.8047729814358 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.85885747358581 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.87280793996236 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.90775077793608 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.92854802554933 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.95452893093204 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.97558643999436 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.98949749979851 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.001634880061644 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.051510965452195 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.16491237588689 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.165382244557264 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.18859743717632 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.20213816748955 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.25583663375046 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.272173646396 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.28096742414976 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.28762745567226 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.32853101367258 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.33927892684922 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.418469496341565 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.431286697789446 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.458287358519385 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.50407633446454 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.505027672578386 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.58475220692764 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.586365082345374 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.64287744755518 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.66682749638698 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.66964994610941 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.77731905450478 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.795538924296466 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.79724169730218 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.79960558008669 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.810357654289476 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.82478989713779 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.85342011912493 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.94869082270801 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.94974096537725 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.99923699825024 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.05014459111781 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.064867544569424 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.07981726726323 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.08631807911026 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.133741201320305 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.136919143772516 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.15481464057403 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.159758598695774 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.20681678853556 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.219721678678276 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.23163081817188 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.2452741127061 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.279923132064376 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.333918278774405 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.39836148463755 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.4222703881553 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.454502335564726 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.50859745153657 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.53479313379907 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.54009801606656 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.544815620589546 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.64963391654391 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.66610375288687 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.6926006623257 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.70180923687695 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.7081902906094 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.72141278708293 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.75224793497104 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.75446355204105 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.83918672809118 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.8494533327799 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.855791131409525 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.85846807951457 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.872012723314384 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.948817290607806 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.98235882386007 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.99633293745993 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.03992952522469 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.168341400381 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.22971397389262 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.22457460991717 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.2688199049957 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.27857765255739 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.28676728896558 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.37111526530316 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.657557877660885 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.66046825360184 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.711717943961034 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.717841355737846 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.72415757376005 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.77208559736417 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.77224057198986 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.80807752109602 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.831824423161656 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.85800888481245 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.926622234792255 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.11989814342326 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.15517178034275 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.20042138060428 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.21618054767543 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.23688906394626 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.24521492771355 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.250267645321216 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.274121908691384 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.32129728036408 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.3214384195728 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.33649997200833 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.3584509151215 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.37675993606466 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.3413976978893345 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.414074497275735 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.432569852748735 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.438829845751634 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.440997616031474 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.447709171589096 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.4725818131927 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.48212173259333 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.48286152481965 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.349465651796919 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.51561698679637 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.520923819569546 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.568546095122116 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.58091237684801 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.59539631875989 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.60069731382988 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.66301348353575 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.691179212673525 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.782898067248006 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.795366894545516 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.81314950700427 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.88546759940631 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.91811071125245 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.94542076125879 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.94748482703757 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.95774787001157 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.9967485381605 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.00079406160911 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.028541964103404 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.06641490060302 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.08607502536871 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.10138962632944 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.11533621632487 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.1169354518382 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.12556930429913 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.13521317760199 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.14222846322545 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.160951420106684 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.416962325308461 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.18105205154124 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.200110279671534 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.26156023944397 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.309872677147155 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.312761871375834 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.321654917655884 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.34905340821956 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.398431459933995 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.44579988849658 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.4505021325508 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.4801985509711 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.501026874824056 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.508336447306974 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.52372925464128 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.56128193400984 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.622714429798805 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.6234081408179 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.65154184760248 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.6836787345393 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.68703115275759 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.70706377066441 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.711437970168994 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.72527405541969 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.72641632963104 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.73326054048637 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.74700141547055 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.754469776742965 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.76957120024053 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.76983059187537 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.835024523719 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.84358548623549 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.88426569473097 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.92702998090444 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.959218936616374 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.500605902320316 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.01779214975062 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.101267212418705 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.11943940691344 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.13860060364972 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.139230430559174 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.150260554959196 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.166186226277205 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.199058387106106 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.21178222839147 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.523166259915939 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.246231567685086 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.28020889074035 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.2867563704988 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.30243514289543 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.314226628094154 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.32086841249529 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.360209199952614 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.48350705707683 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.49661252396207 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.50230168246071 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.53347050997593 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.572885760502984 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.57448568684489 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.558517904137432 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.5986746972704 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.65839425546522 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.71755298059051 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.719033875531366 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.733827332832384 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.573686990885207 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.76023352041317 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.86420622512889 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.931319158135565 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.938841827781175 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.94893660995774 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.9489879568704 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.95431931870092 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.97877609502528 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.99084355840176 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.602099802311216 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.05673930697848 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.079488243796675 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.09763607577409 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.33185739507836 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.405891892882295 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.4196640776313 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.45517641939155 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.499960902834175 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.556699003966315 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.582529751791895 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.60772892916046 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.63171499234567 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.65091630360073 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.65221782764749 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.66701631701558 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.68267412272612 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.69825823450418 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.731277412448236 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.742488243483976 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.765884649665765 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.78097161697717 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.7860647013398 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.78918713039414 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.7932042149381 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.83833077349676 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.111572832631 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.11577348244177 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.218453402661204 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.22073730240547 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.2236137280409 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.2330288456373 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.24279547372502 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.27317998999586 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.32039006155956 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.40923035588396 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.41104898442333 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.43199166216666 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.47858086785094 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.748933984361642 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.4973856377323 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.51470196777069 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.55971200025627 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.579847818021015 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.60777501521224 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.631018034377334 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.66290157836469 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.70287682206623 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.715779971722284 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.75451415003392 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.78207336451238 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.882909408544634 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.920776259358675 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.01637078789184 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.01860742090885 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.802260203937593 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.027393082655834 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.804431509306923 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.04713230979808 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.11292795782299 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.13990373287179 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.201985842235594 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.28813933718442 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.290670132474375 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.8297296805588985 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.30339614360498 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.324316962046716 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.40540029765688 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.429150704276076 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.45352048581529 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.845471411809001 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.466399025095804 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.480544038196825 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.56241726512354 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.657924953180164 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.67554247899116 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.7141294773013 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.74604845718632 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.799468097379616 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.807644418525065 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.834909924204396 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.836485993471086 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.83767855687005 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.88230541919142 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.97570229949463 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.08497622465656 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.13155842764108 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.14214287875987 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.14972347069103 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.160360125373316 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.232176642935826 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.273333823136596 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.308634258024775 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.31588045606924 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.31865182734164 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.932791053870233 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.508935161995865 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.951419807536979 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.520876308861006 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.58336767103594 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.599518885533385 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.60506194406203 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.64711129283038 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.703536090774946 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.761655549934154 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.979497003869213 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.8471158218115 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.851905141216434 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.874598958795474 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.88220837971217 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.932086889028554 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.940545080933674 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.945622173616364 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.96335366609762 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.99165394936146 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.010764227615155 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.0515903503311 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.054088605313716 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.05631751300935 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.07585640784336 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.0081101342841094 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.10242601096334 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.13314861708163 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.15346331730369 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.26254069353496 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.30018883861099 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.38603357425847 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.42688947460755 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.4446068632617 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.44551061187611 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.449611144602436 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.48178382611642 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.51313718773843 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.052489087509542 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.53746514457383 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.537759856493324 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.054578065953464 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.56064360858598 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.5720818757105 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.062888980292655 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.086793794377883 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.869251491388354 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.89219400756296 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.9413352900325 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.01375086965541 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.04039230450684 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.10291816248794 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.13636517067984 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.136797692464896 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.15986689598189 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.16065231856349 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.16456974796751 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.17725478242191 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.21274535671171 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.213715824497264 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.26130045373306 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.29871114487102 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.316979075068254 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.32163769883188 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.133708425418476 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.35139531864242 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.36871875626948 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.37131745452229 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.40067666260238 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.14251620559854 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.157445736890651 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.57963746251403 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.61845491166717 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.64296009935024 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.71999014396845 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.75590413034489 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.75613859323619 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.761772182440765 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.77436595685799 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.8718541732231 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.8883294711557 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.89866556445971 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.917103113836006 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.919965288035115 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.991200601463035 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.99259910501149 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.0164164308737 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.02238661295474 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.070906367067444 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.093689063461376 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.10772441803607 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.211570036214837 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.15605256115142 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.232982643504585 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.238919742303466 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.25094839604894 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.265549261825434 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.27526196499738 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.30317519230568 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.323257330569426 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.234122516435974 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.236334441088729 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.36438212728359 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.37359026723477 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.43493897055949 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.446756029486195 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.451914580611145 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.248948840285593 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.49986403685996 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.51675046415437 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.56603806133676 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.56894111502855 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.59516129662246 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.598955586023955 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.64653900611354 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.679972604970466 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.728727996500375 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.73982773724629 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.80436757712992 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.86803762922444 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.960664488812014 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.03169313510506 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.303322535538513 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.04860224214537 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.19441121065517 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.23319296375873 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.25520189040059 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.330765654724701 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.32218927350923 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.32260474351323 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.34197089434659 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.34866712731338 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.406506293498225 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.420949158581344 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.43393944152922 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.51883765996431 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.54881222016311 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.58653256508602 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.73599552954141 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.736772075477724 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.74062330494652 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.75473861015857 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.76973916745599 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.81642474090572 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.83064993042631 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.88719579502467 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.88979370917194 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.92533796628188 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.393660558396363 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.93819528602156 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.955284428304424 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.96201931530696 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.05651008790431 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.08828333643714 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.09636864326933 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.10762505523569 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.20742798322246 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.27304269426546 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.298385084485 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.32538666821985 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.32625849604028 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.34801480399364 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.3525757374006 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.35428696136151 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.43378102515543 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.46604105597706 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.49616859145497 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.5346995776788 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.54370937761689 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.55655332585775 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.58631599117739 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.61033827164863 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.62060310234457 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.65644117368407 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.68859446132467 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.6888245451502 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.69640567636145 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.76767821687967 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.808211590785 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.82217679427072 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.87134307424819 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.9012978354834 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.90490479358618 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.498813569844771 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.9947603142723 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.01049207961594 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.01148767940202 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.02981638379634 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.04139743478501 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.08940906961205 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.18744744857054 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.19391154794147 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.21869496621554 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.24475920608236 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.27912756632904 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.28548938573667 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.33638794226229 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.33960945152808 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.42008939861608 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.43294878399182 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.46941889702336 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.550708019582046 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.52096321867046 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.56779346513409 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.558296057669068 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.63777047681718 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.66944005801254 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.71643582841611 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.73272820338217 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.74710280615992 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.7506744953459 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.78307617336398 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.83869079294671 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.86731254955902 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.88423079490758 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.88986184552306 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.89042161722526 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.99085757227814 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.99576726160221 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.99624475590961 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.04058517022362 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.05786111721716 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.06466904652603 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.13081225250927 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.16241501073831 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.2084411240088 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.29413158922912 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.3001177533331 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.35327966432558 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.36698861073708 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.39785971275015 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.42619144986733 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.49779790421343 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.5048371130356 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.56016139729692 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.59715125838983 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.60102426894886 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.6564983632453 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.73445919610366 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.7446411738926 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.81452931547219 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.8883126307461 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.93211492496042 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.94352909786876 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.99872287726107 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.99947439743931 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.01569624886031 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.06753514932123 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.10765599139346 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.13844934430222 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.21444148512785 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.25533658236525 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.26607663516207 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.28534216340927 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.29641848871775 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.732325985793182 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.43205612521223 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.4401913650367 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.44890590228236 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.55679654842245 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.5695304824433 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.57881939106802 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.58628036477211 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.59959408383476 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.60870873840614 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.6178053787357 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.64499328248169 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.70941419693366 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.73566688646508 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.7631622554087 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.77633234684855 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.78374059642141 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.80036853340599 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.788684857558607 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.90050147746645 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.93850981658194 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.05386645705917 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.07852825500586 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.80917355369985 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.09716939100275 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.13128692024104 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.13557536485419 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.17790618325903 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.26660451897702 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.32742088503487 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.33099955169597 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.34894399998734 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.35255358156533 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.39956952014998 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.40324967498694 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.41954584551797 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.44562618638854 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.46636503489114 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.47020226130931 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.48484109558417 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.51859829716165 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.51976737580742 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.54414722678064 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.58377495384588 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.62395996079613 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.864069877646102 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.6644221810431 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.72265128598613 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.72770675557958 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.874119357038921 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.74434741201497 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.77534203341769 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.77602052594 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.878109995914798 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.80898795172817 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.881160011546001 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.886450770949253 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.86512759045885 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.87166008326608 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.94069152780665 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.896657125633382 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.01231784503838 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.09141854498554 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.09563770907658 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.914480601610066 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.14547409934153 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.17275021748517 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.17297209701438 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.18177186690828 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.19623698927712 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.921482646245508 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.23307976898083 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.24853186633658 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.32008988179801 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.38167326210791 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.38814977477253 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.3937785445313 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.40667997847187 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.41951304752214 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.49714273816983 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.52665878879085 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.56181057577086 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.60037309833439 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.960226440247567 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.62034250231137 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.69099151314649 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.71475050178722 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.7193341941107 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.80949103691651 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.82259172427088 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.86366232251287 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.98027256210597 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.02678822379536 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.00607305787311 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.1214628997455 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.12487892777726 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.1415321816331 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.14796557661393 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.18267718046927 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.2167044465551 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.28248803249843 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.33521296871737 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.47339254522285 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.47968599996122 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.60534352929002 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.62329834235037 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.6244494067308 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.64577854997427 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.64879254594301 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.66564815990628 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.68287659612484 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.69670380070636 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.69843996423744 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.72481725408542 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.75779127416965 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.80414985939677 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.87460057954765 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.89191025624709 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.0563335513444 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.14429237526043 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.126541874840171 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.27181772276464 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.30462687326211 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.39029911603079 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.40443798495212 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.141611497513864 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.4246161699759 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.45186405125318 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.4653798498136 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.48400070007537 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.49349443763919 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.59133576929653 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.64618658567917 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.6812124604 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.80118639450015 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.82152977895169 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.96826843909577 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.99901209288531 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.03384605650432 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.06908565308647 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.11252103678652 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.23129254191375 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.26888404839067 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.31064116497647 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.31752792273608 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.3187741278087 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.3401217552833 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.3714367561835 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.41782533260898 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.249064325915413 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.5244344769603 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.56057544327237 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.57496709991649 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.58536455681352 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.62576301332508 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.65646845057654 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.65772190875335 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.67652454103248 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.7137078248768 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.74807709975235 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.79805108117559 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.83998089046105 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.8997800612406 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.91243250526392 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.93673037254958 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.93952752757775 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.9696637927312 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.9769755180889 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.98565758036048 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.00286592207388 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.03334285569771 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.03666991953975 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.06466387946844 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.14487459667387 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.314741282764501 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.19771899300262 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.322986008827954 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.24209808549239 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.25981930366382 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.2651576589571 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.27156735428079 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.27683399185042 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.31838712147471 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.37815028896941 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.47490147613709 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.6066937931728 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.65051152368724 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.68350891761351 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.68553547175982 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.7002466305091 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.8293861266747 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.82952751041152 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.83216357859138 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.87644304660814 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.91243322742132 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.9690787125807 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.97697754781714 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.97925173267619 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.01301662101656 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.17492942345048 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.18752275523408 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.22116996772806 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.427839741954912 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.29770565883283 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.29863513649664 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.30269462134163 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.32122698042784 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.33422302564894 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.36237499626186 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.38520309775633 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.38621039584888 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.42435372710227 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.47156591004253 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.4916333781212 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.452503514636149 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.52705561112035 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.56049737026666 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.61999011465792 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.641787652669 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.6590301838932 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.7287150038707 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.78972087444826 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.84338519370064 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.86100128514789 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.8693283365402 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.8824382351871 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.8914566613887 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.91740002277339 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.94479255870718 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.95006225194172 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.95146858208015 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.04049845332639 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.05243605635116 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.15749613734496 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.2448361470128 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.27010668948056 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.27434640624267 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.29611497647744 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.303970381793 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.33939583174075 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.41717497643174 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.42141273875151 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.43935716317364 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.44360138324207 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.48301013385091 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.48837730639546 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.52732447013332 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.5519099681369 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.59949970994062 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.61853628042292 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.564093227550245 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.66782511018972 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.69313622717566 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.73071268787992 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.7417189417144 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.79228098601385 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.81707855798281 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.83665299872266 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.88616115417189 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.88645645948276 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.589374846928294 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.05713649853341 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.23473488477947 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.2532041180249 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.26425129423106 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.29306594874372 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.33267598562398 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.34789777081926 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.36467420284036 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.43946768754519 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.50355355308282 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.5053688170978 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.53516159911902 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.55558506247202 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.659031518551515 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.66366906553812 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.73447952926225 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.6747946411672245 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.80904007866287 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.92869264059621 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.96497051428565 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.97786318650968 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.97899373155579 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.02164762062789 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.03526435198103 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.09126909570344 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.11756195813264 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.15155616900951 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.20356789618641 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.20459712518522 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.3209486719141 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.33980656337683 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.35800732903544 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.36739801626456 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.38159667570723 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.40617910087565 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.41448729880602 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.741853309818978 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.43977771984325 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.49181103095015 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.51244973330624 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.5780169339373 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.60327059287486 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.61523532378635 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.75572628535664 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.7739334492345 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.78444940525759 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.84148451044636 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.85515057944046 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.8944628438533 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.90044253645483 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.90153954407953 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.90589940322215 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.95853375638484 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.97572945008267 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.98042915966138 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.799898793252694 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.05657588958441 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.807773627855269 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.08250888545689 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.12746683000991 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.14124033169742 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.15186781669283 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.817589904355145 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.21398081194482 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.24941703931434 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.29812068425642 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.32280127107424 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.832923026565226 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.35840517470744 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.40287659162837 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.42880608987268 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.46909908525996 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.52010864610135 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.52276105304222 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.54118418952376 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.54942757853729 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.55163431369809 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.55852857977845 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.59261073996566 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.62844539816504 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.64731157996879 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.8714176879553435 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.88409154848037 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.86873773613017 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.87664814251104 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.89561329617388 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.93784437593847 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.96576860052684 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.01373177852503 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.90282191579017 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.0959245391835 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.12244251207802 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.14631299872335 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.24857060286803 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.26483276227984 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.30269175525319 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.32993077379176 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.44455349592776 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.47071612156478 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.49571570647802 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.50672703577956 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.51772237183425 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.55372291995697 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.5766507677071 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.62995952501073 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.6732377416015 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.72134848132907 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.85348113132362 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.86603507676404 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.97663578928459 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.01650054812089 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.06230826393106 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.06555402496704 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.10089461515409 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.12580094281059 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.30253924995961 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.40035917842778 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.43103668636522 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.050409513350658 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.52257845229988 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.052870062426749 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.055134186286764 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.55327050117856 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.57538978765378 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.60839056341891 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.6197037092228 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.06872472513605 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.71045333117436 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.71055715351957 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.72011263547853 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.74014133241022 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.78170521264542 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.79169451589337 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.87170590177436 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.89371700772176 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.097572268408484 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.00959646623551 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.02120479662563 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.02366884643104 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.02618027239738 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.02985965512289 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.04468297825925 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.15142946248402 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.11610870096547 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.18036428065952 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.18621331779292 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.23825844210808 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.26398629575509 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.26759273917459 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.27019864194594 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.29625977515636 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.36329014861359 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.37247481528684 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.3762240809744 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.43841837309635 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.44555425548454 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.44862466190648 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.4513008028088 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.453754740509 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.48570118703668 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.63884312312939 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.67563378791264 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.69101783724149 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.7297744541618 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.75243850690421 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.7714008538301 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.78214464402785 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.79513873888378 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.184322698068613 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.85967743111425 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.186284106273149 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.92505498262716 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.99229070868022 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.99547459862579 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.01324218174797 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.02573515177178 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.03976901631786 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.04089849834016 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.04982140130667 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.24592425919877 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.226939075959834 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.30056088975984 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.230787152365963 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.37180360447655 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.39134286483068 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.39557965793907 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.40383065535562 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.40657350548042 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.47855659837684 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.52727579654533 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.55503125920515 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.5813406360877 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.60244453178638 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.636579396989 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.70979453045243 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.72048765352679 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.74162013224591 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.78612799894742 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.80085939228492 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.84133134599057 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.84668628755749 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.84730980598334 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.86088544564834 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.92783922535372 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.96189595376819 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.96253920518757 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.299874077258963 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.01272179111695 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.01518164960785 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.03012151043117 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.15814373246519 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.19112853650161 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.202121103602 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.249320530376 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.25605153954292 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.30544126372703 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.33128476822169 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.340535973639348 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.46147153937342 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.53231275318338 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.54437640811902 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.59287695230631 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.60727545188398 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.6177606132405 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.63993516677107 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.67978284459741 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.6934864259394 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.72420752489877 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.76179733691515 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.78855350669954 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.02936780806343 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.05446784532893 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.0879601322158 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.11220799422972 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.15307839593167 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.16149346498973 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.16429373723129 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.23334852565245 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.24280808900005 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.28143797114866 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.28151267924846 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.28524895175153 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.30624296799118 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.32533573707495 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.32704351967749 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.34177405242407 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.36307665266779 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.39202302601522 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.51319238756432 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.51357825006889 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.53103378058901 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.60550138451276 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.66183243146537 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.66746896975792 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.67097332267473 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.7055787849527 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.81140735016699 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.82646228384705 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.94152319233712 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.94694356366801 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.503026170153817 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.041735634771 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.0475139990192 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.07425438280008 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.08593066258851 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.14086709874613 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.1892263771744 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.18955411977554 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.23033179469452 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.2587554606919 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.32134116256422 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.43986638991524 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.47190626430879 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.47399964923208 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.5070524038289 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.54288853268103 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.54473562605793 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.56746793555769 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.62964518072955 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.65748431252834 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.71221350581331 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.79235080651813 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.80130835455269 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.89506615380236 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.90237145660404 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.91958245296394 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.93887646690177 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.96361893012217 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.02589131098316 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.0513846880902 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.16052941459705 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.20515877698097 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.23393370731087 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.25740865840304 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.25910399375843 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.26129227154411 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.631733066650398 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.31750203572375 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.34424962499952 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.635037106340462 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.35135147875461 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.4047897071361 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.44202109911303 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.47922441167628 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.51211205516181 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.59943744521452 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.61921267087824 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.62005246032565 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.662928430008733 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.6313623806184 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.6574797189778 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.68625576310576 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.673561770019973 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.74289678136746 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.84816934628394 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.85720412153815 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.87021388135199 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.881532331921 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.94735117309602 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.07849113702548 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.0904462551684 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.12070005542671 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.127761413333 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.16321135835085 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.18611310499273 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.720485311724559 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.2335615095202 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.35378044505735 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.36886979667857 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.37911733897545 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.38247640910475 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.43231375167102 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.45652161501086 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.46813423663673 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.47855050783761 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.48007434012058 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.50527488716217 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.51476060984055 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.755783898284847 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.65428883349044 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.78090118599079 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.80262096216708 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.81078766129183 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.8776268813916 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.8898969433099 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.90470536691448 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.9205718976257 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.946658248974 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.98198414072233 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.03573666981484 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.04200256399753 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.04255961488872 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.07998549547689 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.11205106569555 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.15370061757024 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.19719734141904 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.23556157563048 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.26711807268765 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.31897487727893 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.36866978917857 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.4093693822121 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.4199389059644 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.42540458978578 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.46500641154651 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.48160233687244 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.49175531983728 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.53558936491545 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.54159335847784 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.58874236305192 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.62460879474712 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.62979517256393 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.86575764104822 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.72197224885758 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.74306456990053 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.75012435062271 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.75473811856926 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.76297175521309 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.76727735105916 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.76760535568403 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.80377914014622 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.82045457443107 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.83629605717032 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.84347436250857 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.87819697363895 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.8872186067323 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.93992164147811 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.9777555904598 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.02892607180202 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.04694646834895 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.0793263011922 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.13627152530736 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.17240827908952 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.20166066829194 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.20382897595496 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.922790333817971 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.23886863600427 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.24564343889905 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.24833837132063 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.46342439126478 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.955562280121015 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.55635741519944 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.58228829385801 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.6149978643235 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.96678656830268 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.6778919536962 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.968236311488369 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.68706807820664 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.70192411792668 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.70333918599935 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.74997858578749 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.88990046441667 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.91155034554612 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.93537242911236 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.94079311285239 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.0110538195924 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.01876851375104 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.03147183178099 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.06054551821086 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.13232186069762 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.21089764741868 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.29889426004432 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.30094043087271 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.30351141863689 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.30874453899037 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.377279793095 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.45052198044492 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.4744623719449 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.050258820352994 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.61028839621936 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.66053592786294 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.69146134278137 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.72848764513488 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.73073235447609 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.73629667452339 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.83047272200594 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.83352076506681 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.90726480275247 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.953243338071 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.01882164435085 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.10646251902446 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.1149735310845 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.12789824131417 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.32700315515696 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.3414084339197 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.4253862623058 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.45870105771996 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.49743335462183 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.52828205300689 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.52841258108622 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.58470316118532 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.59741478469064 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.60076690100858 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.61252981230422 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.69258339072036 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.69718381959453 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.7804838673288 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.85959217269443 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.01858156133218 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.07853722480654 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.08781877032533 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.10250622021996 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.14269586006374 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.19583012286989 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.19653798131742 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.21203623273102 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.21247387420841 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.23460325649053 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.40555847885896 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.5508040312323 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.25905032645153 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.63215661349047 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.64986638704218 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.65397061771357 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.68212149280978 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.702402685955 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.70464436921138 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.73196464622436 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.78863572759404 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.85638069920374 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.89302093624616 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.95545128401798 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.964065932316 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.03985759147233 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.305183072338224 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.31137101092061 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.11427048909384 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.13553239436358 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.17871215000255 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.18022680766167 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.19680811825586 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.321389923278574 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.21436860040978 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.23061413399383 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.23638653101504 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.28479816506723 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.32887439903779 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.33292481962788 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.339001732441773 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.340643855285052 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.40689965147797 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.341594556472657 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.46093516114149 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.51565056479905 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.56206949597777 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.5805536552472 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.69197933396327 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.90609937408352 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.9098125908422 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.93316287873094 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.97384078859115 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.97563838179776 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.9774940061174 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.99273115771518 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.01168682146077 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.02001489109107 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.02900754643824 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.05739843814622 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.12895239358434 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.129574225427 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.1871769843287 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.20935777018028 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.421025970354634 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.27215071069317 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.33529618235713 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.35530795930099 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.44327377544101 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.4842161976431 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.53538375552375 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.56721931699445 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.5681330163112 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.58601354548794 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.60385673845644 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.6046137833591 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.63997103621244 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.67207723945319 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.69134641667847 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.70186491379972 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.71862647211029 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.73943180226601 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.78298361417691 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.79002944760899 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.82351904603155 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.8391461806173 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.85386736197803 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.85983010264948 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.91331208922367 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.99839073084945 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.04513019129644 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.05561905832165 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.06350254176957 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.0736876495578 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.515194766652996 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.21113549032233 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.21718866684223 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.28228720131364 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.29716889027402 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.3143064126676 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.33592206662212 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.35138006231011 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.36242657443212 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.41572934991756 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.4198765920675 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.47118824438331 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.50354030338404 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.55955690369042 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.59520381613858 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.64530136405116 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.570911029293612 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.71919650306768 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.733933567328 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.74243891306496 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.74972973654154 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.83674608085535 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.85256180167407 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.588224339484412 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.88538630674792 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.89620395341312 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.95755629542015 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.98334942536215 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.02693936108531 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.08732508730145 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.614204347488624 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.614389834837397 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.16535823615706 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.17519575597055 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.23337553134519 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.252049777186 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.27028496720979 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.283450078012 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.631817866065546 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.39888860319049 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.42690369856193 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.47149005529052 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.51429584148093 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.55616867807713 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.657242020382427 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.62764091233377 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.68247809613841 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.7383179278124 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.75037717539374 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.75421054091522 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.76783650887207 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.79728087544865 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.8212206626964 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.92065751745301 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.93382122300295 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.9747394484875 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.00008044428105 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.0982813836059 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.10585141837309 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.10733714161739 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.12818184795762 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.71446501791769 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.24758034802214 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.29669712071072 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.30789134057287 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.34633815376846 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.37135006188393 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.38047757353476 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.39626783685493 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.3986292264513 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.40776397976182 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.42356690719265 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.50287564766454 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.53297884438949 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.53883475654068 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.53913392436526 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.57367645893069 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.59163286118142 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.59546645655197 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.67760396153209 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.67997504845232 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.70781113588987 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.777239534579408 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.77566121996779 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.80400511154947 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.90121314758503 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.90968780895825 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.95425456404834 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.9647138234852 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.97864738400601 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.02305608118915 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.02422673050121 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.1100457998171 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.14406535073034 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.816050205495358 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.1827039062388 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.20357141202119 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.820573326546821 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.25433371727601 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.30393633553258 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.33468038029731 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.40745317155057 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.42663072255169 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.43294834012515 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.43373411246287 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.46217704799933 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.51424724140843 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.5306265901113 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.53643250618329 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.53970642465752 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.854601126129367 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.859717583330266 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.63608019904771 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.66486025606515 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.74005839111608 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.76603822385641 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.81127242350138 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.8351140693521 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.84344554045657 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.86727545472603 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.88250324693864 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.89671622560795 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.90496584012314 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.9061500381738 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.98203013097691 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.995153700373 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.04190957354434 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.04505867307299 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.09002612614286 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.1752661055516 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.18839233819541 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.19780494208246 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.26160284565955 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.28237809584503 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.34071313631789 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.36195447686976 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.37024341434724 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.41174593675956 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.4330961583454 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.43489910031415 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.43708836215997 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.4414916451207 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.46074777853109 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.4755430125117 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.48487465517255 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.49006128759063 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.960825420308424 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.61063339973575 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.64973017263365 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.65469083319087 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.65638267704063 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.66655030375335 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.71990630687652 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.78074674762043 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.80091786731097 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.86566576618488 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.88490176773095 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.89569280345914 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.90113519961919 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.90235529260727 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.90783921836817 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.97081392215938 ) ;
  }
}
