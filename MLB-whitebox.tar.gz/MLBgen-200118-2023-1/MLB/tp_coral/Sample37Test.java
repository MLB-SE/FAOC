import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.0020453668378070666 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.005105419551853174 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.010346575411148251 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.011087508615994696 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.013086025361236708 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.02100460853285803 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.026340630081216343 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.02705124925706137 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.0295168938867576 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.03666001291677912 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.04739089910630154 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.058411241042932716 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.06115048072164253 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.06655913757394505 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.07582961438332347 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.08189099128142807 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.09298157191447598 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.11830377104024592 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.11997569376630658 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.12406616964112205 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.12448561375104639 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1336980033603745 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1355223533915081 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.13726804409634497 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.14248949505391506 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1476075474791827 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.15195283869428522 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.16211582052341478 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.16461895374056112 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1654666629064373 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1825191264714192 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.19382605446055123 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.19393362159629923 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.19470653307874963 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.19612844251624217 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.19782390416074236 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2219490174333217 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.22320407547297805 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.22556510317110678 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.23091192365993152 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.24234323704504102 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.24439557132210155 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.25089632649170035 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2514773446144858 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.26026144458886336 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.264228167611264 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.26755676363524117 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.26918354867970606 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2972934208406599 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.30074897091890973 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3054272840613521 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.30617473963062025 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3074238433928116 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.30788866142136584 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3201248664708385 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3251473496474375 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.333277269087338 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.340887836222596 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3695040517884447 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3752034444850486 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.38677627516615876 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3937564365637627 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3998043957048951 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.40249832739904434 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4079406531301033 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.40925677606263466 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.41755680891857705 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.42015067816209983 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4245538777056288 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.43000942791789676 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4318687387295528 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.437172131401554 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.44342231046934577 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4534330127214474 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4560856140970202 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.46021331468161164 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4629299261485329 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.464525929225839 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.47483010704560513 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.47613302406466573 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.49559861116361503 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4981817645793569 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5021968893756283 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.51659768798973 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5197136833694138 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5235088800457337 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5242537349626559 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5357827464897053 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5454675164165774 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5472160086403055 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5578962137630583 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5580677423037437 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5694622997247702 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5794874212578542 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.582126009093372 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5827549553555678 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5914615864008157 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5957310606978385 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5974903330364896 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6089619361683851 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6148363720197425 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6227812887276194 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.631001820170872 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.632469664397405 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6324824819763775 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6349341993282224 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6374853521121986 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6399576949956698 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6480794237756697 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6499285753210131 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6573146648990715 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6611846833355344 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6613581552307899 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.664595250994001 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6653928082242961 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6703004298815216 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6748247745997844 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6754994116719235 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6774511888008758 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6837912461431773 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6838137387064727 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6862026757524049 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6940729124341516 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6984830241520066 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7021363069908801 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7207883756097857 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7277111537341847 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7291816536950364 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7403907720644023 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7565649114494892 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7584748121294496 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.766757424486959 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7689834229841401 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7753714792924931 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7788716513988021 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7805242423752645 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7941009513853543 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7949289225496015 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7956271562082833 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8120641525743038 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8226246409677751 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8228106570395664 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8305898648056882 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.836773188197609 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8415411279730911 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8665741430598657 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8745785150343046 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8890259319799004 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8895785539006658 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8921027321906223 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8951680523393577 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9059407574344647 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9116327194040252 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9120179211294328 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9120799029312963 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9125377449637142 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9182456744857057 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9197561692765106 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9256556756551433 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9264110358124356 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9267845171868772 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9392138425642571 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9401534420921109 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9469259021627607 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9497612653267614 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9535552204182522 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9594620016927848 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9687693225825997 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9728096017174133 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9774216535174816 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9997050117264195 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0024958762200948 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0069728662900772 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0182239503094903 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0276685940115513 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0497263792125437 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.051780182485615 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0626590438529169 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0684538777191017 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0729093911197363 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0943444118755252 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0E-323 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1003354313447402 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1135626046999174 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1213714065860785 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1220006345694884 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1251790915952427 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1308293361903026 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1313280764924087 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1350088881864133 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1416684646049657 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1432139671178985 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1465120458934024 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1536626516205095 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1544134129120183 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.154639505275128 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1565300029948402 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1800647828180022 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.184221323124265 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1883359794246013 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2028807427003017 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2153543354670662 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2263341564616468 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2273177425065045 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2315426645491243 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2322268111066805 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2383499058594083 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2447487615618655 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.247548850909585 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2542537835105936 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.257110344703321 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2574803791114253 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2731530541003906 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.274366542080017 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.274624394243155 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2787270531324753 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.284560465719411 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.291560138684119 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3002988370677713 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.306675803659823 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3076384901874007 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3239539804450604 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3273150936909848 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.335471665408439 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.339580120962026 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3406183569751549 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3473425545908213 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.353219764059848 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3726129677007033 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.381066269227012 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3958404641968958 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3977569186750571 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4016673306411036 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4064898725051762 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4119470161405663 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.417776307645596 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4202746733544842 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.420322258520958 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4228554340222144 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4293387506972435 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4423381252888339 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.445855016325337 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4555601056234893 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.464003366062839 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.465570263939131 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4657558970211917 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.476558417736804 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4820152806702653 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4829643975693902 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4883797112328838 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.488601378207647 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4941157556699523 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4965985044251218 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.499999999999892 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.499999999999961 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.499999999999984 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999858 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999876 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999911 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999925 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999947 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999964 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.499999999999997 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999973 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999978 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999982 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999984 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999991 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999996 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999998 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.5 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.5516833815944153 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.5707963267948912 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-18.061943086631672 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.879766425342666 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark37(0,0,2.152329325076451 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark37(0,0,22.38314415723164 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2618.197013530813 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-26.46539551741131 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2715.0335945651805 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-40.515024089882125 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-4.9E-324 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-53.07313044643913 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-55.46417448016157 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark37(0,0,5.551115123125783E-17 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark37(0,0,6.938893903907228E-18 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-73.49609899518259 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-8.020918984432384 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-81.42071310356414 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-85.0782228300569 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-93.25048589359956 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-94.189346255662 ) ;
  }
}
