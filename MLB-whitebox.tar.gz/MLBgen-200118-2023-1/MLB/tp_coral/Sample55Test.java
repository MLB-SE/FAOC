import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(0.0034402438920993978,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948877,-13.385984200746627 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948961,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.0061128762227525115 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.027390863844229663 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.028770042747523095 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.034014810787794225 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.058646798643530264 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.062208199350807174 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.06255252523208922 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.06255252523301495 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.1038338330223189 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.10746541731896286 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.15514758703483822 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.18819957247847474 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.2773777571844709 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.3197988133584233 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.42930067287972534 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.48646921843816315 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.5042591836040987 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.590857689335239 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.6809185581239818 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.6995765742720204 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.7828384438167832 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.8274936847168708 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.8372990946884169 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.8535082371016068 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.884754732885761 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.9214796645970731 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.9761996837419664 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.9765049126823362 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.9768347900726697 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.9957137950957612 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.9981738234063001 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.9992907343067372 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.9999999999999978 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-0.9999999999999991 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,0.9999999999999998 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-1.0000000000000004 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-1.000000000000002 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,1.0000000000111322 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,1.0000001899348203 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,1.0054738779596757 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-1.3237658635061885E-14 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,1.4003167539820549E-50 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,16.632427572037685 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-17.64638534844499 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,18.933125206930203 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,20.030656599540027 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,2.0911514698520513E-15 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,21.706510320225597 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,23.170325502775903 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,2346.2498129894534 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-2.364018248015128 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,2463.03511194896 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,28.104691101600444 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,33.8680417699273 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,35.472950312838734 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-38.10854405352187 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-38.843060829186626 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-42.465797909247314 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,43.32061434825823 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-47.28045880100524 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-5.02106469189026 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,50.778685082676105 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,52.53809665297673 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-54.67089878695299 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,63.70785136973544 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-65.6740269229858 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,70.02230135455261 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-70.0870687638401 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,7.218228053719916E-241 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,78.24673951044448 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-7.888609052210118E-31 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-92.06724260651615 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-93.08986585912506 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,96.14976180419927 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948966,-97.45757183457633 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948968,-1.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948981,0.03565292420346201 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948983,0.9113603298395869 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948983,-0.9992059518547441 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948983,14.52023333812545 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948983,-7.045226993515854 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.5707963267948986,-1593.7031235344057 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark55(0.025554025660031537,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark55(0.032366415392008185,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-3.3881317890172014E-21,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark55(0.06560898813817817,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark55(0.06818336063726083,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark55(0.07436149862562463,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark55(0.0889369050590254,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.9890189291055833,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark55(0.10006265611129095,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark55(0,-10.461205069494355,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark55(0,-10.563146369670974,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark55(0.10780839980098733,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark55(0.11504392239257369,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark55(0.11539105678656014,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark55(0.11692890605465064,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark55(0.13304204831531763,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5476393685536447,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark55(0.17196188295896775,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark55(0.197031966160921,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark55(0.20135074726943003,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark55(0.21111739437316857,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark55(0,-2.3817395095759366,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark55(0.24510434930197042,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark55(0.25036727355681904,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark55(0.2646201010625081,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark55(0,-2701.123833427795,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark55(0,-2722.906738351235,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark55(0,28.454718676246415,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark55(0.2989240295940214,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark55(0,-32.60193508510805,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark55(0.34609593493419766,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark55(0.35028909959660215,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark55(0.3561522609814034,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark55(0.3582525111795387,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark55(0.3686207362234626,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark55(0,3.699509610348599,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark55(0.37934315990425954,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark55(0.3964235694055134,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark55(0.4376912142894014,-1.570796326794897,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark55(0.45764627910094635,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark55(0,-47.739441421306616,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark55(0,48.88994880448695,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark55(0.4890046746109338,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark55(0,-50.052337432671564,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark55(0,-52.33742352434343,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark55(0.5601874818801633,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark55(0,-56.29098800402639,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark55(0.5699774493038916,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark55(0,-5.86211269194348,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark55(0,-60.72835130722507,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark55(0,-6.162975822039155E-33,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark55(-0.6217336082406462,-1.5707963267948966,0.06255252524667063 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark55(0.6739304070716656,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark55(0.6930789831412918,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark55(0,-79.60717852023787,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark55(0.8037802933459073,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark55(0.8064305416408217,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark55(0.8396089368028568,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark55(0.868442280352385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark55(0.8812453120760146,-1.570796326794897,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark55(0.8814563212016966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark55(0.8860127859643123,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark55(-0.9097263621511615,-1.5707963267948966,60.639136643376816 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark55(0.9283029200145947,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.570796326794893,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,0.28569643164487435 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,-0.9999999999999999 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948966,8.324989663719589E-258 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.570796326794897,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948983,-0.7030838393961647 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948983,0.9999999999999023 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948983,-2392.2293772033213 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267948983,-38.688527234351405 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.5707963267949054,-2510.6568345744213 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark55(10.019047118134779,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark55(10.070428934449225,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark55(10.106084280428643,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark55(10.114155944255241,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark55(10.145304222496273,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark55(10.14614076478506,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark55(10.153067994251247,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark55(10.165208689179742,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark55(10.245771949311862,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark55(10.258047250539427,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark55(10.335340935849445,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark55(10.360815288912747,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark55(10.389354949042051,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark55(10.426651054144799,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark55(10.43109445087411,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark55(10.525551440003895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark55(1.054313709140573,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark55(10.557199115236585,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark55(10.557537116598933,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark55(10.562772411495496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark55(1.0596419116767246,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark55(10.609927782020279,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark55(10.62405561703035,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark55(10.654640195156635,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark55(10.678843832370063,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark55(10.680345172889414,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark55(-10.72338487800391,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark55(1.0735475567337005,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark55(1.0774270699323267,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark55(-10.783024545615618,-1.5707963267948966,-0.9999999999999997 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark55(10.837283626305066,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark55(10.956442963674846,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark55(10.96265738933235,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark55(10.981651213795487,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark55(-1.0E-323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark55(11.038730903681511,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark55(11.048979602245304,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark55(11.063475002174911,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark55(11.16697250149455,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark55(1.1177574463019067,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark55(11.207532762418822,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark55(11.213121307022519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark55(11.218578809498922,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark55(1.122722848408415,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark55(11.23192024502608,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark55(11.25197278978061,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark55(11.270166917791698,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark55(11.285754573547663,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark55(11.31857381290556,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark55(11.361177675412137,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark55(11.382718088775405,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark55(11.539115434377507,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark55(11.546893580102527,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark55(-1.1560584994931375,-1.5707963267948966,-77.57234313363571 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark55(11.657964167825426,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark55(11.669172731032049,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark55(1.1679535304121202,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark55(11.681213649831989,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark55(11.693175578300272,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark55(11.736398783387415,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark55(11.77260346435179,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark55(11.788538365954865,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark55(11.797685710507015,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark55(11.817936885514513,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark55(11.926943154072163,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark55(11.983265420786967,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark55(11.996509979467781,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark55(12.084998685622555,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark55(12.09018477141322,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark55(12.146115794646747,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark55(1.2166208602181001,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark55(12.21054020555906,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark55(12.230001910201864,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark55(12.2443116472202,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark55(12.272057127867392,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark55(12.28774721598041,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark55(12.322611832592287,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark55(12.37329052460126,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark55(1.2389154957042765,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark55(12.412704230792887,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark55(12.438205656016672,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark55(12.448782844890784,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark55(12.510204496072035,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark55(1.253530061627423,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark55(12.545095652368321,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark55(-12.602475830341604,-1.5707963267948983,2524.7194971569734 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark55(12.63690233894679,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark55(12.65105206349719,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark55(12.659315792427321,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark55(12.694192192150572,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark55(12.805614553780583,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark55(12.811032601937338,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark55(12.846734405956534,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark55(12.906134689787123,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark55(12.910682979711934,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark55(13.000351126610525,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark55(1.3007796349561859E-259,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark55(13.023278522679558,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark55(13.14671061062675,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark55(-13.216406142693604,-1.5707963267948966,0.3270206287816148 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark55(13.385802894730839,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark55(13.449833630381775,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark55(13.489133448374943,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark55(13.556055973342858,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark55(13.642528452997396,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark55(1.3751798696993873,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark55(13.784334556900756,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark55(1.3793305102551443,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark55(-13.922586099320027,-1.5707963267948966,-0.34970095918235 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark55(13.99546370304607,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark55(14.057849306053196,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark55(14.144765221700947,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark55(14.161575258822891,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark55(14.213701430627058,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark55(14.224846452003575,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark55(14.239784969788815,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark55(14.322422305109455,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark55(14.400522380328425,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark55(14.401176184905143,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark55(14.496449142087613,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark55(14.57743412412136,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark55(14.618414800194401,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark55(14.677567315189538,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark55(14.84638993160084,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark55(14.857812756173018,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark55(14.876464342231007,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark55(14.883871070578422,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark55(-14.924866614098976,-1.5707963267948966,0.9999999999999198 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark55(-14.930587186152124,-1.5707963267948966,-24.72759778612574 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark55(14.933133918383007,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark55(14.957868636065335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark55(14.995907381799592,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark55(15.029454416951669,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark55(1.508241444680806,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark55(15.156779583788293,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark55(15.158829256282193,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark55(15.176725842617095,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark55(15.325305292607759,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark55(15.33692576649102,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark55(1.5340643497358926,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark55(15.376415451161195,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark55(15.46130302616925,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark55(15.461311284694247,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark55(15.509994641988229,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark55(15.511647667918892,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark55(15.567740475065577,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark55(15.570726564662493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark55(1.5595324236663406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark55(15.613319351593802,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark55(1.5621815318616576,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark55(1.5625574433891662,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark55(15.672819171333401,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark55(15.685179627132435,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark55(15.711718089044169,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark55(15.719333371712578,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark55(15.796494058591788,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark55(15.84318492844697,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark55(15.843442521344741,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark55(15.915185096762734,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark55(16.080423453198314,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark55(16.086201210155778,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark55(-1.6111956357606232,-1.5707963267948966,-83.41370095688727 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark55(16.11946626058996,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark55(16.13837391680591,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark55(16.153067693774133,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark55(16.162591503391695,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark55(16.17030952553051,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark55(16.18726734074341,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark55(16.227200868377242,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark55(16.29021803383356,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark55(16.464230326761857,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark55(16.48414499757566,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark55(16.566658856697703,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark55(16.651882515809575,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark55(16.709361926646224,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark55(16.76220886745881,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark55(16.91611049139786,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark55(-16.916560249258684,-1.5707963267948966,20.966917938399217 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark55(16.94107558914956,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark55(16.94800255834011,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark55(16.95116232125868,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark55(17.040047692821457,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark55(17.05196224858049,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark55(17.054152446865317,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark55(17.06239926241244,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark55(17.151804057709434,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark55(17.161791278740793,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark55(17.169423871805336,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark55(17.207126981072165,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark55(1.7390613742855408,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark55(17.419245694328964,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark55(17.48253923568252,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark55(1.7534380497155562,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark55(17.541628184613856,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark55(17.546583924433847,-1.570796326794897,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark55(17.625135302838206,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark55(17.675840982166093,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark55(17.7118087245521,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark55(1.7763568394002505E-15,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark55(17.77853968507063,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark55(17.824705536084863,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark55(17.896185404036498,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark55(-17.9520946440894,-1.5707963267948966,-16.751561767545 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark55(18.02720822882422,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark55(18.041833430263225,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark55(18.051671488759084,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark55(18.074989331179328,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark55(18.177175206350313,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark55(18.20293811582417,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark55(1.8222543179646493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark55(18.259644544267317,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark55(18.275020535168256,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark55(18.29704750847479,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark55(18.363333581754464,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark55(1.8366587445928797,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark55(18.372751180611814,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark55(18.39264890459873,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark55(18.401108316515824,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark55(-18.480518452711905,-1.5707963267948966,-0.14408587184231503 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark55(18.550369169917886,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark55(-18.55300158638119,-1.5707963267948966,-23.621424679803418 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark55(18.647253015512888,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark55(18.761055525011354,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark55(18.761286722548427,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark55(18.781285487538327,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark55(18.79321480370213,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark55(18.820170059606117,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark55(18.84098040678093,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark55(18.89036709941736,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark55(18.928069274431465,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark55(18.934713343058235,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark55(18.945999900073303,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark55(18.95678007577222,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark55(18.964903505026058,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark55(19.081124706606726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark55(19.095646419335623,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark55(19.106526166128187,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark55(19.108402752900123,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark55(-19.137131703782813,-1.5707963267948966,0.931650450191836 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark55(19.138041989930745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark55(19.195734175148722,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark55(19.198063350587134,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark55(19.210336357564813,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark55(19.23217981146966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark55(19.233518750379705,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark55(19.30072080975488,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark55(19.3285867711636,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark55(19.35443831514281,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark55(19.384639497542395,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark55(19.385642669487503,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark55(19.444053187645977,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark55(19.543786765237996,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark55(19.63201409741482,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark55(19.64252900562881,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark55(1.964267627298577,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark55(19.655355029852746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark55(19.67777061954046,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark55(1.96921295223747,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark55(19.722026995075662,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark55(19.729561985948326,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark55(19.780504514793808,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark55(19.808352276358512,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark55(1.9812326630182184,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark55(19.85754776429566,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark55(19.909129011436804,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark55(-19.938948568510888,-1.5707963267948966,7.708323623831828E-22 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark55(19.9465159560044,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark55(19.947860235230795,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark55(19.97582387598598,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark55(-19.977762770069923,-1.5707963267948966,0.04666886331832833 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark55(20.00989242309663,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark55(20.02650848825398,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark55(20.03140968212496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark55(20.11538171849376,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark55(20.15056989994224,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark55(20.15705033168204,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark55(20.15881186479053,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark55(20.1665194312437,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark55(20.17040653107047,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark55(20.18678924458598,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark55(-20.235755656633035,-1.5707963267948966,40.501258680853034 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark55(20.237661187472167,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark55(20.239706806750444,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark55(20.245512173130663,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark55(20.26610251124567,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark55(20.27162178221201,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark55(20.333391026563703,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark55(20.33388614792355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark55(20.370504418925634,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark55(20.372455613842845,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark55(20.383936000817307,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark55(20.424371983144354,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark55(2.046147746867175,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark55(20.529794852019137,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark55(20.542411410840348,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark55(-20.550510279663243,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark55(20.566285253254623,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark55(2.060481046385718,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark55(20.69859368022003,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark55(-20.95274404182308,-1.5707963267948966,24.79163476483346 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark55(20.997655718292357,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark55(21.1372074477094,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark55(2.116709007321352,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark55(21.182002595209706,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark55(21.217205193820774,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark55(2.121903103594504,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark55(21.264189260508196,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark55(21.54667414091422,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark55(21.634162005067523,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark55(-2.1669105493942947E-16,-1.5707963267948966,-2369.2709140356546 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark55(21.68100530970024,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark55(21.816546775107337,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark55(21.853049062752234,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark55(21.85802334548479,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark55(21.934345372853365,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark55(22.04875045477614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark55(22.06878669934696,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark55(22.117064566838593,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark55(2.2178799546944923,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark55(22.18007686298897,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark55(2.220446049250313E-16,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark55(22.229486218936557,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark55(22.23240530022318,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark55(22.31656764584475,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark55(22.324622784534867,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark55(22.334198665030033,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark55(22.36884228586598,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark55(2.2384018298795145,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark55(2.243554322837139,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark55(22.441406305765135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark55(22.446880724091216,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark55(22.448118054983496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark55(22.451810943106437,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark55(22.500506634546767,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark55(22.532268595923206,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark55(22.54451238247377,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark55(22.57526106117048,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark55(22.585809895884015,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark55(22.601090768490522,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark55(22.665676617994748,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark55(22.696192664235596,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark55(22.707852653390617,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark55(22.773780544493583,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark55(2.280757740825559E-28,-1.5707963267948966,-1.0000009103527094 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark55(-22.86266893118509,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark55(22.885129600880067,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark55(22.899915974776203,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark55(22.979363616645614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark55(22.9914198651294,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark55(23.007079268962652,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark55(23.023088177262636,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark55(23.027747955228037,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark55(23.045674684772848,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark55(23.120041221885316,-5.130595267544251,-33.75228132634487 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark55(23.133884990449808,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark55(2.3164386348264756,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark55(23.277170975180805,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark55(23.322702329229386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark55(23.36649714640828,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark55(23.36722084735699,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark55(23.41385813902229,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark55(23.433143214311826,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark55(23.44507131809701,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark55(23.467910332299308,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark55(23.474885772769056,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark55(23.48812717943315,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark55(23.49505062991042,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark55(23.537174173181924,-1.5707963267948934,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark55(23.545533277545815,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark55(23.604718343537485,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark55(23.611526543257714,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark55(23.837502749142033,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark55(23.86537183706856,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark55(23.891003168590586,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark55(23.895231579967284,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark55(-23.9135964985721,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark55(23.936927377852676,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark55(23.98003821614023,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark55(23.99623401705236,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark55(24.0045116509324,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark55(24.00579595101793,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark55(24.037787304428292,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark55(24.05402651477079,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark55(24.08969757099827,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark55(24.13058490139714,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark55(24.184906069319904,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark55(24.238728982738344,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark55(2.4245566852227274,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark55(24.496119507427643,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark55(24.5068479443968,-1.570796326794893,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark55(24.508954275071787,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark55(24.549074256042758,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark55(24.56716680089248,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark55(24.652851725622554,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark55(24.78433715657671,37.31557723746181,39.96159824674697 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark55(2.483138781070153,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark55(-24.871066272561784,-1.5707963267948966,2.981873174886912E-16 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark55(2.4917623750083493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark55(2.5104916414354994,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark55(25.127027950924433,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark55(25.143928750139466,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark55(25.182998217715287,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark55(25.249719086940516,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark55(25.310410178404027,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark55(-25.333234792017784,-1.5707963267948966,78.04626766886409 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark55(25.37729156135381,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark55(25.41574992792195,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark55(25.417431757052398,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark55(25.462295514869723,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark55(25.51690351919966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark55(25.5954261356026,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark55(2.5608723478291324,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark55(25.624287507239885,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark55(25.656369370557485,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark55(2.566388983069487,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark55(25.76540751013016,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark55(2.5827805965617188,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark55(2.584843584070544,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark55(25.891685329064078,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark55(2.592088196517466,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark55(26.01078514781355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark55(26.06723307784663,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark55(26.104228017041894,-1.570796326794897,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark55(26.128228568799855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark55(26.16427064813631,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark55(26.235301417594897,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark55(26.262157183366075,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark55(2.6285264488461375,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark55(2.6318064965942085,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark55(26.384096371458714,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark55(26.451415174834963,-1.5707963267948895,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark55(26.458677516176262,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark55(26.47389099636453,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark55(26.529809919305407,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark55(2.6538453304931444,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark55(26.541560586228783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark55(26.58414269527792,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark55(26.627409274432168,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark55(26.632895116304855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark55(26.63463524286196,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark55(26.672679587010407,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark55(26.67825236987322,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark55(26.834397100698837,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark55(26.846996446063656,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark55(-26.85199861878734,-1.5707963267948966,-0.8777861526710478 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark55(26.885737794159876,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark55(26.928043427064917,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark55(2.6959256762957295,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark55(27.017210690130486,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark55(27.017300511694444,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark55(27.019674138012682,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark55(2.704828055195925,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark55(27.078950165867667,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark55(27.105703217203185,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark55(27.264742540178112,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark55(27.309780498403263,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark55(27.359291084946307,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark55(27.476461622436943,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark55(27.506451770784807,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark55(27.535647982312696,-1.570796326794893,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark55(27.568602911081722,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark55(27.606935682096108,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark55(27.611467707935475,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark55(27.639415516677285,-1.5707963267949054,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark55(27.7324410945303,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark55(27.821832520003653,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark55(-27.84292917903911,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark55(27.858831090115064,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark55(27.88653097785047,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark55(27.89263167335274,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark55(27.911052419261125,13.937347272577185,-80.20056583662591 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark55(-28.01770127615668,-1.5707963267948966,-0.9999999999999984 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark55(28.045499243890134,-1.570796326794894,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark55(2.8050456897650236,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark55(28.10749168279483,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark55(28.11455536403792,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark55(28.178980879870437,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark55(28.223633282988516,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark55(28.22434226699013,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark55(28.280186076430194,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark55(28.290622795634278,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark55(28.321983846447985,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark55(28.362236639051353,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark55(2.840196342272719,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark55(28.502278582093425,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark55(28.5112790248493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark55(28.515552573639212,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark55(28.530327694907086,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark55(28.53655365636879,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark55(28.689917635553986,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark55(28.75906948230272,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark55(28.791318885411737,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark55(-28.82919353716516,-1.5707963267948966,0.54506104200793 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark55(28.901080844614093,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark55(28.920084700170243,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark55(28.946533875847337,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark55(28.978299892541855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark55(2.899386939655656,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark55(29.036821653287433,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark55(29.053441457054788,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark55(29.06509708196345,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark55(29.185497020277708,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark55(29.220993875420266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark55(29.28334256113027,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark55(29.284533112965704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark55(29.3187728256066,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark55(29.371131505440417,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark55(29.386821898962864,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark55(-29.541318392150757,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark55(29.58620523151801,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark55(2.967004527423394E-19,-1.5707963267948966,2.6469779601696886E-23 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark55(2.9685728259615267,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark55(29.726900884727424,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark55(29.73545428236184,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark55(29.745041660914907,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark55(29.748579400483855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark55(29.763424795300637,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark55(29.811777500313056,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark55(29.8204452114783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark55(29.877933923201848,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark55(29.87945979276387,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark55(2.998752336867454E-16,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark55(30.001912973853067,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark55(3.002814103391267,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark55(30.05655304091432,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark55(30.09899945740386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark55(-30.109399514236728,-1.5707963267948961,-69.91314435808431 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark55(30.20234202317681,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark55(30.204617675773953,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark55(30.25484754805285,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark55(30.27044222819535,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark55(3.0283952358430284,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark55(30.342395273465925,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark55(30.365794210487046,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark55(30.40819063804543,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark55(3.0415103077175347,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark55(30.452664055578268,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark55(-30.590513040686645,-1.5707963267948983,0.04187611603924113 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark55(30.604280750624895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark55(30.615138374539114,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark55(30.618254257623036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark55(-30.619338763521373,-1.5707963267948966,-14.505715928096732 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark55(30.627437893856435,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark55(30.707362621643085,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark55(30.736559538588168,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark55(30.73725680239863,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark55(30.802659161289313,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark55(-30.823338449530063,-1.5707963267948966,-78.10618178406686 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark55(30.827882576826212,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark55(3.0868868722982516,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark55(30.914658262349395,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark55(30.935732621715403,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark55(30.983770922503993,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark55(31.082390086289116,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark55(31.239775052767385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark55(31.310472701369793,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark55(3.1324436642475844,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark55(3.1369406641270743,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark55(31.394529911620705,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark55(31.4531112120612,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark55(31.499358418812335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark55(31.547272308308568,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark55(31.551550101061622,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark55(31.568735829009523,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark55(3.158844453619544,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark55(-3.168446310190431,-1.5707963267948966,-0.36208928516251454 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark55(31.700968235353898,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark55(3.17515221743402,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark55(31.78784477757742,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark55(31.788378780394975,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark55(31.82986510728216,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark55(31.8299788523312,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark55(31.89136071167561,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark55(31.971898732247514,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark55(31.98550219429841,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark55(32.03009028733803,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark55(32.05358385636195,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark55(32.09570177698197,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark55(32.112603205175056,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark55(32.12472099392346,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark55(32.16941486886328,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark55(32.29550542981107,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark55(32.33770970207176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark55(32.39217036793511,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark55(32.44304057830221,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark55(32.450687995291815,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark55(32.48713701328757,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark55(3.252313653309306,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark55(3.2579188112586763,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark55(32.588555232081795,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark55(32.611521308147815,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark55(32.6183584015331,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark55(32.63744021327071,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark55(32.68233798125803,80.84369711399785,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark55(32.69367118738012,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark55(32.715591308109374,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark55(32.74033497818591,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark55(32.81039658208266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark55(32.81963725471002,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark55(32.852449930022665,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark55(3.28551892486432,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark55(32.898956765263385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark55(32.91117444539597,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark55(32.97591301927966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark55(33.002049279875564,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark55(3.30328559755435,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark55(3.304203270712441,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark55(33.043252808092646,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark55(33.10423469321559,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark55(33.1832744035585,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark55(33.226179058994234,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark55(33.296748331668674,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark55(33.30488425601263,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark55(33.31910187115986,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark55(33.32748101785742,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark55(33.40383370325778,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark55(33.421812183831484,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark55(33.51364904399168,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark55(33.514353713651104,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark55(33.58145217135513,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark55(33.58410215388484,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark55(-33.59216214672421,-1.5707963267948966,-0.9999999999999996 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark55(33.66272200925009,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark55(33.66290664877756,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark55(33.74415855054152,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark55(33.750958460975205,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark55(33.79234305317003,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark55(-33.81806435102432,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark55(33.83726675744997,-1.570796326794897,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark55(3.383962706570003,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark55(33.87771588721327,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark55(3.3881317890172014E-21,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark55(33.900443575965284,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark55(33.92666942950302,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark55(33.927081593494535,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark55(33.94025395680791,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark55(-3.394186620679541,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark55(33.94321460099008,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark55(34.01551328169167,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark55(34.035984423203885,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark55(3.404097416092929,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark55(3.4175133135657383,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark55(34.31855415531791,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark55(34.49189645316778,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark55(34.52417514697825,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark55(3.4529589284555144,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark55(34.6202989933868,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark55(34.6400311857568,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark55(34.71155657294662,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark55(34.78940178365363,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark55(34.79175940691354,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark55(-34.822165229791686,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark55(34.841264156357106,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark55(34.85568543932601,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark55(34.96303625994166,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark55(35.077221893189645,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark55(35.094336974644754,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark55(-35.129144900944034,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark55(35.217214429929186,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark55(-35.22759319671503,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark55(35.24421939917775,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark55(35.281644558437876,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark55(35.30134405987802,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark55(35.3020996000582,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark55(35.31058519119695,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark55(35.32043271022013,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark55(35.377119836468125,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark55(35.45528864501683,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark55(35.4871481063378,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark55(3.552713678800501E-15,-1.5707963267948966,-47.64306167822343 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark55(-35.53013935780227,-1.5707963267948966,-21.088472170236024 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark55(35.59698609086967,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark55(35.64563490156781,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark55(35.686947016696706,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark55(-35.69413010971216,-1.5707963267948966,24.325380162194037 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark55(35.71982559651701,-1.570796326794893,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark55(-3.5751253221591055,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark55(35.75620212016098,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark55(35.75635754160008,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark55(35.84500102007333,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark55(35.93357878002717,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark55(36.00632819263427,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark55(36.065050680702484,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark55(36.140630217800265,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark55(36.15412582558812,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark55(3.616207450122311,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark55(36.30075819447728,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark55(3.630216345078456,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark55(36.466461144189495,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark55(36.483341080143134,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark55(36.52734674070426,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark55(36.59129115938258,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark55(-36.68008929141038,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark55(36.70831030659858,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark55(36.71870348662126,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark55(36.76091258587414,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark55(36.78154885026419,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark55(36.7873391047509,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark55(36.797540624879574,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark55(36.83892764047195,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark55(36.92898695922899,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark55(37.030513802316435,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark55(3.7099645120988214,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark55(37.13141964777456,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark55(37.16996036423741,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark55(37.19965370214088,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark55(37.301589826127056,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark55(37.30205161358401,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark55(-3.730325412903203,-1.5707963267948966,-0.06255256690264582 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark55(37.37725905697109,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark55(37.38010263181397,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark55(37.46521453021879,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark55(37.48664282947246,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark55(-37.54447573452949,-1.5707963267948966,14.32827284277398 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark55(3.7582122642081117,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark55(37.58821731055968,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark55(37.66147624329009,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark55(37.68225577575894,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark55(37.686356858449095,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark55(37.78785418605598,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark55(3.7964891544836235,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark55(37.96501959295628,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark55(3.8006725529715766,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark55(38.04963278281451,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark55(38.0500724856941,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark55(-38.25377723900285,-1.5707963267948966,-69.402034499573 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark55(38.30699390415526,-90.51837920436063,-95.82908064313493 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark55(38.406710739486215,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark55(38.46378255807241,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark55(38.51310336857589,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark55(38.548554890648035,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark55(38.56235960475263,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark55(-38.66776944824679,-1.5707963267948966,-0.01627219091312803 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark55(38.69884652279953,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark55(3.8719679322204805,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark55(38.825317997821664,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark55(38.835276810473154,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark55(38.94138934101164,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark55(3.896456429240823,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark55(38.9930772160317,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark55(39.05675579458432,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark55(39.130328022670284,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark55(39.14370956315193,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark55(39.16752884269862,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark55(3.9188765474580407,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark55(39.20854867751217,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark55(3.9255581380988076,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark55(39.28492592228616,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark55(-39.30896257890944,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark55(3.938019954333992,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark55(39.41773445785094,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark55(39.4510950900759,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark55(39.523442686327975,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark55(39.568189257949236,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark55(39.60944278834513,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark55(39.61384059890541,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark55(39.653469544796614,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark55(3.9744496025511182,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark55(39.810942030077484,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark55(39.85295845040709,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark55(3.986261621034771,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark55(-39.88721476212267,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark55(39.93063740624524,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark55(39.97155307800521,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark55(39.97729086680167,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark55(40.04532834907849,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark55(40.12787989804124,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark55(40.141359104788776,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark55(4.025820003240426,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark55(40.284283280922274,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark55(-4.028541888908379,44.44922171065954,-33.47041069724435 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark55(40.35564514231208,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark55(40.471059038674326,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark55(40.47967687610815,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark55(-40.48616031363032,-1.5707963267948966,3.273262821808572 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark55(40.49971769524752,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark55(40.52469375357285,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark55(-40.528797048199586,-1.5707963267948966,19.397154323628722 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark55(40.56259339292494,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark55(40.577663762758114,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark55(40.58271861286036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark55(40.690970505058665,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark55(40.787887377901896,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark55(40.82324483971229,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark55(40.8327503694283,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark55(40.91776707579629,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark55(4.092062799714736,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark55(40.92388757566255,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark55(40.9319957865649,-1.570796326794897,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark55(40.962000884146434,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark55(40.9652083062505,-52.60581294048989,-40.570424830560945 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark55(4.101729218696679,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark55(41.03172095908372,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark55(41.04734436627416,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark55(-41.072005027222325,89.14463288673386,47.753749834503736 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark55(-41.11679888355701,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark55(41.14273861566468,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark55(41.15409460256393,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark55(41.19561223570325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark55(41.198016842398026,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark55(41.221053362761154,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark55(41.237300245085066,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark55(41.24525428789776,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark55(41.45680025994865,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark55(-41.46923216345704,-1.5707963267948948,-0.043685631860310215 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark55(4.159887683535326,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark55(41.60833316182916,-1.5707963267949,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark55(41.6232959582515,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark55(41.65424724971247,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark55(41.76110582355895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark55(41.87249171468578,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark55(41.997615715502945,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark55(42.00334929108979,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark55(42.01861244884184,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark55(42.0259965523178,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark55(42.068295032513845,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark55(-42.0805628448004,-1.5707963267948966,0.013651835595899442 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark55(42.12138339970091,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark55(42.14276962539867,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark55(42.181779856616686,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark55(42.279425073942335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark55(42.3058194304123,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark55(42.3901722736847,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark55(4.249071930537655,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark55(42.5028454543287,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark55(-4.2533278185196615,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark55(42.53747950471594,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark55(42.6077804894928,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark55(42.63693749161756,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark55(4.269374415908601,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark55(42.76518980309588,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark55(42.79993936853498,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark55(42.81540054521139,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark55(42.844519876014395,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark55(42.891411974660485,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark55(42.903418817810135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark55(42.98492156743842,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark55(43.011243743074026,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark55(43.11153072478025,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark55(43.216067682430264,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark55(43.237456045115174,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark55(43.266542170291075,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark55(43.26696928385408,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark55(43.29836286221228,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark55(43.31854032272727,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark55(43.35170793444087,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark55(43.45085263567893,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark55(43.456174251042654,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark55(43.542701655673056,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark55(43.56247511627531,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark55(43.66224476181602,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark55(43.76765741620659,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark55(43.79815129150669,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark55(43.828469531982016,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark55(43.86287876731221,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark55(43.913998338551494,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark55(43.953820244850085,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark55(43.96275484179009,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark55(44.00609677563197,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark55(44.0437459286517,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark55(44.06820276010528,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark55(44.08957785320945,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark55(44.132864968859934,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark55(-44.15526696129663,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark55(44.16541500387769,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark55(44.21660583055368,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark55(44.270602283139425,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark55(44.34481163550442,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark55(44.38605289466735,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark55(44.395537033436014,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark55(44.43751997635474,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark55(44.464572000644125,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark55(44.529324206801604,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark55(44.65982365068473,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark55(44.69091157484849,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark55(44.773604181614274,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark55(44.84782147993278,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark55(44.93835143580367,14.041268415914928,28.053919921289918 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark55(-44.9464822794567,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark55(4.503509851920494,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark55(45.049592324923196,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark55(45.139030684170564,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark55(45.176589546881075,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark55(45.29871317355935,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark55(45.376639317319835,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark55(45.39186732775559,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark55(45.449154851926636,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark55(45.457219017761645,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark55(45.502177584856675,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark55(45.50875233881149,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark55(45.52869441360789,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark55(45.57384631897136,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark55(45.57856493821424,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark55(45.579149714344055,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark55(45.580309343571614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark55(-4.559546805456698,-1.5707963267948966,-0.9420795857212001 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark55(45.63094549907697,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark55(45.63373021517646,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark55(45.67270095938542,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark55(45.694816119001004,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark55(45.71820240700663,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark55(45.776691621966734,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark55(45.793818910507056,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark55(45.823404394624596,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark55(45.87039968555446,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark55(-45.88129921520166,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark55(45.90937926078081,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark55(45.937547069171785,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark55(45.957368966700145,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark55(45.96645318177951,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark55(-45.96755255606381,-1.5707963267948966,5.293955920339377E-23 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark55(45.971952370059554,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark55(45.984005048493195,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark55(4.604296986399323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark55(46.08494013167069,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark55(46.09470134637412,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark55(46.1198413843755,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark55(46.21046753547205,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark55(46.24903008955323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark55(46.25812431722566,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark55(-4.6283748277368595E-25,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark55(46.33744568278678,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark55(4.638009811936203,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark55(-46.42958699426823,-1.5707963267948966,-24.38399305121639 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark55(46.44230494446043,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark55(46.62790231664815,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark55(46.6740602956385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark55(46.67720360092167,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark55(46.679377250655065,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark55(46.681791484613356,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark55(4.671752902501794,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark55(46.72971985905201,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark55(46.7578809604076,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark55(46.792223262676,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark55(4.681574083920694,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark55(4.688024132930906,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark55(46.91537416442918,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark55(46.93546205966739,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark55(46.967216508634095,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark55(47.01422924919672,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark55(47.10166371933107,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark55(47.12301047676628,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark55(47.12992002596306,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark55(47.15489908410544,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark55(47.180860097273445,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark55(47.19534046619515,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark55(47.23515651625843,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark55(47.2432502925789,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark55(47.308550975356845,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark55(47.3180049418755,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark55(47.351264918077376,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark55(-47.37372036786488,-1.5707963267948966,1.0469621800781113 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark55(47.37772805920217,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark55(4.744235302386767,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark55(47.459609262880356,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark55(47.47498216233859,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark55(47.51848966893775,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark55(47.53688510887829,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark55(-47.541839589118524,-1.5707963267948966,0.36208929402389295 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark55(47.55991500996163,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark55(-47.62905005555909,-1.5707963267948966,68.57786773596628 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark55(47.63073656137961,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark55(47.77707901859546,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark55(47.779258366327475,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark55(47.83637256747787,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark55(47.887494417163396,63.60419526561677,55.4320989209985 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark55(4.789854819493584,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark55(47.90129631467878,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark55(-47.90131159808269,-1.5707963267948966,-0.009330214518480595 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark55(47.90256753856886,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark55(47.94674551049704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark55(47.94967215358375,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark55(47.982255420696916,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark55(48.06699217173209,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark55(48.09389804685659,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark55(48.100891759649244,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark55(48.13599080251248,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark55(48.23274105297496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark55(48.27799659613638,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark55(48.28664790144862,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark55(48.30553015251835,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark55(48.32921816341871,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark55(48.33747505359091,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark55(48.39264941571359,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark55(4.839351214279645,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark55(48.49673747677522,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark55(48.52261308124534,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark55(48.5322699205515,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark55(48.54801857393355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark55(48.583287426189905,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark55(4.864905393743439,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark55(48.65129620273786,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark55(48.70652028482036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark55(48.72682829427785,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark55(48.76023178937817,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark55(48.77220205635266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark55(4.877242841392089,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark55(48.82189778785406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark55(4.88257612312519,-1.5707963267948977,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark55(48.84428105439757,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark55(48.92495832488214,-1.5707963267949,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark55(48.93912991184006,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark55(4.896274132456966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark55(49.001661441731514,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark55(49.05308530024076,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark55(49.19207096060657,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark55(-49.22332409368537,-1.5707963267948963,6.826954917792705 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark55(49.26325187983558,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark55(-49.286020238208984,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark55(49.36061131438542,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark55(-49.3905519391403,-1.5707963267948966,0.9758163812183276 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark55(-4.943767394110978,-1.5707963267948966,-0.12536425709532384 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark55(49.54029353666533,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark55(4.972952524970324,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark55(49.793281694758484,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark55(4.980658711419721,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark55(49.814570481005255,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark55(49.83359285809434,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark55(4.993528699400883,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark55(49.99741896954624,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark55(50.03266095414945,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark55(50.1177521145411,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark55(50.12900898113486,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark55(-50.14574130589378,-1.5707963267948966,71.95489013112112 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark55(5.018515117046021E-17,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark55(50.225765963125156,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark55(50.23660502564306,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark55(50.24202653587521,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark55(50.25698831130301,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark55(50.270873612204355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark55(50.282606366579444,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark55(50.392979877609264,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark55(50.40482241318563,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark55(50.44474755667963,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark55(50.45395040608483,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark55(50.54236616335223,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark55(50.546312534215495,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark55(50.54893299794349,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark55(50.55765864039755,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark55(5.068759426327318,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark55(50.718246489642496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark55(50.73040307085844,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark55(5.078328111894171,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark55(50.79009701413506,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark55(50.84395340862571,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark55(50.89011519271146,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark55(50.937450840821526,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark55(50.9448922851882,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark55(50.97336077666222,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark55(50.98012256036645,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark55(5.105928040327055,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark55(51.07557358847288,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark55(51.168242179552216,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark55(51.209688257239705,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark55(5.128841301147334,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark55(51.3120501339443,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark55(51.32295665059253,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark55(51.36389089551063,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark55(51.42790470925684,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark55(51.45018733658176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark55(51.464549530877946,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark55(51.47353594166897,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark55(51.563606131855536,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark55(51.65199165863268,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark55(51.6957582215623,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark55(51.703625386085434,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark55(51.78839687998408,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark55(51.807456697560454,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark55(51.85937978532013,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark55(51.887609678613245,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark55(5.1893661154963,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark55(51.90104193865602,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark55(51.994131648004505,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark55(52.02504814892694,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark55(52.025544745415914,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark55(52.03172615733766,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark55(5.209674511953722,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark55(-52.10084666230763,-1.5707963267948966,-0.7670941080632514 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark55(52.11535313963962,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark55(52.12018561465225,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark55(52.12204416155902,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark55(5.212686217616252,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark55(52.16344210173314,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark55(52.22074442968281,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark55(52.274919240340964,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark55(52.29106995391322,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark55(52.34204861235091,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark55(52.350950859830164,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark55(52.3576727054005,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark55(52.36860788262059,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark55(52.41697064397334,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark55(52.44346745031078,-1.5707963267949054,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark55(52.52213444054476,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark55(52.543668750520936,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark55(52.55897562618503,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark55(52.69539055921281,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark55(52.70563187375842,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark55(52.78146499121789,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark55(52.808110785476096,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark55(52.82529893476781,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark55(52.85925663854316,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark55(52.9145358690476,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark55(52.92516987529144,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark55(52.92759997958052,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark55(52.969621112428314,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark55(53.02310146661458,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark55(53.08374929503779,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark55(53.08649283384112,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark55(53.11918349847909,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark55(53.11991681656471,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark55(53.18827178137846,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark55(5.326150940285018,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark55(5.333062279429702,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark55(53.42853305077813,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark55(53.460593083538896,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark55(53.51083480708789,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark55(53.57775802264718,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark55(53.61440683865315,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark55(53.68157288822434,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark55(53.735238128020576,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark55(53.76427658460434,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark55(5.380188888000724,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark55(53.84608371658108,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark55(53.88885155987379,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark55(53.898431831348006,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark55(-53.913075396291596,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark55(53.932093260710886,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark55(5.408426206439017,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark55(54.13000572123752,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark55(5.414124032898741,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark55(54.2783543752106,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark55(54.37868244040495,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark55(54.3944462465262,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark55(54.4104896975368,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark55(54.54112323911829,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark55(54.661096215886715,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark55(54.67612443582618,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark55(54.70626557561824,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark55(54.731488018162956,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark55(54.74452754555216,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark55(-54.75171222873882,-1.5707963267948966,-0.9740527879011371 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark55(54.79052035311648,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark55(54.80817287930195,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark55(54.82676926014599,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark55(54.93017456695181,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark55(55.04920861535962,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark55(55.19631959193964,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark55(55.2015125214325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark55(55.25598990953861,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark55(55.26429940661499,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark55(55.26914133072398,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark55(55.27487448624358,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark55(55.27958354139962,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark55(55.280990012103125,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark55(55.355176973642045,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark55(5.53703050234779,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark55(55.372222184586555,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark55(55.410665459322416,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark55(55.46535622987412,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark55(55.491258946110406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark55(-55.574881856974855,-1.5707963267948966,-0.4924345772235059 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark55(55.614369134429985,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark55(55.641528964977496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark55(55.65333922174132,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark55(-5.579073399345635,-1.5707963267948966,-22.715586217332056 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark55(55.84110893661111,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark55(55.883014033456305,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark55(55.89758413818856,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark55(55.91246214508057,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark55(55.939430875782676,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark55(55.945518959627094,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark55(55.94651127725884,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark55(55.95483587463042,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark55(55.958019907064084,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark55(55.961109306551776,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark55(5.59657525568214,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark55(56.03475728459509,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark55(56.09555795128361,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark55(56.10106959579131,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark55(56.1340514558174,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark55(56.278219298653426,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark55(56.31437416291404,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark55(5.634813364634155,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark55(56.36035552516298,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark55(5.63703093550501,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark55(5.641980484910503,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark55(56.44910192773024,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark55(56.50243876175408,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark55(56.531648313217175,-1.5707963267949,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark55(5.653242614193108,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark55(-5.6537787924013685,30.44225709295378,18.613516051717482 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark55(56.55897354062802,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark55(5.657835860889222,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark55(56.62867515664911,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark55(56.659260564146564,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark55(56.67835263172198,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark55(56.741568715428166,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark55(56.76065733594305,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark55(56.83462994356685,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark55(5.693265763557491,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark55(56.941905654132455,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark55(56.945823313641846,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark55(56.990668769547305,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark55(56.99221756122071,-78.10893032223636,-88.85826388756728 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark55(-5.7021328494487005,-1.5707963267948966,67.1905882850794 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark55(57.022486935262386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark55(57.04124323786351,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark55(57.16588477668003,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark55(-5.717677226570562,-1.5707963267948966,59.74072947124161 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark55(-57.21636439367886,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark55(5.729383417129711,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark55(57.29625507741116,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark55(57.31675326963308,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark55(57.31984548719472,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark55(-57.36845135285226,-1.5707963267948966,-1.0000000000000002 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark55(57.413482240473996,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark55(57.41961543525652,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark55(57.43804008874228,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark55(57.4708017487066,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark55(57.49087593928121,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark55(57.50116233085805,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark55(57.50858920554843,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark55(57.522982579744784,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark55(57.58489313973829,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark55(5.760731454066956,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark55(57.6338900474523,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark55(57.68476075902248,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark55(57.687748923158296,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark55(57.70419670697184,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark55(57.70936298188499,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark55(57.709883316688675,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark55(57.80542766226299,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark55(57.835908528792714,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark55(57.87083573646109,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark55(57.88801266496438,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark55(57.92349293334131,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark55(58.05529738229126,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark55(58.16741902869944,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark55(58.18830687299075,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark55(58.250181021420644,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark55(58.31403195395724,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark55(58.356064328957785,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark55(58.36107910399967,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark55(5.839796768589287,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark55(5.848445199628799,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark55(58.51386761542946,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark55(58.51564817858293,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark55(58.66068573164467,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark55(58.677651327083794,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark55(58.89985897271168,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark55(58.949468926133704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark55(59.02720815771954,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark55(59.04171556046907,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark55(59.04616499885862,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark55(59.12526407561061,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark55(5.917498296688933,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark55(59.18729828561155,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark55(59.21981012850027,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark55(59.24188614295387,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark55(-59.33897809430824,-1.5707963267949054,2459.2755529862166 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark55(59.37665327120666,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark55(59.39352911506036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark55(59.395856428918115,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark55(59.452249298818174,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark55(59.56355111681508,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark55(59.62489461279819,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark55(59.64087268876933,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark55(59.67396870988039,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark55(59.70570271598319,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark55(59.730728255606614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark55(59.759258524581654,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark55(59.765073896583175,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark55(5.97841328066529,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark55(59.845931320009186,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark55(59.89781064275923,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark55(59.91093734670065,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark55(59.92827195583723,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark55(59.941037152201204,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark55(59.96797055567234,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark55(59.97087938516751,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark55(59.97718648183053,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark55(59.996265377304525,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark55(59.99748599393243,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark55(5.9E-323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark55(60.01813059186719,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark55(6.002557996744116,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark55(60.0581222283505,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark55(60.071912970558266,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark55(6.012998324703233,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark55(60.28281339283635,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark55(60.290197086406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark55(60.30699018094376,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark55(6.037851789314772,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark55(60.39924408477306,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark55(60.429330965729285,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark55(60.441375319034876,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark55(6.049308386422711,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark55(60.49574373486861,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark55(60.51615668396214,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark55(6.055356206865277,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark55(60.567899566660664,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark55(60.600781567584406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark55(60.62469779571089,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark55(60.67955927339747,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark55(60.70223166071466,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark55(60.7220104002574,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark55(6.077661228937245,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark55(60.79254789956267,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark55(60.81765958697426,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark55(60.894254446369494,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark55(60.91185898379493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark55(60.918778955671726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark55(61.00020858888536,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark55(6.10168707720959,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark55(61.13605564752438,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark55(61.139929348179336,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark55(61.170161858848914,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark55(61.19893180400854,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark55(61.21403127645584,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark55(61.26707782530549,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark55(61.28279094897928,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark55(61.312505186705735,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark55(61.312510155580725,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark55(61.35191695113907,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark55(61.453979914407235,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark55(6.14652262522071,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark55(61.566349746682135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark55(61.67743130993154,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark55(61.76455592872749,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark55(61.765234746272,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark55(61.83423083433192,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark55(61.8522865883412,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark55(61.882416725124536,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark55(61.929670036625964,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark55(-61.93824710541591,-1.5707963267948966,-5.59012569204187E-17 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark55(62.02576532409133,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark55(62.04396374393001,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark55(62.07490553520678,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark55(62.171989273226245,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark55(62.194652419017416,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark55(6.22397857288874,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark55(62.30316216885066,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark55(6.2311887404148365,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark55(62.43173176869982,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark55(6.253844868258927,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark55(62.5426634360561,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark55(62.603047121506606,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark55(6.261479215036282,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark55(62.649452581725775,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark55(62.80009131564016,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark55(62.87827464162002,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark55(6.290613938108152,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark55(62.906707569776586,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark55(62.97606144547578,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark55(63.01314087122597,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark55(63.0151971269606,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark55(63.04544504664207,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark55(63.095648395863336,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark55(63.09748112081854,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark55(63.18937781374417,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark55(63.19548719032852,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark55(63.21126943605568,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark55(63.37193807401728,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark55(63.48263409701676,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark55(63.48573510681035,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark55(63.58274102406657,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark55(-63.734482892178775,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark55(63.83799979920529,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark55(63.92234498975722,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark55(6.393148630987728,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark55(63.93796847458131,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark55(63.94355923902597,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark55(6.396359327122859,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark55(63.96541003151279,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark55(64.01887312722869,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark55(64.03968119904705,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark55(-64.07372679992531,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark55(64.0740347849326,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark55(-64.08602059751207,-1.5707963267948966,-1.5127860292055555 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark55(64.18933916794134,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark55(6.422810658559895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark55(64.23207077534323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark55(64.2526877596415,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark55(-64.27023516094349,-1.5707963267948948,-0.424079620009595 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark55(6.4638624190112495,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark55(64.64001785494413,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark55(64.69640189580815,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark55(64.70790058691797,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark55(64.75681925590715,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark55(64.76430658487368,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark55(6.479429329051079,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark55(64.81878920657566,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark55(64.84073335442726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark55(64.86504186230856,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark55(64.90634980064598,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark55(6.495618349801731,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark55(65.02945069961476,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark55(65.05247056190893,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark55(-65.06436289838899,-1.5707963267948966,51.323778725834806 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark55(65.09324707604759,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark55(65.13421387798087,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark55(65.14427974152474,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark55(65.22066321232487,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark55(65.29898819556837,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark55(65.42598363975034,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark55(65.49117831031916,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark55(65.51682309600918,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark55(65.54573539148795,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark55(65.57088811191173,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark55(65.60383419128104,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark55(65.61474178788914,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark55(65.62228886669911,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark55(65.63574103012384,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark55(-65.64615788911277,96.30556250010503,-32.489957805806924 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark55(6.564836346044942,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark55(6.565409526778666,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark55(65.79988258865887,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark55(65.80844935407885,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark55(65.81929352151673,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark55(65.97832852035471,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark55(65.99021738346147,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark55(66.04950037918884,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark55(66.0921183198044,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark55(6.610238888225652,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark55(66.12779912993895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark55(6.620116313878344,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark55(66.33762457700566,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark55(6.639969226547976,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark55(66.48330150517783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark55(66.5176457036319,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark55(66.71767108000083,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark55(66.73728743421437,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark55(66.78211324620989,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark55(66.79019151198814,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark55(66.84564342920922,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark55(66.89552749717947,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark55(67.0067901967708,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark55(67.05984140083427,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark55(67.06691515900218,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark55(67.0729743640936,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark55(67.13463751758464,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark55(67.15553448059893,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark55(67.17635671419774,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark55(-67.2278230519685,-1.5707963267948966,0.7717652516124263 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark55(67.2819628066768,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark55(67.28466223708294,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark55(-67.337794586694,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark55(67.38440578228878,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark55(67.46538702044252,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark55(-67.56494052314122,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark55(67.56662252686745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark55(67.65267568173918,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark55(67.7053591442463,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark55(67.80349596866016,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark55(67.80450266480587,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark55(67.8561990959955,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark55(67.8587861570692,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark55(67.88311889304282,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark55(67.88775760727378,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark55(67.91179864091049,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark55(67.9385321390078,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark55(67.94089070472947,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark55(67.95117764108447,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark55(68.04208356729151,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark55(68.06672962831249,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark55(68.08968951955865,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark55(68.13269531487586,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark55(68.16696454042564,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark55(68.18665229398135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark55(6.82573654552769,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark55(68.26674469921997,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark55(68.31884437353654,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark55(68.36499320684706,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark55(68.41348358437614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark55(-68.42176355412128,-1.5707963267948966,0.9460960261642773 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark55(68.48869187407276,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark55(68.58827896299209,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark55(68.59335463548409,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark55(68.6464983755697,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark55(68.65094008360221,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark55(68.67198038483446,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark55(68.7496869978547,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark55(68.76095375086464,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark55(6.883291956135025,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark55(68.99338653443901,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark55(69.08028690383168,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark55(69.08842442721432,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark55(6.912023461860741,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark55(69.12488890361797,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark55(69.12965219157947,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark55(69.19166467541355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark55(69.20482455213318,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark55(69.30351393540236,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark55(6.938893903907228E-18,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark55(6.939075777831085,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark55(69.44097379585094,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark55(69.48474636840939,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark55(69.48597865167554,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark55(69.5048325902577,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark55(6.962846500904467,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark55(69.64733947302037,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark55(69.68740620231728,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark55(69.78690779201276,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark55(6.983840550458083,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark55(70.04171305754875,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark55(70.0530118119112,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark55(70.05472486224554,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark55(70.0589079708856,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark55(70.12484657046039,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark55(70.16557406243838,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark55(7.018467151574654,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark55(70.2184155949002,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark55(70.30985274465148,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark55(70.35118140380615,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark55(70.45763643660209,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark55(70.55578531543576,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark55(70.64430263396426,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark55(70.65680338072141,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark55(70.66327144035971,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark55(70.71518434573878,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark55(70.7304786254557,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark55(70.73529354179908,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark55(70.75999683402759,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark55(70.79258799356424,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark55(70.84056920531215,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark55(70.85872599652652,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark55(70.8628850129419,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark55(7.087403346533198,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark55(70.888491574238,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark55(70.90283680782186,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark55(70.94379392156546,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark55(70.97027991514716,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark55(-7.105427357601002E-15,-1.5707963267948966,-0.9999999999999996 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark55(71.09110338121184,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark55(71.09690163465531,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark55(7.116971461611527,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark55(71.18851131097495,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark55(71.21107051405016,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark55(71.2253382155081,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark55(-71.29156097690469,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark55(71.29923406488535,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark55(7.134266638164249,28.32506320576468,-69.22625584853199 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark55(71.35434437480163,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark55(71.39422214647405,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark55(7.140378631708288,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark55(71.44932415824854,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark55(71.48882300766584,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark55(71.4952756389966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark55(71.51855790335532,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark55(71.60079198419078,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark55(-71.6179432850517,-1.5707963267948957,1.0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark55(71.62929665371007,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark55(71.63490150891883,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark55(71.73416841450987,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark55(71.75225268047757,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark55(7.17541491618673,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark55(71.75689907344665,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark55(71.7669040070906,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark55(71.84546470603077,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark55(71.8715182931277,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark55(71.90976570529267,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark55(71.91474535803587,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark55(71.98145283667938,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark55(72.10175387138048,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark55(72.12219129338376,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark55(72.13453534518669,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark55(72.14359742460522,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark55(72.28946625046372,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark55(72.30017237344447,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark55(72.4490245186287,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark55(72.48283356419785,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark55(72.48897386761502,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark55(72.56039720053181,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark55(72.61516666364587,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark55(72.74854881937253,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark55(72.77283213967165,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark55(72.83105974491497,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark55(72.91539712572381,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark55(72.93191647325257,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark55(72.95312220151007,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark55(73.0133063041036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark55(73.05298316049583,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark55(73.10409926468381,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark55(73.11539054127749,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark55(73.1999171996346,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark55(73.20980384635344,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark55(73.21504715584824,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark55(73.2176523370714,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark55(73.23277289145973,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark55(73.24585694221696,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark55(73.27366938463459,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark55(73.2884996110595,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark55(73.29822894325808,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark55(73.3171575310128,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark55(73.32006004460173,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark55(73.34135144064389,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark55(73.3727937738994,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark55(73.39545864153587,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark55(7.341796218049584,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark55(73.44689385443182,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark55(73.46583576712288,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark55(73.6394518822218,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark55(-73.64752531592205,-1.5707963267948966,0.9541019659520096 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark55(73.65398950760417,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark55(7.369784254642925,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark55(73.76163701658913,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark55(-73.81681075481578,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark55(73.90310746432976,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark55(73.9117315299701,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark55(73.9138042283484,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark55(7.404524499193684,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark55(74.06973513766414,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark55(74.10009588278282,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark55(74.12889889976478,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark55(74.17406596166111,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark55(7.4235411813891545,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark55(74.27947656120632,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark55(74.33709751756072,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark55(74.35206537430048,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark55(74.37089451355811,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark55(7.441971187457639,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark55(7.4529228755891435,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark55(74.54471870415932,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark55(74.61731667233201,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark55(-74.6933034154021,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark55(-74.7338438066707,-1.5707963267948966,-7.272062316967862 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark55(74.76093013450358,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark55(74.83820017705017,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark55(7.489918037214466,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark55(-74.94749756911372,-1.5707963267948966,0.6815710165612257 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark55(7.4973786566595635,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark55(75.04442259748235,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark55(-75.17359437062265,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark55(75.2371633204153,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark55(75.32651288860586,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark55(75.39159506706378,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark55(7.550439914716733,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark55(75.50923554891529,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark55(75.57891346488,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark55(7.561219431804373,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark55(75.6167721686281,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark55(75.65747206899289,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark55(75.6830700205373,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark55(75.68905809061013,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark55(75.85822046651512,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark55(75.88578386642408,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark55(76.03160672506695,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark55(76.11647473693361,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark55(76.33733639101587,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark55(76.36180102558077,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark55(76.43684335034699,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark55(76.52183123753449,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark55(76.55656095384317,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark55(76.57270807608839,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark55(76.578122342662,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark55(76.58139989262511,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark55(76.58877598419309,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark55(76.59741855601268,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark55(76.62793699601488,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark55(76.73189920872453,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark55(76.7367483545503,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark55(-76.84244166212866,-1.5707963267948966,-0.9999999999999997 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark55(76.89276641991356,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark55(-7.692139462951778,-1.5707963267948966,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark55(76.93118228333361,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark55(76.97098855528688,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark55(77.07919414150791,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark55(77.12499974141815,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark55(77.18859492526744,-1.5707963267948952,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark55(77.23878944428081,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark55(77.25471349050781,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark55(-77.28219896139487,-1.5707963267948966,28.84164861093576 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark55(77.28335410892117,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark55(-77.29427638984738,-1.5707963267948974,98.30992531262596 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark55(77.35784715972139,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark55(77.38119300573514,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark55(77.46711899235564,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark55(77.50004247086738,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark55(77.52143087624023,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark55(77.60411972712441,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark55(77.65057949577704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark55(7.766604541528873,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark55(77.7055792778216,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark55(77.72150911956624,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark55(77.7585012630486,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark55(77.79503274099923,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark55(77.84180707654457,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark55(77.85480213566166,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark55(77.90433612679271,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark55(77.98749715072071,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark55(7.800522117087649,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark55(-78.03448413224949,-1.5707963267948966,0.4300976730481339 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark55(78.06185257726338,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark55(78.18272758045465,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark55(7.8213705089541365,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark55(78.22880728822155,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark55(7.825767892090923,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark55(78.26770795122805,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark55(78.32460924765553,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark55(78.38659624575311,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark55(78.39079705516848,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark55(78.44989135784874,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark55(-78.49023409669233,-1.5707963267948966,-2.841136520597292E-15 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark55(7.855658521964053,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark55(7.8595732992191385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark55(78.62917105731756,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark55(78.63267758561203,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark55(78.63715417542737,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark55(78.66201316422382,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark55(78.67033379442782,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark55(78.67576310436743,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark55(78.69516802235074,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark55(78.70940276141793,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark55(78.76934078229064,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark55(78.77916758827249,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark55(78.78780263811763,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark55(78.87046661509405,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark55(78.93515021415273,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark55(79.17175061647292,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark55(79.19187759485732,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark55(79.25687691141587,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark55(79.26560809884656,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark55(79.29204207980293,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark55(7.932854092799685,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark55(79.34761546084991,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark55(79.37101333471982,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark55(79.55054278492045,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark55(79.5700029721921,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark55(79.61196701097776,-12.173156446314252,-95.20835687944171 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark55(79.63421905023455,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark55(79.64275168459821,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark55(79.66207812303402,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark55(79.66341213545131,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark55(79.6815888093654,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark55(79.76677567660947,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark55(79.77134954123537,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark55(79.81638158655531,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark55(79.8684021647492,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark55(79.88518462572577,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark55(79.89980849056789,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark55(79.90892587948152,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark55(8.005105230649235,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark55(80.07478977560052,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark55(80.09504861357202,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark55(80.12884785678835,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark55(-80.2302190801671,-1.5707963267948983,-4.395166096481248 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark55(80.27366755666347,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark55(80.28795463416509,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark55(80.2887081773035,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark55(80.29213563648798,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark55(80.32487548344808,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark55(80.3665945948446,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark55(80.47242834310345,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark55(80.63491363926389,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark55(80.6528155851432,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark55(80.66179684932268,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark55(80.75487931202638,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark55(80.78004802507334,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark55(80.81321428305218,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark55(80.84514675134379,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark55(8.087379353002788,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark55(80.89936515822737,67.96109947862524,-30.953751973532093 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark55(80.91401530471839,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark55(80.9401801461175,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark55(-81.0723188156094,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark55(81.17481082852495,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark55(8.118866390737345E-17,-1.5707963267948966,0.3650807549241686 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark55(81.19060356644349,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark55(81.32086396555914,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark55(81.36787219364506,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark55(81.66957049276357,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark55(81.79153969620329,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark55(81.79163971620045,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark55(81.86709106908857,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark55(-81.89169028023376,-1.5707963267948966,-41.248318424874036 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark55(-81.89936315742432,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark55(81.93679251976127,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark55(81.94724491454001,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark55(81.96002096118994,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark55(81.96163687010022,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark55(81.9632236620666,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark55(8.196443648835142,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark55(81.99267018281498,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark55(81.99518440878805,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark55(82.02786448771465,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark55(82.05440301482506,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark55(82.09828673299975,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark55(82.10961189900098,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark55(82.31280429097693,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark55(82.3810801318254,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark55(82.46352150290502,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark55(8.25164161721932,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark55(8.259161935370088,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark55(82.65253222505379,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark55(-82.70427250909863,-1.5707963267948966,1.0000000000000002 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark55(82.72291835897295,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark55(-8.274489003645723,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark55(-8.283923068029296,-1.5707963267948966,0.9386298636075776 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark55(82.89934788084538,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark55(82.91859092535233,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark55(83.00068112114283,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark55(83.04739323458841,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark55(83.07711879633759,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark55(83.08074971527807,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark55(8.310769517538857,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark55(83.15991248420544,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark55(83.25242478755433,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark55(83.32260972072,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark55(83.38087506575667,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark55(83.39655531762031,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark55(83.4190804476967,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark55(83.46939413080037,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark55(83.54215183218136,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark55(8.370269070040322,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark55(83.73401956170042,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark55(83.7603051520614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark55(83.79756521486391,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark55(8.383709842894634,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark55(83.9215379502314,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark55(83.98978558301916,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark55(-84.03981494149353,-1.5707963267948966,-53.04554859261096 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark55(84.06067060859027,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark55(84.13913335756041,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark55(8.41943049312378,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark55(84.40579455142068,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark55(84.41536348997462,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark55(84.42986280590316,-1.5707963267948886,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark55(84.5493590449289,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark55(-8.461626231850246,25.923140885694536,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark55(84.62982812913266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark55(84.69692564319696,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark55(84.7523666205959,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark55(8.476508607256314,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark55(84.80354637274817,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark55(84.80523521864248,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark55(84.88279190395636,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark55(84.97902720312979,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark55(85.00563468876187,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark55(85.00875933466942,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark55(85.02552308929268,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark55(85.02941795750169,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark55(85.15694967634252,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark55(85.15811725575654,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark55(85.19890242693559,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark55(85.22882118571442,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark55(85.30204028045566,-1.570796326794898,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark55(85.38791986415708,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark55(-85.39499019128259,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark55(85.41806919599856,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark55(85.42318000493887,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark55(85.46618069183432,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark55(85.47569251954167,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark55(85.4945339128756,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark55(85.64649137489877,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark55(85.72460081822744,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark55(85.7434936691206,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark55(85.83157482138478,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark55(85.89285690120363,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark55(85.90359431229135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark55(86.07226176736887,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark55(86.07360897390572,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark55(86.09231590795054,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark55(86.13708174292677,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark55(86.16522572950184,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark55(86.22101206308346,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark55(8.641658606085386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark55(86.44440947249448,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark55(86.5117399778783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark55(86.5161500761792,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark55(8.652094037653796E-17,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark55(86.5251708984004,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark55(86.5515738105182,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark55(86.55882037501492,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark55(86.63282075755896,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark55(86.69796452962132,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark55(86.72014942226662,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark55(86.7901622687786,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark55(-86.82386462067713,-1.5707963267948966,8.470329472543003E-22 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark55(8.684625599079325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark55(86.96534559382206,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark55(87.02325318889038,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark55(87.05027938049355,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark55(87.06879626754625,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark55(87.14126035584991,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark55(87.2464163992149,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark55(87.36320265284236,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark55(87.41911511138784,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark55(-87.42389922760327,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark55(87.4389470314766,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark55(8.755907022740708,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark55(87.6318978875301,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark55(87.6706594573711,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark55(87.67406641077932,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark55(87.71199220695732,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark55(87.7507148901374,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark55(8.778328944158801,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark55(87.8455445645954,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark55(87.87299195738115,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark55(87.95264710401386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark55(87.96223683656913,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark55(87.96835127881647,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark55(87.97135430044656,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark55(87.98411058960956,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark55(88.03459417902836,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark55(88.14110302234906,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark55(88.14750572248661,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark55(88.19003281240055,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark55(8.822166007306983,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark55(88.23818890807638,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark55(88.27759712358214,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark55(88.28343310272032,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark55(88.35204932327517,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark55(8.837589468708845,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark55(-88.42664979469023,-1.5707963267948983,0.8193984360520901 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark55(88.45830702141258,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark55(-88.45877322054045,-1.5707963267948966,65.67872364001198 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark55(88.6063695329816,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark55(-88.66990791501273,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark55(88.70866638012308,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark55(8.872112479625471,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark55(8.878471163125482,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark55(88.79373031620136,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark55(88.89849954434105,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark55(88.9085374473069,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark55(88.91461084292479,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark55(88.99896388028587,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark55(89.01921149511192,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark55(89.02961782089855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark55(8.908957093216806,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark55(89.09424816347268,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark55(89.20994319789597,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark55(89.32656265540456,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark55(89.37114049960263,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark55(89.43306100440519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark55(8.9466335245771,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark55(89.74585535607451,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark55(89.7559440979793,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark55(89.79403916486152,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark55(89.821546631178,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark55(89.9095783995717,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark55(89.97744819738313,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark55(89.98954891160781,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark55(8.9E-323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark55(9.002145032259335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark55(90.02189420914132,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark55(90.15161266274033,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark55(90.24399915391731,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark55(90.25429899892802,-1.570796326794897,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark55(90.3466658765963,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark55(90.5946806486774,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark55(90.61935427768023,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark55(90.77433381099092,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark55(90.92159374434391,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark55(90.957335524431,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark55(90.98778202511045,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark55(91.04635402874453,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark55(91.1259063221561,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark55(91.13117410065166,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark55(91.14616973415019,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark55(91.28988285726251,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark55(91.30402553915648,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark55(91.40326759232532,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark55(91.40490920743578,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark55(91.44398303918103,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark55(91.58789958980117,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark55(91.60856998740866,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark55(91.61294935931448,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark55(-91.64749784445763,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark55(91.6901291747665,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark55(91.75188065187648,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark55(91.78074657166295,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark55(91.78787121901073,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark55(-91.81847352670827,-1.5707963267948966,1.0000000553767203 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark55(91.84896797303017,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark55(91.91002257473883,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark55(9.192160456586878,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark55(91.95849632920738,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark55(-9.210130912790902,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark55(92.26221586649675,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark55(9.229019224556836,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark55(92.29434891562195,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark55(92.39713948327656,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark55(92.4431615199638,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark55(92.47812991928689,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark55(92.51891298223046,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark55(92.5338749538939,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark55(92.59432989717595,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark55(92.77591342428272,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark55(9.285119972264638,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark55(92.91303880001297,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark55(92.93017395903672,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark55(9.297512965766089,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark55(93.00517864130411,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark55(93.1609830157245,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark55(93.1650071396256,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark55(93.2110484992242,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark55(93.27992094842963,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark55(-93.30267613898859,35.08185123761098,86.16526981189202 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark55(93.30618770282024,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark55(-93.34822526849825,-1.5707963267948966,-0.019050306876453135 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark55(93.38180666267166,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark55(93.46806337083203,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark55(93.58781639234354,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark55(93.65681354558465,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark55(93.73564577725071,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark55(93.77462343390746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark55(-93.84758634531907,-1.5707963267948966,0.11533686558810718 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark55(9.3860774815969,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark55(93.92780567784581,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark55(93.9308132668433,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark55(93.96613196402743,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark55(93.996031828051,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark55(94.00910479880596,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark55(94.02602857570797,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark55(94.05048285969656,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark55(94.12092622271368,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark55(-94.14107504645565,-1.5707963267948983,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark55(94.15359093194138,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark55(94.17274063999108,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark55(94.21059391889261,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark55(94.21286534171395,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark55(94.36893571967397,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark55(94.40173344578943,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark55(94.5036986812047,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark55(94.5143547303857,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark55(-9.453487550541652,-1.5707963267948966,0.011656018692088991 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark55(94.58726912926272,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark55(94.62308438378571,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark55(94.63210318827942,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark55(94.65828267086138,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark55(94.6727426070141,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark55(94.67418833830001,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark55(9.46823570325294,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark55(9.469442294658108,-12.875053634111183,-58.36909387785765 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark55(94.72242796805554,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark55(94.72772021034842,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark55(94.79897144547348,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark55(9.501498661111498,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark55(95.24361190209709,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark55(95.26653030867396,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark55(95.27651648951719,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark55(95.30519991158326,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark55(95.37625944677183,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark55(95.40799068185234,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark55(95.43819357174267,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark55(95.51151070128324,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark55(95.63281386435568,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark55(9.568296608933755E-183,-1.5707963267948966,-3.910318545279494E-149 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark55(95.70143177308915,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark55(95.78196290220694,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark55(95.81230692054828,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark55(95.82669245023459,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark55(95.84162297368718,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark55(95.89932380611428,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark55(96.0600374665441,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark55(96.08613155952122,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark55(96.14354977272131,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark55(9.616820338881382,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark55(9.619318232752263,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark55(96.23338976538801,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark55(9.634294806740584,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark55(96.3862220228578,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark55(96.40590845960023,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark55(96.51989683301164,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark55(96.57155151756587,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark55(96.6447640361686,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark55(96.69115891224183,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark55(96.70647243350707,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark55(96.71687490764796,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark55(96.72724556261733,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark55(-96.85713172976149,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark55(96.91853047511998,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark55(96.9918728384467,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark55(97.00400719852773,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark55(97.18566823548484,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark55(97.29577437522053,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark55(97.32014895073874,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark55(9.733016778571297,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark55(97.3418099361887,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark55(9.743399357293299,-11.997246356033784,39.2053539595355 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark55(97.43772847869104,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark55(97.55313027557642,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark55(97.631103684903,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark55(97.76144752195059,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark55(97.77890589009691,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark55(97.87732174013232,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark55(97.90565294229486,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark55(-97.91592362577555,-1.5707963267948966,31.15945138905701 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark55(97.94154122236625,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark55(98.005387306046,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark55(-98.03221740471396,-1.5707963267948966,0.9999999999999982 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark55(98.03302687851496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark55(98.05282493627907,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark55(98.1715947080968,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark55(98.24575697315859,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark55(98.44851209352532,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark55(98.49564934161413,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark55(98.57882126424506,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark55(99.07193882323898,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark55(-99.08794429063212,-1.5707963267948968,-1.0000000000076548 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark55(-99.20146132743868,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark55(99.20909735567248,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark55(99.35767528254486,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark55(9.939316845220107,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark55(9.940016203994887,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark55(9.942312419640306,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark55(-99.48668004856923,-1.5707963267948966,2.6324231435926E-17 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark55(99.50151621711714,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark55(-99.50965925159696,-1.5707963267948966,-1.6418147205193505E-288 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark55(99.66121589501029,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark55(99.79467342168496,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark55(-99.88764979324307,-1.5707963267948966,-1.0000000000000142 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark55(99.89857468610046,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark55(99.92065814881684,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark55(99.99670763012318,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark55(99.99999999999875,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark55(-99.99999999999999,-1.5707963267948966,-0.999999999999999 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark55(-99.99999999999999,-1.5707963267948966,-1.0 ) ;
  }
}
