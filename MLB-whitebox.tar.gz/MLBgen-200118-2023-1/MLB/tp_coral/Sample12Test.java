import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-0.26056037859570447,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-1.0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(1.0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000004,-99.26733297472666,-0.01751302445782031,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000009,-27.561059704029393,47.55164332728876,-1.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000036,-100.0,-16.294435574027972,4.6816763546921983E-97 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000036,-97.81083199849533,0.06137332048308368,0.9874213655880316 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark12(-1.000000000000007,-47.31671643581474,0.0,-0.3366073795626461 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000142,-100.0,-100.0,-0.06256442899824984 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000006010095954,-80.5396824028117,0.0,0.06255282400267306 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.000000000000007,0.0,-0.06255257250425547 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0000000000000142,0.6160236810592016,-1.000000047186695 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,-0.06209125263877888 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,-0.3626304860238273 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,0.9999999999999991 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,-100.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,-1.0000000000000413 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,11.060927544744938 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.012746620359994298,-100.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.02319420329959984,-33.99511811745877 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.026615659352928367,-1.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.0522489119472174,1.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.05643098189814947,0.06255308005325494 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.06255252560305063,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.07392406708553732,1.0000000738124841 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0750900739484458,98.2465845163376 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.3828329194840112,52.82217898506583 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.5610108021984843,-1.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.8549104230121197,31.293674388946215 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.9403132133967037,-0.009615236883044304 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.9527749216594256,-1.1871999185030521E-7 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.9712697072989981,1.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.9719398643577509,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.9905965180861194,0.06256142834713568 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.9999999999999352,-0.9999999999999861 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.9999999999999942,-1.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.9999999999999964,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.9999999999999991,1.0000000000207574 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,0.004551444906342628 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-100.0,0.9199480647603167 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-100.0,-1.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-0.022249161584999122 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-100.0,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-0.6659757678061873 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-0.9753263453687713 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,0.9999033513882969 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,1.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,-1.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,100.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0151767349262597E-115,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-2.3408381773460992E-97 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,-46.23917879015957 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,5.421010862427522E-20 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-57.4732080569264 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.819456636431001E-16,-1.0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,3.3881317890172014E-21,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-41.21207292432673,1.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0162194254282217,0.8968634640392896,-0.9562695601796581 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-11.474854823812473,0.9999999999999999,-14.15544904121433 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-11.558270400679579,-0.03879745504323484,79.7262633862712 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.2534208245105263,0.29059343642420143,-9.067441812220353E-5 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-12.741486816742363,-1.0,-1.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-14.099090385585338,1.0,0.3245426197900356 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-15.73341692710621,0.006101530630327645,-1.0000013872994873 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-16.78334896925973,-0.9999999999999982,-0.05522355302104062 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-17.285931455117396,-0.21262156438340046,-1.0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-19.36043488476392,-0.9999999999999983,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark12(-100.02241643556854,-97.79231300151258,0.0,-2185.180788883572 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-23.524400845757754,0.9999999999999964,-22.381270325986648 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-23.593562385737854,0.54699086791863,-1.0427117039961709 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-23.60169920556519,-0.32392652079605255,-80.00168236714903 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-23.71035984694882,-1.0,-0.046786095147902274 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-2.507224040142673,-1.0,-0.06351280793036246 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-25.589410408297876,0.0,-0.7406433708035127 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-2.590451333310239,-1.0,-1.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-26.62186211703545,0.011882011496968738,-0.8926000134115752 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-27.544673069319032,0.0,1.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-28.06390374063252,1.1102230246251565E-16,-9.4039548065783E-38 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-30.957540288934908,-2.7755575615628914E-17,10.974014132520708 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-31.20576957152729,-0.6700240634842245,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-31.310909007506588,-0.3859599167735126,1.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-31.732595009389474,1.0,31.59711742339269 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-32.463598324501085,-42.60198668249246,0.05885498535320161 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-3.3827155233590656,1.0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-36.56497642913249,0.9890337458365225,0.6178675211339315 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-37.52840684765566,-0.003516801668198566,1.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-38.339627438482474,-1.0,1.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-40.02997634909083,-1.0,14.396863434675794 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-41.36411150085317,-80.7331713426718,-0.9999999999999998 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-41.59719056247883,-0.014253245946015486,-1.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-42.70901762284125,-47.763526814622836,-0.7789674426233546 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-43.232314939011715,0.012647119205309492,0.06255255216992252 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-4.352834675277181,-0.9999999999999999,-1.0000007575365564 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-44.16840892794434,-0.9999999999999972,-0.1091089344798486 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-46.16461391048217,-54.77225332646924,-0.47208473913474913 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-46.23585047259118,0.9999999999999964,1.0272119990058193 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-46.59174102308768,0.0,89.98247401492874 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-49.294266025513444,0.7342443460047501,1.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-4.987176775371616,-1.0,1.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-50.41183205246298,0.9999999999999976,0.06255282857090001 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-50.52552028369167,-1.0,0.3657626341840595 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-51.322535297029184,-0.7794840305541477,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-52.727910324569294,-65.92746575817269,1.000000370326956 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-54.5116297242736,1.0,1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-54.62329340900422,1.0,-2309.18793283164 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-55.55218561446606,-95.58262160741724,-0.7801287290684361 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-5.562635030933704,-0.8972073705563707,-1.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-56.205354875138575,1.0,1.8693139024925298 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-5.630616407715003,0.0,0.006497244883316525 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-58.34699880548626,-100.0,0.017027253140863674 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark12(-1.0006030761215199,-99.55074480465952,-0.8339331218559485,-1.0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-60.86795693702887,0.24033117581164382,-1.000041752343881 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-61.11388903969303,1.0,0.0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-62.54074390665117,-0.0035854013731631967,1.000000364243871 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-63.247811060572914,0.0,1.0000000000000002 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-65.79624932105457,-1.0,71.95446115899918 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-66.78916960813358,-1.0,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-73.41357214498824,0.006080833175995744,0.20212330228517983 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-73.84257470750505,-2.7755575615628914E-17,-0.05422411720468925 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-74.28534374455332,0.010022342755457807,-9.64403155793779 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-74.39694130230482,1.0,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-75.74300084639782,1.0,-4.27812621115452E-4 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-77.4668960051109,-0.03802015142839819,0.2373478870017312 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-77.812325138892,0.0,1.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-78.4106346345799,-1.1102230246251565E-16,60.93265521572129 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-79.11784861874146,-0.044985158989242754,0.29345938968786567 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-79.69994420606287,-1.7763568394002505E-15,8.528561913202651 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-80.03752856449967,-1.0000000000000018,-1.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-81.93577139066315,-0.030570547915644897,0.05529243028196966 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-8.221138596955274,0.0,1.0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-82.62909967827169,0.175890184960549,-0.8613690688501747 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-8.44295669531028,-1.0,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-86.41417270290813,0.0,0.3623616184062911 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-89.9424196862308,-0.042448330853217864,-0.46084342877443296 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-92.45296373987568,-1.0000000000000002,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-9.385321390714024,0.029349448083300533,-1.0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-94.23891242278079,-0.038537327298178575,-1.000000000000007 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-9.604089569176598,0.0385763659716476,53.78541763559301 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-96.60725255915881,0.0324223396126071,-1.0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-97.30021835891723,0.04542822059115647,-6.225605411976745 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-97.42040661965373,-2.432601605386846,0.054122502104863114 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-99.15413760123111,0.04238305516049433,-0.0626818672547206 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-99.4556384552152,0.7492514564872654,0.9999999999999997 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark12(-10.015614607452193,-64.00697681839989,67.33487978677539,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark12(-100.54906162594091,-27.53353376665386,-1.0,-0.926483742860974 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark12(-1.0073310151867405,-43.207486623976266,-1.0,-0.3486872658983735 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark12(-10.12600417037521,-8.59353487816712,-0.2990431257466457,90.7376521423393 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark12(-10.215551472420167,-48.3332961727589,-1.0,0.05041905729127194 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark12(-1.0222448426082735,-87.3760349619249,0.02866353828937189,2.0406293819848997 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark12(-10.232400059899799,-70.96577362438629,1.3877787807814457E-17,1.000000033413243 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark12(-10.234816525504861,-65.06845949695996,0.8084916913250885,-1.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark12(-1.0321803873853679,-19.835080367067782,1.0,0.06270132264718689 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark12(-103.67354042652529,-100.0,0.47683235912998123,1.0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark12(-104.94220684097269,-99.96705705797598,-0.9592531420998308,-2193.121722007352 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark12(-1.0578217001421875,-57.68671646345476,-0.6871009585690184,0.3700730885092982 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark12(-107.21524422932687,-68.98276844735753,-19.26328318011379,-2435.0876067868508 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark12(-10.73589746630822,-54.554511888069385,5.298978653872653E-5,0.8353897353787423 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark12(-10.814330524385245,-76.32480452991483,-1.1102230246251565E-16,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark12(-108.19029356441959,-186.84705243347582,7.105427357601002E-15,2269.330548539342 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark12(-10.904649943361377,-27.156899573076164,-1.0,-74.49007196560787 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark12(-10.932945877050551,-81.27236170094318,1.0,-0.8936773793288374 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark12(-1.0944492672387156,-96.22850945688155,1.7763568394002505E-15,-0.27951785466041423 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark12(-10.945760836106171,-35.30809318544207,-5.551115123125782E-17,-1.6307517695630425E-97 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark12(-10.982361105316363,-5.710338268956887,0.0,-0.9504483055773687 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark12(-10.993236779091584,-100.0,-1.1102230246251565E-16,100.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark12(-11.047252448949264,-80.89182903641604,-0.8842931871344694,-1.0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark12(-11.076571952654774,-96.2628339494479,4.440892098500626E-16,-87.72139634925016 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark12(-11.083644032526095,-28.90305637062886,1.0,-1.0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark12(-1.115903006702099,-70.43716298073112,2.220446049250313E-16,1.0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark12(-111.69231272289201,-21.325276065871776,0.6813413874058643,-1.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark12(-11.171096229418794,-26.845314882107957,1.0,-22.62234457727719 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark12(-112.90211616885948,-39.53680901948093,-0.012592731570202092,2328.511433491366 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark12(-11.339130548363713,-40.012655808065105,-0.15433977107192354,37.43435480734638 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark12(-11.406222393001954,-44.25407078595585,0.9999999999999978,-1.0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark12(-11.516898293351591,-59.58768025658777,-0.9773681548352381,-43.12934796430957 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark12(-11.535952799043486,-21.948192758702337,-1.0,1.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark12(-11.554064067743333,-100.0,-0.005050111147037878,-1.0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark12(-11.631309552995907,-5.224735445316701,0.0,-1.0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark12(-11.685832814450066,-53.98995227041527,-63.88537926563811,1.0874473349826275 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark12(-11.797167202855022,-53.32503566435876,-47.78903722116268,0.5691874574696811 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark12(-11.81543234275681,-20.041250784517707,1.0,39.074578594472015 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark12(-11.880844965183556,-36.852922220435325,-0.039650575450976513,-73.28317655635121 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark12(-119.76317298388645,-87.99743153695339,0.0,-0.26616541966770413 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark12(-12.042456744151593,-100.0,-0.09694779112050611,0.9999999999999996 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark12(-12.049410631870238,-12.228718403854746,-0.039133773582953106,-28.176800130323308 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark12(-1.2075633729476891,-11.756364250014698,-74.0651688128882,0.3301730129649485 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark12(-12.177957856766946,-6.437742961062552,-0.025127042091090034,6.743125486729171E-5 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark12(-12.216489269960817,-97.93155415138403,0.0,0.5525260457280261 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark12(-12.411824059051128,-49.98462287764012,-0.0545275358837794,0.6129409517072071 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark12(-12.432194666376745,-25.950418534801784,-0.4313920775072262,-34.712212401757725 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark12(-12.51487632202371,-37.44015822910649,-1.0,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark12(-12.52054618622299,-52.138343707306475,0.0,0.04123571786416938 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark12(-125.45930280745384,-100.0,0.9948921429934493,1.0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark12(-12.5795118078529,-16.497129907205526,-0.22569264213544638,0.9797747610579761 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark12(-12.602368762817326,-45.24974799429616,8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark12(-12.716142049014648,-2.2847114786253093,-1.0,2.710505431213761E-20 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark12(-12.741532246445946,-44.91748278584358,0.2959647923812161,0.062166109724657304 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark12(-12.791853970521856,-38.776291235424054,-1.0,3.707944901164268 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark12(-130.48350162676797,-255.07104655419172,-1.0,2362.548544762915 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark12(-13.08717930273356,-11.343267423909525,0.052874108360585315,-1.0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark12(-13.170124501504432,-62.41981553533038,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark12(-13.18070984214674,-46.96634445538314,52.43079954923596,-0.012096493901584404 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark12(-133.62377814898048,-54.24403535725053,1.0,2326.694633020746 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark12(-13.625606526532826,-23.88182722830564,-0.00463465634904392,0.9821720043541089 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark12(-13.732429720405008,-7.942650066195991,-1.0,-15.691058760098642 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark12(-13.818710236982387,-47.47792347202829,1.0,1.0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark12(-13.82096332803569,-26.96769337676328,-1.0,1.0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark12(-13.94475366809864,-90.9489175879009,0.48721587873326055,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark12(-1.3994614956404248,-72.52068905833316,0.0443510083713225,84.60405366161271 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark12(-14.01587353357391,-84.9638448356112,-5.551115123125783E-17,0.058934998014603335 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark12(-14.074506474022636,-32.998600702289764,1.0,0.36246967970281835 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark12(-14.096587433496916,-100.0,0.6150548808325627,1.0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark12(-14.139182832861351,-100.0,0.9674407057624405,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark12(-14.23958648063907,-97.75808584662693,0.9890729201532491,16.021255931487175 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark12(-14.28000133426525,-75.39857190832285,8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark12(-1.4334581497558787,-63.47836308512836,12.09206419579315,-1.0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark12(-14.37497291029585,-199.43678652650073,0.9171527756132823,2364.632990147677 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark12(-14.41033151150188,-51.254956296719854,0.0,44.34867017301721 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark12(-14.471053623132912,-47.41796244314885,-1.0,0.03856457389915258 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark12(-14.514086126318489,-45.484162829122525,55.88354672525466,-0.12015144865632632 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark12(-14.55201726332676,-56.04181876368788,-7.19861761800415,0.0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark12(-146.1896821858042,-10.323186594681744,-0.9999999999999973,-2295.2877235108745 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark12(-1.4626459137820602,-94.00322232647181,1.0,0.7860205944480386 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark12(-14.692793966811008,-73.56393772963074,-1.0,-4.3919061076744913E-16 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark12(-14.734163302497592,-24.292367750209863,-16.398849601172017,28.330956845678884 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark12(-14.797960968372912,-69.61098406555368,0.0,76.16607649678755 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark12(-14.825196250570892,-45.35020535805916,0.9999999999999982,-65.38659289728727 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark12(-14.845933340350847,-18.844029571998043,-0.0561211614950497,-0.6359175279975983 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark12(-14.856504504928264,-77.19569525446092,0.061312645232630913,1.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark12(-14.965124763959246,-32.575035843186626,0.4935407245655272,1.0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark12(-14.965149419297358,-19.6306916004669,0.8597817165665913,0.0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark12(-15.03969234368273,-35.407507236867005,-0.060117636376897106,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark12(-150.50929505469185,-17.278522731074958,-95.99604705376757,-0.42514294261108176 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark12(-15.075267563224228,-36.23974102316712,78.38903149548088,-0.43639335421403813 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark12(-15.080155545307697,-65.37684389306308,-0.7441863605711557,-14.188899976407331 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark12(-15.085861691167597,-33.72151518663866,0.0,41.570278807133846 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark12(-1.5131512923526795,-100.0,-0.9378878459665815,7.658597910693509 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark12(-15.156901907335513,-10.808951013668034,0.0,-61.19718572832592 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark12(-1.523803881125886,-15.460999610822217,1.0,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark12(-15.330497912679473,-44.27244744650077,-22.90727384258094,1.0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark12(-15.367301631675849,-27.889297854785042,-0.06239644274506248,6.938893903907228E-18 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark12(-15.38174121766643,-67.72700249521134,0.0,0.2670355506238005 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark12(-15.454528741598807,-28.990630614968826,-25.186938442926213,-1.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark12(-154.64897435274275,-133.49097649652168,0.029266843823367736,1.0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark12(-15.545408420799234,-117.39732589829802,0.0,2368.2652433317076 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark12(-15.57769082015879,-100.0,0.7384165649118231,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark12(-15.712370326703763,-39.5826545601282,0.0010455002960186657,1.0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark12(-15.721585928174624,-89.41135646700576,-13.181183836684042,-2351.903416689851 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark12(-15.74091582284144,-83.63754242445316,-1.0,-9.908912641556354 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark12(-158.72204662029395,-64.18533802988867,0.053336841765082715,-83.05333121699745 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark12(-15.92092357939498,-51.3576028506693,-24.12325232843007,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark12(-15.953067968195006,-17.18288999263396,-0.64099771125767,-49.99906102514479 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark12(-16.000513917585522,-32.284766532917004,-61.280480494295155,-57.04702660238079 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark12(-16.00455169557955,-69.84105511710277,1.0,-1.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark12(-16.06998439305105,-53.6485943264936,1.0,-1.0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark12(-16.175681962747007,-29.885235623775728,-1.0,1.0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark12(-16.278847492886033,-100.0,-0.036393862217873,-0.06255567484641 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark12(-16.2816811171854,-100.0,-0.015504055533479999,-20.18524551976975 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark12(-16.290690370425832,-32.04472147988564,0.4724863419727319,0.9999999999999999 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark12(-16.369198887368288,-12.60927141997198,0.011513427347127441,0.5478707090664584 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark12(-16.565516954185213,-65.69577776473444,-80.66370788965426,-0.9712319918674749 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark12(-16.72257226802185,-68.1566173467,-53.22621567251875,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark12(-16.978758753968524,-1.750525403552017,-1.0,-0.2617943939427647 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark12(-16.987200635489984,-10.081122977701671,0.046280660120725084,0.0010439767583076964 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark12(-17.009934897420614,-82.24307023551836,7.105427357601002E-15,-35.591222500430725 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark12(-17.015188027643546,-90.57012953900724,0.00555988392722756,-0.45239663006184716 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark12(-17.042128745428165,-70.10628731877142,-1.0,83.10005393835533 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark12(-1.72501387616213,-100.0,0.02748769811433551,1.0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark12(-17.336623135285528,-90.56791191273169,-0.9034322503911676,-1.2769169165385637 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark12(-1.7356649571220686,-44.503532777344375,0.04605884836910737,-47.053489508575694 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark12(-17.390171508237806,-76.48789725581177,-0.041317891669339815,0.7202741179623264 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark12(-1.7530472767052954,-6.393634256972709,23.80340539402065,-0.43520772910694655 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark12(-17.552254354780914,-96.64147061151868,-0.9203169371053572,-77.10688639172855 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark12(-17.56208173711913,-65.33734682248169,67.18978445653661,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark12(-178.79222449788827,-74.60463075199891,0.057038633390729086,-1842.7147679461705 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark12(-17.985839619264222,-13.393199059255089,0.0,52.83712229125399 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark12(-1.8217971445997345,-36.025672660187965,-0.879633777579119,1.0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark12(-18.228808251247607,-50.96395256201132,41.49596089436471,-0.570131512754773 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark12(-18.291938178135503,-52.65849299950137,-0.19936312658390948,-0.9999899721005275 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark12(-18.31830327664304,-94.61402529182566,0.03625908239741003,1.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark12(-183.2170314537131,-65.0758129842734,0.02086556431190503,2258.5720571715897 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark12(-1.8328292897453053,-51.22765174138313,29.56775420486565,-0.045875404649120655 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark12(-18.501831256146716,-46.16043172492168,0.0,-4.838080661575934 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark12(-18.52259918808861,-2.736505865752229,-7.106011186307284,-1.0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark12(-18.5485942084334,-60.74301850875318,-0.11774888958318575,2331.8681019974106 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark12(-1.8562500855953878,-29.561228874429037,-0.13193410315145937,0.2495970659532234 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark12(-1.8718245639242614,-24.336517860290535,-0.968687191999837,-0.6384279260929673 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark12(-18.724237510374294,-34.29996388350661,-0.20084524766621148,0.018980583094571166 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark12(-18.731933268332746,-70.42868890653867,1.1102230246251565E-16,-0.8944842954462242 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark12(-18.73307814298564,-56.808145612732815,0.0,1.0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark12(-18.767093807821386,-80.2867380712625,-0.06156237851281221,-1.0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark12(-18.840476447335167,-23.890208357052266,-28.1511834417649,1.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark12(-18.856067721105855,-75.38789519389304,1.0,-2292.3507254561105 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark12(-18.906562047523963,-98.8885088019888,-80.59490468967209,-85.56107592397063 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark12(-18.968859152869317,-18.4141632696406,0.02890685650334194,100.0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark12(-19.201947774712597,-100.0,-0.06006467902304302,-1.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark12(-19.257230857557545,-73.88348684091048,-1.0,-8.158749766116728 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark12(-19.279739045561175,-13.446443681553395,-0.011855061748686882,0.9999806764220781 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark12(-19.291393103958356,-100.0,-100.0,0.9999999999999964 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark12(-19.328791724000343,-47.439967758926784,-0.9999999999999982,46.54400787156137 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark12(-19.467912571864403,-23.860189113095227,-0.013517801702159854,-1.0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark12(-19.574436874932275,-81.69881359233145,0.4201443599277894,-0.012500142465259465 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark12(-19.65669958290016,-13.268006394837128,0.9739018676171073,-7.269246195730227 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark12(-19.77855685842857,-1.0000000000000004,-0.02950123416554989,-1.0000100370942369 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark12(-19.800497080294274,-23.797388019109047,0.011321399746393089,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark12(-19.82923507836179,-2.2402584673165116,-12.853837977724242,-0.013344646979573493 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark12(-19.965631469878574,-53.847204108891944,0,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark12(-19.9695243180485,-31.006105341673475,1.0,43.19053361142707 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark12(-20.026852608816654,-100.0,0.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark12(-200.64790630675589,-59.414654008597694,-1.0,-2253.6888411184764 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark12(-2.0171133422283134,-81.44909658934678,-11.809657860201412,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark12(-20.188599823401773,-64.24774643534614,-0.9839357184276288,-0.9684486378408054 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark12(-20.232942929789672,-29.276684396254666,-14.543404374117713,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark12(-20.2482606476961,-85.68365938896514,-14.724181127549457,98.83244529763417 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark12(-20.304786274573495,-41.27996902931443,0.060549606840704914,0.0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark12(-20.32280526079702,-4.565672745541529,-0.8817794801316654,-0.9870867928821027 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark12(-20.39232274721153,-25.061090583782487,1.0,-0.06255256558129738 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark12(-20.58882597044033,-26.787172576606025,-0.8647431280408324,0.013447955749096543 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark12(-20.752918563155472,-50.552393809533946,-1.0,0.8560391307652986 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark12(-20.788286190277702,-55.141241097940835,-0.08447070727238401,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark12(-20.906037800131745,-56.19513791223065,0.0,0.0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark12(20.936265186798636,0,0,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark12(-21.02386290742004,-55.713315546648616,0.0,-1.0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark12(-21.066426299116657,-33.40627424930156,1.0,-80.91579454281357 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark12(-2.1107380114524545,-42.257350176392166,-0.45668042298596356,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark12(-21.113128670763544,-61.954577547786386,0.10640305551287393,24.54352844302342 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark12(-21.149573950347516,-57.561187877746555,0.12478340064163729,-1.0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark12(-21.189167677145853,-10.40274170260712,0.8777045253840339,-0.657607560125621 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark12(-21.201350398112574,-32.154120696451656,0.0,-0.16478840827284158 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark12(-21.26430356215991,-51.51106002699679,0.9066940444920844,1.0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark12(-21.343141238225797,-24.848713247323836,0.0,0.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark12(-21.451920463096908,-39.39347814277434,1.2212228685422928E-16,76.18638129654369 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark12(-2.147044432261552,-6.870919559736336,0.0,0.6563552777501321 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark12(-21.517102986015722,-4.3139966890052035,1.0,81.15818450725588 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark12(-21.523438147981242,-78.79939098858797,-1.0,1.0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark12(-21.56729166893433,-7.278164498833487,-0.5635646575011375,-0.2891797087780532 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark12(-21.679836518497112,-50.29222122515513,-29.617984517909235,-0.8363945665234495 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark12(-21.821514761296694,-65.61384927565389,-0.8790910987445554,-0.36218131876465876 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark12(-21.835615885448863,-100.0,0.0,0.9999999999998779 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark12(-21.83804985834995,-60.08832353773141,2.7755575615628914E-17,-0.17373422413307082 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark12(-21.8584276755993,-40.14177159206989,0.3026368373124768,100.0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark12(-21.863455128688983,-53.96829342999568,0.03444658475647566,0.9999999999999996 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark12(-21.878311774840228,-40.65321382205882,-0.9999999999999964,28.92338665384966 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark12(-21.89481672293776,-79.48236870135233,-170.29967666496648,-1.0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark12(-21.896789053292306,-67.27576109933872,1.0,-0.031924584652227375 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark12(-2.193286479426929,-25.213400274429763,1.0,0.9999999999999997 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark12(-2.2024829591071615,-90.64455201379411,0.9138693423760784,-0.06300319181532693 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark12(-22.055850139107154,-63.443497850287386,0.053659781674052325,0.0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark12(-2.2085967658744785,-46.6709278097428,0.03694997615589024,-1.0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark12(-22.108885401452014,-4.909304735236027,1.0,-42.25463822268899 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark12(-2.2137331920063614,-56.63025157158834,0.0,-20.6983425965536 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark12(-22.171068902382487,-46.09295397883678,-0.9999999999999964,1.0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark12(-22.21187404253273,-37.513040004166264,0.916192703971909,-1.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark12(-22.443026377285918,-6.985682776553807,-1.6046156174171491E-16,-1.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark12(-22.500038656461356,-9.271490204405204,1.0,0.6273581683059373 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark12(-2.255217852387581,-101.87937657194689,0.04139282127403948,0.9999999999999982 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark12(-22.63404506016579,-50.75411928236191,0.0,-0.9999999999999964 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark12(-22.722960619405985,-3.1731193835796145,-0.010751297053527648,-69.98212258019969 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark12(-22.74230192619396,-37.83745133382668,1.0,10.791493064573814 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark12(-22.76162449155666,-12.125918769357131,0.9440805753349896,-2246.314255582064 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark12(-22.768361360997318,-65.96359550074469,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark12(-2.280263399118562,-100.0,-0.18071196358742136,1.000000103256114 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark12(-22.803052045440328,-61.88841825956987,-35.14730738974786,-0.044001487284878155 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark12(-2.2870303560062566,-87.00768697484442,-1.0,0.0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark12(-22.959505921791965,-89.21597701613918,-21.439529163556138,1.0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark12(-22.964978910413805,-37.682822693397846,-13.117001267826382,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark12(-2.296735330012302,-29.039783469418143,1.0,1.0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark12(-22.9820395043579,-27.296262076474164,-77.47579353868488,1.0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark12(-22.985812563542904,-13.42738496741805,0.08851133540972922,0.4519731792563172 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark12(-23.13804932705058,-100.0,0.0,1.0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark12(-23.220156154098817,-56.10779002107626,0.2294926476806244,1.0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark12(-23.30349300416485,-27.71595129273541,-91.5140470436825,-69.2111469933616 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark12(-23.6021365750201,-100.0,-1.0,12.520472733135687 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark12(-23.60441696105515,-74.53866508971224,0.0,0.3573110664708792 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark12(-23.659542122595038,-31.147708118909502,-0.8965370212121897,0.999999999999998 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark12(-23.711319602807862,-66.57427730884302,1.0,-0.9999999999999991 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark12(-23.736411966347337,-39.247171047200425,0.02237310300175266,-0.053562458550488024 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark12(-23.79786957863912,-49.44674980053436,-47.66047619380768,0.03718053701886026 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark12(-23.85921470579764,-66.59737371601051,-0.8778108691594236,1.0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark12(-23.915212978107576,-31.383231571568004,-100.0,-9.617409786373543E-4 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark12(-23.94959941043811,-93.7757509153215,1.0,1.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark12(-23.973680080544117,-30.290587645891627,-2.7755575615628914E-17,1.0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark12(-24.00841572005851,-47.100305871528,1.0,-97.78071445519211 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark12(-24.04526091311242,-79.92840845708187,65.37433051993361,-0.9405398645668648 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark12(-24.311835298608486,-5.020947183990319,0.9811939207806558,-19.76236839194348 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark12(-24.549805368979488,-6.110515905650588,0.9999999999999982,0.4560458595589352 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark12(-24.60089683559387,-100.0,-0.058750086226798115,1.0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark12(-24.62055157440683,-14.408847854862355,-59.431781936823995,1.0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark12(-24.623396196695268,-53.909524310691566,-1.0,-0.9327895415983937 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark12(-24.7035338782324,-100.0,1.0,1.0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark12(-24.724847347571703,-21.32781367338111,-91.26520594216792,1.0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark12(-24.74662287685541,-15.750690485404945,0.10221408155442635,76.32593968971133 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark12(-24.7572553542835,-89.93121312629052,-63.45272456629718,71.53178113129565 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark12(-24.887322544301085,-30.80039697837485,1.0,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark12(-25.058186109091693,-45.49063214130147,44.14865695765576,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark12(-25.08433849590956,-30.398254710201826,1.0,-1.0000000000000004 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark12(-25.127509886396222,-124.52365409768318,0.0102358315664655,1.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark12(-25.13399058562459,-46.74047840410756,1.0,-1.0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark12(-25.178343879939156,-30.546527682642846,0.060905614238260804,-1.0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark12(-25.204085844857413,-82.5122876230642,-1.0,-0.03988051512164931 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark12(-25.210140703194874,-97.54230512362429,1.0,-0.024015893807289523 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark12(-2.5284886378254896,-59.94178912712593,25.887022646801057,-49.54107945625606 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark12(-25.312960697530585,-76.4712497368032,0.7197673870441728,0.9930984031690038 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark12(-25.320929431460968,-82.86989472507595,-5.551115123125783E-17,-0.9736019396597503 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark12(-25.393818768904953,-11.543529330016373,-0.03790647738707792,1.0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark12(-25.434178951922913,-64.44402887064763,0.9054774727773138,6.578292760759766 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark12(-25.47309827702664,-20.349143469080815,-0.04027620329136267,1.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark12(-25.496296034283475,-31.53112600966699,-0.7212703999430294,0.013190043979424138 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark12(-25.51822789496147,-2.2556781677604505,0,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark12(-25.575308000260463,-67.1250230667246,-1.0,0.8723776039972229 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark12(-25.586681073035166,-68.07252499706627,0.0,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark12(-25.595674474641054,-28.209249551220058,-1.0,0.0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark12(-25.602904405477478,-55.06248499716939,-53.358900971049124,0.5657760229384694 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark12(-25.741642186641897,-2.2018526705355375,1.0,1.0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark12(-25.913114795126177,-67.09654905989163,-0.05850442652881613,58.13158958915773 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark12(-2.5919840569424366,-64.09673640741534,13.3235523690755,-1.0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark12(-2.6134241124137247,-12.640071620195716,-1.0,-2140.576300647878 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark12(-26.18294701990733,-93.82440948554533,0.0,1.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark12(-26.221079143156217,-5.803295032947751,-2.8707791968243815E-5,-0.18334964720800898 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark12(-26.56885268210601,-10.05701410698438,-0.061963466133365674,-1.00254815350414 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark12(-26.709070365772362,-53.543997409858115,80.00755889360249,-1.0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark12(-26.786843992619097,-70.03255482345638,-0.005050603368262796,-1.0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark12(-2.6848949534207875,-46.94151574828734,-26.247579635923813,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark12(-2.6869577948559034,-38.95758420279838,0.916685535299384,0.0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark12(-27.012829239283736,-44.25098675219666,-0.0561809596625652,0.4043991524758981 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark12(-27.068727792655533,-30.221210526837563,-0.04555094869890694,-52.663729357143126 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark12(-27.07623750501874,-13.568879186568683,-1.0,4.273888017552116 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark12(-27.0961954589756,-47.93449816059425,-1.0,53.296716540601636 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark12(-27.228139481314656,-47.13644397953585,-71.55185568166964,83.34635941664271 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark12(-27.537810955285007,-26.671087935019326,-1.0,0.05917159942836448 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark12(-27.56881725361164,-31.43336878743868,-5.907907379596452,63.53403332304663 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark12(-27.60988833587684,-100.0,0.08707566270583555,-0.05851754395793582 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark12(-27.640077672256936,-83.08108257847033,0.0,-33.97649494268124 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark12(-27.720668158960322,-70.64693183304274,-0.9999999999999795,1.0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark12(-27.748504600141757,-39.683091940712025,84.49367974782282,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark12(-27.753814756067563,-46.17858571438089,100.0,-1.0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark12(-28.028850254847992,-66.42734586411402,1.0,-0.020314693802322453 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark12(-28.06427459658512,-100.0,0.0,0.029235993485034605 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark12(-28.10212556474436,-69.65575875054792,0.9999999999999929,-75.66945585819319 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark12(-28.1395893098375,-23.825345955721318,-0.00785734217997569,7.648872063800886 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark12(-28.2283559885106,-100.0,0.9067189553752633,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark12(-28.235291180512995,-8.26632078832862,1.5135576031077846E-4,100.0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark12(-28.492835277269137,-44.86801539587937,1.0,1.0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark12(-28.5439450770103,-89.41460165710428,0.0576311999556616,1.0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark12(-28.58137652861859,-95.295679865219,-54.59790876253815,-0.9719869046702172 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark12(-28.644990559490413,-28.617584425237588,100.0,-0.06263546246602444 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark12(-28.65889814119355,-81.89369050907094,0.9999999999999996,0.0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark12(-28.665560667043106,-14.54840382397057,0.0,-0.04716408193334991 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark12(-28.842226282107376,-16.351710358196996,-14.394923667914014,-23.540386191060065 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark12(-28.852153074007177,-2.9735488403844292,-0.2555088299498749,1.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark12(-28.94909888683934,-49.69692319046178,-55.306994784271495,1.0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark12(-2.899862416615227,-89.44329694680367,0.0075883562890860096,0.0015317071224563439 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark12(-29.04741351620268,-6.057749964067085,-0.05439632129718107,-55.99113311724475 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark12(-29.111952300189873,-32.08859280942564,0.0,-17.068088135334204 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark12(-29.142454348436786,-57.84843638750014,0.2793332788580898,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark12(-2.918043662744149,-8.843220699035713,-0.3802977513934648,-16.190255102535172 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark12(-29.18889754160643,-97.9389241343955,-0.3084981112999704,-1.0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark12(-2.931069884992853,-100.0,-1.1102230246251565E-16,-2.963923852875328E-16 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark12(-29.34151371894327,-53.54039414839788,0.4405292809876706,0.01052140209784322 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark12(-29.355690201189628,-54.4362308359687,0.341415445172047,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark12(-29.366886446002763,-100.0,0.6388129632157571,-2.967364920549937E-67 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark12(-29.40529104139528,-88.12320281068381,0.5164200592493794,0.5035575404822656 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark12(-29.44220943833804,-43.980492170431695,-0.018689973350465683,41.5178601634049 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark12(-29.517892662190263,-84.71057616343299,-60.24181237255961,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark12(-29.59864898377134,-21.85759420452325,-1.0,0.4557913325301318 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark12(-29.63676337733003,-9.787000205175941,0.2895236610324474,100.0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark12(-29.711850500971376,-42.8751789709907,-1.0,35.593445366274494 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark12(-29.71745888403831,-11.771753146079828,1.0,0.9999999999999996 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark12(-2.9723387371001344,-100.0,-0.033057531871090756,-0.12617115473481144 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark12(-29.76662882464872,-68.0843883151927,-1.0,0.7454701382895315 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark12(-2.9852329574101333,-54.0005658848699,0.0,62.027387447566866 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark12(-30.013072301290915,-1.1905488568418428,-0.19966478837028595,57.53993240050741 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark12(-30.03971350081038,-51.65292712944772,0.8738064651029382,22.478346734771307 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark12(-30.196851401762586,-33.61382459752828,0.0,45.76552208644112 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark12(-30.20259639683093,-1.2406483015337164,-0.6567328358831881,-66.26293080192511 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark12(-30.301676582758418,-23.485035605254204,-1.0,-1.0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark12(-30.47344685434392,-1.8846691079553253,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark12(-30.510689039158066,-48.623259582826954,-0.5024501100464027,-0.9435524454755391 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark12(-30.514344655331556,-4.676752488417748,-0.006135955501238054,-0.36571252062269366 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark12(-30.56718347832104,-86.72239764053833,-0.038609951149405936,0.9999999999999991 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark12(-3.060980256021954,-50.903807081793886,1.0,86.48970657229228 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark12(-30.644229138278106,-75.30090087855766,2590.4768098877307,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark12(-30.654797657410008,-1.0356913022644632,-0.3886945107538382,-1.0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark12(-3.069140942489251,-100.0,0.05376737346343241,0.03203805304765936 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark12(-30.74812937741034,-95.00568821134657,-0.03552021642123293,-0.999999999999998 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark12(-30.96434854850159,-15.230606852485636,0.0,-1.0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark12(-30.977507898951302,-20.742420254924006,0.05465148414311993,0.7731723394283767 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark12(-31.02703976464474,-97.61262898316807,-16.778085566770315,0.6896285213444315 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark12(-31.13695043425167,-79.61577957421314,1.0,-1.0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark12(-31.211908647814994,-100.0,0.0,-1.0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark12(-3.121477263775207,-6.7875710376913,1.0,-1.0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark12(-31.266446791558327,-29.39752244157521,-0.6824266407141927,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark12(-31.284587158037176,-52.31404234148973,-53.071400436576475,-8.027892698184483E-16 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark12(-31.354562614579557,-24.85711937835424,0.9999999999999999,-1.0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark12(-31.387579233786894,-6.027859334816213,-0.9999999999999991,45.64789093729332 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark12(-31.55057871236575,-5.478982889351401,4.440892098500626E-16,-1.0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark12(-31.73030190476422,-73.80982326672708,-5.245255119034499E-16,-1.0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark12(-31.88635902609138,-57.96584399215737,-0.8994389447345746,0.3349153258833756 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark12(-31.94272604282832,-32.43704138113007,-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark12(-31.94724024066354,-6.249290914375674,-1.0,-1.0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark12(-31.95377820425395,-93.64898878323325,88.81809865516942,-38.21106309974467 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark12(-3.197051492931166,-69.49856137615285,-0.11678275109342806,87.36636461975311 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark12(-3.2010383218762226,-65.42483516759748,-0.03799090978750095,-0.13145751679518614 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark12(-32.0195062778176,-52.395561713056374,-79.51813769647342,7.191470313844746 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark12(-3.2144335937985824,-22.176762700232683,0.9568993757157427,-23.69155775634315 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark12(-32.184712988088876,-17.491154773424736,-0.3172277328407862,-41.28361310512172 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark12(-32.29148158084601,-52.682693885693794,0.0,32.74216353098586 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark12(-32.38270668993917,-75.29684796472097,-19.160688578691378,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark12(-32.46471333780255,-93.55297731833228,-0.9448602632687039,-0.40493610830829696 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark12(-32.499983206393,-100.0,0.05120754677095111,0.7189572059036917 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark12(-32.67637816843138,-33.071999736414064,-16.058560553486707,-0.1765498567145246 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark12(-32.67990744497206,-30.632445966825994,34.73677037305217,-0.4443923515309436 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark12(-32.77448586983705,-16.68191323143884,0.0,-59.36953172706889 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark12(-3.2807338993553556,-7.430989858622977,0.0,0.8413931347245558 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark12(-32.81858639076728,-100.0,-43.777603304325304,-0.36212018299485366 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark12(-32.86285972902071,-11.80018163656658,0.015407670956771381,1.0002017181425142 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark12(-32.9317506703382,-89.45075551221434,-1.0000000002671965,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark12(-32.99645649425061,-99.28132448879293,-0.06211889917455768,1.0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark12(-32.998488224271576,-63.03553022761551,0.3126677655845034,1.0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark12(-33.02737746771469,-88.88906704138051,-1.0,-10.10653137893658 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark12(-33.14983080985792,-93.889566509163,35.96458260297263,-20.554867681427496 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark12(-33.241480390934775,-36.68908948228074,1.0,-0.7038569159645023 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark12(-3.366421841659537,-58.33642493520343,0.0,1.0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark12(-33.67221365663742,-15.170117891947584,-72.38343583275154,0.9741393786392581 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark12(-33.799478683567244,-44.42740712105277,0.7821757118176824,1.0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark12(-33.94564018497023,-75.89765986769643,0.04053786022318521,-53.926065475826384 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark12(-33.9807372956115,-90.45972931377177,1.0,0.0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark12(-34.21946708202245,-16.859459085718647,-1.0,-0.17578526555638874 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark12(-34.28558628484945,-53.025063327048976,-1.0,-1.0000124479982824 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark12(-34.291489828267345,-25.876202093723002,0.028039254953100036,-0.7735890188220658 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark12(-34.41630480479265,-93.86348099665065,0.02896797320350014,100.0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark12(-34.486732801892316,-77.4101907375204,1.0,-1.0000001016110158 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark12(-34.52375407259106,-39.15539041195395,-1.0,10.409405993875257 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark12(-3.460766472712464,-24.344366416099405,14.949902107228084,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark12(-34.60961967599357,-80.64421474575356,0.0,-1.0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark12(-34.674543170859494,-96.20792902012481,-1.0,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark12(-34.75736558961295,-100.0,-9.080047017936295,-1.0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark12(-34.82789919178411,-56.396412919998646,-0.9999999999999991,-0.9999999999999939 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark12(-34.89420347203519,-11.024847196477346,0.0619917603775179,-0.006358883210716371 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark12(-34.98559568221523,-77.3187983869678,0.006505114743722673,-0.9626722849579031 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark12(-35.16281166237518,-13.526300322215093,-0.015159495303709677,35.64299925865906 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark12(-35.24180056430356,-9.054907332096864,-1.0,0.01717039513221416 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark12(-35.24450428819125,-36.74081467708928,-1.0,0.9566155756257313 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark12(-35.25892924696687,-70.97824425127553,-6.264307990981753E-32,1.0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark12(-3.529424615667603,-43.56508899967561,1.0,-8.316327812515919E-112 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark12(-35.31484249330187,-35.658981972345146,-0.027939297373734018,1.0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark12(-35.67263202295865,-26.028758579884098,-0.9103327818704672,2266.547261533707 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark12(-35.69774543389961,-72.36409570641399,-64.4269003264414,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark12(-35.886727983568214,-21.791733615378032,-1.0,-0.008203065575654978 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark12(-35.95876239263632,-58.26766812853792,-0.9282598691501149,0.9885331410701268 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark12(-36.04617508757117,-68.81430936755442,0.16360098123862699,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark12(-36.12203248230812,-50.01529167247529,0.012109412902011063,-0.8961872217377687 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark12(-36.16062625940604,-32.789797668796645,2.464663547942799,-0.9986713903660971 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark12(-36.16261643309197,-73.18229860278906,0.03282994126636751,-0.021326624946644515 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark12(-36.29810685776754,-19.38265951985576,1.0,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark12(-36.386715971609576,-81.19582397993915,-0.7619093051844636,-4.394431232578728E-18 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark12(-36.44413658181931,-100.0,-0.6791603804800115,1.0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark12(-36.50040944535305,-97.68539160716465,1.0,0.0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark12(-36.56224835345706,-78.805979969311,1.0,-0.9450864633235718 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark12(-3.6696805721274544,-38.22109020296376,-5.2710989716152616E-82,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark12(-36.731145089662476,-9.518256870567516,-0.14507154936127264,-0.018613663517066836 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark12(-36.96284943477139,-100.0,0.0,-0.9999999999999982 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark12(-37.05140045853191,-55.83150869540414,-37.595890130715055,-0.10863744667569186 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark12(-37.06686091243415,-30.293775799248877,-1.0,-23.219486056444957 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark12(-37.18975352380571,-23.499435125284197,-46.027296400407344,-1.0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark12(-3.719790628261558,-100.0,0.0,6.776263578034403E-21 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark12(-37.2690321054192,-8.493225863673715,1.0,-1.0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark12(-37.28361828835846,-65.20453013234307,0.02022705704219363,1.0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark12(-37.31070019817795,-69.40657294178939,0.9999999999999539,0.7431329752716018 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark12(-3.7415355611076535,-14.091214624791434,-67.82078713279355,0.7867726372799595 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark12(-37.50913268137894,-42.160922335192524,1.1102230246251565E-16,-0.19052404288872182 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark12(-37.63495216449337,0,0,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark12(-3.7649020302568528,-15.661683535950715,-0.9716032695423134,0.34771676242288607 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark12(-37.65502610049917,-17.822784787891095,-1.0,1.00000000102328 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark12(-37.712181446299724,-29.408244784635016,0.0,-1.1704190886730496E-97 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark12(-37.757413564458886,-7.394277900041179,-0.02581942828764032,-0.018176029506616783 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark12(-37.80739204635049,-2.272152954539038,-0.9181573787188871,0.0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark12(-3.787213866785768,-147.83354920067018,-1.0,2326.320502400283 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark12(-38.021739753413044,-53.576127329077295,-1.0,0.20141955110678067 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark12(-3.8044037083826616,-52.267761387799325,0.5124158880366778,25.701965957273764 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark12(-38.11964712957227,-32.449452308336895,-54.718775508765034,0.8379364890000458 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark12(-38.12785887117825,-75.0992627296575,0.0,-1.0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark12(-38.15559643401923,-100.0,1.0,100.0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark12(-38.254017762614836,-39.5548249483337,1.0,0.3903132296168387 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark12(-3.831906323510594,-57.89014115865439,-1.0,1.0001464763934185 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark12(-38.42427788506322,-46.75992729779762,0.05153979322083033,-1.0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark12(-38.45573883506151,-17.96361160628473,1.0,-1.0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark12(-3.8501705533792534,-39.66900320717561,1.0,1.0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark12(-38.57010611904839,-58.69305201556001,-99.6203823591794,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark12(-38.57682609811266,-28.820472813703184,40.66921250238383,-0.04873765836315902 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark12(-38.742722186213605,-2.8491659459968606,-0.028394207882896857,-1.6543612251060553E-24 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark12(-38.75670757702533,-100.0,0.04204689135401834,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark12(-38.8726100170436,-99.6820710756989,1.0,-20.27572915341871 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark12(-38.88105137994669,-53.79358964304534,0.011160557755695657,-2.9955298087049296 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark12(-38.89855260471062,-19.609860078564267,-0.9999999999999978,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark12(-39.07143609262518,-93.50946432990361,0.03018037390336431,-78.29224292901188 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark12(-39.12207263867934,-2.524708808541936,0.0,-55.744470459752904 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark12(-39.19699253933243,-82.8720194716332,-0.7848359657021345,-1.0000028131480758 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark12(-39.21516749140377,-48.97165228141667,-84.14479505687532,85.16323819595058 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark12(-39.2291449773329,-100.0,-0.04753569413313283,0.0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark12(-39.38663441725821,-46.437802000854234,-0.39527794293665863,-1.0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark12(-39.39385371508923,-72.28307850929906,0.0609576252203653,36.64274392275658 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark12(-39.53210397369576,-68.48280003660064,-36.55748408699648,-0.7056696641514053 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark12(-39.654433911604514,-50.77972166594739,-0.7281332405487655,1.0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark12(-39.656838583363715,-14.85559082918372,-1.0,-73.26400397138141 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark12(-39.661184368614485,-29.12589748627497,1.0,81.5035858735573 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark12(-39.67229741934959,-95.64822997506616,0.0,-0.7505821435034277 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark12(-39.790867358130235,-26.401528734337308,66.38757723160145,-0.4331482104126172 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark12(-3.981359755569151,-84.26606802812104,0.0,1.0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark12(-39.859677253972436,-11.106349236496584,11.633638286385107,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark12(-39.89465617754799,-20.84376058638042,-1.0,-61.33783830428438 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark12(-40.078695060963014,-7.167392015665648,1.0,-1.8776498356413551 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark12(-40.082212978239866,-48.14229754952779,-0.6501000937049897,-36.033721825668316 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark12(-40.18509134188406,-60.62496271320834,-68.57634828714932,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark12(-40.352120846281615,-60.13967431495237,-0.9999999999999964,-43.25039403901112 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark12(-40.45713548181338,-175.56527791132697,-0.02883290684971873,2005.4619154977602 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark12(-40.48475953427066,-2.398084311236011,-1.0,-0.7987315332065545 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark12(-40.52814182299637,-66.97329576156591,0.10625068273958505,-1.0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark12(-40.62219081293545,-7.879927197387273,-6.953993727603873,-1.0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark12(-40.693220687751946,-55.7925408030093,-1.0,-48.14158308512097 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark12(-40.74157821387801,-55.030836314777304,-0.973545298172858,17.54613690489574 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark12(-40.7451656686096,-65.60680537707692,1.0,-0.008510881606445454 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark12(-40.765401014295094,-35.64001155627215,-0.9999999999999996,1.0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark12(-41.05745223925092,-92.58281232823119,1.0,0.0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark12(-41.07537188619882,-17.20139406566941,0.5181534904834982,0.9839656539480185 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark12(-4.111941465373215,-12.635996963918423,0.8150416846846353,-0.28540974340815883 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark12(-4.112798977501143,-52.78346884002352,0,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark12(-4.123152400441851,-12.286151485569958,1.0,0.04976866865143863 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark12(-41.29309015831994,-100.0,0.983435659000297,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark12(-4.129511376485635,-96.3606061040129,0.061017762602880554,-90.81949169798376 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark12(-41.310123225562535,-1.000000000000007,-0.03412749927886938,-46.67785547496837 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark12(-41.310821843355946,-69.07090493713835,0.008913845896312389,0.536709053243364 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark12(-4.158199080516983,-55.08734080062311,0.1748261789552621,0.011101832495255214 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark12(-41.66947004567601,-36.2042659532973,-0.9420525604098506,-1.0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark12(-4.171170530093432,-46.224229065473565,1.2767065403804019,-1.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark12(-41.72023391600389,-6.48684039532515,0.0,1.0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark12(-41.77751511728115,-54.66014706969734,0.03792762719261766,12.095872245014071 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark12(-41.836972247371996,-24.026900258622746,-78.18044073110147,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark12(-42.044940649989826,-76.20240209298765,-0.8412287433192869,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark12(-42.11280864264173,-63.536007366299806,-0.033138817441882185,-1.0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark12(-42.20877960487908,-21.823308780777943,1.0,0.9999999999999929 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark12(-42.22017754228639,-88.72118714992538,1.0,0.9999999999999986 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark12(-42.24873258629087,-100.0,-0.9973240154073213,5.8508340896672E-7 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark12(-42.28522234793972,-9.163252917098655,0.0,1.0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark12(-42.29936439886046,-26.270230023356888,1.0,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark12(-42.380334834311796,-61.44819648240936,1.0,6.938893903907228E-18 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark12(-42.60978101690402,-64.6614076923842,1.1102230246251565E-16,0.035933173366705984 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark12(-42.612263276761254,-62.760848877940944,1.0,-92.53635058455758 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark12(-42.659999556205065,-82.51669323965756,-12.280921038790808,1.0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark12(-4.283677963045372,-41.41302402089137,0.862616029455173,-63.91227114925685 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark12(-42.844515975183015,-75.04998087337242,1.0,1.232595164407831E-32 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark12(-42.87476458638469,-100.0,0.3212799637814452,-10.734359357330545 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark12(-42.94278363356845,-53.30623478883593,0.9920872173073735,0.30749458138966945 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark12(-42.99151447394047,-21.48030481217333,-93.77807239301481,-0.02037658527054958 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark12(-43.03262211056625,-21.79459024440793,-0.5394934894131439,0.7698430768777065 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark12(-43.086399801609915,-99.96831311956257,61.866598863265516,-1.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark12(-43.098499033181504,-100.0,-1.0,-2.339048199432363E-15 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark12(-43.133106743844905,-55.18730436965376,1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark12(-43.14402519189346,-19.411530472303312,0.9551296752256128,0.6591930605980366 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark12(-43.15365461772147,-22.159552544842583,-0.019920580437518116,1.0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark12(-43.18958603438011,-40.9239607583994,-0.051106367765424834,-84.58633201536367 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark12(-43.23453264376836,-23.278553890789926,-0.03652413327927588,-0.9999999999999991 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark12(-43.25328999002462,-25.89483435028319,0.9544639449073518,-0.9672099334930442 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark12(-43.28481052178756,-12.523630270953568,-36.40767136530796,-30.044871129308433 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark12(-43.493926341951294,-96.4333274072034,0.05527508665634055,1.0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark12(-43.51111625179998,-17.680305157729023,-1.0,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark12(-43.58014687646243,-39.16124204694011,0.9792891568679201,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark12(-43.698250934511954,-57.77611257369061,1.1102230246251565E-16,0.46920590670757434 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark12(-43.796069798965846,-91.49073700845787,0.9999999999999991,54.37125675839877 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark12(-43.81612712677357,-154.89350211125137,0.0,-8.343851699853448E-4 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark12(-43.93191904613482,-18.910587760401402,0.0,8.00965352293045 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark12(-44.23798079899115,-47.072066045848395,-36.439367479099104,-87.99981447296604 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark12(-44.27468256433323,-92.12775886966924,-0.0555755288302735,-0.7005616621546036 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark12(-44.31529218334211,-49.47010404951803,-1.0,0.0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark12(-44.32796448684369,-1.3364058813457043,-0.06233432496903008,1.0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark12(-44.35727921638254,-89.98470952568803,0.057396623060110896,4.9592323208510365 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark12(-44.37434209389567,-45.462740430577774,0.6970105590015713,27.99566594507497 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark12(-4.457166771451331,-46.62786014583123,-0.9176800769368871,-0.0521375659869224 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark12(-44.625145315676065,-32.30010505905485,0.6976920568782583,-15.471471669752763 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark12(-44.90366487078141,-100.0,-0.053159209223655725,0.031042869869523926 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark12(-44.99518510271085,-92.92058764019367,-19.246917089121172,-1.000000000000007 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark12(-45.00277247629516,-31.776265502878104,0.024332350371764865,60.07207174143842 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark12(-45.06702612425983,-50.56334109458344,0.9737538782004741,-1.0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark12(-45.18484574857628,-4.080597135718179,-0.9143621624834886,-1.0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark12(-45.34831263389917,-23.984017165072938,29.690167531421828,-0.04080037693458533 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark12(-45.42897330683577,-99.33060224962857,47.65595997606661,-0.9485867834261725 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark12(-4.549562396780726,-40.57935539375231,-0.9840507420723262,-0.998744794344684 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark12(-45.666471700045086,-50.10452277793542,-0.28829192340442555,-1.0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark12(-4.581595490369907,-12.672696906059436,1.0,-35.96909851485709 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark12(-45.83374023444982,-37.57897595981456,-1.0,1.0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark12(-4.586643585689077,-24.115567657714386,-1.0,-0.06191170578194316 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark12(-45.90312833099996,-63.74898532760977,1.0,1.0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark12(-45.921410128115994,-34.49037052048914,0.026181890252920226,0.46158041901916436 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark12(-46.05601568004112,-63.3938944652573,21.67859308482423,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark12(-46.1892734290557,-81.21245914630451,0.060249035121040295,-1.0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark12(-46.29846303866076,-4.044214297309276,-0.44382394781185286,1.0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark12(-46.3123195841482,-41.99070554441762,0.0,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark12(-46.3788886964532,-17.76334715757892,1.0,37.98996345972017 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark12(-46.55724930393531,-100.0,-0.021531681905173843,71.20319802664686 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark12(-4.660671898286452,-4.412943312085877,1.0,-1.0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark12(-46.75101082285441,-85.20601662500421,0.9664663724321373,-1.0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark12(-46.87319395940707,-62.36875918154101,0.0,0.0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark12(-46.873417777733174,-42.42734574416862,-0.04943944246557552,0.9999999999999929 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark12(-46.952866261771575,-22.535346018472293,-0.21051815299099721,-1.0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark12(-47.00213718060304,-18.6842350368335,-2492.842319699617,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark12(-47.02593944630513,-10.442037369217989,0.056922238767097844,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark12(-47.06174615288967,-16.628985963544896,-1.0,13.90819587129783 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark12(-47.06283032925903,-62.62329691360342,-0.9999999999999996,-66.38234523473606 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark12(-47.39327681735504,-9.211820821738627,0.9127256550845217,-2249.5859324498915 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark12(-47.40599217746384,-75.41960116206295,1.0,1.0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark12(-47.41700942173419,0,0,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark12(-47.46160048940012,-96.15254468915775,0.18911486829597374,0.036501773982894094 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark12(-47.463951288478924,-84.22842521818887,-0.9788815979997924,0.9999999999999929 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark12(-47.50033660135499,-63.951058223648936,0.05601279632926589,-0.7896475427644887 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark12(-47.54737637979514,-41.633120303022565,0.8457654792569869,1.0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark12(-47.62744564279487,-21.93139652095479,-1.0,18.8331950025513 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark12(-4.765872291561204,-43.04504245459345,0.26610681861835805,-0.6740384783777842 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark12(-47.72157573133704,-58.48474051901957,-0.9070618352855657,33.96454452954121 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark12(-4.775817885029369,-99.89597191727184,-1.0,-0.9999999999999999 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark12(-47.784457217172836,-72.2526789438365,-1.0249027393260945E-4,-2393.790281418873 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark12(-4.783716626079487,-42.63261758331494,0.011933581918628621,-1.0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark12(-47.893344423860306,-25.985118812613727,0.0,1.0000127557950858 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark12(-48.046333998272246,-82.57835533016981,-77.71614582992774,1.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark12(-48.1556233454649,-11.785257419533707,1.0,60.0225043067847 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark12(48.193546884121815,0,0,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark12(-48.217104994968885,-100.0,0.0,-0.6344179457210325 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark12(-48.25966342221773,-84.42310332038298,1.0,-86.69286575138419 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark12(-48.53734081523284,-71.4366250332042,0.2522843643793006,0.9447476901526426 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark12(-48.56351441206296,-86.92308751759232,-0.8624765466452397,-0.9656153009001626 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark12(-48.589060135987,-11.338236258638219,0.003497799083638592,0.027636284246338683 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark12(-48.748386142024415,-26.22458819705848,-86.74286244206647,50.8853860815361 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark12(-4.889732681368471,-87.61916012755265,36.814934408164774,0.0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark12(-49.31463214894261,-66.13988219518149,-52.04155787893028,-1.0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark12(-49.37008118660471,-14.466556611570482,1.0,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark12(-4.941930426915778,-39.902700115585304,-0.861324033044859,-34.34364731579596 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark12(-49.4206033927137,-24.561695262201155,0.9500777174892028,-5.0480570034522 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark12(-49.42213568333679,-13.2815741054993,-0.3457622072285569,-1.0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark12(-49.70676743402321,-44.534231386450294,-1.0,-0.9999999999999998 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark12(-49.773576269580175,-37.15782693498976,21.408796387445555,-0.9999999999999996 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark12(-49.85037691850109,-39.059827934113024,-51.467853059260314,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark12(-50.14798885043372,-65.54589257140968,-0.8843083897495987,1.0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark12(-50.16506300687859,-2.4527072495299764,-1.0,-0.32273614885211543 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark12(-50.18999439219969,-14.530994378364035,-0.008726096286924875,-0.9835551780383521 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark12(-5.019050918259602,-100.0,-0.03676605167765507,1.0000000000000067 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark12(-50.228480202251234,-44.96614778434319,50.777699723246165,-1.0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark12(-50.27835479966394,-97.59068193649776,88.62792834971086,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark12(-50.41514958345114,-77.52363105455827,0.024932084616373,-1.0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark12(-50.429651772344485,-65.22375083734643,1.0,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark12(-50.44283038841244,-45.466484595703704,0.24117743274529602,-72.20844973324606 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark12(-5.046890505597261,-81.97484258390423,-91.07920051710414,-38.856412526032315 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark12(-50.49791353444937,-47.1952862825401,-1.0,0.8228920029569488 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark12(-50.51130839106351,-3.0604799972488985,1.0,1.0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark12(-50.56047136843802,-64.86246984229729,1.0,18.700412293104932 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark12(-5.056761629626614,-11.669041483742774,-1.0,-47.45460701213406 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark12(-50.64187766331834,-40.31853104730964,34.063380376493555,-0.9896809840629581 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark12(-50.734244087094545,-21.45231038850538,0.0,0.08606816018953012 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark12(-50.91086122008243,-78.93203944757062,-1.0,-53.09537325266953 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark12(-5.091206228497946,-87.23052823756639,-0.9949850945906367,-1.0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark12(-50.936269256601555,-51.23719056749513,-0.9999999999999998,-1.0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark12(-51.02452768074499,-91.84371462380234,-0.05704929637975868,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark12(-51.08685400242227,-57.158672163214135,1.0,0.9999999999999987 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark12(-51.11092254102477,-71.88436167758721,0.0,0.3694937825464745 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark12(-51.16366139678466,-22.28076783526357,0.5994289658957935,-0.0347364388135533 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark12(-5.122118207306443,-5.98952465385041,0.0,-0.5610120782920822 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark12(-5.13752565042391,-35.2930539035011,-1.0,0.627201868544006 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark12(-51.703512782554725,-1.2021715014606968,0.0,0.959311784862911 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark12(-51.705135004597395,-14.667266027978403,-88.43467421068,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark12(-51.72312250623712,-65.32877140946562,82.21435870401115,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark12(-51.942448037576504,-94.59656252535883,-82.92747819283508,-100.0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark12(-52.02902858723247,-21.987735169733682,-5.89461743590941,0.0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark12(-52.07706009749715,-100.0,0.0,1.0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark12(-52.092525675720346,-46.88880294872415,1.0,-39.23930753615457 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark12(-52.470523704554935,-55.44635471108746,-1.0,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark12(-52.79782055291578,-15.81042122893426,1.0,-5.152184749591337 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark12(-52.824849763618,-100.0,-84.8166788103799,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark12(-52.900376718094094,-10.086325114593647,-29.430604048810938,-0.13954980537473816 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark12(-52.92711794449873,-66.79059838166897,0.6466621763518912,1.0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark12(-52.952148287748514,-79.07213347080636,-0.7199057614619235,-2.2831487857732924 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark12(-52.98186585778001,-64.9473106213814,1.0,-0.10909458808018258 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark12(-53.10786252808506,-88.67531030545639,-3.6498529244621665,1.0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark12(-53.124245102890676,-22.03891537685054,50.64626715162963,-2.202675529029497E-17 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark12(-5.314864559063547,-30.671977278378357,1.0,-53.13965099135041 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark12(-5.316459777686839,-3.8706651176619573,-0.055469502045733726,-0.5177414782042276 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark12(-5.319308126583067,-2.793791243243618,0.14316077638339664,0.0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark12(-53.49280711841384,-54.329619115023114,0.4930823446077483,0.9297878284286414 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark12(-5.355493646946213,-54.9173743334204,1.0,-0.12556242457032973 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark12(-53.71707074479252,-8.619960405532273,-0.9999999999999996,-0.0627705823534504 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark12(-53.72074108479949,-17.841567098333726,0.21699206905375684,1.0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark12(-53.77029416451565,-17.336402671080222,0.2306412784695291,-1.0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark12(-53.81212176035356,-51.55149846831431,1.0,1.0000005361233408 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark12(-53.86247458959688,-62.918914496011766,1.0,-74.39668824841883 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark12(-53.92858462118301,-38.380399807557026,-26.06913125566558,-0.05225572086098951 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark12(-54.101589939426454,-63.017104220283,-0.45836794295670025,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark12(-54.17065063039466,-100.0,0.8804871736282438,1.0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark12(-5.4232305320221315,-30.515524047212992,0.05121634923390994,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark12(-54.33224379976055,-60.531324604726734,0.9516601669450556,-3.177539732277025 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark12(-54.42287871764108,-100.0,-0.3530220000214631,-0.018839395882364385 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark12(-54.425455315069,-26.38355933026316,0.8848825291108179,0.11694366938987244 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark12(-5.443092658207963,-18.59899328745306,1.0,-1.0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark12(-54.44192444614015,-3.473665147590715,0.9778179956781505,-0.46175565896350956 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark12(-54.61937752540434,-73.93909997371807,-1.0,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark12(-54.70520172265331,-22.362261426650175,-1.1102230246251565E-16,9.113208669306196 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark12(-54.78006976045123,-35.55851870453451,0.9033662156983413,-0.20466925814280368 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark12(-54.83209262667183,-51.14553120433104,-0.022088021193632165,-6.604338370091865 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark12(-5.485202882535274,-64.70001459810652,1.0,-1.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark12(-5.485911309151241,-70.43851803397462,-20.323088048863923,-1.0000000000000009 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark12(-54.91686544710533,-9.762054703020954,1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark12(-54.958664582423026,-100.0,-100.0,-2.0590230357872116E-84 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark12(-54.986109462364,-45.848539377659556,-33.90900235717319,41.084194881475696 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark12(-55.05922827005861,-67.8849689165503,0.7261367146218373,-31.990342714860947 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark12(-55.14581494040042,-1.6369956285876608,-1.1102230246251565E-16,65.22384506286681 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark12(-55.191018050570094,-65.83313548097448,-3.6555700004778657,-74.4097644163261 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark12(-55.22084372688121,-74.45277372142483,0.2389129291909613,79.37210895910219 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark12(-55.3312218009749,-52.83043021099171,-1.0,0.6074413249941086 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark12(-55.45710364841131,-61.364855893108796,-1.0,-0.6043268721533432 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark12(-55.58920075114691,-39.830451827902685,-1.0,70.39928404190324 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark12(-55.66107098506969,-12.249805907906072,0.0,-1.0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark12(-5.579895973244262,-84.09847442183319,4.440892098500626E-16,-1.0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark12(-55.93717200247207,-15.618086993037053,1.0,-1.6082158694519961 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark12(-55.98395509401417,-27.5430444290293,-0.008709229520463976,-0.5715205941841088 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark12(-56.021458950324245,-32.65886375202646,-47.55398326185711,-1.0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark12(-56.05390295745936,-99.02906361698052,0.0,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark12(-56.077673675461796,-19.205026970148808,-49.09869168681604,99.0891279115092 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark12(-56.09357025387478,-45.068689367811096,-0.9870855829744016,33.514559876855316 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark12(-5.609819641599599,-49.88022809467451,0.2358071450873026,-0.9996220509507003 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark12(-56.15776287522405,-10.627825095286056,0.0,-42.04439412465686 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark12(-56.17901216070263,-3.436597749440253,-0.9264224185986756,0.445864205450917 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark12(-56.24351398285543,-36.21522168780042,0.0,98.60300259823694 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark12(-56.25613896355933,-10.440935576536914,1.0,0.04049336362092357 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark12(-56.268345470752124,-18.464126216499686,-0.13951676956271153,1.0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark12(-56.32815884915967,-87.0192809429924,0.7984992976790968,-59.39439445398522 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark12(-56.37765172602476,-61.73648846800192,57.430439627736405,-2457.6547168089055 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark12(-56.43194020280336,-96.04230802818945,1.0,1.0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark12(-56.46447392148737,-84.36053354302197,1.0,-70.63525436295257 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark12(-56.47395707024495,-74.2366315678812,0.9888276445098256,54.66470659006295 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark12(-56.537233225038605,-25.43256986327779,-0.9999999999999999,-0.05653208694169161 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark12(-56.55491807235807,-12.157566499186956,1.0,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark12(-56.61998696190296,-85.04721587211634,0.05475196217446763,1.0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark12(-56.62531909516058,-33.833010890457636,-0.9999999999999987,0.028564486766538787 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark12(-56.683058124336426,-24.0364705252706,1.0,1.0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark12(-56.70398434894425,-71.09189687743108,0.9398907978401745,-1.0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark12(-56.73017334304957,-11.724119541759519,0.0,51.50113328485043 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark12(-56.83971395236072,-100.0,-1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark12(-56.88250484966273,-100.0,1.0,1.0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark12(-57.08302086644663,-21.911081610363375,-60.645025403692145,-52.47867994756632 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark12(-5.711386326753329,-82.53537280862196,-0.9352196866370399,1.0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark12(-5.716835434064363,-68.42352249939232,-8.852123775394233,-0.6313266479977091 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark12(-57.17658240519877,-66.48188690060844,1.0,0.01761022541863566 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark12(-57.23576232293982,-52.29511120562324,0.03866933848810661,-37.36311031138367 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark12(-57.29249809344539,-53.41255819189834,-1.0,-76.08384280878109 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark12(-57.4135257137798,-94.00491309698916,-83.32035373887086,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark12(-57.476812859115185,-48.842789809226126,-61.62849222333118,0.42887680250257176 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark12(-57.48740895036466,-44.008815240520434,-1.0,0.20416566631578714 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark12(-57.50197817663544,-38.93758014906821,1.0,-0.11924923060816976 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark12(-57.58141337975335,-22.216313698522473,-1.1102230246251565E-16,-29.480543653438662 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark12(-57.63928449319295,-66.16756023324194,-35.19663380361757,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark12(-57.681648185003745,-91.10602581089138,1.0,8.293697546115197 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark12(-57.69773316547424,-28.394279560551425,-71.38311167227,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark12(-57.75670704968938,-92.69520845500352,-48.92404506537378,-1.0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark12(-57.79897188853211,-86.16143539867855,-0.01764020255645804,1.0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark12(-57.85375191688291,-12.48440867734617,-1.0,0.023975662549479193 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark12(-57.89394920761835,-45.37013380736465,-1.0,-55.346289395111505 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark12(-5.80871213234999,-68.74158148568162,48.42856205799735,-0.3077261586207588 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark12(-58.169075855579194,-66.04040254676923,-1.0,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark12(-58.311554322132935,-66.32063333456907,-0.9831937236110844,-6.344854593289123E-117 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark12(-58.32954429044052,-47.02646806199002,-1.1102230246251565E-16,-0.7787705654920744 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark12(-58.34459340472907,-88.65581964569361,-2.7755575615628914E-17,-40.18392374885062 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark12(-58.37435106900266,-73.84654746002096,-1.0,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark12(-58.47271947722922,-1.5683481884846842,0.011828883067829636,2296.192811458405 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark12(-5.849350463116528,-100.0,-0.547457921890552,0.0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark12(-58.51702924795691,-21.708975531368317,0.0,-49.25161895137777 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark12(-58.52165512726739,-99.68737697217327,1.3877787807814457E-17,-0.8614283143048895 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark12(-58.53508047642998,-72.42649669206087,0.9789573999264222,-73.1484391088596 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark12(-58.54381496870909,-10.993614064432835,-1.0,-1.0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark12(-5.866822097350564,-100.0,-0.034498589182980766,34.140490193333164 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark12(-58.81385114883704,-82.99805620577223,-0.8603781734761338,-19.84265127686996 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark12(-5.887384919105713,-41.49203611560358,0.03418059449321126,-1.0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark12(-5.890207247671603,-61.047669292909326,-1.0,0.19255601298712516 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark12(-59.20069492194448,-50.8553662714548,36.03959236013309,-0.011311851015990568 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark12(-59.25462979222635,-2.0144839815419573,0.0,1.0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark12(-59.25529770870051,-45.78082560565201,-0.059496767361955305,-69.58472569246054 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark12(-59.61019447213443,-99.10374439023884,-1.0,-0.5380439989155572 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark12(-59.71068595337831,-4.196995468349865,-1.0,1.0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark12(-5.9713943506203275,-40.69663738163968,0.2517133158962283,-0.002995250055534174 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark12(-59.73378620184548,-75.4429284030786,-0.010001346772995773,1.0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark12(-59.91740960775983,-95.28520345168324,-0.07577050644389961,0.0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark12(-59.9579449046392,-85.14235754542739,0.0,1.0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark12(-60.04730036288052,-62.156274621971406,0.260424927737299,-1.0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark12(-60.073923443995135,-24.234728354993308,-65.2094343503794,0.6232172940427652 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark12(-60.0849453938972,-100.0,-70.87071180934721,0.3637410506851517 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark12(-6.009246254781235,-100.0,-1.0,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark12(-60.11467359899821,-100.0,-0.8041469393811826,0.00824829730634688 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark12(-60.15560106867947,-88.5771400278316,1.0,1.0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark12(-6.028319973676421,-47.814757709845935,-0.027139514560008522,-99.96589342963604 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark12(-60.39120358033287,-72.77031196120815,-1.0,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark12(-60.4058630742812,-82.97382992861334,0.9999999999999964,100.0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark12(-60.52421068145733,-99.14854692533677,-1.0,-34.30325895260406 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark12(-60.63651117791436,-50.06589106985337,0.0,-1.0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark12(-60.7218746364808,-6.359054043450314,85.04029414418127,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark12(-6.077188063097225,-30.60764622988941,0.0,-1.0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark12(-6.079239036636096,-73.02161500151956,-2097.297779560596,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark12(-60.860292086514185,-7.86653316065995,0.022674918192112998,-0.4958995639839869 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark12(-60.86828121993329,-28.021774987445593,-87.00551171771983,-1.0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark12(-60.89355736801423,-18.040449032853477,1.0,0.038065558613261184 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark12(-61.04650888201819,-5.663655386039153,-63.21183669652608,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark12(-6.107014829704041,-45.49086801784869,0.9152372627186259,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark12(-61.11918330401371,-48.44055385295227,0.06251843173234378,1.0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark12(-6.116998440140007,-3.8012061728947617,-0.0018195316765915528,-0.015190962111678743 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark12(-6.121134014533153,-55.732786050817424,0.9778223141990151,-1.0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark12(-61.216410196658224,-76.581342022473,0.9993811537406416,1.0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark12(-61.40735620782135,-60.20445868853041,-2.220446049250313E-16,0.33075969533120764 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark12(-61.53866586663003,-43.76615524088347,-1.0,1.0344932778389524 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark12(-61.5427608559377,-65.37948147124676,0.0,4.302721437717724E-10 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark12(-61.67168165683417,-80.73435996667062,1.050344894570489,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark12(-61.858932424006504,-54.393150521360646,0.04462488443838847,1.0214833912812233 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark12(-62.03622259432488,-10.76680447284592,-0.016467962604748365,-100.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark12(-62.29238799953856,-10.244936577903916,6.776263578034403E-21,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark12(-62.313432654460144,-54.30315365120444,-0.9362421876691656,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark12(-6.233246840552702,-17.59608725521636,0.5398130711945444,-0.9430335650752633 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark12(-62.50319096975806,-37.11976003698348,0.05446969976273639,1.0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark12(-62.58724804501326,-11.29925142284506,-0.3602239156205298,-1.0000000000000018 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark12(-62.970768490727636,-21.145523541152826,0.0,41.67206416994137 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark12(-63.107820168458716,-39.05872354964108,-1.0,26.3712501756663 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark12(-63.12822530317788,-46.23509928668445,-0.9999999999999989,-0.5624710082503503 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark12(-6.319245929203107,-3.8572447031821135,1.1102230246251565E-16,-0.033190389193656356 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark12(-63.283507949347104,-15.948298902254495,-0.05956962405367766,-7.530432219276369 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark12(-63.39599544248773,-32.6375746054999,0.005882740591970723,0.9577443551686182 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark12(-63.39882662975951,-76.86088624602759,-1.0,1.0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark12(-6.341647495306503,-66.06514953630251,0,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark12(-63.42342931852882,-25.25301085230336,-1.0,-1.0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark12(-63.44685180124108,-100.0,-0.017472355200493922,0.7838737175106552 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark12(-6.3711731940741565,-3.981056991183012,-0.9888669569045502,-1.0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark12(-63.78234504042355,-19.822808641732433,-0.9999999999999991,-0.45065617158403626 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark12(-63.79785876181134,-100.0,0.42034478877672576,5.321844595819579 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark12(-64.1042126416158,-100.0,-0.959567658529697,-0.9999999999999991 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark12(-64.15691891039546,-54.05304441486534,0.20409574967754898,1.0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark12(-64.34606676302172,-7.553656512606817,0.016150937516231062,-1.0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark12(-64.39906009319773,-42.98748922562146,-0.6114004866791583,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark12(-64.48260750997959,-47.87558736927755,0.0,-0.5141617824445273 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark12(-64.61835225484789,-12.85281943960075,55.01599045216625,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark12(-64.68480410095381,-74.89669742188468,0.23920073018851085,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark12(-64.73806527828755,-81.95481617371905,0.9917944860837026,-1.0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark12(-6.4785548817809895,-84.69765215091019,0.04047643908463385,30.659063809290817 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark12(-64.91872912693061,-87.50267677748475,0.0,1.0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark12(-65.01397851601344,-34.83455970469458,-7.474941052322521,-1.0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark12(-65.17030673738336,-15.625276137791564,47.12085371054522,-8.433758354584419E-81 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark12(-65.27953322104668,-5.823946549174006,0.05479060678797154,-5.702086860557131 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark12(-65.28651762314655,-57.75963955172691,0.0,-9.498770838520159 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark12(-65.30155467712069,-17.34924971903449,-1.0,1.0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark12(-65.50335996813396,-100.0,-1.0,-0.21446353164040577 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark12(-65.59835353067477,-49.850587515667804,0.010337721675998137,1.0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark12(-65.90377311017312,-37.101207313184624,0.0,37.69038115880318 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark12(-65.95802441590395,-59.216940624161715,0.41032232860281626,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark12(-6.597292559366693,-34.58234730221534,-1.0,4.027414766915236 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark12(-6.610974410705351,-45.91774466735341,-0.058667004429464334,-53.44066920898957 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark12(-66.16907891182528,-21.705433482539462,-1.7763568394002505E-15,1.0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark12(-66.20119684219758,-5.332570924004098,1.0,-1.0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark12(-66.20249136623187,-21.19156797521203,0.0,0.8208741704345641 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark12(-66.31144559018722,-26.36669581606094,1.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark12(-66.37216330499925,-65.9122276818579,-75.46201464327295,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark12(-66.49128606299625,-1.0000000000000004,-0.9999999999999996,53.628075467640286 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark12(-66.52669448422687,-58.66277475095677,1.0,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark12(-66.60764793124746,-27.184723313320944,-0.4064522558879703,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark12(-66.61037488688547,-78.55833783699424,1.0,-1.0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark12(-66.7773784496267,-5.163780730959928,0.06029102469385246,-1.0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark12(-66.88731150743449,-79.11117785957452,0.004251645390234607,0.7542259857935072 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark12(-66.89459359816414,-48.31603594221528,-17.88473026153427,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark12(-6.689946617689225,-92.75729696819475,0.0,-0.9999999999999996 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark12(-6.693975922083498,-83.05175671166486,-1.0,-1.0000000000000009 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark12(-66.95064045299958,-97.15321579126027,-0.4060396160867965,55.01948184002069 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark12(-67.05752096215294,-23.45119840072294,0.0,-1.0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark12(-67.16979501992388,-80.72326054539249,0.08821125134007977,0.9999999999999993 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark12(-67.27854141072953,-2.2849351349498903,-1.0,1.0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark12(-67.28467325755611,-33.767947185523134,-0.9318362018317377,-0.9950274212174062 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark12(-67.31091087690967,-27.796639049237776,-27.547540043143723,0.9999999999999982 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark12(-67.31991732024689,-2.123461863782664,1.0,-0.9934586560463552 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark12(-67.36204553810668,-1.000000000000007,-0.023928568793537608,0.6484478813196068 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark12(-67.45990964591992,-33.26870787819752,15.829074137529275,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark12(-67.57446948153984,-36.38353565569961,0.0,85.65703144306568 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark12(-67.75208016227586,-100.0,-51.94076398431361,1.0000000211335265 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark12(-67.76230453932084,-28.96432481891521,0.025054593081778265,31.941080260364515 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark12(-67.86414075730964,-74.96743283033562,0.03405783787661254,-67.97344314458309 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark12(-67.88703330054967,-40.94057697977717,0.6043143271718736,-0.051757814562767734 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark12(-6.8005463951744645,-59.24363458585589,-82.14600323331096,-46.66926046824356 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark12(-68.08744215492587,-62.49902314564508,0.4511722280925345,1.0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark12(-68.24546742307928,-100.0,0.04158411606340301,-1.0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark12(-68.32216348762702,-92.49665388192034,-1.0,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark12(-68.35607478229703,-74.7176688188935,-0.7622336599834251,-36.14465871500208 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark12(-68.53894220251564,-24.00864974999527,0.42115001998316937,-1.0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark12(-68.64559085779484,-75.77987309530175,0.0,-97.25417961935402 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark12(-68.77000811191978,-73.18598491549018,0.2839281946480169,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark12(-68.81268813327249,-8.144763176945153,0.0,1.0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark12(-68.93992302611598,-79.35871192509033,0.0,79.38888227887269 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark12(-68.97263998272909,-55.156159714323685,-1.7763568394002505E-15,-0.9999999999999964 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark12(-69.12071038693647,-100.0,0.0,-1.0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark12(-69.3093146800631,-22.023799037645013,-2.634074474932995E-16,-1.0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark12(-69.3997182492134,-69.04677590446747,-0.05517709403039864,-0.8640339691284473 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark12(-69.5687700136741,-89.78132688464015,-1.0,8.470329472543003E-22 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark12(-69.57734106124354,-46.96019049139803,-1.0,1.504632769052528E-36 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark12(-69.62318124510381,-29.330914034458427,1.0,-1.0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark12(-69.6314266355831,-28.228723634259786,37.47300297061442,-0.9999999999999982 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark12(-69.63498326544976,-4.885466121605644,0.629170179732071,46.91599977003652 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark12(-69.68922565045104,-76.24669406892474,-1.0,-99.37391280625307 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark12(-6.985176549675432,-1.561749339365985,-47.90049154815109,0.9407089340666586 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark12(-69.86800017174872,-56.993071708188126,-6.938893903907228E-18,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark12(-69.87874429015478,-100.0,1.0,-0.9499216077450046 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark12(-69.91093852235663,-44.67344248517373,1.3877787807814457E-17,95.19484781904713 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark12(-69.92008955634819,-62.81457350310718,-1.0,0.9676445191304932 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark12(-70.11768618798226,-77.85114801569081,5.551115123125783E-17,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark12(-70.30613505987233,-46.067524357548244,-0.04981149728325285,-30.70002860987236 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark12(-70.4307254385666,-154.82653500783422,-0.0192442321730959,1.0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark12(-70.43826902062847,-16.256710290455395,-47.220262632756814,0.011412458155108822 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark12(-70.45528187148632,-25.111876387832787,-0.2096887706845898,-37.959059520111104 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark12(-70.48539036108593,-78.12852405352302,0.0,45.11519189976917 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark12(-70.72382004453152,-37.020917594586045,0.0,0.04740316343903411 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark12(-70.73714846320965,-36.65617030937092,1.0,-1.0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark12(-70.80942790128432,-10.188715550884018,1.0,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark12(-70.93457729902238,-64.48818871679363,-61.71175485073853,1.0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark12(-70.94083180811822,-56.19681435410023,5.551115123125783E-17,0.06435122042889496 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark12(-70.9737422231822,-66.39125099542682,0.04300618252492175,-32.22623059875771 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark12(-71.02924551685233,-71.64169915111493,-99.71882104756922,1.0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark12(-71.0297849763033,-44.56265014932408,1.0,0.8796712865088145 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark12(-71.06112612320953,-100.0,0.02029526411051759,0.7310235266783227 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark12(-71.13611542217635,-3.5808954171523255,-0.765792659056481,-1.0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark12(-71.23539109490878,-49.686466248936775,-0.05210285682281621,-0.001445969882023937 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark12(-7.136530304072483,-84.33756670944815,-74.70673957292557,0.6280843753806199 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark12(-7.1464886350830295,-22.16446469020118,-1.0,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark12(-71.46889188625111,-63.00634756522548,-0.02600013340550047,-40.03825534130952 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark12(-71.47948949919949,-6.9865668189176064,1.0,-41.3172104304217 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark12(-71.48789275487654,-100.0,0.9751100117726352,-0.9974960917431216 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark12(-7.157538308763975,-9.885877992670515,-75.77013134020893,-0.9223995026779763 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark12(-71.57743690858351,-14.113881447205515,8.881784197001252E-16,99.44921827267825 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark12(-7.175304442932024,-3.215983093157491,-0.8456857238315031,-0.9553731793165773 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark12(-71.78737747374008,-41.67931926312599,0.7248006658819521,-0.022537872422452754 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark12(-71.86941963250027,-77.26540868056674,-46.9571148331766,5.637107251932164 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark12(-71.8832640990014,-38.81912817666267,0.006849685720357901,-1.0030981563017995 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark12(-71.9412791887438,-99.99997669226609,0.4482115319608862,6.776263578034403E-21 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark12(-72.04148638402262,-51.98453584483735,65.29768733909393,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark12(-72.35733063811716,-92.52146434318921,71.35378466444558,-2366.4945816823924 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark12(-72.39084689473562,-75.02281732134114,1.0,41.595949761282895 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark12(-72.41349376135862,-46.42565545311488,-25.88478707711365,-1.0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark12(-72.68034305493362,-5.473980562669837,1.0,0.9762479158982984 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark12(-7.271999852896856,-88.6207905222208,0.1075604381650894,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark12(-73.10573569146194,-62.98323581092926,-1.3877787807814457E-17,-0.0018701708098659044 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark12(-73.23644462723377,-17.493787152292896,0.062552528363825,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark12(-7.326024248832103,-22.52065711726937,0.9606543972356396,78.66794245817232 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark12(-73.33287335009572,-100.0,1.0,-0.3630058817265931 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark12(-73.35118755349508,-1.803124329930292,0.0,-1.0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark12(-73.41931999804076,-100.0,0.05221648514131435,0.392250737732563 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark12(-73.43076755698961,-68.63385280977775,1.0,32.843359885175005 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark12(-73.48664832148626,-56.91978252219373,0.6384892056412445,-1.0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark12(-73.53478183028905,-100.0,100.0,-0.8528660374656665 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark12(-73.53599031249823,-100.0,-73.13471957056912,1.0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark12(-73.56001580891238,-57.02175465738062,0.0,3.308739648734805E-16 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark12(-73.56040022456381,-80.6989348889773,0.0,-0.0434857598247628 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark12(-73.61442719019777,-100.0,-1.0,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark12(-73.6797166625622,-32.168898401100535,-0.007453614877874147,0.02181235203265296 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark12(-73.7363939775976,-53.4533808045208,-1.0,80.45450184866652 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark12(-73.7437796638929,-13.871383913521388,-0.0046803916805693525,-0.026435205640965617 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark12(-73.76297177618743,-64.8403116029999,-0.5927178141792498,0.9971400989878707 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark12(-73.78808724459746,-20.01730654209497,1.0,1.0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark12(-73.87065083405031,-78.80902497361234,0.0,-0.4187746894468125 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark12(-73.92543979609256,-70.39640686081427,-1.0,-1.0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark12(-73.99803927464602,-40.46352840221609,0.0,-1.0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark12(-74.08032343856433,-56.87793469867409,-1.0,0.06255952126200123 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark12(-74.17477222149178,-88.7819856810079,-1.0,-44.65825639097041 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark12(-7.43788178411525,-88.1378981783073,-1.0,-0.9658329401928434 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark12(-74.38181278000383,-30.647239651534576,-85.87219756437145,1.1358565445788145 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark12(-74.51577573638522,-74.23226234485263,-44.14001062987829,-1.0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark12(-74.54304297305212,-45.75350640670207,-0.04014010835436868,-1.0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark12(-74.6238085230859,-12.40673731686202,-2.892697242928776,92.75003267741303 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark12(-74.68943568430551,1.0,0,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark12(-74.69559006058935,-71.58686777048547,0.07611243260779799,-32.82061015553349 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark12(-74.79994306343475,-43.586870816569984,-0.009346335267932826,-75.30854025681693 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark12(-74.87478437080021,-33.82990052782924,0.0,0.03714464186337825 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark12(-74.94401347626399,-93.05770941509215,83.76177970879894,-37.98051064260153 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark12(-75.10644832386912,-54.78843445520531,0.751542814241655,1.0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark12(-75.12165095353097,-98.81891331800213,-1.0,1.0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark12(-75.13035983412779,-20.34704747477521,-1.0,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark12(-75.1852238850877,-89.52257028895751,-1.0,1.0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark12(-75.19724807418626,-12.828138682182397,-1.145061234805948E-17,23.1187755111076 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark12(-75.26242810303201,-41.59580364272228,0.0,-1.0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark12(-75.26481232984173,-81.43232813942399,1.0,-73.28458453241865 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark12(-75.32205567995027,-78.17712060472803,-0.0038721228567820953,13.866139206147656 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark12(-75.32795681722273,-15.294395306469085,-71.96328803180143,-70.98761565286333 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark12(-75.37931693742993,-13.970001063467672,1.0,-0.6539343028051178 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark12(-75.38496987276423,-1.0759642341360893,-0.01926482807332758,2.4074124304840448E-35 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark12(-75.71341416109519,-87.60955747707118,-4.217935822032672,73.99226882182936 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark12(-75.79373146122697,-100.0,-0.8581431523706351,100.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark12(-76.08804459215895,-51.27405348497388,44.76133900550181,-0.5640621626950979 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark12(-76.08939548205379,-60.22091971038279,1.0,0.018708103472771576 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark12(-76.1240101732244,-186.0168964202643,0.01764895994484611,-2224.6882884097704 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark12(-76.2964946051201,-73.3298724263843,0.9709356995463431,-75.22073516208964 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark12(-76.30564450261036,-5.47689374981389,0.060820002760254954,-58.430500402493074 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark12(-76.31283296293337,-75.86940909981355,-0.999999581938528,0.361695864593999 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark12(-76.48477341880691,-65.73175662148753,-48.31983151576042,-1.0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark12(-76.55238385172339,-18.065774406748798,1.0000000000000018,1.0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark12(-76.55939318554621,-17.126618181817964,-0.49422649323493917,0.664009963480223 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark12(-7.660192246363845,-100.0,-0.03654696238500546,1.0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark12(-76.6197372926649,-59.01192987288986,1.0,2168.0013580283958 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark12(-76.77637119422486,-65.46476918862786,-0.8384319750810729,-32.75084396193975 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark12(-76.78131116596609,-16.051606216073054,0.019946381952283793,1.0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark12(-76.87534073233698,-82.72048999130809,1.0,1.0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark12(-7.693223106740774,-80.64112518091822,61.77285002974088,-1.0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark12(-77.15347772535051,-7.491870595319567,0.007945437444923865,13.89968593317701 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark12(-77.15385542326696,-88.55198585570466,-6.7059946727747075,2309.282319250635 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark12(-77.18643384661533,-21.870443941758577,0.0,1.0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark12(-77.19973215330698,-38.17707463187611,-0.023306184294718396,1.0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark12(-77.22290493391995,-33.00162171381157,-0.058787486469548844,-0.03461720598604125 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark12(-77.23093245717389,-58.574001311427324,-0.2136779483248712,0.9569011455134042 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark12(-77.36391883195203,-11.15223391718284,1.0,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark12(-77.463743747763,-79.6850257938028,-43.371721356093225,1.0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark12(-77.4779962049588,-10.75870979764344,-4.7141166211244496E-17,-1.0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark12(-77.54197128973117,-29.769015009483304,-0.032257166745419896,-99.99389938766447 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark12(-77.61612941473629,-88.73449803940727,1.0,41.85065335590002 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark12(-7.771686341344976,-7.2645133163127715,-0.18239726311204374,-1.0000000034779744 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark12(-77.92701956200392,-38.94042917204871,-1.0,0.5563637933186616 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark12(-78.01769688619385,-36.60780843925585,-0.8845308283347901,1.0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark12(-78.06501376009116,-100.0,1.0,-0.03663346429025956 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark12(-7.8170711211980635,-84.9627842466753,1.0,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark12(-78.45302915498273,-69.1225363723835,0.31548427250116984,-100.0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark12(-78.47788032001706,-48.720590907866075,-0.039156039795990596,-1.0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark12(-78.51831674804062,-18.909563458975942,-1.0,-1.0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark12(-7.853217325872276,-30.680453125708873,-0.025156277237529667,0.0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark12(-78.55114002925767,-28.2453848224879,3.552713678800501E-15,-54.32779341514997 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark12(-78.55787090156909,-51.18857245002566,-1.0,0.36995779081697755 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark12(-78.66257082525125,-63.019741898363165,-1.0,-1.0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark12(-78.6700144924034,-15.4334634010369,0.0,56.16270887932595 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark12(-78.68065364530625,-9.631438911190955,-82.52097082979424,-13.654365509162787 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark12(-78.7020980908116,-57.75734197897431,-0.8035335345146818,21.19369619536758 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark12(-78.7652946653185,-14.851059412320074,0.5877032551814585,1.0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark12(-78.82653450268118,-34.570262526695075,0.030708869288571274,-0.10450729920168556 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark12(-78.88420316565816,-78.35531295944413,0.0,0.5790585059795645 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark12(-78.89446898150028,-89.87122502453148,-1.0,-26.089822368032905 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark12(-78.9436165858221,-48.1928203438492,0.0,-0.04679270145073591 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark12(-79.00313319397478,-66.20369901213336,-1.0,0.8255423947135858 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark12(-79.09919361741325,-100.0,-0.027210967572009637,-1.0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark12(-79.31060373257056,-81.77233075499166,0.0,25.07680158282412 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark12(-79.32070641398175,-95.49728829745428,-55.602090657683846,37.66338726906875 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark12(-79.36957925199044,-82.0044901785407,-48.620749487961014,-1.0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark12(-79.48292614203638,-58.646437241307765,-7.105427357601002E-15,-0.009289037522511312 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark12(-79.57345070555732,-81.1842385219058,-1.0,44.495514492860565 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark12(-79.63520586364281,-48.45304352986653,0.9999999999999996,-0.22873258662095663 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark12(-79.64231867577995,-78.91040817611635,0.0,33.53815414303423 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark12(-79.73299394020327,-80.66135700928587,0.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark12(-79.83358497481561,-13.541439471038032,1.0000000000000107,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark12(-80.02159061448823,-54.94590360039551,-71.07169320455888,-1.0000001818317108 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark12(-80.1426804740353,-92.97419572373545,1.0,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark12(-80.24105555362237,-23.269489793828413,-0.04161872402124055,9.683985937189902 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark12(-80.28194093069278,-48.0290224959101,0.8256563018205336,-1.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark12(-80.3083719228598,-8.00792479737504,0.0,-1.0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark12(-8.03171608049554,-81.08896241065085,0.0,-30.495660449336427 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark12(-80.34404538700656,-57.52894799307464,0.0,-0.9328046580612863 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark12(-80.3540120943535,-92.72869959719048,-1.0,-1.000000000000008 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark12(-80.35516167738373,-41.250569181290544,-0.03534786296747814,38.67077396382832 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark12(-80.46297003804524,-47.3001973520211,0.023888466963308663,-12.29986678099732 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark12(-8.062179730085074,-100.0,1.0,1.0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark12(-80.68042996739086,-73.26533514789966,0.9088786352546663,-66.83648756449182 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark12(-80.85613133500976,-12.145470560250345,1.0,-1.0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark12(-80.88973628754682,-11.859030857285386,0.6035319168340525,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark12(80.98417635428567,0,0,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark12(-8.110867774507419,-70.83942852231193,1.0,46.875914665479506 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark12(-81.12919264780842,-42.49413053733574,-3.1911637992294626,0.0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark12(-81.1295206502101,-43.63229468334458,0.9999999999999982,-0.7614637013625425 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark12(-81.15592735982833,-69.0554166036095,-1.0,54.44718852863343 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark12(-81.22896257584644,-32.52528053029465,1.1102230246251565E-16,-0.0061504797513865506 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark12(-81.25329940227816,-146.9491802311957,0.7458475530159256,2299.305251398307 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark12(-81.35792881488595,-20.576136429804695,-0.9920071771509625,1.0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark12(-81.63904496445983,-34.58672357121566,-0.9051610295601885,-55.29294812856086 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark12(-81.79609205340313,-1.0,0,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark12(-81.8832139229633,-22.597181846639888,10.361248987820161,-0.024242808232829274 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark12(-81.92823748078033,-54.68182538695146,0.0,0.00378055500739437 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark12(-81.94079642172784,-14.396721743474778,-0.9306736201125663,-1.0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark12(-82.0425201558832,-15.20209725742285,1.0,0.08147333784215283 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark12(-8.212099423100177,-52.68882354112961,-1.0,66.42133274338782 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark12(-82.15153581950702,-12.294284010256398,-0.022947099754801137,-0.6548816667819914 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark12(-82.18210035935512,-33.58801014634974,-0.050696646206893375,1.0501074241170647 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark12(-82.50947448515467,-17.082102342950094,-71.37519917519745,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark12(-82.53764881980213,-65.93817103187622,0.016279419753187516,0.8657082151426716 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark12(-82.55397153518743,-12.737398078421108,0.0,0.7367441687223433 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark12(-82.55885186447071,-4.751276096013512,-1.0,1.0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark12(-82.65274693997587,-116.72976476554408,0.0,-2360.3075380065834 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark12(-8.269919932860656,-26.71755270340004,1.0,0.6877290416353463 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark12(-82.72323020651856,-56.566809169790226,0.0,-54.187956253616996 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark12(-82.91529769480583,-33.339149928127696,1.0000000000000036,-0.49457548395978446 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark12(-82.95130487072011,-15.93582135018622,-5.551115123125783E-17,1.0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark12(-83.02176676001413,-46.57225407906034,1.0,-0.08163339655436985 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark12(-83.07800492004753,-42.229590717717564,0.0,-0.5563450080894696 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark12(-83.25611199451606,-21.080831821080025,-27.65250423201276,56.89842265353079 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark12(-83.32627512532476,-49.95643192337981,-0.9867670546584549,-1.0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark12(83.40900747217296,0,0,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark12(-83.4936052490755,-55.15331521048967,-1.0,1.0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark12(-83.60291408943314,-9.76882469295504,-0.4181588104474139,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark12(-84.0034615083072,-14.051005878016909,0.0,-1.9601317252149641 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark12(-84.09525045403916,-7.841116948892534,44.25715488842363,26.627465081629182 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark12(-84.10747763976994,-37.326140490169365,-0.7002709595787746,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark12(-84.18489196225511,-27.130113898746444,-36.64307222848222,-81.77684305808356 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark12(-8.424287238482588,-28.039377233241577,0.04496308189777293,1.0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark12(-84.32453792447777,-64.51264423949064,-1.3877787807814457E-17,0.058743710575674346 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark12(-8.45509038501324,-100.0,-1.3877787807814457E-17,12.837142999509625 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark12(-84.68334059125908,-14.996526813125996,0.0,-8.338688693605427 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark12(-84.70736651683025,-33.99385725368328,0.4637776951275252,-9.374270894469175 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark12(-84.73037134800043,-1.123785093592545,-86.97524720000123,-74.51985227593474 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark12(-84.77941265299442,-49.87972480480847,-1.0,-74.96114749132515 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark12(-84.9613674942344,-36.414559057121544,-72.70609907648883,-0.6654449840765203 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark12(-85.14844412098228,-84.33434243719083,1.0,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark12(-85.18852745527367,-62.07354930154371,0.3740554753126008,6.497131103528062E-114 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark12(-85.42314832945365,-23.053578707851326,-0.05755591784949649,0.0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark12(-85.43449587856321,-92.36919658931942,1.0,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark12(-8.544141619871962,-12.886741362051252,-0.12516965234123573,0.9997919278977941 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark12(-85.52841328549339,-26.736439125210165,0.04113669450541005,-1.0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark12(-85.53914916181405,-73.24542606968338,0.016680798353323582,1.0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark12(-8.564287052818873,-63.670711240086064,-1.0,1.0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark12(-85.70845899964044,-57.347365487047796,-87.36511077675323,-30.583371499890006 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark12(-8.595744300528056,-30.818621202486277,-0.2124133584007445,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark12(-86.01066610907527,-100.0,0.0,0.9221490155358363 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark12(-86.11987735626099,-27.667121174300043,0.0,-27.468964523310948 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark12(-86.16401337220822,-100.0,0.0,8.186194466162042E-9 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark12(-86.34631033581596,-38.72414895056338,0.03383182127935011,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark12(-86.34870790004574,-78.15940661300615,1963.7048122491199,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark12(-86.35234900268176,-27.448478246065108,1.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark12(-86.47628963483733,-8.268657613437135,0.0070149814848165445,3.0319993568111823 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark12(-86.47853043909164,-69.46798270915832,0.0504157786035081,-1.0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark12(-86.5834973370676,-71.74267346635233,1.3877787807814457E-17,-77.21339251322664 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark12(-86.61022705967768,-74.63246942092441,49.613289551434754,-1.0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark12(-86.83874150067807,-100.0,0.0,0.28468528303154983 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark12(-86.86191845953415,-22.878462144785708,-1.0,-1.0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark12(-8.688706280336532,-90.41923531687584,-67.62013051288028,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark12(-87.090541974212,-7.437662579616955,1.0,-1.0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark12(-87.10478199465024,-100.0,0.0,-100.0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark12(-87.27622460463577,-98.3033614123777,-0.2873969343777816,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark12(-87.31829890221277,-83.76662236128345,0.6050544650837806,1.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark12(-87.64546491222384,-19.166108437896696,0.0,0.6799404494996304 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark12(-87.70467210837066,-44.52021860131606,-52.12477015163794,0.031209137616101196 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark12(-87.77556742758135,-2.1617983597806294,-0.6762958124655736,70.0066663810961 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark12(-87.92130241155371,-74.87563341568364,-48.898307273605425,1.041509777325969 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark12(-8.849935037373966,-49.620487298421054,1.0,-0.7984854435363564 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark12(-88.63894552580126,-19.352194828458064,-16.01458388667801,0.7302461136953688 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark12(-88.75628612575277,-1.0000000000000142,-27.321719681729327,-1.0000004484095053 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark12(-89.13374783455639,-70.35985420479754,-0.9838530975705025,-0.0327840990125335 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark12(-8.921040563675653,-85.10690702424422,1.0,-0.4884535607987541 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark12(-89.22999674133914,-70.42353883459684,-0.8377364062538153,3.7982270983039195E-65 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark12(-89.36069164881374,-18.01485686347611,0.8092168239311852,0.059294422171057015 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark12(-89.38789872319951,-70.44168913530265,-79.95975067725054,0.03733031927477515 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark12(-8.94890749998652,-86.08465424567424,0.9720338763811818,1.0000000000090583 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark12(-8.952393264934917,-93.45389990190601,-0.022263030633865588,-1.0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark12(-89.5272688760069,-71.36787768607587,1.0,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark12(-8.956484411133724,-8.362424095713276,1.1102230246251565E-16,-0.05173070271977365 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark12(-89.71267196175674,-5.686131338356575,0.13299767924542039,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark12(-89.9099454178249,-35.22816680577708,0.026834766284910744,-0.03858447561118447 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark12(-89.99904005588499,-57.22433068045287,1.0,-0.8046150102222613 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark12(-90.10514317300942,-20.17278495620249,3.945536104346985,-1.0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark12(-90.13710991830372,-45.469043757776475,-7.509503264177923,-97.01880472538038 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark12(-90.13784955932461,-5.172917203369252,0.0,1.0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark12(-90.15173404750394,-3.244313080977946,0.02788811611364243,0.0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark12(-90.29136031751204,-28.69984217670661,0.45458550985597634,0.03684930949623322 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark12(-90.46049185280489,-137.46015289385502,35.49916909228075,-0.9548213549841728 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark12(-90.5338702051532,-100.0,0.031835187924396144,-0.5074690756282454 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark12(-9.064980929435306,-72.88751131310156,-1.0,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark12(-90.94126331603808,-18.18900940507799,3.57852575144089E-16,-100.0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark12(-91.01449704790953,-64.64002956159838,-0.4326563805355059,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark12(-91.05411337720369,-17.154694355120988,-1.0,0.003942903421556579 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark12(-91.14644849361255,-60.13764327621593,-0.3856977843961078,-69.06639110441478 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark12(-91.16545768689595,-100.0,1.0,1.8367099231598242E-40 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark12(-91.24243244338173,-11.753201686485042,0.060367784692158866,72.44171057143208 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark12(-91.38967803858512,-25.80614021981972,1.0,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark12(-91.43836369719358,-32.788714617949125,0.0,1.0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark12(-91.48178640482038,-64.98864695519579,0.0,-13.231959373026708 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark12(-91.65201144449934,-64.97641491511784,3.6783139288777034,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark12(-91.66436007538064,8.244174974620378,0,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark12(-91.68213197641506,-3.7302072009942955,-0.0519671244970022,0.1582773103725844 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark12(-91.71859453054496,-75.63996335822384,0.0,-1.0000000252666403 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark12(-91.86829645777084,0.7076886241141409,0,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark12(-92.05593432310812,-48.484252545763226,-58.472348414569055,32.669533733340586 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark12(-92.09836436880522,-19.57972224973266,1.0,86.28305965133367 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark12(-92.10823604310379,-57.357807777611484,8.881784197001252E-16,-0.8358601892994333 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark12(-92.22020342841665,-30.64948096551487,1.0,-4.515802274639611 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark12(-92.30923372914654,-9.570029431671117,0.05108532921531865,5.2710989716152616E-82 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark12(-92.40038770377367,-9.547048164070304,-60.81760120015123,-32.80276326305113 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark12(-9.248284206730503,-72.00072823878888,-42.674423983295256,1.0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark12(-92.48722827120727,-64.46302778761815,-0.5213928722216411,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark12(-92.60531859087189,-34.70274252327479,0.8633563409899981,-1.0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark12(-92.6197495239329,-78.53833545662879,-1.0,-1.0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark12(-92.6512490082416,-100.0,0.9898730558678318,-0.9997562647537073 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark12(-92.84997572077303,-63.06725716072136,0.48757958875320373,-1.0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark12(-93.00565858776906,-75.88794841869122,-0.2866547554649663,1.0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark12(-93.10553012620396,-100.0,1.0,1.0000012661676763 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark12(-93.17484047585545,-76.79715367792268,-21.69038126548513,73.06636819348171 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark12(-9.333029901968843,-80.18115981001839,-62.2547723963971,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark12(-93.45439133672794,-2.414215593314102,-0.0561526017197774,100.0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark12(-93.95190208658843,-73.95205856116236,0.3625099389642181,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark12(-94.04638435559325,-60.22505571012753,-0.06201821697160314,100.0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark12(-94.21481950929072,-28.451132507169888,0.00442429726670591,1.0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark12(-94.63223021563948,-49.76545764289372,0.9216238752060724,6.794721861651155 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark12(-94.69729722146175,-36.63797568242295,-0.9615640858683787,1.4325034825726224 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark12(-95.02187559828867,-55.465744098346015,-74.76565711368568,65.2138613155567 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark12(-95.15812816658509,-46.93454702398383,-1.0,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark12(-95.21484873909844,-35.11581455132338,-0.9215308724158962,18.48878788487957 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark12(-9.526672226329248,-68.00049196973711,0.05887115635846507,5.079061015325763 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark12(-95.26924751909442,-100.0,-1.0,-0.6462415362055052 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark12(-95.29830148918926,-67.94406641036647,0.31536910648917543,0.03712607458415007 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark12(-95.35445398453633,-98.42612706632093,-100.0,0.0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark12(-95.53389161351294,-89.05436364434682,0.09057767081754431,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark12(-95.58006431002164,-88.68313650294235,-1.0,0.5802232311408309 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark12(-95.60950325910537,-98.27564188876426,1.0,0.9595673995463754 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark12(-9.561289069853007,-4.361984312863845,0.0,0.0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark12(-95.72227133202043,-34.21388790604467,-2.7755575615628914E-17,0.9435543956440577 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark12(-9.57999279632109,-12.034261024773812,-1.0,-1.0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark12(-95.86152507940605,-84.4393806033993,-1.0,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark12(-95.89259988978613,-100.0,-1.3877787807814457E-17,-1.0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark12(-95.9530333532624,-86.25944774379282,-0.6848456913555836,91.57978333408934 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark12(-95.9695578706011,-20.163858489699734,3.8732451992362486E-4,0.02173864744712868 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark12(-9.60106280984499,-56.77164837312697,1.0,0.9999999999999982 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark12(-96.09792324444152,-1.3166419174172221,-1.0,-1.0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark12(-96.19014491818167,-5.885836706942838,-1.0,-1.0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark12(-96.46752083817296,-3.054995302323875,-56.43716680626342,0.06255266676825552 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark12(-96.50820923346889,-93.51226977629264,-60.26966240319949,-1.0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark12(-9.651511827323617,-39.192170377806676,-0.010714778834676864,0.3627792258434566 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark12(-96.53220095722419,-99.2516596574587,0.0,0.5651068886907384 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark12(-96.59167190386124,-76.75878223853645,8.881784197001252E-16,-1.0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark12(-96.6723943022574,-99.06197529566283,-0.05260004901732929,0.7547752345218665 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark12(-96.69549774379205,-90.57664782168094,-3.552713678800501E-15,1.0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark12(-96.76510305819941,-67.35265808221058,-1.0,54.135749332858694 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark12(-96.82841126874922,-19.230839114909372,-0.9999999999999982,1.048354948496903 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark12(-9.71266075176311,-46.19308971369843,-1.0,0.0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark12(-97.169308884629,-100.0,1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark12(-97.30801925405626,-88.89841345027799,-77.70858037366683,0.6589012562887149 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark12(-97.46597123386856,43.09579508806033,0,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark12(-9.757896409072966,-6.307868621781246,1.0,-0.9979791234779821 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark12(-97.9247464276132,-3.7529145090709166,0.9584828357094078,-0.9025833484595747 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark12(-98.1902276976901,-100.0,1.0,0.49584994059381904 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark12(-98.1944446454443,-44.73200276632703,-98.37201882463003,0.3732681399721358 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark12(-98.31010337027013,-53.48682703130041,0.7747310589067147,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark12(-9.832065474575352,-23.731181283135417,-1.0,1.0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark12(-98.42343072598831,-100.0,0.06068973015736134,-1.899227742281334E-5 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark12(-98.7284445066211,-100.0,-1.0,-1.0587911840678754E-22 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark12(-9.883484028381758,-57.38720060889316,-0.8569188187230329,1.0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark12(-98.89618737325608,-97.89241267185982,-1.1102230246251565E-16,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark12(-9.892886439672296,-9.81577265918132,-0.8585945687761862,31.379356275274176 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark12(-98.93921529690668,-92.57966855355404,1.0,-1.0581878690642474 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark12(-99.01441669721163,-17.721406324846647,0.0,-1.0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark12(-99.05796877477906,-100.0,5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark12(-99.09594580591093,-93.20994845280102,0.7248119626156511,-0.39619774701603894 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark12(-99.16043697328918,-31.11264454018728,0.9999999999999999,5.239446465138343 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark12(-99.2822069593687,-36.55878940554012,-49.64581463818585,0.5281895751549738 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark12(-99.40902015739027,-95.21181604827333,-100.0,2182.4137422160247 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark12(-99.56722731129548,-93.55057833681411,1.0,0.0411428442157201 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark12(-99.5830631229644,-100.0,-0.04688890916724775,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark12(-99.6822320750983,-11.717686999009969,0.9869365591009919,0.03648552326675764 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark12(-99.73142221056683,-3.3998526699074603,-42.47991446538633,-29.55599465657923 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark12(-99.76805189082165,-76.59983277233277,-22.370439076499252,-30.500335598772082 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark12(-99.83529386874744,-54.00358557058403,0.04797177237616354,70.38557628700774 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark12(-99.88683493982309,-100.0,0.04777223144763661,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark12(-99.97522595951803,-135.73167952809797,-1.7763568394002505E-15,-2308.045395777348 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark12(-99.98375502351502,-20.51270713823595,0.030661583895383815,0.2909746056990601 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark12(-99.99855325562058,-85.87239369800064,-4.6028391225588273E-4,0.3319712548389622 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark12(-99.99999395483118,-8.748384045169173,0.052271429010099374,1.0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark12(-99.99999999999994,-39.756671248806555,0.0,-0.8640788098729371 ) ;
  }
}
