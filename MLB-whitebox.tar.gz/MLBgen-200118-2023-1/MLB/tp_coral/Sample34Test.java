import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(-0.1763844495155169 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(-0.36712817670212416 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark34(-0.49999888585670776 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark34(-0.5652017636851788 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark34(-10.255607685517361 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark34(-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948963 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948966 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark34(-15.707963267948967 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948968 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948974 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark34(-16.504604230617105 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark34(-17.5194673306908 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark34(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark34(22.314254723101286 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark34(-2619.3494118781546 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark34(-26.39974745464211 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark34(-2710.819591043581 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark34(-3.1415926535897953 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark34(-3.141592653706214 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark34(-3.141592653738458 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark34(3.141594560938433 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark34(-3.1418832538049246 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark34(33.13089515825112 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark34(3.3881317890172014E-21 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark34(-35.42919487014777 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark34(-36.04224670482941 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark34(36.86773801467311 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark34(4.442834328490903E-8 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark34(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark34(-526.2167676842042 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark34(-526.2167694614759 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark34(-53.40708042794264 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark34(-53.57809715638038 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark34(-5.505020040848095 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark34(55.345725704886235 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark34(-5.551115123125783E-17 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark34(58.84015774378685 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark34(-6.077163357286271E-64 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark34(-60.821901864250314 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark34(-61.23667577119676 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark34(-64.21209576966635 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark34(-66.55462493461187 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark34(-71.1621068685078 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark34(-72.10528797565306 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark34(-72.82035294063374 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark34(-73.82023338987631 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark34(-78.58614119158938 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark34(-78.9372857036181 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark34(-82.5818358000892 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark34(-84.71593007720939 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark34(-84.91340660192203 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark34(-8.61819020799011 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark34(-9.595277539854486 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark34(-97.85543685906262 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark34(-98.0708446602065 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark34(-98.32783849785332 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark34(98.58936745818932 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark34(-9.936835650199455 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark34(-99.95565706181115 ) ;
  }
}
