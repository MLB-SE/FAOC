import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
//    0.6174740572005901;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(-0.0014452578695305363,-1.1102230246251565E-16,-0.784675534462683,0.7853981633974483 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0.0015033899308589038,0.04899779351095263,-7.516949654294519E-4,-0.8098970601529247 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(-0.0017821374789831629,-0.003564274957966167,0.7862892321369399,-26.24480915004804 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-0.0018035985443505414,-4.440892098500626E-16,0.7862999626696235,4.134889209952587 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-0.0023995063050716078,-1.1102230246251565E-16,0.7865979165499841,-30.8098506542893 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(-0.0034231308392443606,-0.006846237230021256,0.0017115654196221803,166.5333383484887 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark07(-0.003461725426187501,-0.006923450852374933,-4.556208284969944,-87.97764479225226 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark07(-0.0035338156033194582,-1.232595164407831E-32,0.7871650711991081,-99.99999999999999 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark07(-0.0035597151919797053,-0.007119430383955808,0.7871780209934381,91.97755916592426 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark07(-0.004020988376911339,-0.008041976753822608,-0.5508061893862223,0.004020988376911305 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark07(-0.004587606531322619,-5.551115123125783E-17,-100.0,-14.071432278330972 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark07(-0.004680553761046591,-0.009361107521979871,0.0023402768805232954,0.004680553760989553 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark07(-0.004805933946709056,-9.305013331122306E-7,0.002402966973354528,52.04264203172826 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark07(-0.005454820399189139,-1.4526139427169957E-12,0.003046802518490875,32.00006187705603 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark07(0.0056383728638390255,1.5747406734989446,-100.0,-52.627552802369514 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark07(-0.0060796562834569265,-0.012159238036129524,-58.901607111007465,-0.7793809928962036 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark07(-0.006250128205669725,-0.012500256411339127,-51.05400606013424,-100.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark07(0.008356975581490289,-5.0487097934144756E-29,-80.04513924039503,-39.92451761920513 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark07(-0.00903681724801464,-0.015480331897264908,-259.9618925079042,-0.7595819573934979 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark07(0.00911888797447099,-6.3108872417680944E-30,-0.7899576073846837,13.540695870633426 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark07(-0.010051359786032664,-4.521590422148239E-7,-0.7745808620707714,-53.81114599502042 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark07(-0.012326833412799054,-0.024653666825598053,50.378439662548416,3.020188817250109 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark07(-0.01291771040621803,-0.025835420812435988,0.48262051873954304,-59.45586591028782 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark07(-0.014183951480432116,-3.469446951953614E-18,-98.65333442078159,-6.996342903995938 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark07(-0.015064622766442048,-2.8788815603136485E-8,0.007532311383221024,-34.82666781620033 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark07(-0.015106736407378106,-6.898345542474813E-18,0.007553368203689053,20.1649647138774 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark07(-0.016089852198059473,-0.0321797043961187,0.7199685606563274,-59.16683476221834 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark07(0.0,1.765893789672486E-4,-52.64364383870534,1987.0889024558542 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark07(-0.017740414813741015,-8.881784197001252E-16,0.7942683708043188,49.28626332457419 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark07(-0.018401811274036506,-1.1102230246251565E-16,-100.0,-67.01236261449883 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark07(-0.019002957682068056,-4.440892098500626E-16,-100.0,-4.6704677259720215 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark07(-0.01968760760324312,-0.03371083078575127,0.7952419671990699,304.6428701803647 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark07(-0.020525347678187138,-1.4210854715202004E-14,0.4996377817551901,39.50319094851106 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark07(-0.02074772284324733,-0.04149544568649177,-100.0,-0.7646504405542024 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark07(0.021160176009481415,1.4430810153844416,-0.010580088004740707,-91.04206605189313 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark07(-0.02135310938337341,-0.042706218766746816,-0.7747216087057616,-0.6231435617814318 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark07(-0.02273906411902347,-0.023305625171899214,-93.45632901123864,-25.100139106795638 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark07(-0.024543221290729937,-0.048270680737185136,-0.7731265527520833,73.21932244053943 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark07(-0.02473663311121209,-0.049462477847965425,0.7977664799530543,66.80617023430989 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark07(-0.025409098251024165,-0.05081819650204829,0.38642218603815814,-43.434830976250495 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark07(-0.02579994852143397,-9.946628015222639E-13,-23.54330782852452,-100.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark07(-0.025978145283537604,-0.0519562905670752,0.381313788371043,-28.444070393117876 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark07(-0.02601098721066797,-0.014918987153593043,-64.55145461337585,-47.545505538042605 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark07(-0.026100836771545143,-6.938893903907228E-18,-19.615031253511855,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark07(-0.026134839311635346,-2.133060767032326E-9,0.013067419708730307,8.320593028480499 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark07(-0.026270774517149542,-0.02576027579007502,0.5582194360469492,-25.5999819136936 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark07(-0.02720112388392127,-0.054365981922737394,0.798998725339409,0.7839832696827623 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark07(-0.02787604225724946,-3.597785170964984E-5,-57.84684305298702,1.798892585482513E-5 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark07(-0.0312578254861458,-6.263996210633302E-15,-9.066570622714591,-63.00434393478294 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark07(-0.03130925007208936,-0.01897678667218014,-0.7697435383614036,0.7948865567335383 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark07(-0.031631116587572464,-0.06326223317514396,0.8012137216912345,-0.7537670468098764 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark07(-0.033067262557949784,-0.005516972802602154,-0.7688645321184734,-6.626101072183461E-13 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark07(-0.03357147688478079,-0.0671429537695568,-93.10402966866766,-77.23907360303144 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark07(-0.03499047024927826,-4.4344560317855126E-4,-38.9896299998332,-30.90941397307812 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark07(-0.03760979321665215,-0.006755687019710799,0.8042030600057744,48.187706696724575 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark07(-0.03819916964613193,-0.0047308569945823525,-60.169687578247846,62.22891487892407 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark07(-0.03827208342544705,-0.07654416685089409,-43.11780543113987,-0.36769430731983843 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark07(-0.03945364419430244,-2.2145366954652366E-16,-67.59564346323714,1.1072581800953475E-16 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark07(-0.040225292138274416,-0.08045058427654554,-0.7652855173283111,77.40935870835486 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark07(0.04099885271651463,-0.2742888827694053,-0.02049942635825719,-55.657914196051756 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark07(-0.041247232908553366,-7.881298592674572E-14,-52.30234969405265,-6.898512811394951 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark07(-0.044619151805036394,-0.08923830361007273,0.8077077392999665,-32.08267365958582 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark07(-0.04481545892173781,-7.068182016157876E-7,-58.332289743064194,0.7840835964871304 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark07(-0.04840761714727518,-7.909995534775238E-4,0.02420380857363759,3.7656945429178896 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark07(-0.048638784691743236,-2.722000345154366E-11,-0.7610787710515766,88.82331564911777 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark07(-0.04948866572946248,-0.09897733145892484,0.8101424962621795,0.014162187550437966 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark07(-0.05080709420401111,-8.948199389139479E-4,-17.07811848399201,4.4740996945697397E-4 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark07(-0.051194268731605395,-0.10238853746321075,0.8109952977632501,-46.281900362126116 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark07(-0.05129616994276206,0.4815762024416456,-0.7272758353818716,-259.42184785592224 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark07(-0.056748842953473044,-0.009917048833181646,141.91190630701237,0.004958524416590824 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark07(-0.059111556063419446,-0.08518315728050718,-58.15631511123226,-0.7428065847571947 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark07(-0.06203861935924596,0.26465712676495945,-42.49042317229426,-131.29884269032377 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark07(-0.06204136125462864,-0.12408272250925723,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark07(-0.06337876782031948,-0.11802800579085478,0.817087547307608,0.8444121662928756 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark07(-0.06539620950938439,-8.013923284849971E-15,-0.7527000586427561,4.006961642424986E-15 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark07(-0.06622656346368,-8.881784197001252E-16,0.8185114451292883,-57.13862126478222 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark07(-0.06995575291872111,-3.5527136788005025E-15,-10.341897019662168,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark07(-0.07211029378984053,-0.13898114988722116,0.8200848374681011,0.0694905749483227 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark07(-0.07252322258780863,-0.11719221882137715,0.8216597746913527,0.8439942728081369 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark07(-0.07958737504130647,-0.15917475008260715,0.03979368752065323,0.07958737504130353 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark07(-0.08051658196028644,-0.1610331639205723,-97.5743821244065,16.62037402712058 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark07(0.08188108613013402,-1.4210854715202004E-14,-109.64421998318166,-39.88466195812539 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark07(-0.08225454193798942,-8.831334483763291E-14,-100.0,87.13590549741832 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark07(-0.08508499814085027,-0.16316823240083522,0.042542499070425135,0.08158411620041761 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark07(-0.08687589591753264,-0.171858490355096,0.4034165222040168,1915.6523349585946 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark07(-0.08844712290875933,-0.05216079674582935,-97.71799623259753,-1659.9258649007356 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark07(0.08940801629577777,0.1788298967221541,-166.06933752561875,-140.11907428232198 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark07(-0.09081056952313737,-0.17929892293581268,0.830803448159017,-54.013435944041575 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark07(-0.09237588087913591,-1.6607103653760302E-16,0.046187940439567955,140.6095325107699 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark07(0.09375822334071404,0.4336153010027444,-100.0,48.50947435396741 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark07(-0.0953355929114834,-0.032587207600612386,-8.506288269081962,-0.7691045595971421 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark07(-0.09576981637168203,-1.5076900743669358E-14,0.04788490818584101,32.15334681483241 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark07(-0.09614255520618879,-7.641661498603344E-32,-87.28899248121512,-0.040979008218847986 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark07(-0.09811108175241312,-0.1962221635048261,-96.31175153420747,-13.090709670686646 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark07(0.10021991069978628,1.0390309085114438,-88.6238028012625,0.26085764717154425 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark07(0.10180730176711794,0.20361460353423894,0.7344945125138893,-0.8470678103044404 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark07(-0.10244333501621383,-2.8421709430404007E-14,-40.91747577235125,-27.608077536253788 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark07(-0.10336607021116556,-0.01727070778504156,0.7547625187020947,23.996240852874397 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark07(-0.10421718990326975,-0.16282624890988057,-0.7103940656897685,-10.364837535776457 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark07(-0.10611415089483778,-0.21217526366784678,0.8384552388448672,31.88829990683001 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark07(-0.10728034424545728,-0.10835624479975793,0.05364017212272778,-2135.7520922786734 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark07(-0.1107972656440097,0.7103448863073847,-25.570296724380384,20.080862863799695 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark07(0.11179979463796418,0.2275282636654521,0.7294982660784662,177.40917266193622 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark07(-0.1120715702337819,-9.387243431450577E-4,0.5795636204492152,4.693621715723406E-4 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark07(0.11386336095115263,-1.1231270653722682E-16,-0.05580688491702546,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark07(-0.11392229627041961,-0.16966256459603196,0.056961148135209805,-0.7005668810994323 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark07(-0.11553990540077178,-9.676080059565437E-15,0.05776995270038589,-99.43897809650478 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark07(-0.1158069858354799,-8.179266203934234E-17,-53.864112560558446,0.7853981633974483 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark07(-0.1163981032554757,-3.725476316678841E-4,-0.7271991117697104,100.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark07(-0.11690106865140171,-3.552713678800501E-15,-68.00224627422094,2137.2956633098306 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark07(-0.11790765617089254,-3.552070407363924E-14,0.7264443353120198,-0.7853981633974305 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark07(-0.12083539470892528,-0.005631937882808736,0.06041769735446256,-76.78915232949707 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark07(-0.12127073140781314,-0.22588545211637115,-0.7247627976935417,81.09069894639438 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark07(-0.12132342355654657,-0.2018077995503287,-12.8594003590934,0.10090389977516435 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark07(-0.12293957577711591,-0.2458791515542318,0.8468679512860063,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark07(-0.12405365866883755,-0.185189722401469,-96.51452187085127,-162.33755632521988 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark07(-0.12408644156976738,-0.0971847841225262,-168.8054868540808,-109.79410542974215 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark07(-0.12421065374769569,-0.05912488624025286,19.001509826080728,96.38747629383938 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark07(-0.1249286740363408,-0.24985734807268156,-12.99869947176636,0.9103268374338036 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark07(-0.12544370715375086,-0.19224094722904528,-0.3263954507543607,-32.126145696252436 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark07(-0.12673824177838355,-0.05510791779932028,-100.0,-56.84858551784695 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark07(-0.1271164298872881,-0.2542328597745761,0.45424855802411024,-30.826382783928228 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark07(-0.1271481298228395,-6.827587010166831E-13,0.06357406491141974,-28.610751744085043 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark07(-0.12793836920876345,-0.2478439740008751,-0.721428978793071,70.54442158972151 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark07(-0.12796845080740868,-0.25161054687598294,-0.721413937993744,0.9112034368354397 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark07(-0.12836920635034269,-1.0240063972169154E-8,0.49881282973730345,5.120031953964599E-9 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark07(-0.12891648271219885,-0.14392222925911913,0.8498564047535477,42.87070058506988 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark07(-0.1298383078843696,-0.16598902752693978,-0.7204790094552633,-94.41996230723944 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark07(-0.13304093951635504,-1.5777218104420236E-30,-32.0792877196482,0.07893999716084252 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark07(-0.13445037673365345,-1.27453351047344E-14,0.13345637709038408,-15.346020652919037 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark07(-0.13531708995760605,-0.27063417991521194,0.8530567083762512,-1725.4088165365304 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark07(-0.13651020665431562,-0.0705181873822604,28.60511247580898,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark07(-0.13908484829877182,-0.013353474590572956,-92.19712250196372,-95.16027172633383 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark07(-0.1394215603494664,-0.07874037123414829,0.0697107801747332,-31.37641806331293 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark07(-0.1411221057837066,-0.20149098376131389,-54.00043742217161,0.8861410505524522 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark07(-0.14374792476179998,-0.2874958495235998,-99.30195576297619,-71.96320872151878 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark07(-0.14440945731382654,-0.28881891462765297,-3.568199431054115,0.14440980498452968 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark07(-0.14593811295368134,-0.04736979700438734,0.07296905647684067,-0.7617132648952546 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark07(-0.14646733815202884,-0.29293467630405745,0.8586318324734628,58.36157042401581 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark07(-0.14772967386016475,-0.17477626865826718,0.8407134712808539,-79.66947643656697 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark07(-0.1484141512931036,-0.0935075461754451,-0.6958255322514155,44.53251216780657 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark07(-0.1484257962075013,-8.881784197001252E-16,-72.15502990350066,89.82434609313704 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark07(-0.14910563002525606,-6.908847666469529E-11,0.8524471022842625,0.7853981634319925 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark07(-0.15001791392354144,-0.13521751414912886,12.269732205693046,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark07(-0.15396103747066425,-0.1993748962665464,-46.392616725103814,-28.717412026540032 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark07(-0.15477649988381603,-0.3095529995993044,0.8627864133393564,-0.6306216635977961 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark07(-0.15548055378707465,-0.31096110757375883,-31.737459213597617,0.1554805537868873 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark07(0.15603147611834642,0.31206295223669295,-0.07801573805917325,-91.11430875516929 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark07(-0.15890408177846374,-1.3298455528420907E-11,-0.11220419217184313,17.205134329819266 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark07(0.15981298308676628,0.509968539229678,-0.07990649154338325,-100.0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark07(-0.16040577160729846,-0.13423621315782694,-11.726026800932475,76.25212852031696 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark07(-0.16194832333524747,-0.32384360242181115,0.8663722331996581,35.4527625061251 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark07(-0.1640033256974862,-0.32800665139497215,0.8673998262461912,-94.45406236560902 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark07(-0.16437422484855735,-0.32731355192848083,-44.26029871916748,-2.184772840017527 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark07(-0.16459028232671624,-8.758115402030107E-47,-0.1444632283539902,4.379057701015053E-47 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark07(-0.16546962452282749,-1.3915542548148535E-13,-0.5206146544578549,-48.624183323605905 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark07(-0.1663942144660811,-0.08754069591881225,0.807283337377152,-16.962525362013277 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark07(-0.1664999347034479,-0.2205088474581624,-0.644243150690044,-0.38987329033159784 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark07(-0.16775583278942285,-0.33551166557884055,0.8692760797921597,-100.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark07(-0.16903049694275651,-0.2579033513105511,-65.56437432318073,0.12895167565527552 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark07(-0.1706449748566996,-1.1102230246251565E-16,0.5937556238672133,24.83645739128859 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark07(-0.17141316872509796,-0.3159030739426637,-100.0,0.15795153697133188 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark07(-0.17182587119993156,-0.34365174239986307,-0.6994852277974823,0.17182587119993153 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark07(-0.17235295032512887,-0.20917927443083795,0.8715746385600127,-25.606781042144306 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark07(-0.1738548535447194,-0.2630837275039874,0.08692742677235973,-0.6538562996454544 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark07(-0.17743232210182514,-0.3119464930724831,-71.86367280450935,54.562930136902445 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark07(-0.17763911590161216,-0.3014053478396175,-0.6965786054466414,-0.6346954894776395 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark07(0.17842483286896083,0.5028517518213281,-0.8746105797385733,-45.80451931546696 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark07(-0.1797742323489002,-0.00855923969679023,0.8752852795718983,0.0042796198483951164 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark07(-0.18116735086765964,-0.04653451010347508,-0.1944118851247044,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark07(-0.18139816213738738,-0.18703706005849902,-18.13491289405339,0.8789166934266976 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark07(-0.18665727365743776,-0.22853985004657393,0.09332863682871888,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark07(-0.18828223256262788,-0.3765644651252546,0.8795392796787622,-2.952524494613712 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark07(-0.19007230712353995,-5.621779318841486E-16,-0.49850552992267616,-0.785398163397448 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark07(-0.1907694832862123,-0.3815388938447978,-48.22273069563266,0.19076943288623072 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark07(-0.19083468239195836,-0.38073342308776503,-16.36079546047566,0.19036676388185764 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark07(-0.19239551967430085,-4.930380657631324E-32,0.11514551101712722,69.91099457002431 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark07(-0.19286504270621052,-4.331251124410728E-11,0.09643252135303114,2.2789218642022657E-11 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark07(-0.19487506954205802,-0.3897501390841156,0.09743753477102901,34.75338338905583 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark07(-0.19719514155215231,-0.15412799387005532,0.8839957341735241,21.494761401888763 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark07(-0.1980436548547506,-0.2634392846565756,22.119300637540434,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark07(-0.20050084300607793,0.7594041232513578,0.8856485849002314,0.4056961017717695 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark07(-0.2033604275272189,-5.479615743418224E-15,-41.32106201877394,-0.7853981633974455 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark07(-0.20424542237121612,0.860747803997383,0.8875208745830562,-13.49674450522951 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark07(-0.20435584047655972,-5.1156593476831E-9,15.957721142227982,21.79374699886634 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark07(-0.20513007562764501,-0.4088796747403405,0.8879632012112705,-100.0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark07(-0.20605716370183425,-0.06797916725184855,-0.6177548860053141,-86.4830400767752 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark07(-0.2071084313400715,-0.41421686268014235,-2.2279678608328854,0.20710843134007112 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark07(-0.20804017248610285,-0.37337256857815004,-5.1930987519469145,-29.363779395542426 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark07(-0.20920929729861282,-3.552713678800501E-15,0.19957928952381043,-45.7704196055506 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark07(-0.210012033195735,-0.2711309485521137,-0.6803921467995808,13.31065392453607 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark07(0.21078924686762512,0.38964303165692443,-182.33794878523375,-99.9477893402984 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark07(-0.21194268549166062,-0.4238853709833091,0.8913695061432786,59.84597814732052 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark07(-0.2137161036623239,-0.42493819713801795,0.10685805183116215,-0.5729290648284393 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark07(-0.2143803417003051,-0.42876068340060874,0.10719017085015255,-12.165624021281316 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark07(-0.21540429523886107,-2.2092890003110545E-16,0.10770214761943053,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark07(-0.217033714915978,-0.43406742983195556,0.568581468685983,11.039819577217479 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark07(-0.21739192349752318,-0.21644099294970362,0.884760001172138,-1966.0864090826478 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark07(-0.2178496065911979,-0.4356992131823875,-9.576122461452087,9.458165874073885 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark07(-0.22090085671365356,-0.4417593859550579,-8.528912477826058,0.2568757696461777 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark07(-0.2229788215971422,-0.4335859274686486,0.1114894107985711,0.21679296373432427 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark07(-0.22418593070632775,-1.7629973526132677E-15,0.897491128750612,100.0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark07(-0.22422487416091494,-0.04733080081002161,-0.6732857263169907,-99.26532510652156 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark07(-0.22541689494766803,-0.45083378989533585,-37.56350373096765,-625.331543347944 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark07(-0.2259268098485751,-0.13114456561877597,-73.5673696740428,-59.34105163287158 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark07(-0.22656913470277806,-0.4531382694055559,-39.51520883856199,7.414682606802556 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark07(-0.2272561456285458,-0.4545122912570914,-0.6717700905831754,-100.0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark07(-0.22736466716261564,-0.4014286245887494,-30.532207420853965,-54.88641851999557 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark07(-0.2286661997913607,-0.20418012966047555,0.11433309989568038,-95.6801540310978 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark07(-0.23028980965812568,-0.02256054425114562,-39.67406822199318,0.01128027212557281 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark07(-0.23212389979470768,-0.2579855664600868,0.06449639161502141,-47.317672474971985 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark07(-0.23264958957707674,-1.1102230246251565E-16,-3.7149569247329364,-5.947257512707151 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark07(-0.23331087120852337,-0.4666217424170467,-63.50208082608266,-107.3656947715519 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark07(0.2342483285383962,0.8796409717318523,-99.66702190883993,-1.2252186492633745 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark07(-0.2389562092615693,-0.2251212206398344,0.11947810463078468,50.254977185950736 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark07(-0.23913839853434296,-0.24766330426743832,-0.6658289641302768,-29.783614472861302 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark07(-0.23923022675006378,-0.03465711376550035,0.9050132767724799,26.80732150584882 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark07(-0.24068151492010298,-0.0067544675086982486,-125.5026463750909,-100.0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark07(-0.24126930834341082,-0.0013600720432980623,0.12063465417170541,0.7860781994190973 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark07(-0.24192821456803415,-0.4828219522698161,-30.624915150081396,-44.758015944401194 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark07(-0.24501344442219586,-0.49002688884439144,-100.0,1.030411607819644 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark07(-0.24570390240698892,-0.4914078048121198,-44.09061486749619,100.0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark07(-0.24633020909999748,-0.47755247068311263,48.024588282151896,0.23866912980377486 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark07(-0.24702408400096942,-0.46476901438922236,-7.708596846425728,11.277747351237778 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark07(-0.24776066644657535,-0.4955213328931505,-0.1751891654070743,-19.863491351914526 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark07(-0.24822806413489643,-0.48144516817444244,0.12666993042691832,1.0258301611425955 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark07(-0.2483959145614416,-0.3459860904080073,0.1241979572807208,-100.0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark07(-0.24960982737341333,-0.26427602639068887,-3.774892163723422,1.3804783981922653 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark07(-0.25003508178958256,-0.5000701635790108,-100.0,36.22742372442988 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark07(-0.25051918539094786,-0.501038370781895,0.12525959269547393,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark07(-0.2506320838547409,-0.5010651681307433,0.9107142053248187,-44.25487761288839 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark07(-0.2507004646983194,-0.5014009285210335,-0.6600479310482885,1.000266536266281E-11 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark07(-0.2516367568074447,-0.5032735136148891,0.12581837840372234,-34.16079312256944 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark07(-0.25278227127307673,-0.5018344703758241,0.12639113563653837,0.26179938779915 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark07(-0.252869335338767,-4.5749213453954074E-15,-0.6589634957280648,16.45380114070002 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark07(-0.25289314477932806,-0.3178106106921926,-100.0,0.9429885484241404 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark07(-0.2556724145425575,-0.27362575434267855,0.913234370668727,0.9222110405687876 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark07(-0.2564809241984783,-0.5129618483969546,-99.99999999999993,-12.621395699247408 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark07(0.2570565842689234,0.5141131685378479,86.90496422281822,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark07(-0.2575388271035397,-0.31070904408895683,0.12876941355176985,1.82232109036768 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark07(-0.2576401311015024,-0.5152735458347762,-76.51870817285496,0.2576394486888023 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark07(-0.25846384866489114,-0.24315442031299694,-65.2043526780237,-1299.7722972924482 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark07(0.25948578321066884,0.5189715664249692,0.6556552717921139,-48.95709087533231 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark07(-0.2599134660165597,-0.08729025907150112,-28.521530497879425,-0.7417530338616978 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark07(-0.2599343701010457,-0.5198687402020911,-40.586535276778896,-41.10809609059304 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark07(-0.2601970325589976,-0.4027859735911009,-33.614071776645886,0.5458143342820558 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark07(-0.26025215427309867,-0.5205043085461959,0.13012607713654933,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark07(-0.26047887739282927,-0.43454041554005735,0.9156376020938629,1.0026683711674769 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark07(-0.2604853293762651,-0.51797650612827,0.13024266468813256,-77.58980780417171 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark07(-0.2607214081387632,-0.5209187644422791,-99.61430989725613,-0.5308036305521284 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark07(-0.261107735226586,-0.5222154247805078,-39.921455762191606,-40.56722691794371 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark07(-0.261127267903241,-6.938893903907228E-18,-100.0,0.0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark07(-0.26152810900486534,-0.5230562180097291,-0.6546341088950156,1.046926272402313 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark07(-0.2615633924939164,-0.5231262964594569,-5.362187626062782,-0.5238350151677198 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179042578797496,-0.4953874403869278,-0.6545029505034609,-0.5235987755982991 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179837421929575,-0.5235967484385324,0.13089918710964787,-23.345597982899925 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179936875808885,-0.5235987375161775,-100.0,69.53074624110387 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779844236,-0.5235987755968846,-0.6544984694982271,57.5362588358132 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779857803,-0.523458166284563,0.13089969389928902,0.2174887576282338 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914524,-0.5235987755982902,-47.58424796771337,100.0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914735,-0.5235019011012099,0.13089969389957368,-43.33650832033295 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914824,-0.5235987755982959,-24.02949254956578,1.0471975511965963 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.07594640183189716,-72.61944126927628,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.21273267025094217,0.13089969389957457,174.4647582264938 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.37199531331847235,-15.459125642962519,-2072.8674926730596 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5095731994333418,-79.76407403852292,-120.25030468398784 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.523598775598282,-9.864551947544445,-27.743314307134327 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5235987755982947,0.13089969389957457,0.26179938779915146 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5235987755982947,0.9162978572970228,90.63311044561934 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5235987755982972,0.13089969389957457,89.5867891748504 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914924,-0.5235987755956307,-0.6544984694978736,-0.523598775599633 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914935,-0.5235987755982985,-0.6544984694978736,52.35346733021391 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.5235987755982987,-6.791653402305934,8.006722061406935 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915013,-0.16706410004780187,-25.21108776074431,11.669327045867092 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991502,-0.3372651032305358,0.9162978572970234,0.16863255161526794 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915024,-0.4254639576325191,-81.99882400944341,43.42518088891688 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915046,-0.02459992895950583,-2087.8684013295656,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915046,-0.4793308794064986,0.9162978572970235,0.23966543970324927 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915046,-0.5228281759320569,0.3387410356099432,54.55454536784572 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.5235987755982983,0.130899693899575,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.5235987755982987,0.130899693899575,-6.747226081056054 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915074,-0.5232155657472296,0.13089969389957537,28.56161266087904 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991508,-0.5235987755982987,-0.6544984694978728,-62.63258337682848 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991508,-0.5235987755982987,0.9162978572970237,99.22588919024659 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.33406335727994657,0.15797295208529452,0.16703167863997326 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.41667538160026407,55.29375442481187,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5088665011124042,0.13089969389957545,100.0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982981,0.13089969389957545,0.26179938779914913 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982983,0.18706169040587783,38.71000803360388 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982983,-0.6544984694978719,10.912062165731061 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982983,-0.6544984694978728,-86.6200454725018 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915096,-1.232595164407831E-32,0.13089969389957548,84.03757193272 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991518,-0.5235987755982987,-65.6001557208544,0.2617993877991493 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991527,-0.5235987755982983,0.9162978572970246,62.752183520615404 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915446,-0.47617155002015066,0.08951495820519992,0.10462330993257923 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991579,-0.3312640225352324,-75.25251074211197,99.91785083590825 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991579,-0.5222702532037671,0.9162978572970273,1.0478482103187525 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991651,-0.5235987755982965,-85.32325571405943,-88.36988626894285 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991674,-0.5235987755982978,0.916297857297032,-67.85409234907894 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779916795,-0.5040173419253469,0.9162978572970323,-13.69918379321588 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877992255,-0.5020070674811058,0.13089969389961276,1.0364016971380012 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark07(-0.2621464751117554,-0.523598775598288,-100.0,-0.5235987755983043 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark07(-0.2622419237335424,-0.20465053731244273,0.1311209618667712,7.515550341538292 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark07(-0.262578068545107,-0.5235987755982987,-21.787502223486165,0.26179907168991057 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark07(-0.26265354505537064,-0.5233717348177255,0.13132677252768532,-0.5237122959885855 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark07(-0.26403678242366846,-0.5229105438770252,-81.4452726368705,-100.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark07(-0.26439675467091645,-0.2905541742673534,-0.65319978606199,42.57240667884949 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark07(-0.26448993103040547,-0.4146439875350818,0.13224496551520273,0.2073219937675409 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark07(-0.26459530421620453,-0.4414404568304364,-0.653100511289346,-100.0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark07(-0.2646464428591733,-0.5235987755982547,-109.03801488296384,-163.09558081820487 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark07(-0.26526552736603864,-0.5235987755982987,-0.652765399714429,-0.45337158789443777 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark07(-0.26568318528988794,-2.6821327359249335E-20,0.9182397560423923,0.7840937331016676 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark07(-0.2658984880553725,-0.2830685105168351,0.7630329896567974,100.0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark07(-0.2663414845873766,-0.4911417728508318,-0.6522274211037596,1958.3926097835983 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark07(-0.2691494004925796,-0.5235987755982978,0.9199728636437381,-32.24260399620806 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark07(-0.2695102581169115,-0.046652110453812956,0.920153292455904,-66.46219827712096 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark07(-0.2695959244191333,-1.2016632723404474E-28,0.13479796220956666,-132.7270305525651 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark07(-0.26987581379731146,-0.5235987755982987,0.12459786852790453,100.0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark07(-0.27044654212927133,-0.17738941596490154,0.1364116827659987,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark07(-0.27171543146065885,-0.4453030901924837,-45.57472474960829,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark07(-0.2734982722281353,-0.5235987755982945,0.9221472995115159,-29.55528663477398 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark07(0.2747800787181783,0.7311022158656525,0.6480081240383335,90.74511234408911 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark07(-0.2764835322726984,-1.773764366559826E-15,-0.30105463502095764,8.868838103205177E-16 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark07(-0.2770647555387392,-0.5154995417082777,0.5328039845948012,-4.177436278074543 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark07(-0.2774009367386838,-0.4944587215550447,-100.0,19.701406040853815 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark07(-0.27741064131652454,-1.1102230246251565E-16,-81.85760112459326,-100.0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark07(-0.27819633313996317,-0.5229048041244045,-1.1065529867780435,-30.66369607469393 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark07(-0.2832228541321602,-0.504251690674252,-34.408657527873864,0.252125845337126 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark07(0.2836780811543037,-1.1102230246251565E-16,-50.12190082448828,100.0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark07(-0.28396333923926775,-0.4883453835476989,-93.16210233787704,56.7197635622196 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark07(-0.284305555948613,-9.860761315262648E-32,0.1421527779743065,-0.7853981633974456 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark07(-0.28446880858372636,-2.0194839173657902E-28,0.6581513947037139,33.5528463439654 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark07(-0.28593865543390123,-0.004778103731057014,0.7122683001240971,-54.39526872723452 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark07(-0.2860322309314192,-0.5207794371351429,0.1430161154657096,-56.42215195126427 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark07(-0.2867329485648238,-1.1102230246251565E-16,21.49326943192957,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark07(-0.2871948244155105,-0.5235987755982983,-17.166465316840345,-44.716233414456255 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark07(0.28750971845957374,0.575019436919149,-0.9291530226272351,-0.2875097184595745 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark07(-0.28761067136562746,-0.5235987755982988,-99.96671365564421,-53.772405042985255 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark07(-0.28790756757794655,-0.26493753812860804,0.26129883653529723,-51.69658122102773 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark07(-0.2902959718733428,-0.0015296050634852065,-0.3507172689349935,-0.7846333608657057 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark07(-0.29094045301691007,-0.5230012432452061,-81.07504726591482,-39.59113853382343 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark07(-0.2909900530502049,-0.5235987755982983,0.18198990831549056,-44.67562302572499 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark07(-0.2911076677550071,-0.5235987755982947,-0.027079522273698753,-77.28645204164079 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark07(-0.29724939118031557,-0.5235987755982983,-0.26179938779914735,-55.62571701939474 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark07(-0.29874945743224596,-0.512870179722356,-0.6360234346813252,10.181212791887125 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark07(-0.29939380786875136,-0.14861019050238178,-2314.1006402579837,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark07(-0.2997001136962426,-0.24631839656526622,0.4599596298968075,41.747946938027965 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark07(-0.30038318603105907,-0.2925802043126917,-45.19519856962909,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark07(-0.3004899344929246,-0.5053946128142958,-29.855205602871063,11.30994158929624 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark07(-0.30187230413304467,-0.5235987755982983,-71.6335702177894,0.26179938779914913 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark07(-0.30279086369354674,-0.5235987755982947,0.9367935952442217,-41.26336741832562 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark07(-0.3036216816805548,-0.5019822137115909,0.1518108408402774,30.85413143457921 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark07(0.30709013551422953,0.6297369162681798,-0.9396017075255174,-59.22112694637382 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark07(-0.307167714296537,-0.5235987755982987,-71.26429792425562,99.70513490629405 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark07(0.3076330772017802,-3.469446951953614E-18,-22.644962759590832,16.360750962508522 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark07(-0.30854822437627993,-0.01072158257424824,-99.66302798781955,-0.7800373721103242 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark07(-0.31161413863725484,-0.3165139540984281,-0.5491244534661961,-30.864480799884653 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark07(-0.3116179188012106,-0.11137905301978533,-225.37728148689143,0.055754875681770955 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark07(-0.3117356970871429,-0.5178776430453277,0.9412660119410198,-0.5264593418747845 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark07(-0.3118962799914794,-8.881784197001252E-16,0.1559481399957397,-35.88468617071163 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark07(-0.3119567994024985,-1.734723475976807E-18,0.17662839477230471,-82.05312505094378 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark07(-0.3147319466072266,-0.5067860206704994,0.9427641367010615,0.2533930289836025 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark07(-0.314833410737025,-0.48526666238712357,-0.6279814580289358,89.22968815078453 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark07(-0.31517498455116744,-2.3936071158715844E-13,0.942985655673032,0.7853981633975681 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark07(-0.3155424909506914,-0.3946080729951996,-50.605361219972764,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark07(-0.31688967685756886,-0.5235987755982876,-90.0599607046811,-17.592288663524542 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark07(-0.31813292740103344,-0.6059635744373634,0.944464627097965,23.078994606125974 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark07(-0.318417993005576,-0.01685526916331667,0.17099960070592565,97.80384229945243 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark07(-0.3216058311529363,-0.523598775595179,-93.30548575148714,1.0471975511950378 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark07(-0.32279135237599066,-3.552713678800501E-15,0.9467938395854434,-23.15130548658169 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark07(-0.32301371623334324,-0.2158124855729009,0.16150685811667176,0.6510034609040213 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark07(-0.328937562080791,-0.5234604590193311,0.9498669444378438,50.40832442438264 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark07(-0.3303182589468854,-0.3012281073106544,-0.6202393109197342,106.96391216695267 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark07(-0.3304282286488964,-0.31610638265552893,0,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark07(-0.3322198725143686,-0.5235987755982987,0.9515080996546326,3.21153136710248 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark07(-0.33281479857245655,-3.552713678800501E-15,-0.06260184093451926,-121.79482144434816 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark07(-0.33388426539387694,0.4105200203388737,0.16694213269693847,0.5801381532280115 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark07(-0.3346609404958892,-3.944304526105059E-31,0.9527286336453928,0.7853981633974483 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark07(0.3358815119075595,1.5471878689632454,-84.53873356820907,91.90535362850153 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark07(-0.3382876497466283,-0.5225668128175851,0.9545419882707624,94.93759183249404 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark07(-0.3387735428295065,-0.5235987755982735,-29.71968234268495,0.2617993877991367 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark07(-0.33950136788915664,-7.105427357601002E-15,0.9493651276760908,4.068100467596482 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark07(-0.3436000296913271,-1.1102230246251565E-16,40.26905579608487,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark07(-0.3450445817139853,-0.5022298960936459,0.9579204542544408,1.0365131114442712 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark07(-0.3455962939439214,-9.860761315262648E-32,0.1727981469719607,84.03760189816066 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark07(-0.3473391285262681,-0.41118744030903054,-0.6117285991343142,-0.579804443242933 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark07(0.3475386228926895,0.9380874919936044,-100.0,-99.69335149086321 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark07(-0.34933969886753397,-0.5185278449715452,0.3758961500190132,0.2592639224857726 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark07(-0.3505486929980407,-6.484047893560575E-17,-22.739121720353268,-3.8927458549231573 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark07(-0.35170520192765065,-0.34489852528618914,0.9612507643612735,77.19330364140444 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark07(-0.35404034653911864,-0.5235987755982947,0.17702017326955932,58.46236521106043 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark07(-0.3541959442209754,-0.11268166897192326,0.17709797211048772,34.152760315275216 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark07(-0.35587430027181544,-0.5235987755982983,-0.37657150155579594,-40.373614278130454 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark07(-0.35613633145572776,-0.5151796847902242,0.9634663291253122,0.257589842399346 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark07(0.35746423263209065,-1.1102230246251565E-16,-213.0216256790967,49.94043808956553 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark07(-0.3599825253539182,-0.5011496849219685,-173.34397313982987,0.25057484246098427 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark07(-0.36126222169333183,-0.5172116996452611,0.9660292742441138,72.9698306042171 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark07(-0.3613459813620927,-0.2715508270758625,0.9660711540784946,-4.811546939491274 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark07(-0.36205388737521826,-0.4321082611823215,-97.85593455635248,1.001452293988609 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark07(-0.3635383991928678,-0.4223727885309244,0.9671673629938822,0.9965845576629105 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark07(-0.3635531442156985,-0.5235987755982985,0.0528419074102356,-0.523598775598299 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark07(-0.36529919553986545,-0.4992241152175664,-3.4593425460212384,-8.431302692510931 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark07(-0.3658368403213649,-0.30021597141634737,0.9338667997181566,-83.62356584014252 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark07(-0.3679829750128548,-4.440892098500626E-16,0.6595601998732299,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark07(0.3696814063782057,33.490471002575276,-60.849211317682126,-84.67594361373689 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark07(-0.37062592358250085,-3.280800372954284E-21,0.18531296179125042,0.7840832430780081 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark07(0.37143200271572974,2.299695762267348,-100.0,-41.21001523576692 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark07(-0.37164167911262946,-0.5235987755982983,-47.40791294230922,-55.937828280333726 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark07(-0.37255830557851555,-0.5235987755982734,-56.572734264243884,74.61415078206991 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark07(-0.37366492985582556,-4.922291842041405E-12,0.8489799016908375,-73.93482250130135 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark07(-0.37445797958665594,-0.3287538414427947,0.187229641801786,-112.14886700379077 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark07(-0.37560660972088017,-4.740116417782902E-5,0.8453052992003312,13.948700745956273 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark07(-0.3760198019711248,-0.17442143658441273,0.3031916866493182,0.08721071829220638 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark07(-0.379583040134766,-0.37872218904369226,0.4082208755675004,-2035.251638687633 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark07(-0.382078442658913,-9.970577954144962E-14,0.1910392213294565,93.46239596832801 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark07(0.3827474538853946,0.7654949090629022,-0.1913737269426973,-99.99999999763504 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark07(-0.3830580922066008,-0.5233425498814184,-28.617648776715818,100.0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark07(-0.3845137421889784,-0.01836842600101385,0.1922568710944892,19.645377613365252 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark07(-0.3881410396823348,-4.440892098500626E-16,-27.767008751825657,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark07(-0.39092658742440034,-0.3243648684578364,-100.0,0.9475805976263665 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark07(-0.39126109842568096,-0.5235987755982975,-0.45821347603791884,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark07(-0.3926806811952488,-0.5235987755982805,0.9817385039950727,-0.523598775598308 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark07(-0.393602336118792,-0.2911927933293995,0.3700123673630613,-1.605870839470981 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark07(-0.395956965169295,-0.5235987755982987,-0.5874196808128007,100.0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark07(-0.39611303810686155,-0.523598775598284,0.9834546824508791,0.2617993877991438 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark07(-0.3978483856894323,-0.11574767972303684,-0.5864739705527321,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark07(-0.39791333164089515,-0.5224765099847555,-100.0,0.26123825498564757 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark07(-0.3988991090367189,-0.10295640462436377,0.4130754391422866,0.051478202312182475 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark07(-0.3990521323357681,-0.4711920051343931,-16.86341884766024,0.235595822511573 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark07(-0.3990672501642877,-0.5235987755982799,-15.008030965839167,-0.454706136023449 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark07(-0.4005624639217572,-0.32734805583353355,0.20028123196087855,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark07(-0.4037312970931095,-8.881784197001252E-16,0.20186564854655475,46.40456444109382 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark07(-0.40732978225994765,-0.5194577164812211,0.9890630545274222,0.25972885824061054 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark07(-0.40783986617245205,-0.15454714842197587,-0.5814782303112223,27.04247552917225 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark07(-0.4080899756303813,-5.398224530783079E-16,-0.9306835696558284,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark07(-0.40904716501634664,-0.5235987755982663,-96.47404256750487,-100.0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark07(-0.4098619029977544,-0.5235987755982987,-94.20376118126994,-75.62368564164599 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark07(-0.4137453162972821,-0.04472642992597457,0.5094017360006049,-20.793888388144573 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark07(-0.4145716522094104,-0.48966184752086567,-9.12703041550975,10.508261994068604 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark07(-0.41699214020188186,-0.49184681812981773,0.5332402707711128,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark07(-0.41920421159745674,0.33479372633963744,0.9950002691961767,-54.3089542166619 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark07(-0.42197285600607587,-0.05866890622292589,0.21098642800303796,-59.01755863005561 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark07(-0.42250704724209975,-0.5235987755982987,-62.564789660312435,-11.750017017927322 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark07(-0.42336133220428523,-1.1102230246251565E-14,0.9970788294995909,-45.44137514044878 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark07(-0.42373715940566314,-2.800716582229945E-11,-81.39238455665284,10.326977888171411 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark07(-0.42427980281588806,-0.4457125517225406,-92.38635431044416,0.22285627585826126 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark07(-0.4249329595785509,-0.021725442396775502,-35.70613927625423,0.010862721198387753 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark07(-0.42787464883371584,-0.5234275867518839,-0.4349257329046248,-1957.6239606555457 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark07(-0.43004980324902187,0.0,0,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark07(-0.43030805830409236,-10.279055136378418,0,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark07(-0.4349772261426304,-0.5174409886885797,1.0028867764687635,-0.5266776690531585 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark07(-0.4355789083795127,-0.32992477884866567,-5.184724663479008,-100.0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark07(-0.43632293616776785,-1.91699002673286E-10,-82.88530379522567,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark07(-0.4382820799873999,-0.3721431891338851,1.0045392033911482,-29.381841356543763 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark07(-0.4397793288196626,-6.106226635438361E-16,-88.1979813719013,26.772395251060235 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark07(0.44115933499302495,0.883241719036494,0.5648184959009358,31.757835571875617 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark07(-0.4416912070170369,-0.2733538358593962,-53.22932897708878,-0.6487212454677502 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark07(-0.4419133812943136,-1.0369483050005322E-13,-49.23002850881479,-99.04121569834885 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark07(-0.442101018232372,-0.4780970769841803,-2.9578954699960747,14.18542819236211 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark07(-0.4426391385786457,-2.031859447609377E-12,-21.376532690099616,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark07(-0.44583552291264783,-1.3155324571383932E-14,-70.10410868089069,-33.552317553588836 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark07(-0.44802711713725074,-1.6109900957978027E-5,1.0094117219660736,-97.4263422008966 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark07(0.44806372587541893,0.8961274517508662,-0.22403186293770946,-5.900944329807314 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark07(-0.44950422719772615,-0.5235987461811711,-0.5606460497985852,-62.62061784800434 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark07(-0.45206392506043436,-0.29425372395879795,-45.6882828592002,-11.706475536244643 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark07(-0.4531383462028758,-2.2652771302991807E-16,0.2265691731014379,23.412237693803085 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark07(-0.4540912380727655,-0.5235987755982987,-100.0,1.0471975511965976 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark07(-0.4578808610401246,-0.5182245317825959,-37.53869086023166,1.0445104292887462 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark07(-0.4580133959371641,-0.4783054592521018,0.22900669796858206,-84.32412950387943 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark07(-0.4581732283342035,-0.5058836262706553,-0.24396011417946784,-100.0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark07(-0.46408783989069136,-0.34450877988114653,0.561752040456672,91.09038800406115 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark07(-0.4689792070503904,-0.39104755891906495,-50.816397861319935,0.19549396960316423 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark07(-0.4712436601289107,-1.0905213153775267E-26,0.2403353680880486,-90.32233706275323 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark07(-0.4721556540154801,-0.5235987755982987,0.24714373915188004,0.2617993877991494 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark07(-0.47368154908851867,-1.4210854715202004E-14,-88.13602104511064,100.0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark07(-0.4741841654687038,-0.037368978271499244,88.76736096377343,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark07(-0.47599701595783506,-8.591926783316273E-12,-0.5473996554185308,-7.4322703838283175 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark07(-0.4774836457589966,-0.24798204289090078,-0.54665634051795,-71.05513123263951 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark07(-0.4783455400817278,-0.21665526461034054,0,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark07(-0.4785713668039975,-0.16781160797690714,-13.019791937574567,49.92000856430555 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark07(-0.4822607744697529,-6.123233995736764E-17,0.24113038723487645,-0.7853981633974483 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark07(-0.48280454734060657,-1.1297341845253677E-17,0.24140227367030329,84.26325378482301 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark07(0.48316822821610905,1.0526078500967024,0.5758317230009549,10.474206118034019 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark07(-0.4854942335675456,-0.0011551136210068355,-0.5426510466136754,-90.71523221856029 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark07(-0.4874856247724958,-5.551115123125783E-17,1.0291409757836956,-0.7853981633974483 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark07(-0.4881201559224433,-0.2778064812825255,61.61909973615059,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark07(-0.49348811745077015,-0.010181039384765236,-25.504295765528347,-6.836393204668461 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark07(-0.49427787320261873,-9.860761315262648E-32,0.9149029028348594,92.23694191269884 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark07(-0.4956380625905307,-0.5235987755982983,-100.0,-0.523598775598299 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark07(-0.4957679614986719,-0.06315269590567135,78.89738158250938,0.031576347952835704 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark07(-0.49704139890969223,-1.1588674879165023E-12,39.02254641420247,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark07(-0.4999169368496016,-1.9242444798150147E-15,-0.2552042463059807,9.621222399075076E-16 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark07(-0.5000604585420502,-0.048437445824646375,0.25003022927102453,19.186399298810684 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark07(-0.5003598434885196,-9.261078236832703E-15,1.035578085141708,4.653700038059589E-15 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark07(-0.5004690970808352,-3.552713678800501E-15,-100.0,-82.14184830933296 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark07(0.5012978191155297,1.4582772409860847,-51.74574158252511,-1.5145367838904906 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark07(-0.5031737193540002,-0.6090196123126563,1.0369850230744484,-45.24858367084051 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark07(-0.5033516416645842,-0.43011132878322555,-142.03238685997002,-16.15244531589413 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark07(-0.5036774462790952,-0.24372940426849007,0.2518387231395476,0.9072628655316933 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark07(-0.508438961038089,-0.5235987755982779,0.9162978572970184,-58.39113570757911 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark07(-0.5088664970486388,-5.045963646921336E-13,-100.0,-0.785398163397196 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark07(-0.5090034500115479,-0.28663984099996753,-42.10355577578731,-7.151415318399845 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark07(-0.5092397416475966,-2.220446049250313E-16,-100.0,-98.18992853947861 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark07(-0.5109177626611214,-0.22827204723817676,-0.5299392820668876,-15.839945955655379 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark07(-0.5139066557490686,-0.5235987755982986,-0.528444835522914,0.2617993877991493 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark07(-0.5139140434112646,-0.47684988950123536,0.2569570217056323,1.023823108148066 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark07(-0.5151155052107155,-0.32941680460328093,1.02070550079628,97.99419095442 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark07(-0.5151269835547653,-0.30223267993407216,-14.974544949958162,61.17319126330149 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark07(-0.5164431501463987,-0.5235987755982805,-75.36620285141974,-31.597036616931575 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark07(-0.5166677597628068,-0.10110608628329731,-71.50175782024738,94.06067969417505 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark07(-0.5206177616536598,-8.326672684688334E-17,-75.8972822585252,-100.0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark07(-0.5226879965086678,-0.36138436745274116,-63.75527457667656,12.5328619391707 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark07(-0.5254996957659009,-0.06698264680697064,0.37690874291363596,-90.85743021322992 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark07(-0.5315753974794831,-0.1771941994169916,1.05118586213719,-96.51669576750261 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark07(-0.5351245305154539,-0.41787361447653604,0.16418103720350175,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark07(-0.5358813219302905,-0.523598775598281,-99.99999999999275,52.26629442787635 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark07(-0.5363975024620018,-0.24066193127959046,1.0535969146284492,-39.58488202754923 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark07(-0.5414489065978754,-0.5235987755982987,-12.970801066006727,-2073.1225559384193 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark07(-0.5447870669720326,-2.775534917037933E-16,-0.5130046299114319,0.7840832430780219 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark07(-0.5455089747019237,-0.51785661902557,-93.1896260667276,1.0443264729102333 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark07(0.5458824522466466,-0.0019784233867095047,18.608118818387368,9.892116933547523E-4 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark07(-0.5460616946281236,-5.551115123125783E-17,-100.0,-46.333336882974194 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark07(-0.5491102046735827,-1.1102230246251565E-16,-5.115381286302336,0.270453294282217 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark07(-0.5516667271155004,-0.4368691349780861,-58.44627710110427,-61.68720613755065 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark07(-0.5532041233484851,-0.02731668964255209,-128.7824341710181,-0.6704071883817742 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark07(-0.5547857327734893,-8.881784197001252E-16,-12.338910216766003,4.4408920985006257E-16 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark07(-0.5556289111515742,-3.552713678800501E-15,-0.5075837078216612,-100.0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark07(-0.5640021157421086,-0.05302035471738603,-28.771795757030333,-22.326330980962734 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark07(-0.5644452636743149,-0.49796074658028067,-0.5031755315602908,27.572122331133507 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark07(-0.5651014377964214,-0.5235987755982984,-100.0,0.26179938779914913 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark07(-0.5666230829955414,-0.4052193963936969,-100.0,18.82893910598756 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark07(-0.5672550417281298,-0.730263721871446,1.0690256842615131,-45.963543757052925 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark07(-0.5694436518581639,-0.5235987755982983,0.06005840823687039,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark07(-0.5712665156398411,-0.026187559014531053,-0.49976490557752773,0.013093779507265528 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark07(-0.574101502953603,-0.004072524932142995,0.26399007336391817,0.002036262466071498 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark07(-0.5742071705151134,-0.5235987755982987,0.769080072275165,8.103455295336913 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark07(-0.5768389673206058,-0.5235987755982986,1.0738176470577512,25.292605683733797 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark07(-0.578076132715051,-0.0010941949717557695,-0.4963600970399228,-2012.3867237487532 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark07(-0.5787370384726296,-0.3164666423056112,0.01651082321527786,-12.88406633930019 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark07(-0.5804276276766273,-0.5235987755982987,-6.903047353126185,0.26180154114201104 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark07(-0.5822845854680134,-0.5235987755982986,0.27723758807729787,-39.56029723391857 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark07(-0.5829454556205992,-0.005095059034356772,1.0768708912077478,59.98233232272299 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark07(-0.5835694889494877,-0.5235987755982987,-29.765350324280547,1.0471975511965976 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark07(-0.5870818746135644,-2.220446049250313E-16,-100.0,-30.968783353156933 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark07(-0.5871034279768566,-0.5076113854513777,0.29355171398842805,-90.88166973322281 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark07(-0.5878605580241419,-0.5097180748302752,-55.665324094381624,-82.81911847645591 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark07(-0.5884299111617319,-0.08319582551657702,-100.0,-19.476253048593513 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark07(-0.5908991223754874,-0.5235987755982616,-6.646745782631454,17.581390856821642 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark07(-0.6018612622395284,-4.226878297281788E-4,-7.597484472056157,2.1134391486408942E-4 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark07(-0.6061445353838414,-1.1102230246251565E-16,-0.48232589570552764,54.152896830655564 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark07(-0.6062342753185308,-0.296128089439428,-0.4822810257381829,0.9334622081171622 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark07(-0.6104599405819973,-0.5235987755982947,0.32578917791418427,22.063609507719647 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark07(-0.6107638873077584,-1.1102230246251565E-16,-84.73964781933115,1310.2924477899942 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark07(-0.612980261131062,-0.09861414849632703,1.0918882939629793,2.620309376931118 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark07(-0.6136897051011497,-4.078949825607017E-30,-8.692471905061453,2.039474912413362E-30 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark07(-0.6153671399430156,-4.440892098500626E-16,-0.47771459342594047,33.11912347858716 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark07(-0.6180155034886811,-2.3761831063825894E-9,1.0944059151417889,-47.05888149524283 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark07(-0.6180931031084231,-1.4949883491877785E-15,-77.4453721016313,0.7853981633974491 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark07(-0.6187505855161013,-0.07203227047629032,-55.4764055399146,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark07(-0.6194491905445622,-1.1102230246251565E-16,1.0951227586697294,51.90825572282313 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark07(-0.6202178245300268,-1.1102230246251565E-16,1.0955070756624616,-54.40809647597935 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark07(-0.6220822426985428,-0.029771425636774596,0.3110411213492714,103.70615108920893 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark07(-0.6228664302633131,-0.1762842407647774,-0.4739649482657917,-2.055946096675192 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark07(-0.6237623152972378,-5.551115123125783E-17,-57.89025653161909,63.49425437563627 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark07(-0.6265225943945637,-0.007622502623548967,0,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark07(-0.627464239907847,-3.439026841078885E-10,0.31373211995392314,2143.6227082427004 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark07(-0.6282312418912142,-0.3156970061949112,-23.171536200344555,1.035106195788924 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark07(-0.6288325677677886,-0.3650645541825677,0.3144162838838943,-0.7900058164031629 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark07(-0.6293263629395882,-0.20540862961599854,0.533795066690151,-36.831359581792015 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark07(-0.6307860788711772,-0.3036091100585452,0.8171765200013241,-0.6335936083681757 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark07(-0.6308854888867963,-0.5235987755982983,-89.3898624917661,-0.5235987755982991 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark07(-0.6309219389345453,-0.4910580084935256,0.34686733774349215,-79.08168264468398 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark07(-0.6318675746497593,-0.5536227523364463,0.31593378732487964,70.96264835566615 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark07(-0.6324593702020103,-0.31446891524178955,0.31622968510100513,-57.018778016518674 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark07(-0.6376516712679804,-7.070416078529324E-9,0.3188258356339902,61.56528956536242 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark07(-0.6378728243206702,-0.19714930550140697,0.3189364121603351,0.09857465275070344 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark07(-0.6382543212332149,-0.5235987755982987,2.330991805243535,59.68956416972544 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark07(-0.6390950427603977,-0.5235987755982947,-47.222797615680726,54.09537209466171 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark07(-0.6424733281044598,-0.5227875441795927,0.3212366640522299,0.26139377208979636 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark07(-0.6429358380865119,-1.1182107009267561,-74.92532779492277,-21.43245176515435 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark07(-0.6445296074576561,-0.5179054540222775,-82.82546672036452,0.25635711226879104 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark07(-0.6469460556105793,-0.49364275324624884,-100.0,3.648527693525024 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark07(-0.6476828331970059,-0.24753449334411987,-31.4495703522579,-81.79637374982967 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark07(-0.6484588378227887,0.19841944232570957,-100.0,0.6861884422345952 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark07(-0.6501618156932996,-3.552713678800501E-15,1.1104790712440984,2051.2268172365725 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark07(-0.6511303773518378,-0.11748768426075644,-0.4598329747215294,-16.000379287515685 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark07(-0.6512371817625687,-1.0658141040438995E-14,-70.38598311849722,5.329070518200751E-15 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark07(-0.6535676769136327,-0.5235987755982983,-37.80597109540927,-100.0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark07(-0.6556175079026619,-0.08718542364349524,-0.45758940944611726,-0.7418054515757007 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark07(-0.6560963598698767,-0.008066852246856977,1.1134463433323867,-76.88845062610156 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark07(-0.6568377090247629,-0.0416902537365872,100.0,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark07(-0.6570951002606603,-0.210792174826816,-0.45685061326711796,-72.46264839360748 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark07(-0.6575604474964387,-0.4312519659314426,1.1141783871456679,-2019.4880169056526 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark07(-0.6593501656694624,-0.4773656503501401,0.32967508283473135,-5.251861524529117 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark07(-0.6649392595532142,-1.6844051660247675E-16,-99.18833764891302,8.925341831183314E-17 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark07(-0.6653988815230747,-0.0712057845903511,-0.45269872263591093,-11.747635854030563 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark07(-0.665459858741394,-0.5090383287957441,0.332729929370697,84.74630764537358 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark07(-0.6680410222936679,-0.48510476590113605,1.1194186745442822,-0.4918035238021091 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark07(-0.6716895753151082,-8.881784197001252E-16,0.2119811303292296,-54.14319980105526 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark07(-0.6731966273220104,-0.1893411182169427,0,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark07(-0.6736670238687372,-0.06576161292086881,1.1222316753318178,-153.9972641920875 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark07(-0.675076889424,-7.431186498532571E-15,-66.38955685493966,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark07(-0.6779996283227848,-0.5228774752361759,-23.78913309478133,0.2614386331697659 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark07(-0.6820972139297509,-1.3877787807814457E-17,-3.4363331352119615,0.08589963147601054 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark07(-0.6847622862065503,-1.7763568394002505E-15,1.0855436849831732,24.987077487974716 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark07(-0.6853657820271906,-0.4882457807400513,-26.870853919712662,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark07(-0.6886530286224077,-0.5235987755982987,-86.9828646805461,0.26179938779914935 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark07(-0.6902017636923459,-0.19749667046097183,1.1304990452436212,-77.09832877916404 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark07(-0.6911472963830683,-0.5235987755982983,0.34557364819153413,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark07(-0.6915190737219266,0.17054378362686773,-100.0,63.521925051719165 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark07(-0.6924111710279656,-0.3032594794006108,-0.43919257788346533,12.114555337739047 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark07(-0.6937973913994613,-1.3342866232587522,-24.389598389180463,175.05678558585606 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark07(-0.6943786464564143,-0.4334732620602392,-10.38852831495759,87.26655709480372 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark07(-0.6945252759306733,-0.5235987755982983,0.059916156879198754,-46.17626291474129 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark07(-0.6956000736885758,-5.551115123125783E-17,0.3478000368442879,-66.38905460257764 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark07(-0.6978895026940816,-0.49860480822789127,-0.43645341205040744,0.2493024041139456 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark07(-0.6980080157694958,-0.012366219898878967,-61.87846835500918,67.40889085178624 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark07(-0.6990963387229615,-1.7926154220886157E-15,1.1349463327589138,8.96307711044308E-16 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark07(-0.7001089505820854,-0.00424345943517102,1.135452638688491,0.7875198931150338 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark07(-0.7016163232370961,-3.0810148386869344E-11,-89.39504485097413,-64.9919159705903 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark07(-0.7017839223253499,-6.162975822039155E-33,0.49781011140927023,-65.48060938604456 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark07(-0.7052721393984209,-0.246559733725543,1.1380342330966589,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark07(-0.7071183476444708,-1.3877787807814457E-17,-87.83008512985215,1339.1410560962174 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark07(-0.7072620121777489,-0.04535018097920385,-0.43176715730857385,0.8010294668652028 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark07(-0.7073456907824901,-0.10894970443659768,-45.638355474219296,0.8398730156157471 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark07(-0.7101484672546123,-0.0034135473192673316,0.35507423362730617,3.920628966760837 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark07(-0.7112902586690837,-0.053421321054318495,0.35564512933454184,0.8121088239246075 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark07(-0.712439760264644,-0.40353623244171954,-71.43558552796722,79.73878709924648 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark07(-0.7133593917399441,-0.0806267758696528,0.5819529365767269,46.030737985295616 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark07(-0.7160516457289953,-0.04011311342379818,-0.4273723405329506,69.91914150833864 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark07(-0.7175186478975978,-0.3355397200454401,-0.4266388394486498,0.9466230098775644 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark07(-0.7186992039110732,-0.021585902437894267,-100.0,-42.57516910419241 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark07(-0.7228653517843796,-0.523598775598292,-13.153394312627299,-100.0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark07(-0.7242983994562282,-0.21259460447230236,0.3555030661903689,0.10629730223615118 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark07(0.7283827128356862,1.4972169538085578,-0.025162531253393537,-2.7370795043120175 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark07(-0.7290441270349344,-3.552713678800501E-15,-0.4208760998799811,36.177301004891916 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark07(-0.7304988586113126,-0.3033456249535593,-42.392483133359974,-100.0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark07(-0.7327431832485285,-0.32398212343472493,-29.665571180762836,-47.367833309239536 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark07(-0.7337893974489296,-0.513796321179778,0.9590134463299773,-47.088278221323876 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark07(-0.7349016644296134,-0.523598775598298,0.3674508322148067,0.26180227035017 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark07(-0.7354249841251232,-0.09701960048450238,-0.4176856713348867,-27.66909319697247 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark07(-0.7361163148520012,-8.881784197001252E-16,-58.93404157974816,-2.474252327645588 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark07(-0.7363794964597152,-0.5218634877386501,-0.41720841516759066,100.0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark07(-0.7365091274892189,-0.5235987755981135,0.36825456374460946,-0.3416172020349845 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark07(-0.737904192628891,-3.524311659727663E-15,0.3689520963144455,-2.5636550135960494 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark07(-0.7392497936328338,-0.5235987755982663,-100.0,-100.0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark07(-0.7405779736332374,-0.5235987755982939,-171.67110715120043,-20.447008080208406 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark07(-0.7459192905885459,-0.06753707085885631,1.1583578086917212,-48.62070729064375 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark07(-0.7461007720002096,-1.2898502722779715E-7,-100.0,-0.7853980989049346 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark07(-0.7480612188089832,-0.2213817699371226,0.6485118898128848,0.8960890483660096 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark07(0.7486279088601607,-0.0532911284883826,-80.43603783082361,-1.4659492532999951 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark07(0.7519778339588438,-3.944304526105059E-31,-1.1613870803768709,2.7034774313012656E-17 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark07(-0.7525038041794225,-0.4728243194790973,-79.22214382266932,-2120.2612981180846 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark07(-0.752627736268299,-1.4091279846713848E-13,0.3751654977207719,-0.3029413520236914 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark07(-0.7550641083315597,-1.7763568394002505E-15,-3.7423829377557563,8.881784197001254E-16 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark07(-0.7551904602109903,-0.16047725016612624,-82.31277893212382,-100.0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark07(-0.7555437941827101,-0.030789991225156632,-0.9153667824222893,100.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark07(-0.7558800748250647,0.05903617714476676,-88.02237729177787,-0.029518088572383364 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark07(-0.7573117414786736,-0.03531071915472854,-0.4067422926581114,74.66479185683788 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark07(0.7582850062990416,1.7585821851765793,-0.3791425031495208,27.400694835470222 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark07(-0.7584699082250512,-0.2263518772304174,0.3792349541125256,-0.6722222247822396 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark07(-0.760027769326223,-0.1303069358175124,0.3800138846631115,-104.57186471394226 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark07(-0.760380060974147,-0.5107550201788759,-0.42314257939107563,98.33362275110596 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark07(-0.761078545064056,-9.281157865974291E-4,1.1659374359294763,53.657554051687235 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark07(-0.7617847557435815,-0.1067065845708563,-29.94205996691501,0.05335329228542816 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark07(-0.7647324305075076,-0.5235987755982987,-92.25078057238359,1066.4586335569325 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark07(0.7658509946667518,2.941174258945799,-60.685632287234306,-19.531991029691067 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark07(-0.7675931477789886,-0.5235987755982983,-0.40160158950795405,-39.64467705921736 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark07(-0.7684101630733791,-0.5235987755982987,-191.56121608013396,0.26179938779915 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark07(-0.7705852900503467,-0.3926531471518559,-70.88521225153384,-44.2447251240623 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark07(-0.7721706197622766,-0.22069032292889235,-49.04354325894356,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark07(-0.7729240787996574,-0.5235987755982987,-90.4991226130546,0.26179938817936665 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark07(-0.7737835171459317,-1.338566458586792,-61.74492152752791,42.14734684990418 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark07(-0.7738406994044629,-0.5067522225722672,0.5861705627319727,-0.5320220521113157 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark07(-0.7754049416430853,-1.0312979656592179E-30,-91.07667390811892,0.7853981633974483 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark07(-0.7755517718218179,-1.7763568394002505E-15,-0.3823997681833335,-100.0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark07(-0.778521554731991,-0.003926440473705061,-0.3961373860314527,73.04264983677575 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark07(-0.7798999893800256,-0.048856529945240756,-0.39544816870743543,-111.51548777536843 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark07(-0.7815068295829064,-0.010684530116113299,-99.26710819941609,0.005342320306542993 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark07(-0.7833059944606148,-1.4210854715202004E-14,-0.39374516616714095,-0.7853981633974412 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark07(-0.7833331273886536,-6.938893903907228E-18,1.1770647270917751,-44.69433440063775 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark07(-0.7836520663108147,-2.007736738031188E-9,-100.0,1.0038683773139212E-9 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark07(-0.7840977596020762,-1.1102230246251565E-16,-11.882356070208504,22.373468216410885 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark07(-0.784449313126042,-0.01687353377490982,0.392224656563021,71.55769174823375 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark07(-0.784753502081784,-1.775811178502271E-15,-40.61744458822851,8.881784197001252E-16 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark07(-0.7848915657022602,-2.859586424312217E-4,-0.3929523805463182,-68.3373379381136 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark07(-0.7850228883157272,-4.6455870909829047E-20,-16.009950009193137,2.322824075032435E-20 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark07(0.7850833638561755,-8.881784197001252E-16,-103.3249012692954,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark07(-0.7851078505876268,-0.04478094130686823,-100.0,100.0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark07(-0.7852462225975367,-5.499122309524746E-6,-100.0,2.7495611547578847E-6 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853690290090158,-5.557007580938141E-5,-25.29041446896663,2.7785037905760036E-5 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853951250015996,-0.09097815157897471,-31.024213408840403,-0.7399090876079609 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981557845249,-6.889154987537216E-10,-28.6665969351628,0.7853981637090265 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981621471406,-0.10689663986109149,1.1747917591846146,55.767073877004165 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981622009856,-5.950400680815738E-10,-0.3926990822969555,2.9752003404078696E-10 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633299996,-4.3368086899420177E-19,-44.83070643511933,-100.0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633796465,-0.015452241836330876,0.39269908168982326,100.0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633970335,-1.7763568394002505E-15,0.39269908169851675,99.99999999978408 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163397387,-2.5243548967072378E-29,-0.3926990816987548,-0.7853981633974483 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633973879,-2.3757008590050894E-12,1.1780972450961422,67.45348766766503 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974342,-2.7755575615628914E-17,-1893.5877270063863,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974363,-0.5207460586045344,-0.503726040019977,41.73467531268584 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974367,-3.565830570593953E-14,1.1780972450961666,48.17401905558522 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974385,-5.916339935685311E-15,-67.84940020613519,-2152.315228612508 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974403,-1.1102230246251565E-16,-100.0,58.17819034760822 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974407,-5.910702263739608E-15,1.1780972450961686,-64.23919122430152 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974414,-4.98769277513201E-13,1.110933887362682,44.83925390862527 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974453,-2.220446049250313E-16,-75.82710840707148,100.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974453,-4.92164030153175E-14,-1.1493340016134451E-15,-61.5227946950047 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-1.1102230246251565E-16,-18.990592108660238,81.77264893142103 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-1.1550341468459958E-14,1.178097245096171,84.81805156029168 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-1.2277252017000153E-14,-0.3926990816987255,-47.64483129492482 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-1.4210854715202004E-14,-0.3926990817001939,136.49331602844364 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-3.999639433900308E-15,1.178097245096171,0.4259007376861099 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-6.124091736486075E-9,-0.39269908169872547,3.0620458668639827E-9 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974463,-3.968843413048344E-17,1.1780972450961706,0.0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974465,-3.944304526105059E-31,-0.392699081698725,0.0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974473,-5.688223089328458E-15,-106.86624430693344,100.0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974474,-2.3591515390026276E-14,-0.3926990816987246,-100.0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974475,-1.7763568394002505E-15,-100.0,75.45201222614973 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974475,-5.4030741589418457E-14,-0.3926990816987246,-14.92125018423199 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974478,-0.10853236637865193,-0.3926990816987246,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974481,-6.938893903907228E-18,-50.892928568891406,-88.13991008065287 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-0.03480058812199036,-7.700092196219552,-20.556730617066272 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-0.19135501234605584,0.39269908169872414,-0.5606182185970521 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-0.3194193130178099,-112.8769286795591,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-1.3202549560446515E-6,0.39269908169872414,0.7853981633974486 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-1.6228887084915663E-16,2046.3205438782618,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-4.430603705077577E-15,1.1780972450961724,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-4.440892125169301E-16,-100.0,2.220446049250313E-16 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974485,-5.91874392372419E-16,-53.7549630446428,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-1.7575709926508723E-13,1.1780972450961726,54.49386228646742 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974493,-2.1938435113289426E-15,0.7363015612779473,0.0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163397449,-3.882201877024449E-15,0,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974502,-2.4614594673214668E-14,-51.30982741057892,-1587.2749266793767 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark07(-0.78539816339745,-6.3409684534115304E-15,0.1380175238211746,-100.0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633976512,-4.063416270128073E-13,1.1780972450962737,100.0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633977583,-6.368075304997972E-13,-18.399715954378514,-2.3530505189742374 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633979181,-9.538246119819393E-13,1.1780972450964073,32.06052644550863 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981634485279,-1.02160397252307E-10,-100.0,-33.00556887716521 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981634503864,-1.0587638999587733E-10,0.6471394956354323,-70.26438318915608 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981750139991,-2.3233101963564973E-8,-100.0,77.85928885549387 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981780384105,-9.556276257374412E-7,1.1780972524166535,99.99999901755758 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark07(-0.78541911863873,-8.006602294996744E-5,0.392709559319365,-0.760816542825298 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark07(-0.7859936536811385,-0.08719611907099471,1.1783949902380175,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark07(-0.7861514371893876,-0.0015065475838790697,-100.0,-23.489186406591916 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark07(-0.7862721661286028,-0.0017480054624718089,-0.39226208033314686,16.49664699060497 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark07(-0.7863921867906098,-0.0019880467863233734,-46.04528841820371,1704.7596671757642 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark07(-0.7867440273481996,-0.002691727901502835,-91.34822551459544,29.719232448131013 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark07(-0.7880470892101406,-0.012847074260914138,0.1127907821254564,-100.0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark07(-0.788826086372628,-0.007479546365806001,1.1798112065837623,27.002455575829707 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark07(-0.7891110998764393,-0.04384629732400223,-0.39084261345922866,0.02192314866200107 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark07(-0.789591040800574,-0.008385754806251571,-0.39060264299716124,0.11311808872135332 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark07(-0.7915741598015971,-0.012351992808297796,0.5990160765192419,63.484432753082004 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark07(-0.7953141608080676,-0.23025439380685206,1.183055243801482,-0.6702709664940223 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark07(-0.7958811430897784,-0.5101998149727699,0.3979405715448892,-0.5302982559110633 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark07(-0.7975725691198849,-0.04411042189935019,-0.38661187883750575,49.88210538084608 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark07(-0.797970352640097,-0.5235987755982876,-0.3864129870773998,47.958490596103815 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark07(-0.7981566161427379,-0.02551690549058682,-0.3863198553260793,-5.356234738422366 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark07(-0.7982233216137691,-0.5235987755982983,-54.151374992011306,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark07(-0.7985245985402545,-0.44859119481605175,-99.63463709585962,-0.5611025659894224 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark07(-0.8005101365664795,-0.03274360988162989,0.45169382870034713,0.8017699683382773 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark07(-0.8006725027837224,-0.3062148011885544,-52.896183050706696,0.8870606849014185 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark07(-0.8019615551379906,-0.03312678348108518,-0.384417385828453,0.6545783497495137 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark07(-0.8021656548455041,-0.5235987755982987,-0.38431533597469625,32.55061191263492 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark07(-0.8034381061017001,-0.4770994353825532,0.9162978572969007,2229.202111916841 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark07(-0.8043877545550968,-0.03797918231529719,-0.3832042861198999,100.0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark07(-0.8063365035120658,-0.14349704189165222,-100.0,52.96476677278606 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark07(-0.8071049435982651,-0.04341356040163391,-0.11326086002220892,-0.7636913831966313 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark07(-0.807505166010636,-0.044215908060001655,0.7337045675147668,0.022107954061543977 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark07(-0.8082266408552317,-0.5235987755982947,-0.38128484296983245,-62.622867987106616 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark07(-0.8090287143144024,-0.04750758738555866,-67.28157542747488,0.8091519570902275 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark07(-0.8090684220514474,-0.5235987755982987,0.4045342110257236,23.46683606830464 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark07(-0.8098301111578098,-0.497560336173073,-39.83656835248273,1.0341783314839847 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark07(-0.8109230841240127,-0.7038800116084881,-0.25522199277447943,-61.410181536396465 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark07(0.811126177016026,1.6222523540320584,-0.405563088508013,83.2369750482117 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark07(-0.8117272551055978,-0.052658183416305564,1.1912617909502472,83.3071501793816 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark07(-0.8121359346281698,-0.05347554246144371,-0.3793301960833634,0.8107115388716015 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark07(-0.8124246699587644,-0.05405301312263533,0.1802794181642895,-64.70446434721778 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark07(-0.813497173212658,-0.5235987755982732,1.0906453790399837,-56.08213068626278 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark07(-0.8144760123924535,-0.0581556979900108,-1.215707292220753,43.91422163660039 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark07(-0.8146921336363374,-0.07594051675174211,-34.43883761432749,0.03797025837587098 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark07(-0.8168703603900132,-0.5235987755982987,-100.0,36.36631384956581 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark07(-0.8178693201261503,-0.5235987755981102,1.1943328234605235,74.22779916445178 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark07(-0.8186456071661832,-0.06649488753746993,-45.17153004320308,-3.2178503654175126 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark07(-0.8203855621642384,-0.8983416011604866,1.1955909444795674,37.057678227026884 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark07(-0.8215576182916381,-1.643115236583276,1.1961769725432674,-16.45719783798987 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark07(0.8218587980612198,1.719315576397455,-0.41250173411200625,-99.95450020763873 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark07(-0.821977543254766,-0.07315875971464238,-54.68950992397302,0.036579379857320404 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark07(-0.8230507034342005,-0.5235987755982983,0.41152535171710003,-0.5235987755982991 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark07(-0.823127904199387,-0.07733703717591714,0.41156395209969343,-56.40270098710075 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark07(-0.8237400130004859,-0.07668369920607582,-0.3735281568972053,1.4693073836265451 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark07(-0.8241833333534917,-0.523598775598275,0.4120916666767092,0.2617993877991374 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark07(-0.8270034379529925,-0.523598775598286,-6.475586133885927,100.0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark07(-0.82764334906377,-0.5089655081152004,-24.902168792345076,-0.530915409339848 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark07(-0.8296619380567422,-0.08877047883505709,-0.37056719436907726,-75.53510642262533 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark07(-0.8298313621162563,-0.0888663974376176,-29.9388572527019,100.0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark07(-0.8333298357148458,-0.5235987755982947,-0.3687332455400254,-39.12739871582024 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark07(-0.8342919539113852,-0.16697729944903128,-47.47331590282484,-9.605588980385619 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark07(-0.8363714629485912,-0.10194659910230047,1.2035838948717439,17.49887183714644 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark07(-0.8364217054943108,-0.31612655252985267,0.4182108527471553,-16.745440092793352 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark07(-0.8409984024565129,-0.11286217905775196,-54.62415249633114,0.8418292529263244 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark07(-0.8445526261461981,-0.5108790390046021,0.42227631307309904,43.98326378277651 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark07(-0.8448271285273545,-0.26553228956686364,1.2078117276611255,0.8094725003064097 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark07(-0.8450003284403774,-0.5235987755982983,-65.62282647722392,-50.89678324307551 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark07(-0.8454747456893301,-0.36162770554254287,-75.67061420330883,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark07(-0.8473047422653112,-0.12381315773572596,1.2090505345299858,0.8459898218598247 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark07(-0.8487463717839773,-0.4097164566673206,-83.7988470951335,41.27686253874734 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark07(-0.8488662135739811,-0.5235987755982987,-33.82417048394683,-43.343940338222396 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark07(-0.8490990633846622,-0.26277176162173443,-44.88623395546655,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark07(-0.8503756807034932,-0.5173665974600229,-74.63447852979012,6.613359868815993 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark07(-0.8510364552053817,-0.5235987731401965,-193.01764456253218,-71.18723052457578 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark07(-0.8542065632483415,-0.17784430284413436,0.8982710600364383,175.97054954594236 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark07(-0.8548098817520378,-0.5104253694075274,-100.0,1.040610848101212 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark07(-0.8558420925030379,-0.5235987755911905,-0.35747711714592934,1.0471975511930436 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark07(-0.8583303600317801,-0.4564457795475997,1.2145633434133383,-0.5229475393113523 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark07(-0.8591061310748426,-0.5235987755982877,1.2149512289348696,0.2617993877991438 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark07(-0.8602428766365184,-0.14975050538771653,0.4746930437052188,-73.76450289098642 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark07(-0.8608140756080096,-0.15083182442112225,1.5094963481815358,3.848236122913454 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark07(-0.861416197642943,-0.5235987755982947,-20.217854802103602,1.0471975511965956 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark07(-0.8624749073140495,-0.46882498750367646,0.43123745365702476,-10.278445920794574 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark07(-0.8636139104921025,-0.15643149418930852,-100.0,-34.177528155079955 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark07(-0.8642938236255782,-0.513398246338007,0.4321469118127891,44.4047088554482 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark07(-0.8645596539039987,-0.21846151353461923,-0.35311780758561717,0.10923075676730963 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark07(-0.8662506501706483,-0.20052408987353842,-81.50555126565006,62.803117937663835 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark07(0.8675615320850625,1.7351230641701565,-0.43378076604253124,238.6730917121581 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark07(-0.8682955311644065,-0.18192055087876982,-74.11956832031015,-29.92999242736503 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark07(-0.8713162964075423,-0.5097177263638132,-3.438513849647835,0.25485886318190654 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark07(-0.8714944255146959,-0.40595629323996774,1.0782111205908118,-100.0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark07(0.8721917563873625,2.080661533706454,-0.7964250902719975,-100.0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark07(-0.8755541355863213,-0.18031194437774628,-0.3476210956042876,0.09015597218887313 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark07(-0.875838592474663,-0.4389581249403831,1.214047087150374,14.055579468019701 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark07(-0.8796415789994048,-0.5235987755982987,0.5235987755982974,30.2075826618512 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark07(-0.8801596215638006,-0.37529685934407286,-0.345318352615548,0.289067965696684 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark07(-0.8808708467953237,-0.4513013466220719,-0.34496273999978644,91.56209319766852 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark07(-0.8844264646212356,-0.19805660244757903,-0.3431849310868304,59.6411305936963 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark07(-0.8852449413422702,-0.24356545755155248,1.2280206340685833,-3.1812934585690433 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark07(-0.8852726909483302,-0.5235987755982983,0.4426363454741651,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark07(-0.889239887071168,-0.5164694659185154,-30.49600491889591,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark07(-0.8895474415996327,-0.24441849104758895,-94.34363959668138,-78.92281934675802 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark07(-0.8900607842131578,-0.3367830943329231,-0.3403677712908695,1891.6588872325347 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark07(-0.8904984723700378,-0.5216238158329203,-0.3401489272124294,1.0462100713139084 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark07(-0.8917119138218652,-0.21262750084883436,16.255591462498217,88.69530717499389 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark07(-0.8921982855364998,-0.4121719374384868,-16.395016694756013,-20.831624719267168 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark07(-0.8925444490712189,-0.21429257134754162,-44.26004552839098,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark07(-0.8934510714548592,-0.38612978302422385,-91.73175618325335,-91.16777746191988 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark07(-0.897863824287247,-0.2672308747273276,-0.3364662512538248,-75.62277337959905 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark07(-0.8997612897047935,-0.24218165757126203,-0.3355175185450515,0.9064889921830793 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark07(-0.9019812325870107,-0.5235987755982987,-189.79105790707285,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark07(-0.9023679596469655,-0.5235987755982983,-96.61097158326558,-87.92285012208961 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark07(-0.904044624018145,-0.3935538562343585,1.1975093767369231,-0.588621235280269 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark07(-0.9040528535722032,-0.5235987755982987,1.2374245901835499,-27.270698708798207 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark07(-0.90575296841567,-0.24070961003647134,-0.3325216791896133,25.711366031253153 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark07(-0.9070045649485858,-0.5156603356342236,1.2389004458717412,81.49213654964701 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark07(-0.9082624424230141,-0.5046942137429564,-119.24934452140407,-0.5326463139788843 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark07(-0.9101327400374863,-0.2494691532800763,-15.362062710524768,-39.17859011527528 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark07(-0.9110449685241405,-0.47404941294122793,1.2409206476595185,1316.0232934215526 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark07(-0.9112737382476874,-0.34326573086355056,-3.137349006812869,0.1478410654343718 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark07(-0.9115530847591646,-0.2523098427234331,-31.34061074981762,23.28602280562132 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark07(-0.9129926008364919,-0.47589751762611776,-18.558366792078367,63.41885681163493 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark07(-0.91393266854665,-0.37301172958700923,-0.28956908891479216,-59.573204131380436 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark07(-0.9160729977465433,-0.5235987755982819,-41.30878325816099,100.0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark07(-0.9161585235429895,-0.3680050326259811,1.243477425168943,73.61721574685096 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark07(-0.9162274849722731,-0.37781088703614396,-0.3272844209113117,-39.19260639460593 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark07(-0.9164412958613491,-0.26208626492780507,0.4582206479306746,-79.96818522061635 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark07(-0.916858822684721,-0.5235987755982987,0.9951816146948443,-100.0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark07(-0.9177938192804095,-0.27455816158133456,-49.87574775004313,0.13727908076631704 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark07(-0.9186158589541544,-0.26643539111341275,-38.426897582461244,0.13321769555670637 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark07(-0.9222643702066725,-0.5235987755982987,-129.9897226690865,-0.16285318510176322 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark07(-0.9222766748476625,-0.5235987755982987,0.7692760798439031,1.0471975511965976 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark07(-0.9234795833386764,-0.34835944856479084,0.4617397916693383,78.51458565122546 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark07(-0.9237519958177529,-0.2767076648406206,-13.767951131348354,5.4578919181230106 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark07(-0.9239626426167775,-0.3187375869004334,0.3160791037861611,0.15936879345021648 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark07(-0.9240789703906812,-0.3533575235394433,-53.65071276968818,61.45886839002962 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark07(-0.925406102073563,-0.5235987755982987,-72.08512464016951,-73.91599487655427 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark07(-0.930232833980208,-0.2898892757047931,-0.32028174640734436,0.028687867510274856 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark07(-0.9302583655468275,-0.2897204042987586,-54.558167594764946,-68.64637998030604 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark07(-0.932379194092527,-0.38441372173791627,1.2515877604437118,15.787822845145797 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark07(-0.933431623534075,-0.5235987749106593,-0.31868235163041075,-0.5235987759421186 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark07(-0.9339949806913881,-0.45142338050917374,-200.91018292781948,-72.02744604048033 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark07(-0.9348244769883391,-0.5235987755982988,0,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark07(-0.9369541005853343,-0.30311583775444745,-12.840578658921501,100.0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark07(0.9396352533871665,1.8845476575088365,-202.9777950264133,-10.184720637332173 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark07(-0.941325424037192,-0.5189153071942999,-0.31473545137885234,-10.507878325929909 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark07(-0.9416397023783573,-0.5235987755982974,0.473353884704234,1.047197551196597 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark07(-0.9434646235090075,-0.5235987755982858,10.100685460698646,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark07(-0.9478193779989884,-0.5235987755982983,-0.30882225790801243,-80.99493774809287 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark07(-0.9488894510842774,-0.34253786250591084,0.4744447255421387,91.98789039063732 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark07(-0.9507735494801688,-0.33075077216544124,0.9701135512944827,0.16532159559387033 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark07(-0.9510652409658871,-0.5235987755982947,-15.944794864878991,0.2618054003516383 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark07(-0.9516314673238988,-0.5235987751673808,0.5235987755982995,0.25484851050729473 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark07(-0.9532212986776875,-0.5235987755982947,0.4766106493388437,2046.7799645106586 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark07(-0.9556066696776054,-0.5235987755982983,-19.17369229899427,-0.5235987755982983 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark07(-0.9567613410940459,-0.5235987755982983,0.7064199838628111,12.169750563440441 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark07(-0.9575447261787384,-0.3442931255625806,-45.09266478828053,-1099.6814116346827 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark07(-0.957568055845157,-0.5235987755982988,-95.49126605316339,-0.5235987755982989 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark07(-0.9576482882518265,-0.5235987755982987,-0.8341409773431111,19.638213923024903 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark07(-0.9581652344354374,-0.397163918464093,0.4790826172177186,-0.5868162041654018 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark07(-0.9590678271734937,-0.3473393275521398,-100.0,0.7512774151842279 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark07(-0.9636291504693917,-0.4541248533575836,-54.66043832876708,-27.43653312451309 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark07(-0.9638825512209355,-0.3569687756469768,0.48194127561046773,91.61554048592595 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark07(-0.9645633861969937,-0.5235987755982987,-47.75908581284954,-100.0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark07(-0.9649933263928908,-0.5228244982997509,-0.3029015002010029,100.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark07(-0.9656613725307999,-0.3605264182667056,-0.30256747713204835,-0.9375979203588279 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark07(-0.9681232969968179,-0.5231079431722186,-0.3013365148990393,-26.530878181233916 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark07(-0.9701788283571069,-0.5009145776453028,0.22144352915341908,-59.62148543490865 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark07(-0.9713417545731188,-0.5022873471858441,-31.366450847580726,7.946931243840656 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark07(0.9721451105226073,2.361323908190193,-44.96065968681149,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark07(-0.9739419172291217,-0.37708750766334737,-53.663444086105265,0.18854375383167365 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark07(-0.9739465634518352,-0.5235987755982945,0.4869732817259176,100.0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark07(-0.9758344223830693,-0.3808725179712673,-100.0,100.0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark07(-0.9773455714456829,-0.5235987755982947,-100.0,71.64590253750166 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark07(-0.97779765599754,-0.4534498995484971,0.48889882799877,246.86101317820345 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark07(-0.9801329586006937,-0.4030868933817552,-0.2953316840971015,6.982806042406704 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark07(-0.9828415279240068,-0.5076870325786261,-0.29397739943544493,-41.1451384185237 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark07(-0.9865603364631974,-0.42664746320267855,-100.0,172.00664737836553 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark07(0.9868516668307182,1.9737057228779782,-1.2788239968128075,43.802574342772196 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark07(-0.987981602458704,-0.5235987755978934,-0.29140736216809615,0.26179938779894674 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark07(-0.9894221529115947,-0.5180650050047839,-0.2906870869416478,-79.36638073307931 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark07(-0.9896338596867192,-0.47996358074164713,0.4948169298433596,0.23998178790004535 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark07(-0.9898045238986846,-0.42468764979856466,-80.47568717345763,0.9977419882967306 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark07(-0.9921152065971491,-0.41343408640201246,0.49605760329922916,29.40839608537899 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark07(-0.9925109062242572,-0.43029961599465155,-0.2891427102853196,13.565603665434526 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark07(-0.9936014610790886,-0.41640659536328095,-8.728005198777169,-67.09152919586177 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark07(-0.9960644341727638,-0.42449471670722455,0.4980322170863819,0.21224735832343264 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark07(-0.9977613364505754,-0.512022212740702,-85.05243217716375,99.99999999999976 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark07(-0.9993984473700417,-0.5235987755982983,0.49969922368127634,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark07(-1.0001787090756435,-0.4346030576246415,-23.07615846777697,1958.8754835526702 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark07(10.00476359189742,20.869971473779206,-4.4844872571161405,-70.12524488099615 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark07(-1.0006429224503728,-0.49360453521260106,-38.63304757486752,-82.08288983977573 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark07(-1.0020422251361314,-0.5235359160619651,-0.2843770508293826,-78.77118359763288 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark07(-1.0028578783663573,-0.434919429937896,-65.054204824911,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark07(-1.0035480002702877,-0.43629967374567896,1.2871721635325921,-50.07312099661381 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark07(-1.0045978149844004,-0.43853688539508545,0.9359468127021235,72.72462131096093 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark07(-1.0049365318318226,-0.5235987755982987,-156.89536352597906,0.7853981633974483 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark07(-1.005665864247628,-0.44188185082264747,0.502832932123814,-48.14835144773081 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark07(-1.0060465053309555,-1.1515512591425237,-4.268913957527476,-78.74951048827398 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark07(-1.006627092487045,-0.5235987755982987,-0.11565348385489205,-22.91964061407998 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark07(-1.008158198563482,-0.4455200703321605,0.504079099281741,39.50585390890052 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark07(-1.009572791983677,-0.5235987755982999,-87.66475780678097,0.26179938779914996 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark07(-1.0096462616215318,-0.5235987755982985,-0.2805750325866823,4.182008148675635 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark07(-1.0120250855780504,-0.4532539519593944,1.2914107061864735,103.00911407749265 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark07(-1.0122071696341233,-0.4536180124733659,-0.2792945785803867,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark07(-1.0126312878657624,-0.5235987755982734,-84.92687135596083,-90.06218809158266 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark07(-1.013339604730644,-0.4558881921182336,-86.67252486873757,1.013342259456565 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark07(-1.0135573713410668,-0.4563184158872884,-34.40348769787208,0.08744008309791695 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark07(-1.0143849838067807,-0.457973640818665,-100.0,-18.202325009686852 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark07(-1.017217520705287,-0.47026749137525015,-0.27678940304480476,-0.5502644177098233 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark07(-1.0181679539715773,-0.5104991427241181,-12.342725229962268,5.879554276212214 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark07(-1.0182193538629927,-0.4656423809310893,1.0054194926944642,-100.0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark07(-1.0187202095087866,-0.5235987755982947,0.5093601047543931,-18.905515798665615 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark07(-1.019205348861645,-0.49502880327638693,-0.15920073190340478,78.77275277556578 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark07(-1.0200336924751165,-0.5235987755982987,1.2954150096350066,-91.1474447379653 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark07(-1.0225026813907112,-0.47420903598652603,0.5112513406953556,-45.12822259129823 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark07(-1.0225835561702912,-0.47437078560788193,-9.698777852301017,1.0225835562013892 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark07(-1.0232377182011851,-0.4756791096079699,-0.2737793042968557,1.0232377182014332 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark07(-1.0233517626334567,-0.5235987755982983,-0.21096180300805978,-1859.9526590081953 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark07(-1.0252722392718345,-0.47974815174877267,7.727325405055388,0.23376562734941997 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark07(-1.026335078128966,-0.4818738294630421,-100.0,-1762.9385769606556 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark07(-1.0268421747683507,-0.48288802274180515,0.7304764672899497,1.0268421747683507 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark07(-1.0287388854116903,-0.48864781673687846,-100.0,-42.95126015817178 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark07(-1.0301450313698408,-0.4894937362256684,-100.0,-100.0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark07(-1.03015881923349,-0.48952131167208374,0.515079409616745,66.55683933522003 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark07(-1.0311306219807732,-0.5235987755982929,1.3009634743878349,-0.5235987755983018 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark07(-1.0319753355185497,-0.5229893757260324,0.5159876677592748,1.0468928512604663 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark07(-1.03242606348161,-0.5235987755982983,-26.38438596062675,0.26179938779914924 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark07(-1.0332108368224198,-0.4956253468499481,0.5166054184112063,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark07(-1.0332297799438281,-0.4956632330927605,0.5166148899719141,-20.872071512260927 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark07(-1.033337581456216,-0.49587883611753564,1.3020669541255563,-39.803110715953544 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark07(-1.033346219737609,-0.5235987755982972,-24.864476968773243,99.19953160787719 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark07(-1.0334094903885351,-0.5025508665384654,-92.42720811296657,0.2512754332692327 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark07(-1.0338060676807914,-0.5235987755982983,-38.499875616054176,-3.6500712144501692 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark07(-1.033861764250143,-0.5235987755982965,1.3023290455225198,12.343036670890516 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark07(-1.0340995513054403,-0.5235987755982983,0.3408981483611937,-64.2872375525631 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark07(-1.0343919313619763,-0.49798753592905626,-53.81860710890487,2159.5207026855496 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark07(-1.0347566324714002,-0.5074536849843168,-0.26801984716174826,-31.46272112934937 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark07(-1.036393133883247,-0.5019899409715978,1.3035947303390718,0.20975019360918418 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark07(-1.0371449743138956,-0.5235987755965913,0.5243538570454833,-58.82119716563558 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark07(-1.037295350999473,-0.5037943752040495,-2.6792907010474494,-49.365560504327476 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark07(-1.037794076224784,-0.5235987755982981,-0.26650112528505643,31.66332103006769 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark07(-1.0383484214264957,-0.5218285336629155,1.3005330306358402,0.26091426683145774 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark07(-10.388646958340985,-47.98047655474584,-49.34612482348386,98.2760225781648 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark07(-1.0400421074189146,-0.5235987755982876,-56.83730672950405,-64.42000082064995 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark07(-1.0404211123566145,-0.5100458979183367,-65.76944833361108,-0.5303752144382798 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark07(-1.0404306427416936,-0.5180732409241893,1.305613484768295,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark07(-1.0409509856097983,-0.5111056444247003,0.5204754928048991,-56.40069155729155 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark07(-1.0413237415385554,-0.5235987755982947,0.5206618707692777,1.0471975511965952 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark07(-1.0415705767191008,-0.5123448266433053,1.3061834517569988,0.25617241332165264 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark07(-1.0426140214424788,-0.5144317160900613,-0.26409115267620886,-29.533884828830512 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark07(-1.0433696887392703,-0.5214590711804657,0.5216848443696351,1.046127698987681 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark07(-1.0440532010492873,-0.5174454767983344,1.307424763922092,16.74454405645292 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark07(-1.044206429102701,-0.5176165314105055,-100.0,-0.5235987755982983 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark07(-1.044328660297101,-0.5226403489017285,-0.2632338332488977,55.29656581257835 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark07(-1.0452150739326203,-0.5196338210703442,-0.26279062643113815,-15.450486080074482 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark07(-1.045650353416011,-0.520504380037126,0.37244358100822617,-90.84213379545947 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark07(-1.0456820675445282,-0.5232558299554775,0.5228410337722641,-53.14583096114737 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark07(-1.0457969360640584,-0.5207975453332205,0.6715887186553652,99.99695059683626 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark07(-1.0458732714839547,-0.5227310800461907,1.3083347991394256,0.261365389241201 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark07(-1.0462211595436135,-0.5216459955321904,-27.317185888831833,0.17379740600979032 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark07(-1.0462433147248105,-0.522292311251115,-57.635034310799014,-24.62864532003592 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark07(-1.0462745440631172,-0.5234347482351752,1.3085354354290069,78.92660587764131 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark07(-1.046507226295342,-0.5235987755982987,0.523253613147671,-54.641393576164944 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark07(-1.0465216454829473,-0.5224282721229121,1.308658986138922,52.38255819324381 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark07(-1.0467667413979265,-0.5235987755982983,0.5235987755983,1.0458826308771925 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark07(-1.0468176179284665,-0.5232939924212601,0.5234088089642333,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark07(-1.0468345415449472,-0.5235987755982965,-0.2619808926249747,1.0471975511965965 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark07(-1.0469830003862501,-0.5235987755023258,-62.746478286912975,-0.5235987755982986 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark07(-1.0470230605213788,-0.523581910610423,-0.26188663313675886,0.26202485658423813 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark07(-1.047153780835114,-0.5235112348757539,-47.96383319037966,-21.64496743242509 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471592518786892,-0.5235959399472604,1.3089777893367929,1.0471961333710784 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark07(-1.047163760418681,-0.5235313807109947,0.5235818802093405,16.89251437335622 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471941113596361,-0.5235918959243759,-2295.84769603479,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551192271,-0.523598775589646,1.3089969389935838,-14.662090193540275 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511963931,-0.5235987755978899,-86.80646379609254,20.552923253426837 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965388,-0.5235987755981812,0.5235987755982694,100.0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196553,-0.5235987755982108,0.5235987755982769,59.095046217612435 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965645,-0.5235987755982338,0.5235987755982822,0.2617993877991169 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965823,-0.5235987755982983,0.13507280383131492,0.036428272375717774 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965894,-0.5235987755982825,1.308996938995743,-60.865911138120474 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965894,-0.5235987755982947,-46.61646150482912,0.26179938779914735 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196594,-0.5235987755982918,-22.201652981510804,-6.712150475997117 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196594,-0.5235987755982973,-59.18116689955011,1.0471975511966072 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965943,-0.5235987755982985,1.3089969389957454,-8.25688584059303 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965947,-0.5235987755982932,1.3089969389957457,-44.18051545595969 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965947,-0.5235987755982938,1.3089969389957457,0.046748248084420505 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965947,-0.5235987755982965,-0.2617993877991509,-53.295018742206125 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965956,-0.5235987755982977,0.5235987755982978,-0.5235987755982994 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965956,-0.5235987755982984,-0.26179938779915046,40.08390262311542 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982974,51.04118204331759,0.2617993877991487 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982981,-27.44439489513246,77.95201312051692 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,-100.0,51.710643228829966 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,-100.0,80.97876044355482 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,1.3089969389957457,-63.97219756190737 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982984,-99.00492194118588,-0.523598775598299 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196597,-0.5235987755982976,0.5235987755982985,2.7601145287693605 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196597,-0.5235987755982977,1.0309270356396647,-24.825813232028302 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965972,-0.5235987755982983,-100.0,-56.756145003787005 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982985,0.5235987755982987,-81.40410294640161 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982985,-39.09668879871933,-82.67591179442799 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982986,-100.0,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982987,0.5235987755982989,0.2198638368564545 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982987,1.308996938995747,-7.603899091741422 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982987,-33.91067317339708,-2.6616647270382754 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196598,-0.5235987755982998,-68.63675181654646,0.26179938779914985 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark07(-1.0619307539917453,0.07276107653438645,-100.0,0.7493220029420112 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark07(-1.0629053631604801,0.0661414115616111,-100.0,21.95807594681696 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark07(-1.0635791415189657,-0.5566535192935825,-100.0,-0.6150751613741476 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark07(-1.0658141036401503E-14,-8.769379736440316E-31,-56.260680341677414,-60.51909033304351 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark07(-1.0682157935348178,-0.5234068678475087,-100.0,40.63356296787716 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark07(-1.0688939392534622,-0.5669915517120281,-0.2509511937707172,-0.5019023875414343 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark07(-1.0887198620575163,-0.6066433973201362,1.3297580944262064,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark07(-1.0921391360541892,-2.1743219950325043,0.5460695680270949,1.8775372994516388 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark07(1.1016136523914473,-0.44231851232854985,-164.4717979774263,-33.37641700698604 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark07(-1.1025233957943083E-16,-5.551083495792103E-17,0.7853981633974483,-0.7853981633974483 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark07(-1.1090347614510373E-6,-1.0282565084784016E-6,-100.0,90.50454932294096 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark07(-1.1102230246251565E-15,-1.7763568394002505E-15,2380.5798270127657,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark07(-1.1102230246251565E-16,-1.223159829645964E-16,0.7853981633974483,95.09552424554218 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark07(-1.1102712313351173,-0.523596141300593,-15.155037461388092,0.2617980706502965 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark07(-1.117036800983694,-1.7516230804060213E-46,50.8700672693623,4.567678659444203E-31 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark07(-1.1187681262893323E-4,-2.237536252578511E-4,5.5938406314466615E-5,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark07(-11.28661530838474,-21.506866330009313,6.102196434805316,26.42599329519466 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark07(-11.317939292737844,-0.5235987755925023,4.865433436512975,0.2617993877961873 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark07(1.1372443823545564,2.2752753221059376,-0.5686221911772783,-74.138790338324 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark07(-1.1399615139544651E-14,-2.1297773347788084E-14,-0.7853981633974483,-1878.1150411647745 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark07(-1.1616811409271828,-1.5210299631044126,0.5808405704635914,1.5459131449496546 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark07(-1.1686818535716914,-1.0768493135267827,-0.20105723661160257,140.92639493592725 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark07(1.185936793842595,2.3744495158525454,-0.5929683969212975,-2.0485957716194454 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark07(1.195201416440391,1.0606687841525726,-1.329313049470783,-1.3157325554737345 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark07(-1.2024569560349843,-0.869096238808658,1.3629899026239358,16.615213097782373 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark07(1.2261645986892646,2.5992789531771163,-1.339591945572381,15.176040028933775 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark07(-1.2404863950049005,-0.9101764632149049,0.6202431975024503,0.4550882316074524 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark07(-12.44243149851724,-0.5235987755982983,-166.6110010054902,0.249318147455726 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark07(-1.2538956321581776,-0.9369949375214588,-100.0,-0.3169006946367189 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark07(-1.257034798257426,-1.0957060132174372,-0.10647074403967294,-100.0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark07(-1.2610501916412753,-2.081925931373681,-6.066071264546711,120.42147238476417 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark07(1.2621823875913676,-2.1175823681357508E-22,-93.02265161229174,41.39127252850371 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark07(12.635759059142513,25.27154745289233,-100.0,-11.85037669124943 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark07(-12.700357052567371,-21.453766160239457,-7.50159266850352,-136.15364161535214 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark07(-12.824173043665207,-24.07754976053552,7.197484685230052,100.0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark07(-1.2859124876030137E-10,-2.571823904696218E-10,-23.387900542650197,71.89364783037007 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark07(-13.06155172192225,-0.5235987755982968,3.316172958609991,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark07(-1.3412921450537975E-15,-1.7810814347831333E-15,-0.7853981633974476,60.554139226541594 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark07(-13.430886757250981,-26.861773514501962,0,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark07(-1.3567379286114392,-0.5235987755982987,-182.5857706702784,0.180038525028553 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark07(-1.3614275787510504,-1.1520588307125263,0.6807137893757734,-99.99999999941578 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark07(-13.626546784484134,-0.5137880875747071,-103.85590719308573,0.2567358012676612 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark07(1.3636263230194403,3.986444649468772,-1.4672113249071685,-93.09940197240435 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark07(-13.673831021814063,-25.776865716833232,-68.12179093475535,31.7379887365357 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark07(13.788456932134421,27.69523739847295,-73.93682717528462,-59.39516311155576 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark07(-1.3851174938421968E-17,-1.3877787807814457E-17,6.938893903907228E-18,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark07(1.3904990626507954,2.8617686493422068,-1.327606573720718,-75.25831163186628 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark07(1.4022133186254433,3.0717822981069247,-0.4210995257593657,62.86675824953733 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark07(14.265084212964902,28.904799999349567,-60.510857591582784,-19.948179595652277 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark07(-1.4268007408020296,-1.2828051772251112,-0.07199779299643345,-49.88666049795093 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark07(1.4284330976095352,2.8568662934422715,0.07118161459268069,12.076473326467678 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark07(-14.395665747715388,-0.5235987755982987,3.983230968051337,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark07(-1.4455318375281447,-1.845351807469669,1.5081640821615205,-32.07306720404881 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark07(-14.463756220365227,44.05340535088121,0,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark07(-1.4483991908571827E-13,-1.7617030602416467E-14,0.7853981633975207,8.808515301208237E-15 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark07(-1.4490954935376266,-45.545429809363334,-84.04733676866726,57.614970734082874 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark07(-1.4744245681749555,-2.3291962780408495,0.7372611771813347,-78.9460138278534 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark07(-1.4835889627917709E-8,-2.9671779052319003E-8,-75.56650978022608,45.33989439679122 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark07(1.4894735381111488,-3.552713678800501E-15,-5.19645735563094,72.28919033258641 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark07(-1.4905568345512372,-1.410317342307578,-0.04011974612182967,-25.999805941914268 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark07(-14.909504832808633,-28.249523472891614,-98.24679159074309,-41.63851472924687 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark07(-1.534190024809147E-14,-5.0300074395751475E-26,-0.7853981633974406,-93.08196691864204 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark07(-1.5363174986746193,-2.2662907000609396,0.9624231134650244,1.1331453500304698 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark07(1.5486879351594833,3.0973758746557123,-31.42516196905465,-1.548687935159517 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark07(-1.56192982974679,-0.5235987755982983,-100.0,-49.02351552560187 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark07(-1.5987211554602254E-14,-6.3108872417680944E-30,-10.05122273373462,20.78089098862894 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark07(-16.079524349274962,-30.58825237175503,0,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark07(-1.6089684928777974,-1.647156784177113,0.8052147902902661,1.6103407583142033 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark07(1.6218012203957912,3.2437038839139096,-100.0,-15.543947048747537 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark07(1.6710282567666606,3.36138542907795,-0.050115964985881986,-69.59871406698983 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark07(1.6818398621292612,-1.3877787807814457E-17,14.86704592870335,27.750423099572558 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark07(17.126919430694613,-83.41119841550324,-94.67998122106216,91.76961209586537 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark07(-1.7166467677537938,-1.8625654587460856,0.0729252204794486,1.7184874355707696 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark07(-17.456555381563035,-34.90438002140992,-63.22414720223051,15.381393783279607 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark07(1.7624063608556109,3.5271559134563693,-100.0,-24.522980478315702 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark07(-1.7717939002579013,-2.565756076682732,0.8858969501289508,14.343568830424465 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark07(-1.772178883922536E-15,-1.1235928451381044E-15,-0.7853981633974474,-21.04602873300206 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark07(-1.7763568394002505E-15,-1.5777218104420236E-30,-41.56232457574823,-60.09179497410485 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark07(-1.7763568394002505E-15,-1.7763568394002505E-15,-0.7853981633974474,-8.63192976504606 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark07(-1.7763568394002505E-15,-2.7094359633102395E-15,-80.36353845405397,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark07(1.7769204030516108,4.277427872209738,-96.94477796301541,-47.65262872660738 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark07(-17.820320216467497,-35.57077847084142,-35.14914776297462,17.78538923542071 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark07(-1.8305447349571846,-0.5235987755982985,-144.41772905068618,100.0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark07(1.8375679887791623,3.6751359775636763,-89.65778199988328,-100.0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark07(-1.8428614993776284,-0.5072736481353577,-80.76002533935998,0.25363682406767885 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark07(1.8436697033021183,3.687372058661588,-60.18817087742329,-100.0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark07(-1.8789715496082535,-0.02592955639231853,-29.941057573526678,0.012964778196159266 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark07(1.886824648188096,3.7736492963780592,-85.58731613464042,-1.886824648188103 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark07(-19.301318773734536,23.693157998399045,48.77449808603146,-64.64228641029636 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark07(-19.36850366604412,34.949195982373936,-71.42644054902645,-28.070136179631902 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark07(-19.420723869194283,-0.5235987755982947,60.7612425554269,-100.0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark07(-1.9465084989012922,-3.883788447723771,0.1878560860531978,93.04808109674292 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark07(19.488857298090792,40.38333513068849,-9.744428649045396,-10.801834184222324 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark07(-1.97753296511583E-30,-3.9550659302316596E-30,-0.7853981633974482,-28.89446065686872 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark07(-1.9847131512506397E-15,-3.693799507990442E-15,-0.7853981633974474,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark07(-2.0038022436703216,-2.5690638813755684,0,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark07(-20.208194234296045,-66.80950062782438,26.736504491726507,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark07(-2.0343157042542295E-13,-1.6909202948132601E-13,17.304903830958978,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark07(-20.365974505001574,-39.16115268320826,-95.25832193435443,-25.956043850543253 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark07(-2.078337502098293E-13,-1.7763568394002505E-15,-100.0,100.0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark07(2.1212987464865467,4.242597505122572,-0.27525121133108793,51.4209592898293 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark07(2.1565741841203194,4.582092127196143,-0.29288892866271143,8.631940158313204 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark07(-2.166758174544924,99.71530189249145,-15.48151146526773,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark07(-2.1671553440683056E-13,-2.7623305128802146E-13,-9.985451644818369,9.134727691196787 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark07(21.88332665035502,45.33744962750475,0,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark07(-2.1943429134985577E-4,-3.3953168235675447E-6,1.0971714567492788E-4,0.8060602281770873 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark07(-2.2093876545966493,-2.847981666369033,1.1046938272983247,77.43799411379553 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark07(2.215371374768196,-4.3368086899420177E-19,-72.57455410114181,-99.6661030760712 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark07(-2.220446049250313E-16,-4.099715836323608E-16,-66.7570652028484,0.7853981633974485 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark07(-22.452049157369345,-43.3333019879438,0,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark07(-2.2497188831169934E-10,-2.5874594587196167E-22,-0.7853981632262563,-40.59145819149186 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark07(-2.2547091724210566,-3.6332305018728905,0.34195642281308,-19.451635161987156 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark07(2.2622964180084097,-1.3552527156068805E-20,-10.50192915023794,3.8906648589775514 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark07(-2.2646803400764337E-10,-5.280987504264227E-11,1.1323401700382168E-10,-43.53377264644956 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark07(-2.2833120582725467E-4,-1.989296400127432E-14,-121.73532447152478,-0.7853981633974368 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark07(-23.440263326801478,-46.87883505366365,0,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark07(-2.3653073473698125,-3.2172515306505174,-33.44031994197802,12.850734675781826 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark07(-23.915115709400087,-0.5235987755982963,-32.08863588144838,4.080045371202601 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark07(2.408982355750055,4.817964711500113,-1.2044911778750276,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark07(-2.420117943922073,-4.303434487340016,-100.0,-48.68266346635247 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark07(-24.320892769382894,-47.246597331155584,12.066944525636703,27.545310470297988 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark07(-24.495845056180073,3.4689763612324924,11.758505700876213,8.595016488630279 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark07(-2.4513906971469392,-4.203499179408136,-133.36298417484548,-100.0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark07(-2.453627503393289,-3.3364586799919023,-32.755644174542695,0.8828311765985027 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark07(-2.461070061728576,-3.3513437966622557,-44.47249791423112,-88.70119515912857 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark07(-2.4770448575985875,-3.3833326204745355,-98.64051094588805,0.8641043858653165 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark07(-2.5009565480368896,-4.970336819838451,0.4650801106209965,-53.26804365000483 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark07(25.05448024370001,-6.162975822039155E-33,-49.440953801492384,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark07(-2.5167740993214047,-4.979645847795674,2.0437859962995546,-106.67065928227537 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark07(-2.5520782526342227,-4.244614531595946,-100.0,44.54943206637188 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark07(25.99861252636275,52.82120530390499,-12.953370030488912,-16.199109510355008 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark07(26.09102779622063,43.33082672818071,-10.754318033152714,48.129124427164555 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark07(26.260988890501864,52.83080809544428,-13.130494445250932,33.274856051835684 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark07(-2.6398427102780073,-3.710025687059489,-100.0,-92.65827726458652 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark07(2.650462834464172,-4.134381526946416E-12,-100.0,-0.10420910518875104 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark07(2.6514056493077427,-0.13293714696056527,-100.0,-0.7189295899171656 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark07(-2.6645352591003757E-15,-5.113185878912313E-15,-0.26886466371939566,4.774164515245005 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark07(-2672.77897816365,61.24961678138655,0,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark07(-2701.0923500163562,51.10495886628479,0,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark07(-2.7149200742633357,-2.631548610523497E-11,2.142858200529116,-97.75233169651217 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark07(-2.7234171430416967,-4.067803093023965,0.5763104081234001,-16.013055618782932 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark07(27.416506728561362,54.83301345712272,0,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark07(2.7586733712850706,5.529941648211707,-36.94462470758228,-4.33576715090075 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark07(-2.8026290449545375,-4.10912491552769,2.186712685874717,-3.4258978708280234 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark07(-2.812063539287316E-5,-5.6241270785743064E-5,-0.7853841030797518,4.319222942909825 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark07(2.8736149426394415,5.747232437207038,-100.0,-182.05874885904853 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark07(-2.930735377988604E-11,-4.985009032672117E-11,0.7853981634121019,0.7853981634223733 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark07(-2.9437862755911315,-4.316776316449282,-76.79324958451522,73.07585333199222 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark07(-2.945098463222339E-9,-2.068379450782611E-9,-35.333596345122665,-85.22763490347668 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark07(29.515063388102334,32.60333377586886,-66.82591598564373,-37.532356032418 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark07(2.9572989016545996,5.968291103178544,-82.30807772893866,-171.5279351451251 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark07(-2.9721731259617785,-1.1102230246251565E-16,5.359148181061836,-100.0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark07(30.02304297377384,-0.518521342346105,0,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark07(-3.038870690054532,-5.960191889809811,0.7340371816298177,-11.943881197600623 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark07(3.0703914239796117,6.625232984407448,-1.4944619348759476,51.87324545120758 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark07(-3.074258979800913,-5.816360257427813,-157.85058493912925,-96.05200490877374 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark07(3.108748419965954,7.186392756271105,-1.554374209982976,15.256359538010482 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark07(-3.13260159900284E-4,-2.4074124304840448E-35,0.7855547934773984,3.6621288319149605 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark07(-3.1375006852459477,-4.7098983278128115,0.7833521792255256,1.5695510005089572 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark07(31.449564682013403,87.99903883249411,-56.43322964767401,75.0491961290559 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark07(-3.150879995788979E-4,-1.016059441969337E-12,0.0,-1880.0922636070463 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark07(31.894472190635444,63.788944381270895,0,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark07(-3.1970125244223344E-17,-1.992373762512303E-20,0.7853981633974483,59.111389544363675 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark07(-3.231231609818167,-5.129727445012411,-76.25178226581998,76.39128861627874 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark07(-3.2380474996385207,-4.905298672737357,1.6190237497964546,-87.86945550724849 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark07(3.2476545883868297,8.04168161713197,-1.6238272941934149,-0.09905638597020029 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark07(-3.268698798156385E-17,-1.232595164407831E-32,-0.7853981633974483,100.0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark07(3.361014756000013,8.269554149482028,-0.9613787199033698,-19.057070728267075 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark07(-3.3669884249321993,8.184738155131035,-183.00121883913513,188.33018239564007 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark07(34.48149395170952,70.35065237968438,-17.24074697585476,-40.67304355561517 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark07(-34.91746888193863,-8.832149362370359,-70.68151217003481,43.412308774295525 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark07(-3.521954806634942,-6.589322415688677,-64.90084021739051,125.81654776626979 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark07(3.5256445511586607,8.018686040707099,-1.101141753956939,55.678052394347255 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark07(-3.552713678800501E-15,-3.552713678800501E-15,0.30334819386360934,45.34497878311499 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark07(-3.552713678800501E-15,-7.105427357601001E-15,0.7853981633974492,36.06436531097725 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark07(-3.5589110853314,-0.5235987755452823,24.556000206558714,90.14732058522043 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark07(-3.6128370777475993,-49.60691904918668,26.627599355250013,-65.51806160560207 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark07(-3.6385496563805394E-6,-3.469446951953614E-18,-79.03764850918004,-71.53813367836679 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark07(3.64029100414713,7.3451148844917675,-1.0347473386761168,100.0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark07(-3.681972604727384,-5.793148882659871,3.51797715576934,2.1678978920565632 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark07(-37.07847628163228,88.39998101565018,82.57968618030509,-71.75604745021971 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark07(-3.7888037954079485,-7.216136891865706,2.6798000611014228,-77.28903675015327 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark07(-3.8211128135726833,-0.5235987755982987,1.1251570213485131,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark07(38.301791026876614,78.17437838054812,0,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark07(-3.8951065277679513,-6.2194167287411375,2.3515144540561885,3.1097083643705687 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark07(-40.092176380610944,-79.80423315606389,0,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark07(40.79949239631559,83.16978111942608,0,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark07(-40.98180948265913,-80.39282263852337,0,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark07(-4.11827350025634E-10,-3.65550258342616E-10,-24.563650505981137,-13.53396782067515 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark07(-4.140230293572164,-8.067251390244603,-7.673675937337556,-51.785386899794304 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark07(-4.146016058611168E-12,-8.292032117222335E-12,0.7853981633995213,99.99999999995367 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark07(-4.175189826393337,-8.788166803736589,2.0875949131966687,-13.614445920390532 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark07(4.188030714093447,8.462173628026974,-99.95392636425863,-3.4456886506160385 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark07(-42.66979497245516,-70.91511118860147,0,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark07(-4.294960379542346,-3.4977093311046574,-83.4616936072545,-43.02035897246828 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark07(4.308015815453448,8.771175104273325,-2.154007907726724,-3.915446002931527 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark07(-43.17388964187272,20.564323112738066,-73.34159935331148,-82.1821630102516 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark07(-4.319378284727623,-7.0730323828860655,1.3742909789663633,60.08518394484359 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark07(-4.393025135139624,-7.485668936930924,2.196512567569812,-52.0204356531685 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark07(4.404286544179227,8.834214162972444,-2.2407514177772487,-87.67321831568984 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark07(-4.408310819799527E-9,-8.812272669616156E-9,-96.02828267037822,0.7853981678035846 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark07(-4.4189509693529733E-14,-5.551115123125783E-17,-100.0,-0.7853981633974483 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark07(-45.3054289172177,-89.0400615076405,0,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark07(-45.65094988503287,-89.73110344327085,0,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark07(-4.581151411709409E-19,-8.235934343636449E-35,-0.7853981633974483,4.117967171818224E-35 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark07(-45.95866090857915,-0.5235987755982983,15.7647286176867,-42.66730686926461 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark07(46.41605727557149,-0.030058224667573,-15.993425555723505,0.015029112333786527 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark07(-4.64663048344822,-7.722467123022617,-97.43061006484442,35.12692042840402 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark07(-4.664872796324978,-7.978569723900096,2.387238535311403,308.6322006887984 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark07(-4.6734322050479715,-9.330372289197058,2.336719487320361,-76.22215750834471 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark07(-4.683748967865357E-16,-5.392505761142286E-33,-43.18555416389282,-0.7853981633974483 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark07(4.787481582427224,14.260328754562249,-2.393740791213612,-4.792177623436111 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark07(-48.06330511425323,-84.31983100247746,34.92327231115391,31.661699965621636 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark07(-48.229532439369805,-13.090067094945397,0,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark07(4.8651196861837285,11.292861523106343,-48.760085794376664,-63.76589362543546 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark07(-48.88146538724174,-84.33359959175473,29.950591750523756,66.22769463167714 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark07(-4.896262858693692,-8.488551542908336,1.8573017247888708,-79.79332775355144 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark07(4.982187509816898,9.986005298413042,-2.082594335548465,-19.915518446237932 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark07(-4.996003610813204E-16,-8.550000323218143E-16,0,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark07(-5.038097805644708,-0.5235987755982987,66.32322502644197,-100.0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark07(5.0697466059507565,2.347457510671926,-10.887914157545655,-29.445948827546687 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark07(5.168841959487835,10.367345082982673,-2.5844209797439177,-32.67477605277761 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark07(51.775210848049426,-35.821036991595975,-23.933739511168724,33.14985603705881 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark07(-5.213748189479799,-0.5235987755982985,56.79846661080878,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark07(-5.228260654529459,-0.5235987755982947,-64.64472606848177,-67.05399769160961 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark07(5.326654492150604,12.2215872316819,-2.352744802945555,-95.64618304807225 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark07(-5.36929242247533E-4,-0.0010045404764302468,-0.7851296987763245,15.795929534557441 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark07(53.73613608990569,-5.551115123125783E-17,-19.65346608824534,47.4087850465309 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark07(-5.41561350585852,-10.503000486394809,1.9224085895318117,-61.57097369946253 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark07(5.59977994794652,11.256750816521775,-18.812900992937323,-95.95095271429061 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark07(-5.60404359355054,-10.072609116924141,2.016623633377822,-94.69923642488861 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark07(-5.608705208749648,-11.163458728222977,2.804352604374824,5.581729364111489 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark07(5.7578023365675195,8.558610146207066,-49.98689728821217,-3.493906909706084 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark07(5.807181416184209,11.790845917513352,-2.9035907080921044,38.87228618593835 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark07(59.12723479805007,13.983717863489957,-39.5847900872875,-89.51012588765745 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark07(-60.74958173968867,-65.67504753719933,-17.161065117838277,33.752200751499515 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark07(-61.0180283157242,83.62463893543591,0,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark07(-6.178904126705994,-12.357808253411974,-81.28737431453675,6.178904126705987 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark07(-6.21438604715558,-11.209188870532568,2.3217948601803418,64.75926618171493 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark07(6.2323185777755565,13.048056439316209,-2.33076112549033,-97.58641928264414 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark07(6.2819779480105495,-1.0182314955596741E-12,-25.786011093851346,-100.0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark07(63.16043966293046,61.40250376148455,0,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark07(6.36704799750876,13.078542919346313,-11.845949156384634,77.49833305527413 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark07(-63.719657688732156,26.721903871014675,53.02364395543796,-77.15621440718108 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark07(-64.1777536795823,-39.52290472574862,0,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark07(64.41602747003694,3.4708090091553316,-59.87692802750539,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark07(-6.4776675049898405,-11.39272470649845,4.0242319158923685,6.481760516646673 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark07(-65.5456846862433,89.09525967139928,-12.68000471143111,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark07(-6.568452702437835,-11.921263973559588,-100.0,15.885409614130626 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark07(-6.580654770094174E-4,-0.001316130954018819,3.290327385047642E-4,-0.005619235851610136 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark07(66.14082784159493,-39.04740798913726,-97.28746379253322,6.702873213434941 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark07(-6.616797012711089,13.746785495799998,-34.90548764931411,-38.659538151377106 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark07(-66.78560788274532,31.128345447600054,-31.00314982417136,-41.34431976850848 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark07(-6.700481909101775,-13.375816041216753,-47.7577061067992,-89.91837207978375 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark07(-6.730616064487549E-12,-1.3461247088460455E-11,-4.609153988018596,6.730463408821663E-12 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark07(-67.7052090166427,-2.054783882942985,48.76585997315627,-98.28079137055316 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark07(-67.75665717015724,-37.740553337941705,53.349043662252,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark07(-6.813739650573268E-5,-2.1995261336715574E-15,-48.23722474888276,1.096345236817342E-15 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark07(-6.882688171503275,-13.146643325512182,-4.962691953144674,-42.90453964865972 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark07(6.905840273388439,15.178974532612008,-2.6683209643439305,100.00947474486311 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark07(-69.06547600080086,-4.950213417958508,-97.46221523074968,0.6980047891537993 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark07(6.998128164146314,11.208691940455722,-2.7136659186757086,-51.13739759756953 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark07(-7.105427357601002E-15,-1.0658141036401503E-14,0.7853981633974518,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark07(-7.108019604565208E-15,-1.4216039202105377E-14,-10.12106750215635,7.108019601052688E-15 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark07(-71.18538361795984,-54.891615859021115,15.241506141571008,86.89588556280319 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark07(-71.87525623963691,-16.7801104875618,59.94649993455687,80.85687585749321 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark07(72.36713773346361,27.565192832960037,43.974296721292035,78.72777242546124 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark07(-7.245817926371796,-13.294649391690896,-230.97112486281915,6.647324695845448 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark07(-72.51314768269307,-18.36648295936027,23.858220177500627,64.62939345182579 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark07(-7.251500076906327,-13.3064086794552,-91.11203839304146,52.1975118559835 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark07(-7.30627421418542,-10.748366244027315,4.4385352703975105,15.80512174577243 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark07(-73.8531587639529,35.84081444331778,93.79453997291222,50.431099116282496 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark07(-74.59337790883936,4.4802641967690136,-28.778684279271644,35.77678405481157 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark07(-7.463810127744864,-99.50160090949144,22.23753496176721,-82.60766977000502 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark07(-75.37854732109884,-37.62752359821273,0,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark07(-7.581650970610664,-13.59250574266719,3.790825485479545,-70.17381670267274 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark07(-77.28326115644835,-27.65192937148946,0,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark07(78.07664754140623,51.35637662865827,-55.5127048715135,76.11225370087652 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark07(78.7750765132568,99.90130775704168,51.705537244528244,-91.3816708532357 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark07(7.880347117981854,16.28568191158616,-3.1547753955934787,75.89476628820712 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark07(-7.9272272453525225,-14.442879746776416,3.178215459278813,51.99423383958681 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark07(7.962163547628341,17.036861353681346,-83.0045398628558,-29.725454825683112 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark07(-7.97021881607567,-14.369764208507158,3.985109408037835,-59.703691201210574 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark07(80.60500210564769,-18.506839544973516,0,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark07(-8.08180350804677E-8,-4.024182263062995E-8,4.040901754023385E-8,-100.0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark07(-8.15815071459478E-10,-5.331437541845686E-26,-25.688349923371785,0.7840809561862924 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark07(-82.35145834356906,-42.90997442030457,48.862625747702346,21.429458566309552 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark07(-82.60309803489503,-87.74165442599559,0,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark07(82.70827333878944,23.312484299964908,-69.79578755633659,79.84629975218559 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark07(-8.307995919998723,-15.07297694279942,4.369464925278484,6.7707936087581855 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark07(-8.326672684688674E-17,-1.1102230246251565E-16,-17.108014095839717,-55.214271228837276 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark07(-8.391739391628546,-15.212682456462197,4.91235555691688,98.43418884635827 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark07(85.03461112860882,-2.2012492039277583E-16,-35.30270361183343,0.0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark07(-8.520368934851571E-4,2.1684043449710089E-19,-82.98317561931204,8.540347258777922E-4 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark07(85.41687223004533,-63.01539920218187,-13.482359878279922,2.088984396159148 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark07(-8.555926343808665,-15.541056360822436,4.277963171904332,53.10945768424067 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark07(-8.570053725111707E-11,-3.422434967971918E-11,51.73291026831996,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark07(-85.71978480608198,-68.298902854635,-36.08472130381677,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark07(8.711248004110304,17.654118935536722,-13.602225277743187,-99.9332325589856 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark07(87.34972814215666,58.88770347329029,-25.341940649620426,8.624260126789778 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark07(-8.770761894538737E-15,-1.7446563510079378E-14,-14.814942761522019,-98.61162489840942 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark07(-8.881784197001252E-16,-1.2474868739872082E-15,-47.64078968314911,45.38887716337362 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark07(-8.881784197001252E-16,-1.7763568394002505E-15,4.440892098500626E-16,-7.075486192926108 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark07(-8.942809889714384,-0.5235987755982987,-99.20115262360596,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark07(90.68965250028981,-47.85946337624674,14.587445224055884,-28.49032161534275 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark07(91.96755430366755,-17.998008495832522,93.61517432866631,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark07(-93.04096352505067,-84.90285151005837,93.77836605588311,79.0603154638157 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark07(-9.307932584305576,-17.04506884181626,0,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark07(9.353140743947208,20.27707781468931,-5.043175032861344,-10.138538907344655 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark07(93.90670627264984,-78.57923280214379,-30.829601557557254,5.419819011539204 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark07(-94.55342803062375,24.225541902280213,0,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark07(94.74988615392877,-69.35306270635317,-4.368031569869174,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark07(-9.488302478459798E-5,-5.76896551764678E-5,4.7441512392299226E-5,8.170323612037495E-4 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark07(95.12626456253307,-33.729777626544916,-55.92468003656484,66.93806285140201 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark07(95.47582236947022,28.052081390953305,-0.32297154484351154,37.600024215560836 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark07(-9.595657601835228E-13,-1.919129830992954E-12,79.21209391273014,52.15893620100524 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark07(-9.623467247259907,-18.655438202913114,4.8176244881547365,13.254559932508815 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark07(9.641857999420104,-0.5209567040505226,-1.6038588790595063,0.2604783520252613 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark07(-97.76539195485752,-1.1094311739350928,-37.086232269531735,-43.08858746808688 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark07(9.786171363393223,19.93168577265622,-100.0,-68.8720103289805 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark07(-9.905716724638461,-19.632101859520837,4.952858362319231,7.74525460298922 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark07(99.48046627975,29.94099783293325,-71.61268301305132,-81.15461620047064 ) ;
  }

  @Test
  public void test1367() {
//    	UnSolved;
  }
}
