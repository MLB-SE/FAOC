import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(-0.01205038042124329 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(-0.08540718540865555 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark18(-0.09455362668740008 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark18(-0.42091369967613446 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark18(-0.528047320016384 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark18(-0.5911085065492045 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark18(-0.6870130109941641 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark18(-0.7071067811865476 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark18(-0.7151393507734127 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark18(0.7561354021514011 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark18(-0.7911747751582681 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark18(-0.8310186172784171 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark18(-0.8963995120148809 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark18(-0.8971742925076427 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark18(-0.9156327535629032 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark18(-0.9544032429394447 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark18(-0.9635774369004793 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark18(-0.967206614279263 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark18(-0.9821538721646306 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark18(-0.9940527808062285 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark18(-0.9981993234274285 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark18(-0.9994467811038277 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark18(-0.9995925323607651 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark18(0.9998137723515784 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999904948762136 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999998341 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999999982 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark18(0.9999999999999982 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999999991 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark18(0.9999999999999991 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark18(0.9999999999999996 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999999998 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark18(-1.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark18(-1.0000000000000002 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark18(-1.0000000000000004 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark18(-1.0000000000000009 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark18(-1.000050319418146 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark18(-13.791625895639399 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark18(1.734723475976807E-18 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark18(-1.953566004012913 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark18(-2.3623171607696207 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark18(-34.13818243519475 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark18(-3.469446951953614E-18 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark18(-35.00634665207964 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark18(-44.99465565317815 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark18(45.44905854016517 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark18(-5.1306710016229703E-290 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark18(-5.551115123125783E-17 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark18(-61.192603688288536 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark18(-6.123233995736766E-17 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark18(-65.35075376319497 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark18(-66.12887728918636 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark18(-67.3822218366642 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark18(6.938893903907228E-18 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark18(-8.71511210004725 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark18(-8.772614747301574 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark18(92.38768692115036 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark18(-9.541632117623337 ) ;
  }
}
