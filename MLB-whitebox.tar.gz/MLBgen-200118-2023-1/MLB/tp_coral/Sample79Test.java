import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(0.024021008768404517,-34.77269667090264,-34.77269667090263,59.87928704826007,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(0,0.40954617113158065,0.4095461711315842,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(0,-1.0066265431892845,13.248955033932617,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark79(0,-101.13648548141107,89.30077117681739,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark79(0,-109.74783128345835,80.1971568586917,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark79(0,-11.610192593835706,32.01647471764409,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark79(0,12.332824679487729,58.491286688441846,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark79(0,-124.3702744793197,112.92550501887929,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark79(0,-129.29064075207006,50.70936010170362,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark79(0,-137.2957795025545,100.0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark79(0,-139.9163959474788,93.87167707845893,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark79(0,14.055661690612787,14.055661690612794,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark79(0,16.058055933044386,16.058055933044386,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark79(0,-166.1754561984145,14.765756902062293,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark79(0,-169.21537147087912,24.620278906460285,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark79(0,-178.75656846621825,13.428875663531187,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark79(0,-18.383154145816547,161.8148225177332,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark79(0,-190.15000482845073,-10.149991168072326,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark79(0,-19.212868385224475,13.491311676651277,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark79(0,-19.617191130991657,70.38280886900834,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark79(0,-2.0528630038954674,67.0554479699851,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark79(0,-20.655492018560523,55.3783779462191,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark79(0,-21.867844545772456,68.13215545422754,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark79(0,-2203.289007342098,515.7887375126523,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark79(0,-23.217122491851118,66.78287750814889,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark79(0,-23.481206638632685,66.51879336136733,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark79(-0.23498471471872184,-27.25570191049924,162.96106041705855,-68.6474641422964,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark79(0,-24.524044951708674,170.767593448733,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark79(0,-2516.7077805587055,247.86326264142394,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark79(0,-25.88478242740311,157.30493713548321,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark79(0,-2.629459333438632,87.37054066656137,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark79(0,-27.92674830884863,62.07325169115136,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark79(0,28.100301842757943,39.6010682481342,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark79(0,-28.41483273147378,17.357385413816658,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark79(0,-31.240207069074316,58.759792930925684,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark79(0,-32.56537148501767,57.43462851498232,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark79(0,-33.77151589392555,146.34494097252764,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark79(0,-35.036571805577886,54.96342819442211,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark79(0,-35.35401610157262,-35.35401610157261,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark79(0,-35.69850158338541,54.301498416614585,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark79(0,36.86738925993061,36.867389259930604,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark79(0,3.919929655440028,183.91993050941286,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark79(0,-40.55301380615415,-24.332288489940268,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark79(0,-41.57674471788597,67.20600609324438,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark79(0,-4.487548048591904,60.044542531661705,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark79(0,45.10281412135245,-56.117767950439124,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark79(0,-4.590347561363444,11.17773395641619,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark79(0,46.13867012815905,46.13867012815904,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark79(0,46.43714904460859,13.763542542935951,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark79(0,-47.18415577347044,42.815844226529556,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark79(0,48.68329270361039,6.199184566546023,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark79(0,49.364577888855365,71.62244423125142,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark79(0,-51.4982819637868,38.5017180362132,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark79(0,-52.03974126281797,127.96025987859186,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark79(0,54.48536221786273,92.45822720801564,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark79(0,55.61897522003349,75.07830539478107,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark79(0,-56.65659529669025,33.34340470330976,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark79(0,-57.695278024320814,133.26520779541536,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark79(0,-59.121654674054746,60.49489537528112,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark79(0,-65.57158032180863,24.428419678191382,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark79(0,6.607439168119764,6.607439168119765,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark79(0,-67.83270548355655,-30.627285590026318,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark79(0,69.20399882848707,95.65448886669355,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark79(0,-73.22929114915802,-1.1831187262255156,0,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark79(0,75.69706190702698,89.64567171384229,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark79(0,-77.72830597806653,74.72086491418372,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark79(0,-79.22117891467775,10.778821085320317,0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark79(0,-7.942048468811498,172.05838866329685,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark79(0,-80.00000000000013,100.0,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark79(0,-80.99558742085624,123.05952481420928,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark79(0,8.210469650178583,98.21046965017857,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark79(0,-8.351414477469945,22.483747800458303,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark79(0,-86.6896079999323,-54.85156242427094,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark79(0,-87.54079307491583,-62.94044338269735,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark79(0,-90.10456221657128,90.30257547188282,0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark79(0,-90.21488680426172,89.78511530232393,0,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark79(0,-91.9185752111971,-1.9185752111970942,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark79(0,-95.21288651659916,97.25906769521006,0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark79(0,-95.41990066789667,114.18489868393911,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark79(0,-96.04424170905152,-69.69782808536284,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark79(0,-96.98334114206793,129.34820438949376,0,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark79(0,-97.5688703808418,-7.568870380841815,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark79(0,-97.75365292072627,-7.753652920726267,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark79(0,-98.23370216781684,96.80078339730915,0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark79(0,-99.40597331141065,-9.405973311410657,0,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark79(0,-99.52139493175409,-42.632955881655874,0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark79(0,-99.99785754198611,-99.9978575419861,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark79(-100.0,-94.3160978130644,-4.3160978130644105,0,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark79(1.0140316101324521E-8,-11.088470248827534,-10.461203255666021,0,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark79(-11.577573566384345,-57.960044869250204,32.03995513074979,-70.50413098299363,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark79(-1.166559276585615E-20,-41.60443759923083,48.395562400769165,120.23802742918164,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark79(1.3406179378022135E-32,-2.2364749178927354,-2.23647491789273,0,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark79(-13.590009690700938,49.5737262145351,56.227998821499455,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark79(13.868690464234177,-53.953243922252895,30.259991504867457,66.26784237344543,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark79(-1.4148068612286723E-13,-99.99956740996178,80.00047371517958,-100.0,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark79(1.5285052259415383E-34,-27.289138592516345,62.710861407483634,0,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark79(1.5438941360930013E-27,-70.81351524003384,19.18648475996616,84.3691974095075,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark79(-1.6540232906631489E-34,-75.66426480876332,14.335735191236674,0,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark79(-18.35624468918023,-35.39885349317227,-8.245467153193474,81.9734545209345,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark79(-1.9184019216276327,14.000138756729928,14.000138756729932,-33.416211176358416,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark79(2.060585127348482E-5,-95.24838840144675,-5.248388401446757,84.8185892595331,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark79(2.081654600244651E-9,-10.24699427287539,64.67766481367903,100.0,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark79(2.2192226508098853E-21,-42.85643027754505,-42.856430277545044,0,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark79(2.3341953712562304E-9,10.0,100.0,-5.894698264901457,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark79(-2.3358790540079595E-5,-80.06600917212289,99.9471437097683,-63.50191254290941,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark79(-2.336302405147649E-21,17.05283718226855,17.052837182268785,-80.21006690872278,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark79(-24.441326638874855,40.72238995127083,92.23107116264185,-32.59537661624694,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark79(24.887581059011794,23.158056101303345,99.01013013612615,0,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark79(26.044271104330953,-2.906337503364079,87.09366249663591,0,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark79(-2.7263850266642648E-17,-28.524036586422127,61.475963413577865,42.62502169362253,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark79(2.7635419259703895E-9,-52.58003527174825,37.419964728251756,31.00341945682787,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark79(2.773709707350368E-30,-48.58698701135613,41.41301298864326,0,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark79(3.363113676833457E-9,-80.89526540552188,100.0,0,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark79(-3.4375095644490067E-28,-63.014393763217626,26.985606236782374,100.0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark79(3.542878384857506E-28,-51.18278014737938,-51.182780147379376,-71.75763862517962,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark79(3.6499417303994054E-33,-8.705036762566303,81.29496323743369,0,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark79(-36.92195710949318,-51.46455467421432,-51.46455467421431,7.424209235829361,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark79(-3.8864134874611267,56.58933782285061,60.036540696793395,0,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark79(3.9875857562124856E-10,-37.299454499547025,-37.29945449954702,0,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark79(41.96911181117591,4.888835562371762,94.88883556237175,36.7326887949211,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark79(-4.228696122967778E-21,-89.84508684062406,91.40665624297904,0,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark79(42.321048550115044,-91.79939665900622,-1.7993966590062342,0,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark79(4.8344046482463005E-33,-37.36529603528057,52.63470396471943,0,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark79(-4.852895058209328E-13,-89.5984088962577,90.51420618710253,-100.0,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark79(48.603882664960565,-9.499364520465932,80.50063547953407,0,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark79(-48.61008947679322,9.168867324227165,99.16886732422716,0,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark79(50.6776226887805,-60.25976213243587,29.740237867564126,-40.03395543947206,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark79(51.67312453606311,41.241483918368345,43.93614837347394,23.634481185320382,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark79(-52.885520679314915,-32.71532945909348,46.90926675161805,0,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark79(5.306502496614362E-30,48.03751816699911,61.75314594502416,0,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark79(53.206576288292354,-88.08787134538348,93.45807978682264,0,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark79(5.605430629943427,-31.168737343542247,58.83126265645771,0,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark79(56.081611555086,-91.82069749517896,100.0,-81.91842009009969,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark79(-5.61054264937119E-4,-11.372748261397499,168.6286708063895,38.17473997262309,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark79(-5.6356696679028974E-5,-100.0,81.42110387217582,0,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark79(56.735132778259356,-50.638775830638224,130.5810610179844,0,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark79(5.720785215605442E-24,-81.60973661648698,98.62320889356542,0,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark79(58.20607158927541,-2.245812205024407,3.7898300864688537,0,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark79(6.096730284609671E-5,56.63930589788203,58.769014383436996,0,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark79(63.8690318163292,18.15863941174866,19.307712548113273,48.3619330418413,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark79(-6.6431015019168385,-48.224137969558896,41.77586203044111,0,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark79(-6.655107631022927E-26,-81.76247622643842,100.0,96.7087529934716,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark79(67.04039933673165,-184.80813601204244,5.9089104926653135,-100.0,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark79(6.732505926417273E-13,-100.0,-81.41912886394442,-42.3159461967161,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark79(-72.86705221437742,-42.391369351246325,-5.244058338696007,0,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark79(7.52817738390516,-69.2796355428512,20.720364457148804,0,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark79(-7.777371006460664E-9,-12.991789266723643,-12.99178926672364,85.33329992068238,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark79(-81.11953908494785,-139.51833150190583,49.83904436051023,-76.53999081518546,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark79(-81.8180840171795,-40.351217178093385,49.648782821906615,0,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark79(-8.185290316868894E-9,-81.00129197921768,100.0,0,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark79(8.240947428544491E-9,-68.53631372083049,21.463686279169508,92.51480135224298,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark79(8.355183482969928E-29,-7.591426707503436,-7.591426707503434,-90.8724643487791,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark79(8.541816839846695E-29,10.44978780601875,10.449787806018751,100.0,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark79(-9.183630550800327E-34,-1.9179453742976176,88.08205462570237,0,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark79(-96.3161007456871,10.000000000000004,100.0,-100.0,0 ) ;
  }
}
