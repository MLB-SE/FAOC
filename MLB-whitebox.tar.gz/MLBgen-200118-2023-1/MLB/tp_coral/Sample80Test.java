import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(34.044194851700325,-1.2512799618444035 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(57.885648708299414,51.89621873567975 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(-7.5974500101068125,1.197434665315937 ) ;
  }
}
