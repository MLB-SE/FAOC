import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(0,0.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.2907613194343155,-1.5707963267948966 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(0,0,1.180677307214168 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(-0.015732136762297122,29.446219661974645,-0.01925780456349056 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark27(0,0,21.4659877480877 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-23.49618960605902 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-2620.153933487824 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-2711.9524639680767 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark27(0,0.4342421352758905,-1.5707963267948966 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-45.20063996885382 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark27(0,0,45.23908736119208 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-48.963868512144295 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-5.056746140338646 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-60.64770642700839 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-6.3565665225654016 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-65.89752265199056 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-67.42053748983672 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-76.51655750586235 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-77.2292083389913 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark27(0,100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark27(0,1.415534356397074E-15,-1.3941178974907358 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark27(0,1.5707907940934973,-1.5707963267948966 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark27(0,1.5707907940935348,-1.5707963267948966 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark27(0,1.57079079409354,-1.5707963267948966 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark27(0,2491.2430411748346,-1.5707963267948966 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark27(0,2511.9814912902966,-1.5707963267948966 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark27(0,3.552713678800501E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark27(0.3784488168649759,0.3415419749164752,-1.5707963267948966 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark27(0,46.33363741703472,-1.5707963267948983 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark27(0.4934294207767067,30.024893236929756,-1.9788279878867314 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark27(0,52.90673127447445,96.29790582971782 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark27(0,6.039613253960852E-13,-1.5707963267948966 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark27(0,7.531752999057062E-13,-1.5707963267948966 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark27(0,-80.6063964513354,-1.5707963267948966 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark27(0,8.086345225943312,-1.5707963267948966 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark27(0,82.23408847822972,-1.5707963267948966 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark27(0,90.01195013795277,-74.83474716360993 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,0.2875101135694051,-1.5707963267948966 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark27(-10.165563961741478,0.2125420136957341,-1.5707963267948966 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark27(105.82506735689351,0.05853836276956595,-1.5707963267948946 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark27(-1.3500311979441904E-13,0.48353910589309923,-1.5707963267948966 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark27(-14.423189028068776,61.23707981992089,-9.66105036173434 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark27(-1.557374211108995E-207,0.1145481632813419,-1.5707963267948966 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935348,2.5654237087022006E-13,-1.5707963267948966 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907963721097,3.460384501052648E-5,-1.5707963267948966 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707928698196396,0.0016013866285567672,-1.5707963267948966 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark27(-1.5804570619553748,0.11063813016408733,-1.5707963267948966 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark27(-1.5805662365718263,0.1112580963957088,-1.5707963267948966 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark27(-1.5856503858335278,0.13699412720689624,-1.5707963267948966 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark27(-1.734723475976807E-18,0.006288030213175718,-1.5707963267948966 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark27(-1.7775089260060155,0.4870714606933368,-1.5707963267948966 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark27(-1.811523276525441,-6.524774770450856,-1.5707963267948966 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark27(-2080.9369333131763,0.3133054280888548,-1.5707963267948966 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark27(-28.555058497856272,1.2539730269453891E-6,-1.5707963267948966 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark27(29.178261406165518,76.24586103102365,34.87961129979621 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark27(-3.469446951953614E-18,5.977049442186858E-14,-0.03074893058138375 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark27(-34.814059009817505,99.99999999999847,-2.8447310797564073E-4 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark27(37.623819766869005,0.1871055418192911,-1.5707963267948881 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark27(-41.35437214983182,-8.630433724466428,-70.77731797040316 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark27(-41.519770928698044,-33.76939938167462,3.967764708460638E-16 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark27(-42.864089133382286,5.3888474857437366E-12,-1.5707963267948966 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark27(-48.52738281303023,0.022633349606243653,-1.5707963267948966 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark27(4.894130241025347E-10,-0.051695270774248736,-1.5708124015440625 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark27(-5.6843418860808015E-14,1.0957872218977849E-14,-1.5707963267948966 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark27(-5.733991376175233,0.055743142309330994,-1.5707963267948966 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark27(-584.7923121168027,8.716985466783456E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark27(60.686881165696896,-6.529443708678899E-4,-0.19592994482953424 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark27(-65.65500664508097,0.031209841683431216,-1.5707963267948966 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark27(-65.83666365834307,0.20674291123151778,-1.5707963267948966 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark27(7.260845979866119,3.1647505058110568,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark27(76.5038952339095,0.5237870742742337,-1.5707963267948966 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark27(-77.09613780746204,0.05629257828229836,-1.5707963267948966 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark27(85.59815222095715,0.39297291027185266,-1.5707963266861211 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark27(-87.7810093559241,0.5245718878638446,-1.5707963267948966 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark27(-91.40508429551778,-6.54575394193485,-1.5707963267948966 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark27(-92.09608726687013,1.2623953455864529E-8,-1.5707963267948966 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark27(92.90439919653424,6.938893903907228E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark27(-9.947598300641403E-14,1.346625820344371E-10,-1.5707963267948966 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark27(99.68876750903503,0.20385811790338915,-1.5707963267948948 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark27(-99.99999999999042,7.052557313778893E-5,-1.5707963267948966 ) ;
  }
}
