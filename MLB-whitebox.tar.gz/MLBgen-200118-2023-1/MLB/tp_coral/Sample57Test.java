import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.012286401341336538,-7.769757863823653,47.496350214615866 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.023415018566900203,17.184348581935723,27.860186551653143 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.034638588300552664,-37.56647306389298,11.770815595562055 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.049272086825342606,3.4060114928252005,0.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.05938994947479703,30.181696136679648,-6.488138384169716 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.13945106473712787,-1182.459659597379,1322.9911935164148 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(0.0017804584190059813,40.02249833813165,-0.05681102874159738,-0.19091729571035532,8.227613291605625 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.4525208211106503,-1124.3131148777684,1399.7223241194436 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.9999999999999996,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.9999999999999999,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.1102230246251565E-16,-4.31544504706057,3.1554436208840472E-30 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.1102230246251565E-16,79.5588087992236,-73.961746399098 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-11.545833536536499,-0.004250879661857332,2.2000765479156854,-0.6292802211207871 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.1690571750412042E-12,0.07895740164444476,-19.894225165468242 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-12.509720475055772,-0.02436800596459962,4.812391844980218,-0.02271804887200224 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.3877787807814457E-17,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1751.2317811769574,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-18.897495391436355,-5.663017667750034E-15,-0.5321919001196843,2.1029882269145825 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-21.983978104853477,-0.05871197409574569,-0.19698602233999105,3.9419286165584424 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-2.220446049250313E-16,-30.266615933510494,93.08190347296014 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark57(0.0,24.59284785507903,-0.026034155907691203,52.63119002421581,-0.029845350752513156 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-2535.648191176591,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-26.738557845021116,-0.0324650031025186,-6.827284752864791E-4,7.302582828074072 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark57(0.0,27.163636583658402,-0.06234792043407539,-0.019123697924746774,80.25290053373888 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark57(0.0,2.72267173760968,-0.01839850576224593,35.11437591575502,-0.04473371050544883 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-2.7755575615628914E-17,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-2.7755575615628914E-17,100.0,-37.65535041848619 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-2.7755575615628914E-17,16.456835808829076,-27.577736660166693 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark57(0,0,28.467951523176424,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-39.852184089277046,-0.0019479528856449465,-3.469446951953614E-18,89.53156071840351 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-39.904122546003784,-0.06155391097577337,14.281903528518963,-0.09951052748919666 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-4.440892098500626E-16,-83.81185691586931,15.685720201913169 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark57(0.0,45.16801466846326,-0.03455993217752766,-7.666247204723983E-12,49.292268258480874 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark57(0.0,4.5557809598285175,-4.099909098918275E-27,33.046606427557414,-5.8732760150877995E-21 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-49.574769406868434,-0.001127985695494202,0.65234709172816,0.9184492350667384 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-5.345529420184391E-51,-1.6620460497584242E-11,11.381125113853008,-0.13799307267942013 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-57.16690136084348,-91.14322779113238,63.7932488833311 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark57(0,0,57.90647916884927,74.20776528520344,32.55151259796199 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark57(0.0,62.03961911898714,-0.05788088663503997,1.570797461892525,-1.1350976252585398E-6 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-66.68546491144922,-0.18274675305136112,-0.3632305793653322,4.324515654875554 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-70.25204517648804,-0.0551144500285734,106.83414068874855,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark57(0.0,7.608302440968728,-3.899157571037731E-9,0.968025514752371,0.6027708120425268 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-79.51932936248096,-0.01719586645286586,-0.0017593995918882832,78.55803171773283 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-8.235163727978573,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-84.01218368450886,-0.05626765883141085,-0.19267835856975785,3.3387604515918525 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark57(0,0,8.665065412058581,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-8.82892552401984E-16,1.6597412421334982E-194,-3.7322328533861396E-63 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-8.881784197001252E-16,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-8.881784197001252E-16,73.6008083355728,-0.0020864905077434387 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark57(0,0.8882945864579055,-1.3877787807814457E-17,-0.01791589949839245,83.31839524480188 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-90.13909849288021,-0.012224216013159261,1.7741494435673992,-0.20335311677250045 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-93.43455469163723,-0.005369831568593808,1.5707963267948983,-3.108875031093472E-27 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-94.76636605385661,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-96.6896347535168,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-97.45410355989877,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-98.57778988102113,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-99.09658539820828,-0.047849681725743665,-1.5451286716058685E-15,36.19228569033385 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark57(0.0,99.98382797190612,-0.04759480328430626,0.7845937535288241,0.7862772421555712 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark57(0.0,99.99999967878672,-0.002374763740614156,0.70191806202158,0.869917886977306 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.007235322254369153,9.100834257922088,-10.671630584716993 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-0.01263914628381746,-0.6344321210122223,2.1746773677661233 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-0.013945625438699448,1.9445470884891491,-0.37375076169425264 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.015273156733236853,-11.497851081849356,9.92705455117138 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.032413122618839094,0.043440801831813224,-36.159468991305474 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-0.05751389884063378,-3.5473829244444937,3.547398144024143 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-0.05912561785788623,-2.633348323164455,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-0.08325145864452554,11.925103307282109,-10.354306980487213 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.7766244149694463,12.330932678069138,-10.760178812144263 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.9999999999999991,-6.240592878404324,4.740592878404324 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-1.1102230246251565E-16,2.2196684064318237,-0.7076716153833056 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-1.1102230246251565E-16,-3.2048739416714724,3.2048739416714724 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-1.1102230246251565E-16,-47.88853539032543,0.03280109349746807 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-2.7755575615628914E-17,-0.11268264990348476,8.88359246767968 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-5.551115123125783E-17,20.934307891802902,-22.434279315967487 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.13867341280435,-1.7763568394002505E-15,-0.002607279938939666,602.4379261597554 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark57(0,103.06832992556664,-0.0032870277964785247,-80.03621115859454,-0.003605159137521241 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark57(0,106.05625906991965,-0.41451272123683486,-12.3169163544177,-0.21068628616947002 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark57(0,108.70481476122715,-0.04657999519485789,-1.377189823510804,-0.19360650328410145 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark57(0,11.26851172478439,-0.01838730251916501,23.695711526405745,-0.06629032114289624 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark57(0,1.143184493552539,-0.012617162597136963,25.83194766719575,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark57(0,-11.99625083074315,-1.1102230246251565E-16,-49.84103799631485,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark57(0,-12.634302273734448,-57.99274957904552,88.36711001299577,-45.241692460644934 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark57(0,-129.05795078813483,-0.8374199927423562,-2.5980943438021633E-5,2062.4299484311623 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark57(0,-13.086748978293937,-0.03027642769503261,-0.039890224348424166,39.23900206742594 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark57(0,149.7049107405855,-0.019127757538768275,-0.044434409389076224,35.3508991880752 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark57(0,16.474836759168426,-1.1102230246251565E-16,3.6441090739567557,-5.214905400751653 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark57(0,-16.498888429523706,-0.05276572295478295,40.537984866997306,-0.03874875211355835 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark57(0,-17.33643516235938,-0.14319653617141634,0.741245512626379,8.662276739913365 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark57(0,-17.743367898946403,-0.05473458094677997,0.029060373081644553,-0.029060373081641444 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark57(0,-18.66614139965983,-0.035760458532282186,-6.880612848886184,5.309816522091286 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark57(0,18.94387001779624,-0.10823989147792623,-0.33945218549802847,2.209405436321292 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark57(0,-20.317965578733684,-0.02621279141379134,-3.3144079524470134,1.7436116256521161 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark57(0,20.627513949375142,-0.020346615031718918,-45.07448647839853,0.0310600081386712 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark57(0,-2.1108132721946284,-0.11738676802032107,-19.803451697852285,21.303451697852285 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark57(0,23.60390374565174,-0.4565880834808772,6.221033542317976,-4.689557630704025 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark57(0,24.140568758756913,-0.0587353847706274,0.0018057236628827196,-138.2284164266443 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark57(0,-24.4507716698443,-0.022073256658009244,-8.409628705390972,0.186785455301262 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark57(0,26.373302961290303,-9.518138111502292E-4,-8.691146605572778,8.691146955667264 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark57(0,-26.85888597824358,-1.379850044165601E-13,10.381135052058127,-1.060764586495149E-12 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark57(0,-2.834217085727573,-0.016098896395206674,-100.0,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark57(0,-28.363517842064326,-9.860761315262648E-32,2.508787613592104E-16,-9.536686092587601 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark57(0,32.60726174454027,-0.038306148832593,-3.4492681540299057,1.878471827235009 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark57(0,32.730129519213996,-0.014280028888709398,-24.54221845476279,22.97142212796789 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark57(0,-33.673922359213684,-0.008762833060061266,1.728624651941993,-0.8819038153262193 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark57(0,-34.892101515703715,-0.049908292583990516,-5.4812539224348376,0.11239527490099199 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark57(0,3.5346694280458166,72.16838696731068,78.78019387268995,-79.67383414248268 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark57(0,36.23239452374214,-0.04971160321349824,8.881784197001252E-16,-74.38839347197333 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark57(0,-36.41551844687612,-0.017472886989454484,-0.8949080505401673,2.4657043773350638 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark57(0,36.52803565863388,-0.007869857277132337,-22.50201862995706,-0.9891299451714936 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark57(0,-36.62450727866229,-0.03254326365636473,4.831690603168681E-13,-40.46020126976406 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark57(0,36.87258143738879,-0.027370692333763443,-1.5938501375369027,0.023053810742005965 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark57(0,-37.24070320377354,-0.03131886652592808,7.105427357601002E-15,-46.316342843224774 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark57(0,38.59126585990028,-0.02813773730152036,1.3877787807814457E-17,-14.395329648232273 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark57(0,39.88065201480933,-0.043702905097746415,-5.834709972299035,5.834709972299034 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark57(0,-40.23125000101304,79.68015040670258,-86.30859831845001,-68.61881875055309 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark57(0,-40.53043961879681,-0.025070829835867503,1.1102230246251565E-16,-1595.5106366334983 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark57(0,-41.373642050592714,-0.0021663875127327144,34.99930454107652,-0.044873820046411245 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark57(0,-41.956355220063095,-0.05500171321521635,0.0031687429638526327,-71.16710353313287 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark57(0,-44.098481829422816,-0.035711922638343,0.5779602679890501,-2.1487565947839466 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark57(0,-44.670786118635,-0.05766844693111413,-68.85393359244688,4.973799150320701E-14 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark57(0,47.626916647031294,-2.7755575615628914E-17,-0.6368887240530576,2.2076850508479544 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark57(0,-5.087667436475659,-0.05130239760639177,-10.271226675586508,11.771226675586506 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark57(0,53.447583208651984,-1.1102230246251565E-16,0.705646669296913,-0.7056466714472318 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark57(0,-55.655970369598705,-0.18339112170988858,0.6515720596682452,-2.2223683864631427 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark57(0,-58.30512703678812,-0.0248587713946051,17.810087686184744,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark57(0,58.79929821202614,-0.04215911070891966,-1.9851411250802982,-1.1564543390457456 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark57(0,-58.969685123554775,-0.0109828335131946,0.04636988636891753,-33.08443497315318 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark57(0,58.99923492964527,-0.048166023966183885,-0.1353762372458463,11.603190920000936 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark57(0,-5.974027348103927,-0.05884283844583482,80.47651578285769,-0.019518692024803386 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark57(0,-60.832299394323286,-0.0321766205905315,2.3186290950540167,-0.7478327682591192 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark57(0,-6.2702179464066194,-0.022581347003533425,0.8423014497479158,-0.8423014497479073 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark57(0,-63.04647727110806,-0.060464017608542496,0.04579744446037637,-34.298776827030125 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark57(0,-64.70747623230105,-0.03515295135812343,-3.489274986908896,-1.1540942273590735 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark57(0,65.10228137659914,-1.7763568394002505E-15,3.931561991240164,-2.3607656644452675 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark57(0,66.29297877980919,-0.035317385313019464,-0.17611814100757384,7.358848772879249 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark57(0,-6.731932731835093,-0.037252901525720215,2.2138291734876514,-0.10860153038911884 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark57(0,-67.68489204830419,-0.009341423532396441,-5.421010862427522E-20,1.4999915312861403 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark57(0,-76.15936225201312,-0.028490452655480517,-0.13439134939080483,9.787170402916132 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark57(0,-76.2799670874899,-0.0031381236240631827,-4.440892098500626E-16,57.3554321194332 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark57(0,79.71451725407715,-0.05080258614814584,0.02414421556510747,-65.01230264281325 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark57(0,-81.94912372409762,-0.008671691112740465,-56.49847073179625,8.881784197001252E-16 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark57(0,-84.21212849261022,-1.9703185990105343E-4,-30.44661801241604,0.04841637424602574 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark57(0,-84.93693244628432,-0.00924765642107278,0.7051921391821736,-2.2274728255147256 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark57(0,-8.690250275512417,-1.1102230246251565E-16,-0.018934108099837088,46.70202702952678 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark57(0,-8.793804572652931,-0.05700097739609755,2.129146183290423E-4,-1743.4368677223379 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark57(0,89.44687311321786,-0.020573236463923898,0.0236187018599594,-1.5944150339524348 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark57(0,92.20668169135136,-2.7755575615628914E-17,7.43488798169444,-7.323274901511306 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark57(0,-94.65523374221203,-0.0037846293776544904,-17.500890684109145,19.04572835421613 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark57(0,94.93517859081356,-0.03359883363883004,-23.873749136135885,0.06130142145843635 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark57(0,-95.23208713664489,-0.9999999999999937,-23.413137247918783,23.416716872697958 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark57(0,95.7384911082942,-0.057074016488419636,-6.37049149632493,4.7996951695300325 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark57(0,-96.55119486217623,-1.1102230246251565E-16,0.06263599569882705,-25.0781728504437 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark57(0,96.5764041155619,-0.008217522344644568,-8.045815646093942,0.19523145892081573 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark57(0,-96.86084520251305,-0.9710237554382529,-26.77000886819179,25.199212541396896 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark57(0,97.32203354037995,-97.59821801477042,-60.79007987526974,-84.22039434286421 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark57(0,97.99393330668785,-0.05922495924094956,8.162889931822626,-6.662889931822625 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark57(100.0,31.7346743387272,-0.0390874838758742,-2.7755575615628914E-17,8.073701188295527 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark57(100.0,-57.01473997563134,-1.1102230246251565E-16,-0.06178772282537871,-1.509008603969518 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark57(100.0,-59.64612227673852,-3.058736250946764E-13,-0.4287929501509314,3.5704106353094147 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark57(100.0,-95.1238279241364,-1.1102230246251565E-16,-0.018509749704728528,38.18281109362965 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark57(100.0,99.9999980832531,-4.440892443856863E-16,-7.674466025058002E-6,100.0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark57(-1.0299315917408028E-14,52.48717434085296,-0.012709780993898452,-0.13360901867150612,9.627417848759531 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark57(1.0316063003421378,1.4933563750194652,-0.005306129261126169,-58.98283333480408,4.309775283332426E-17 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark57(-1.3177747429038154E-82,-96.30468013168125,-0.03348195104584141,70.71930778913462,-3.6204836678695086E-6 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark57(-1.3552527156068805E-20,-16.345442699944435,-0.05652996115725273,10.423320300150637,-0.002621296633342349 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark57(1.404466019662587E-48,-3.1375800087661225E-19,-0.01729894542452642,2.110149647078008,-0.04094934411649831 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark57(-15.333401503116107,-21.925500086978374,-49.676446716620326,45.267514384324414,44.356731664385904 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark57(1.6960798596470212,12.539063149090286,-0.03948925193853037,-3.552713678800501E-15,3.065127377559321 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark57(-17.326031176472064,-0.05975685605545067,-0.0404006896210401,-0.032557789722474695,48.24640555100519 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark57(17.363182220030584,-53.05152181627035,-2.4578669974504908E-36,3.7837123717385452,-0.06555503356660099 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark57(19.90019375536599,80.77933600707473,-0.006431040233618912,3.740799710123441,-0.41241299232572814 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark57(-20.672090880979923,-70.60970404679767,-5.551115123125783E-17,33.44095724658962,-0.04697222974843385 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark57(-21.797410584893026,100.0,-2.0089497698490376E-26,3.7224854420780136,-0.31416722606872766 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark57(-2.4450905033245394,-26.456967833598398,-1.1102230246251565E-16,31.472661093352365,-0.011894632200689445 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark57(-2.702584932947463E-16,-60.59237898645345,-3.6879634597244786E-14,-0.04097000040365506,38.3114204878554 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark57(-27.723491096197595,97.90917396968452,-0.061231493606978216,-0.08363758838677858,18.780985404920962 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark57(-30.488350392164666,30.032417381869983,-0.005639442175259815,-0.03567630788095233,44.02911680313048 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark57(33.434147743751,-73.6599445397661,-5.551115123125783E-17,-0.024760502388601814,44.04124127815519 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark57(3.552713678800501E-15,-1.1399894618990887E-14,-0.01646088925787559,-0.00847651901855781,7.4155614825253835 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark57(35.91245789023171,-18.913340041629695,79.67653851599303,88.70114983479743,-30.76520134090535 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark57(41.03092592305815,76.84844809357303,-0.049442722454270976,4.82073720070023,-0.07073759115852041 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark57(-41.553431685819234,22.05996941403096,-0.06126257145017627,-1.7686053155180325E-15,35.62747108004757 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark57(-41.57007695612727,-31.966740487294132,50.227897994581554,28.12712950969754,-32.1004683887611 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark57(42.571674817028,-100.0,-0.021031688037374346,-0.21696330177335632,7.239917137856693 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark57(-47.98361832157997,100.0,-0.061562772313994374,-0.06296456870522016,24.94730543059636 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark57(-49.20823099781754,-48.13314663325913,-2.8910456920076816E-11,2.9761205672732576,-0.014742243310563896 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark57(-50.14135492816454,-91.68207271263071,-1.1073596055747883E-24,-0.3717902595134711,4.224952877599478 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark57(-5.300910967632424,90.0282617844503,-0.028248079376468976,9.099380345555314,-0.022645464360280032 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark57(-56.81248140270739,15.553415984216231,-0.04588273967722156,24.578812806491356,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark57(-57.43866834172438,-15.189211677167883,-5.050659814679922E-34,-0.026780557531745686,58.65435493390532 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark57(-5.938971595748288,-100.0,-0.0243737143529954,0.8285114702961098,0.742284856498788 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark57(-67.59169046648354,-25.782132372531223,-0.029261774323562806,8.949722442878965,-6.665793345423224E-30 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark57(75.8351834837675,45.62129140531485,-0.003409068531596837,18.712193153773956,-0.06847340847300344 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark57(75.83753386071618,-63.85868015219791,21.55962663950615,-0.31337042428651785,-7.670928342300726 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark57(-76.7122449289788,-90.63996643835702,-0.00993777408958299,139.7065474070031,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark57(-77.21734586182144,-100.0,-0.035618762736773994,7.9326540141466015,-0.19801649284002928 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark57(-83.01741157244035,27.52978622857063,48.94337769027484,-41.99894427957644,-68.08224940416781 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark57(-8.50380332348601,-25.519424397693005,-4.440892098500626E-16,-8.40076500922837E-15,98.49374174847964 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark57(-86.0142495414548,100.0,-3.166265456556604E-19,100.0,-0.015707963267945324 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark57(89.56820465293384,-100.0,-0.03138775526003257,-5.853412111395834,0.027962680039834507 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark57(-91.91900702976235,-95.36293861977066,-0.03405271897748777,3.567127622777498,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark57(97.22189236326338,36.33210105497349,-98.1711003698136,-67.58957862950146,43.14132860273193 ) ;
  }
}
