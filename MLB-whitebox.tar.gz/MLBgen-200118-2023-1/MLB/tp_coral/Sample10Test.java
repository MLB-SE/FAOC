import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(0,0.013875381906821938,-1.5707963267948966 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(0,0.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(0,0.01904947385803381,-1.5707963267948966 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark10(0.0,0.20626534259370533,-1.5707963267948966 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-0.6563524641265417 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark10(0,0,10.439226665060545 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-25.080641700336727 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-2638.6278501819065 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-2726.180984066571 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark10(0,0,30.296998137477715 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-4.722253844134457 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-50.638478915962516 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-52.0359894217393 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-59.7429588959872 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-74.16322389520049 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-76.49210749453172 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark10(0.07693887016432646,-0.5810941574044372,-1.5707963267948966 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-83.1753584284107 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-83.76419506296524 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-84.61271834442756 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-8.467675692300958 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark10(0.104660528229644,-11.917628593408963,18.408895635682782 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark10(0,1.5707907940932841,-1.5707963267948966 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark10(0,1.5707907940935348,-1.5707963267948966 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark10(0,19.39419734693597,-1.5707963267948966 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark10(0,2570.377440441826,-1.5707963267948966 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark10(0,2586.408567861565,-1.5707963267948966 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark10(0,-30.088994213941604,-1.5707963267948966 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark10(0,3.552713678800501E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark10(0,38.84297275681532,-1.5707963267948966 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark10(0,43.08249095358511,-1.5707963267948966 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark10(0,46.69530695496223,-1.5707963267948966 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark10(0,69.88457385951817,-1.5707963267948966 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark10(0,7.1150034207552775,-1.5707963267948966 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark10(0,72.55722814361127,-99.35318896598591 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark10(0,8.980394448564738,-98.7517690405053 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark10(-0.9722915700715191,0.17164718100085083,-1.5707963267948966 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark10(0,9.891000358300671,-1.5707963267948966 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,0.19597899166548718,-1.5707963267948966 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark10(100.0,0.25199521310166606,-1.5707963267948966 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,0.2937944223223369,-1.5707963267948966 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark10(100.0,-11.716116015192831,-2.4643381623866008 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,3.6891089752794445E-4,-1.5707963267948966 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935348,1.6637490462100267E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark10(-1.570790794093547,3.552713678800501E-15,-0.017236224895108114 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907946398263,1.1459239249583823E-5,-1.5707963267948966 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707909112276501,3.6237615210828807E-4,-1.5707963267948966 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark10(-1.5723451540319928,0.04444701100047473,-1.5707963267948966 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark10(16.96156498917749,0.4644929433691587,-1.5707963267948966 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark10(-1737.5157461233644,0.15656381530567015,-1.5707963267948966 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark10(1.7916053354086638,0.5017248027440827,-1.5707963267948966 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark10(-1.8034445156896912,0.5135648023694587,-1.5707963267948966 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark10(18.273117245297783,83.20197591949582,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark10(-2025.9071414784105,4.023403303670439E-9,-1.5707963267948966 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark10(-22.539657740634098,0.029395246748358382,-1.5707963267948966 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark10(-2.4970825834643193,-7.513446361926932,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark10(-2.8421709430404007E-14,0.08760372633214208,-1.5707963267948966 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark10(-3.0417465060722557E-210,0.5186049237889847,-1.5707963267948966 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark10(31.101966850845486,0.15108141033280667,-1.570796326794897 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark10(-3.5510134278400596,0.48493799647748137,-1.5707963267948966 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark10(38.222225295524304,0.008702937315381595,-1.5707963267948966 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark10(4.913868825450251,-14.907432750768912,-1.480063361781981 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark10(-54.68080334657227,1.1327583906465395E-8,-1.5707963267948966 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark10(-59.769421361774235,7.863695678544196E-5,-1.5707963267948966 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark10(-61.26084096964785,2.625323881100908E-13,-1.5707963267948966 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark10(6.452953215305106E-17,0.18535864254602452,-1.5707963267948966 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark10(-64.8000269449389,0.01715269160593391,-1.5707963267948966 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark10(-7.105427357601002E-15,0.004637740557780336,-1.5707963267948966 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark10(-72.45205137178627,-26.291224768095887,76.7310615214162 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark10(-82.07694004847882,0.15000382142939914,-1.5707963267948966 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark10(-86.66454754538479,0.18592289371638393,-1.5707963267948966 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark10(89.3326589335561,-3.6548903740573495,-1.5707963267948966 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark10(-98.08260242732051,2.638018085200548E-5,-1.5707963267948966 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark10(-98.11796403444733,0.10218152783655526,-1.5707963267948966 ) ;
  }
}
