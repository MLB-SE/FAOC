import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-0.007220984074494337,59.683039434211906 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(-0.008581969126268518,-91.11476892323027 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-0.010138756528917135,-11.966205753857786 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark91(-0.012696903748697268,72.41144087845616 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark91(-0.013704638553254433,43.46265574927207 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark91(-0.018975243639014705,0.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark91(-0.0242564796507659,0.0242564796507659 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark91(-0.03125022790904739,-22.022398803037646 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark91(-0.07244299473142705,-43.91018951374493 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark91(-0.0816351378831794,-175.84749033007145 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark91(-0.08820348755576468,96.73449809471867 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark91(-0.08975019467097295,-2.8883110013837273E-275 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark91(-0.09046443152311046,-1.5707963267948966 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark91(-0.09181614556342066,-72.34871235975776 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark91(-0.09986096879042815,28.17447291351771 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark91(-0.1127731175798048,-73.08547958288958 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark91(-0.11611384184598901,-40.9568183385133 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark91(-0.11868112079057011,-66.09212684617623 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark91(-0.12012185449791088,-66.09356757988357 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark91(-0.1694128311352136,-50.09606962630148 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark91(-0.1718589297210258,37.19225348853524 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark91(-0.17902648929777065,-43.96822246276671 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark91(-0.20090836505818485,-41.0416128617255 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark91(-0.21394069856623332,90.89224625553777 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark91(-0.23309280653492465,12.799463420894098 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark91(-0.23369223105161296,-54.03954930130109 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark91(-0.23971871265445138,-119.00382032622565 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark91(-0.25964650385881927,-55.51923405604522 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark91(-0.2620347929877729,19.530860938355787 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark91(-0.2651481876030794,23.55591966603356 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark91(-0.31510600693581736,-1.3615476358213465 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark91(-0.31791730288264486,-93.92986230481115 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark91(-0.32764847352669246,0.5743873072777584 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark91(-0.3330718636440166,-31.082854672253916 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark91(-0.34039680028138514,21.65075080313718 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark91(-0.3442956816405952,0.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark91(-0.35202469933447894,0.04881232290417703 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark91(-0.3584035393333365,116.26455948474198 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark91(-0.3643312873262806,63.99014425326547 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark91(-0.3909069886032991,-24.741834240115047 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark91(-0.39272630774496115,0.39281732506290845 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark91(-0.438934854380043,90.54934335265241 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark91(-0.4476517288807287,1.5707963267948966 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark91(-0.4815039577925688,14.667033458783663 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark91(-0.49866097983665675,78.04115535990817 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark91(-0.5037799930140476,44.48607714327115 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark91(-0.5114443410278802,91.09114783925648 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark91(0.5201091828765669,-60.66854479783501 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark91(-0.5239232095855706,-56.02474455503071 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark91(-0.52464383777779,-35.082163027265516 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark91(-0.5262160726924094,-16.234179340641376 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark91(-0.5309559833957959,-100.0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark91(-0.5314470038528127,-3.9263416310101814E-11 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark91(-0.5342464018156763,0.5342464018156764 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark91(-0.5389385277433227,-53.826728522075015 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark91(-0.5414837873764125,60.85236944527344 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark91(-0.5427879330075736,-169.10321536084126 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark91(-0.5527805632159801,25.6857856609533 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark91(-0.5672269976070887,44.441557661153354 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark91(-0.5886080853575213,-59.245489564990564 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark91(-0.59086213580707,2575.4300422452898 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark91(-0.614702050763122,-60.30478835388398 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark91(-0.6355669403707992,52.771508170655686 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark91(-0.6435112357527875,27.63082264655535 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark91(-0.6506437034558274,66.65436017342466 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark91(-0.668568399081867,-3.8101610526716603 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark91(-0.7195029335689345,-10.144388482459021 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark91(-0.7336040731540603,-72.77704687441815 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark91(-0.7345686662693734,46.389321137577525 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark91(-0.7749732878775153,-91.38892218135406 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark91(-0.7751380251963769,96.61423423608721 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark91(-0.7866296277859998,-24.346111600932346 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark91(-0.8049813860619237,1.58E-322 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark91(-0.8225296984052938,25.955272712871704 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark91(-0.8945987422956944,1.5707963267948968 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark91(-0.9007363695634796,-1.1553244005534909E-274 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark91(-0.9130286846086904,-71.364436059481 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark91(-0.918718099124926,16.609668209232574 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark91(-0.9237646042377164,-83.28854174997139 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark91(-0.9312111916559651,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark91(-0.9315175725158981,7.214702879695484 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark91(-0.9403578391794171,0.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark91(-0.9445295969150129,-58.83684954210155 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark91(-0.9504246818300184,82.63183367516464 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark91(-0.9523271765350049,27.322006705773134 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark91(-0.9703614266164253,0.9703614266164252 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark91(-0.9772680663983699,28.201784027260288 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark91(-0.9789973393989814,-48.10288714324588 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark91(-0.9847819829555249,112.76294320676276 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark91(-0.9900970375077711,-81.29206592607498 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark91(-0.9999977928554493,77.53981633974482 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,0.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark91(-100.00000000000001,100.00000000000001 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-0.5309649148733837 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-100.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,100.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,1.3319983461951343E-256 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,1.5707963267948966 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,1.5707963267949054 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-2619.5909752599487 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,2628.4087707000403 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,55.03893226109892 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,6.770957768435252 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,79.3044247294019 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-89.77563731614786 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,91.93667062563682 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-95.49271699921401 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark91(-100.52466107693775,-1.5707963267948983 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark91(-10.07444383329134,-32.52593171843982 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark91(-10.086005995683607,-3.745586645091194 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark91(-10.089912580166507,-32.25784635407785 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark91(1.0097419586828951E-28,81.68140899333461 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark91(-10.115458315579708,-1.5707963267948966 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark91(-1.012149351046356,37.14926059557888 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark91(-1.0157514881026535,-41.856455984769966 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark91(1.0164791435450619E-16,-31.415925453112315 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark91(-10.165967866208746,-35.26967444269245 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark91(-1.0241937770334647E-12,113.09572080863975 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark91(-10.25930433192282,1.5707963267948963 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark91(-10.345841457312815,-1.5707963267948983 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark91(-10.358576934162173,95.22182489276587 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark91(-1.039646950610725,2574.2026857232413 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark91(-1.0420220734289363,63.8738751452248 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark91(-10.42054555836184,42.16299136525325 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark91(10.424777960769381,12.716697147914493 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark91(-104.43450625302835,90.59999528115628 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark91(-1.0494670338935301,-55.49920073072275 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark91(-104.95635797175592,60.92930529930075 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark91(-1.0537371427289628,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark91(-10.542238317594041,-0.9487885184154692 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark91(-1.054516428997914,-92.16070338310192 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark91(-10.646670673456368,-56.23546729999671 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark91(-106.81395974687658,-1.9048492303210533E-4 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark91(-106.826219499382,-72.25663103256441 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark91(-1071.60706262712,-1.5707963267948983 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark91(-1.0720112892212592,-73.3286423217865 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark91(10.764680706603343,-28.88937474349396 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark91(-1.0842021724855044E-19,1.5707963267948966 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark91(-1.0842021724855044E-19,21.991148070586412 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark91(1.0842021724855044E-19,72.25661075023062 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark91(-1.0842021724855044E-19,87.96459430067357 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark91(-1.0900484102337316,70.20527999073192 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark91(-10.932948467930308,-1.508170507160929 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark91(-1.0947555821198054,-74.30346810403523 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark91(-10.987152817507095,-84.79471302936591 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark91(-10.995510730948276,-1.5707327701784288 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark91(-10.995574287563262,-1.5707963267948393 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark91(-10.995574287563635,-1.5707963267948966 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark91(-10.995574287564281,-1.5707963267948983 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark91(-1.1030582009303866,-111.99427732830218 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark91(-11.068503128490665,73.90035620028652 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark91(-110.84829003782511,88.74658311750375 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark91(-1.1102230246251565E-16,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark91(-1.1102230246251565E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark91(-111.5849873517415,-9.519852263505599E-14 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark91(-111.59214766436804,-62.832028413830685 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark91(-111.62772627318928,-1.4696092560432747 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark91(-11.168032903119451,59.69026041820607 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark91(-1.1210387714598537E-44,50.265776405674146 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark91(-112.6620957454113,31.16288596419607 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark91(-112.78103632320914,81.3651097873112 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark91(-112.97435939833602,-30.850405858872918 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark91(-113.09639259338428,9.428684516936034 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark91(11.39774495788896,-35.861778697960986 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark91(-1.1422812385010797,114.23961676773364 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark91(-11.425226836549712,-175.83776292357226 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark91(-11.623834588897864,-0.9425360254613089 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark91(-1.1636626712555596,-54.570737782282045 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark91(-118.00979142217933,85.67256176173174 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark91(-118.28971013329343,1.5707963267948966 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark91(-118.8145187937708,-33.991517146846384 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark91(-118.94048840230946,1.5707963267948966 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark91(-1.190399975028201,-67.16384570041386 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark91(-119.07007372348409,-59.66939050587935 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark91(-119.31681340611229,-0.0635614316716171 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark91(-1.199594930374623,96.18977733090897 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark91(-1.199967863537844,-24.862456884452055 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark91(-1.2178827469504172,-42.76441440330669 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark91(-1218.317631786224,-0.8077170315644405 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark91(-1.232595164407831E-32,72.25662933554956 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark91(-12.348018473091342,-0.21835214126783115 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark91(-12.373242950509395,-65.78031806153588 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark91(-12.373840184838617,-1.5707963267948966 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark91(-124.08684787242109,-1.5707963267948983 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark91(-124.14715938811554,-39.54788210797127 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark91(-1.244366404543051E-5,1.2443664037036532E-5 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark91(-124.83012929940297,-180.9584320418783 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark91(-12.486970810920141,79.78085797771064 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark91(-12.504283098568322,-1.5707963267948957 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark91(-1.2538237965374872,45.23612094679459 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark91(-1.2550820094559754,-4.3966746630457685 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark91(-12.566370614359046,-87.9645943005142 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark91(-12.566370614443839,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark91(-1.256780053522328E-12,9.424777961703155 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark91(12.56832374166482,1.5707963267948966 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark91(-1.2569836736208373,1.5707963267949054 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark91(-125.9697934124976,-91.10619546631025 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark91(-1.2621774483536189E-29,1.5707963267948966 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark91(-12.677066480964712,-120.51352371691536 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark91(-12.679455518073976,-1.5707963267948966 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark91(-1.2739448570286669,-54.68045397384299 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark91(-1.2741055483041643,-1.5707963267948966 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark91(-1.2924697071141057E-26,-21.991363492106025 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark91(-1.2926775967865614,170.9386808906354 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark91(-1.3050608935997049E-54,65.97344572538564 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark91(-131.42155363733724,-69.65461341683097 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark91(-1.3143977703539997,20.677837620924084 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark91(-13.176788437937638,-100.0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark91(-13.255964854980022,-1.5707963267948966 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark91(-13.294255322434537,-16.43584797602433 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark91(-13.304760502759681,-3.879982541990301 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark91(-1.3345265732877862E-17,-84.82300164605921 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark91(-133.5176877310506,1.5707963267948968 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark91(-1.3368785801502554,1.3368785801502552 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark91(-1.3401017270423001,-1.5707963267948968 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark91(13.46993941126982,-46.14570605650861 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark91(-1.3552527156068805E-20,-1.5707963267948966 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark91(-1.3552527156068805E-20,1.5707963267948966 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark91(1.3552527156068805E-20,9.424777817325795 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark91(-1.3558975611217636,-1.5707963267948966 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark91(-13.661397843941074,-1.5707963267948966 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark91(-136.6592804311553,-1.5707963267948966 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark91(-13.688738502707182,1.5707963267948966 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark91(-1.3692625699837768,1.3692625699837766 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark91(-1.3738480563195505,-42.84404330979049 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark91(-137.86481649918505,-111.73684419258045 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark91(-1.3855684910241315,1.3836014579693046 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark91(-1.3872044141214512,1.7543882394683408 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark91(-1.3872837055242158,27.50761000588134 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark91(-13.931739577676154,27.732326988058347 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark91(-13.948077415590461,-103.13518613678714 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark91(-13.975704911987776,4.9E-323 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark91(-14.090932089594405,-36.174550367842286 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark91(-1.4102973562954368,26.543038585013782 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark91(-14.137166941152095,1.5707963267948966 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark91(14.13716694115407,38.97554125977817 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark91(14.137330101784467,0.0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark91(-141.4562511933184,-158.1726131187361 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark91(-1.4196964949842876,-29.996230040913645 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark91(-1.4225290002447795,77.11728733950005 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark91(-142.66338061062547,57.797698319107525 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark91(-1.4275745265002229,-2616.9232388757405 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark91(-1.4349296274686127E-42,-84.85425164692442 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark91(14.360088251485024,-84.25381175712559 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark91(-143.80907645956222,5.543004348094556 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark91(-1.451200732838822,-73.70783176540407 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark91(-1.4643046308970185,77.07551170884781 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark91(-1.470843086571689,27.054199851959453 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark91(-150.10055550656375,-95.6833560358311 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark91(15.048499916415048,66.63357928411041 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark91(-1.508560280787771,-17.006024904365177 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark91(-1.5154271787031603,-55.035549697657274 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark91(-1.5178626290642567,7.906915331705122 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark91(-15.187649950233677,-42.14661739414885 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark91(-152.0706955185456,1.274248146235515 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark91(-1.521703985727516,-99.00926092914587 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark91(-1.523464731156898,14.181979876224233 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark91(-1.5249196184316873E-8,75.39822774847264 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark91(-153.94821312982006,94.24790604426694 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark91(-1.5407439555097887E-33,-50.265482457436725 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark91(-1.5407439555097887E-33,-59.690260418202385 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark91(-1.5441166832000158E-16,-91.11009610878368 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark91(-15.443485922889892,14.14081639409946 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark91(-1.547980524004935,1.5707963267948966 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark91(-1.5482162428358714,-37.63562056956188 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark91(15.512101499676675,90.39027645246907 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark91(-1.5513156205163625,-38.074271331771705 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark91(-1.5580084526784284,-36.290189041479955 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark91(-156.03051672888674,-2.4740256868791334E-15 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark91(-156.04423128553228,9.960172893606892 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark91(-1.562867518616053,1.5707963267948966 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark91(-1.5632928355403213,164.92611082220958 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark91(-1.5638517759364363,-27.13249858472735 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark91(-15.645161824693403,71.37344000475221 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark91(-1.5686545809647419,20.42249399416376 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark91(-1.5688621925675397,-61.03343100497208 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark91(-1.5689483410690248,-65.1417950632822 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark91(-1.5693625762554173,89.5368243778487 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707959064673973,1.5707959064776054 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963143850987,32.986722850288125 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796324580543,-98.9594278039019 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963247005952,-48.70184447290103 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963258901565,-42.53668336242991 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326145103,20.427246453303926 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark91(-1.57079632648342,20.42035224863838 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963265048719,1.5857375137740246 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963265332776,1.5581458121349938 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963266174334,1.5707963267948917 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963266188167,70.6982603749681 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963266351028,1.5707963267948963 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326647533,26.710868424851515 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963266838514,-61.24450637037373 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267243672,45.54832969574277 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326728666,-36.14378306427624 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267467253,-10.984033711958402 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267666094,1.5707963267948966 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267810587,120.95131660163214 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267888585,1.5707963267948966 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326790832,1.5707963267948966 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267914065,1.5707963267948966 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267919893,1.5707963267948966 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267926441,89.53539062731636 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267931047,-48.69468613063714 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326793731,51.83627878423019 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267941158,1.5707963267949934 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267942666,76.96902001294828 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267942748,-23.56194490192125 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267943013,1.5707963267949148 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267944354,1.5707963267948966 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267946223,-67.55794902152569 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267947782,-48.513832970788805 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794778,39.09914304200552 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267947935,76.04476205052615 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948168,26.681190180285366 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948637,1.5707963267948963 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948664,39.26146563979919 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948764,89.53441013655164 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794877,62.1921159556191 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948808,1.5707963267948966 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark91(-1.57079632679488,1.5707963267948966 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948841,95.8185759344814 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948848,-11.006110204150371 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948877,61.67330999733721 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794888,-98.93951568345086 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948895,-77.29814620752542 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,1.570796326792903 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,1.5707963267949054 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,57.54080780086605 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,-86.8086873708035 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,-92.676983280899 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794893,-32.31758094663351 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948941,-98.95736055884711 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-100.0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-10.983771602697447 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,1.5707963267948961 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,15.831595638416033 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-25.257045182519292 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-28.58657359063912 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,41.871753403158216 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,63.94245545726059 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-86.39987783587142 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794895,-12.56637113133476 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948952,139.80087308633753 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,100.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,12.930327034439458 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,28.268214291084234 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,-29.408527070563338 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,76.28138880607327 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-14.80500897901069 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,1.5707963267948983 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,2524.5775327582587 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-42.53650082748851 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,6.776263578034403E-21 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-72.15971867359599 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,74.94253015540951 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-95.45277130019365 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,0.28268935774272425 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-10.99662553561624 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-111.52653920243873 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5518835038670897 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267921508 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948963 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948983 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267955516 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5895700177157905 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,20.422015328234167 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-2535.6942953560774 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,39.26618054391904 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-42.40986002060697 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,43.267830106918986 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,51.83627878422706 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-54.979832036454305 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,55.069579265112765 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-92.67674583770287 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-92.67698328089475 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-92.67698328089604 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-95.26615044726076 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-0.0791941427787652 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.0010415475915505E-146 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,102.08120445663387 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.0274410151546425 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,10.803677672202056 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,10.823305279508986 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-10.995574287563493 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.1861656130221163 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-12.566370618898404 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,12.566371323133211 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-130.37609512195738 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-138.2348186273595 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,139.8008640562184 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,146.08405839199511 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,14.681404444358876 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5516855813771966 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5518091643743186 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5544748064312581 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5635222150702277 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267899792 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267924048 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326794822 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326794826 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326794859 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949019 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949028 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949097 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949216 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267950475 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267969696 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.8900642872465014 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-197.9176842145837 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-20.660914126912708 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-21.99114857512855 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2.2276109039658383E-18 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,25.13274122871834 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2520.6044535331716 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,252.8981892112105 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2.53E-321 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-25.758803835625823 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,2626.198350970388 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2626.200467745121 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,27.00841147677761 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-29.84513020909907 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-29.845130209100244 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-29.845130209101963 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-29.845130209102027 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-29.884938787437548 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,3.1415928920083727 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-31.416116411718736 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,3.1572176535897936 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-31.75500745489287 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,32.98672286268697 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,32.98672286269 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,32.99557970926145 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-33.39198954337465 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,33.83395004180494 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,33.83724393533109 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-34.55751914119955 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-36.113558484991934 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-36.11886806210205 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-36.128315516277084 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-36.12831551628083 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-36.128315516281646 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,37.07034230151865 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-38.49848340742689 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,3.918309334380794 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,39.2699081698656 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,39.269908169868934 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,40.44273523989614 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,40.84071975545638 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-41.01324383724851 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.39742546339238 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.41150082346114 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.411500823461196 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.4115008234612 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.53650082346221 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.72066936079597 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,43.76746070318413 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-43.98229718005966 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,44.57301713640384 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-4.4E-323 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,45.24919939710634 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,45.55309347705005 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-46.276779842301565 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-46.575842601101435 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-4.712388980379733 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-48.69468613064163 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-48.69468613067247 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-48.81968613064206 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,49.67514082539268 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,4.9E-324 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,50.30552432756074 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,51.82029464506503 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,51.836278784230906 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,51.836278784231055 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-53.40850752321329 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.150966193681064 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.51863447327757 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.66175544375829 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.97787143781887 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.9778714378213 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-56.25811105521812 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,58.119464091408005 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,58.119464091410514 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-58.67239772655139 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,5.9719240580552935 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-6.0834930121445114E-210 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,62.17570910443502 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-62.51706381263916 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,62.90381475879455 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,64.40264939858784 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-64.95393737434314 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,65.97368986601066 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,66.59809778567654 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,72.48732406893625 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,73.18542055677807 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-73.42502296729161 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,73.59163564338482 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-73.63983589773486 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-73.82742735935453 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-75.39834721293725 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,75.5959557986371 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.95842596459725 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,77.05517754119498 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,77.51193958771424 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-80.892273144064 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-8.179511904850862 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-83.10222681514382 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,83.25220532012838 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,83.2522053201292 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-8.424777267827086 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,84.82332763155341 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-85.89303774315319 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-86.393797973716 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,87.9645943005142 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-88.98705965514644 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-90.07385774560333 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-92.66984719703115 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-92.67698328089367 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-93.17715533191313 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,94.25637982297866 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-95.5135292304934 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,95.8185759344883 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-98.34361439594005 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-98.96016858807354 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,99.24791307276313 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.570796326794325 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267948966 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267948983 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,-42.41150082344563 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,-48.12388980384689 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,50.14291505108986 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,114.668131855732 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,1.5707963267948983 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,1.5903092383487492 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-17.268688298147975 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-29.827183186276944 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,32.97045791991103 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-42.4025475783896 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-4.70500869754614 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,71.59373760750151 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,7.867722613214663 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949003,1.5707963267948948 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326795059,-73.8274273593603 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark91(-15.708024303108616,-1.228673787191397 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark91(-15.72358922284051,1.3234889800848443E-23 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark91(-15.786335747097354,-0.0783724791483878 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark91(-15.803988181717145,11.18792780230163 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark91(-15.822107684537993,1.5707963267948968 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark91(-15.826286154951381,-180.65262053404714 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark91(-160.46363215793127,-28.031927057456322 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark91(-16.134622187170372,-27.84767496308673 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark91(-1.6155871338926322E-27,-28.274333882310614 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark91(-1.6155871338926322E-27,-59.69026041830884 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark91(-16.173602917868827,-93.54650292583226 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark91(-16.206523409545103,-1.5707963267948966 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark91(-1620.8527691957831,-0.455571936629346 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark91(-16.221213905219436,-95.66334399280169 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark91(-1.6242827758820155E-114,3.248565551764031E-114 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark91(-16.255060809788773,-4.899127703322662 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark91(-16.443435931645766,61.470068537032404 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark91(-16.511923209986755,-1.5707963267948963 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark91(-16.5480680751815,91.106186954104 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark91(-16.615709751390824,29.9038677548439 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark91(-16.64096772991182,-1.5707963267948966 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark91(-16.828011099017345,-12.882460773470555 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark91(-16.83466868803147,-126.63409177820023 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark91(-168.40274334562747,97.98860073929558 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark91(-168.52856311552898,49.77756678923982 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark91(-16.88016987986917,-185.80268430608038 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark91(-169.32973295611882,-33.46890323763523 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark91(-16.955689453460707,17.681153277070266 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark91(-17.02887159992687,-1.5707963267948966 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark91(-17.078467852590023,-1.3705045846410568 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark91(-1.7105694144590052E-49,9.424777960663622 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark91(-17.112068040551712,37.82060929276017 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark91(-17.32783416585842,-62.77798532953336 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark91(-1.734723475976807E-18,-34.57118396820487 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark91(-174.3494056259014,7.105427357601002E-15 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark91(-174.38036729994153,-1.5488213010868968 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark91(-17.504758264026975,-1.3452162156189893 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark91(-175.67508438556698,5.447150535507897E-6 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark91(-1.7763568394002505E-15,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark91(-1.7763568394002505E-15,141.3716694111528 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark91(-18.062619724905232,0.0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark91(-182.206951373805,-1.5707963266325438 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark91(-18.264050877730583,-1.6649979327439179E-257 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark91(-1.8367432614250492E-40,69.11503837990858 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark91(-18.501008011542453,109.9557429910572 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark91(-18.560919547647323,91.6740367005562 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark91(-1.88079096131566E-37,1.5707963267948966 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark91(-18.84952897762942,9.424777960677016 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark91(-18.84955490033648,-34.558495751987735 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark91(-18.84955573344893,91.10618695410399 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark91(-18.84955592153873,1.5707963267948966 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark91(-18.849556209089247,-78.53980765169072 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark91(-19.029678549385004,7.839474260456782 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark91(-1.9098217742659877E-12,-28.398789285590368 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark91(-19.103722612506463,56.788557065347206 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark91(-19.116674280348306,-181.87913226733204 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark91(-19.25515338174169,-36.318213907972265 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark91(-1.9259299443872359E-34,6.283185307179585 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark91(-19.275338176079472,9.468561454174113E-7 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark91(19.34913501518689,24.275583562339406 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark91(-193.79518760122915,5.299628385841551 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark91(-19.714747800813612,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark91(1.9721522630525295E-31,-91.10667558513943 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark91(-1.9838005931103915E-16,12.56637061561163 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark91(-20.03108966885651,-69.53930249705438 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark91(-20.14734005356955,-90.93666525802804 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark91(-20.342459078798086,0.3757842184871443 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark91(-2.0373729891050207E-4,27.566884358188076 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark91(-20.377957246336642,-40.93672265764343 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark91(-20.378664142708082,-62.27993793796912 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark91(-20.420352248330236,1.5707963267948966 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark91(-20.420352248330378,1.5707963267939122 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark91(20.682250495511113,13.547654929339075 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark91(-2.1382117680737565E-50,-50.26548245743668 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark91(-21.396418157426893,-8.096833340910933 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark91(2.1684043449710089E-19,21.99114210570955 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark91(-2.176985214024803E-17,-75.39856524128662 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark91(21.99017201252297,-0.020625508725598797 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark91(21.99017226479787,-0.11587772033039742 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark91(21.99114855131333,-0.842119138077732 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark91(-21.991150005630455,87.96462494007204 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark91(-21.991163834419616,-100.53086012929633 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark91(-21.996274535115653,0.005085989284192015 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark91(-22.022398575128555,0.0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark91(-22.106537199378778,55.581100388858516 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark91(-22.18574326193112,86.1338260265322 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,128.81311129740854 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,24.43142239771676 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,-2.9290953396399042E-244 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,-62.2422134015216 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,7.792564341204934E-6 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark91(-22.21001635568139,-9.681379833016763 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark91(-22.227412093023055,27.77300507615052 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark91(-2.222937108912832E-16,6.283242307041407 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark91(-22.253519786785915,-88.97734930591173 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark91(-22.348241088675366,11.931834513686695 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark91(-22.379016947372648,-18.221392380698447 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark91(-22.41617635004357,-18.84955592153876 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark91(-22.4554486982481,-0.46430012311954894 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark91(22.51497515812737,0.6661444199839792 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark91(-22.597672269556533,-10.102002895418565 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark91(-22.718138409596342,16.709066073106513 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark91(-22.937617946648174,1.5707963267948966 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark91(-22.95123888008173,-38.659202148030694 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark91(-2.3039002592435322E-79,2.698802673467014E-79 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark91(-23.05688283947096,-60.75282184378206 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark91(-23.452585182629946,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark91(-2.350988701644575E-38,-59.6902604159257 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark91(-23.521841460273663,55.01797487947117 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark91(-23.561944901706454,-1.5707963267948966 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark91(-23.772667335373285,-1.3595721357340966 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark91(-23.82974196410825,-56.96486751907415 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark91(2.4074124304840448E-35,-50.265480230125526 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark91(-24.429328354779983,-77.26757577963907 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark91(-24.537517614903194,-0.9756456459433615 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark91(-24.60210089874984,0.09202320051967394 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark91(-24.635198256029867,-35.107258787715395 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark91(-2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark91(2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark91(-2.465190328815662E-32,-22.022398575131387 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark91(-2.465190328815662E-32,-62.83185307179585 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark91(-24.74051350969604,118.91434902078095 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark91(-24.78751436732381,-24.970953837309423 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark91(-24.861809006598335,26.751049996414025 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark91(-24.87643555494357,85.71858324724565 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark91(-24.92457730431839,-2607.785436769139 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark91(-25.13273826200168,3.1415924259966865 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark91(-25.132741421470396,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark91(-25.289436595481305,-95.32584418128455 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark91(-25.30497007987327,-20.637571682137803 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark91(-25.832777629508257,-2.1794925485637577 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark91(-26.23696461441483,-2541.8161617964074 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark91(-2.626597810834909E-32,40.840704496667314 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark91(-26.433246134650346,1.3005049059320009 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark91(-26.433577887686525,-83.33872149601913 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark91(-26.637949589250837,1.5707963267948963 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark91(-26.696285543864974,1.5707963267948966 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark91(2.710505431213761E-20,78.53981399208936 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark91(-2734.414150720746,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark91(-2734.611606622461,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark91(-2.736911063134418E-48,81.68140899333463 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark91(27.5446084357325,12.714774182744094 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark91(-2.7649407265736052E-9,-16.869318585388353 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark91(2.7755575615628914E-17,2.220446049250313E-16 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark91(-28.27436439988627,47.12388970168897 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark91(-28.28132702837011,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark91(-28.3430331014925,40.84359305404196 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark91(-28.35818725650418,-0.08385337419604144 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark91(2.855746792615355E-32,81.69703971159977 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark91(-28.59241570129919,100.0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark91(-28.714952188353184,-27.833715576263096 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark91(-28.721938063968476,1.5707963267948966 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark91(-28.73471921433803,-77.01292110552197 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark91(-28.794937188065745,17.273546431615387 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark91(-29.01251655560621,-11.433545755708423 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark91(-29.12896904046766,-0.85463515815952 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark91(-29.2353881437233,6.283185310290205 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark91(-29.349231327338245,-1.5707963267948961 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark91(-29.3722533170874,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark91(-29.637926000600494,67.22970886547847 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark91(-2.967364920549937E-67,-5.795634610449096E-70 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark91(-29.725262323334476,46.60160420697002 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark91(-29.76785998553919,-1.5707963267948983 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark91(-29.791161858240745,-1.5168279759326053 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark91(-29.80503448114132,-113.04279007847656 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark91(-300.12095071098645,-0.1404847486148062 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark91(-30.080304559924272,195.6258992148842 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark91(-30.25411171044948,-1.1618148254484537 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark91(-30.760657776022043,35.01919774555014 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark91(-31.096667576301503,-91.10618714861656 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark91(-31.19301754137875,58.97054241955868 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark91(-31.4159220952796,59.69026041820606 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark91(-31.415925399005946,-40.84072294131445 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark91(-31.415926535897928,0.0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926535897967,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926535898167,-1.5707963267948966 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926535916143,-1.5707963267948966 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926535970695,1.2037062152420224E-35 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark91(-3.141592653609996,-0.01929242483168107 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926537062098,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark91(-3.141592654055455,-1.5707963267948966 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark91(3.1415926540560086,0.0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark91(3.1415926631298476,-6.284162005914162 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926944166728,-0.020458510029863985 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415931905142256,-7.767834236494828E-5 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark91(3.1415945609859697,0.0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415945609866585,-1.5707963267948966 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark91(-3.1416006135964567,-0.16163062650946078 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark91(3.1416008347573703,-1.194328568225382 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark91(-3.1416231711683658,-3.05175817864707E-5 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark91(-3.1416231712280593,-1.5707963267948966 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark91(-3.141654449831868,-1.5707963267948966 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark91(-3.1420809348397936,-1.5707963267948966 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark91(-3.142080934839794,-4.882824330069908E-4 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark91(-3.1420809348524874,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark91(-3.142081048689492,-1.4543087336425193 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark91(-3.1420821839369353,-1.1255970331683054 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark91(3.142092499439036,-53.40707511102649 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark91(3.142149043302261,-0.5827427326658134 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark91(3.142698153934731,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark91(-3.143545778591313,1.5707963267948966 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark91(-3.143546118777787,-1.5707963267948966 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark91(3.1437138387757484,-1.485435773212283 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark91(3.1438079498750797,-31.413797064913354 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark91(-31.447176535928232,0.0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark91(3.1494062309322475,-1.5707963267948966 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark91(-31.601479582941863,9.860761315262648E-32 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark91(-31.681450879661966,-1.0816072715095806 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark91(-31.73776205650188,0.3218355206039464 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark91(3.1774666817441823,-40.876578524687865 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark91(-3.1861306721991494E-288,0.0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark91(-31.912032573381595,-83.48952468658675 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark91(-31.933870444404256,1.5707963267948966 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark91(-32.03306139851367,-1.5707963267948912 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark91(-32.20976308312531,61.0900072665419 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark91(-32.29324910709458,-58.76909541564362 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark91(-32.30262794373024,-91.21921509413127 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark91(-3.2311742677852644E-27,-9.424778692893916 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark91(3.2311742677852644E-27,-9.425945500166733 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark91(-32.370605927173536,-93.2931002164182 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark91(3.2442279000499923,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark91(3.2665926535898113,59.56544529480552 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark91(-3.2665926535905565,-1.5707963267948966 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark91(3.2665926536021868,78.51238782680457 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark91(3.2665929213930993,188.54809495077708 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark91(3.2667924311433056,31.45727391425993 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark91(-329.8677688322325,-56.54866776461439 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark91(-33.05546660081437,17.9557258641491 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark91(33.53755141875922,91.36187423759245 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark91(33.764679735339826,-90.3270532151496 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark91(34.55654262643265,-0.007735373627983613 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark91(-34.55752681900093,1.5707963267948966 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark91(-34.5893904562044,-0.03187126671806934 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark91(-346.13456801556885,1.5707963267948966 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark91(3.469446951953614E-18,-1.5553182200222326 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark91(-34.74690694712189,-26.814615526759923 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark91(-34.750691561000906,-0.1351979637566474 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark91(34.7715814107579,23.99327720937363 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark91(3.480538644469514,-119.04157484553242 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark91(-3.4918499740806155,55.14550320174999 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark91(-34.98694525609807,-1.5E-323 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark91(-35.06359994045735,1.5707963267948966 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark91(-35.091040201079416,-0.31696973346064766 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark91(-35.17172207528622,-78.03976020463762 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark91(-35.19963789406813,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark91(-35.334720361618196,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark91(-35.39650385700613,-7.122169974697992 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark91(-35.51968617523339,181.96424527200128 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark91(-35.60271189698343,-70.16023108647116 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark91(-35.63086741263071,-72.4596276547317 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark91(-35.68008800869972,-48.518042446025106 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark91(-35.69675241248926,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark91(-35.749319287438055,11.19888918305088 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark91(-35.75434874320041,-1.1968295537126843 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark91(-35.76867795921187,-1.265E-321 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark91(-35.80850014759474,2.4709862742017283E-17 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark91(-35.95627390982602,38.990409600952376 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark91(-36.0228575650683,84.77669087011168 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark91(-36.05671185592458,-98.22122076300754 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark91(-36.10984984155791,-1.5707963267948968 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark91(-36.110310325620404,-1.5707963267948968 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark91(-36.122360253642576,-1.5707963267948957 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark91(-36.127976811847006,36.12797681184699 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551627952,-1.5707963267948966 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551628053,-1.5707963267948966 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark91(-36.128315516280836,-1.5707963267948966 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551628208,-1.5707963267948966 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551628262,-1.5506345767537653 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark91(-36.12831551628262,-1.5707963267947767 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark91(3.6189448610755903,-0.0010733009898414296 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark91(-36.26995682350889,-90.87940632169206 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark91(-3.6361304492020694,35.0520569851 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark91(-3.639038949388734,79.11455469174643 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark91(-36.53750316351839,-26.37510763680008 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark91(-36.76333615844755,-0.935775684629968 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark91(-36.79038128065921,-43.83170194343815 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark91(-36.88739964492271,0.0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark91(-36.98387960394647,4.097530740842051 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark91(-37.06794817034724,-63.46301674452614 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark91(-37.19699411372328,2611.8836180997105 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark91(-37.21352944297216,93.86537882071045 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark91(-37.26513694671665,0.0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark91(-37.28018129399175,24.62037526035303 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark91(-3.7291703656001034E-155,4.5082903334625246E-131 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark91(37.34209193428626,70.14792021663189 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark91(3.735720892136783,-73.77720394375274 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark91(-37.45298642618532,15.954088684841166 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark91(-37.69895253478104,-12.566614754984204 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark91(-37.69911184262689,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark91(-37.70301809307807,-84.82300163334676 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark91(-38.00948291109781,53.43949825056697 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark91(-38.07441531718607,-205.3317948566278 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark91(3.808693751008873,-154.60514112331893 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark91(-38.15521987486243,50.78028630951778 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark91(-38.16171850097493,19.349555921538762 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark91(-3.821926632710486,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark91(-38.316038306588915,0.0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark91(-38.44224763407544,0.0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark91(-38.50019180782364,-3.9426726183359144 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark91(-38.50631546808907,-113.08851815821393 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark91(-3.8518598887744717E-34,94.27903679398682 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark91(-38.67350935739404,0.97439751431652 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark91(-3.9162097419232985E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark91(-3.924393478679036,-77.02863408355967 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark91(3.944304526105059E-31,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark91(-39.60881838059977,95.97366749820699 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark91(-4.007983824698002,15.377891943439721 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark91(-4.013499383693102,51.845904136909326 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark91(-4.0219922592243606E-16,12.566370614359174 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark91(-4.044692335475046,41.743804178552566 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark91(40.46060051811517,-79.38177552925292 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark91(-4.083637434756059E-32,-43.98229715027171 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark91(-40.840704496667314,34.55751918948773 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark91(-40.84071975545638,37.703018914249725 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark91(-40.84071975562019,-56.54866776348938 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark91(-40.84073715216051,21.99095085527984 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark91(-40.84672493799276,-0.006020441325448728 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark91(-41.19212876668278,-0.351424387175926 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark91(-41.21824525225338,66.35098648097173 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark91(-41.30000218604064,-2622.9633087221546 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark91(-41.33205095842219,-7.4E-323 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark91(-4.141592483792881,-20.980938795163006 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark91(-4.141592653589777,-27.20353754246065 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark91(-4.141592653589793,-1.5707963267948966 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark91(4.141592653589794,-75.25416384175945 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark91(-4.141592653589978,-1.5707963267948966 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark91(4.141592653592749,-53.66968385146493 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark91(4.141592834748852,84.60470281776615 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark91(4.1416041189228405,72.22470208737184 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark91(-41.65384929673567,-37.42439021991027 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark91(-41.68807965421542,-59.2522869085454 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark91(-41.7315688473727,-90.88657267993023 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark91(-42.125177009681934,63.304787157416484 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark91(-42.144507215945254,-33.25371647020978 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark91(-4.215123043566436,-96.1133412060341 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark91(-42.21818921054472,32.1506973055279 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark91(-42.237070858394524,1.5707963267948966 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark91(-42.24211962854603,-28.274333882308138 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark91(-42.31930037044429,80.72212395198086 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark91(-42.38724121516396,-1.5707963267948983 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark91(-4.240896135759158,-1.5707963267948968 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark91(-42.41150082345602,-1.5707963267948966 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark91(-42.411500823462205,-1.570796325765747 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark91(-42.411500823462205,-1.5707963267942073 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark91(-42.47904134888959,66.50097752869766 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark91(-42.53650082346221,-1.5707963267948966 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark91(-42.60806802814597,-28.342938315905954 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark91(-42.64331775628423,42.64331775628423 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark91(-42.67748811506803,-43.99707293832916 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark91(-4.268351989599638E-15,-91.1061907688013 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark91(-42.71573638898754,-84.66580470074715 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark91(-42.73833788476942,3.8214845971702656 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark91(-42.739143442731205,1.1553244005534909E-274 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark91(-427.6129260277129,1.5707963267343776 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark91(-42.808673908934196,1.5707963267948968 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark91(-42.826917408551346,91.60475815631844 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark91(-42.837130932787474,82.01561055511445 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark91(-42.84088903684602,-1.5707963267948966 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark91(-42.860407112210964,78.2891360280469 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark91(-42.86913300937598,1.5707963267948948 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark91(-42.91170422370291,42.91170422370291 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark91(-42.912825105424496,3.9415126120274238 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark91(-42.94386777400796,-10.870882210555237 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark91(-42.97573045331869,2.577363023751456 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark91(-42.98142090375357,-0.3989743659009406 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark91(-42.982297150257104,1.5707963267948966 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark91(-43.09655608513718,-0.885743178729613 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark91(-43.330899893276964,-52.547538841232644 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark91(-4.336808689942019E-19,1.0451361413042083E-199 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark91(-43.44247861859032,49.93248674200044 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark91(-43.61646598037059,86.34938133677878 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark91(-4.3643195743542113E-4,25.133177652356448 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark91(-43.800327236589425,-1.5707963267948966 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark91(-43.89711176251818,-57.252258784559615 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark91(-43.974945141008455,-12.597628475393662 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark91(-43.98229706056132,9.4039548065783E-38 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark91(-43.98425027525711,-1.5707963267948966 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark91(-4.435924121533523,0.0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark91(-4.440892098500626E-16,75.39920141879091 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark91(-44.565654742545206,0.5833797565075971 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark91(-44.5662818568419,-1.995675828504451E-18 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark91(-44.57418074626261,50.407036315791345 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark91(-44.62263070719321,-1.5707963267948968 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark91(-4.465879051575399,-74.31844131164513 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark91(-44.66120632536321,63.51076224690197 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark91(-44.760278095795336,-1.4788152327084684E-272 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark91(-44.82454472604862,-72.79622501389194 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark91(-4.4841550858394146E-44,-56.54866776461627 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark91(-4.4911360891540415,2582.4109315183873 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark91(4.518533583920578,-23.368089505459338 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark91(-45.88341016460971,-24.031040512755794 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark91(-4.602704620504966,42.63896085328054 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark91(46.33674376068012,-70.77727414536498 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark91(-4.658314982417803,2.1015228422647686E-286 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark91(46.82633021727861,76.38709735380564 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark91(-4.71238898038469,-1.570796314596783 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark91(-4.71238898038469,-1.5707963267948957 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark91(-4.7123889803846986,-1.5707963267948961 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980384759,-1.5690671007881494 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980392692,-1.568041682789762 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980499494,-1.5650485669042897 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark91(-4.7123889822389815,-1.570796445553572 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark91(-47.1248663663469,1.5707963267948966 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark91(-47.36400361190431,-27.16163613570913 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark91(-47.521341855565936,0.0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark91(-47.70034754854141,31.951430230171212 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark91(-47.70841548371349,3.3699245509503157 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark91(-4.771230632695972,92.73582493321018 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark91(-47.8171510415885,28.967595120049744 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark91(-47.88221789541795,-59.14333258263837 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark91(4.793955089348152E-15,116.23890696127565 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark91(-48.04520109332622,-26.800027223259164 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark91(-48.13398923197922,0.0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark91(-48.17228512153995,-41.92392600179953 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark91(-48.200178782912815,-59.69026041820607 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark91(-48.22812798430787,42.238116468171455 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark91(-48.25655625945468,0.0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark91(-48.37555264185283,-72.71439322525046 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark91(-48.49569855206357,2612.9114880722204 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark91(-48.6782203705231,-1.5707963267948983 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark91(-48.68646006401632,-1.5625702601694151 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark91(-48.69468613063888,-1.5707963267948966 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark91(-48.694686130639006,-1.5707963267948966 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark91(-48.697217190863235,-45.5776415015805 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark91(-48.697742556277944,70.06088227940447 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark91(-4.870326360683055,4.8716711447119385 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark91(-48.719351689649926,-45.49129065097242 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark91(-48.733528512065114,-0.03884479085012788 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark91(-48.73807961771983,-25.376955899764383 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark91(-48.7664826474288,26.394852822341896 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark91(-48.790624844234685,4.168719574169934 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark91(-48.844831804226715,12.138471327968276 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark91(-48.89102113997097,-1.5707963267948983 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark91(-4.892594752242217,4.892594752242216 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark91(-4.896087794914895,61.444755559531174 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark91(-48.976407303321444,47.9066518929841 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark91(-49.295053359796356,-21.643520404700496 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark91(-4.932228826865829,-45.77293332353314 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark91(-49.487559817873255,-80.71754040693276 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark91(-49.50677684099918,-0.8120848087310967 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark91(-49.69553170535536,-0.5699604444631352 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark91(-49.70916646531227,40.70301435643279 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark91(-49.74021780763298,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark91(-49.754265141943854,19.12591620919497 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark91(-49.76547702349857,-19.349561355476883 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark91(-49.76654977676581,-74.08970471707087 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark91(-49.7811670958548,84.85349741953668 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark91(-49.78857976589017,34.72390375796908 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark91(-49.81620072643322,-0.4492817310034687 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark91(-49.837034361740024,-73.71232913285884 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark91(-4.985405261098759,1.5707963267948966 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark91(-49.86138207610773,-57.741849174196545 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark91(-49.86788651422812,-80.95772544690935 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark91(-49.877154708370554,-82.06973674240076 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark91(-49.938850165438524,5.94792935277657 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark91(-49.93949791273127,-2621.052255707061 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark91(-49.94319818580599,90.0411255539972 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark91(-49.97982754883818,-26.369178628980734 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark91(50.00805279806971,-65.48410450410046 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark91(-50.028982860748265,6.567966768414962 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark91(-50.04080644164621,-5.648665246041364 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark91(-50.04592709266876,-1.570795979989882 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark91(-50.090017814458584,14.62385924738853 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark91(-50.127330653649835,-66.97108155726397 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark91(-50.148624377106145,2583.522637820216 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark91(-50.15888992492623,17.62388662373263 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark91(-50.19769883653338,-34.69581799694615 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark91(-50.265474384889636,141.3716200048869 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark91(-50.26548166001822,78.53981458406822 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark91(-50.26548243009238,1.0339757656912846E-25 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark91(-50.26548245212757,-232.4543277362176 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark91(-50.26548245676136,-50.265482429388335 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark91(-50.26548245743625,103.67241697790845 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark91(-50.43251904327514,-0.16690096643884927 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark91(-5.0487097934144756E-29,1.5707963267948966 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark91(-50.56402291606112,1.5707963267948966 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark91(-50.57729109484386,-22.548933609303745 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark91(-50.5929892834297,0.0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark91(-50.5930926749752,-22.133193052196717 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark91(-50.7512876877682,-56.062862534284776 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark91(-5.0899705229276475E-33,-12.566370614358986 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark91(-5.124787430228395,25.99424878393315 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark91(51.294136922028315,-40.50465525351888 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark91(-513.1718728387274,-1.0676709688321295 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark91(-5.132713915745742,4.292064045023638 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark91(51.38662345271325,12.451711795639511 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark91(-5.293955920339377E-23,-6.283183632504411 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark91(53.02611140046892,-7.921572917531222 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark91(53.04396862814207,59.67581850933823 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark91(-5.311521034662176,43.010632877739695 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark91(-53.40707512071955,-1.907348698232069E-6 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark91(-53.40707701837512,0.0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark91(-53.48601885172424,93.77589807975619 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark91(-5.352876922849862,-21.060840190798828 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark91(-53.54403825369557,-0.13696314266908308 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark91(-53.555310983807615,66.52911004628038 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark91(-53.63604891971717,-8.362041744266975 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark91(-53.65707511102649,1.5707963267948966 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark91(-53.934099631779205,-32.15564210074429 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark91(-53.96414226146371,-1.5707963267948966 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark91(-54.415737411052376,0.0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark91(-54.445214623288976,1.0261342003245941E-289 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark91(-54.47383182012772,0.008142593673954146 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark91(-5.45252817978551,79.37047346713891 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark91(-54.54076181741199,2649.867262155288 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark91(-54.59101986429567,-2639.4201859120685 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark91(-54.59204270959426,9.603051034649638 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark91(54.60602570806728,97.72208257714746 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark91(-54.610932866418686,-57.752525520008476 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark91(-54.654441166589365,-11.975758898676453 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark91(-54.71485807677432,8.389653757014187 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark91(-54.72514121983381,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark91(-54.961377062800395,-1.570796326794536 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark91(-54.97786486201776,-7.853981832570235 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark91(-54.977871437814315,-1.5707963267948966 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark91(-54.977871437823296,-1.5707963267948877 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark91(-55.054416425250245,7.853981633977187 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark91(-55.06963739074222,-98.98704895813204 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark91(-55.11507873671759,-1.2283083360220253 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark91(-551.2904767661436,-0.8326814150861588 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark91(-55.13213962997882,-90.06901119873564 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark91(-55.13803340219898,73.70625464497459 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark91(-55.14117310612046,-91.10618695467947 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark91(-55.14773677078017,112.08071799978359 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark91(-55.16020708331648,-67.26082375017057 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark91(-55.16073863259792,-56.21512444907374 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark91(-5.51624027230852E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark91(-55.16867646044778,2.7791405132821723 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark91(-55.17640753465791,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark91(-55.191529463125356,-90.04220313218336 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark91(-55.20317066839293,4.9528284499886395 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark91(-55.20780780475712,5.319094240946197 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark91(-55.22624893556113,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark91(-55.22656976968945,-26.72489894210861 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark91(-55.22748247778507,2367.081902842527 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark91(-55.22861104731081,-27.681035549723703 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark91(-55.23565266323067,-1.5707963267948968 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark91(-55.26986656473909,-1.5707963267948966 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark91(-55.299117171294064,-1.2495505933222146 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark91(-55.32093821956152,67.20117527044042 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark91(55.33242402242567,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark91(-55.40475130430216,-80.53037693114975 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark91(-55.41384417755934,4.330909994620114 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark91(-55.44820034641768,-70.09439323462314 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark91(-55.47593427553992,-56.64756048325965 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark91(-5.551115123125783E-17,0.0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark91(-5.551115123125783E-17,2.2509561272213152E-11 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark91(-5.551115123125783E-17,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark91(5.551115123125783E-17,-28.274335781965057 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark91(-5.551115123125783E-17,43.98229716020317 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark91(-55.52673547028144,-40.36744706964271 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark91(-55.52756554604668,0.0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark91(-55.64933126256028,-0.8993365020559971 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark91(-55.73209662386287,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark91(-55.79480225580002,51.365544508477086 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark91(-55.95552507484071,16.861299218264932 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark91(-55.98931758366717,3.7009428345388984 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark91(-55.997165253383066,1.5707963267948877 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark91(-56.02603894573322,-0.5226288188830588 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark91(-56.02661451482003,-82.88109011524755 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark91(-56.04802698274675,-15.974334956535117 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark91(-56.084285983895924,-27.809952101587786 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark91(-56.08500270598505,-25.880689886415205 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark91(-5.613525544451932,79.7746212401048 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark91(-56.14066854479648,-61.818144643438934 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark91(-56.18874699216765,23.633827730561414 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark91(-56.28655744848403,61.56561714421638 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark91(-56.31055314673554,-44.650047988295526 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark91(-56.34172734467312,10.089588889230413 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark91(-56.34297554808738,27.85818760903024 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark91(-56.402808209911186,60.14335611149829 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark91(-56.425282514014995,-30.560608197474266 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark91(-56.49407737506473,34.61210957903928 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark91(-56.52003067971158,-2570.763705622445 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark91(-56.53354906534409,-1.5707963267948966 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866774650133,-163.35793389084424 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866775912491,-53.407075591742256 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776461548,-37.699111818957704 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776461626,6.018531076210112E-36 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776461627,1.5707963267948966 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776461627,65.96940727195988 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776461629,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark91(-56.552578281588254,-94.24778727983342 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark91(-5.656685539522154,-8.538542640341127 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark91(-56.57794543740086,-55.79994667120085 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark91(-56.69745699576407,-32.030668472344885 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark91(-56.745967448243505,0.19729968362722652 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark91(-56.798667764518704,-34.807519189588895 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark91(-5.690070000051975,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark91(-57.36579932536583,25.413844116595556 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark91(-5.752220392306203,100.0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark91(-57.76323291905516,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark91(-57.92409459979992,-6.27055757470572 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark91(-58.75651042861767,-20.83876467065855 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark91(-5.887974688080405,58.859786523744646 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark91(5.964169426497156E-17,-50.26548166733776 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark91(-59.691236980806444,3.944304526105059E-31 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark91(-59.735495694443614,-12.566370614576774 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark91(-59.80563244774042,51.27929154317823 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark91(-59.893801822552774,-17.18259402601788 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark91(59.89902046070293,-1.067350847880661 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark91(-5.991557192294796E-6,-72.26053728256527 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark91(-6.020291319185262,-5.544548160402101 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark91(-60.34060018140042,-63.47473670548332 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark91(-60.3717794632249,50.17532206221601 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark91(-60.38071547268001,15.900239333110761 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark91(-6.049366807187545,-0.2338375854661172 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark91(-60.49412491636757,-3.3256741720626053 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark91(-60.592501750443375,-0.902241332237304 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark91(-60.65432068505445,-137.3919538994563 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark91(-60.99526678406982,-181.79676689680122 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark91(-61.04949780997717,0.0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark91(-61.109125808811136,-26.775492294146503 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark91(-6.124695328976706,89.20829363315175 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark91(-61.25360870590321,55.32514680905655 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark91(-61.2610567449994,-1.5707963267948966 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark91(-61.261056745000964,-1.5707963267921705 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark91(-61.3175650793218,-41.79506351581905 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark91(-6.1525441030642725,-48.46454941113978 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark91(-6.179466034004946,-1.5707963267948968 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark91(-61.86221591965998,68.14540122683957 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark91(-62.071487299004424,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark91(-62.14518365357798,-0.6866694364645598 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark91(-62.28418577242012,-84.27533434754868 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark91(-623.5625490056133,0.5475605025178231 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark91(-62.3828360845051,-47.83879971885922 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark91(-62.534532141322494,90.1109884425005 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark91(-62.61921044408194,-8.382489453188995 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark91(-62.83185300706616,-131.94689143625118 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark91(-62.83185307179587,1.5707963267948966 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185307196915,1.5357263102530345E-11 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185307284785,0.10392308554240465 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark91(-6.2831853369819095,1.5707963267948966 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185337922589,0.04395569055522917 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185784016745,1.5707963267948966 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185784016746,1.5707963267948966 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185786076208,4.786697790150983E-7 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark91(-62.83209721242087,-1.5707963267948966 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark91(-6.283214571730614,1.5707963267948968 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark91(-6.283816351778465,1.5707963267948966 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark91(-6.287091557309307,0.0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark91(-6.290460958704486,-84.99058846735295 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark91(-62.949973547836315,36.054758996350216 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark91(-6.304158649750546,-0.02103660263298515 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark91(-63.345691852973474,12.571599077662453 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark91(-63.41467781332841,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark91(-63.589267666999305,-36.33969473721122 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark91(-63.73395706369121,-43.080193158361766 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark91(-63.93233081452415,-26.37078063872285 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark91(-6.394337712833359E-8,113.09733550528827 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark91(-63.980402564182114,-24.049595848237644 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark91(-64.00816590915734,-11.390057776997697 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark91(-64.18302251736766,1.5707963267948968 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark91(6.42526529357001,-50.40756244382708 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark91(-64.38617547401887,-1.5707963267948966 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark91(-64.40264625846373,1.5707931866753928 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark91(-6.462348535570529E-27,34.557518571473985 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark91(-6.462348535570529E-27,62.894353140348 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark91(-65.7278464631232,-6.507588186464616 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark91(-65.97344575447427,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark91(-65.98125822551296,-81.68140899016602 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark91(-66.06661986759364,1.5707963267876832 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark91(-66.11881519905101,68.9317932333442 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark91(-6.616636342266349E-15,12.566395810409421 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark91(-66.21465209139294,29.961408974404513 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark91(-66.37296599659118,88.93061230227387 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark91(-66.44452992060432,-44.37564435993373 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark91(-6.650973046009767,-31.058360305366833 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark91(-6.667555033968426,26.135033564690218 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark91(-66.70840546844184,-65.28397059934721 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark91(-66.73156232763466,10.629287919583348 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark91(-66.76605833095746,0.6438708095901688 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark91(-66.83367950599916,4.001826434203292 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark91(-66.84788955899882,-41.304688588898415 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark91(-66.87638568196064,-60.84912359073762 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark91(-67.14569193277256,-24.60894618297182 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark91(-67.26156756315842,-53.54447127527381 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark91(-67.39428725024503,-78.52029839064076 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark91(-67.47934121190244,-10.705527253371875 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark91(-67.4804770177239,-95.98972353068285 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark91(-67.52853430913746,-1.555088583751806 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark91(-67.54424205217511,-1.5707963267948966 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark91(-67.54424205218055,-1.5707963267921712 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark91(-67.54424205218055,-1.570796326794896 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark91(-67.54424205218055,-1.5707963267948963 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark91(-675.7597809166518,-0.8320364600090178 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark91(-67.58742123831756,-82.91185136126573 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark91(-67.69303171462867,1.7800590868057611E-307 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark91(-67.70132159147636,4.555309441088887 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark91(6.776263578034403E-21,-9.487279504589285 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark91(-67.88417462398182,-21.75402606730347 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark91(-68.06610951209491,-55.40801167202274 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark91(-68.0792108972989,173.82342342911517 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark91(-68.08583040335004,-1.0291399987249947 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark91(-6.81415022205297,-100.0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark91(-68.21340366535725,-66.02873454968308 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark91(68.45768977538708,4.266217135540856 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark91(-68.66860689869569,-19.604827332305803 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark91(-68.72689522470392,-42.07111749129213 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark91(-68.9625122496701,117.93180032492826 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark91(-6.900382752023313,-1.2661587803118082 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark91(69.10682209173953,64.49187778577809 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark91(-69.11503836905369,56.54866824419861 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark91(-69.11699150397651,-69.11699150399403 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark91(-69.19205641830504,-0.07694192897212444 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark91(-6.938893903907228E-18,0.0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark91(6.938893903907228E-18,-47.139516404970394 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark91(-6.955592741507596E-32,72.25663104136464 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark91(-69.72023528259683,7.4E-323 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark91(-69.86726189530191,35.75435841627373 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark91(-69.97808076599549,-25.212286821696022 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark91(-69.98601464817509,2687.971142428742 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark91(-70.0145622416942,-80.89511999143377 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark91(-7.00483942112983E-14,-128.80632587087229 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark91(-70.13992526920269,-51.21244913902638 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark91(-7.01581821634319,57.1254985248392 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark91(-7.042015088523044,0.0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark91(-70.47119221482585,-2524.1760251036953 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark91(-70.68583470576749,1.5707963267948966 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark91(-7.082243185248103,-3.250461934330917 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark91(70.85102412422853,-59.83177106650628 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark91(-7.151018426514548,7.151018426514548 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark91(-7.199440340920887,1.5707963267948957 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark91(-7.21519941097957,63.76386717559585 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark91(-7.215686695009888,-36.76661045524722 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark91(72.20169003585679,17.762088195542376 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark91(-72.25663103351373,-1.5707963267948963 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark91(-72.25663104519043,-15.723588706576022 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark91(-72.25663151010498,-0.031172459521086937 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark91(-72.25763764370186,229.33625961414742 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark91(72.32322405005127,-31.600652330800074 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark91(-72.54401483946205,-1.5707963267948963 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark91(72.54727344833469,96.28530158877575 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark91(-72.57679838584244,55.20899504638706 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark91(-72.58140160484993,-75.6895904418444 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark91(-72.58703252506741,8.146420921375373 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark91(-72.68671852731619,87.87642713483947 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark91(-72.72336997771609,47.254887378308865 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark91(-72.72863038786453,92.01016017352042 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark91(-72.73715779111359,94.50880489602065 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark91(-72.74957322535107,24.85227774509775 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark91(-72.77366187390977,-0.5173770483212805 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark91(-73.05702746622288,11.884591666722798 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark91(-73.10554688106707,1.5707963267948966 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark91(-73.16201029599492,78.06399486685521 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark91(-73.2430859053997,117.5234002604571 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark91(-73.26452761428526,1.5707963267948966 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark91(-7.331075975204449,-42.74291392987108 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark91(-73.41203319428139,-115.38911889987077 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark91(-73.43640833843999,71.66876098562213 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark91(-73.47902701760148,-61.51457746659512 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark91(-73.49081107023392,-21.726835421396505 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark91(-73.52550594729736,0.0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark91(-7.364781617907219,-72.89006784852197 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark91(-73.68638592472728,0.4719734188389799 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark91(-73.81502802606893,-1.5707915868965163 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark91(-739.2191338108964,-0.5269693487957028 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark91(-73.93734041181833,88.76807888709499 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark91(-74.30068526077133,1.1595085070965132 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark91(-7.437974949247016,-49.11069281536926 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark91(-74.48576995058376,-4.666731699377621 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark91(-74.53475659342186,-1.5707963267948966 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark91(-74.68007799986404,-37.675120670355696 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark91(-74.82333091673576,-68.66126999339619 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark91(-74.94985680570707,-36.45795915888781 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark91(-7.500941699901763,-167.72216703298122 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark91(-7.529062202107634,-80.14312712969975 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark91(-75.3445274899374,-53.119394191435546 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark91(75.38285774372471,-12.902062385401862 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark91(-75.3982218647757,-15.708024303105217 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark91(-75.39822368369134,-2.4208850371403023E-9 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark91(-75.39822368615502,0.0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark91(-75.9643227439861,-3.170538680531436 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark91(-75.96556758875555,6.850529209780096 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark91(-7.622940887247646,-36.35935626300946 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark91(-7.640402192869104,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark91(-76.96541938969288,1.5707963267948948 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark91(-76.96902001294306,1.5707963267948966 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark91(-76.96902001294555,1.5707963267948966 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark91(-7.702888002066402,-8.9E-323 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark91(-77.21283411134519,76.89433576374259 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark91(-7.76569417330327,20.377349712312906 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark91(-7.844093573724539,1.5707963267948966 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark91(-7.852030473772615,68.18538152400183 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark91(-7.8520339284245075,2507.5773086477275 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633974483,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633974485,-1.5707963238097593 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark91(-78.53981633974485,-1.5707963267948966 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633974842,-1.4653017050672046 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark91(7.85398163399742,-1.5595038583401248 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark91(-78.53987737547708,-47.139514805854816 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark91(-78.53987948821506,-50.26548168592847 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark91(-78.54030462109935,-9.424785567593792 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark91(7.854038328531333,1.5707963267948966 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark91(-78.66704141064353,1.3508068024458167E-225 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark91(-78.66721106858114,13.17954446605134 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark91(-78.69350951899395,-0.15369317924911788 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark91(-78.76233864522135,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark91(-78.77521990921836,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark91(-78.89858593100409,-0.3587694507830545 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark91(-78.90005599094543,-137.31777393702433 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark91(-78.90454269682662,41.20543085374911 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark91(-78.98205756200463,-1.5707963267948957 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark91(-79.00311788586814,-0.4633015461233048 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark91(-79.30780043153244,44.25672178852162 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark91(-79.38595797268854,48.39047071554053 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark91(-79.3916743579471,-109.1038848574405 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark91(7.952591924211871,61.16249871002633 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark91(-79.71670794536317,0.0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark91(-79.88045126130763,2.173120587952667 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark91(-80.03752614256297,72.25663103256524 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark91(-80.04567640530134,-1.5084994663548392 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark91(-80.04724539293153,-1.5074290531866976 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark91(-80.11061266653473,-1.5707963267948966 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark91(-80.11061266653972,-1.5707963267910108 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark91(-80.11061266654046,-1.570796326793917 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark91(-80.16318340982907,-1.5209063385171966 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark91(-80.33260969675995,-89.83487319116894 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark91(-80.46905728344045,-81.79543717563746 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark91(-80.4861708864645,-3.9938504481543644 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark91(-80.80154072824412,-0.879868265090504 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark91(8.103981633974488,-1.3197603802435278 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark91(-81.17985872665689,-0.24824247609002656 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark91(-81.27103605604407,-44.97751554959972 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark91(-81.46497154069408,68.77260979956156 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark91(-81.48519084189871,10.809990363413597 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark91(-81.48721185025977,1.5707963267948912 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark91(-81.53861363682014,6.140389950665107 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark91(-81.63192845471745,-0.0494805386171709 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark91(-81.68140899302435,-113.09729442528648 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark91(-81.6955394084805,-60.68559144938816 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark91(-82.9081475461006,94.88329386734429 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark91(-83.04723523510415,-73.91378403139461 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark91(-83.1862973526149,-73.89333532687476 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark91(-83.25220532012848,1.5707963267948966 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark91(-836.4414786523838,0.10563317392512772 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark91(83.96154880830912,78.21542179245847 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark91(8.470329472543003E-22,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark91(-8.470329472543003E-22,25.13274122871832 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark91(-84.84196375146347,-51.225967608912306 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark91(-84.8522700699873,0.0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark91(-84.85257093169616,-1.5707963267948966 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark91(-8.489907097183892E-26,-37.69911184307749 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark91(-84.96205857439925,77.37026544552808 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark91(-85.0432348891481,75.00447175049112 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark91(8.506211013758332,80.76258070906937 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark91(-85.07487469502722,-0.25189179114255655 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark91(-85.30413268392476,-7.646486644072198 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark91(-85.64534285311626,1.5707963267948912 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark91(-85.75609455593307,0.0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark91(-8.585119448921003E-13,72.25663103256439 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark91(-858.5219966972828,-1.5707963267948966 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark91(-85.91209442928754,-64.92310183549526 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark91(-86.14705969044118,-3.0E-323 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark91(-86.37115773456722,-1.5707963267947953 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark91(-86.40882089515401,-7.166311744571786 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark91(-86.48716988954388,-1.664168242619462 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark91(-86.6417369447877,125.72591063100494 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark91(86.69512235685121,37.50256928820562 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark91(-86.7094372347545,48.910219259152 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark91(-8.673617379884035E-19,-28.274333882296602 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark91(-86.89889721062809,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark91(-86.95557843440278,-94.26834713103446 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark91(-86.98662559679856,1.5707963267948968 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark91(-87.17848752217658,0.0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark91(-8.74856862946296E-34,28.274333882296645 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark91(-8.758115402030107E-47,12.566378243753768 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark91(-87.61158727047342,-0.2692313201535441 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark91(-87.73285810476835,22.22288477087441 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark91(-87.78315262115927,-0.18144167935493613 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark91(-87.96850055177826,-72.25663077336182 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark91(-87.98867927882556,-37.69538184723329 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark91(-88.08131597085894,9.150944847214262 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark91(8.85398163397448,-0.5744237162157946 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark91(8.853981633974485,-27.691528975197283 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark91(8.853981634571712,111.75194978454932 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark91(8.856549060522662,-1.4753432015855965 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,-100.0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,14.15328287093672 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,-3.1418038668898234 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark91(-89.53539062730823,1.5707963267948966 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark91(-89.53539062730911,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark91(8.97416974451136,97.84140239811974 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark91(90.99044059430315,83.20130979872798 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark91(-91.22226603419568,31.367582565679232 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark91(-91.25779809599278,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark91(-91.33138026981234,2609.322274439901 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark91(-91.6371518689774,99.99999999999999 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark91(9.169972496806833,-0.2576509319185842 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark91(-91.78375951594609,-2.42298627221102 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark91(-91.80085563378668,64.63769740245061 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark91(-91.85892031347768,2.53E-321 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark91(-91.86505486301462,-0.7588679089106165 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark91(-92.120155877305,-3.604407557629287 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark91(-92.1511733150318,1.5707963267948968 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark91(-92.26122090486699,-2601.7019281658436 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark91(-92.27414143768954,84.82300164692444 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark91(-92.3068898088913,0.0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark91(-92.39041752508254,-1.2842305709785364 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark91(-92.40061186481658,10.334009392264477 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark91(-92.45070787474664,-18.849555928528083 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark91(-92.46180536314324,89.89448185647376 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark91(-92.53690650343948,-2.8574684782056875E-101 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark91(92.60580149060539,-27.958149943282564 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark91(-92.62421894875195,-1.5180319946479397 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark91(-92.67077722438715,-1.5707963267949006 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark91(-92.67698912408032,130.3766015231412 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark91(-92.67958877284866,-1.5707963267948957 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark91(-92.72439550325848,-1.5233841044353147 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark91(-92.95410918758154,-70.96296061245299 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark91(-93.1727168070433,55.473604963965784 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark91(-93.33567567292967,83.28758124563949 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark91(9.345436998312884,113.01274236470691 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark91(-93.46679481610826,-19.630540713124294 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark91(-93.57358714810967,27.07315563536787 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark91(-93.75516587173074,26.655641989114855 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark91(-94.00992814417934,-6.6599917309756716E-257 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark91(-94.02785957075297,24.81400614005615 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark91(-94.19645933608673,3.266592653604592 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark91(-94.24777960717918,94.2790296076938 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark91(-94.24777960769083,78.53981633974482 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark91(-94.24777960769349,6.950458397316136E-33 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark91(-94.24777960769377,1.5707963267948966 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark91(9.424777960769477,-1.340238507102451 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark91(-9.425266242382403,-147.65510420072505 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark91(-9.42526624506714,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark91(-9.45689747084522,-0.0321189668932876 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark91(-94.6147426341137,-5.443703071045334 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark91(-9.470035434826814,-75.44348116021247 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark91(-9.493213645161106,-55.24032096204574 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark91(-94.96070625171981,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark91(-94.9999012457061,0.0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark91(-95.06720394726172,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark91(-9.56386161990119,50.65671182778638 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark91(-9.599553604591634,59.29502556180071 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark91(-9.606297561524308,21.76496011824544 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark91(-9.619509994061232,16.706924957914644 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark91(-9.621340682005581,52.033993542468636 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark91(-9.629649721936179E-35,-9.424779086916192 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark91(96.77668142877266,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark91(97.00926112047043,39.935176606444315 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark91(-9.723319626588037,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark91(-9.7310620189796,76.42700828530477 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark91(-97.39718537490536,21.99114857512802 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark91(-97.43513764538292,-2634.6735620830145 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark91(-97.44923459972124,-0.05986233843764641 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark91(-97.45187223448039,-1.5707963267948966 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark91(-97.46658489342913,3.2665926535897936 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark91(-97.4838852008181,-51.20679348605799 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark91(-97.68248634187714,24.839627148124798 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark91(-9.773497120691331,-93.36638759790175 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark91(-97.95730825117579,-84.25506565703222 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark91(-97.96413604504488,-91.106186954104 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark91(-98.02778399876316,-48.58593312755987 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark91(-98.11599994373219,-24.175389794496823 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark91(-98.12333413748821,6.28318530717953 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark91(-98.1678797921813,-19.2976291262341 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark91(-98.17150680277902,91.79622202061202 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark91(-98.3012038078932,-0.9118315466096117 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark91(-98.36107367384092,-0.5561038085609482 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark91(-9.860761315262648E-32,1.5707963267948966 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark91(9.860761315262648E-32,50.2654880193916 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark91(-9.860761315262648E-32,-6.28330953768671 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark91(-98.64197841926166,-64.11810524542324 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark91(-98.79673683764929,-20.471966471235696 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark91(-98.95425509703686,-20.42626573937528 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark91(-98.96016858807782,-1.5707963267948966 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark91(-98.96153489714207,-1.5707963267948966 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark91(-99.2400932325819,30.553308232375628 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark91(-9.92498952501911,48.78364580380067 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark91(-99.46919155427895,88.10963782921411 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark91(-9.947810340619403,-27.751301502458116 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark91(-99.48087445743249,1.9037439192102918 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark91(-99.52677518635484,-1.0041897285185437 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark91(-99.6348567530882,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark91(-99.97343748378607,40.22426435690511 ) ;
  }
}
