import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(0.0013358525182792398,0.23566131812985447 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(0.0027078717227942972,0.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(0.004929934771304545,1.5707963267948966 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark03(0.014005301056318545,-44.97596022281558 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark03(0.015581806416633013,-63.83712959837633 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark03(0.016304619222229054,-46.08420306578924 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark03(-0.02246027799448408,-56.864612219798374 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark03(0.03462673373429754,4.721039156323593 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark03(0.038577984487755124,16.626099742262777 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark03(-0.03975662353253627,-42.37174419992967 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark03(0.04093199066908504,-1.5707963267948968 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark03(0.04178598325456484,31.368605329066096 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark03(0.04784911094733957,-22.130006841443787 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark03(0.04950060314967253,-83.02333397171554 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark03(0.05057121711516133,0.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark03(-0.05124927592578326,-97.26647332734599 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark03(0.054225635109742765,0.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark03(0.06445504103235593,-0.034406943463062216 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark03(-0.06606136032043186,-100.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark03(-0.067591316787451,14.20475825794152 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark03(-0.0749373513487066,-42.925017461010825 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark03(-0.09201947645417251,21.318885733368482 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark03(0.09644745130628962,71.8205373129225 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark03(-0.10328349547632099,0.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark03(0.11031916296356314,65.04528852919404 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark03(0.12052516789123523,-67.56910393564337 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark03(0.12338492904843561,-11.395533560812941 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark03(0.1443206213483171,58.518770820520665 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark03(-0.14811248648912256,-49.905885858452194 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark03(0.15361546405226445,-98.06926801813083 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark03(0.16211071600904334,-23.724055617932493 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark03(0.1646084027165884,59.22960943959769 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark03(-0.17745096623398027,-43.158222917322966 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark03(-0.1793150311418598,23.801200182849918 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark03(0.18343176390635607,-2592.5380400768936 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark03(-0.183719069483061,40.521148194570465 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark03(0.18547696701981028,88.88079706807801 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark03(-0.19826068176209186,98.7619079063164 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark03(0.20577942002188704,-9.634326432455936 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark03(0.21355675715903122,0.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark03(0.21840028711572912,-1.5707963267948966 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark03(-0.22575620155531062,-45.52224522108625 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark03(-0.23369560688587923,-53.40338917142461 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark03(-0.2358075934490209,-65.85928559357708 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark03(0.24027325897333382,95.57830267551536 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark03(-0.2412836014822429,-89.77667422879135 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark03(-0.24790798263595581,-58.40176539270494 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark03(0.25966320578454916,-2.4316228317923563 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark03(0.2633249686204983,0.15921648739106917 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark03(-0.27062735517072056,-2474.6447903896287 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark03(0.27085346736659216,6.126625490529049E-17 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark03(-0.30252746280956533,-8.244031628147624 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark03(-0.3026713556851788,-1.5707963267948966 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark03(0.30739563732692843,-1.5707963267948961 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark03(-0.3101351601487487,84.56510446231053 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark03(0.31398337568219714,-1.3200585652783714 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark03(0.31940794785186166,-30.164538156954897 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark03(-0.32141752724052175,4.327046368168531 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark03(-0.3252120345789047,2423.4229256166677 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark03(0.33009944962822474,-15.458315868576417 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark03(-0.3367388190829509,-26.157482449710745 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark03(0.3484952901721625,0.0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark03(-0.3519438375964512,-71.73327776981878 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark03(-0.3637916338271042,-1.570796326794886 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark03(0.36491128371113746,79.42135809365297 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark03(-0.384501895246405,-94.36157192251449 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark03(0.3928900854124411,-1.5707963267948972 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark03(-0.40143720312832354,-198.08813249218545 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark03(-0.40258602247352293,76.36372895586234 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark03(0.42896987735665004,1.5707963267948968 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark03(0.43882284570525776,24.01845169887148 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark03(0.44614054625691324,-23.793645519404954 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark03(-0.4553656285476677,-36.091786182883624 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark03(-0.45611286295139086,1.5707963267949019 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark03(-0.45720773499502343,-5.896418179662064 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark03(-0.4710345871026327,68.62441519294214 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark03(0.47796069585908496,1.5707963267949054 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark03(-0.4965775519378326,-29.624070616870238 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark03(0.5019890608345463,19.3706503551238 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark03(0.5127231950589568,0.49538984531825514 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark03(0.5195677203334128,80.57962028198713 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark03(0.5211886947583633,-79.43271423318596 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark03(-0.5428425217805568,-132.94234094728372 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark03(-0.5585783430756499,-1.5707963267948966 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark03(0.5700182541223231,-55.806027986188326 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark03(0.5800398367562518,50.32747579999286 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark03(0.5881871534030336,-38.68172101646938 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark03(-0.5927671088905409,0.002140846874276725 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark03(0.6094229125526656,-31.668459574651685 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark03(0.6147041080256073,-36.40887751047124 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark03(-0.6175892668099354,1.5707963267948948 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark03(-0.653322453694031,-85.32683593805982 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark03(-0.663537754823821,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark03(0.6874586136658802,1.5707963267948972 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark03(0.6977956811898747,44.998752555475136 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark03(-0.7063083427174885,-95.81857593448869 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark03(-0.7160552208091828,49.16313121592336 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark03(0.7351903567804955,61.996247101781464 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark03(0.7406836978078566,2.220446049250313E-16 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark03(-0.7427563401146529,1.5707963267920537 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark03(-0.7559071481393795,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark03(0.7570216807056767,-47.88431863900441 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark03(0.7597229005948298,1.5707963267948966 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark03(0.7603242806913242,-64.2959338231845 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark03(-0.7655566727491074,-0.024001571766937894 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark03(0.8039518091710471,75.87681247531691 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark03(0.8343003140914647,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark03(-0.848045020923924,14.429215890455808 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark03(-0.8574010032571469,0.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark03(0.8626759620978572,2565.76277966222 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark03(0.8935024789339843,100.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark03(0.9000628995145377,-45.00693091540422 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark03(-0.9020827160393392,35.3052913517765 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark03(0.9168500451348933,-76.42226912337871 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark03(-0.9394168090293107,1.5707963267949054 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark03(-0.9471557294812136,-1.5707963267948968 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark03(-0.9477889107228791,-91.51747757324185 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark03(0.963110230066185,-62.0907030343294 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark03(-0.9695522850282572,34.55443659168478 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark03(-0.9808877394892705,1.5604558794977386 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark03(0.9862698164091706,1.5573897815884448E-16 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,0.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-0.1449451426314748 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,0.20993347413052466 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,0.2720597413877582 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-100.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-11.526539202437661 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-1.4478711930965115E-8 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,1.5707963267948963 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,1.570796326794897 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-1.5707963267948972 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-16.486590281329526 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-38.76604923803788 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-59.77143010243564 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-68.98482759000014 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,72.66063579911975 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-7.324086943178465 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-87.89614378780612 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,93.05722947451329 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark03(-100.52706522027641,-42.411500823441294 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark03(-100.5298296613656,-10.995574284363498 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark03(100.53868951467994,-67.54424205119638 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark03(-1.0054632270380361,8.872976256625066 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark03(100.63449596821857,0.34184997894671676 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark03(100.78718074902118,-18.389083853578484 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark03(-100.97402793668704,58.49925183594564 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark03(-1.0165953978257782,-1.5707963267948966 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark03(101.90244462308166,66.43813337308299 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark03(102.10176124127538,0.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark03(1.0270605283076821,0.604571745790051 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark03(1.0351150698438984,-0.24834982959451768 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark03(-103.67177379286927,4.7436389803847225 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark03(-1.0393074493932148,0.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark03(-1.0424208586010568,21.991148575128552 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark03(-104.27351632264218,-0.5705656001781706 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark03(-104.39968518023034,9.72423018085625 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark03(-10.448229144896132,2632.1300871822177 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark03(-104.8508844379302,-6.118709316474908 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark03(-1.0505660641771746,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark03(-10.50910594512088,100.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark03(1.0651859965630308,-67.23744971880797 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark03(-106.81318949381436,10.995574287555476 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark03(-106.81418500734995,-83.2522053149225 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark03(106.81422038116347,-1.5707261676844009 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark03(1.0730045797132632,6.646634264666923 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark03(107.46516069027489,0.5527386677270824 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark03(107.48045239430297,0.7472489109850642 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark03(-107.49925164602223,-32.462935270219546 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark03(-10.78056597081468,-188.7105675321372 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark03(108.28338852582127,42.86493931893966 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark03(-10.884054540312668,1.5707963267948972 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark03(-10.922388489701348,-38.45428276474265 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark03(-110.36789050266667,1.5707963267948966 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark03(-110.82151666831103,0.04904457081911701 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark03(-1.110779096583455E-16,0.5707963145556826 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark03(1.1139077650531846,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark03(-1.1179937213724327,28.101169642045733 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark03(-111.99232406344984,1.7487936192062749E-15 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark03(-11.223090962943829,-62.50414738743903 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark03(1.1245871251429929,-2584.6463600703937 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark03(-112.90101629698911,69.68380704313424 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark03(113.09847196167071,58.11946790610845 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark03(11.38150456692928,-61.02974739206268 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark03(114.24744944689914,-12.987053023487487 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark03(114.26719188243732,0.5196808515765162 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark03(-1.162356195998759,-100.0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark03(-1.1625818424751662,135.63477031270818 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark03(1.1643085659620975,88.3810985344937 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark03(-1.1710174392823745,0.0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark03(-11.713839764207904,-77.4822992383261 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark03(-117.28356714853913,88.36610665122959 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark03(1.1791474952802954,1.5707963267948966 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark03(-1.1812824920854392,-1.5707963267948966 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark03(-1.1823942653435608,0.02287891167216311 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark03(-11.838465155255454,9.131304225936573E-6 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark03(-11.845146978051945,1.5707963267948966 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark03(-1.1867118698236048,38.76136535894327 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark03(-119.06372896370165,-1.4141417564937115E-15 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark03(-119.14959948991317,107.80498589818095 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark03(-119.37515563633012,23.561944900747793 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark03(-119.38512896931579,42.41151049510882 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark03(-11.953747484215626,42.8132969306989 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark03(-11.980718351766043,-1.5707963267948966 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark03(120.02792971016555,-2599.730137503005 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark03(-1.2003644976099945,1.5707963267948966 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark03(120.50341383665878,5.520997770882403 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark03(-120.70335508039207,135.33644618717608 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark03(-12.1151522344759,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark03(-122.51952194987093,29.845130209483745 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark03(-122.5946706478538,31.844734481923737 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark03(-1.2279079704130574E-35,32.986722862692716 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark03(-122.9376425351565,38.85437912471785 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark03(-123.0664947177283,-82.9134658361088 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark03(1.232595164407831E-32,-1.5707963267948966 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark03(-1.232595164407831E-32,1.5707963267948968 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark03(1.232595164407831E-32,64.40264939859662 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark03(-123.49436575400706,-1.5707963267948983 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark03(-1.2413840736306931,9.754190213933583 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark03(1.242783070728342,95.39768890591495 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark03(1.242894163509959,-1.5707963088386971 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark03(1.2431220049932858,-39.80104050905005 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark03(-1.255363332333205,-1.5707963267948948 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark03(-12.566361392501879,1.570796446004188 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark03(12.566370614369264,-1.570796326784754 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark03(-12.566370629317131,1.5707963267948966 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark03(12.56637063070827,-98.96016858782114 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark03(-12.566371568062985,7.853721322176785 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark03(-12.566379705346653,-0.34034876623715615 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark03(-12.568323739365368,-83.2524107309874 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark03(-12.568339887459752,-0.5601049444573484 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark03(-12.568347442484662,-1.5707963267948986 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark03(12.574183114359174,-54.97787143782086 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark03(-12.584170200357761,-10.557385692421931 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark03(12.626460120573244,-1.5707963267948983 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark03(12.639476665733241,-72.63000685204916 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark03(-12.647319843581386,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark03(126.49399534159869,53.46777282551756 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark03(-1.266454152763231,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark03(12.68987327530212,-0.6601370144565653 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark03(-12.691370623108012,-54.9163638264141 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark03(1.2692896874983497,-0.19186572375068717 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark03(126.96590127901449,49.996881266064555 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark03(127.13718132314413,-91.94630735611533 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark03(-1.2746451299984,1.5707963267948966 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark03(-1.2748801234347198,-2530.889571012733 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark03(12.74982554565495,-72.506395515596 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark03(-127.54216882635902,-45.365331584828084 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark03(12.783993956907779,-83.04711549668882 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark03(-12.825061198095682,0.0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark03(-1.2841472695931033,-58.56541716876651 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark03(-1.2847487773434807,34.13272499559673 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark03(12.849897807940577,1.5656854008772427E-4 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark03(-12.948546470085624,-1.5707963267948966 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark03(-1.2959887330088327,0.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark03(-129.7658216846118,75.2213577189457 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark03(13.057913505458608,1.570796326794897 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark03(-13.059828121545706,2.070796326794902 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark03(13.067862249878786,32.576545551480336 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark03(-1.3078167411582404,-50.01010782097384 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark03(1.3092008646811202,67.13892528572188 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark03(1.3108104959105666,36.12831585013627 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark03(13.127745773106042,20.175161085131368 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark03(1.3159771971618106,-1.5707963267948966 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark03(131.9479250376485,-14.486787962055146 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark03(1.3200961249277698,73.55498434864911 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark03(1.3243652256487124,-15.333257772990379 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark03(1.3256775917051797,26.16885177161125 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark03(-13.256783718526087,-44.72086664124116 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark03(13.27032664457226,140.05463245559534 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark03(-13.313870091816186,-164.85733177558086 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark03(133.35403280528033,89.81771644229758 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark03(133.4027026519922,14.429992192427811 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark03(-133.4674777632473,-0.06012515247030628 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark03(-1.335289022875087,3.8475743489551064 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark03(134.0257149668863,-1.570707079922798 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark03(13.415460787743399,-79.22707014049892 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark03(-1.3423588664954684,2.9131551932903648 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark03(-13.42799561205994,40.60277874346157 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark03(-1.3545583807168275,61.45688449675063 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark03(-13.548530948569763,-1.5707963267948966 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark03(1.3580945317389421,-3.4218144891529505 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark03(13.58642187433226,2590.7852805462135 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark03(13.597652537060563,-1.5707963267948983 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark03(-13.675736443033173,-38.96291988434841 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark03(-136.8433016345379,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark03(1.3698063792725208,-31.616916483420308 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark03(1.3783271060288556,1.5707963267948966 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark03(13.812045106661214,-1.5707963267948968 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark03(-138.2368723482215,88.81143299791671 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark03(-13.83456932682266,52.84210986707157 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark03(138.69410612286623,-5.212680811632294 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark03(-1.3877787807814457E-17,-26.70353755551314 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark03(13.878217849614103,-0.059069992241295104 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark03(13.884457258295331,31.66863621875667 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark03(13.888098068436335,-1.5707963267948912 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark03(13.91699869243703,-32.628250303267265 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark03(-13.920959482004298,0.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark03(-13.927858684141853,62.21424298570393 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark03(-1.3936217247282627,-8.056561506768588 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark03(139.63262375862124,16.220881730636652 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark03(-14.06231301540322,14.883011694538723 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark03(-1.4085004949468716,-45.12085994945322 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark03(140.88555952171015,1.0378447421117341E-10 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark03(-140.9289470779457,-2.5707963332608585 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark03(141.23697694830554,32.04859989279021 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark03(14.138441013635969,63.43100780948504 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark03(1.4139602394426243,0.0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark03(-141.71890182552482,15.586684361585192 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark03(1.4264662026191237,163.36914429314012 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark03(-1.4349296274686127E-42,-1.5707963267948966 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark03(-1.4381760222844815E-5,-158.65042900622225 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark03(-144.09357401497783,8.881784197001252E-16 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark03(1.4434005628963062,25.260136992616935 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark03(1.443778620243051,67.36958654036589 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark03(-14.472532739211147,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark03(-14.482513486793053,1.5707963267949054 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark03(1.4557788765032207E-6,-45.55310230110077 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark03(-14.581999656977885,36.90954637647715 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark03(-14.593047117447071,0.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark03(-14.60218814707494,2615.3194312057526 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark03(1.4620468928515766,-32.748914865450416 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark03(-14.634637026633342,-90.93435401594546 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark03(-146.52867705740582,-84.21396152219629 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark03(-1.465606292782042,1.5707963267948966 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark03(-147.1337332774222,-5.665818182949622E-15 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark03(147.30910494152343,-14.04408172746426 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark03(147.31622641029247,-24.36978042579159 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark03(-14.732969807387754,-3.6903740722375744 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark03(-14.820539321467493,-44.8193602223452 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark03(-14.832242148593775,39.632487771393556 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark03(-1.4834745154646567,107.75424195457457 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark03(-14.891509930589372,53.774542786253065 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark03(1.489534600963959,-0.08126167346553143 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark03(-1.4912553414977392,93.41624134477493 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark03(-149.16676221718708,-0.2413554261661922 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark03(14.919316655070475,-0.6294430784678866 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark03(-149.5206556145743,100.0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark03(1.504632769052528E-36,1.5707963267948977 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark03(-150.79644643626452,-4.743639980327836 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark03(150.86945850487618,-30.802280163544467 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark03(-151.20565187163024,16.12248731538645 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark03(1.5191939588483698,0.5358294299822092 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark03(-152.14290675967158,-65.74910878595226 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark03(-15.23547322819934,-1.5707963267948966 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark03(-15.290630483544174,-1.5378083080571054 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark03(-15.318966863629129,-90.42796844226908 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark03(1.5379445077270657,0.03285181906783087 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark03(-153.88413842451553,33.99140775302183 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark03(1.5389949728137275,-0.051135387912901814 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark03(-1.5394850214596079,-14.742568484502264 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark03(-15.396137027081423,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark03(1.5397893270204632,-45.87583006776534 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark03(-1.5521778342563057,0.5689359417796621 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark03(1.5523641757137656,-14.430385743496501 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark03(1.55412741770607,72.84625073970926 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark03(-1.5545112644675756,-6.843314153985067 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark03(1.5563618378248392,3.612332869469929 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark03(-1.5569477851369027,10.516116932273505 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark03(-1.5576043514472455,-5.107956042421816E-6 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark03(-1.5618434099852099,0.0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark03(1.5639320606385048,18.842691655382367 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark03(1.564605100490175,-6.123233995736766E-17 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark03(1.5646354361955594,-88.19668759000139 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark03(1.5651587042206931,1.5707963267948966 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark03(1.5694371584685936,100.0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707294038265944,83.51466271929621 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707911843998121,-9.424783103163856 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707961774413808,62.83861915857741 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267901097,28.27433388230487 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267923126,-78.53981633973771 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267924516,-43.982297150257814 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267932081,72.2566310325667 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267933225,-53.4070751110259 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267935423,-69.11503837897261 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326793656,-56.54866776462145 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267938776,53.40707511102933 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267940832,-9.424777960773795 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267943013,0.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267943406,-4.336809829134318E-19 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267944778,-15.90556183350111 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267946319,87.96459430051614 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark03(-1.570796326794668,1.9032601583967696E-15 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267947942,62.83185307179511 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark03(-15.707963267947962,1.5707963267959044 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948326,0.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948344,-38.08843372081694 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948,-53.40707511102982 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948752,-1.5707963267948966 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326794877,-34.14249219829021 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948877,136.6592804311717 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,10.946408742575551 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,1.5707963267948963 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948912,3.6129354829327127 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,-72.67561465494349 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326794893,100.0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948937,-67.54453171307046 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326794893,88.49197023796404 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,108.38494654884784 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-1.570796326794897 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-17.342286867736618 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-2566.9151018548596 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,-35.36056326576994 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,-36.26854836279221 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,44.224384542650725 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,44.86378976994166 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-65.75820421665257 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,-81.71613203642467 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,84.47983260324564 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,95.16958585378237 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948952,0.0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948952,-1.5707963267948934 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,14.561541619236309 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,1.5707963267948968 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,62.10259266498187 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,94.95361475986907 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,-1.5707963267948948 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948961,1.5707963267948968 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948961,2.52479891610578 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,-3.1415926535850485 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,4.4123391208261004E-4 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948961,52.04762712130555 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,-66.00293212884851 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,-67.2507282053008 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948961,99.00369926461227 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,-0.2228471092308305 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,0.32932583092249107 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,14.429276621726444 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,2366.635382684237 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,2449.4255448095487 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,-24.67460635229926 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,31.939335538865308 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,-91.37132166313897 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark03(-15.707963267948964,95.81857547431652 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.002578549221627763 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.02414854154158482 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.031046147217289093 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.07426606144609904 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.12059479798562428 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.21415621137089735 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.2715056933688539 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.35955385526683054 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.3683350722979647 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.37753545148320883 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.3999147592413772 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.5453401864510675 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.5483785290632258 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.5592762941439098 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.5642210066374301 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.5680219225297437 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.569270187969417 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.5703040833311374 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.570486749232385 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.5855423838724929 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.6001059603330727 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.6378045777143715 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.6922794456763146 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.9062076101908529 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-100.53096491478028 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-10.564219344589588 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-107.45122576499652 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-10.993478729636536 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,10.995574287220363 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-10.995574287564272 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,10.995574287564276 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.1288485729809876 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,11.810313251946635 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-11.922126356929592 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.1932802774916802 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-12.025486400592637 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,12.56637061435512 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,12.566370614360816 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-135.60375871432075 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-14.137166941153746 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-14.137166967063598 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-14.42920989473825 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,14.801162666923645 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-15.246549549224625 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.560845001065096 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948082 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.570796326794887 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.570796326794897 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267948972 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948972 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267949014 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267949125 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267950105 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.574702576794983 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-15.811529831790507 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.6032730698611942E-12 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,16.828529111762734 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,17.278759594743864 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-17.2787595969688 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-17.94437527100959 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.9747491733434155E-13 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-20.07600023117974 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,2.0125102124255925 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-20.42035224833365 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-21.069601179014157 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-21.504591648042446 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,21.733497923455886 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,23.040534859893835 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,23.569757402348184 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,23.805716401563416 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,24.35005363854306 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,2508.1575122099707 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-25.13274122871759 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,25.132741228718118 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-25.372177747902384 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-2562.78311387529 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,2571.39816692516 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,25.717584327292894 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,2574.042194368736 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-2615.5787155348767 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-2620.503935687816 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,2633.2063296264146 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-28.602206246221233 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,28.78213783195073 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,29.073578019124657 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-29.128992382628667 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,2.9540437709051717E-16 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,29.84513021005606 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,30.062980648847585 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-30.2853088517739 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-31.02197982556551 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-3.141592653589973 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,31.415926535959102 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,31.78274524932012 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,31.873459665504527 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-32.064081850033745 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-32.517103819954876 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-33.781844854012235 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,33.87725230680007 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,34.23574372958541 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-3.5747592139487765E-15 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,36.12831551632828 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,36.49870409766379 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,37.39684723834026 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,37.69911184308021 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,37.7612795736153 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,38.131327342772465 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,3.9347580463301368E-16 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-40.608544439104676 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-40.84070449666831 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,4.141592653589794 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-4.168286148554339 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,43.140553953230324 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-43.61831412854299 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-43.982297150259704 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,44.0549151642698 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-44.112292028042056 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,44.3278113404746 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,44.48642585029766 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-4.475069287303848 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,45.433121535962016 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-45.52157709638168 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-45.54986046674517 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,45.55309347705194 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-45.553093477051995 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,47.12388980384758 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-48.694686130641784 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-48.69859238064183 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,48.7259361306418 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-49.66037264043661 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-50.89779480269343 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-52.570720267365 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-52.60615296995865 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,53.8399875544177 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,53.865497305747155 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-54.26015298025861 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,54.743357502524944 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-54.843955014776924 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,54.87761078601788 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,54.935210474780774 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,54.97787143782137 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-55.30155239341806 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,55.43661253143188 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-56.02031494112727 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,56.414343129406866 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-56.54866776461141 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,5.759458153502795 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-5.801500907547477 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,58.895001983946 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-59.69026041820403 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,6.003569420229766 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-60.433344217444926 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,6.123377471966352E-17 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-61.26300987000099 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,62.311942584377654 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-62.449683210288384 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-6.35325512360654 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,6.744647945562576 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-67.54424205218048 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,67.54424205218054 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,67.54424205218076 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-67.54424229059914 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-69.11503837897779 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,6.954016902675898 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,69.79031131277715 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,70.68583470577033 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-70.69364720577036 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-71.57220985002664 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-7.165612634142869E-4 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-72.07647138448546 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,72.25663103256134 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,72.31973540773828 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-72.40093545639132 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,73.34847083348208 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,73.4912461267499 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,73.53015036535139 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,74.50135151204051 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,74.68123014802231 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-76.72203973632246 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,7.672391821440584E-8 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,76.96905061152673 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-77.16120669415272 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,77.83526491697339 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,7.783777413603684 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,7.806411471901865 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-78.36266552730828 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,80.11061266653971 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-8.077935669463161E-28 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-8.390713628791275 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-84.84120262687524 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,86.22785294263718 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-86.39379797371872 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-86.39575109871932 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-86.47828452219007 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,8.663650182537554 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,8.667810925447085 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,86.71361683392921 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,87.57103464163919 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-88.17338924014977 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-88.25858548649872 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-88.41600566953893 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-90.61802550702389 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,9.102593624649039 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,91.1061869541025 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-91.31500204112766 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-9.209647927419418 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,9.227234874501617 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,92.43651691123232 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-93.18968553412458 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,93.37540039470946 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-93.80053594817018 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-9.384860995827426E-16 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,94.07785180444833 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,94.24777960769033 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,95.12214751086701 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,95.39779062860401 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,95.81857593448868 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-97.38937225888036 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-97.39106988456226 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-97.80043589262763 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,99.43676745732388 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948968,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark03(-1.570796326794897,-39.12345199345217 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-14.431592267263397 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,1.570796326794897 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-2612.6645016024045 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-2616.772063463615 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-28.417239088618373 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-59.349672432999924 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-61.60498735329676 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,70.58320925046614 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-9.45843012941863 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,96.79128726932632 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,9.794361684711593 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267949003,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949019,-1.5707963267948963 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949054,0.0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267949054,0.0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949054,73.60079717583196 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949125,-84.91926204517814 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark03(-1.570796326795059,65.97344572538161 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark03(1.5707973314403387,-14.429209012990675 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark03(-15.720550318056752,83.6488729924466 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark03(-1.5722620240173986,-3.1401269563672143 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark03(-15.723588268920611,67.54424191395938 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark03(-15.734262293080377,-48.40564568834283 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark03(-1.5777218104420236E-30,-1.5707963267948597 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark03(1.5777218104420236E-30,1.5707963267948977 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark03(1.5794233496388426E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark03(-158.20966771830948,-0.12931480572544396 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark03(-158.4273180989914,28.051222975014987 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark03(-159.08150951672104,49.29558528242876 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark03(15.911096430577444,24.104029714055613 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark03(-15.976286160503037,0.13612619395134917 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark03(-160.21949860336727,0.0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark03(-161.0761279025881,-81.71263578811818 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark03(-16.123580057359824,-30.260746998513895 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark03(-161.25649944520035,0.0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark03(-1.6140005558447956,0.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark03(-16.143412105091514,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark03(-1.6155430611124137,3.18633938790731 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark03(-16.187406149116264,-2503.6028307174092 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark03(16.209890073202487,9.8889653438154 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark03(-1.631107158927049,14.429301296479423 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark03(-1.631607676875703,47.184701153927705 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark03(-16.330088874433415,96.04111700970924 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark03(-163.37844298666926,0.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark03(-16.343113127090703,0.0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark03(163.45249783657448,-80.21294694186432 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark03(-163.46726791293713,-72.428037701627 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark03(-163.4922380871156,-54.97787143817919 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark03(-1.6407411847479196E-17,-29.845130229149873 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark03(-16.425323484445016,-1.5707963267948968 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark03(-16.47471223655205,-1.5707963267948966 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark03(164.79085815908434,-18.158071581208848 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark03(-16.51052266343007,32.54373622297405 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark03(-16.551192597882938,30.262683790505175 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark03(-16.57749142573033,-1.5707963267948983 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark03(-16.606062665485396,0.014471756475903694 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark03(-16.62206526188261,18.342478205017983 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark03(-166.5043167255589,1.5707963267948968 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark03(-166.56856450929368,4.776544035239117 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark03(-16.66781022647534,0.0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark03(-16.726898995161545,17.06567260015472 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark03(-16.740617540799093,0.0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark03(-169.64600276724354,1.570796326794898 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark03(-16.986077693624992,-128.96683496533024 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark03(-17.02780244305041,-1.4921546575339864 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark03(-17.027909026879513,-1.5707963267948966 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark03(17.028782925635497,-67.16883522823642 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark03(-1.7060392380275106E-16,66.94438580102067 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark03(-172.78120474490518,1.570796326411246 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark03(-17.292818993665527,1.5707963267948966 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark03(-1.734723475976807E-18,1.5707963267948963 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark03(1.734723475976807E-18,-1.5707963267948977 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark03(-173.77573289928543,-95.3085431992407 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark03(-173.95709345165432,16.2145994756158 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark03(-17.485394157644322,89.57733646408778 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark03(-175.98209705918754,1.570796326794897 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark03(-17.65801970553913,-0.37926011079526617 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark03(-17.75160343216599,61.7668107685393 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark03(-1.7763568394002505E-15,18.49286238063682 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark03(-1.7763568394002505E-15,92.54956327108171 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark03(-18.138147409746622,47.480474249458666 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark03(-18.19573871202202,-0.5749982982807438 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark03(-18.207080087345425,1.5707963267948966 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark03(-183.92908662715345,44.32877837329764 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark03(-1.85451871531464,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark03(-18.651463219375202,-9.542155535509105 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark03(-18.83181799675387,73.34677296943943 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark03(-18.849555923401407,-1.5707963267948966 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark03(-188.4986485856652,7.853981633969421 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark03(-18.849921854911432,-0.030140966248939964 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark03(18.85053248405046,-1.5707963267948966 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark03(188.85032240367917,-89.95221559176318 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark03(18.91994894895295,93.97568304653379 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark03(-18.94376071362375,-6.429651143709056 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark03(-19.077577416481773,-74.95612344566894 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark03(-19.186986131902163,-8.191411850501375 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark03(19.22472077204664,1.5707963267948966 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark03(19.25151410948624,0.0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark03(19.286462490838467,2497.918286679366 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark03(19.439645279865346,13.568863405849598 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark03(-194.7787355803378,92.67697563668995 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark03(1.9479966064884735,90.91514336511901 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark03(-1.948504981460268E-11,-0.5365830903706846 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark03(-19.5080463212998,-38.59705846187806 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark03(19.52822824027149,-11.015467491260637 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark03(19.560802492286534,-43.23329172350324 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark03(-19.585319913492256,15.968743515177806 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark03(19.594858532785835,-0.4901341790917978 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark03(-19.603669712560865,0.0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark03(-19.627051534714838,-70.76625915981363 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark03(-19.650810233703172,-1.5707963267948966 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark03(19.66053747482002,-0.19724202680887265 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark03(19.719826737300906,-83.96571736456733 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark03(1.9721522630525295E-31,80.11061266653971 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark03(-19.72842211239289,0.0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark03(-19.744067443556304,94.62405099315922 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark03(-19.770014051414492,-2490.8990790718435 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark03(19.775840186859874,0.007206371007159323 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark03(19.84589316210881,-1.5707963267948966 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark03(19.866902736999094,-1.5707963267948966 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark03(19.867189858545316,48.94952255248438 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark03(20.001168834904725,0.0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark03(-20.017086691237736,0.0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark03(20.017718328761177,83.9038470419278 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark03(20.12006647256854,-17.56760053108544 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark03(20.146184343912978,-19.742099485387342 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark03(-20.213693425715956,1.5707963267948974 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark03(-20.29384925950622,-1.5707963267948966 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark03(20.322583765429485,-1.5707963267948966 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark03(20.33701100960539,0.5338376097657412 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark03(-20.40983946338226,-35.52018537793853 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark03(-20.45842862627641,5.798549115426891 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark03(-2.0458686097270657,83.24703514774907 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark03(20.48935446448506,3.099880262523553 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark03(20.502335516350314,0.0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark03(-20.518218745023162,-65.07415342958666 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark03(20.519133332371382,-4.2831054349868865 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark03(-20.5607061952484,4.440892098500626E-16 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark03(-20.60932394771882,72.30539326663083 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark03(-20.609515983099442,-1.5707963267948983 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark03(20.616521006261664,-1.5707963267948841 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark03(-20.627643185268767,0.0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark03(-20.66161210464406,-28.31605941584985 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark03(-20.70567930629585,-48.119891955272635 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark03(-20.708227193964987,0.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark03(20.735600748216882,73.82742735936014 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark03(20.73779336203509,-35.76577727985344 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark03(20.75738788593653,0.149079849043245 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark03(-20.83708696183146,76.15612211236395 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark03(20.85540469968032,-68.24812579810323 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark03(-20.869105099314957,-14.42944377038441 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark03(20.889782652493125,1.5707963267948983 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark03(-20.891615475604162,72.72789425983575 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark03(20.896977121334388,160.25782367548845 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark03(-20.921996794331008,1.5707963267948912 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark03(20.92626855559449,-16.54235561159119 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark03(-20.967027570619944,-82.15393210668907 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark03(-21.038989252020016,0.0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark03(-2.1149163607993415,-9.860089481276901 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark03(21.180904486219276,88.34258396705306 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark03(-2.1261062054633355E-9,199.49191374968711 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark03(-21.35093706849129,2496.7335903568587 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark03(-21.35580338327023,52.47162397608991 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark03(-21.36992439625169,14.18407400060093 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark03(2.1382117680737565E-50,67.54424205218001 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark03(21.39629633432712,-75.78523018519441 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark03(-21.41672639261094,0.0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark03(-21.443336389734412,-16.42803451871705 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark03(-21.492600488953308,1.5707963267948966 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark03(21.495470209440377,2635.5081750081695 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark03(-21.50818721976179,2.070796326794899 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark03(21.50989135720622,-0.0034424709045288104 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark03(21.522255758352557,-78.8508608979997 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark03(21.581904043914584,-1.5707963267948948 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark03(21.61343853096497,-71.74801048763196 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark03(21.61592947549977,42.134008635612616 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark03(21.62311690071867,-20.06621138387245 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark03(21.62447920801934,-157.14917102581003 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark03(21.65809021748926,164.68767937138688 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark03(-21.684978323187345,-46.41222999913364 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark03(-21.70475408606691,44.15298017762917 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark03(21.71484240267685,2592.2602279839352 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark03(21.717724896031157,72.43494953162063 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark03(-21.718046103859535,-81.65142639714745 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark03(21.724385124294642,46.68497882282699 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark03(21.73708302756463,106.52221437172383 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark03(21.73972335285626,-0.04444812019834738 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark03(-21.742957983183718,-40.27436678237572 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark03(-21.744585702227468,-1.5707963267948974 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark03(21.780557266543173,-159.14607992423925 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark03(-21.789379763377532,-1873.50719222061 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark03(-21.818779845921128,97.87596654291815 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark03(21.867860159953302,55.10115985299663 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark03(21.87049441085188,-0.18378506038251363 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark03(21.881602913658085,-0.15030612354689055 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark03(21.903838054203046,1.5707963267948966 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark03(-21.929648884653474,-48.30056436055796 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark03(21.949846128462426,0.03222260553409357 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark03(21.96843235748962,4.743638998298417 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark03(21.987755880004578,4.715781675508666 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark03(-21.9909112703019,-36.128315754701326 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark03(21.991148575054737,-67.5442420480026 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark03(-21.99114857512855,1.5707963267948966 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark03(21.99114857512855,-1.5707963267948968 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark03(21.99114857512855,1.5707963267948977 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark03(-22.08740532810936,-45.456836724071195 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark03(-22.18440377606807,-1.5707963267948966 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark03(-22.19495411390247,-135.18407121202938 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark03(2.220446049250313E-16,-0.08554556188775264 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark03(2.220446049250313E-16,-0.820716456421666 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark03(-2.220446049250313E-16,1.5707963267944318 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark03(-2.220446049250313E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark03(2.220446049250313E-16,31.372718038614423 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark03(-2.220446049250313E-16,-44.57144791640421 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark03(2.220446049250313E-16,-4.768977516234636 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark03(2.220446049250313E-16,55.26398022127584 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark03(-22.247579662493266,69.14974553221006 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark03(-22.249656054383564,-164.32937732519568 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark03(-22.254503473315737,-2603.1928003595376 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark03(-22.267132025512105,6.6247094726639375 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark03(-22.367757532057013,-1.5707963267948966 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark03(-2.2386610422424815,2.473727938142208 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark03(-22.498128807429424,-78.11325117457139 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark03(-22.518214193594126,24.089010520389024 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark03(226.21029608589802,23.561944890160763 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark03(-22.644720219675435,61.79063173479963 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark03(-22.788537662384783,51.848838061579094 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark03(-22.85430219696717,-31.1190895927013 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark03(22.885800637918493,25.108269930116705 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark03(-22.94365180234945,-39.115259597857815 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark03(-23.187259123539178,-1.5707963267945182 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark03(-23.27597442120846,57.92875697498931 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark03(-23.45668068929794,56.05444869662094 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark03(-23.577187729874495,2635.6722935751545 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark03(-23.678345112305863,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark03(-238.76246068301498,-1.5707963267948963 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark03(-23.89723888918094,26.8247649585508 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark03(-24.148757881297406,18.262742942164802 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark03(-24.212996334598735,0.0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark03(-24.5503185574629,75.37086269307679 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark03(-24.629617177764942,99.46329263903189 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark03(-24.644897065508033,2592.986051383043 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark03(2.465190328815662E-32,-1.5707963267950105 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark03(2.465190328815662E-32,36.12831551628261 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark03(2.465190328815662E-32,-67.54424205218054 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark03(-24.653662673711565,-1.5707963267948966 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark03(-24.811782545782705,6.464152010100648 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark03(-24.982463030451484,1.5707963267948983 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark03(-25.025503756571467,-65.60541513428751 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark03(-25.06186569517538,52.23177294711692 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark03(-25.132740446910912,-67.54424195087051 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark03(-25.132741029027788,61.26105674500028 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark03(25.132741229099338,-1.5707963267948983 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark03(-25.13274124409203,-17.279433646134105 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark03(25.194144963423604,0.0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark03(-25.20726268668788,-1.5707963267948968 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark03(-25.214519939519136,-32.06357864554874 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark03(25.21714084426705,47.068210443846084 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark03(-25.250927802668983,0.0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark03(-25.260735788221478,48.56669157113866 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark03(-25.28369041253461,-2.7071389066926344 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark03(-25.40788559582176,-97.28397305108159 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark03(-25.41270365549127,-45.14656378960305 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark03(25.44695406448237,45.512603370890474 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark03(-25.463720922237172,0.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark03(25.486002563043282,93.03024461522384 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark03(-25.537087639049613,67.23157730896004 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark03(-25.55920432308516,-77.48166273773154 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark03(-25.57085959340254,39.617228148990364 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark03(-25.63523241779095,1.5707963267948957 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark03(-25.659195301382766,84.89775661213969 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark03(25.660785726852215,1.5707963267948968 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark03(2.566857279061935,10.75686179613254 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark03(-25.70566176663982,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark03(-25.851883950134024,-78.51974960241708 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark03(-25.876746854399315,-71.67045436828283 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark03(25.89609433774122,-7.7722556267942196 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark03(-25.911220671950517,90.2967810584136 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark03(-2.595614936176727,1.5707963267948966 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark03(-25.976257536472787,168.0754288595746 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark03(26.068521139329963,-37.85865853774619 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark03(-26.07398752068852,-135.16646068317092 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark03(-26.093213924002185,0.0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark03(-26.106207856555486,-1.5707963267948966 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark03(26.117622970683314,0.07128786645458263 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark03(-26.131129364611354,-90.8189523338732 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark03(26.132741220369066,-44.55309346795083 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark03(26.14509146555079,-70.74831370108805 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark03(26.155636857278182,-1.5707963267948983 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark03(-26.162007591370795,90.3584444561737 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark03(26.167112194739815,44.994687779001026 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark03(-26.18823034300803,85.90141805061432 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark03(-2635.137591810379,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark03(-26.42390252403061,-1.5707963267948968 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark03(26.501248992829957,-1.5707963267948966 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark03(26.62359392922744,-2557.59483655364 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark03(-26.671507868811503,1.5707963267948961 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark03(26.703537555512955,2.3595060936748654E-12 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark03(26.703537555518622,0.0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark03(-26.70508051652364,-1.5707963267948966 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark03(26.70914066792339,-0.005603178199688903 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark03(-26.71037925977636,-0.06234287629640851 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark03(-26.757983966028558,0.0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark03(26.758710310146338,-50.32065521206979 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark03(-26.824204316967187,73.70922929016675 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark03(-26.851902883343662,-103.8209228962936 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark03(-26.878812032552474,-1.5707963267948968 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark03(26.91363645710973,0.21009890159648872 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark03(27.042439757874092,-6.283185307179582 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark03(-27.081948203309693,1.5707963267948966 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark03(27.08518001124294,0.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark03(-27.11846160731806,44.09190158073095 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark03(27.12658473427056,49.8597765323874 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark03(-27.13406298464192,-82.35194319454322 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark03(-27.14454479884487,82.40881556942836 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark03(-27.179290891459345,-47.90223909537464 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark03(27.180531568908663,-5.078310474364557 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark03(27.186722227715602,0.0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark03(-27.19206415447762,92.74558143549972 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark03(-27.226576972842263,59.1004417996555 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark03(2723.001909910295,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark03(-2723.7080512782854,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark03(-27.251815239634155,82.80683758375355 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark03(2726.112989949409,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark03(-27.264381485026792,-9.98562189028293 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark03(-27.273222043722043,1.5707963267948521 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark03(2.7369110631344083E-48,-42.4115008234622 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark03(-27.577001147185936,-52.94847308336539 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark03(-2.759725722125637,-9.58561936116979 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark03(27.749032188538276,-44.11619154647931 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark03(-2.7755575615628914E-17,80.11085680716474 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark03(27.76541463364798,1.5707963267948972 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark03(-27.86375990428498,-49.817964368449914 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark03(27.874409336004124,-164.5336897671207 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark03(-27.876386541165303,-0.21077549212401436 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark03(27.89926116374775,0.019317752585719435 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark03(-27.941226362025148,12.104636901449744 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark03(-27.96628882587912,-98.29478495697472 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark03(27.97308681939198,53.76024926818117 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark03(-27.97358629044564,42.963668181895486 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark03(-27.97454237268448,-1.5707963267948966 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark03(-27.982470304455575,-27.724291810598302 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark03(28.002010313304112,55.807224313593565 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark03(-28.009292065324487,1.5707963267948966 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark03(28.015969027072195,0.0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark03(-28.019721964357,40.677673822005346 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark03(-28.058408435832135,-3.5826111870969255 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark03(-28.128957842661272,-83.93163806445435 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark03(-28.13002506322822,1.5707963267948983 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark03(-28.146169332528753,-58.21578655411832 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark03(28.153334349839838,44.40148027600236 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark03(28.159759565320456,-89.07732240159964 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark03(28.17070000436511,-55.08150531576441 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark03(-28.17223786082633,66.16583732658657 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark03(-28.177395383138652,71.00760053042441 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark03(-28.19594329319368,0.1599229950686039 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark03(-28.19874671513361,10.857281755853169 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark03(-28.19951718795099,-1.5707963267948966 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark03(-28.21504449816156,-73.76813797521356 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark03(28.217596157485744,36.18505324110502 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark03(-28.27064087261771,-2.0708097912399586 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark03(-28.274213223214627,1.5707963252524548 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark03(-28.274302748930097,73.84305235940285 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark03(-28.274312950866342,7.853876595129716 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark03(28.274333461039443,73.82742730180992 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark03(28.27433385205913,-67.54424196144791 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333870769166,114.6680905126849 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333879906443,0.0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333881829907,-45.55309347704503 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark03(-28.27433388209426,17.279248114993603 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333882164093,164.9336028213147 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark03(28.274333882298635,-54.977792097378305 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333882298684,-1.5707963268043525 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark03(-28.27433388230764,-1.5707963267948912 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark03(28.274333882308092,10.9935242845853 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333882308134,-1.5707963267948966 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark03(-28.27433388230837,1.5707963267948966 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333882322697,29.845119129356405 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark03(-28.274334351035147,-61.26103389878498 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark03(-28.274364401106084,-1.5707963267948972 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark03(-28.2743949174644,-10.99557413510982 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark03(2.828851253108403E-17,-98.96016855504647 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark03(-28.415126979732648,-54.174884193843454 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark03(-28.42788437055254,38.82119482510742 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark03(28.55362755385292,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark03(-28.64489395430914,-62.798481611653 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark03(-28.75670052457069,-31.327044199822126 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark03(-28.763202423382882,32.497854321618085 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark03(-28.76654492903998,-2608.7251466452904 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark03(28.77111088135439,25.237060426152723 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark03(-28.79419302169042,15.235363471963161 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark03(-28.833418308846845,-24.832313913618975 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark03(2.8849451806883764,39.50988631333584 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark03(-28.972857728438175,-5.410912826514726 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark03(-29.05685615563418,0.0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark03(2.917927180017363E-17,-67.54424205218054 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark03(-29.187644269628052,-91.26505003474203 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark03(-29.368840187468237,100.0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark03(-29.580969385323122,86.73545419988639 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark03(-29.63254538231208,34.53754844279444 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark03(-29.71681884723416,0.03367766296305774 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark03(-29.84513020910301,1.4720447109887775E-12 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark03(-29.84513020914743,3.582829050462331E-11 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark03(-3.00893050133954,1.5707963267948966 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark03(-30.15393978849316,44.68704001984281 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark03(-30.295700829651288,-42.82289528942438 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark03(-30.379503129995655,150.38391980913053 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark03(-30.77008724638648,-5.6485077710401725 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark03(3.083063127072478,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark03(-31.269861145271776,-59.96006958637572 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark03(-31.34773101966897,-2626.865560302609 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark03(-3.1379886646546504,-0.5700747558760085 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark03(-31.41590722546932,-64.40313767984081 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark03(-3.1415926535897865,39.2699081629277 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark03(-3.1415926535897922,0.0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark03(-3.1415926535897927,-45.552990003218625 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark03(-31.41592653594031,1.5707963267948966 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark03(-31.415926544206137,-98.96407489709007 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark03(-3.141592657235592,-67.5442419852028 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark03(-3.1416231711682054,-1.5707963267948966 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark03(-3.1420809348397936,1.5707963267948968 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark03(3.1420809348397936,1.5707963267948983 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark03(-31.447176535897935,-1.5707963267948963 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark03(-31.447176535897935,-1.5707963267948966 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark03(-31.453685233377964,55.055314174698196 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark03(-31.480829955132084,-14.429555531821862 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark03(31.518174408471307,-26.601289682939868 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark03(3.1601433462550808,-161.7734709684148 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark03(-31.63686001836095,2565.895639439175 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark03(-31.671421570599765,0.0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark03(31.677920016972365,-81.13598875139752 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark03(3.1783592774664227,-10.958807663687647 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark03(31.83822333107824,-91.72537121352664 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark03(-31.848203409017167,-36.456241876884235 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark03(-31.92592850235647,-2612.298642411788 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark03(-3.1938722729093314,29.873335510079812 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark03(-32.03704210060047,0.0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark03(-32.075102218850084,-21.110753153490975 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark03(-32.082952891047185,0.0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark03(32.13223985347934,-149.9419643630966 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark03(-32.21883119321913,-31.196775619606882 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark03(32.40620712357196,14.42986338466909 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark03(32.45575794781944,-100.0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark03(32.45872896595819,0.0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark03(32.50825403047016,-1.5707963267948966 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark03(-32.52359814869715,1.5707963267948966 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark03(-32.53317460427393,-83.5105291223245 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark03(-32.548318376417456,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark03(-32.591790017927295,-40.496164093456116 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark03(-3.266592653591175,-1.5707963267949454 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark03(32.69011852739761,-44.99781252770492 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark03(-32.70446545366739,-2568.9813583552345 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark03(-32.73255884236714,-0.863331748839471 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark03(32.78468706212854,41.36692921458692 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark03(-32.787679184088375,-88.19453819185011 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark03(3.2788888071702433,29.845128268322384 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark03(32.80677778335007,5.750160833994329 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark03(-32.808241195721706,0.30253505320227086 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark03(32.826507637968774,-84.01936966699716 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark03(-32.86132077485367,-0.42371630572403085 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark03(-32.91931868973275,22.197567866623643 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark03(32.92281276808342,0.0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark03(32.93064122732619,32.14468985297122 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark03(32.94407740788031,48.611706810146664 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark03(32.97425567637705,68.66480147101231 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark03(32.98672286269087,0.0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark03(-3.3079580680874025E-24,42.41176530618665 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark03(33.24437227985479,-52.60736734900669 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark03(-33.275387699871246,64.13056594837423 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark03(-33.27680387450829,-64.05459756775551 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark03(-33.36217856065342,-87.83373532674148 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark03(-33.71313650728894,46.06553712122178 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark03(-34.074686366204304,37.485528642416654 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark03(3.425610149841219E-14,-1.5707963267948624 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark03(-34.2963117721843,1.5707963267948966 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark03(-3.439500923645934,5.212388980384936 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark03(-34.508765244207204,1.6332963267949077 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark03(3.4515799268692113,-67.23425477890117 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark03(-34.55751650314748,-1.570795576512695 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark03(-34.55751918896242,-26.703537067688536 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark03(-34.557519189255565,-14.137166906482516 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark03(34.59093406825946,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark03(-34.65481534310134,-95.72127978087508 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark03(-34.669308569541954,-44.47810447350442 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark03(-3.469446951953614E-18,32.986722862692275 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark03(3.469446951953614E-18,73.8274273593601 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark03(-34.73370664179045,39.820567030955395 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark03(-34.73628306176306,177.1431200398614 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark03(-34.768006288054565,31.888928734429896 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark03(-34.76859972963968,-44.562997785301846 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark03(-34.7956513652382,1.570796326794897 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark03(-34.80168714244971,24.238762831722212 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark03(3.483111302237188,121.29283581185392 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark03(-34.837422808963325,17.665848079351687 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark03(-34.85786516837857,-0.10038538820600271 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark03(-35.04599482449892,-51.43986401608329 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark03(-35.187879709926136,105.0183734740369 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark03(-35.233324513940275,12.392526505453617 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark03(-35.25928260302328,6.271111959163872E-17 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark03(-3.552713678800501E-15,77.32811498670026 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark03(-35.66602099856132,-4.712388993177072 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark03(-35.67247058606431,1.5707963267948966 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark03(-35.70505073025807,-0.05176567733229936 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark03(-35.712410703513015,26.857272090089126 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark03(-35.76602459325086,21.538383887547937 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark03(-35.77989419175111,-1.220411530741572 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark03(-35.854378523186824,0.555750479518777 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark03(-35.923147813149086,0.5684051778827272 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark03(-35.9475732428111,0.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark03(-36.050086760452785,-0.00933624999540335 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark03(-36.06661141547618,-19.966554809916925 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark03(-36.12831551627993,0.0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark03(-36.20117618943133,-24.792774973309236 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark03(-36.25340506303525,-18.72446637478613 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark03(-36.36155686326836,60.931539933014086 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark03(-36.396883435726934,46.3955912751346 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark03(-36.41629468109884,0.0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark03(3.6498676446431007,4.204113989331383 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark03(-36.778454926681235,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark03(-36.98665516972765,0.8583396534450255 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark03(-37.35303646409234,-6.510197303497776 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark03(-3.7387709557264976,0.0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark03(-37.408776637027316,67.04012325233117 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark03(-37.592465963244926,5.438801315826934 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark03(-37.608113666533406,-1.5000355477055507 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark03(-37.699111659102115,-1.5710404674198968 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark03(-37.69911442404516,58.11946400028225 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark03(-37.703437694440304,0.42646041713129457 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark03(-37.72304602910419,89.29194949452251 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark03(-37.77215841284526,26.77658412528098 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark03(-3.7803910642760314,0.0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark03(-3.783039508175861,-67.91043824277212 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark03(-37.83203687476263,37.02673359103298 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark03(37.86344314173131,-57.30676566231423 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark03(-37.87134777304165,-4.302457403109226 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark03(-37.96851526296214,14.056268129432794 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark03(37.99837910086421,31.54112653017748 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark03(-38.0177075511137,-46.24560857957766 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark03(-38.02662125786406,0.18372174521487328 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark03(-38.0309295692546,-136.38700839723404 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark03(-3.8040477318039336,89.58462881696929 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark03(38.05482987554195,6.432277953386401 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark03(38.07477427815614,-2593.839566808152 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark03(38.15889482474102,-21.87458743558915 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark03(-3.821905854084002E-21,-26.703537555458897 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark03(38.3767135877076,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark03(38.37819981862323,-15.76879569684965 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark03(38.40722963053142,1.570796326794897 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark03(-38.450766971443585,44.18715399557357 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark03(-3.8480581191583383,-12.770224361130602 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark03(38.49329663484224,-46.06738523806639 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark03(-38.51482315100813,1.5707963267948966 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark03(38.52100690125679,89.49805856133847 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark03(38.555874681873746,53.762301611933644 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark03(38.565564692724244,0.0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark03(-38.60096543968798,-56.17625969825994 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark03(38.60709482355159,42.97474519253666 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark03(38.662889095005305,-62.508948331211414 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark03(38.67094284680463,-93.41108390423932 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark03(-38.713900043773066,-193.52837629798404 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark03(-38.759082755770606,76.83885562888054 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark03(38.76917829588439,-19.385125967421146 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark03(38.77667077402273,-19.398224480004416 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark03(-38.81898856795674,0.04190284166615894 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark03(38.82401144085734,-43.03563582295257 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark03(-38.82989594595514,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark03(-38.831603192663856,1.5707963267948966 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark03(-3.8861538244983933,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark03(38.8624306253445,0.5461420394889883 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark03(38.919302044719274,-31.57508685212153 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark03(38.93695715079236,75.39056864333963 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark03(-38.938541849800444,0.0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark03(38.9412788608342,16.225378800052084 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark03(-38.95251013147997,-1.4802605953572932 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark03(-38.97347181072408,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark03(38.987001107818195,-46.15272537733712 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark03(-39.026541393028005,1.570796326794897 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark03(-39.030651399180684,-0.5916328573494176 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark03(-3.9108580067373673,-67.4621256596103 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark03(39.12048519847134,18.94716154721709 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark03(39.13544407501058,-1.1940456342119634 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark03(39.19921425988113,-0.49917059772017736 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark03(39.205651282600826,0.0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark03(39.256760414878514,1.5707963267948968 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark03(-3.9338690994212104,1.5707963267948966 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark03(-39.43756555467757,-87.94731242195029 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark03(3.943767041050271E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark03(-39.444515410366954,76.70816430796339 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark03(-39.504623148572726,1.570796326794897 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark03(-39.521954578643935,35.133218207278276 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark03(-3.985871319922563E-34,-45.55309347694056 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark03(-39.87884268866325,-44.44855879034304 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark03(-39.8942533808597,-89.99553436882859 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark03(-39.9680802024077,-71.39122021507016 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark03(-4.006467511360305,0.0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark03(-40.32841960116145,-1.1057733221281154 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark03(-40.35899193585558,1.5707963267948966 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark03(-40.61101280497308,88.33491405116936 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark03(-40.73783609181045,89.61430917299782 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark03(-40.8407044947339,-1.5707963267948966 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark03(-40.84070449528896,7.853981570839774 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark03(-40.84070449666729,73.82742735936014 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark03(-40.8686215672557,73.84004753348532 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark03(-40.86914101782834,1.5707963267948966 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark03(-40.930135989535685,-74.40720271019225 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark03(-40.952364287402276,-49.62285462267184 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark03(-41.07662215005341,-31.27827772352538 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark03(-4.10899811228954,-92.95825602119463 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark03(-41.14448112521292,-42.79693192265044 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark03(-4.130064000763639,-14.918998066448921 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark03(-4.131235213299476,79.71721875901008 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark03(-4.141590809045549,-0.5707954713069557 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark03(4.141592653589795,2.5707891663558393 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark03(4.141592653590823,10.499192698771509 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark03(4.141592667647405,-16.63990166740332 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark03(4.141592922807505,168.0717461411096 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark03(-41.45691441542006,-1.1316526047111852 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark03(-41.47563724867633,-3.2600927694348765 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark03(-41.480144682880805,-69.85714682792423 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark03(-41.541600474888305,80.71246630907342 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark03(-41.846822340655486,-68.98897942420703 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark03(-41.930318638933926,89.2881881030427 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark03(-42.06294322931123,22.244398017679586 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark03(-42.16443313004842,-14.435048841674444 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark03(-42.32278208362396,-18.640115945373424 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark03(-42.34706619987103,-1.5707963267948966 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark03(-42.353006122797645,2597.913856587617 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark03(-42.36571460865464,-1.1599695596664306 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark03(-42.41150082294298,5.233335203992088E-10 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark03(-42.489801957485646,-45.26553720509786 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark03(-42.561006995356585,52.684701293047794 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark03(-42.5627867820594,0.0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark03(-42.57342165733593,42.10260013448888 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark03(-42.60214009005221,71.07974487883541 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark03(42.63426244330583,76.65838881612086 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark03(-42.6782916645867,50.88140153182714 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark03(-4.2691732677934086E-19,-1.5707963267948968 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark03(42.69456544002418,-35.270614036784394 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark03(-42.73276347772431,8.06673004098511E-18 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark03(-42.75966753142989,1.570796326794897 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark03(-42.780391653414206,-0.37863982209238223 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark03(-42.81116445117593,43.98905916997004 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark03(-42.83152444695306,0.0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark03(-42.85678093455537,4.277606218729524 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark03(-42.86733683598132,1.5707963267949054 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark03(-42.87053158297475,0.05922220100949877 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark03(-42.8734944876357,1.5707963267989684 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark03(-42.87997143194719,0.7005858202436589 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark03(-43.155135979497686,-1.5707963267948966 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark03(-43.16281053784884,13.317680328745805 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark03(-4.320265224898719,0.0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark03(-4.3368086899420177E-19,0.0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark03(-43.722252890794834,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark03(-43.75253537214352,-1.5707963267948912 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark03(-43.85696140764146,92.83444968797187 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark03(43.98229715025714,1.5707963267948966 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark03(43.982297150722786,-1.5707963267948966 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark03(43.982297152165586,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark03(-43.98262222690719,67.545220718264 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark03(-43.9862057662978,-1.570796326779225 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark03(44.10089564045087,-86.51239646391308 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark03(-44.11460225209327,-95.6441663879862 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark03(44.14476159367794,54.930105278778 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark03(44.15798891123026,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark03(44.28247213213288,-22.757541655928975 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark03(-44.30476767889833,0.0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark03(-4.440892098500626E-16,35.281896292111064 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark03(-44.4410999897286,-1.5707963267948966 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark03(44.44490309640316,-2553.5727887805574 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark03(-44.45720752432729,-0.5668819075823196 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark03(-44.47388733154424,-1.5707963267948966 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark03(44.48010247537876,-16.81387763187378 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark03(-44.48746125627516,-95.94579633697956 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark03(44.492165304491635,-61.06210631891389 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark03(-44.5157627595123,-61.81402224520986 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark03(44.557574207561416,44.97781641974769 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark03(-44.68894035065265,-17.807205424181305 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark03(-44.75950444423569,58.51480249912518 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark03(-44.79859382435241,85.57780803200765 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark03(44.83534795387233,-36.981366319897845 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark03(4.4841550858394146E-44,-1.5707963267958063 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark03(-4.486304450425155,-4.712388980784511 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark03(-44.88877915921255,-94.60094254996643 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark03(44.89855265323877,-0.18216084091580917 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark03(44.90235395649311,-106.90848840285207 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark03(-4.499655903171089,45.38198438705349 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark03(-45.00750854736866,0.2221680855687609 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark03(45.014435181919325,5.744527012046909 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark03(-45.035471566800716,0.49999676309070323 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark03(-45.070606866290305,91.10096622659489 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark03(45.09963836715626,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark03(-45.111471917743685,2.052492877956169 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark03(-45.229931501622985,129.12846077261054 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark03(-45.24237323388372,4.675380749820437E-9 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark03(45.243615957988254,-39.65080706517197 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark03(-45.29256576462355,-51.19963377131509 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark03(45.3945573469052,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark03(-45.40582733192273,-15.914233247664384 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark03(45.42992480796581,1.5707963267948966 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark03(45.43378498175014,58.80781151430622 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark03(-45.45131240608802,47.92230213518029 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark03(45.498889237671335,5.357510429760854 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark03(-4.5596228791293326E-5,-0.557764864979201 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark03(-45.952811588050736,0.0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark03(-46.024267090971605,-72.62473372876511 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark03(-46.131092443311815,-59.194937662684445 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark03(-46.204861363505636,94.10762636867614 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark03(-46.27488281104222,1.8579632213445763 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark03(-46.50728274113618,0.0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark03(-4.668919935720714,0.0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark03(-46.714235701253365,-1.5707963267948966 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark03(-46.836653661096705,27.31659108144506 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark03(-46.950969139065315,-91.72382930510854 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark03(-4.700555844429317,37.75739687396783 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark03(-47.043057959037824,44.344627664145094 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark03(-47.04541447616022,186.44019857179606 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark03(-47.061443657551685,1.5707963267948966 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark03(-47.123950839230666,-61.261049365453935 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark03(-47.13646352267411,6.450616080400231 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark03(-47.14879289274176,-79.84325596103577 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark03(-47.24514089692148,-86.4831896410436 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark03(-47.2809964514052,-80.6893286769087 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark03(-47.372356983444135,27.96716255536839 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark03(-47.41700107315841,0.9674150528599722 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark03(-47.428269153875924,0.0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark03(-47.520847420441164,-1.5707963267948968 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark03(-47.53527237716839,-1.5707963267948966 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark03(-47.62950052339682,71.06341209181917 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark03(-47.75059599387546,-28.35256666949546 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark03(-4.788331332083857,-74.90908072678909 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark03(-47.90819152479524,1.5707963267948966 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark03(-47.92457547820255,-2630.654314347929 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark03(47.95866978639597,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark03(-48.01311497384029,7.829568891907509 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark03(-48.013590829015506,54.38281139897171 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark03(-48.083270467129324,0.6114156635124709 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark03(-48.08948302686806,0.605203103773736 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark03(-48.176771942589625,98.16778793066945 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark03(-48.19801494692859,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark03(-48.32521502065358,-45.44075695055379 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark03(-48.341564391921324,-0.35312173872047126 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark03(-48.773327884461864,1.437516258449059 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark03(-48.78234999422997,0.0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark03(-49.051226287696934,0.5707652331599112 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark03(-49.29462584240194,-47.8068362365843 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark03(-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark03(4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark03(-4.947414116255192,-87.47327069999216 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark03(-49.50922437169773,44.626220244196446 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark03(-49.518414004422695,-2635.893087441744 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark03(-49.734612000059236,33.10331376773641 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark03(-49.74933669223283,1.3064034481666484 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark03(-49.756140481910435,0.0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark03(-49.85465818260057,25.60958028529639 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark03(-49.88135271219134,2296.741510568585 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark03(-4.990556716457121,49.438771356614566 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark03(-49.973357325748815,1.5707963267948966 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark03(-50.04968451947094,29.27418463507007 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark03(-5.0055629382955165E-11,-4.609710947931899 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark03(-50.061556516543874,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark03(-50.11921753053763,-92.62133352169566 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark03(-50.1985325025442,85.07478084765708 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark03(-50.21977057854941,45.12672461760485 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark03(-50.24407277547051,-4.733798662617211 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark03(-50.265469134819035,73.82742721856837 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark03(-50.2654824167149,10.995574287564084 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark03(-50.26548244510947,80.11061264272824 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark03(-50.26548245743668,1.5707963267948966 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark03(-50.265482457440335,-1.5707963267948966 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark03(-50.26548251705223,-1.5707963267948948 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark03(50.26553780985079,-1.5707963330308914 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark03(-50.26560453738943,45.553093448661734 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark03(-50.2664592170059,1.570796319310864 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark03(-50.28591340024848,-68.68741671314432 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark03(-50.32795744807572,1.6332963267948977 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark03(-5.0487097934144756E-29,36.13026864128269 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark03(-50.51537021781116,18.629153345315615 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark03(50.55516339018152,-34.96563764312832 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark03(50.571025206162695,31.77372278530064 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark03(50.581526161154386,54.10450935961123 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark03(-50.59716688042902,68.45021746732749 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark03(50.71841435559674,1.5707963267948966 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark03(50.72477861233557,-1.5707963267948966 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark03(50.7703802222641,-108.28508361683632 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark03(50.79921903662487,-20.278100103846228 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark03(-50.83410775705957,-80.17645907470025 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark03(-50.91239000633815,-58.766371640312634 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark03(50.975868592014514,-0.08365432820526308 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark03(50.99805373342804,47.590370646509626 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark03(51.018859255150886,-0.36554586932412875 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark03(-51.065605404997214,110.73768518739467 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark03(-51.08381873681439,3.6271655416969453 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark03(-51.11264298251093,-1.5707963267949054 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark03(51.11347632419079,46.773520324251336 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark03(51.13334632871465,53.11738874134301 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark03(51.233124865404136,82.130524104063 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark03(51.31022353619747,0.8809197296600706 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark03(51.346164814957575,-0.4901139692740132 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark03(51.38797027207656,53.27667432823773 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark03(5.141592653589794,1.5707963267948966 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark03(51.43280283782937,-17.380747112142203 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark03(51.47460250347686,7.029783729891491 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark03(51.50333112685229,-1.5707963267948968 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark03(-51.75037074631015,1.5707963267948968 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark03(-51.77401719138349,10.960883331036444 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark03(-51.77785439857883,1.5707963267948983 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark03(-51.786195921303616,99.69123548359187 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark03(-5.188096160472011,-45.49124303984152 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark03(-51.981141017884646,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark03(-52.48609046662543,-26.465276619178212 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark03(-52.48810635353847,81.25944721803418 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark03(-52.49118595029121,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark03(-52.58205525999644,-89.78370479256084 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark03(-53.025890202807915,-1.5707963267948966 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark03(-53.08198590687725,73.6720594127896 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark03(-53.263333937502,-46.286661807286734 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark03(-53.40707506824314,-45.5530934769438 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark03(-53.40707511102868,-1.5707963267926925 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark03(-53.4070751110294,42.41150081554826 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark03(-53.407075587863645,1.5707963267948977 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark03(-53.53245483760824,67.56293193725148 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark03(-53.60128350389339,-73.82965891856604 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark03(-53.620334502232254,0.0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark03(-5.362440689780157,-1.5707963267948966 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark03(-53.646818832332954,-9.473901982870462 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark03(-53.88668312956412,-43.060146669527576 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark03(-53.9155582984691,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark03(-53.98639137106542,1.5707963267948966 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark03(-54.04652663164302,0.45163797518738874 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark03(5.421010862427522E-20,64.41827439909798 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark03(-54.321685921217735,2.908208496745246 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark03(-54.41234699884035,1.5707963267948974 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark03(54.4449999117827,-70.6494460500185 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark03(-54.470640643802255,1.5707963267948912 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark03(-54.58580931410226,-1.5707963267948966 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark03(-54.593392248104706,17.166333286514877 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark03(-54.70267825822913,0.14900171282186983 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark03(-54.82475553931639,-0.06904979192546969 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark03(-54.91632270416524,-43.15356593728504 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark03(-54.97140109679681,-26.977185119789752 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark03(-54.97496407817045,51.94442536503942 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark03(-54.9778714378239,0.0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark03(-54.97787143782419,0.0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark03(-54.97925055741452,0.0013791195932213328 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark03(-55.11751646589153,73.14661644787529 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark03(-55.153488238460604,26.688055118988984 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark03(-55.164795998832616,9.240917838943117 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark03(-55.2038590646084,10.893714824898439 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark03(-55.214514852139416,1.5707963267948963 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark03(-55.31382220420366,1.5707963267948966 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark03(-55.37197079808767,37.822424970503114 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark03(-55.43225387568245,75.55605254579231 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark03(-55.452915411379415,0.0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark03(-55.47122201178512,116.39283814753759 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark03(-55.474896086264685,-2.4834554070927974 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark03(-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark03(-5.551115123125783E-17,-1.5707963267945522 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark03(-55.59259313603491,92.6769832808989 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark03(-55.63719634245246,95.66660804354791 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark03(-55.77973698851546,0.7733850233404513 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark03(-55.91138431608506,-19.70072162481351 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark03(-55.98200066256916,14.588345186563359 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark03(-55.99737338289939,8.68713472715947 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark03(-56.020115989036,85.7845150266404 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark03(-56.09113320292523,0.0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark03(-56.12461767217529,0.0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark03(-56.132604476429336,1.5707963267948966 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark03(-56.19674949916495,12.596855770667124 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark03(-56.20953020724875,1.5707963267948968 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark03(-56.222029526447976,0.0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark03(-56.26742239708587,1.5707963267948966 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark03(-56.29070337830016,2496.835492845524 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark03(-56.33553693005564,1.5707963267948983 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark03(-56.33965761885574,0.49989395238350826 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark03(-56.36531302344598,18.69363618446988 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark03(-56.37586830329749,62.610722870824134 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark03(-56.43085324204715,0.15383926804399756 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark03(-56.445306006715136,-4.815750738285833 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark03(-56.514531445492366,0.8268746425523694 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark03(-56.53445211251168,0.0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark03(-56.54814576062877,14.140221921245459 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866776459568,1.5707963267742957 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark03(56.548667768610784,54.97786542792895 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark03(-56.548667773319686,0.0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866784235506,0.0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark03(56.54866824145344,1.5707963267948966 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark03(-56.54868078518397,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark03(56.54868591053283,124.09287501900484 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark03(56.54891190524132,1.5707963267948966 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark03(-56.55257401461628,1.5707963267948966 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark03(56.55257443371123,-73.82742735930829 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark03(56.553356469455835,1.5707963267948988 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark03(-56.55425620225816,-17.28428791469581 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark03(-56.57135480064907,-102.10158162255108 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark03(-56.60885452423488,-2.070796326794897 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark03(-56.67643970649202,2520.480096903169 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark03(-56.71030215252606,99.00586902933864 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark03(-56.77560356075377,2.070796326794897 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark03(56.85531463244965,0.0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark03(56.9619950628738,-2.76646502589739 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark03(57.01404035178234,-55.64477572837667 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark03(5.709200050315796,2.1456946755908617 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark03(-57.173706631376305,-2.9069513788392953 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark03(57.283632953068064,9.575204212643333 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark03(-57.46865560694832,175.42523329581292 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark03(-57.57695521486458,-2.599083777043201 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark03(-57.59488111018658,-1.5707963267948948 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark03(57.68218158469395,-60.7823242263001 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark03(-57.70372337141359,75.23975898655155 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark03(-57.714534340916,101.64959146595882 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark03(57.783346235123844,-95.44581944386519 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark03(-57.81285528205903,-128.89120679354977 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark03(-57.838796807498696,-7.360967156062117 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark03(-57.86156844063967,-46.8659941530754 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark03(-5.7866689506900455,5.2123889803848 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark03(57.883157074631164,0.23630704360627608 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark03(-57.93496663562645,2558.0308491138726 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark03(58.009391629603414,-74.9713706284354 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark03(-58.02643073492568,-81.11528728161663 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark03(-58.02775086148457,2593.9258257652705 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark03(58.05122867686387,-38.57258227830613 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark03(-58.070606237841815,-53.99356868549433 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark03(58.08012700739539,1.5707963267948966 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark03(-58.09726099659728,-48.105884716780324 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark03(-58.90763440965945,-72.70598716399002 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark03(-58.92459478447962,-81.03281921129425 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark03(-5.909668540063164,94.3511512830084 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark03(-59.251991844860044,67.54424205287242 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark03(-59.690186469134446,-0.5707054736516756 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark03(-59.69026041820606,36.128315516282626 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark03(-59.69026423290338,-1.5707963267948966 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark03(-59.71600147612357,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark03(-59.72397064506359,-158.27298590961252 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark03(-59.82114700952044,0.01161428505318226 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark03(-5.987082361944232,85.29386763018806 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark03(-59.924867779474546,2495.872380889844 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark03(59.939160269885235,18.464677091868495 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark03(-60.1821034180309,-0.023258459968751817 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark03(-6.031035761052764,0.0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark03(-60.36697221756326,-0.8940845274377096 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark03(-60.37296566188011,-166.08994413938197 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark03(-60.382714190448866,67.29065502842931 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark03(-60.40715297796293,-1.570796326794897 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark03(-60.43644593743959,0.0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark03(-60.73864025216773,-17.189635303001765 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark03(-60.75507199423403,-57.05465251538322 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark03(-60.91202758038704,-0.7898216208325 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark03(-61.00101206361126,0.005223833290812857 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark03(-61.05286621595644,0.0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark03(-61.09243514578506,-80.41431743827599 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark03(6.12006091007729E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark03(6.123233995736766E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark03(6.123233995736766E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark03(-61.23913346167558,0.4544354544858822 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark03(-61.26935291152105,-52.73605831711761 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark03(-61.538638317278284,47.85760422563521 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark03(-61.54554607668532,-1.5707963267948912 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark03(-61.62770139766277,-16.27530733340856 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark03(-6.1838367388288225,-4.837388980384692 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark03(6.1966801881609115,36.73343645319096 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark03(-61.96906973534466,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark03(-6.197920468352424,0.0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark03(-62.142170779710916,98.3773472094403 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark03(62.183955810098155,-88.1278214655631 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark03(-62.297296914859864,-89.0008344703731 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark03(-6.239057321123198,-31.326013696201443 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark03(-62.45377271651674,32.22431584852393 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark03(-62.478694323125694,110.2458308122197 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark03(-62.54985931442674,-84.71552817892339 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark03(-62.83185307179291,1.5707963269372214 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark03(-6.283185307179634,-1.5707963267949443 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark03(-6.283185307180097,1.5707963267948963 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark03(-62.83185307181188,-1.5707963268109126 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark03(6.283185336986552,1.5707963267948912 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark03(-62.86062676765603,0.4999624704347823 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark03(6.288143806126274,95.81361743554248 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark03(-6.289114723127886,-61.2563004873356 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark03(62.903689976936704,1.5707963267948972 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark03(62.91159629552939,-84.40835779960989 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark03(62.913321607607145,1.5707963267948966 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark03(62.9559469583279,-55.20065150644584 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark03(62.97706844236296,87.59204256977776 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark03(-62.99427052965611,-75.7833587853558 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark03(-63.02995186168462,-0.3573169992604192 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark03(-63.03158466496597,0.0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark03(-63.11530124623236,-0.32291581740884967 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark03(63.11851303977807,0.0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark03(-63.1634543393758,-10.560977524061201 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark03(6.31949009006771,98.9964733699957 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark03(-63.23820152862609,15.917887956040069 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark03(6.3238933094105505,0.19225485394999137 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark03(63.272596458445605,95.33604389605969 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark03(63.30057195759666,49.16340501644259 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark03(-63.43844422990972,0.3029343267683671 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark03(6.3456880631299,48.726198530802264 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark03(-63.4851078309858,-1.5707963267948966 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark03(63.5703619157255,36.27597006321794 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark03(-63.64876551630475,-71.50274715027923 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark03(63.796029695455736,-7.948509121909447E-6 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark03(-63.852934593793414,-4.527888122184474 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark03(-63.875385727245316,1.570796326794897 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark03(-63.91399120816459,-2620.0263441473835 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark03(-63.93100397737055,53.703273258061984 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark03(63.95644156036799,-12.791738557786896 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark03(64.03967991107174,-86.39390152234387 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark03(-6.4045471792354975,42.290311425198 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark03(6.406939824805363,0.0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark03(-6.416188549409319,23.589777132807825 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark03(-64.19635522573864,100.0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark03(-64.20009727052127,39.162848269627176 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark03(64.25275841071235,50.81866627215118 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark03(64.26426419910686,-100.0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark03(64.28879110168447,-37.81297013998381 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark03(-6.43013480768151,3.5919967480882336E-16 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark03(64.31907770416393,0.0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark03(64.3196306307421,-95.98785113826823 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark03(-64.32909033692097,-22.064707636798346 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark03(64.33455003360987,25.14687264038593 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark03(64.34720598801414,-27.776224137424308 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark03(64.40264939858987,0.0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark03(-64.40703088734396,1.5707963267949019 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark03(-64.44368609979169,74.65492056721617 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark03(6.446401770293992,94.33136630033877 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark03(-64.46635635871743,0.0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark03(-64.59614393387558,-40.647209961382494 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark03(-64.84133519096437,2.7029068612161824 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark03(-6.484332739643305,1.5707963267948966 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark03(64.91421638325203,-100.65112429148485 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark03(64.91931430006791,-137.71341185647375 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark03(64.9270001052071,30.41706102335317 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark03(64.9276379033565,124.87884129486474 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark03(-64.9489539516724,0.009132682942897612 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark03(64.95569347866882,0.4789817963240548 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark03(-64.9562337416508,42.297791003626386 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark03(64.959196172394,44.40244967585381 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark03(6.533185307179587,-70.58860207973284 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark03(-6.533185307179587,70.71519045358309 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark03(-6.533185307179588,230.8944774755073 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark03(-6.53318530717959,10.884257794955662 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark03(6.53318530721097,-45.55303004800631 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark03(-6.533185308396933,45.73886801871387 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark03(-6.533226502101331,-73.59966679918301 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark03(-6.5348711363096115,-83.32582921243704 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark03(-65.5009033391549,-78.13996481898802 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark03(-65.50148932189009,-2.412477116563011 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark03(-65.55235521090087,-88.21511982267947 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark03(-6.558651681623218,-1.5707963267948966 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark03(-65.6061174335874,48.520161082795084 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark03(-6.56510096765704,8.135897294451937 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark03(-6.58072371707096,1.3921472529970833 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark03(-65.88919462075087,0.3518177221513617 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark03(-65.97343280486895,89.53539062730847 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark03(-6.5980304871812905,-18.731162760647884 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark03(-66.02552353720066,162.0637905357487 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark03(66.05647920320297,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark03(-66.13741112873787,-4.876354383737272 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark03(-66.17385806190048,-29.9501182570688 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark03(6.61863441376137,-42.746949930043975 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark03(-6.630985209834808,4.364589077729468 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark03(66.39408561237371,-77.17300752816898 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark03(-66.49519381180112,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark03(-66.52270905606548,31.029341042113938 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark03(-66.53567881134559,24.12417798788338 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark03(-66.57360158083583,17.873297017131748 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark03(-66.57553037857917,-1.5707963268176233 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark03(-66.6686804246115,1.5707963267948968 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark03(-6.674870984128219,52.22796446118022 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark03(-66.76197854758746,41.14250264707956 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark03(-66.84949543405767,-63.11302166361947 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark03(66.85348389620279,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark03(-66.86539724372763,44.18330006874825 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark03(-66.88893999813467,88.57866593606806 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark03(-67.13446085801974,4.97948359160452 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark03(-67.28228220162785,-87.31905150102723 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark03(-67.35603052907595,-50.24835414996127 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark03(-6.745804127232219,-98.85200789173871 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark03(-67.49082433524785,0.44219871461013593 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark03(-67.50029997709983,-0.00938632872261369 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark03(-67.54424205217728,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark03(-67.54424205218058,0.0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark03(-67.56428692090726,74.32220150850064 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark03(6.80924448067878,99.24219730403703 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark03(-68.10747642141739,-1.5707963267948968 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark03(-68.11460992586977,70.22536521171929 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark03(-68.18798111861504,-1.0753023431235853 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark03(6.83279777335513,32.86146742641519 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark03(-68.37048064127188,-42.425035382981584 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark03(-6.83757206143857E-30,-29.845130209579867 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark03(-6.842277657836021E-49,1.5707963267948966 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark03(-6.84254245364409,73.26807021289564 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark03(-68.52896876735144,75.89873608707103 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark03(-68.81461602559342,-5.406963056043139 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark03(-68.89749568772403,10.995574287564278 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark03(-69.11503837895937,1.5707963267788143 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark03(-69.11503837897543,1.5707963267948966 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark03(-69.11504600836999,1.5707963267948963 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark03(-69.11529040602566,4.712389069210566 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark03(69.11699152862825,73.82742398764817 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark03(-69.13066337897546,-1.5707963267948202 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark03(69.13250157647703,-1.5707963267948968 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark03(-69.13815842655714,-33.47336888581572 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark03(-69.16603571279299,-83.29502352337433 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark03(6.917450834317317E-4,0.1273855718889903 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark03(-6.918975223953665,0.029178754122415038 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark03(69.2037955717054,0.1594960428226575 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark03(69.22875325314956,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark03(69.28010942526605,99.28288312980857 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark03(69.30231642351701,0.0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark03(-69.35059076641508,1.5707963267948966 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark03(69.38869913206011,31.955950252417026 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark03(69.3916399473014,-0.5934592467082922 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark03(-69.44275140191307,-18.247656520237584 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark03(69.4921980389175,17.366272596984714 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark03(-69.5553370730035,43.60185982807163 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark03(69.55713489560821,2642.5865191102484 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark03(6.957014257422478,0.6042794404647036 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark03(69.58011443461479,-0.4587698802797978 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark03(-69.607662748157,-73.3457903656949 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark03(69.76574728718634,-16.862203725801123 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark03(-69.77265618892868,1.5707963267948966 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark03(-6.988034057742836,1.5707963267948966 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark03(-69.8969507582934,48.68766996145871 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark03(70.00394918991574,-57.032533554351716 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark03(7.001561728924514,-1.2614062038027762 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark03(7.004123016579914E-16,0.0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark03(-70.04335038293222,2.499108330751663 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark03(-70.07690637234336,0.469129231044726 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark03(-70.17812980302514,-13.00057332102233 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark03(70.21564666539523,1.3322034638843343 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark03(-70.23681341973077,-88.40209979311354 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark03(-70.26468475452367,79.14516333249702 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark03(70.26768662239893,0.0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark03(70.29947738907518,0.0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark03(70.38191748299681,9.86886603175194 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark03(-70.39678789997885,-61.4285958496117 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark03(-70.4259250139372,21.741930507932537 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark03(7.074713674603245,33.080434196325506 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark03(-70.89231011266895,86.53403365342415 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark03(-70.89870294222479,1.5707963267948968 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark03(-70.91261746751204,7.1535737622042035 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark03(-70.95751745683384,-1.5707963267948966 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark03(-70.98073954572004,54.3518929226116 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark03(-71.00035088688644,-1.570796326794897 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark03(7.105427357601002E-15,0.0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark03(-7.105427357601002E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark03(-7.105427357601002E-15,68.132314031697 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark03(7.126716822036872,107.89346635581585 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark03(-71.34169218604197,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark03(7.1440455155721025,0.0021942443959820242 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark03(-71.51766973713285,-51.19982240373555 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark03(-71.52747309904356,0.0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark03(-7.169058550186708,72.41440196615991 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark03(-7.181152526260632,-26.812513001912947 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark03(-72.00211699853618,-10.970399504391622 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark03(-72.08027552664839,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark03(7.221447117676647,98.4467612084913 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark03(-72.23054579889667,-74.51211228138582 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark03(-7.22479576420148E-21,1.5707963267948966 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark03(-72.25657167951903,86.39404211434434 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark03(-72.2566310202333,36.12831700279564 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark03(-72.25663103256522,-1.5707963267948963 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark03(-72.25663103279808,1.5707963267948966 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark03(-72.2566313567771,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark03(-7.236810902881523,0.0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark03(-72.38163103256524,-36.25331551628263 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark03(-72.38454773219212,-1.470590536002998 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark03(-72.46885720760373,1.5707963267948966 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark03(-72.47683341052529,1.5707963267949054 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark03(-72.5075038352156,26.37358577290034 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark03(72.58384202100555,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark03(-72.71766709685626,0.22020258684222047 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark03(72.76270630401055,-62.67417374711914 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark03(7.283915349494464,0.0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark03(7.288143827247158,-14.429212539076978 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark03(-72.89195805355055,2.345163678002347 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark03(-72.89333014809706,-55.614570553353204 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark03(-7.305104962236396,0.4984368812154368 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark03(73.11001879357872,-6.828632308042486 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark03(-7.314535456623771E-8,-168.07563069642083 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark03(73.35290901231716,54.20703554929355 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark03(-73.46413628369477,-44.39835682568847 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark03(-73.49703675249575,1.2040544783991909 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark03(73.53671064442142,-0.6937970964618074 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark03(-73.64610333790449,-11.967933764423183 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark03(-73.6729659714905,-112.42344425993022 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark03(-7.370435093186776,46.422017231980846 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark03(-73.74463300576552,1.5707963267948966 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark03(-73.91564344837019,-0.30043207051927523 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark03(-74.35825296750696,-23.184546394890376 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark03(-74.36080075135308,-44.51567054225005 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark03(-74.79981388196444,34.469313859976126 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark03(-74.98503001957687,-84.48228796861397 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark03(-75.13827264553375,-37.61795738957625 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark03(-75.3710458526545,0.0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark03(75.39822368627489,-1.5707963267948966 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark03(75.39834575646874,1.5707963267948966 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark03(-75.4238226861059,62.139252338408134 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark03(7.543995131496139,1.5707963267948966 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark03(-7.549406373606999,-28.44711794979035 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark03(-75.50674717598025,0.0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark03(-75.5570892141293,61.86501355167516 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark03(75.59102243828593,14.429224860595987 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark03(-75.59546536131117,-75.09907094503995 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark03(-75.61027749997362,1.5707963267948968 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark03(-75.66773729957855,-22.271376966836783 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark03(75.68903855258807,0.0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark03(-75.69086726667528,52.704478339210056 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark03(-75.70851061148119,-54.66758451249523 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark03(-75.74543681991734,10.617615650772876 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark03(75.83474362430266,1.1342763886472738 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark03(-75.83821816806164,28.699548532335992 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark03(75.87660732061642,100.0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark03(-75.95455720670712,-8.737224339246918 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark03(-75.96562014756574,-1.5707963267948974 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark03(7.598495157045663,-88.22008077744303 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark03(75.99079208751951,63.78584475224298 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark03(-76.00556892628829,59.043831480950274 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark03(76.01841741408265,1.5707963267948966 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark03(7.602929962806201,1.5559222898113665 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark03(76.0940059454511,5.414283570063077 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark03(-76.13082138187217,-4.5484908711731435 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark03(76.16121617783017,-19.331653667570905 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark03(-7.6234679734718185,7.044912828939175 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark03(-76.33144092903859,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark03(-76.34910205947648,1.3127820777071562 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark03(76.36091564754462,0.6081043654053186 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark03(76.36131647045013,87.01612265614727 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark03(-76.40571906285149,0.0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark03(-76.42329892912,23.561945431154054 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark03(-76.42438536882003,-48.41853388934483 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark03(-76.42561431193704,31.389290339617105 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark03(7.645275123058284,54.97787169315192 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark03(-76.46597679265918,-0.44324846889589403 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark03(-76.4974310625439,13.461661323864911 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark03(76.51536770615016,-88.33455943687889 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark03(-76.52275866212904,-0.4300853569867229 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark03(76.54065067472081,-32.445395201100325 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark03(-76.60355366514466,-33.22695138173117 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark03(7.662053149935118,-1.5709226466862245 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark03(-76.64680139969178,94.84820925006036 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark03(76.66949363592371,33.62794951763044 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark03(76.7211885512528,-12.775718449835113 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark03(76.77452117417232,-1.5707963267948963 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark03(76.79641394668772,17.843907213128873 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark03(7.681862857162723,-87.79247552370245 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark03(-76.84144255934626,0.0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark03(-76.84496307683621,9.753171418359585 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark03(76.969000089083,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark03(76.96902001295007,7.100937648649146E-13 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark03(76.99076443057066,-38.78490422935773 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark03(-77.02145624929182,1.5707963267948968 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark03(77.02484968694806,0.5577246116513249 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark03(-7.703719777548943E-34,83.2522053201295 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark03(77.09337725190801,0.0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark03(77.09567987569605,8.815312933179626 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark03(-77.12609139539846,-51.79185536131119 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark03(77.13234095325993,0.0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark03(77.21072550661157,-40.825487142400235 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark03(-77.2110831528688,10.845751394485877 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark03(77.223911998691,-66.41903364724763 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark03(-77.24887619145872,0.0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark03(77.2651103641732,-100.0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark03(-77.28036723274373,-95.56083330892666 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark03(-77.29578109129982,97.00942843594368 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark03(-77.30799421451009,0.0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark03(77.34488015029831,-1.5707963267948966 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark03(77.35092631554946,-1.5707963267948966 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark03(77.41144855971669,61.26105674500097 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark03(-77.41968235964349,41.20660917522579 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark03(77.43256302184031,-18.58462992676139 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark03(-77.4426727526934,90.63253421436055 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark03(77.45338298626127,-86.80416127752886 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark03(7.746495117509825,16.1542726406454 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark03(77.51694877295978,1.570796326794897 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark03(77.51763969358095,24.27585844273011 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark03(-77.61325038576888,-1.5707963267948966 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark03(-77.63143424992452,-25.089692258434383 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark03(-77.71210556973266,-47.866975360629624 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark03(-77.85967853996641,-43.69295254681334 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark03(-77.94212473866779,7.853981633974483 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark03(77.9757244455773,0.0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark03(-77.98992378685791,0.0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark03(-78.05138540526197,-108.01093545307907 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark03(-78.05582801104862,-12.397965296666552 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark03(-78.08232119339358,10.995574287566654 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark03(78.09187831497754,-249.62611590281483 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark03(78.11474502364382,0.0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark03(78.11958720794959,-1.1303923272939775 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark03(78.13177599758238,-97.53315483893597 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark03(78.17738193398056,32.25992914320503 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark03(78.1932530451549,9.884078566347824 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark03(-78.20594958646375,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark03(78.22470366441641,-77.91366651570507 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark03(-78.23034657161891,18.988969948367338 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark03(-78.29631359807323,0.013647043785414426 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark03(78.32325602254878,1.5707963267948966 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark03(-78.34083372219933,-73.75008462166828 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark03(78.3503836911917,-1.5707963267948966 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark03(78.35550276712961,-0.42677769134942 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark03(-78.36348203126032,0.0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark03(-78.38196160986286,100.0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark03(-78.45526094437993,1.5707963267949197 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark03(78.47095181014981,-136.16375475404215 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark03(-78.47099568198426,-23.562194253982877 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark03(-78.5228081901231,75.9595316537995 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark03(-78.53235393645114,-1.5707963267948948 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark03(-78.53968838643281,39.26989766630304 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark03(-78.53971678690473,1.570796116423915 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark03(-78.53981633974443,1.5707963267948966 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark03(78.53981633974475,-1.5707963267948117 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark03(78.53981633974482,1.5707963267948966 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark03(78.53981633974482,1.5707963267948977 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark03(78.53981633974482,20.420352248333657 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark03(7.853981633974483,67.8665989449248 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark03(-78.5398163397602,1.5707963267795342 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark03(7.853981633979261,15.709357769698624 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark03(7.853984210141192,-60.88686128441891 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark03(7.853997987623561,-6.683628886553568 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark03(-78.56716046263088,2576.1403621023005 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark03(-78.68604196885481,21.584882850267057 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark03(-78.78826711315372,1.5707963267951777 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark03(-78.85253711281578,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark03(-7.888609052210118E-31,20.42035224833365 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark03(-78.92456709379721,0.0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark03(-78.94261315635802,21.580642028220836 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark03(-79.04136269036135,-31.895023010235775 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark03(-79.23666093909034,-42.59381897815353 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark03(-79.26940891817371,0.0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark03(-79.5675414971845,-0.5430711693552347 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark03(-79.57964775166634,-100.0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark03(-79.60449847830077,1.5707963267948966 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark03(-79.69906134604234,-70.43302722152976 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark03(-79.75976387047818,35.89631010354006 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark03(-80.1106126665442,0.0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark03(-80.15242940629824,-0.04181673975851084 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark03(-80.52773746079623,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark03(-80.85866787402863,0.0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark03(-8.094842738852804E-17,0.0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark03(-81.0455093128068,0.0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark03(-8.104787841223377,122.27130728275304 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark03(8.114326804821879,-96.50237500454215 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark03(-81.52024006733673,-38.5290974599104 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark03(-8.152232067430418,2469.497554335682 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark03(81.68143965367027,-10.995095573548664 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark03(-81.68922149333463,1.5707963267948966 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark03(81.68923216588222,-32.99103511393491 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark03(-81.70895335543602,-54.91250809767805 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark03(-81.74982363180811,0.0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark03(81.77312023241737,-30.330711376271992 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark03(81.7898560532455,-59.42112277043752 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark03(-81.99679194533098,-4.397006028388331 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark03(-8.213681376063022,-31.897145873750787 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark03(82.22399635497,1.5707963267948966 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark03(-82.23714955535638,89.36419783712418 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark03(8.229087335798635,-34.831564996537 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark03(82.37928889234959,2618.1651698910655 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark03(-82.48045591366201,-25.04595928393091 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark03(82.48475381951724,0.2659741952871025 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark03(82.48817249483022,-0.7644256063160622 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark03(-82.49715465247456,-34.20636919740507 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark03(82.50840305017513,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark03(82.51845578935286,121.09742332074825 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark03(-82.55424847002048,1.5707963267948966 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark03(82.55971477251443,48.694693270087924 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark03(-82.59202247166759,0.0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark03(82.6481073068583,40.91264682837382 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark03(8.267077397718367,1.5707963267948966 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark03(82.74956288321656,71.70704817067448 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark03(-82.75391276148439,60.61788998431339 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark03(82.76265608528394,1.5707963267948968 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark03(-8.277756864028852,-0.5601585587547323 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark03(8.279492403084518,-87.88886133983004 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark03(-8.286575580051589E-9,-60.994669417579274 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark03(-82.93521014505387,-34.20599411657872 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark03(82.96770296055728,0.0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark03(83.00353807240995,-99.9143957860988 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark03(8.301032033379162,-62.57780121897572 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark03(-83.04113963114273,9.203740572987968 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark03(-8.312160738868315,-1.5707963267948966 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark03(83.28836024658885,0.0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark03(83.29679474306741,50.44681817477402 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark03(-83.31663428640665,-58.33821320611909 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark03(83.32832138331685,0.04506408878392008 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark03(-83.33556076763004,1.5707963267948966 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark03(83.33872005632935,-81.69241117266172 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark03(-83.36639944370934,100.0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark03(-83.37258982614026,83.72794458421001 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark03(-8.339015286448623,-80.59200512148914 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark03(83.40983301993873,-80.11358633863273 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark03(-83.41866856356563,0.0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark03(-83.44747816161839,13.969914309415152 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark03(-83.44965751262279,61.34350107130938 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark03(-83.46499756530841,-0.6405718364407846 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark03(83.4950991599739,85.78697217448818 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark03(-83.57355422682109,24.84753671152981 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark03(8.363693156586091,0.0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark03(8.367929959114033,13.080318939498722 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark03(8.374295864272469,39.9853411222916 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark03(-83.88177942639396,0.0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark03(8.403521206607195,89.18601255600568 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark03(-84.0587321129554,-0.04660805512685389 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark03(8.416236681449334,-2124.5526596721998 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark03(-8.422838581850897,32.63285043119903 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark03(-84.24825254638635,-1.5707963267948968 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark03(-84.26537304987869,-1.8169177642888676 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark03(84.31304701068203,1.5707963267948966 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark03(-84.36003138532593,-115.13110211762594 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark03(-84.40522693728693,-35.499815133232424 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark03(-84.41638406115607,-2619.527291113143 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark03(84.42262839513735,-1.5707963267948966 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark03(-84.45557583202542,-0.9198680477494132 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark03(-8.44570770466467,0.0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark03(84.48823982870712,8.703577492924714 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark03(-84.51346375266716,35.55850528082314 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark03(84.52283802384869,-71.65372197802947 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark03(84.53111709672524,-92.30320626329285 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark03(84.59363141548164,25.253894213365015 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark03(84.60425933569665,-53.10532044545169 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark03(84.60640273381831,1.5707963267948966 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark03(84.61429997818541,17.46302152692448 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark03(84.62184202801029,-1.369636707880771 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark03(84.67274311494681,6.906132520751567E-5 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark03(-84.69587103083092,1.5707963267948968 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark03(-8.470329472543003E-22,-10.995696357885375 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark03(-84.74353294874331,-9.756122448477084 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark03(84.81933676453025,-1.5707963267948968 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark03(-84.82201554369315,97.03185014568876 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark03(84.82300163776415,-1.5707963267948966 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark03(84.82300164632916,80.11061198310328 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark03(84.82300164684374,36.128315516226046 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark03(-84.82300164692376,-67.55518263955734 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark03(-84.82300164692424,-45.55309347478512 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark03(84.82300164692438,-29.845130201753424 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark03(-84.83857252744806,0.1714511685483185 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark03(-84.92960533076544,3.514512597345236E-15 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark03(-84.96757871770087,92.73772844966359 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark03(-85.04152779777519,53.766586475281706 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark03(85.08636542808756,56.762202149816034 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark03(-85.24234002962241,41.72021794429699 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark03(-85.24500487493005,0.0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark03(-85.27273993734774,0.9242479481569394 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark03(-85.27901341072939,0.0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark03(-85.31110991940318,38.7346201495246 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark03(-85.45432636693118,-1.5707963267948966 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark03(-85.7734260736347,-0.9625112382331622 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark03(-85.81446495414045,-4.181466555745495 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark03(-85.94947425531605,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark03(-86.0424279266233,-1.0790574654614167E-4 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark03(-86.19316703006233,-1.5707963267948966 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark03(-86.1996799200082,0.0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark03(-86.2784830616923,12.391204017548603 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark03(-86.36970208881034,1.5707963267948963 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark03(-86.37214120347909,-51.293849866147 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark03(-86.42412486437982,-2.026382539237545 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark03(-86.55102558275746,2.220446049250313E-16 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark03(-86.72815053797865,65.40166907655066 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark03(-86.93139508641008,95.78212724257745 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark03(-87.07453860255667,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark03(-87.10978401775222,0.0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark03(-8.726210383685611,-23.95648263604835 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark03(-87.27885726324867,-70.55790919156777 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark03(-87.60552243216162,0.0037192873097081137 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark03(-87.70420039732467,-4.532038572470157 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark03(87.78728578241481,-88.88002790864209 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark03(-87.86164542794043,15.28734102384955 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark03(-87.95431793390645,17.289035961351622 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark03(-87.96458999772449,130.37608557330933 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark03(-87.96459430051388,-1.570796326794898 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark03(87.96459620786285,32.99063364902416 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark03(-88.03783006210892,1.3985453289387506 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark03(-88.0449414232856,0.0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark03(-8.811043015617088,95.72658622294408 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark03(88.11783193826045,-1.5707963267948966 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark03(88.25841173438079,11.87244566325058 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark03(88.28673851840657,20.098208030441302 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark03(88.3064419750057,31.395901154485756 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark03(88.41483204916813,0.0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark03(88.47476030059755,44.32996392348661 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark03(-88.48482410009788,-49.502181016033894 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark03(88.49312087835958,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark03(88.5145273503379,-1.5707963267948966 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark03(88.54129687041399,-84.32002336753088 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark03(-88.56565596027693,-0.12157339102938114 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark03(-88.60830744982695,0.0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark03(88.61018121853684,-1.5707963267948966 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark03(88.62697371958089,-0.9084169077282187 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark03(88.67690303018026,61.97336547466701 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark03(88.70799856927678,-82.1458216987785 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark03(88.81636927370975,-6.429385442579968 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark03(-8.881784197001252E-16,-93.80381405731175 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark03(-88.84884760969929,32.688593603321436 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark03(88.8757188169557,0.0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark03(88.94791247383638,86.54218458406979 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark03(89.00287811665405,-27.946354939228414 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark03(-89.17050456251968,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark03(89.211804285206,17.32594893328006 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark03(89.26616644893096,0.0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark03(-8.930600932164936,-11.775938803548598 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark03(-89.31178166141846,0.0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark03(-89.34121155253808,-44.32002318240103 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark03(-89.41128947194244,32.12064460745103 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark03(89.42745858564317,16.95276589820658 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark03(-89.47489770690875,47.845820407295975 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark03(-89.54738238704715,-11.191893626165188 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark03(-89.54889303159064,-31.54929799661108 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark03(89.55425185857682,0.19598548361546206 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark03(89.60536452478513,-30.73180750666188 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark03(-89.64996268547335,-62.99834436988655 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark03(8.971432888479155,45.098340318728845 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark03(-89.71518398987708,-14.137166941154069 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark03(89.74054161666596,-0.4895959568394007 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark03(89.75706174607423,87.96459430051421 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark03(-89.80056464233053,0.0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark03(-89.84989274069206,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark03(89.85481992683384,1.5707963267948966 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark03(89.85516716129877,18.845688418724322 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark03(89.87307801617479,226.21148719351905 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark03(-89.87622765033046,0.0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark03(-89.88415813689866,28.623101391897695 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark03(-89.8991306645258,-65.9972280768551 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark03(89.91033428615644,-0.007983585947271079 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark03(-89.91427748297905,83.47560941167438 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark03(89.95060461993637,-38.107355062288974 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark03(89.95821018717616,33.58280967327366 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark03(-89.96273396549972,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark03(89.98155665156547,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark03(-89.98987532945121,-14.718726386667939 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark03(90.00401940431001,0.0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark03(90.04049645168791,16.446444358113318 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark03(-90.04708653510994,88.01972057478065 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark03(90.0578804673874,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark03(-90.07212490102121,0.8936820609326723 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark03(-90.37853548624489,54.977871437821385 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark03(-90.48350776354647,55.87591898405202 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark03(-90.54851075103502,38.36883232016699 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark03(-90.54999320726387,2567.8273690737465 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark03(90.63583098510165,-1.5707963267948968 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark03(90.65075837308548,95.18120376568046 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark03(-90.68320860216072,0.0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark03(-90.68551002550191,-1.991473255396988 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark03(90.71347883696347,-14.438623866303509 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark03(-90.76317142140188,-12.374677627061834 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark03(-90.79628538176435,84.14447496215999 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark03(90.81235288131026,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark03(90.83669409730052,0.7944171795128918 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark03(90.8417473952911,87.96459430051421 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark03(-90.88514014285768,29.72126416582645 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark03(90.92116025386562,86.73985550848391 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark03(90.93957552031833,39.10329673608674 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark03(90.95646144471294,90.51855668248541 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark03(-90.99828748617205,-1.5707963267948966 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark03(91.01563099626401,-37.04669484904488 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark03(91.01716665483656,17.88070527001034 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark03(-91.0443692107067,130.88483835875812 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark03(91.05436551338053,-2594.7103635475582 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark03(-91.10614884809367,-1.5707787937656603 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark03(-91.10618694625936,-1.5707963267749894 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark03(-91.10618694798359,-1.5707963267947929 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark03(91.10618694810313,1.570796399082262 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark03(91.10618695408489,1.570796326775783 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark03(-91.10618695410399,0.0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark03(91.10618695410399,-1.5707963267948977 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark03(-91.11682368577715,4.712388980778565 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark03(-91.18312508775662,4.837388980384722 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark03(-91.29433570067782,68.63879566504392 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark03(-91.55894123740475,-1.5707963267948966 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark03(-9.157363283703674,1.5707963267948841 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark03(-91.68211832359975,59.92275614155093 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark03(-91.73239163572102,5.338593662001701 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark03(-9.17654420786997,34.56315839838984 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark03(-91.77478424471053,1.5707963267948968 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark03(-91.79378610692137,-27.72289237935948 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark03(-91.82335791706338,30.492873964968602 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark03(-92.16235847669671,-16.31110989868219 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark03(-92.18673985652792,0.0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark03(-92.1904500577129,-5.521161322668956E-4 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark03(-92.24889396917398,39.41617118680919 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark03(92.34076717244918,-4.035788686121961 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark03(-92.35670369086561,-95.03796156280077 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark03(-9.255897464004619,68.41991470848495 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark03(-92.67698328089462,0.0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark03(-9.30399160954964,-1.2801763370186234 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark03(-93.19160592571829,39.74417398691659 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark03(-93.29629011627189,-0.042874250088936194 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark03(93.31980947886481,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark03(-93.32126418749502,1.5707963267948966 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark03(-93.38375887522989,-50.01473117797624 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark03(-9.407148911083707,8.103981633974485 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark03(-94.10612777072014,1.5707963267948966 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark03(-94.1868242899979,-1.5707963267948966 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark03(-94.24777958902538,-92.67698327455548 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark03(-94.24777960768279,-1.5707963267813732 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark03(-9.424777960769358,-1.5707963267949183 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark03(-94.24777960769377,-1.5707963267948966 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark03(-9.424777960814163,-1.5707963267948966 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark03(-94.2477815152687,1.570796258787354 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark03(-94.24790167801079,-95.81841330832407 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark03(-94.27903202260548,39.26605387400334 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark03(-9.428684210769388,-45.55309347795897 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark03(-94.3007545565046,72.62622588734878 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark03(-94.33187941242002,-1.570796326794948 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark03(94.38208974185861,67.76763960842368 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark03(-94.40956348726415,-63.06630256493035 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark03(94.42065637171879,89.35059178347133 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark03(-94.44556561204547,59.79519562965935 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark03(94.45808191943007,-96.01017393539912 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark03(-9.458720366609257E-16,63.734546463725906 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark03(-94.59271238675919,-60.68970335556625 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark03(-9.459719213818344,117.84466576266621 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark03(-94.62426319757553,82.4799574848075 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark03(-94.64185882730175,-1.5707963267948966 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark03(-94.67435164689077,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark03(94.68228348567355,-5.146892858364444 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark03(-9.472309315242745,88.3044125596384 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark03(-94.72778057249064,1.5707963267948966 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark03(94.7394772436359,32.49502522675072 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark03(94.73997248978901,-0.35002873951889796 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark03(-94.81807793834787,196.76870050084548 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark03(-94.86740402655926,6.677118057164368E-7 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark03(94.95923616486095,-9.942385434553762 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark03(-95.0026697041978,-28.50460886427011 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark03(95.04396616086018,-72.24220542122303 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark03(95.11182041211619,-1.5707963267948966 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark03(95.24905437146282,-1.3651645836099848E-4 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark03(95.25557727434258,-73.52344762750967 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark03(-95.31295678638868,16.52794385845428 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark03(95.337665717748,33.39285702616249 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark03(95.40219815463172,0.0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark03(-95.43836938186637,44.99188883574855 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark03(-95.47831813547482,-55.2558373188353 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark03(-95.58479975291601,-66.20722190695834 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark03(95.63320314621743,87.63152330226828 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark03(95.6367178047252,-66.44849918639031 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark03(95.6401306093401,1.5707963267948966 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark03(-95.67365370128873,-62.858476481082945 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark03(-95.67718977721917,96.59195207149588 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark03(95.72870032005245,-48.04234557083116 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark03(-95.74802360799322,62.05824195662285 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark03(95.7972032185853,1.5707963267948966 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark03(95.79889465472829,0.0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark03(95.81211107232807,-5.734633402152525 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark03(-95.86309379638298,-0.09329822487802777 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark03(-96.68643518410369,-45.21367430707175 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark03(-96.70279500109069,-71.4754938059323 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark03(-96.7099789749938,-2.6491860145247728 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark03(-96.79445981659576,8.448894078662311 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark03(-96.80366687088147,-17.278759594904663 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark03(-96.90255329786146,-0.0746636969430626 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark03(-96.92909165006056,0.5707812875021637 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark03(-96.96530368905742,-1.2389010829162856 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark03(97.09583927658682,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark03(-97.24883409258615,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark03(-97.28470674723543,-44.717650695134914 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark03(-97.31852485782125,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark03(-97.38927660373545,1.570796285276231 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark03(-97.39718476128363,1.5707963267948966 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark03(-97.39718476158535,127.23450534418387 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark03(-9.742052419771447,0.17365809094868756 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark03(-97.51552162219885,-21.371290877791147 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark03(-97.52332819981383,-96.13324330797396 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark03(-97.68223236730176,-38.841251913279336 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark03(97.82657901062075,73.29090629808869 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark03(-97.93603069607651,64.04584899965181 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark03(-97.97313297634594,-59.972122087986435 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark03(-98.10105876463078,-1.5707963267948966 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark03(-98.1063206102257,1.5707963267948966 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark03(-98.28943103606653,-14.289891605773875 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark03(-98.29648137254898,49.68068912166394 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark03(-98.33234998539986,38.77851105855117 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark03(-9.847736610565526,4.539460142831729 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark03(-98.5521315102457,62.42381599396308 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark03(-98.64256610416152,-1.5707963267948983 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark03(-98.85966510390195,75.49872717033158 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark03(-98.9601685880784,1.3573951068940769E-12 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark03(-99.00937078942673,-14.42920497318142 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark03(-99.22401060334779,15.833640367179868 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark03(-99.22558438193873,1.5707963267948237 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark03(9.924777960769381,4.314890533311974 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark03(-99.34998953140766,-0.013886456088304683 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark03(-99.44440815478033,6.712388980384691 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark03(-99.50353782290114,75.94497284897454 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark03(-99.70880209943924,-38.54490886025608 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark03(-9.987766479787174,-90.18843090839512 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark03(-99.9999997753029,29.84513023827574 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark03(-99.9999999985233,1.5707963267948968 ) ;
  }
}
