import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(10.483184155337389,99.4139658793795 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.3618158950681573E-5,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(1.490854202140537,0.7317920498995605 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-2.6747111854601258,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(2.7414501205474266,4.774098642902073 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(-2.963198977076364E-38,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(3.3182283907123633,7.692411262217197 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark41(3.6146230974488416E-39,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark41(-4.042271879616138,20.38223382835152 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark41(-4.4949578851671044E-38,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark41(-64.18085562702072,-5.774473032216278 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark41(6.9437990667467766E-9,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark41(7.630345859446378E-9,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark41(-8.472372443719593,91.51258329499436 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark41(90.37302393905912,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark41(-99.44349052972974,0 ) ;
  }
}
