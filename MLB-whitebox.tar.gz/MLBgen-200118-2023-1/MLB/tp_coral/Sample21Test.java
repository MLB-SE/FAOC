import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(0.0071412502234029515,-228.61417340762392 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(-0.008001668727067661,197.44216344570572 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-0.008372510330509793,-197.7563239843737 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-0.010892255897476336,149.95025364747482 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(0.0,11.130109410483044 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(-0.011302506687852553,139.11704379551225 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark21(0.012391002008100036,134.45145605765273 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark21(-0.012910041150681478,121.97502385358104 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark21(-0.014103519518458256,201.07497407277134 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark21(0.01478552746699532,113.61246276610221 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark21(0.015520095989229656,133.69306745385958 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark21(-0.015707963267948967,-100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark21(0.015707963267949012,-100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark21(0.0,1.618555525497186 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark21(0.016717829163255173,93.95934791865302 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark21(0.017501262293852855,-89.75331609918354 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark21(-0.017703374174100735,88.728640729568 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark21(0.018327001952136393,85.70939921855515 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark21(0.018546189458854556,84.6964456110912 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark21(0.018687382670178377,84.05651980786227 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark21(0.018834242591291073,83.401088160628 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark21(0.019144952786007252,-82.04754247013726 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark21(-0.0192399424070251,-107.63007802326159 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark21(-0.019421835438832226,80.87785172220282 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark21(0.019881392030389553,79.00836744197126 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark21(0.019995790569171997,78.55635021586153 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark21(0.020199263319684135,77.76503043377673 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark21(0.020589048636449274,76.29280762463591 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark21(-0.020830472361403896,-75.40857929392777 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark21(-0.021500693398245785,-73.05793807203247 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark21(0.02182221354761516,-71.98153035059822 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark21(0.02437498355797807,64.44296969719349 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark21(-0.024761203064978664,63.43780319045052 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark21(0.0,2.488909668988498 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark21(-0.02646796470861875,-59.34707651636694 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark21(-0.02652562660769953,123.21252204132537 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark21(-0.028550775976741313,-120.44036347671542 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark21(0.03078004762567775,-106.12700058628525 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark21(0.03253759362005643,100.39627442637705 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark21(-0.03272750224673969,100.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark21(-0.03354547876150865,46.82587295779745 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark21(-0.03359159436116954,46.761588924588466 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark21(-0.03372062895083026,-46.58265209362954 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark21(0.0,-33.798327562728076 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark21(-0.035433941433572334,-79.20605626020095 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark21(0.035946227730562,98.2821314148566 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark21(0.03743039267710474,-41.965798765336366 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark21(-0.03753712018108142,-87.04210632302099 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark21(-0.03775213003303513,41.60815099493369 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark21(0.038179152643380135,41.14277604501147 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark21(0.0382419701123851,41.075193620481805 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark21(-0.04003203103853149,-103.45728498814496 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark21(0.04399632922211329,74.56843664880319 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark21(-0.04595355335319835,-34.18226039500761 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark21(0.0,46.54614614206167 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark21(0.04668269252215905,-33.64836606306032 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark21(-0.048110981132093104,67.89726344664649 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark21(0.051332745405773116,-61.37149923761119 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark21(0.052063844913773104,62.87324551627998 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark21(0.05244406667164676,-59.938209201942236 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark21(-0.05353386951321703,29.342103253101893 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark21(-0.055836713018637386,28.131962679654716 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark21(-0.059181460838506235,55.19705978963972 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark21(0.06087495902979181,-53.663711157078005 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark21(0.06317873243639942,-24.86273887144194 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark21(0.06433835476450318,24.41461757212261 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark21(0.0645256970612591,24.343732781431555 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark21(-0.06465661105320879,48.5888852285305 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark21(0.0,-66.87105568392633 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark21(-0.06752908316975861,-23.261034402705214 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark21(0.07939758098435319,7.185909873614863 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark21(0.0,7.951039154116842 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark21(-0.08396415594330861,-18.707939228919027 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark21(-0.09554273661928825,-34.22239413384645 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark21(0.10508346920558223,-14.948082116720343 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark21(0.1060380289266211,-31.85155268678809 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark21(0.11421444047007535,-28.600520405505772 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark21(0.11824261356696653,81.92188652458452 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark21(0.12074323425271069,-82.40339558276094 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark21(-0.12153089139355996,-4.696717507738723 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark21(0.1221820917379386,-12.856191152497274 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark21(0.1253434326687306,-85.36283100872853 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,-15.942661449856363 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,18.43572282942315 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,-19.455482816515325 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,21.488479555423837 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,29.674310389153295 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,-31.17211006433157 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark21(0.13112531277708173,11.979352373141332 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark21(-0.13173520089126683,23.874156147737008 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark21(0.13769940206213263,68.44458160100072 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark21(-0.14448149887333633,-10.871954811128234 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark21(-0.15096036822691306,69.04192163394079 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark21(0.16248170227127198,-9.667527511327814 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark21(-0.16993221157542718,-9.24366435434564 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark21(-0.18239170145360994,-60.285493044440216 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark21(-0.186643728466902,58.91210153419727 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark21(0.1983358380336932,-21.03144332431681 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark21(-0.2047162246465133,-20.230898273634903 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark21(-0.21536892647685738,7.293514215309457 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark21(0.2162978166911272,2.830927324837833E-16 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark21(-0.246849137475691,6.702104534773024 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark21(-0.2787228991193332,38.636738449027064 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark21(-0.2815887305189463,59.99630975757869 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark21(0.2933882481025905,-5.615807519611792 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark21(0.30022278158363697,10.464204981119304 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark21(-0.3044288523681047,1.174096401164193 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark21(-0.3060146535606697,-13.674353805427373 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark21(0.33218628685179064,9.457321924849081 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark21(0.3445423378984365,13.67724213264554 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark21(0.34458387007870594,-4.558531211678925 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark21(0.3526808513305122,100.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark21(0.37911068717519764,24.86032980909735 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark21(0.43017797084547543,7.350911343008388 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark21(0.4394132983682888,-21.687179845147682 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark21(-0.46051519940060315,-6.821908797506164 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark21(0.4700420503261853,-50.12731283418718 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark21(-0.47295048751285973,100.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark21(-0.4863729826469443,-100.0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark21(0.4974953533073271,-31.57503910779048 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark21(0.5010620408459527,3.1349337981039054 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark21(0.5729831563601984,-3.7913689383330222 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark21(-0.5855611930946918,5.3650970908547935 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark21(-0.6113964406882013,17.050890845456305 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark21(0.6128529758747496,-16.476555531527183 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark21(-0.6250736598808143,2.5129779538213293 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark21(-0.6382818612105932,4.9219703485611275 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark21(0.6546911308253264,2.3992937323203023 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark21(-0.6577749047236239,-90.30368217656707 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark21(-0.6593120161264581,-3.1768562985322735 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark21(0.6639412309238056,44.010548186330475 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark21(0.6782174809499679,-1.4779288903810084E-12 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark21(-0.6854238706060719,-2.2917152351375694 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark21(0.7051993479766755,29.16680262346543 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark21(0.7058612159345898,-99.89961508867738 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark21(-0.708277457832925,-2.5340550615362245 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark21(-0.7127901100630578,-4.5828254907657 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark21(-0.7268909401209314,90.81075602125398 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark21(0.7287030288142105,-100.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark21(0.7371844049517826,-13.223651240002406 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark21(0.7414196700893021,-88.21270933905555 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark21(-0.7529868355905478,-2.086087369061323 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark21(0.7578119255696615,44.30643031157393 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark21(0.7585236162324127,-11.67243430687072 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark21(-0.7697516316344694,-6.121960365811156 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark21(-0.7753230930941296,85.37967933500616 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark21(0.7775096626756125,-51.23878629490509 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark21(-0.7786171303146845,-29.414113041224997 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark21(-0.7796900206749922,100.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark21(0.7818456561510981,37.07677540555108 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark21(0.7821818280813787,2.0282001821687716 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark21(0.7843758385769649,-18.098378576383226 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853948037417116,91.06054755131868 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark21(0.7853980980778104,-61.1334893448983 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633904108,-68.62226416214462 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633968892,92.26270358850252 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633973746,2.000000000000192 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974094,27.12094422279873 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974351,2.000000000000206 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974456,100.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974456,2.000000000000007 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974456,-21.756663918281944 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974456,66.10299825784854 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974456,-92.35166632872958 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974474,-12.561038055585286 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974478,-43.69977365366537 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974481,-85.73658991401732 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974482,-100.0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,100.0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-100.0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,100.0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,11.208793552817625 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-11.724299612720362 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,11.729690795771546 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-12.46848007977129 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,12.57231932009276 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,12.662070611099603 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,13.30915819868138 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-13.504629924633775 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-13.808788541672083 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-18.09615906795499 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-18.668901213744874 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,19.20000156035259 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-2.000000000000023 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,2.0000000000005453 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,2.0000000000006857 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,20.253948990207146 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,2.054000894430572 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,20.575337835375688 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,2.075471543957514 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-21.925338460317864 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-2.3083361240317757 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-2.367739541782395 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,2.497698585109597 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-2.6982988197698132 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,27.891840146533248 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-29.68676339286978 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-29.92936604416794 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-36.09256845720949 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,4.048139911448295 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-42.005843770433444 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-42.19701645808413 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,42.276093291176196 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,42.39967151947946 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,45.295000956619404 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,45.99855985363547 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,50.14022720974826 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-50.407746782821256 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-53.93887439038514 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-5.413639243191671 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,5.511537935827464 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-5.597619336689164 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-5.833774474128212 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-59.93721120026485 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-61.83720607827863 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-66.7104388168995 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-66.99569772471324 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-67.62269273304649 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,74.72059674486232 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,84.2450371521188 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-84.35826439719325 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,90.07673555346874 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-93.39435877164371 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,93.9365900152801 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,93.93767908417063 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,98.66375224461837 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,98.7089202410335 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,99.6957078967692 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,99.94348245574209 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-99.9999999970011 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-99.99999999946928 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-99.99999999999993 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974484,-100.0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974484,19.12184141602893 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,-19.227214363449953 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,27.0317781290713 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974484,-2.988018376078793 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974484,5.086258585862154 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,53.367017813932236 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,5.837588345761084 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,-99.99999999999999 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974488,4.085042534319953 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,-100.0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974492,-20.440547928826007 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,-42.76351183536829 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,5.399956868918508 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974492,68.68528739560819 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974503,91.7048585644355 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974533,-66.47044162743776 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark21(0.785398164762184,35.838874843848494 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark21(0.7884450051803049,68.05430278394155 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark21(-0.8045874440792204,2.2356634520690193 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark21(-0.8167690742397961,-34.61734180958948 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark21(-0.884607549563782,73.33927771533001 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark21(0.9421412040380495,-77.11781898094124 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark21(0.9737737125221173,-1.613102003674399 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark21(-100.0,-100.0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark21(-100.0,100.0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark21(100.0,-100.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark21(100.0,100.0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark21(-100.0,-52.48403965271561 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark21(-100.0,-57.4523823934675 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark21(-100.0,82.52383718362321 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark21(10.0790130493358,-93.8813498982706 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark21(-10.112461065152456,45.569475812046534 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark21(-10.303676229919326,-88.60969262908188 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark21(10.430459669747677,-35.84952658364031 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark21(-10.468103463953899,-76.06778603437286 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark21(-10.468502534391803,-6.848373133699809 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark21(1047.2520095642683,123.17802767103177 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark21(10.646449732138578,-45.0931944449251 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark21(-10.710648093064297,-18.403774733004987 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark21(-10.736623524259414,-8.932199617623084 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark21(-10.7439966048766,-87.35521587915684 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark21(107.78917695997805,-0.021434655138676817 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark21(-10.87453758160009,0.41950290695656633 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark21(-10.910684558466052,20.900414699412302 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark21(10.949924704825172,228.66361315539854 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark21(-10.995573517471929,-0.14410363523144193 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark21(-10.995573912288805,-15.111619350027793 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark21(-10.995574287564274,-49.51176729035437 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark21(10.995635648337307,12.795803406233338 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark21(-11.071263089700848,-49.679946793412 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark21(-11.120574229597818,-29.75927261542855 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark21(-11.15094404424454,-14.936398168967656 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark21(11.16710269197954,-11.548597465817082 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark21(-11.237226167128483,42.90354584001636 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark21(11.287489193371457,0.13916259850929436 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark21(-112.97099540166153,0.0238766559491026 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark21(11.428752875412163,0.13744249647521123 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark21(-11.528684140830393,17.38785644329097 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark21(1160.4273906808612,1475.0339092061515 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark21(-116.17471642266908,-0.02521403528281496 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark21(-1.1622894681174225,-8.10880535327229 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark21(116.27146607300017,97.35114810856216 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark21(11.71088328134542,72.5962594449501 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark21(11.791434302005204,-31.739491548010022 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark21(-1.1902755936689147,1.319691284228606 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark21(-119.27496635834416,-85.47509507200945 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark21(-12.005447455428907,26.508024417490013 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark21(1.2136558912040059,-39.354582003423886 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark21(121.75839132351463,-0.9556671116185385 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark21(-12.341179993429444,-86.35912056016471 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark21(124.30875325448764,-93.33164373672874 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark21(-12.435582781556244,-87.56613047520685 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark21(-12.44147854923945,49.35221876436534 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark21(-12.496085734464543,-17.075353038875463 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark21(-12.569726004378346,54.317316296258525 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark21(-12.572206377159873,-0.3549006547012965 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark21(125.7633648384796,-92.0571113716917 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark21(-12.582902877402262,0.7762641513990474 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark21(12.680798404078914,-91.32230095300608 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark21(-126.90541297935596,99.50427926266521 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark21(12.69271074193021,14.05232164444064 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark21(-12.70493764522043,51.68772842017773 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark21(12.729093211533566,-3.0980636054128325 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark21(12.729616387137185,27.387678724634213 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark21(-1.2761248793265594,22.49273743711553 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark21(-12.761819656111001,65.66171288635297 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark21(1.279561169935354,66.32182905361267 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark21(129.7819077262458,-41.9087867267796 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark21(12.98502631474092,43.4133895096741 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark21(-1.3080015873641884,-93.4650170202087 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark21(13.08386508564449,23.783594547795694 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark21(-13.088248753127017,14.76194058662449 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark21(13.126120123691935,-44.2777176681066 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark21(1.32242636675808,88.72799527939574 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark21(-13.265127571141804,56.56624600945495 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark21(13.355437958979206,7.235075395758502 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark21(-13.411852156435426,-49.03750844839938 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark21(13.414111164649086,43.68770692101576 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark21(-1.3433378016082287,-85.28388409690547 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark21(13.452850213356841,-80.99715430870596 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark21(-13.498733942067815,0.70901823557619 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark21(13.566370614359174,-0.12736656101576813 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark21(13.576815826792927,-19.101113181980033 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark21(-135.82842775851702,-60.21500948658729 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark21(136.6749078698911,118.08220180447108 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark21(-13.867685582016566,0.1175397914492301 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark21(-1394.5560890848462,1312.310168959233 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark21(13.966169529081695,-120.45645567035909 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark21(14.010826813583034,-65.79443622127873 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark21(14.02345905259051,52.2766961862818 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark21(-1411.6961367724637,-1275.0031245233406 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark21(14.123341746391162,-63.89140233488284 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark21(14.138143503663478,-0.11110408059909525 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark21(141.53651297078738,-29.22192681868492 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark21(-1.4210854715202004E-14,0.0682567942985628 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark21(1.4210854715202004E-14,-72.31680884286585 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark21(-1.426152664359904,-19.789009350370648 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark21(-14.263507068725106,0.11248581530654375 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark21(-1.4293515705987119,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark21(14.310539107667438,25.596515422698516 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark21(-14.314490831313881,50.720676965347884 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark21(14.493516478824791,62.99785672060884 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark21(1.4509547897845763,1.0825949491011462 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark21(-14.515540963976068,59.19349426171513 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark21(14.606451641094864,9.696435310494934 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark21(1.462228776038228,-1.7148410882429204 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark21(146.458160878787,36.57265227268685 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark21(-1471.2585652665484,1211.3253507060742 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark21(-15.16212136188058,21.6105950764627 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark21(-1.5243882142634944,-89.64733615101397 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark21(-15.269943730994967,-64.80355885927065 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark21(-1.5397116199966328,-100.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark21(-15.583071202829371,-42.55603849112157 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark21(-15.644075671387025,-39.88404608654413 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark21(15.70796326789729,42.294398479263805 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark21(15.70796326790293,-57.76691648828932 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark21(-1.5707963267934086,-1.9868531933167444 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark21(-15.707963268007195,-11.789333424863935 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark21(1.570796326815461,-2.8321804028158226 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark21(1.5707964460041872,-2.672108779327063 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark21(-15.70802430310522,-0.5433554455803957 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark21(1.5709841037753884,-21.700381691758878 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark21(15.822824418628883,0.0992740793451361 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark21(15.932222732011397,22.66428483955328 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark21(-159.32660488682936,12.912406325526575 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark21(-16.033253950276386,93.50997041526847 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark21(161.069123483736,3.3286442692197573 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark21(-16.206675402290884,0.09692279803252292 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark21(-16.259043398585604,16.72873033924507 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark21(16.260251950598544,-94.44015203682264 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark21(-16.264767328272804,91.29774710159148 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark21(16.461875742263082,-98.24668959137493 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark21(-16.487653460294535,-100.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark21(16.601018769411695,-74.0143350061275 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark21(16.661798008193813,-36.65842714105827 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark21(-16.741399974388823,-80.90071105384757 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark21(16.758715205770276,58.69849116331464 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark21(-16.765611902262492,0.09369155960140779 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark21(16.85204049758491,-130.69069186473752 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark21(-168.59122646080075,132.3606535921231 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark21(169.53408805509434,-48.68177322909961 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark21(-1.697136454365933,0.9813206476706016 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark21(-1.697136454365933,1.5574990870908074 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark21(-1.6971364543683491,98.44294490855215 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark21(-1.6971364951127792,28.13829456249772 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark21(17.030110054657264,68.45328082381633 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark21(171.17883098990782,-0.0033343212740694194 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark21(17.16185662247684,32.83937162682299 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark21(17.216026884326354,-18.599955758713094 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark21(-1.725830143926784,2.399768406132463 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark21(-1.7278759594746342,-100.0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark21(17.281404278325414,0.09112182880224518 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark21(-17.390986045491598,55.01428055485532 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark21(17.471983514980238,-68.10484949685909 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark21(17.49784589867744,11.712633275481792 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark21(17.591438236254323,-61.98528635567406 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark21(17.599597634482663,-0.0892518317417248 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark21(-1.7621423292758855,16.28900528656343 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark21(-1.7763568394002505E-15,-97.79511122060373 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark21(-17.96794743744266,-127.77412385879381 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark21(-18.07029839645125,5.302545305688247 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark21(-180.8619728451217,53.19600999229282 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark21(-181.54307834716306,-11.54281308259435 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark21(-18.265924867432503,-21.91447367059358 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark21(-183.2937340793185,-75.7132712624291 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark21(-183.7631089354027,85.67497587828093 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark21(18.393648001242756,13.891780428086058 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark21(-1.8456516801060572,-21.277517036869796 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark21(-18.5977762174722,14.949687886957834 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark21(-18.72466385641904,75.61582116919135 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark21(-18.785006917650122,-4.196139298516348 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark21(18.849555921535682,-1.5372264812442866 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark21(-18.855099343841886,83.48916420049716 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark21(-18.92703415628567,6.48916534145701 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark21(18.931712620638088,-34.75979725662245 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark21(-18.971584011367582,38.91989907810802 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark21(18.975896049109796,-0.08949014311487666 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark21(-1.9052265291403359,8.881784197001252E-16 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark21(-19.06122610831143,64.72371815696711 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark21(193.24411960602285,55.41239117949263 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark21(-19.50861395736517,-0.1175184301741048 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark21(-195.93380385930038,-124.51163235192777 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark21(19.634954084936215,59.116877374410294 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark21(19.634954380227395,-19.111913806715734 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark21(-19.64505765650032,-4.439270214688284E-16 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark21(19.673285801326884,91.85317676960904 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark21(-19.817964590693123,28.943671332428494 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark21(1.9821212004932107,64.5461701372281 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark21(20.220470579204147,-10.65995909912455 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark21(20.266029622697573,-82.3095046396529 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark21(2.031975898924344,-4.546115151507152 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark21(-20.3675829678687,18.418675868405614 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark21(-2.041017564620934,-0.7696143110297768 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark21(-20.420338886357282,8.419051564901585 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark21(-20.420352247015003,5.108772551746519 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark21(20.42089729918069,0.1870628178885596 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark21(-2.0527229064636074,-26.16356319149458 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark21(-20.5488921052946,-34.366007017440666 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark21(-20.67035224840498,0.07678667384440045 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark21(-20.701298350601032,-41.355696767624245 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark21(-2.070796326795007,-0.8119161566440312 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark21(20.76833115320717,27.944752105246252 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark21(20.798773493976366,5.313499983013784 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark21(21.047450710350716,0.07463119160661336 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark21(21.14186345379251,63.81543944095819 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark21(-21.14534748789809,26.60559120420794 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark21(-21.17216907538195,-7.247648041836456 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark21(-21.327353261795086,58.423214138595604 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark21(2.140678183868232,60.21837000386071 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark21(-2.1578195138443506,-51.07302165837449 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark21(-21.599122621682938,46.080091923737115 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark21(-21.801189848203364,-10.799644521455505 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark21(-21.83095472375372,0.07195270874329651 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark21(-21.907647109089528,39.650670294294585 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark21(21.93710953495367,-77.49719189703706 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark21(22.126317883321406,0.07099221555941426 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark21(2.220446049250313E-16,-18.275765943415024 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark21(22.331724931253106,27.39109400085641 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark21(22.397612633409203,-0.07013231063974601 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark21(22.476533079091254,0.14563462438840702 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark21(-22.49227950145177,-14.664270575498417 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark21(-22.565966100935782,-6.037769382050257 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark21(22.605671266268484,0.0694868318679922 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark21(22.626590463844536,-8.76368029826331 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark21(22.638494961786492,3.722237491016969 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark21(-22.643210308437276,50.305960436867025 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark21(-22.77654652077599,39.253321949267956 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark21(23.04557501299705,-49.5185189232074 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark21(23.111777008346095,4.022680878976743 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark21(-2.356194490192342,1.6506725540906757 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark21(-23.688285029494487,50.77980232310901 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark21(-2.3806537585094314,1.9795280122939505 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark21(-23.812641754309862,78.75234809468117 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark21(-23.822210853643583,54.261683571123086 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark21(-24.36450411131631,71.06172488494596 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark21(-24.382598478883196,90.05959870210773 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark21(24.697232753209033,-0.06360211860540516 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark21(-24.948171963467193,69.44746039635827 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark21(-24.950159122206685,-30.073760331211766 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark21(25.02379709636368,59.35468075665119 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark21(-25.038218923666022,-83.24608215437232 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark21(-25.047681091229585,164.16526742234743 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark21(25.06433316477643,60.011617993687736 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark21(-25.102581699025464,-12.143191608940649 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark21(25.13274122230659,-46.846692134538614 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark21(25.431059874059045,124.88086046780617 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark21(25.489791459730966,55.14749429844102 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark21(-256.2409545712837,-37.60392885109391 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark21(-25.74135012288596,-46.20655850028519 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark21(26.132741228740258,60.169088513125736 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark21(-26.235533352042665,-53.50355021095065 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark21(26.578645490393523,56.61921600132809 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark21(26.694719833797336,-65.57534443320486 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark21(-26.703537555398913,50.45812254728065 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark21(-26.704035876348012,-0.06373997126826225 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark21(267.1864198520637,100.2197828680762 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark21(26.75403177620919,56.459467642073 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark21(-26.82853755551324,20.28284122420158 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark21(2.7141165880915143,-27.20127340265563 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark21(27.349847545487478,-49.250239449181144 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark21(27.350517830347524,-63.563016749834105 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark21(27.395519845224186,-61.793030081036804 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark21(-27.57296800216313,-0.05696870669387734 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark21(-27.72247305585334,-13.486111565271727 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark21(-27.73644397927155,90.30504508690487 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark21(27.927692409485985,-16.279062099298653 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark21(2.793248689972378,-0.581770640746789 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark21(-27.958978467611495,-96.08730975828351 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark21(28.028893516707654,44.74924831282948 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark21(28.070183384183707,-45.84794869928057 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark21(-28.40033041538943,-1.0124770339380282 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark21(28.400674009879175,-2.1017198534602612 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark21(-28.46819578065984,81.08767716179241 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark21(28.557118347028563,76.20697812846836 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark21(28.56386222369639,25.008715430427486 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark21(28.797998478128562,-54.82023073183222 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark21(28.83016825398886,-27.376421889434454 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark21(-28.988956343582238,-0.05418602547044263 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark21(29.047364835770825,-26.682087589439433 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark21(29.131997874260833,-77.1494277059383 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark21(-2.9145597656387345E-13,5.937618568842353 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark21(2.9641410058460678,1.5369071935250602 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark21(29.679216004332886,-19.83497790941253 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark21(-29.78932407717869,-1.5312752187952867 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark21(-29.86711697235226,-0.05694000553681544 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark21(-29.971470336674074,-26.89049746624404 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark21(-30.027457655274937,26.933520493874894 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark21(-30.11719649140957,36.003037125193146 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark21(-3.015252526018757,15.399851654961656 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark21(-3.015252526018757,3.4190123769802696 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark21(-3.015252526018757,-36.69310160998516 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark21(-3.0152839098591153,-63.98413433136315 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark21(-3.016700588470071,5.019329860338307 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark21(-30.555700610857926,0.0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark21(30.595828035659423,-38.51085642866756 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark21(-30.61328038198438,-63.97818649161268 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark21(-30.82341585300145,100.0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark21(312.18967926934016,-72.6252889528962 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark21(31.415926535897928,-37.86504121513333 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark21(3.141592653589793,-0.551632589394847 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark21(-3.1423860580717413,-29.473155160376933 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark21(31.54226666346897,63.85637395183804 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark21(-31.594359083288694,-13.618516925975172 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark21(31.87073077393711,83.03294192510552 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark21(31.877660936113728,16.24906774665682 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark21(321.5344459859545,-96.91971817640898 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark21(-32.19779095514875,26.835728626679185 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark21(-325.6470459458229,214.20191052539886 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark21(3.2665913204596726,-0.4827426628333091 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark21(3.2665926535718346,6.997482319777484 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark21(3.26793278116083,-0.8303568069858898 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark21(3.26793278116083,-14.125837218975876 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark21(3.26793278116083,-2.832559284655123 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark21(3.26793278116083,-6.595801623287656 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark21(3.26793278116083,87.79938957607787 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark21(3.2702130654861836,95.41203171084567 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark21(-32.98671700490765,23.74243881268697 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark21(-3.2989375387385635,-100.0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark21(33.07266813144197,52.5481104117815 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark21(-33.083496231269976,-35.463886367569145 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark21(-33.11306299026386,-0.0474492093690129 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark21(-33.329550117821206,74.36628859853585 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark21(33.42589277232749,1.6120758850753987 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark21(-335.0250154025225,0.0017036623538865517 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark21(-33.704710715564445,97.95873333602549 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark21(33.74564917936041,-58.031354342157734 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark21(-33.82133414653529,-17.53477701792545 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark21(-3.3980948382323937,0.46225794204495685 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark21(-34.00728496052609,11.84199367697903 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark21(34.198387949731654,61.58519829197962 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark21(-34.35159328493866,-18.88813266949765 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark21(34.509714711947225,0.04551751122568248 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark21(34.51444888282077,-32.15280975026178 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark21(34.619446061488446,-42.3546769175811 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark21(-3.471837903378855,-0.4524394198472663 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark21(34.758117284260294,63.18027751717642 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark21(34.79528198546418,12.05343354968194 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark21(3.4810714145958954,11.312005661489142 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark21(35.32848808039583,13.3906004026029 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark21(35.343437566488745,73.38215486309764 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark21(-35.359944369654244,-15.95966783220807 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark21(-35.72153233836131,0.04397337471181273 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark21(3.5729095737428005,0.4407410472723732 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark21(-35.768283188286915,0.04391589941642171 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark21(35.78578941092855,76.30346611509694 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark21(35.82231708266619,83.23975125091144 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark21(35.86865788656089,-19.438705246521398 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark21(36.001975388711585,40.957381900832075 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark21(36.03548606278878,-0.04359026333305849 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark21(36.05532574305174,-0.048808004873838406 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark21(-36.163443560256184,52.47391977955138 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark21(36.32338731308724,-0.04324476441156122 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark21(-3.634654154140878E-13,87.61747105707856 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark21(-36.564303111991634,-3.7072946440764922 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark21(-3.669777320328876,18.275128505523103 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark21(36.70348255605998,56.72448772832968 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark21(3.67280782961312,14.746281817684292 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark21(36.93738204418095,-33.78353320314011 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark21(3.6942111087865185E-15,-99.99996734800649 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark21(3.7087814993862764,0.42353434060616124 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark21(-37.492565405112394,18.846439843211204 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark21(-37.64896279595349,-89.50768220859845 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark21(37.667071483621434,36.431962954275804 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark21(-37.81980179304805,-7.093491265369067 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark21(-37.974608762514485,32.019274134095724 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark21(-37.98891674433626,-76.18983216835915 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark21(38.09366729786771,63.42355989023295 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark21(38.184642205303184,-52.86838920587742 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark21(38.18509495724267,52.37586161191879 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark21(38.72091323440366,0.2460586727998546 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark21(38.78609634497601,-0.040498953873154164 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark21(-3.8883119279138305,2.8278529324327266 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark21(3.9093410046638866,-0.4059042461061608 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark21(39.14356804230138,0.04013520217801239 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark21(39.14356804230138,63.97166368785564 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark21(39.14356804230138,75.87744893478336 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark21(3.9269908169632526,-16.81189611063069 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark21(-3.926990816987245,-100.0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark21(-39.26994614789326,10.447625746062926 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark21(39.277720669872416,-92.52986673322418 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark21(-39.42030115162682,50.40742816133351 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark21(-39.47679654138825,-19.582552942936275 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark21(-39.52253832892685,92.48026533401952 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark21(39.65094938557448,68.4987597060175 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark21(39.66730672283367,-29.69824526071345 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark21(39.67986906577735,38.109627666119536 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark21(39.75856321592758,-68.80218371579386 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark21(39.80631693788655,56.90956873060699 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark21(3.991292195202277,46.696414186820014 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark21(40.11353728458293,62.57684382492975 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark21(-40.12223140241558,16.997670964285273 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark21(-40.319912455384575,0.03895832682010505 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark21(4.051246524155238,-1.1133707322810693 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark21(4.053697299840635,84.56583468481128 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark21(40.59193444448363,77.7160795994715 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark21(4.068138371593478E-5,-37.07717787972746 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark21(40.82954153698287,67.92766737971853 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark21(40.84269521877975,3.3126211637772833 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark21(40.96704462423835,31.214400442386086 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark21(41.03957468581879,0.038275160959154064 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark21(-41.10343750459698,-20.13133591801453 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark21(41.131446565992405,-36.24275226132993 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark21(41.1803093610701,-51.78057393244553 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark21(41.209776537178385,2.6943226967767373 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark21(-41.2299630191979,-31.157687848680112 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark21(41.422653803853024,-48.27878893305393 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark21(4.145402723674368,79.79672423339926 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark21(415.4718760134255,-53.573390864624514 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark21(-4.166769436046614,56.817002961460986 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark21(4.186051392646211,42.83777655067435 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark21(-41.92797060957303,187.3750653740854 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark21(41.92873952820846,-67.04288839281985 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark21(-4.194576312721351,98.39304794583268 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark21(4.201446302742411,-0.37387038024735375 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark21(42.135457457255995,-45.14203337464422 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark21(42.29817022013713,-88.2790613890195 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark21(42.329452573595454,-76.55337823558392 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark21(-42.38034575305532,-2.5830008825633826 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark21(42.409290036473834,-80.33922101953121 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark21(-42.59342351990004,8.494272420716015 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark21(-4.261049056150654,28.68562166279165 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark21(427.59085511426844,26.97230403007586 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark21(42.779092827339355,33.44852147409841 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark21(-42.84194993627496,54.74651056963472 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark21(4.302051585123385,-85.41683441723909 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark21(-43.1157485031741,52.371376829967915 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark21(43.16594030254316,-77.80967538964532 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark21(-43.171780093973,41.83901187890001 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark21(43.329194702710566,-36.440536480968355 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark21(436.1106570025647,-72.67765488745687 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark21(-43.690863715203506,-49.409499515453156 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark21(438.58709407318366,-38.57198586105666 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark21(-43.87107617957475,41.899867689012275 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark21(43.901246485148334,-15.670008318671389 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark21(-44.102963740384915,-0.035616570714921636 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark21(44.108637277828144,0.044252426362471516 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark21(44.16527225888737,58.70597695151548 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark21(-441.6900869143679,-40.37771373957116 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark21(-4.417887629392439,65.36892090534417 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark21(44.3013505827532,-94.21925704029839 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark21(-4.446273628255475,0.35679795584715635 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark21(44.49278234509842,75.08346515239657 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark21(-4.482785401408713,37.1650160406467 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark21(44.88426050241354,0.03499659589380144 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark21(-45.03707575394597,39.561122309378206 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark21(-45.048940280073126,85.11501823006577 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark21(45.27305095937706,0.0346960563405716 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark21(-45.28439164436289,-62.1211412741113 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark21(45.28892116771598,-50.98180868991203 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark21(-45.46377229882291,51.21217050564535 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark21(45.48426128506563,-13.622804866492501 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark21(-45.51271014317215,-79.22091658838062 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark21(45.51330488881692,-47.27501637628582 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark21(45.54245982223854,-54.87177283233889 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark21(-45.54433652400215,-40.77049729662343 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark21(-45.55307737793024,53.15964816149996 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark21(45.55310110644687,0.08892759232261938 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark21(45.553341435603514,0.03483293485493277 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark21(45.55504660205205,89.56182410872029 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark21(45.55504660205317,-0.052289659306396175 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark21(-45.626936642081695,-39.1634510844854 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark21(45.6720181885442,-21.271128036888754 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark21(-45.70023484495227,-16.96760747049967 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark21(-4.5844077090582225,-18.159861175973475 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark21(4.586048852813653,77.56659099430838 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark21(4.5874969152649685,41.67143861825529 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark21(-45.98829241311764,-70.58306789479099 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark21(46.12353751168726,-22.378079862967226 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark21(-46.18584282124654,-99.40058559969331 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark21(-46.652932537862,3.272719552153575 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark21(-46.6843186217645,42.073467644527156 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark21(-46.73378529947076,-0.6186695035071 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark21(-4.6993102863339615,-34.01194582585631 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark21(-4.699606090937585,-96.80814148843382 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark21(47.12282750950833,-51.11175716399716 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark21(-47.13850204759762,30.563351744124134 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark21(-4.725357956062311,0.0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark21(-4.726342769985961,-72.41346721219068 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark21(-47.339868194671666,81.05887148357547 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark21(-47.495535636019184,-33.43437179035981 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark21(-47.53670012006164,94.29258566828406 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark21(-47.78294783967331,100.0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark21(-47.90928796724247,2.585147085328334 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark21(-48.00883754272427,-0.03271889941923711 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark21(-4.8343195558666565,43.29636173025571 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark21(-4.837388932961179,38.63493204273251 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark21(-4.8382687205222545,-0.3731178870968159 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark21(-4.838729107955727,-57.76040499562634 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark21(48.405914328200694,9.118931755818672 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark21(-4.8461019803118255,86.22187262831685 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark21(-48.51942649667333,-92.91946335146122 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark21(-48.69468606080209,-20.72604658955865 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark21(-48.70701357307472,-170.18904928512598 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark21(-48.750526860943836,-2.0844551499902906 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark21(4.881525834103002,89.75582617747651 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark21(48.91252028763057,-70.57555541414659 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark21(-49.03989265451551,-25.061882791534615 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark21(49.16047436603544,36.375098914611414 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark21(-4.917402194051618,65.52868041368723 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark21(4.9222683565754295,-0.3191204162399117 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark21(4.963046585070328,0.31649840473392193 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark21(49.74726987273027,19.78431532366318 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark21(49.90030311631952,-17.339296899850325 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark21(50.07742221788328,77.6155701821053 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark21(-50.139142329865656,-0.03136744567346608 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark21(-5.023154304539368,-14.384712604553702 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark21(50.258847930294735,-143.73622682253585 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark21(50.28245315819979,-67.67829054741247 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark21(-50.28425246645185,-0.011351378782672755 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark21(50.32343559426531,-0.031214012084937792 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark21(-5.037507285582093,-75.27450302380173 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark21(-50.50111479832998,-82.9530034096723 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark21(-50.740052565375436,9.71368836854613 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark21(50.751342260139154,53.64692785282904 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark21(50.895288042695995,-44.401788277368006 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark21(50.898147148081705,33.2481104910882 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark21(-50.94608652021469,84.17634323106495 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark21(50.95517161214704,97.72989259915971 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark21(-50.98018962404784,84.73271274900863 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark21(-5.115785345850028,0.9211467373640736 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark21(51.68769470905431,-89.99935116054996 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark21(-51.76943250900577,4.41236702936672 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark21(-51.83821109623716,-95.57470354426157 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark21(-51.94093233638975,93.22428258461395 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark21(-52.020061122196836,44.77855998208349 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark21(52.0899678212744,-68.54334290266637 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark21(52.10999622795702,25.261977658671825 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark21(-52.155270817840524,-68.85034452565024 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark21(-52.303473424663174,-38.50983634056999 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark21(-52.58895334610605,74.15439611968961 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark21(-52.621676947629034,15.55739089360118 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark21(5.272687002130219,-47.357926156492304 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark21(52.76392816315564,-14.4271431458955 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark21(52.84405427299859,74.95042489146078 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark21(52.89851929758515,12.032760309781509 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark21(52.96370759004262,95.82040945276626 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark21(531.8351846213935,23.98658002804568 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark21(-5.327695645563439,70.17294722690313 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark21(-53.31593535156285,74.51845939215771 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark21(-53.356899395224815,-19.249277679883516 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark21(53.359505274973145,51.84585150673789 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark21(-53.41264348213615,-70.15499398646361 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark21(53.65519129872797,0.18498253528100417 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark21(53.74685757189951,-35.37629124619903 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark21(53.75521582756397,-34.53615508342102 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark21(54.15490688648937,84.77751763943101 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark21(54.22666752838302,40.17115866778124 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark21(-5.427320170230516,0.2894239288694962 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark21(54.31874143041631,8.97907149394905 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark21(54.359946608539104,79.80635946346337 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark21(5.46397085261728,-66.20882461659463 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark21(5.469411075044544,-78.58750965123575 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark21(-54.923626385937574,40.63904944848872 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark21(55.01150073923384,-96.65782650113847 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark21(-55.10421156539242,-14.663514545928308 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark21(-55.353027440363434,35.650194640709344 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark21(55.38960976386059,39.01672914490791 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark21(55.70260804973378,91.8502774796087 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark21(-56.14428592760214,-72.69897449265017 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark21(56.230110573374816,27.192430378700983 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark21(-56.2653626431499,38.00746946474348 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark21(-56.272597113795186,-0.0279140542175157 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark21(56.32310935739985,-62.281088071133105 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark21(-56.3754355560248,72.47698186544872 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark21(56.39651768711346,38.022442827305326 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark21(-56.57193204139419,-66.58807282064673 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark21(567.991372326809,-83.54898038741908 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark21(5.725272809741199,17.261458440642443 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark21(57.26619961793992,76.98895384188131 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark21(-57.73551870237306,60.47396432684897 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark21(5.819094890644198,-12.420319329320087 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark21(-58.47498761795811,3.38353993945033 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark21(-58.679390355911,-0.026769131670718933 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark21(-5.877490731862082,-33.74249081818803 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark21(-58.81201516615637,-23.15804680254807 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark21(58.90486225480862,30.26214391515813 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark21(-58.90695719058545,-173.89043551513527 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark21(-59.04737712322785,-62.28044465947138 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark21(590.7073373611677,44.44817049410506 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark21(59.10842592337855,0.04201128827370226 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark21(59.19805003364792,64.42595172496675 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark21(-59.40578687972806,43.735029901324395 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark21(59.555022383610186,-98.60625326078285 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark21(-59.58880633401505,-85.44486888732641 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark21(-59.607904292036665,99.38283569906588 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark21(59.66183902231305,69.69105433593455 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark21(-59.69251827595426,0.031210117647574975 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark21(-59.7202246837027,57.624878555997185 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark21(-598.0901537214073,152.02662379884885 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark21(-5.991497269327226,9.2483234072674 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark21(-60.09613332536483,5.359284316153577 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark21(60.332362251389185,-84.38661185746376 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark21(-60.42872636076571,75.87195156439586 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark21(-60.53421210987591,5.760696593785795 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark21(606.1985392036612,66.58829777159815 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark21(60.63655453165498,-10.785683966913666 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark21(60.77263104667344,-10.580927184283311 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark21(-609.9020241818105,70.67424558605151 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark21(61.12364493368048,2.311664757784172 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark21(61.49431189838438,-4.014509680270091 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark21(61.59304857763817,50.30861673891374 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark21(-61.74693402598657,8.394039575887213 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark21(-61.80158423886184,-0.02541676473411769 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark21(61.896823941273745,-81.77064965393883 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark21(-61.92011478082738,-0.025543370165692636 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark21(-6.195390606903885,96.94261802448841 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark21(-62.2068432388718,-38.92450794234716 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark21(62.56176206063975,-77.96892161082233 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark21(62.86448349524517,-99.47258850060605 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark21(-62.89435307179749,0.06355076997384401 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark21(-6.295736633193272,-85.19231668970161 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark21(63.053621147331924,-58.46089994628066 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark21(-63.072668040871854,-34.93504830304161 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark21(63.090425058017665,-29.506277349670285 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark21(-6.321835616517623,52.201762981395625 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark21(-63.59781441859177,4.797405408434537 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark21(6.376961397872002,-15.339370874525219 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark21(63.77509728229827,-0.024630245875467985 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark21(-64.01336921678896,-36.080145183956304 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark21(6.409525434750623,0.2544264177627369 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark21(6.409525434750623,-0.435341075856019 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark21(6.409525434750623,-25.811505576814156 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark21(6.409525434750624,-14.177977807930837 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark21(-64.15567093778351,26.022463595430395 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark21(6.42866920906339,95.29352771586494 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark21(64.30624309180969,20.872052786751837 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark21(64.40547375090982,-27.247435002278216 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark21(64.43671222879874,-45.782837696779936 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark21(-64.50366728286204,42.402992415649074 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark21(64.53146121639693,-78.42233503144777 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark21(-64.70027338737181,58.418811780300985 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark21(-65.09807283202325,-49.94809557398332 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark21(65.31732187371595,100.0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark21(6.533185307179928,43.769062458806964 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark21(65.96698361259166,3.9589443670987663 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark21(-65.97344572922889,-0.1559550479096049 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark21(-6.612086718702283,65.02711000217425 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark21(66.24963644004403,23.556761041850024 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark21(-66.27313959143743,-5.71305855198127 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark21(66.29171009489497,-82.15949680074337 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark21(-66.32440775047874,-78.77869028237832 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark21(-66.39526061192228,-76.62579433582482 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark21(66.68661610246428,24.832359893881403 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark21(-66.69551574078355,-2.4344247763826274 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark21(-66.75830072395146,57.094490879258785 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark21(-66.88204870232718,-40.378503023048665 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark21(-6.693275345335771,-18.378831820239125 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark21(-66.9950195392749,0.02344646419386509 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark21(-67.06505167202124,91.68963733812731 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark21(67.15788642730794,46.35538902087032 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark21(67.18197875917815,69.61189935085429 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark21(67.27358914365112,10.623966073306022 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark21(-673.7022457726013,24.045812321353637 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark21(-67.50008988001062,-20.448734402838056 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark21(-67.50824100258275,-66.78308245907841 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark21(-67.54424204725082,-37.82473796917621 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark21(67.57549820965099,-80.11377791641974 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark21(-67.68710598019976,62.87110513135261 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark21(67.72587790762081,33.359878173969236 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark21(-6.789783758554961,-27.304256889986405 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark21(-67.90911000590975,-43.63129347897547 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark21(68.01502485593082,38.96100029245111 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark21(68.12045815457553,-97.54683163328635 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark21(-68.25866714181096,-78.94075086204255 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark21(-68.72926138309032,38.830374508886266 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark21(-68.8017847996975,-94.47848875529796 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark21(-68.95617544406068,73.65821650598582 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark21(69.15689363518132,38.010930320613255 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark21(69.43757199524677,-82.58496625577885 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark21(69.45711652079663,100.0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark21(-70.02133360443068,81.07729774084137 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark21(70.04300284926396,-70.56804202366646 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark21(-70.16421325013079,-93.20888555418048 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark21(70.31051588594522,-58.95294930440534 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark21(-7.031061410985593,10.25548674854545 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark21(-70.68583470575867,22.81432598102051 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark21(-70.69543510208646,88.6934950327144 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark21(-70.77658780566964,96.27535379343547 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark21(70.7889183464674,-24.53008960617231 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark21(70.78954992965355,-1.3200132866940635 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark21(-70.81083470496957,-0.022183925854594833 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark21(-70.81217483334139,-0.040839718639335144 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark21(-71.40331971859055,20.206193974044837 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark21(72.13190543895246,88.97725869288577 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark21(72.1377823340451,50.65643731972722 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark21(72.13952450820922,6.858942394111369 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark21(72.20382139066653,-58.368746457548845 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark21(72.2566310325652,2.2994985773279986 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark21(7.229145916638217,-0.21728657090454284 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark21(72.34162826408544,-94.31366317726066 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark21(72.38297116013628,-0.02170549271221618 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark21(-72.48272270844072,99.76892419001115 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark21(72.60993974041907,54.63593894775414 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark21(-72.62310633830067,-30.00508310580605 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark21(72.87434488154801,77.65402031777495 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark21(-72.90214935113819,9.96567242040809 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark21(73.06453779176817,-46.99007866466718 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark21(73.37999046175935,11.168820676377035 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark21(-734.1168706227481,92.84401188264212 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark21(-7.377601279275325,-48.07174698524217 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark21(73.77872078899355,-55.497025997401586 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark21(73.796050369373,100.0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark21(-73.8079868579796,-35.782812629304544 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark21(73.83096226654763,24.107170375681534 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark21(73.88823620870187,-39.93226944736126 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark21(7.405643676391924,-66.80773493319865 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark21(74.12123107343186,-60.554853753275054 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark21(-74.24719481942407,-65.09824275460251 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark21(74.34731564762744,151.75587319325842 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark21(74.3482581077541,73.06355836526711 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark21(-7.447839276330015,-19.993165689042613 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark21(-74.55769535395993,-0.021068198518463532 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark21(-7.464746134040382,-78.77191314114404 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark21(-74.72394940230367,84.53680588017437 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark21(74.74231368697939,2.0608638331425837 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark21(-74.81673743203899,1.7416455099514936 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark21(74.91521096861561,100.0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark21(74.97760640980633,-0.22750126856016806 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark21(75.39822368615502,4.4748548443183225 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark21(75.5229932335712,-33.63304456666237 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark21(75.96901771222487,25.020674198458764 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark21(75.97655997594026,-5.408257603116098 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark21(-76.18780582853748,67.17843476563226 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark21(-76.27687477086661,44.179527570576255 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark21(76.66618996440889,64.27830876467772 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark21(-76.73945886499548,59.714027726642 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark21(76.80099589107624,-7.009813763423705 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark21(-76.81809738209095,84.66706681106871 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark21(-76.87917694774761,-1.3343010165602838 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark21(76.92080215809008,-0.8865323696443284 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark21(76.95418600321301,3.469875680066849 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark21(77.00027001298132,1.5971101808280554 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark21(-77.01095067093723,96.62758743611117 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark21(-77.02750609840851,14.87252324875277 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark21(77.04760572455332,-121.37308015470751 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark21(7.7276415064034465,-19.73770506255562 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark21(7.7276415064034465,9.330291502756925 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark21(-77.3142115288173,-30.582517636212714 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark21(-7.7365636003904825,-71.73640810175024 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark21(-77.38063277091065,-31.131893805957517 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark21(-77.39592692417986,-43.46902177517303 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark21(77.43583637147938,14.820726168519414 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark21(77.44252958460157,-100.0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark21(78.03030974387354,-27.335670608699886 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark21(-7.815970093361102E-14,-0.5808850866996238 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark21(-78.31557323230749,21.462784716586114 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark21(-78.38548622515243,73.70246455718339 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark21(78.61012701696488,-0.019982111547230286 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark21(78.66615646731587,-4.836942515259689 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark21(-79.06220721176238,-101.10999246098478 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark21(-7.918314898035412,69.4339721416277 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark21(-79.50748865938849,65.54661403223122 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark21(-79.57191328303287,-85.7800764093588 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark21(-7.958512423587354,12.855926336950112 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark21(-79.59857918391711,-12.100177950362493 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark21(-79.61146499399798,19.916615586278084 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark21(79.95307066510443,-34.08635544071541 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark21(79.98185787028606,110.65746117034084 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark21(-80.06100660880958,-50.67686710617203 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark21(-80.12395204558479,86.0123129496549 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark21(-80.16447503295257,7.097267358553609 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark21(8.024288232200291,-0.19575522231262 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark21(80.34861635375644,28.186037226547427 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark21(80.86323447702713,9.593421273095771 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark21(-8.103981633974664,-68.66934794130684 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark21(81.28835492764469,-0.01932375588354418 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark21(81.71716532786456,92.98666982345841 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark21(81.80640899333457,1.3273199185390703 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark21(-82.1677899520094,-64.4377691125826 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark21(-82.34406536867607,-1.7122988638743877 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark21(8.278980880005887,48.08688851207354 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark21(-828.8940406219017,-123.88604742270537 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark21(-82.95747310846946,8.067977288585666 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark21(83.07830710933388,-28.95660346649369 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark21(-83.25218731569342,-15.048190443382175 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark21(83.3059013549776,-286.19276978351064 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark21(83.4033634425271,-92.15426508486087 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark21(-83.507277206306,-0.927202936208916 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark21(837.4983384304536,114.3829746847221 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark21(-83.76794276908853,0.0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark21(-83.81941408146488,-93.64701760511313 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark21(84.17317303731923,18.924876216987627 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark21(-84.24245499887243,-16.15752729924384 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark21(84.45084677107454,91.01504322249164 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark21(-84.66423823298261,43.00852203263824 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark21(84.74141579621318,25.776019260026587 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark21(84.7923875702908,-64.34023935537152 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark21(84.83865219155084,-0.03324200938546085 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark21(84.93412063831354,83.48305195088861 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark21(-85.43806855899302,53.869279614568846 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark21(85.7061504417358,121.0177840116312 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark21(858.9583356047171,71.33097178476169 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark21(86.10869818509897,-64.16162243969099 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark21(-861.6876811217447,-81.04486055841139 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark21(-86.23742790179176,5.503660254895479 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark21(86.26745784614828,0.024491322168330498 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark21(86.26745784614828,-61.44229677270845 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark21(86.36285858105248,-19.59147564704675 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark21(-86.39379797360887,22.491405263323845 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark21(86.77835697771111,-76.29476523715854 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark21(-86.87829472040166,49.03135789931318 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark21(-869.40523909913,-129.06438823525156 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark21(-86.9526131251868,53.14280270283797 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark21(-872.3883990760878,17.230271702889482 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark21(87.31608456547252,-9.524156662522799 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark21(874.0442519664996,-15.891131945826821 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark21(-87.56538919386827,2.8471420206817015 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark21(87.58448102013682,18.39403171550726 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark21(-8.77406915935191,64.63141235826177 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark21(-87.83825417294318,-3.6273444582752123 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark21(-87.92557482962211,9.887699142362976 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark21(87.96459426400283,-89.83393531596593 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark21(-879.9019258024504,10.751061051673659 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark21(-8.801061968055706,-0.1784780441836311 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark21(-88.57011179061382,87.64552044383137 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark21(88.71887189262348,14.49028144158143 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark21(8.872592475681245,0.0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark21(88.7366968353397,66.11599229026638 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark21(-88.7729253721379,-71.37899208591338 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark21(-88.96044759444348,77.44616305407484 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark21(89.21651383343993,-12.116649905196923 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark21(89.40905049973807,-34.81659689855729 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark21(-89.53539061871255,-5.645975003640772 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark21(89.53597423394045,-92.29904008955769 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark21(-89.60285769681515,-32.37106012824921 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark21(-89.62379930532799,76.37119083840906 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark21(-89.66173075488014,73.63228185043009 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark21(89.6989645147236,57.32442867535673 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark21(8.969931572381654,54.95689637534588 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark21(89.75296448087335,-162.50455570046472 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark21(-90.13890552907193,-8.829547413998656 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark21(90.28958585642717,61.812658637917394 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark21(-90.29324795723383,0.006321484473239556 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark21(-90.35147005491383,-10.259941481829413 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark21(-90.40880795783656,-22.419042016649282 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark21(90.41635578835613,-34.42813018028616 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark21(-90.43196311011815,0.9458419906792699 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark21(-90.58453841693137,31.732271664475693 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark21(-90.73044266787345,13.4824051005167 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark21(90.82945987243848,-29.970342641678346 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark21(-90.97996782760339,85.2031220804449 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark21(91.04036169760144,71.66566214896059 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark21(-91.06036371008747,6.951772361834058 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark21(91.10618675243198,-63.636015384433236 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark21(91.10618695410398,97.15366044323598 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark21(91.23252708167504,14.285067482169506 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark21(91.37967171638715,63.83951931134389 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark21(9.150587410312387,-14.096127329280606 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark21(91.59326756619339,-91.96090333792205 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark21(-91.59936892704756,38.174448437929016 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark21(-91.76219575966876,65.96465548606196 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark21(91.89158511750145,-50.42762603065591 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark21(-92.00460689276518,-19.68655892084979 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark21(92.58666357944902,-10.830509553464253 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark21(92.61299898811023,1.041289010032287 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark21(92.63221385691102,-85.57812472198889 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark21(-92.66627201830886,-29.00335210005048 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark21(-92.77073011688188,-76.25006941449 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark21(92.77100855355752,-90.32877695944184 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark21(-9.28890086764004,-97.78341346707965 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark21(92.98297541616577,-63.812751530121695 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark21(-9.298437833198344,-0.1721169711239483 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark21(930.1968622868733,-20.496762198555928 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark21(-93.11734386638858,-15.019219357703207 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark21(93.3660222790709,95.98851370614287 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark21(93.38728442067952,-93.84810049872844 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark21(-93.63462972742231,23.458144774845977 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark21(-93.7883837434323,58.55566926519086 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark21(-9.385843846325116,-53.26347323805853 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark21(94.02917763121852,-10.255902702927116 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark21(-94.1876173746758,15.71764386358008 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark21(-9.424778080410913,-0.16666666456329327 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark21(94.28512603261353,12.892004386026244 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark21(94.29894545916906,51.25647788425583 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark21(-943.3834679435585,-65.9133048475486 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark21(-94.80097011913449,-96.9149483112462 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark21(-9.487277960769381,36.797803735708264 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark21(-9.48727796077168,-0.17322250178460563 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark21(-95.09731752821874,-42.577048661265685 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark21(95.31141598934528,28.763418413726413 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark21(95.39852419297853,93.6763506740203 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark21(-95.40693338151318,41.58980363170727 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark21(9.551118088340417,0.16526285028633936 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark21(9.568521185538074,19.296482291960864 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark21(-95.81857593448849,24.23516902250214 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark21(95.88551441674974,56.06295113249337 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark21(-9.59370872574257,-44.86254542906158 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark21(-96.16523896325918,5.728854426245206 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark21(96.39534775752787,-92.03774831883234 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark21(96.57450043381465,63.06337493543883 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark21(-97.20489106200723,-66.53056980634817 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark21(-97.53492309927043,-99.92524616772293 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark21(-97.77707681853937,-9.34684483434684 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark21(9.78035345489115,-100.0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark21(-97.86554818124753,-83.74013035115841 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark21(-98.02653255610052,-51.685366851842105 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark21(9.807125696850719,-31.09591774192178 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark21(9.819594191503484,-54.77475510994989 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark21(98.45426311607156,-6.928525200193093 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark21(98.54909889702273,75.06764017581054 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark21(98.78914658506451,34.490696246875615 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark21(-98.9566781120631,0.01587357575826598 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark21(-99.02972279299323,62.541554452166324 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark21(-99.21224119658754,-9.779845635185453 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark21(-9.940869146105214,-149.33855323092726 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark21(-99.42115636081668,94.311653246059 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark21(-99.60624043661235,3.1938138186685165 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark21(-99.69176162600242,-89.01718698009525 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark21(99.7439551590477,75.32405134081829 ) ;
  }
}
