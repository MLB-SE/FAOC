import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,1.3682030258886186 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,70.34022512230811 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.3587498141743737,2.9387358770557188E-39,-10.362023565088665,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.5071083645935524,-0.4681669872623512,35.750417735756095,-36.290053096745226 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(0.9201575487275181,-20.479189678617985,-19.641887658380263,0.08658995493851634 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(100.0,1.4693679385278594E-39,-100.0,-100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-1.6940658945086007E-21,17.213879908847257,-100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-1.8546030753437107E-68,99.92160749906716,-20.38212971574449 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-2.1661765349266285E-5,100.0,100.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(100.0,5.551115123125783E-17,-72.1220239305806,15.207381476392516 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-6.372367644529809E-58,100.0,-100.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-6.406665904585922E-145,100.0,-100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(1.0532485845851276,41.50173599858185,42.59202566822059,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(1.0560891191139496,-2.1684043449710089E-19,99.99999492238273,100.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(11.593591888726962,-2.6080480189901003,100.0,11.180690429499156 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(11.609929923186327,-2.967364920549937E-67,41.71543742547494,100.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(-13.124683373071846,-67.22745713702614,48.32826385778185,98.50885273287554 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(15.235205386522958,1.6704779438076223E-52,-100.0,-100.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(21.60329529903758,-6.938893903907228E-18,97.40224710671829,42.43552776983529 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(22.884549668098273,-1.6704779438076223E-52,74.11649715151258,-35.165896856121556 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(23.72685890791893,-8.552847072295026E-50,60.412499302416116,-95.63767042007328 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(24.03042008108673,3.0811813076970367,-34.90259765747024,24.085709231979948 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(25.029789478741545,3.469446951953614E-18,-0.2796429711444137,76.64780218659985 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(26.90200454369015,0.0,-28.715425650882786,22.30415587475838 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark62(27.306307317096696,-1.3684555315672042E-48,30.940494863924272,-100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark62(27.471921559905894,-8.468806377450619,-32.86836415284351,76.19139206904518 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark62(27.62553455168082,-5.551115123125783E-17,100.0,-100.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark62(28.955934578001177,33.117760350500106,-19.903008753561053,81.18687989049965 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark62(29.924921228623337,2.778448436856347E-163,-100.0,100.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark62(30.12045603930642,-3.606342024673495,58.14191313217208,75.36171375086658 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark62(30.63357907015503,-8.022649354901565E-5,100.0,100.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark62(32.55348329372296,-0.8558638640946583,50.742031931527606,23.392674583104878 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark62(33.980109604833125,-26.008264180120474,31.830503908947648,-1.6268264436284978 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark62(3.546117906578175,62.2228173923471,117.17265143992898,9.045309600367375 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark62(36.97949608907112,-35.14815730437417,94.01512445410977,-1.0521034081200336 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark62(37.96034863819046,2.4454581553010564,-29.90862290590566,2.6568304506019444 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark62(3.831964443883772,-6.044239020086309,69.48984934943144,-31.411041873795668 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark62(46.583543165622274,26.155542170452577,-1.296318440845127,87.32313767815819 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark62(-51.28731115715976,88.88913803638766,-48.257680420374214,32.54204523364322 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark62(52.716686622354814,77.41292863699854,-28.179262878964124,-28.52569150428441 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark62(5.5098544358226675,3.3409558876152446E-52,-100.0,53.8075453386137 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark62(60.52207603472462,-3.637301756173585,83.33638518941254,55.16746948599592 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark62(65.41028542775081,-8.21621789721932,86.31499589225142,-29.120928361719933 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark62(70.90890480465282,-25.914950508551968,-89.89405062787532,-11.308273031628161 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark62(71.62439044238198,-39.33901428045286,41.87821265669851,-8.533942104860484 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark62(73.30707813057862,67.18691618630115,20.143352047506482,-15.543667275187815 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark62(74.2819761296455,-54.36449796115546,87.86320173417818,-28.572127994195526 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark62(77.13846084905524,-0.5309655249333645,-14.766943482422604,55.6110805265256 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark62(80.28902377956317,6.077163357286271E-64,-10.957638473172928,-70.90698498025398 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark62(8.278785693622988,0.545043422334006,-28.963546057928014,6.031597393583681E-4 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark62(82.92010131393494,-28.44807667263187,-12.816218047963318,67.28824268926638 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark62(93.37881802872766,-30.851994582543355,67.86234398765643,9.768843829452308 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark62(9.8479238988415,-1.6410906865413892,11.560840988070709,-24.174318598769588 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark62(98.83422387680795,40.66488913272511,40.03619165098053,-21.36640118460565 ) ;
  }
}
