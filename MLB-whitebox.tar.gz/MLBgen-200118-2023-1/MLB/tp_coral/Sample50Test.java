import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(-0.0034558660758809466,1.6127840737745908E-5 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(0.015189133667056242,1.918389841371591E-5 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(-0.039052396429878886,3.109610235189393E-4 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(0.5551459739098021,46.0523062713788 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(0.5887377437537196,27.130322901729233 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(0.8699816055973129,45.944096576182176 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(0.8908071606444032,13.890807160644403 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(10.077433917285546,19.655104705172263 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(11.05039130891339,83.92380924852347 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(1.2575070376696893E-4,1.43283824451936E-5 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(15.822188260560523,47.775656333967305 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(2.297951112428273E-5,1.4428476765513642E-6 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark50(2.41095190868497,5.266538543278624 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark50(-2.4633224883931916E-37,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark50(2.52705752953414,5.246171131993771 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark50(3.261729469503094E-8,1.806025877334631E-4 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark50(3.4775139101276267,22.22267752459031 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark50(4.0448975690719456E-17,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark50(44.10046991581618,81.01450200361845 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark50(-4.525165253761708E-37,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark50(4.880917705177781,45.11908229482222 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark50(-49.325430168149985,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark50(50.62435787103777,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark50(-5.304703587056078E-9,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark50(5.759587726851549,7.161614655887377 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark50(64.43611753863007,98.2918671955683 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark50(75.21004264993928,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark50(8.187957072761214E-9,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark50(8.579011047542807E-5,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark50(92.13481402664638,71.50120255744724 ) ;
  }
}
