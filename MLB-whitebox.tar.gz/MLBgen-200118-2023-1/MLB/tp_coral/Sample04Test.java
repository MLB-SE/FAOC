import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(-10.25106053761742 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(-1.070661941329904 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(-14.37164478080956 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark04(-1.494140625 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark04(23.59625017267011 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark04(2.5844963340191214 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark04(27.923993372227457 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark04(-37.908811013832164 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark04(-40.08005323930348 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark04(-40.19140624999999 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark04(-40.19140625 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark04(-52.734409627391024 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark04(53.269977716712305 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark04(-58.2812054151757 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark04(65.92771273528876 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark04(-709.0945212091924 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark04(-709.1062484815851 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark04(-709.2626115025824 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark04(-709.3604672058149 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark04(-709.5295042296417 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark04(-709.7240941645052 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark04(-709.7397762954819 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark04(-709.8115045160669 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark04(-709.8415721475695 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark04(-709.9046951935358 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark04(-709.9903110747653 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark04(-709.9973817506833 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark04(-709.9995559474421 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark04(-711.7231094482418 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark04(-711.8928849307752 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark04(715.5236722859838 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark04(-717.6648974679815 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark04(-726.3325733254584 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark04(-728.198313587593 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark04(-734.2150602230815 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark04(-742.1079717227135 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark04(-742.6467885288544 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark04(-745.327215599547 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark04(-745.7216916971104 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark04(-745.9999999998233 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark04(-745.9999999999638 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark04(-746.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark04(-746.0000000000573 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark04(-746.0000000728998 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark04(-746.1914062500005 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark04(-747.1914062521716 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark04(-764.9538650789559 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark04(8.181854962956962 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark04(-95.91298581552292 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark04(-97.37280223408011 ) ;
  }
}
