import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(-0.16805746836251334 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(0.3620892720600545 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark17(-0.36208927206005465 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark17(-0.9997011722805305 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark17(-0.9997535999997429 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark17(0.9999714537355557 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999849 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark17(-0.999999999999993 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999974 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999984 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999991 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999996 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark17(0.9999999999999996 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999998 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark17(0.9999999999999998 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999999 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark17(0.9999999999999999 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark17(-1.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000002 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000004 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark17(1.0000000000000004 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000009 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000013 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark17(1.0000000000000018 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark17(1.000001028123558 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark17(-1.000002696678819 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000211610501821 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark17(1.0000250155668056 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000343309963742 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark17(1.0006721470423907 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark17(-1.0007258344376064 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark17(1.0026822763076637 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark17(1.0700762099119316 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark17(11.086843449258652 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark17(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark17(11.697827402843572 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark17(-12.069025175160533 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark17(-1.4094320944435574E-15 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark17(1629.4680649189477 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark17(-16.36569430158876 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark17(16.479567306145327 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark17(-16.937046234271705 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark17(-17.518444702290623 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark17(18.542005570976585 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark17(-20.5376268054154 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark17(20.72335060471879 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark17(-21.65238763352542 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark17(-2215.5835918976604 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark17(-25.626671072133718 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark17(26.157394077557996 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark17(26.409308067459165 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark17(-26.70803767308479 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark17(2723.8188967737774 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark17(29.277939319410535 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark17(29.77183322128772 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark17(30.066058594944053 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark17(31.147537889248014 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark17(32.135409883479184 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark17(-32.44233455816324 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark17(-33.3003936119794 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark17(35.56746676435006 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark17(-38.35873368353544 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark17(40.11488378689751 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark17(42.504097755575685 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark17(4.823261886840541 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark17(4.930380657631324E-32 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark17(-4.963410115564045 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark17(50.12724744577582 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark17(50.759528878760335 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark17(52.668374250301184 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark17(-5.298281646574637 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark17(-5.424370638905131 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark17(-54.59865909483328 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark17(54.999679182033844 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark17(-55.27493562819854 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark17(-55.75587234888471 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark17(-59.41147423153828 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark17(-59.86373246942609 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark17(-60.970218578831535 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark17(-61.84281394812538 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark17(64.54002363730135 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark17(-66.83142672124691 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark17(-6.7059078021696905 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark17(-67.80120567605732 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark17(-72.05824688343093 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark17(-72.67333389716745 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark17(74.91266420270887 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark17(-74.99871714105794 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark17(-77.71939618597719 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark17(77.73611571192777 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark17(-78.10835014204417 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark17(78.91161165009348 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark17(-81.41167850560329 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark17(-8.256523171501314 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark17(-89.59158963578768 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark17(-94.82764728339743 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark17(97.59346734547108 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark17(-977.0665555754931 ) ;
  }
}
