import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(-0.0015332465078095902,12.864061835557598,27.065157128293503 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-0.0022568755121302334,-77.41603642220406,8.990448142586096 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(-0.0036731909825939682,14.622552386703838,29.245104773407746 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark08(-0.0048395611758398965,-7.412174566749806,-14.838867817027126 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark08(-0.0049682041472209415,-18.650439851622732,-16.952406797512 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark08(0.005264145442283208,-12.229375740273625,-24.399881016993778 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark08(-0.005973713774677156,-100.08811890382387,1.6725267133298574 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark08(0.006468365655816777,-25.41677087729751,50.122139920305486 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark08(0.00648727028268319,-14.71520211376506,-29.41094241668206 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark08(0.010041328229962829,-52.34519580637463,2.9884905360373732 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark08(0.010450887825367003,-11.482953770174039,-1.0023250056059965 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark08(0.010484076037356821,2.423021192508086,4.969708251710167 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark08(0.0,-11.385422395855427,-22.640375565461195 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark08(0.0,13.621795693522975,28.814387713840844 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark08(-0.013656333210029962,8.139736871571746,60.679148294458315 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark08(0.0,-14.552793015509806,-27.729265182167474 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark08(0.0,14.685310289424843,30.61202923131713 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark08(0.0,17.39854958939449,34.98852486697032 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark08(0.02104481206798215,-27.16518185418386,2.747655046872396 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark08(-0.024931069013601537,-44.67176302323477,11.319529846101917 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark08(0.02838374561335317,-0.4297730050853797,-4.8944583639642945 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark08(0.0,36.09930115365259,73.24898945892338 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark08(-0.03945330332990338,-57.5640027215791,-14.355350501108425 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark08(0.04592632295153805,-32.79925677280284,-66.73902255018443 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark08(-0.05522853773693256,-12.231975847173388,1.505887980124156 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark08(-0.06558290997449498,-8.005156422944413,-2.9919847226439913 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark08(0.09932394131372746,33.73347631009007,55.6454577759342 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark08(-0.10573721129754178,2.977425277540983,50.70438518466436 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark08(-0.10742239551579084,0.11641642820813952,5.0539682649402436E-175 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark08(0.13505760632651054,-7.58031621990459,23.185155687050997 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark08(-0.13855491818669508,0.7023258852311233,1.007025382241602 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark08(-0.1472606719716414,-42.07195188885584,-83.01488946683172 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark08(0.17975051946723694,-45.70256069876122,-89.57883479491899 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark08(0.19190019629446745,1.3391143988500607,4.752454925826158 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark08(0.1986917752122821,28.191730130242576,-75.5468915297578 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark08(0.2032807847818684,0.0,1.8226242377680129 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark08(0.22712134682640253,-16.254100748974654,-31.15931814402911 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark08(-0.23578252900244578,-28.349102418191762,0.23500058450531475 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark08(0.2608072213733562,-28.90837985883684,-55.84037394237887 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark08(0.2912460307431206,-30.990631137201397,-60.36525616941051 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark08(-0.3037373767914886,-26.98368779292703,-52.80670122709123 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark08(-0.3522239646431269,-18.588063321621263,-36.66200221037761 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark08(-0.37070443507447237,14.152175353354089,28.76303372827965 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark08(-0.38218285479375214,-42.925690915704955,2.169009685137159 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark08(-0.4315981560578395,26.81577491422121,48.69255749012795 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark08(-0.4391275980524561,-2.54657164192823,-6.002476727740586 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark08(-0.4475752735915335,0.4913167200893399,-3.2975788820555607 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark08(0.4547439252438181,-98.41943727322007,-99.95468713901673 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark08(-0.46355108366753306,-4.457833221302697,-8.735523366813098 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark08(0.4785016070972008,-66.55448438371839,25.5906817077215 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark08(0.4805240862974011,0.3459581216685895,2.33584095381598 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark08(-0.5032770690164737,-14.048969434967884,-29.4968086544537 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark08(-0.5150273908627034,1.5110245833439406,2.146111946895874 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark08(0.5296761592705699,-0.2473927890468407,1.2385769182277582 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark08(-0.5444210917432599,-75.52231053599931,-33.482911910090564 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark08(-0.553647896570638,-5.386182764425993,0.13354469713081413 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark08(0.5933279132387994,25.228803325416518,52.23759039054948 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark08(0.6082172245312443,-4.708278949347284,-3.375077994860476E-14 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark08(-0.6243260921986575,-40.26663584579086,-38.19859376376528 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark08(-0.626987504571062,-22.000388899125465,-44.310943985169224 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark08(-0.6366734265897787,21.308559442519893,42.27789493206534 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark08(0.6884292025371358,16.905535717736836,35.974008562147354 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark08(0.6949007923256467,-7.268291220200884,0.31099249182110017 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark08(0.7401458370073982,-28.73959841914189,26.506326519222466 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark08(0.743404773766799,61.45620308134261,157.59231274502963 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark08(0.8478096987080888,-8.417520688695893E-4,2.5417455919864693 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark08(0.9070232735933117,4.490487416923481,13.272840981421528 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark08(-0.9315076345917817,50.67865333892222,100.0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark08(0.9549030056563007,-86.44651341462409,24.811815991413145 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark08(0.9574549660779008,-2.8472738375520974,-1.253057435323355 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark08(0.987197964673047,-45.01928953244737,-10.487462882882937 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark08(0.9965988753717596,24.988532360548064,68.28899443062818 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,0.001438434016618786,-10.920183398382392 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,0.007446082278132041,15.00556680150449 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark08(100.00018185467871,-131.5210773287182,57.580822698776664 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-100.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-16.763575997490122 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-54.71869206943755 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-55.22399679205728 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-68.56234109138566 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-99.8165325193119 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,119.45875752084513,-59.63954446561476 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark08(100.0,-132.1777462048248,80.75392514773108 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-140.54215632502272,-84.25916725474377 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-16.876746348892777,31.567135964303773 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,20.74289944655999,87.1110821874145 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,21.144648481061004,31.585166329312095 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,25.831110885907695,73.25506828162433 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-27.044010233933278,-90.09771602229554 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-29.796235259097585,-9.194590443266755E-7 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-29.80513441092547,-1.6437558095284076E-4 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,30.294717257789312,156.82410701450632 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,3.122311998433773,-9.898352621569636 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,36.636204093642164,63.27867560608196 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-54.469981503273246,-100.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,58.75977791476541,44.87993370655269 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-79.19449016186726,-55.17318781836718 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-79.86916738105242,100.0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,82.94019207616245,17.05980792383755 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-85.98516064434816,-1.8268225761559204E-4 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,87.4318519096448,-100.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-93.92333601068154,-27.62085831299859 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,99.55832942448447,-100.0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,99.91247373451665,-35.875573083963815 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark08(-100.12241653595576,-119.28105255367089,-168.1210188667637 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark08(10.025600350231334,33.62847330525334,98.90454398799557 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark08(1.0037426334875477,-31.258565296123933,-0.5036749896119652 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark08(-10.097891104244535,19.800105322839304,9.306537332945005 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark08(100.98194976284182,-140.60818610001948,22.245769202048294 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark08(10.121775767570046,29.061595871959163,90.05931537342336 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark08(-101.39278843212395,86.83865996244451,-130.4440379974873 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark08(-10.152184622485265,56.68515274752076,22.64989545442046 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark08(10.178021179024341,-50.84473652947408,-69.58461319508025 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark08(-10.214201771573613,64.53437456909987,-61.19947174546765 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark08(-10.241255060896906,13.47606817161152,-2.2008325126727857 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark08(-10.247218426354879,46.37759152199265,63.583296056803974 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark08(10.309307195912094,-0.0046908851884218585,32.48146378689799 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark08(-10.318865453417114,-4.277050181710044,-7.573825206420651 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark08(-103.38172447324676,12.945176335906808,-3.736097877549119E-4 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark08(-103.75281593147338,-139.7226444417197,-231.7482015180983 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark08(-1.0391398940892742,-67.37722182608209,-10.822143317206113 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark08(-10.458403394666776,-38.2461087316968,37.14583564948913 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark08(-10.478552982683578,27.784827654346923,25.151554172371664 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark08(-104.82997748468534,-105.3237253470998,91.01107134576262 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark08(-104.89996745943779,68.59925024874215,36.25588145922957 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark08(-10.570049340944527,82.1005915092544,131.2303353519105 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark08(-10.615669301256654,62.19538886754389,93.69687351071364 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark08(10.622413562776895,-0.0029479635534273504,31.91703521884451 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark08(1.0658141036401503E-14,-5.646858162311325,-9.722919997827734 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark08(-10.67339990085674,24.725939036852033,17.43167837113385 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark08(10.696546032700084,-1.5111383575476056,29.630260127642188 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark08(1.0705210708978958E-12,-5.7356834074033385,-11.235214050427146 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark08(-1.0709926865573642,1.6133476493205556,0.01371723896901944 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark08(-10.753755586232652,8.785334003567936,-14.690598751562083 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark08(-10.766158214833357,-3.3917488748706432,6.313891448965965 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark08(108.7120924476207,-110.70660810703491,211.06407678012556 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark08(-10.924134966387285,10.685809424522972,90.2011074225671 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark08(-109.39203220414775,-178.37933917255566,-169.17473965030493 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark08(1.0947683285448824,-1.0217228484046718E-61,35.033658236225556 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark08(11.05840559031627,1.3637646145520874,74.66253694768743 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark08(-11.093337286407559,-1.483202215505289,-29.430596111965134 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark08(-11.130671099445312,-100.0,-30.88849282212544 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark08(11.150711307654383,-18.286476225081195,-3.120818527199237 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark08(11.160837238086955,-38.82986884253974,-42.60642964402372 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark08(11.184794945909804,-21.86465356172374,-8.604125958923172 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark08(11.210747671792024,-18.490952746742533,-2.1525094697062945 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark08(-11.24252936602862,59.59219910512825,86.25453304924645 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark08(11.302667257208713,-15.345112861213032,4.788572375994967 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark08(11.31172745353731,-18.34614504804582,5.463621267713606 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark08(-113.28556064443636,-64.33648331180757,67.0994071624956 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark08(-113.40850078943112,7.356651287061993,-98.05686310694284 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark08(113.5385173943348,-127.01002460587081,130.93522382714337 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark08(11.407154250569455,-14.798140032285541,4.961782108510982 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark08(11.421729402593249,-15.862228903292086,4.111526727990467 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark08(11.44294398461668,-52.633000012521435,17.368248265724343 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark08(-114.61591188320111,250.6361706390092,158.68891155871023 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark08(-114.63822547776962,-78.38206665277316,267.34280098923864 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark08(-11.55612616550383,-8.933583790246214,-1.5086298188789549 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark08(11.719596031379908,20.285551612623337,-64.87083399862013 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark08(-1.1724544806391008,-14.584526769606143,5.262698526089491 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark08(-11.751862580712732,5.724993543876446,7.613361455914856 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark08(11.766999848796909,-44.307716998694076,-52.75068526561362 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark08(-117.92668026283344,-133.08769582790188,-217.57112840026204 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark08(-11.7928233935646,-34.30262400324243,41.05353068752952 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark08(-11.811708374017371,-60.79273306107276,7.595615900617787 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark08(-11.835253113499292,-16.39740146450904,-66.72976594272106 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark08(-118.70888184008756,5.89557228016544,1.2867711482417319 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark08(-118.72345207567298,79.00734123997672,-27.074754840170087 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark08(-119.06381865176454,77.98099175349634,-194.8462980658832 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark08(11.95921539521369,1.1965107926405412,39.841464097717044 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark08(-11.986020510058662,-2.3125839706108557,-39.10847110791416 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark08(-119.88177397028116,-21.88960338099124,100.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark08(-1.203849811361219E-15,-100.0,-79.44326515417555 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark08(12.039254707545883,-74.34754280583417,-34.14343509190469 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark08(-12.065132450139965,34.048862672088646,33.47312432055229 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark08(-12.075102104526103,62.91111841297415,91.16772683916489 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark08(120.96205129848447,-254.024192461975,113.33203705859447 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark08(-12.118817484897484,31.248261934336398,26.140071413980365 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark08(12.123729243175214,-32.28284671147493,-27.855369794776898 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark08(-1.2126484389233076,1.3176493813629282,0.5681497727508298 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark08(12.141988728293,-2.7755575615628914E-17,37.7460996473152 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark08(-121.42546982111612,82.49617556973723,-22.272728067689172 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark08(12.1530355748256,-21.952618971992322,-5.881883509261175 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark08(-12.173622811425716,-0.8720169609385335,13.021402865554371 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark08(-121.93635876667986,244.07320573640484,146.7875725857885 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark08(-12.228609565574102,37.85561426534267,40.596196160757934 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark08(12.228685171339517,-87.63989826827165,75.41121309693214 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark08(-12.229491967051473,20.157676538549467,91.79986668482705 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark08(1.2229818491806412,-3.684526004191544,-2.1293101340462854 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark08(12.257799385935385,16.548143007059505,71.44048049872006 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark08(1.2278701500417029,-76.44787962955438,-54.95567411406758 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark08(-12.303796607299686,-3.148778021880288,-42.590274661749994 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark08(-123.06822311584384,56.31043313115617,-29.964032234350377 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark08(12.328805152143893,0.6428893801647535,39.834685012704796 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark08(12.332220257399758,-16.575447204443563,4.2432269470438175 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark08(-12.34610709670054,-39.37851872978414,99.1046704548786 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark08(-123.4813729652656,-184.91007151291612,-198.34161758657126 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark08(12.373612319765575,22.931011146075786,84.5536555782432 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark08(-123.77117177940372,-217.58088223916678,186.3279571761448 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark08(-12.387456081582886,10.782543517986568,-15.334224699753916 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark08(1.2494271940907082,14.642398255762902,34.603874420592824 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark08(-124.99975275702008,45.75467625839527,-250.67042035349306 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark08(-12.515396719078772,-7.700907310828453,-65.58294892188242 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark08(12.523044855677686,-16.430098697082887,5.477850168200095 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark08(12.565406571113002,-16.275992894375033,6.711920064353901 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark08(-12.582681493456839,-12.587655553391935,-62.91925725367733 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark08(-12.659255857837712,4.747060025737616,-26.912851195243007 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark08(-12.669275690544046,-9.23218496709416,-54.901654952008826 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark08(-12.865559896394545,19.772597618647872,0.9536420561088343 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark08(-12.873411744601727,12.14390222963894,30.841152544838845 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark08(12.873564304023528,-79.621126017148,-127.87416311449921 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark08(-1.2919993978113404,1.1986263811776308,0.09205089571613663 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark08(-129.27923538599677,-97.37779411776957,-280.04152490370893 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark08(13.024610935667102,-8.925502682947606,22.558600600182636 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark08(13.063947051626073,-21.5039285395679,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark08(-13.074223807539754,-0.954556298733791,-41.02536921106267 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark08(13.092674625091476,-75.72633103781729,-24.589762776458926 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark08(13.10669903840752,-54.62940167517666,-68.36790990833586 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark08(1.3115942291789489,-45.94063702048904,-49.12904837673032 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark08(13.117760834990966,-14.878260077547623,11.167558676672545 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark08(13.130805937188065,-22.76041946995481,-6.121042177897104 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark08(-131.63212531433643,-79.07510757960922,-345.51010603979284 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark08(-13.194906493836166,11.139362762122811,-16.46591981818347 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark08(1.326058239938827,-48.565808023511316,-93.15328520734015 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark08(13.270125364695147,-19.45243236577085,1.0407143474859073 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark08(13.289118011352222,0.2900552165926636,41.97603385976117 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark08(-13.376139417167733,4.713173345557111,-30.702071560388973 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark08(13.537466870861437,-6.402844227378602,60.24114077039183 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark08(13.563381213118689,-0.687670134940447,-44.29527101485344 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark08(13.588759031253113,-20.749604349160144,-8.718556804310923 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark08(-13.670203959929148,7.693443015678208,-24.13978942725554 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark08(1.3673604170132503,0.0,4.305880782821858 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark08(13.699790835997105,15.140804947817713,71.55546771923532 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark08(13.72603990911541,-7.032091782176549,60.09471817656472 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark08(-138.20546059305266,46.316789245024616,74.97779569303937 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark08(-138.26151603146857,30.48055035161968,-13.308460320534124 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark08(-13.838172039952624,-68.63349209950907,42.58223940843194 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark08(1.3844039196398938,-5.817511344327277,36.98404711457262 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark08(-13.848767613388759,11.789667013219848,-17.966968813726577 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark08(-13.853226191495606,1.868818394992567,-36.251245457706794 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark08(13.87341332866852,-56.08430358459124,-68.97757085638203 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark08(1.387359222535835,-80.69712272797607,89.65699658732692 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark08(-13.96885130669257,-79.41758944392973,39.51159017836164 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark08(13.992074323751243,-80.53958530538124,-18.571982718552633 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark08(14.044070711880144,-19.123465134446473,3.8852818667474875 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark08(-140.48268086893904,19.25846437307438,70.95899547294746 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark08(-1.4073269064030014,-3.463060843992705,-4.554390394907136 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark08(-14.078800937484118,20.917767135027837,0.001996892740578623 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark08(141.21944285627066,-132.02161306905128,174.57293761557338 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark08(-14.141316840799067,-12.121802495126515,-66.41874707635978 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark08(14.14784891873303,-29.411087263928106,-16.37862777165712 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark08(14.16415588043614,-44.30628323922372,-53.306760489210035 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark08(141.83354251320642,-337.4913690471187,-103.74598727998124 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark08(14.191418997943128,-33.89652334398901,-25.099195264643622 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark08(-141.97463155135233,-137.38359924159886,205.61418560567017 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark08(14.201845247894493,-9.63314613661196,23.339243470459557 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark08(-1.4210854715200278E-14,-101.12775117169232,-92.50988683842867 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark08(-1.4210854715202004E-14,31.235576778367005,63.916612043313165 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark08(-14.270546401848726,6.935148319751894E-7,-15.469935097153721 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark08(-142.85859927774393,73.17617053997807,-162.76679618799795 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark08(14.301515649697336,-74.39425228109269,-11.55880809015133 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark08(14.334996581896414,6.274565729584973,56.359458364963565 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark08(-143.56469763635928,99.30371177280077,-231.9966830420141 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark08(14.379457585404829,-19.4644067186576,5.125891306014841 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark08(-14.398987552426085,51.296432854875675,59.395906421441026 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark08(-144.0034729975475,100.0,-231.0493182410402 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark08(-144.0604671913919,-10.530498020605325,31.94237751391607 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark08(14.447452166766285,-1.3457951307172153,42.22156256565932 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark08(-144.4855329437608,126.02007499443648,-180.75097667514686 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark08(-144.5981511286873,-33.50283018653171,-60.6278992149128 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark08(-14.499769639496378,-36.296817173355464,99.08533258117654 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark08(-145.0003802276047,99.05296633748064,-236.62986296261266 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark08(-145.0862260847082,130.33810253224,-174.2075146715312 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark08(-145.57372105933197,100.0,-236.63127120565989 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark08(-14.591289386752173,17.862155086439188,-7.585785632876011 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark08(14.615182303969355,-69.81200806103753,-0.4519506680332454 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark08(-14.6218896244804,22.406103724834274,2.5173349030222503 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark08(14.650493874012707,-100.0,-77.94254468761011 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark08(-146.69190735445804,-109.82883306530331,-231.34455909050413 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark08(-14.670435849979867,11.2522454817473,-19.936020259650107 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark08(14.70186683975945,-4.343438861789769,35.418743419524574 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark08(-14.708926703871196,71.27799189240935,100.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark08(-14.71741809913447,-17.878149553806594,21.019872343058456 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark08(-14.720041708239465,-72.74312663740656,81.0075020818319 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark08(14.721861198204481,19.700028835247714,83.56564126510888 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark08(-14.724842309041431,90.79865010721063,144.83210530995333 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark08(14.733211689363785,-42.19029195958271,-38.610152524279215 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark08(-14.757404699352854,19.64309841870619,-3.4350594856213346 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark08(-14.802040241559036,-51.64844963222839,16.159542033468774 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark08(14.84008940778952,-70.01674795893727,-0.001511755036565787 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark08(-14.85200871198632,3.5174540576741373,-36.36270741251889 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark08(-148.58205612026333,141.51838749578638,-161.9331377553634 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark08(-148.96527679504888,17.88502189802695,-71.7699881105365 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark08(-14.900275614355799,34.03878101041098,23.47265916790397 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark08(14.90427340755495,-35.337061757500464,18.86199202315062 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark08(-14.912343432873554,19.376424102859943,39.43332873796793 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark08(1.4931605354182671E-5,-131.91845554754227,-243.50182929878792 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark08(149.3378407957921,-105.19125845682373,237.9117032742242 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark08(-149.4866264356978,142.88434313912097,-162.18770026492842 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark08(-149.56613521001373,126.09546207905422,-195.4924154530546 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark08(14.966440319241087,17.44883813227621,60.79155050647135 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark08(-14.987457881522602,-53.02255811608114,12.91456323128682 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark08(-149.87687154625894,136.99466687538455,-175.54022206632794 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark08(-14.998632789904242,21.357162560022054,99.25206720838214 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark08(-15.03415346211144,20.3756795896561,-4.351101207022107 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark08(-150.4498153699037,100.0,-249.8885995700876 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark08(150.49490529773382,-125.2347345933051,191.63478107505424 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark08(-150.66885795004967,144.2607347308179,-162.30502100021903 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark08(-150.70549767808697,100.0,-250.63189689233374 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark08(15.07277693526234,-20.848696581056355,5.091733970469204 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark08(151.18270695224356,-155.00957204239296,139.84097399868983 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark08(-15.118566473712644,20.151380620376763,-3.4821418535895066 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark08(1.5127912956380183,-1.8787284067531576,1.9367334379100356 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark08(151.51880556190622,-114.494236673985,225.583128927826 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark08(-15.23003188551386,16.73790819764603,-10.64348293445463 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark08(-15.265153708842652,1.0240201472080496E-11,-44.224664799736374 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark08(-152.7172307893614,133.20214892634135,-191.7411078100434 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark08(15.322447832713337,-71.28162084026161,-95.02510185558832 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark08(-15.333959770256957,0.8777740361963942,-44.246331238378076 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark08(-15.405293209016016,30.502965742403873,14.797732497330287 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark08(-154.32658523428074,-130.8875158460525,180.6689568168423 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark08(-15.46586976628122,-34.89206519422783,105.27031137465727 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark08(-154.80567245652492,-0.6568420066848972,-100.0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark08(-154.86623763631553,137.30356329726297,-188.50547547001162 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark08(-15.490676803851374,20.163479921498446,-4.672803117647069 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark08(-15.493157764126273,-0.0022555206075985847,-44.950355872303355 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark08(-155.93530162285984,-62.22709975289945,138.0594395672858 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark08(156.03989010794376,-100.0,269.4095091075923 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark08(-15.606647184223505,-13.234433141673748,147.99904950464563 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark08(-15.614914887824746,-6.422787751608282,22.03770263943303 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark08(-156.6374458063712,24.82724600228009,107.5297990210725 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark08(156.7328368090129,-100.84581028447955,269.5507320661427 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark08(-156.9776335955503,-221.00496731881944,162.5651694160311 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark08(-156.99422956942828,171.12095478428225,-154.51106946034815 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark08(15.730580832082635,-67.29782792892223,-85.83312250124301 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark08(-15.77719953986788,21.369102669846995,-4.2202364663941045 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark08(157.93984968286946,-157.02796942462018,161.06825933428897 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark08(-158.20054774781076,-60.59546540699074,-60.80695302619228 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark08(-158.24892027564223,168.9682541084532,-136.33489524589365 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark08(-158.4063209629356,-169.83073472671327,-122.45059598960664 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark08(-158.91391304180848,-11.881214720657765,16.190574649558023 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark08(15.898699169085033,-100.0,125.72636886150931 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark08(15.914508422990114,-41.630823893358674,2.3564130269105483 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark08(15.953463821066926,-21.856481503282414,4.332221355420594 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark08(-1.5976263060143274,-0.09088893892443989,-3.403860469096967 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark08(159.96456711616645,-184.68975620785346,111.50511744532734 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark08(1.6044522311200384,-15.914730890174267,-26.922913736093392 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark08(-1.6046407345836826,-86.30717064243132,-28.82140399184341 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark08(16.06127430694267,-24.87061007100877,14.616587815380601 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark08(-16.07227902456816,29.792471678652536,11.368106283600593 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark08(16.08007814249541,-71.87872808181967,-4.547473508864641E-13 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark08(16.092223928777205,-10.729433759649481,28.388600593827277 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark08(16.152658510044205,-30.809383908587375,-23.796144358778513 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark08(16.17896018715717,-46.3195576114967,-42.535458960108144 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark08(-162.07252378447336,99.53709262670039,-211.7176405587029 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark08(-162.16208295799098,186.6379245700777,-112.11998012547237 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark08(16.24933732593965,-21.051681446287258,6.64464908524444 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark08(-1.6266568822501855,19.731546386935296,34.583669867852485 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark08(-162.82054033171366,-123.76011784375102,169.51226547176793 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark08(162.898282611542,-143.94405758309475,200.89459424934043 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark08(-162.92937566012648,-192.46949023453652,181.87396632038264 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark08(16.29358242462905,-24.600743378711616,0.45317636740513245 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark08(-16.30537445388563,-9.271901510091341,-65.88913005504467 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark08(-163.6444029227434,93.25493107955452,-228.86129181365803 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark08(-16.39638801023011,18.23423564059327,-11.286878788199939 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark08(-16.447765400117852,18.20182378776002,-12.14504125885078 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark08(-165.12930996758226,-153.95929283147737,-130.99393931768478 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark08(16.52566899498858,-21.875606444954332,5.825794095057087 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark08(1.6543464790188303,-75.25895300364449,-0.012609448752898912 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark08(-165.4409497825195,122.38134072099044,-175.074050630775 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark08(-165.85982700622517,132.30939025925395,-187.95248466313316 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark08(-16.607906647494687,41.574253240778155,34.89558286586714 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark08(-16.632533161092624,-71.10112708785468,-91.19268559193722 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark08(-166.8024388209489,-168.92516747925384,142.7746718831091 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark08(16.694454537315494,-60.94884731320804,-71.81433101446956 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark08(-16.72239221193997,7.923269410638961,4.657530147708338 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark08(1.676458057443998,12.6556893360426,31.909769054293115 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark08(-1.6790813043890327,-1.2693324203932095,-0.1931804935361796 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark08(-16.798486178082868,-98.45475631684725,22.955065775957127 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark08(16.821325904528834,56.045077496996356,68.25729288112365 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark08(16.827688731169243,-24.483446854186155,1.7652101717906066 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark08(16.838242866926215,-35.98721020425767,17.578171010536554 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark08(16.850456852161788,-9.184209379279112,-50.33842628468206 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark08(16.862787657830847,6.710530170046548,64.3922530554263 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark08(16.92064616506286,-52.73829301987278,-54.714647544556975 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark08(-16.92862147803192,-51.53701988189844,59.94546406263838 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark08(-169.37367551211213,162.71764121467567,-181.81880077606976 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark08(-169.7423158467189,73.2946366178431,-84.98111140675444 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark08(-169.93092353110248,-137.54782150540808,-187.24093602415462 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark08(-17.04616675160102,45.037010516493496,40.50631710497882 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark08(17.065256947161714,-58.35829965251529,-65.51998225569544 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark08(-17.13557786788236,61.93601507437813,62.014492371345426 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark08(-171.56273992723985,191.31252871788507,-131.52608669409568 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark08(-171.8246549397485,-118.26589473857307,-223.41447867832878 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark08(-17.183439093655323,-84.98603523157638,-64.2996142601584 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark08(-17.187000765203987,54.40058397802729,58.60499271864974 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark08(171.88561446595736,-272.1840817071854,78.2648635361984 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark08(-172.11810811477545,189.45451941384368,-136.43854194618638 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark08(-17.24446988366755,57.74814379229879,65.33285010171792 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark08(-17.262421205374928,11.013282340534005,15.676094190883646 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark08(-17.28677758074311,-64.47695002194367,-3.568330306188018 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark08(-17.288556577337697,-3.7450075290092997,-58.998305227890654 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark08(-173.32239493197048,211.7441529260119,-94.91607972725495 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark08(-173.39316349328934,-72.58322402080606,46.11107721532221 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark08(-173.53687379180076,-132.55095889970596,-150.43546559010153 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark08(17.35643912612223,-12.309874549163412,29.018352163268496 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark08(1.740568551939986E-10,-47.74511588152825,-93.91943543580982 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark08(-17.442085762409892,13.304594217711141,0.006817092088674315 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark08(-174.87698152886847,-243.97424533583884,100.80229883599947 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark08(-175.1655098723199,143.57564349459363,-238.3046495831932 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark08(-175.42737592831773,100.0,-325.78320178029384 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark08(-17.552928493336367,70.8458675036307,-76.23725426164087 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark08(-175.55636673034437,-45.73734739087079,-32.64708558310245 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark08(-17.615788055708983,-18.259417696352376,-87.79540323303723 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark08(-17.65320496273606,0.25519504239370755,-0.8951652152796555 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark08(17.687590526828043,-0.01013582215645864,53.04249993617121 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark08(177.01692945452726,-195.53999349050855,141.5297379194226 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark08(1.7722122196851195,-83.24022711218365,27.765612146981578 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark08(-1.7763568394002505E-15,-100.0,-67.25554213198794 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark08(17.78172576881756,15.544470681856257,86.00501190968698 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark08(-17.78625154324484,-2.8968647665323752,-57.87232502996848 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark08(-17.81416134574116,10.11424669349939,-0.23204279781513354 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark08(178.23895419883323,-186.31262080155295,162.12051543467865 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark08(-17.838586808949316,19.3648805923619,-13.215202915332384 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark08(1.786649888179998,-2.449785430005828,0.6631355418258305 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark08(-17.876555674742104,3.392909576726285,-2.0759270739689994 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark08(17.914126079264577,8.167878561036675,64.90574233076991 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark08(-17.91976552458165,-64.07499561367527,26.599683690400365 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark08(17.923728295559652,-21.546208816505057,10.678767253668848 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark08(-1.794388414731987E-4,-45.224443342586845,-90.44888668517369 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark08(17.96227646410324,-75.93253612830617,-96.40744653750772 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark08(18.03858618052783,-52.31674659630332,-48.967098310027396 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark08(-18.074039957368335,22.064452493873386,-54.23034170440404 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark08(-18.074608544367194,-95.45102361840078,67.799290934574 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark08(1.8075290412420386,-19.18310438664967,-31.514505942487705 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark08(1.8105222217815862,-80.19175679815828,78.20833787141525 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark08(-18.14406675821161,23.58796480556188,-7.014694374145165 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark08(18.22610002050324,-87.31103340560513,43.64946049618385 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark08(-18.33877995363777,5.45520714342716,52.434225457381956 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark08(-183.5737281823033,-181.85399747622134,-134.67449583970506 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark08(-18.378137653363993,-47.017450462150464,-54.85034873961443 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark08(18.39006745806469,-24.15805711466299,6.854088144868084 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark08(18.404639556139827,-31.735928517288176,-40.49298606615313 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark08(-18.41039353297151,8.381914189518838,-46.60854873193212 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark08(-18.413229948476157,0.001559956041052515,-54.68617400379246 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark08(-18.44900920555258,-6.325132142465968,-71.55322550646953 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark08(-18.452729524948385,11.696076415413884,-30.395239417222513 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark08(18.456209677817096,-32.14866372184102,-8.65525491438298 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark08(-18.478776391018403,0.09891554593497606,-54.4352076009561 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark08(-18.507862635023876,20.400548452648348,-9.746667507098655 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark08(18.541584045084093,-100.0,-100.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark08(-18.622713830727363,22.960110236736607,-9.481615638237919 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark08(-18.716833605909432,4.650079772590341E-4,-55.11105640722075 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark08(1.8753563315045023,27.702858856613894,59.23057171571434 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark08(-187.92457365496705,184.36689853386125,-100.20344301790348 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark08(-188.60923030220948,-137.90387293926173,-205.64111106015315 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark08(18.876843746101134,-43.2972050148725,14.181311480306789 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark08(-1.8884093792904835,-20.573849484868582,-36.549096046130124 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark08(-1.8892266474695159,-76.92606071457718,28.985596201489617 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark08(-189.033742440762,-78.85899474117228,-233.60311101507415 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark08(-18.91120001253166,1.1025567272136836,-54.37596960252004 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark08(-18.962024937555743,24.75675568193372,-5.794730744377971 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark08(18.968414408225208,-22.624386537962902,11.65647014874982 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark08(-189.84270621660252,-121.67972652199389,-145.32736808686832 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark08(19.000028576713774,-8.478012641401772,41.61485677413267 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark08(1.9030088287478855,8.3776880597356,21.40579448046761 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark08(-1.905919267374982,-77.7148687093443,116.49727447484369 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark08(19.05942099302762,11.825834035354498,82.27754479140485 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark08(-190.64473559268512,191.67863131732577,-124.33479356073657 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark08(19.105402637488357,-45.5153077309499,-20.714961275044274 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark08(19.126132354012583,-58.23803064701511,-57.5580192955389 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark08(-19.146792379312057,0.8573144414906144,-100.0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark08(1.9152648947427071,-18.68720439873375,-25.01217792764666 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark08(19.19389624843969,-19.03273354010888,21.087017991896204 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark08(1.9264793884984441,-27.21314454926959,-47.111131057403924 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark08(19.26500994941682,2.41187862000159,82.03911147927096 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark08(-192.9373418365344,-114.89893044839036,-205.21277039855232 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark08(-19.29859683618869,-15.563681034620362,-87.65983561919289 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark08(-193.1467649536142,-93.36821932540383,-282.3649687485066 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark08(193.3493537583993,-180.94081324089112,219.16883471823198 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark08(-193.71759522627744,231.77393756715693,-117.28632358752913 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark08(-1.9372063819338026,-34.923445431777225,-74.08771368256096 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark08(-19.381903423734155,28.347986135108442,0.059999511873063564 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark08(-19.43250800662635,-78.21276373561135,25.141089359993444 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark08(-194.39813657851144,104.78273230906959,-221.73956986476364 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark08(-19.46873963280759,9.248709194199565,-0.779637224647812 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark08(19.52196634417904,-103.4601835498747,9.951852304615805 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark08(-19.552423208805337,69.84660026572496,82.6067272318288 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark08(-195.62714011501504,-96.48890364827352,-175.9919897561877 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark08(-19.577032980189045,24.401286890370045,-9.410874291088117 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark08(19.590534117162466,-13.096809078398014,33.47871164063519 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark08(-19.62554793852502,-80.79313364024718,19.80423870136289 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark08(-196.35124852174297,-18.93703773679162,-161.4149213982638 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark08(1.9674314769928996,-64.93702331428284,-3.023234794012577 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark08(-19.67588522190521,70.03351358461921,82.22685427157683 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark08(1.9740648885462981,0.009828712496549721,-15.052546868919713 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark08(-19.784801047776348,45.19390091864082,31.90787133056833 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark08(-1.9805168583213246,-29.58246998459819,-27.15737870108284 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark08(-19.816927569111684,-11.215177404058355,-42.88022960645995 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark08(-19.83764461351842,-27.60846252149247,-19.54676600571097 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark08(-19.854755206433165,25.80230426137879,-6.3888607697470245 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark08(19.86000129873828,15.40146947090198,91.95373916481368 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark08(-19.90212666035747,13.158107912392573,-33.390164156287256 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark08(19.91030078370218,-37.57485323897596,16.8437653389377 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark08(19.914611528459996,6.531954377020878,73.01360270053262 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark08(-199.6034532356908,176.95695718742093,-100.0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark08(-200.3617461116121,-126.46517757150248,240.79462288028822 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark08(-200.75495423933492,92.04541482756186,91.89204552174944 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark08(-200.8531791293911,194.66249406543574,-98.77549169627551 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark08(-201.51530170707238,91.34419127715842,-213.94215729251306 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark08(20.286742022427717,-27.212686537910987,6.925944515483272 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark08(-20.43999701887831,13.708113123983848,17.171326118739596 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark08(20.47884222376882,-31.81382157065793,29.493331037102738 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark08(-20.49785133465414,-89.50110207495806,-89.60834583951205 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark08(20.50364702441743,-25.627023157859373,3.5444876519187436 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark08(-20.50558385316922,-100.0,97.86736610375422 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark08(20.606307561009096,-27.65753793384899,8.07282551645739 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark08(-20.664150186075407,-15.658445513279101,-91.73854525798953 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark08(20.666470502355544,-3.116718349066968,100.0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark08(-20.70651212230338,15.513476182653434,-31.068535269444467 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark08(20.75709689738106,-74.00255144277776,52.65503093299344 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark08(20.79132210270673,-50.29344909704765,-0.35058920070703437 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark08(20.83984407340988,-0.15796612410508004,62.20359997201948 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark08(-20.863828132270953,45.707897355674746,28.82431031453664 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark08(20.894933005368113,-7.893396541860617,48.44550352886653 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark08(-20.899475273920622,47.602595015846276,65.41774743329114 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark08(20.925326661590105,-61.058811125641135,-10.157092330706945 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark08(-20.949352887748297,6.519198456792729,-48.23886542286454 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark08(-20.95047189405446,-48.681128095368955,66.56583873530309 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark08(21.026494010466955,-49.50501522347352,-42.64293739593099 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark08(21.104780409212058,-13.172713171348832,38.539711211733405 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark08(-2.117320499410539,-0.34264975634791994,24.857412519283855 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark08(-21.173489571560424,34.26266804641602,3.989601279339502E-7 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark08(-2.1191180944968977,-15.691932430852452,-46.42040793252506 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark08(21.2677662027917,-58.870738441053604,-53.9381782737321 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark08(-21.283144607436384,4.577371375488738,-53.123894744536784 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark08(-213.10841426923258,98.24795793575075,-165.85572755188312 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark08(-21.313412730723268,-47.619090741995244,67.35420133765267 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark08(-21.325221732787465,-38.79371196919736,21.799728850051196 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark08(21.35113621620867,-28.981484171537012,7.630347955328345 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark08(21.358057838262823,-59.00540539721696,24.55863201634235 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark08(-21.397548603332552,-0.12080273741803457,37.534913075125374 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark08(-21.405277191548848,3.1203327601725936,-38.08507105111868 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark08(-21.468823269474882,-70.63573278031544,-28.64083702130813 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark08(-21.495984346626177,28.619985791302344,-5.737944515546193 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark08(-215.15341356341742,266.7197040207407,-98.95962344118175 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark08(-21.522717908201013,35.45012070416356,6.332136139753729 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark08(-21.59749257308179,-59.67489398118102,100.0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark08(-216.24681918831945,229.84655393626906,-187.9695811977784 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark08(-21.649256294706426,-0.36029763547052196,-64.09756782826544 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark08(21.684786501180405,-26.63312580440923,13.358904221517642 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark08(-21.74616306765776,-4.688006851086907,25.916462009726267 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark08(-21.768940089900497,6.554755172201799,-7.283256899620888 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark08(-2179.5486955630295,-793.0129761096305,100.0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark08(217.99560158601753,-270.4159956892089,113.19381528818138 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark08(21.859896992178577,-35.32736072451946,-4.6926978408228734 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark08(2.187214234573159,22.800318146392733,53.552344993935186 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark08(-22.004108643261173,68.59545369514848,72.74937778730833 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark08(-22.061254295296557,6.853055320377421,-50.912653880775395 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark08(-22.09494650084968,27.49638143443596,-10.568320591481053 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark08(-22.126145450639125,-3.8162490690156514,26.5203358938631 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark08(22.136872211537952,-2.2116902286516256,63.4164915533619 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark08(22.240212034673085,-73.0365265118298,-71.7380595924698 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark08(-22.289259507784735,60.878728977794516,54.889679432234836 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark08(22.312694564933228,-23.320623829881313,20.700771545186274 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark08(-22.357976009296237,-6.671746946418442,84.1279384822517 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark08(-22.36683718154108,30.692887199486204,-4.147840331746736 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark08(22.368721472648303,-50.477796140682976,24.096713762573586 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark08(22.377107795844836,-6.985948545533205,70.64592106748577 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark08(-22.39095089192674,-72.29621170460028,-48.25530314180856 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark08(22.58725660183473,-21.256744314283093,26.819077503732903 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark08(-226.43749828903898,130.7837911747869,-229.12811457024054 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark08(22.701562014398938,-21.346892984124594,25.430483205651957 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark08(2.2716298290952693E-8,-16.655772669078114,-25.671250118315864 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark08(22.727642566476042,-61.252393572343664,9.835909200683005 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark08(-227.614727055924,92.6513210262646,68.87237332165233 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark08(22.779113067807735,-13.704420465956169,42.49929459830575 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark08(-22.867064165263074,21.088870868646534,5.442991353155332 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark08(-2.288266050888482,-21.129946792758254,7.423976026447463 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark08(-22.88865985468487,5.587684489474924,-55.649555332417 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark08(-22.894694422823996,21.04900300169037,-25.01528093829641 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark08(22.918417045438474,-82.57389466217951,-69.6997655366748 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark08(-2.299268790469034,51.251897586798975,96.66647497128872 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark08(23.01461981579708,10.865124325861602,91.78316251022497 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark08(-230.29870383546591,-99.27351878930648,147.72238506504252 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark08(-23.097086324961566,34.06891020342681,-10.971823878465244 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark08(-231.86429970792133,162.45474370124091,-112.59282264392931 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark08(23.232932018322284,-81.97606317237037,-93.61299457136954 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark08(-23.26810229986184,23.699228970834984,-20.852796891259455 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark08(23.27058371573166,-31.067895567688243,7.797837512510426 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark08(2.3293944630080503,-14.440110288385991,10.043224784509249 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark08(23.300334364956377,-49.201222146102495,-28.501441197335822 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark08(23.30071388079449,-33.631535846561874,4.209866276054609 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark08(-233.02892830900007,45.506774869162726,171.06877350991152 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark08(-23.398302513523024,-0.1460819879742605,31.279335529633176 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark08(-23.40579146552971,76.99771589462091,83.77805739265271 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark08(-2.340972004283658,-14.978435269929713,-11.737037751655919 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark08(-23.425396832089895,6.803352580227575,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark08(2.3468142032882167,-12.566265150526359,-18.092087691188066 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark08(-23.53121934247207,-59.99012525292473,24.221285041668725 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark08(23.54861704695308,-51.82355385538895,-31.4307795750758 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark08(2.35943774264245,33.518303033435934,75.68571562159411 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark08(-236.6104679345904,-422.00464238075574,-176.5830420475385 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark08(-236.7283923299356,96.18044116979146,86.7811939363201 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark08(-23.681633546575025,0.2315168714461242,25.020913001923798 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark08(23.682273900640467,-28.96492517283809,13.193072130835949 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark08(-23.715717271877647,43.695347792324924,17.80940074312133 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark08(23.71848062873338,-31.258139625081775,8.642904966249281 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark08(-23.881588271156446,79.57946940596277,62.332330767582874 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark08(-239.48875343486986,37.150496162597065,135.3443026679684 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark08(-24.01000906968066,24.982852233702264,-22.064036936742117 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark08(24.03151126134602,-36.51580283738256,-4.2308896179524616E-4 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark08(-24.113354636097323,3.3881317890172014E-20,-71.82134225756737 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark08(-24.15705572756675,31.598470393653773,-7.703430068597802 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark08(-2.422768408038027,-34.962485403806916,-77.1932760317279 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark08(-24.234875406258784,39.270938960703646,5.8410155578056635 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark08(2.437676367253059,21.97104738641764,52.56029625927937 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark08(-24.379049531904887,-0.6251271851515074,8.30351633315233 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark08(-24.37909705361274,-33.08251710884524,-38.35696180564887 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark08(24.409123184312907,-23.827080558539663,27.144004762654287 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark08(24.59402366583327,-8.027317542686461,59.29823223892174 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark08(-24.61866401918014,29.885361214387025,1.2190822123676242 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark08(-24.63926808290494,-0.384599308281503,-74.59265908862261 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark08(2.4685522577511607,-21.46060927229755,-15.623748024774837 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark08(24.69435052501763,-26.269846207121173,23.11415548760544 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark08(-24.709524580524473,30.849274554424056,-12.422990903330097 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark08(24.7201895120855,-59.57054834769229,-44.5843401399412 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark08(-247.84439157084793,69.03984114838727,174.4102136901699 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark08(-24.830458683023377,12.897001303762293,-9.555102356008474 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark08(-24.83702940709825,-13.393047350840838,-100.0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark08(-24.85314872472631,-41.50230506705701,-31.345735080934503 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark08(-2491.0775411921563,-525.3800278185626,-29.810860092393426 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark08(-2.494025585075058,12.888845083453123,19.666767868132297 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark08(-24.942338044637516,25.97816720272787,-48.00367146793904 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark08(24.959782498062857,-3.86689046517858,68.41518097427293 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark08(2.498947374517052,-23.1813510368916,-39.96614838650481 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark08(24.995462317122524,-87.77253508368982,-8.95016208603671E-5 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark08(25.010426160113987,-6.049412057548435,64.50325069203998 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark08(25.01651883367159,-14.544226728033998,45.961103044946775 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark08(-25.024829519331558,-20.715917631866642,47.3115434779931 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark08(-25.036654545320978,35.85246489182697,-10.000939396688693 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark08(25.06796631440817,-39.187116199120204,-1.604812383790071 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark08(25.112003204809714,-70.45071455986944,-65.56541941893043 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark08(-25.155572849255076,47.857768982284675,20.269482487094734 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark08(25.163183891452874,-100.0,-23.52811014583756 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark08(-25.17709492868943,0.9683913164614019,-95.28115997348083 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark08(-25.24333361097962,9.615071912317731,-56.499857008303344 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark08(25.249872887730543,-10.925987099450156,54.22068260450779 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark08(-2.528464738145047,-44.20257157190841,-7.941119526091285 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark08(25.309233237961312,-38.98208067768745,-0.46566531469618516 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark08(25.316549016410754,6.058965524566538,81.24796005906514 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark08(-25.322235809189173,-42.7290391701161,-73.38752608198945 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark08(-25.340653446651306,66.77447435974732,59.0977847063356 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark08(-25.351140097347326,50.036000788786346,68.2562265254507 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark08(25.47463121852816,-92.62437334439366,73.99963432949625 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark08(-255.48920052678247,100.0,-150.25373660131493 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark08(25.6419693399468,-17.70450409935889,42.00606019533264 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark08(-25.668342969000573,-8.054245432398649E-4,-75.97963169947005 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark08(-25.704401344771423,21.643621132062908,-32.25516544339356 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark08(-25.79489073628754,7.507267350883997E-4,-84.1891969328191 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark08(25.863328120934398,-2.048847477371567,75.06308573485495 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark08(25.892123863029205,13.757876293834702,106.76286403319304 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark08(25.944098974854054,-11.72909563505613,54.374105654449906 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark08(-25.948725798031692,-17.892220455032447,100.0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark08(-26.008454267574194,60.287497508700106,44.12042854147248 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark08(26.014477058959564,-88.02310292910278,60.302077270085825 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark08(26.04606851620833,-38.403604975270575,2.9017919248787303 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark08(-2.604816358147133E-4,-84.36505375844013,-8.562480760852504 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark08(2.6079921464548095,-20.904933395813988,-47.91352830106992 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark08(26.14507435797642,-35.293085811049124,9.201022024422299 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark08(26.197774629844922,48.017151942135015,86.54009739973912 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark08(-26.217260605385682,-8.12092252241505,-82.16849982335903 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark08(26.225579145887373,-38.678236896671756,1.4576380081420757 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark08(-26.234205367742046,33.9788653910517,-9.174088994327846 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark08(-26.23723124001904,-7.355515889498408,-93.34273820553491 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark08(-262.492530808071,114.04573123064931,119.45506765696629 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark08(-26.256358551276193,-77.47411099025852,-6.414704062065653 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark08(26.259028369158408,-33.07252620930911,13.232510270653384 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark08(2.627580343259183,37.804263247411626,85.06206385139569 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark08(26.29412998276659,-69.64885865139709,96.8828941478734 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark08(-26.318160775201093,-4.901183046426444,68.74992149960248 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark08(26.372822725243505,0.38150645103023884,81.9613058884332 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark08(-2.638236494850211,-71.42658613624197,18.87812589749327 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark08(-2.6429379727298206,12.448981087424091,17.049659981980177 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark08(-264.6360870273607,100.0,-172.10126804110104 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark08(26.63296805496101,-2.6519606700860763E-4,79.89837377274903 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark08(26.63867539230668,-56.968603335231926,-34.021180472038736 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark08(26.645163978867707,-35.73876104712087,9.85984994803364 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark08(26.795436823089773,-53.79429665592092,18.036144599998064 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark08(26.816677291114537,-32.034295811333195,17.83893218688046 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark08(-2.6844795684998495,38.25342762917993,70.02421287965521 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark08(-26.84765871645384,0.9753275335882035,-78.21818302926643 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark08(26.84821682610123,-7.934322604639807,64.67608811877406 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark08(-26.854168501133763,2.3877614924071615,-75.7186999691141 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark08(-268.7401449883568,167.91455705953868,-73.97985326919006 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark08(26.894069872276617,-60.139259027172585,-38.025512110720435 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark08(-26.981148917910314,0.0,1.8839476026106454 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark08(-2.699758053151536,-32.452129141189054,-71.43273611503783 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark08(-2.7001695228412395,4.069258566069979E-11,-8.011136304195215 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark08(-2.710505431213761E-20,-100.00354293661455,59.15502982962419 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark08(-2.712010040030674,6.938893903907228E-18,-0.6844738595168429 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark08(-27.12075494881095,1.7231663526555927,-76.34513581432678 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark08(27.12586368200998,-22.812247962224273,37.31879470877183 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark08(-27.137352846586623,1.5390816430280343,9.89058221347947 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark08(27.158592397096555,-34.477618496896866,12.520540197495947 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark08(-27.17694904341426,58.50600830011707,37.05167777552271 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark08(-27.18053269080037,22.02308534385471,0.4435254004885678 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark08(-27.199316378752343,28.099865821307247,-11.390430710668056 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark08(-27.296106262825855,68.31121214031803,56.374296901334695 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark08(-27.303720598548985,-5.245311786459098,-3.0859757338154705 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark08(-27.377198595215944,85.39495001514464,90.22910057143635 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark08(-27.389392935600412,-9.442139590076,-99.50932974789815 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark08(27.403801361334445,49.186859369368534,97.43664969220683 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark08(27.409015776430778,-0.18853744410834783,81.99524391680153 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark08(-27.463058590710368,57.610388395983904,34.255297979669464 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark08(-27.56142718647556,36.1157970002437,-8.881891232144381 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark08(27.587276435529454,-20.971091600025446,42.164208001224765 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark08(-27.703829521720415,-33.94860324420506,-25.08927103536611 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark08(-27.73857317145925,29.685919589440505,-24.01084723343732 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark08(-2.775405837039065,-7.36642481454099,-23.04930707451009 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark08(-27.855855888081052,19.77123610278947,0.030580878937256955 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark08(2.790507195154541,9.4680595673482,-10.680647557994666 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark08(27.91141357767051,-45.06670840384172,-6.399176074671914 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark08(-27.912621286165322,0.24035379628283382,-76.65425487232498 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark08(27.94528834424061,-69.01016023519286,-15.157965442376995 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark08(27.96624867570182,-48.520935456391555,-11.572328558882774 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark08(27.975246573563744,-8.91082017321891,97.52125956980552 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark08(-2.7980263899590247E-4,52.93505090924737,106.05343404025635 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark08(2.802682353033208,-3.503193267391457,2.079818395148431 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark08(28.035383719107614,20.017683502332765,169.4400066909887 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark08(28.035893015376363,26.92071705594428,175.7749638478861 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark08(28.04968248531383,-42.075189441629085,-0.0013314273166760843 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark08(28.15397696843702,-37.471664025946595,9.518602853417876 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark08(-28.16036322928335,37.99305979273849,-8.494970102373069 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark08(28.183978663878836,-14.946788460284983,50.323692783023475 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark08(28.190904460687193,-53.38818091935824,-22.203648456654875 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark08(-28.199835551864762,-35.772319501608436,-79.5873899851965 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark08(-28.214731483440247,52.487264631256146,20.371766201409606 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark08(-28.227734071442107,33.877623485657786,-15.569797382591148 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark08(-2.826008559241346,-37.760809378190594,-82.43148744881161 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark08(28.276471854766456,-83.50671570621093,32.190669495843245 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark08(28.304743050260008,-13.11850268087422,58.8780705937233 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark08(28.377824896411152,-100.0,87.72279764326272 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark08(28.389907418248754,-91.22693820900741,-1.569147462190747 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark08(-28.401650978403506,0.3446253949271598,-82.9676683591753 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark08(-28.406784100143284,-93.24822094710747,-26.358497900700023 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark08(-2.8421709430404007E-14,-10.786532752245378,-20.003042268949 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark08(-28.44006973975533,-88.72098493466135,-65.18119207751903 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark08(28.44589560892598,-57.09452804825256,28.648632439326565 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark08(2.8451311993408992E-160,-28.568902433301428,-56.560223907927984 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark08(-28.5071233836197,44.824645563126296,4.130805561569014 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark08(-2.859616850331609,-62.17806540123309,80.89701809790992 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark08(28.60719629939057,-132.08118171777014,30.35066713759985 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark08(-28.737928696699782,-53.24481585379693,53.641993076170905 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark08(2.875846428377456,24.121234677419576,4.185395141576009E-9 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark08(28.785497830336773,0.0,86.95709248408875 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark08(-28.8096490790006,-11.451833164614142,-21.238603252126143 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark08(-28.830576054736373,45.15941388078155,5.560473268246688 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark08(-28.86044751650675,-31.552493905329776,58.84214509504163 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark08(-2.8900426640612813,43.7943033529363,80.48370880791094 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark08(2.892902151951981,-10.735373477190699,-11.22124417173056 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark08(-29.028712510716254,66.62468518834571,46.16323284454268 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark08(-29.065970728780613,38.70160870188829,-39.52298251739135 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark08(-29.103013733955834,83.97290480132148,49.962690069269286 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark08(-29.14302044353861,40.92929441453369,-5.390463838284928 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark08(-2.9158475590304267,0.07677374183219642,-7.023198866631991 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark08(-29.212497173217812,-43.117220826650396,-16.590271163277052 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark08(29.218270936423608,-14.38151266119803,90.71218830869226 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark08(-29.264250575863358,-0.3452578698941725,19.75060855374126 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark08(-29.267027281519447,74.17109512158663,60.54110839861494 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark08(-29.26938266515733,38.960584047970514,-8.695072587991593 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark08(-29.27843622432111,43.90846142421031,0.0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark08(-29.286389602481506,-2.7168519105458375,1.954907100853712 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark08(29.323179673810266,-39.655516078559295,8.658506864312205 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark08(-29.350832908932805,-4.3765208749146165,-95.23474414983276 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark08(29.35385020594483,-39.1000998452754,9.865041233624128 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark08(-29.357341391048795,-35.99483031672942,60.85650951041279 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark08(-293.6037889326296,-112.6864665135376,144.94287036417853 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark08(29.408346506904625,0.7357658155771145,91.26736747866194 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark08(29.471594094833932,-60.79496660071153,-31.604354590126377 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark08(-29.48341685095015,-47.53197862574734,7.035978453139705 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark08(-29.520369373913184,35.763096567895516,0.05608311521301781 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark08(-2.956999772291264E-14,-31.495977726986887,-61.421159127178974 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark08(29.57346968425963,2.0194839173657902E-28,90.21985005212615 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark08(-2.9626259681199087,24.080569870926468,-86.43765950134687 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark08(-29.64988184164215,73.77429023408163,62.001027146342 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark08(-2.9674943482240583,19.643267661801204,31.954848605725125 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark08(-29.710495677131153,85.56492617668597,81.9983653219785 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark08(29.716790883039284,-15.857030122117393,57.74083122764651 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark08(-2.9785897413871303,0.19640515759618019,-0.8546857810042212 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark08(29.806744608861827,-28.84858557319091,51.124614575464854 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark08(29.834837415619116,-48.680930030594325,-7.8573478143313045 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark08(-2.9842794901924208E-12,-56.15836554178768,-112.79616346628936 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark08(-2.995005954294459,47.79484366120409,88.17546578631969 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark08(30.01053230879712,-2.8072001110444447,84.41719670430248 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark08(-3.0049534417281527,5.598261278038993,3.7524585414429783 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark08(-30.061319989992157,5.895134511854153E-4,-88.63762513376429 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark08(-30.11923880686328,-5.8069450462920855,-75.28822136120982 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark08(-30.199087742345075,19.47442581114599,-50.15241346917294 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark08(-3.029448094125228,-34.88524669738549,21.67212724091773 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark08(-30.322654338026453,-60.60033543647583,44.77860498426975 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark08(-30.347423946489034,1.1102230246251565E-16,-91.01514564737566 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark08(-30.383495072712932,27.205268932263532,-35.16915102681685 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark08(30.39379192125391,-32.395762539756014,0.253655280947239 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark08(-30.419774132430803,25.25321908623222,-8.210032802027541 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark08(-30.46461262670792,-8.175542453331657,-6.9129429794114055 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark08(30.483207654041564,-92.47136957309456,-91.92231985726954 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark08(3.0507415275565295,-4.862729915862939,0.9975610777386072 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark08(-30.514495790014735,-84.45425149058715,3.442625795140072 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark08(-30.51616830364137,-84.2512429125237,29.919810416656162 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark08(-30.528776448033575,47.54222317648354,3.602189865610304 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark08(-30.610472063470645,1.568605339169963,-25.780789558701628 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark08(30.865301066437596,-55.29859168179963,26.004086942156935 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark08(30.886502666725196,-11.29996581751286,70.05957636514988 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark08(-31.00291839565498,43.61454817883718,-5.779658829290559 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark08(-31.05971208392782,-52.934801754551344,-28.336958142776837 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark08(-31.077665295015766,100.0,150.88178269579194 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark08(-31.104639787898606,-155.4069139435501,-1.6211773872589996 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark08(-3.122424656179411,-3.5095729970516194,-15.428854380491076 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark08(-3.131621810657838,-13.067441066302012,15.362680827879228 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark08(31.321624256112017,-1.7035736143525781,-83.42047327075954 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark08(31.476699710853193,-78.23626586744199,46.27325576289638 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark08(3.1496229867763645,19.95253780789228,50.72790003802627 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark08(31.504824377423795,-42.64614444632883,10.792980566408602 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark08(-31.526614539823992,8.894502052135767E-17,-93.90862704328555 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark08(31.530984030015247,-44.84937091092188,11.747590554111735 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark08(31.560236056043557,-42.27780627282194,10.476311340810259 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark08(-31.572307030211277,16.642921825665404,14.855924594954317 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark08(-31.61554260173314,1.1440820866205315E-23,-93.27626073654379 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark08(-3.1703550199533583,36.54507695967651,64.06866007758022 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark08(-31.749800810748546,35.38196520004435,-23.24365538236332 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark08(31.768380305242694,-45.07277905616449,6.730379130050571 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark08(-31.771312806728293,-28.09346760521079,-44.07934739073282 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark08(31.87976702421658,-65.71073799732793,-35.770427694929595 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark08(-31.885029785613927,51.95219592628865,5.316665483891811 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark08(31.916018451584918,-41.991081265377595,11.76589282399957 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark08(-3.195988672634699,-9.928169397710462E-14,-2.807937884554827 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark08(-319.69589956209217,165.14973516710447,100.4247722196304 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark08(-31.97244119245855,53.475922409285815,11.034521241195982 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark08(-32.02466631807187,42.200116130245114,-10.175449812173245 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark08(32.0839456840377,-10.180668806602355,83.46037268737484 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark08(-32.102401388856485,4.61133760451316,-85.51373263074825 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark08(32.1489331310228,-66.48005935622068,-34.94252299257807 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark08(32.151052976844255,1.772914960140918,100.0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark08(32.16939198247127,-23.875558967919574,-65.06996521409897 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark08(32.19084462389939,-100.7353054100324,-103.33118367290734 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark08(-32.205218101945164,-19.511659547160026,-34.65464738578591 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark08(32.20718914097673,-47.8264893735687,2.53938500258768 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark08(-32.25487273987436,-5.041233139220012E-4,-96.60236565409366 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark08(32.258664586666995,-3.7191171240196543,90.4125852287298 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark08(-3.226211397292019,-5.681549161512165,-0.9033503335561655 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark08(-32.30165152736481,-40.925879208777886,10.482858570194537 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark08(-32.35746714240122,-57.77874383201376,89.61386110416966 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark08(32.38643408384803,-44.89044639730644,8.949205783726086 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark08(32.40532309947091,-9.693447382197052,78.10411715094452 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark08(-32.44662795794471,0.2937699247952024,-96.7344296392118 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark08(-32.501661264935464,1.532310745775702E-4,-95.93418760928476 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark08(-32.511853216284585,8.881784197001252E-16,-2.845657636900883 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark08(-32.535834826045274,-3.4347026144122466,-65.51552687756052 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark08(-32.56976245941551,-1.5333665388995903,-99.98860549202003 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark08(-32.58141786969947,42.94577720764904,-10.364359337949564 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark08(-32.6508637546423,67.77644585752954,39.17109677792706 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark08(-32.65185145328173,-20.869559821864087,-44.11796098613778 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark08(-32.76922952722112,-25.353138866434534,-21.943428189940338 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark08(3.2779275069467184,-15.07452584738548,-27.02765815431553 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark08(32.791173233658505,-61.02510379666007,-61.62579983035189 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark08(32.80973455773504,-2.68212707775144E-29,100.0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark08(-32.829074249832395,0.01657510070845299,-84.06921685862216 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark08(-3.283933033216471E-4,48.89433666316178,97.82886753955614 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark08(32.84518391759098,-99.91466474977757,0.0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark08(3.2858356168607807,-3.9673910818240894,1.9832455972845382 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark08(32.87822907646731,-57.74708646729945,28.688094736954632 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark08(32.903947418210514,-64.19464859711474,-29.100811078811617 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark08(-32.91267308035371,34.218640531056366,-17.650571284994115 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark08(-32.913087301364826,-7.105427357601002E-15,-16.368368978098225 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark08(32.967840237715144,-64.03903892872646,-29.174557144307464 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark08(33.004840626973134,9.848868211458665,28.518628302958632 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark08(-33.03316433993558,35.92614500997808,-58.88596405489118 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark08(-33.03832096703527,14.172511367163377,17.69543591977187 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark08(-3.3113099832394046,-5.283677015222418,-0.8337010068106826 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark08(33.17063175227369,0.07580012421075821,100.0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark08(33.28478375054849,-1.3697015761765422E-18,-42.138765384690245 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark08(-33.291342981681225,2.8808016560684213,0.5656695519089183 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark08(-33.31099568687047,-7.327238959190112,-81.88470870250346 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark08(-33.34359732339682,-23.843108331102258,-21.369319844351296 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark08(33.36120658962351,-28.26669879566328,43.601823159349934 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark08(-33.458607161364554,-63.89573253690944,-19.864438616802744 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark08(33.49114194849175,-58.8586309479085,-15.673039723546893 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark08(33.57796136865272,5.572988699969401,100.0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark08(-3.3679285260331757,74.84158093200028,137.6369473288972 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark08(33.694829802242026,-5.179616593582907,92.29605254635516 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark08(33.733115050690195,-28.652165449221204,37.1819130754223 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark08(-33.75207324404248,-53.76884122806611,14.060159407629143 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark08(33.75212730359881,6.586410881205899,100.0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark08(33.834382456595144,-73.26269454493512,37.85751576154508 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark08(-33.841459221653885,53.56819214299607,7.182802947825369 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark08(-33.890589255009075,0.23824856853609747,-100.0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark08(33.94951146856825,-0.30682369097806017,100.12959140840559 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark08(-3.3958169485744065,-19.212096205392044,-40.00365348613697 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark08(-33.96136248415944,57.17999225117982,14.041649981469652 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark08(-3.3968533313608464,4.967649658155673,6.966921549755202E-14 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark08(-34.01756845944702,1.1001044501689279E-5,-6.617901760900194 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark08(-34.0368326256784,51.251744208277614,51.91144005104701 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark08(34.039787560292226,-12.43294040177971,77.43115697423524 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark08(34.11820616473174,-46.533338337503665,10.844335845977035 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark08(-34.133982773866,32.610253249724515,-37.18144182214897 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark08(34.14377321217372,-43.41569559233548,17.12590401415804 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark08(-34.253499891552,21.19409011482081,-58.80152311821978 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark08(-34.300952456720836,76.0447917603753,49.255265773881085 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark08(-34.3197503503607,40.36822483205706,-22.163281607123135 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark08(-343.41450769659247,100.0,-100.0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark08(34.453768487467194,-21.959471774818994,-16.737003340209426 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark08(-34.46977564454913,89.49307848120209,75.5768300287568 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark08(34.501500882304086,-58.41639710226236,2.7986746231821864E-4 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark08(3.4565638628325983,-33.37615272977661,31.913007124744468 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark08(34.586661671752225,-35.57843856485522,32.60310788554625 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark08(34.71068820316069,-99.99999995600182,-82.5545487212666 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark08(34.72076830207542,-66.72607592677741,-2.586310033009891 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark08(-34.79010798337843,-42.789916505231034,69.24240179477896 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark08(3.480815097236046,7.858758880321394,-6.217248937900877E-15 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark08(-34.82227261311162,78.49370584807987,54.09139018361976 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark08(-34.82801921166134,-52.963716503145086,-2.8004113487628928 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark08(34.883619456564034,-2.9048361860420324,100.0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark08(-3.491278424021249E-6,-45.49713779731803,-89.63742790783446 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark08(35.00401706287691,-52.06096470186391,0.8901217849029189 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark08(-35.011087059266494,47.18702861326115,-17.37454514060448 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark08(35.08994381326834,-38.65484119101971,29.530945384560482 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark08(-35.092737722854025,24.63132385955043,-55.948885437835486 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark08(35.14384130806977,-98.33883450775409,-89.67534876450398 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark08(35.27904784120892,-42.77736894821964,20.400141257325856 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark08(35.310908513248876,34.92548193894868,-34.31163667867973 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark08(-35.34688445466873,4.998037805976955,-94.4737814252574 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark08(35.36060518832878,-53.04325134020137,-8.374715280807119E-4 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark08(-35.416044057268635,1.6178079939201524,30.368958982219425 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark08(-3.5444997109866993E-12,-17.08909693234963,-34.17819386469634 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark08(-35.46797578215781,-42.38521371866639,-32.572643376720436 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark08(-35.488632335336355,-48.46240595822089,4.589012716929027 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark08(35.54881014916032,-90.92355141061756,-75.2006104141084 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark08(-3.5639633976655176,15.094952095195737,20.011747981037175 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark08(-35.65950281250053,78.47145965788613,51.535207205065575 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark08(-35.715645920086985,14.877481911856492,-28.721369643717168 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark08(-35.739217584133414,-97.99016111931606,-13.96439806623299 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark08(3.5793649437123114,-17.664695651782935,-23.62054571495446 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark08(35.826432962990935,-3.7396494447649546,99.99999999996062 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark08(36.0033616949664,-52.210486184263836,-8.356397417377702E-4 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark08(-36.08729669637781,33.35302942852218,2.7342672678556412 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark08(36.30275778071895,-157.07459064067262,-185.50966487727382 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark08(-36.33008218386851,64.4889544095617,21.558458594312754 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark08(36.35066026122474,-15.527056566067785,4.371637533581998 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark08(-36.430694601655865,53.90773192140051,0.0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark08(-36.56661651496687,-14.073600373339673,88.50477053977755 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark08(36.58621759809553,-44.779371002425506,20.79983045264537 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark08(-36.63614663531131,96.91280805197506,84.53161018152406 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark08(36.69481253443532,-284.60574383876536,-62.83404682142491 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark08(3.670812716390974,14.501832734181466,41.51768672763491 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark08(-36.89581066533068,-59.637729901831584,-59.550854204848925 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark08(37.03477975846495,-61.8903048073021,-12.256718412297404 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark08(-37.19932818835317,29.49291449887899,-0.1475681098168949 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark08(37.22027215078396,-25.591099270307595,60.4790638572544 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark08(-37.2984747079785,-92.73747391862399,41.98524823912393 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark08(-37.2998959608545,-16.78453892735879,-24.816027113207596 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark08(37.32766885159249,-16.633580018395243,-2.9656097534541606 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark08(-3.7351357288179217,-18.3953743870809,21.581262747384763 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark08(-37.35421680339526,-14.930552039735744,22.873421840488476 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark08(-37.36341237963081,-19.13902711166446,64.46505131113554 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark08(37.39647446972673,-49.91317649120717,12.535738762765053 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark08(-37.40269814265249,0.0012962674354114155,7.540274651731089 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark08(-37.449509324644076,18.91841451402616,-43.09277183726533 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark08(-37.49245730103422,-5.551115123125783E-17,-68.47325874765097 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark08(37.500115467742816,-57.70200909462551,35.93417236763675 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark08(-37.52012061474422,-0.1603577308356754,-111.39922022758194 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark08(37.690023545356325,-25.140410482756362,62.96993349322103 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark08(3.7728580003660284,14.903710367957343,42.69679106380764 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark08(-37.73027544773151,2.8061949506508483,-37.49746386148947 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark08(37.9063875422211,-43.11616859946882,71.48694076700465 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark08(-37.941882194897666,4.20787625079135E-14,-62.380332840453136 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark08(-38.04960913453641,0.0011475328214875535,-35.9753113474558 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark08(38.1134127325739,-44.67512431493061,-5.770368839297888 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark08(-38.17286037629434,106.24806065047841,100.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark08(38.189711905954496,-31.099927781380476,44.757053333904715 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark08(38.19254891368282,-51.526026353012924,11.762681112535205 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark08(-38.24871781060635,73.53122813874214,33.832503207823535 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark08(-38.28184906697671,-276.882635556088,-77.48470962255277 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark08(-38.342524620777624,-2.2719563952380777,38.61093605759525 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark08(38.36111636136704,-40.559431883942395,33.96448531621633 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark08(38.37344045454253,-44.83727229967247,62.63682286712838 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark08(-38.421258323703974,-57.0274222421425,79.65251686672957 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark08(-38.42420193844778,-120.26375934977652,35.25000455628255 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark08(38.451308093092344,-26.375330117694865,50.06674849429825 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark08(38.625104511580275,-100.0,61.367378315133664 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark08(-38.6677393167054,16.6565830525754,0.002438850506605978 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark08(-38.747324227809635,-0.1632348585681146,-2.5485552521582755 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark08(-3.875946020096403,-13.434999792730872,-37.09612929818142 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark08(-38.79374543569458,-8.12178154640273,43.632909210868405 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark08(38.847821427122575,-56.064498106962134,10.567070829585834 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark08(-38.88996962971341,-0.9716742774459196,-127.05369238837737 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark08(-38.9276658123894,-1.8087879383629435,37.991670957646605 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark08(-38.957655989603275,49.16702992816106,25.818631469933663 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark08(38.99620861125331,-466.0204926960194,-185.92447736052046 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark08(39.029693362869,-27.720358815076214,63.21862292000968 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark08(39.04772418968043,-73.63366103154719,-30.12414949405308 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark08(39.04953837747235,-33.881331099967205,50.74878710835712 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark08(-39.05485799493174,41.95963434765341,-19.38492910888832 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark08(39.09566099081622,-52.12372197419254,14.042787153691656 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark08(-39.12273447296582,12.956166305598241,-89.88507448090627 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark08(-39.25441236350978,20.399777093123205,17.2844648467096 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark08(39.33600059465827,-84.19372069766871,-49.37948893757587 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark08(-39.45668797081876,-62.26177767286838,-64.04999173051212 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark08(-39.482153219814364,13.876685486921687,63.1229097522361 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark08(-39.63362128628331,47.38148454296263,-24.137894772924664 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark08(-39.65972907132429,-82.0875773195171,4.824948649036708E-4 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark08(39.72501110467343,-20.63741565569401,44.534104311992294 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark08(39.835879291209125,-51.20301803099188,17.257570937988405 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark08(39.869585057091804,-63.06742671201698,-22.878491106685317 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark08(3.996630707990685E-4,-14.526574154914172,-28.970000638548747 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark08(4.010645560656433,-8.489383061525558,-3.3760331142869213 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark08(-40.14457129534239,5.93809354428229,32.60670033662668 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark08(-40.14813361497695,0.001588978848708399,-24.622740977487876 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark08(40.28737890775355,-40.104818623775245,42.22329580250503 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark08(4.035265199130268,-45.21215000928363,-78.31793103401361 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark08(-40.36696974654732,53.779784183517776,-13.412814436970464 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark08(-40.407333802443716,58.425385138446764,-2.8004348036427262 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark08(-4.041958816843614,6.403440267740046,0.7973403602536945 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark08(-4.045636242817711,-18.669764036335607,-10.597080468668729 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark08(-40.47489772855175,-85.35512696052447,72.18827453846316 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark08(40.48979751144317,-78.51130508695958,-21.877052900067874 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark08(-40.491049306854094,99.09198831841721,115.52045162821904 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark08(-40.54045084084703,-8.025180734376753E-8,-7.15428240613126 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark08(40.57143570924279,-91.46916595510962,-61.22402478249085 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark08(40.5815403109036,-48.7684866743829,-45.44918106612936 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark08(-40.612139850822594,-47.182468142205195,-216.19294382691874 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark08(40.65451322552542,-6.9946121349612245,100.0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark08(4.066487387400092,36.36673466431123,129.18022770050456 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark08(40.66605375359816,-77.12208750746501,18.809601162580194 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark08(40.68171248708848,-62.67465682815894,0.0015388359316534101 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark08(-40.7566265320346,31.070267433922453,-40.18560448333823 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark08(40.83443657738978,-58.40431761076225,-14.50788610127828 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark08(40.976813375763506,-52.30948639393782,19.882263666209774 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark08(-40.98636873063213,-4.128868808232281,94.97783293218646 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark08(41.16556028583171,-93.90980283114621,-62.75212847800239 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark08(-41.18199912391884,51.324473554730986,-38.98742150123445 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark08(4.1192328584731355,-6.415660019140738,-19.323177384400907 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark08(-41.229800033854566,6.53947308273753,-9.910890320905708 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark08(41.2754263892651,-90.72460977835061,-57.362366269094366 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark08(-41.29628834910895,52.73936125112019,-16.839346218291574 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark08(-41.2974990331306,21.58108104116377,8.082709686159017 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark08(-41.330127792334515,17.754446678394647,0.0021406515859676307 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark08(41.34292311387993,-55.96464158423018,23.97123383699457 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark08(-41.46389337664031,61.466661317454964,30.381806363893766 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark08(41.466456735481955,-73.60940828201593,-15.275569678201764 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark08(41.56328244364316,-55.34488246586296,14.45062250840817 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark08(-41.566765758619184,42.4704680879712,-39.75936109991515 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark08(-41.59828506324373,14.755840030905121,-0.9686597287047221 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark08(-41.61052019540013,-73.46920900908461,74.84181121038199 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark08(-41.63178784989203,54.11236153982539,-16.67064047002529 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark08(41.66760341294081,-11.105182466958867,102.79948712438885 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark08(41.699285309878704,-71.10425578577274,-17.110655641909354 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark08(41.79769297276593,-40.02012811843696,45.38127488707188 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark08(-41.823732986614914,50.2794687524425,-24.912261454959744 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark08(-41.8335220236822,44.30293856809941,-35.60283452205495 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark08(-41.970899576015526,30.641364497194218,-64.06868860742385 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark08(-42.02023425623115,29.142148299910257,0.3117153414893416 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark08(42.02257091981252,-71.00945183054706,23.18880319409938 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark08(42.02850877965432,26.25519574099893,18.370040383332054 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark08(-42.07897833364187,10.097292707109332,-57.74318201279802 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark08(-42.12775662495069,29.92169407194312,90.7615719022357 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark08(42.18845728211299,-38.97382624107604,48.61771936418694 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark08(42.357533558694456,-65.69763521254924,-4.322669749015101 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark08(-42.39649172577098,24.23985477390329,22.29822960584785 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark08(-42.41444681628593,55.34696910946332,13.069494304011585 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark08(-4.2483208085199635,-3.3868948270967007E-4,-5.273278071454044 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark08(42.49450687277147,75.30140719630452,51.836206273731904 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark08(-42.65815214887006,60.61814632241826,-5.173099588664759 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark08(-42.7277280531501,41.04343748703978,-45.661622694511536 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark08(-43.03544849478436,68.40673361551461,7.3253629657580825 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark08(-4.308834169219703,5.811775434452266,0.06282766041735158 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark08(-4.31109166804873,32.40287754600087,45.16008688528928 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark08(43.12509514067809,-36.439692307257495,57.6626951096186 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark08(43.228548744341985,-57.5387055545455,14.60823512393497 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark08(43.23863652534848,63.93110543242844,56.78806470637639 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark08(43.3452457546855,-68.0836280320382,26.309178604147593 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark08(-43.396134268397255,-94.998586591494,93.96747268104372 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark08(-43.523440075971436,-54.73410640250677,9.047566839862681E-6 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark08(-43.55884083954869,64.59707727971944,-19.40750204081579 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark08(-43.63161094048978,47.17328607267721,1.1717075085788542 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark08(-43.64134079286655,67.09609895148101,2.68062397062063 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark08(43.68750811205202,-31.722340685815293,69.1884066512289 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark08(-43.77028732219794,0.003170581026125774,-11.318832242372386 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark08(-43.80608371573511,31.132948191818926,-69.15235476356747 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark08(-43.82987147686623,-9.02047856640226,64.19990263826588 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark08(-43.87257052749172,71.4177931355081,-17.986737536378186 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark08(-4.390846071013135,-1.658317362607829E-10,-6.825605625298557 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark08(-43.92960241765451,31.3924787134538,-71.66237489133248 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark08(-44.01381204985735,10.852420619858922,34.70844122413915 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark08(-4.402677944740746,-100.0,-100.0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark08(-4.416017059714595,0.739104499441281,-11.523179058063556 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark08(-44.21202020764567,-38.00836699208929,74.29090535561276 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark08(4.430977322166058,17.359704274822278,48.01234051614276 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark08(-444.3041706794342,-734.7240415211899,-797.4548097245134 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark08(-44.45726353032216,-88.2734079570873,30.39456155529382 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark08(-44.46681682182337,22.006012520128202,-88.96555857896395 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark08(-44.474453273204716,77.58822313356282,4.011845892856812 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark08(44.51792071923552,61.34584407015501,36.63160825537625 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark08(-44.52534658177066,66.34936842982877,-5.317111592508363E-4 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark08(-44.59028538170657,79.91915393754175,55.679556773267194 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark08(-44.60576620677756,-30.951147253887925,80.75579218990441 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark08(44.63602618145575,-81.32926673598868,-15.692674696415068 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark08(44.643746028048085,-20.035268760736965,93.86070056267032 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark08(44.64378837605895,-139.35925427192848,-81.07320407395713 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark08(44.763441844324056,-19.101234568925126,129.0745748272581 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark08(4.483318712539333E-4,-24.252532519528465,-47.53309821800802 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark08(-44.98009583611778,-5.979817545793522,49.38911705511641 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark08(45.01695083999476,71.31437827022674,-77.03190557120698 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark08(-45.03495290605164,-69.36611123118047,-53.67503963612838 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark08(4.5104721835130395,-17.641069815125647,-21.75072307971217 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark08(-45.117997262467725,41.062010711546066,4.055986550921642 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark08(-45.19383573971694,-0.012077082945974508,2.877919389340259 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark08(45.32205765938551,-67.67296750449364,0.620237969175434 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark08(-45.35792089056522,79.75756249972699,25.012158654553218 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark08(-4.537950951672337,-19.914723457995546,-52.26599560185545 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark08(45.388164500910015,-43.48688330698564,50.719066475928656 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark08(-45.40333072733489,7.29050134492315E-4,21.171990555356132 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark08(-45.405971778370066,-19.958265538952062,32.006636936489684 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark08(-45.449089891033864,25.031090973939513,-86.28508772522257 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark08(-45.469336652211545,14.191696612788895,2.1385363417124103E-4 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark08(45.472585750314906,-280.0818870730341,92.70125555523626 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark08(-45.50525816872825,65.10034112307389,-13.033132979019197 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark08(-45.51577486239693,19.13593177290069,121.71527822238596 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark08(-45.570003683365925,-0.7646807605210739,66.00388599007755 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark08(-45.66122087038107,59.14263215854601,-18.194178133066377 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark08(-45.758428857650514,-20.40304569873078,-26.895689684860805 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark08(-45.78717094627699,83.9302064346311,31.906261290777536 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark08(45.90957528035428,-54.05715043931335,29.61442496243616 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark08(46.062070363410136,-100.0,-42.418173734678476 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark08(46.064442886930436,-56.4739483954666,25.245431869858127 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark08(46.08156133161675,-169.88348415113137,107.87593469901083 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark08(-46.20020428298184,87.30780550442407,76.11597987568175 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark08(-46.200467685017415,67.92016449851502,-1.1991995222255165 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark08(46.218949959776005,-84.66516284155725,-30.626675714842275 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark08(-46.2630573585974,-36.30910273453169,9.929565951580827 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark08(-4.6295433229263585,-9.058007959986536,-31.865542194472486 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark08(-4.633740483222038E-4,-41.0056411533608,82.66935765414543 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark08(-46.352051520142425,-44.91115882486639,-64.43399015310554 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark08(-46.36702516328724,45.659213653511564,-46.24462274832101 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark08(-46.43632710723726,-75.41821138644923,57.000584125475406 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark08(46.44855114178063,-21.225602205319078,96.89444901470384 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark08(-46.45434860645567,68.76028041911572,-0.39439393870774564 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark08(-46.69852310608783,56.47681748374981,-25.571138023968984 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark08(-46.72986802123023,60.10089159488626,11.432105747466764 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark08(-46.864467957426726,66.52009576300017,-7.553212346279821 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark08(-46.895395883001996,68.77927943684784,-3.1276287753103036 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark08(-47.04784729483156,3.317579934053699,-133.76927894766894 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark08(-47.16398647103988,-14.284764772693215,43.56681148559986 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark08(47.177192663964654,-42.01992464245985,57.49172870697427 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark08(-47.21325096561155,29.32051495055503,-81.42792666892969 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark08(-47.21889885144738,-1.4578392689018573,0.0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark08(-47.369027890791514,63.23263363669163,-14.292809419105222 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark08(-47.44891397222707,63.287961030368315,-14.268250600175639 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark08(-4.745578610850921,-25.406861198268107,-64.54611285608424 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark08(4.7658554764202355E-4,-100.00000000000001,32.95937811305106 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark08(-47.66232636792717,-23.665236955668476,-1.3309028967032361 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark08(4.775373076038106E-13,-37.79476609726651,7.2007262634137295 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark08(47.76294631438558,-72.57475542512233,-0.3215235282759562 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark08(-47.786502473501066,-10.123723928758265,37.99638625973219 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark08(-4.7856831453198145,7.860552845752935,-10.928867587845927 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark08(-47.87506899819674,26.399933962131506,-76.8924805560584 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark08(-4.789183171226426,14.006284219939765,51.460511830854614 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark08(-47.95143534587564,48.88362454978792,-0.9321892039122925 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark08(48.00310000190031,-71.3634991597886,32.900495130898236 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark08(-48.037343406288834,-36.46586748312324,10.215375193443966 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark08(48.218776514908654,2.8307843014172818,-35.34963888270235 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark08(48.35114502992735,-4.847490810534933,166.92483156005585 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark08(48.37648411120483,-23.35012433020465,100.0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark08(48.37812533838,-125.82446890860682,234.34823673915764 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark08(4.8378550980049075,-51.14441787559517,-86.20447413038072 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark08(48.37982825293175,-64.97186231188016,18.16283038574331 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark08(-4.84779284179308,24.7590471096198,67.53936214369298 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark08(-48.49474920472353,-358.1272022219464,-225.80027399897062 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark08(-48.69893028734806,27.77590419897487,-7.97949492728776 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark08(48.7035802009722,-34.78006675973033,89.22723772214076 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark08(-48.736960251717484,-54.434559203226925,-14.87948567351225 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark08(48.79696676114013,-73.20636975720556,-1.5582733671637325E-4 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark08(-48.83029482558563,-26.30831135567834,8.839049343782733 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark08(4.884478896131464,-20.4098758527742,18.910206997479904 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark08(-48.91843550010916,-43.2609920213408,-7.422510897852064E-4 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark08(-49.013083779581,37.662664053144994,-71.69511737764421 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark08(49.02040520413678,-63.91761661094613,19.225982390518087 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark08(-49.11896445076642,20.072429204481466,0.18001008979704736 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark08(49.12040072828666,-73.99153317273802,0.9489321661788528 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark08(-49.12823836371072,-65.46978736625837,-64.67877024111657 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark08(-49.277905030690974,13.973840296052368,9.83705424838366E-4 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark08(49.40182100230044,-34.01637101777985,81.7435172981365 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark08(49.48053833288331,-73.77264156015997,0.8963318783300187 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark08(4.973287228943466,-1.2782287473694334,13.913780201701027 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark08(-49.75686209754254,74.24387329666972,4.252127439999809E-4 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark08(49.817968739295175,-46.71770366810553,56.61701397458151 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark08(-49.85921142951844,-0.35007174971982025,-5.273776147855905 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark08(-49.87244893583923,48.40628379292485,-51.303542288561445 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark08(-4.988725212462427,-4.670773218571542,-76.1763537582404 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark08(-50.0089916304412,58.12225881331901,-32.21166093789071 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark08(50.01526873573447,-87.24066157138478,-24.035568348179627 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark08(-50.02078986724124,-27.005579726260947,48.52833963032285 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark08(-50.04959446379003,-15.439441688016387,95.9154343088303 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark08(-50.10091144076601,-161.4384077124058,92.46242701100756 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark08(-50.10354544093721,-1.3749437816166354,73.57516941500168 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark08(50.14061056467567,-55.63394518971529,0.7883488461569887 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark08(-50.181460286212086,54.901190748613935,-39.1712030346135 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark08(50.19171963644306,-206.4770750103682,-61.14921727519849 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark08(-50.41322688888134,-4.106806704306501,54.52003359318784 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark08(-50.43215883336996,0.008070373053832547,50.400661559261685 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark08(5.046487851186704,0.509088581191375,17.728437042737756 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark08(50.594749818272135,-62.13073608677199,2.165011369667692 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark08(5.080396597036775,-5.824150778723527,0.7963076903213847 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark08(-50.86306567924367,46.74124108908067,-59.10671485956966 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark08(50.97361537578138,-99.70201370137141,-84.67667547512309 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark08(51.00221999136508,-50.09055943506843,54.39633743075328 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark08(51.0625270945628,-68.6065592740071,17.544032179444294 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark08(51.08827743114313,-99.99161535234882,54.347074240351496 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark08(51.112548649763625,-60.96467181761556,36.48096332863661 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark08(-51.124009269369694,29.753632547043463,-93.77017808572994 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark08(-51.18633634454857,37.30181148344982,-77.38458973995118 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark08(-51.20061278642942,29.092143634479072,-69.8144736227069 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark08(-51.23431487421823,27.604643078086525,27.7712644497215 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark08(-51.296653317111144,-56.88950241831939,71.64328124443634 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark08(-51.30008496806702,-5.781811954689753,-1.0375672670748166 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark08(51.33639055386058,-99.72301182166048,-43.86605565494434 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark08(-5.136998174187052,13.118636838452453,12.397075481138646 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark08(5.138301639366626,10.644050589457189,81.94898422862724 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark08(-51.38664727201544,-46.01203099220847,-31.408075486073056 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark08(51.39688395821437,-187.75919383672576,-157.23001887033791 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark08(51.529857181603425,-95.40290752660722,-36.21624350840416 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark08(-5.153264929582583,-3.0853995892542003,-21.62940437962602 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark08(51.533639676538314,-56.5271237255085,72.3625397979306 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark08(-51.716231408201075,37.509357590044544,-72.90185682409908 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark08(-52.01520247916805,15.973087132502924,42.42585546331282 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark08(-52.30421217903385,-17.700961147854983,-9.755292043594679 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark08(52.34810399762471,-79.25171093961525,0.11168644043850495 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark08(-5.251255289563409,-15.689191518529729,-9.231125434807268 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark08(-52.51900925457809,83.71763045028096,11.449029463622542 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark08(-52.69595137266894,68.31070934721852,-20.21496794125822 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark08(52.82624212880154,-79.44791236394349,-0.41709834148217273 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark08(-52.882479171562075,-0.29443537224823085,54.39199269271348 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark08(-53.05827674590414,79.76183804740216,-3.2821535106430994E-6 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark08(-53.12331715181281,56.226459447444114,-1.5323459688364043 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark08(-53.16625478632264,97.5340877539157,36.52081418146 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark08(53.27812564020669,0.002220094582642291,161.34947619148338 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark08(-53.30988134613912,93.18446053863735,58.3621716378599 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark08(5.335290209199833,-40.38173324568092,100.0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark08(53.35854303226709,-29.542927077671948,101.961765159137 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark08(-53.58103817873253,58.27058629209595,-43.801937358800686 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark08(-53.681929321490756,56.28550801032975,47.339506461597765 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark08(-53.68617676043103,97.40508838602162,34.791378257226974 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark08(-53.90576001715834,17.891946250250975,-74.37818524410761 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark08(-53.92308809813364,49.95639075711112,-60.41543197763728 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark08(53.940806932119806,-96.13529913420551,133.92885886980963 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark08(-53.95262093918513,4.825613712694127,-56.95361184633885 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark08(54.11113842936128,-71.980466012262,19.440123909695608 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark08(-54.144647395763926,-100.0,-46.787987141742306 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark08(-54.14759082546814,-396.7443533353234,-175.38641491122908 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark08(-54.17166843458433,71.60971233265285,-18.515715627086553 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark08(-5.422066065240983,-80.41993285562434,-32.29893673719579 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark08(-54.30293823482824,63.570128309021804,-35.7685580862904 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark08(54.32567834311516,96.3058132377233,-90.02448415087127 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark08(-5.444065740842902,-111.54530953381203,2.8421709430404007E-14 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark08(-5.445583023834541,-27.14850458574829,31.023291282787937 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark08(54.53732306062695,-291.7772187567577,89.46730994879971 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark08(-54.559490132899576,63.532670265468084,8.795782565392766 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark08(-54.57804179307882,42.42614327160226,-77.67202683045008 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark08(-5.4645104243663525,48.57800877856121,64.60694255027497 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark08(-54.68068615573867,100.0,37.349802824202484 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark08(-54.74744186536552,62.3019042674981,-39.638517061100366 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark08(-54.792770364835604,-41.26894467975575,-26.607189658373795 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark08(54.84612086410717,-99.28222392598191,-1.1283006965830453 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark08(-54.85447190282841,23.686457949918783,46.29459849756779 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark08(-5.490637438971081,-30.04360267053575,-74.98832133118985 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark08(-55.0371991207786,-31.222560920708712,43.13752342567058 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark08(-55.07726922245495,17.412807435913308,91.53636677307296 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark08(-5.517372648680788,-5.464701231922808,4.224925787991901 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark08(-55.178085792116846,-5.762742055487683,24.432820723034983 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark08(-55.18355144852367,0.7757789132709494,0.004755537711223102 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark08(55.1983406382964,12.380979010658422,95.54050645103825 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark08(-55.326191972274074,73.76521094501886,-18.439018972744798 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark08(55.3284315908154,-43.89907064856753,116.91265970957755 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark08(5.535863733218127E-4,-50.15336248654191,-98.96412039008885 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark08(-55.36710176494404,-59.290789992897274,-63.20204602721202 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark08(-55.44427458532382,-0.9759249752843293,-55.106339657451066 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark08(-55.48638861257498,-62.20877008681056,48.91647595703975 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark08(55.49746547071878,-100.0,-33.507603587843654 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark08(-55.635355568164854,73.35505098129332,12.329861715183068 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark08(-55.64369218051115,66.09164340255978,-21.443663175445547 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark08(-55.65213559990619,-6.184480168659622,22.240182394273106 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark08(55.686286606216974,-83.99996775465607,3.3770410681760454E-4 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark08(-55.79007201947401,-67.18318706274623,1.3339897109680658E-4 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark08(-55.898134670500156,0.0,-72.28172932235296 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark08(-55.95670182888946,-47.62946442007554,27.01238959326153 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark08(5.612907718979342,-4.570355988215022,51.98818519868505 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark08(56.14144794693273,-3.4341823919925574E-4,168.48276951275943 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark08(-56.33437109339199,100.0,31.776316845111893 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark08(-56.33796187498829,61.52509295334044,-45.963699718283976 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark08(-5.641582755036012E-4,41.58481200155374,66.9551783927978 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark08(56.427049745851356,-44.81427910125826,81.22338152686784 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark08(-56.44928676411459,-85.55525520512391,100.0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark08(-56.47493808134432,33.92700895861904,-100.0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark08(-56.649525761800994,40.90598664336913,-85.32023790087479 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark08(-56.749473697743106,71.58345457885251,-25.510715608729413 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark08(56.77591555537667,-85.50790327648917,-5.881188247656724E-7 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark08(56.89324185756795,-77.9313115606967,13.184087996334933 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark08(56.90315283437895,-52.66092930516599,66.95839621959976 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark08(56.956047463802584,-89.38798545351231,30.861141662914832 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark08(57.046817849106404,-82.22429576060962,-24.734519256673007 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark08(-5.705621701507773,-20.289897132441606,-57.506686486219174 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark08(-5.708419235200864,89.872733335996,-79.28583025118667 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark08(5.713995441803377,-19.003399367620872,-20.54272382969776 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark08(-57.17290112776459,-75.84985698175251,-46.37683742582539 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark08(57.361915456196826,-76.88199400584175,19.520078549644914 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark08(-57.43839284115513,35.60907431584415,-7.679923842829333E-4 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark08(5.74420663064447,-80.28911936443146,47.62667503192955 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark08(57.53103554699017,-45.34456434234268,83.47477428308002 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark08(57.571742715676216,-70.17198132590762,33.752932849058816 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark08(57.72159565458442,53.16887294648901,381.35016900051767 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark08(5.772581222679489,-24.43254287773849,-2.2092527462297396E-7 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark08(-5.794773436881296,-19.441679677355157,1.791758689257307 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark08(-5.798156223481638,-42.088163828175,-50.04768408425056 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark08(-58.03895078965742,-6.111184754421103,15.537571684274255 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark08(-58.08899534205697,77.83787316212499,-18.591239701920912 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark08(-58.13770996463558,72.30667458906927,-29.797246766697608 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark08(-58.223071101561764,74.97971201279522,6.8070062580267825 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark08(-58.23674647366071,67.42393190689293,-38.32869833168729 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark08(-58.245201845798384,79.2025407575302,-37.165207682683636 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark08(-58.259234969519305,36.42092407167726,-0.18326938669193282 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark08(-5.828160931311808,-12.689666552317732,-42.77657877290965 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark08(-58.35107980645646,16.508262394670545,-120.33781853017766 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark08(58.53866533846741,-82.44893479034921,10.718126434703812 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark08(-58.59107259610244,-0.9490954448589299,55.508869919365935 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark08(58.61683613220687,-77.9418805543194,20.895840748907425 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark08(-58.648973405564945,100.0,126.15483425745306 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark08(-58.76019817365646,76.46966755122986,-21.77046309171476 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark08(58.7712248317482,-98.80763596010848,-21.30159742497237 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark08(-58.80392299600425,89.99434135420701,3.5769137204012678 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark08(-58.846403789689475,34.65434999273046,7.702685966339998E-4 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark08(-58.91354974430914,44.74017441829831,-87.26030039633079 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark08(-5.893529708804721,3.3694742202203702,-9.494251889179068 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark08(59.01249172264859,-100.0,-48.43601238219351 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark08(-59.084000352397666,73.11798169694183,13.39644204296026 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark08(59.091373821913024,-78.20163017964752,22.251862026336248 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark08(59.097115092215994,-73.31175032635566,30.66784462393666 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark08(59.12614943543784,10.311318810355559,-20.89241087136766 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark08(59.15811830817371,-80.326366985918,17.3060495853111 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark08(-59.214677263173755,-35.53096827052573,-9.258369355219699 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark08(-59.2209481505364,-142.67185335478072,-60.08205776854204 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark08(-5.925414858555221,3.7582754390389823,-8.688897370792802 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark08(59.275827086735035,-64.00602715887635,50.55773790200686 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark08(-59.28764496867574,-20.877805098157324,-100.0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark08(-59.30340769602455,38.89485343819571,-68.53037297125537 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark08(-59.31867534020936,90.90345022516944,5.4216707565056765 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark08(59.44325265337493,-88.5088862834331,1.362984899246134 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark08(59.444097904453315,21.8314958937774,89.47145429591257 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark08(-5.951783045287238E-4,35.98150518929413,73.34887517409265 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark08(59.646436616040674,-103.27968949099369,-34.6287017644392 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark08(-59.66462464369464,-272.08319294722094,-181.89197811153488 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark08(-59.66790600138176,55.657721983816835,-66.15784235749258 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark08(-59.676343372953085,-66.7166537119499,-29.530974346701953 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark08(-59.68555207849581,-99.87839973574391,-44.94118251651645 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark08(59.6902409627106,-137.85881114929157,-58.925351419574355 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark08(-5.9748358076131E-4,-55.741847604349026,47.16331007818892 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark08(59.859749369335105,-137.40800036176378,-7.11810608338844 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark08(59.86225423630469,-81.73810273468692,53.813745813974165 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark08(-6.005532749092831,37.13497679837579,87.98466116029275 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark08(60.056295137404135,-94.73262517922188,-8.88539660105355 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark08(6.011401877690214,-0.0046120829626799704,18.03421033931612 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark08(60.12672897484143,-73.4071171139492,35.01667552452061 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark08(-60.27247927908517,-38.46500688802183,-43.44747891983941 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark08(-6.0531575882580535,54.085336931911215,90.21113463098212 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark08(60.65356501348336,-74.22892054664015,35.073650273964645 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark08(-60.67608317169718,128.68820857288446,76.59071830052264 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark08(-60.75071276602377,13.584535899755522,47.16583442680909 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark08(60.760643683590445,-73.8226365754976,79.98501443532206 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark08(60.88204841767589,-52.81982379255048,78.5772939947216 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark08(60.949837317473325,-51.99465863242956,78.86019468756085 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark08(60.98989978961507,-85.15615047601517,20.177687968181022 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark08(-61.10380729793713,51.32811900171182,-79.50712596103247 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark08(-61.21226827071755,120.98202729122954,59.10526299550034 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark08(61.29001677462418,56.04822072550749,-1.886012680293362 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark08(-61.38622530545402,9.236834756740691,42.710893137511135 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark08(61.43400899019511,-23.665537276396776,-14.970943120975647 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark08(-61.45450535091857,-3.3502250808229084,73.66215858121669 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark08(-61.557752823793635,-106.00820055985805,94.05111834887029 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark08(61.64036304914447,-53.994127247087945,78.5036309800524 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark08(-6.166311131911538,-24.846350263090773,-67.60322644977587 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark08(-61.71073879963136,51.98114301526405,-79.59913404157106 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark08(-61.734831895031746,32.81529633118575,-18.219979267171198 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark08(-61.79100726817526,9.791999304808776,-0.923832379126404 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark08(61.809505990744356,-100.0,-14.1207127460359 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark08(-61.922203043074326,98.97329267098202,13.750588144459966 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark08(-61.92971415623531,82.05082511496563,-20.121110958730306 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark08(61.95877846625854,36.29425132167814,359.00902393755416 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark08(-62.00227270135469,-312.6453283175545,175.65874268126794 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark08(-62.057792700575774,50.8678532269966,11.189939473579168 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark08(-62.10308519470667,79.22479689038448,-27.844703435999786 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark08(6.2284444863232915,-89.86262457187985,28.452529692566912 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark08(62.35392335993898,-93.72343290692486,-3.356723427968193E-8 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark08(-6.243516427961589,0.4263681464525486,1.120539686550707 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark08(-6.244051124361405,-82.87875861908431,-88.85459390445085 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark08(62.56407409404164,-61.35197001305295,54.69672233615324 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark08(-6.258143778597522,-6.600887273040908,-31.941206041517855 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark08(62.63308053916501,-81.19236840343842,75.0690820007027 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark08(-62.72147135736375,-93.34630568974798,34.838460106530874 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark08(-62.83593058416532,9.744797186595377E-21,-100.0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark08(-63.07928871667258,75.85284168694535,-35.96138644933215 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark08(-63.097556933706485,83.86443388406776,-20.766876950361286 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark08(-63.15146885018265,83.7354792836236,-21.98344798330074 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark08(-63.21172575103904,31.949388181854793,32.826520951660235 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark08(63.34798690002893,-94.55203257559012,14.998890780452086 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark08(6.342895745651456,5.3115435994594264,74.71119610032369 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark08(-63.458732081272224,48.06065881860671,-50.00876500379973 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark08(63.53030092453928,-66.08618393971884,58.41853489442543 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark08(6.377329522340021,-5.722216558546222,9.257972890945632 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark08(-63.80305432633422,-108.73362105517384,4.440892098500626E-15 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark08(64.05783597017556,-69.109550756981,55.52520272335957 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark08(64.18875145810337,-97.66881890262002,-1.6184614526110863 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark08(-6.4242449068196565,-18.280326098065295,-54.26488178934234 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark08(64.26594508879037,-72.12026487875004,3.381559851811655E-4 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark08(-64.43910279740064,-25.80560204211399,100.75157654417968 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark08(-64.58758898106827,97.01601576219473,91.33868986660485 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark08(64.6155865896402,-88.6787619532254,16.48923586246981 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark08(-6.4669272204041075,8.622693294454598,-0.5853557404966595 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark08(64.7082653544548,-54.53101636446358,32.568825430803294 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark08(6.481160580370087,9.035005505961408,-34.62704296088856 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark08(-64.81921031964082,77.15067579179451,-38.58548304853854 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark08(-64.83117034454662,-76.65184465291941,-33.35269617808447 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark08(-64.99842312739823,-0.005380233961976788,-193.58777525852784 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark08(-65.05137862830449,20.31679863362456,-9.198257844333293 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark08(-65.10583890074466,100.0,55.05231805678079 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark08(-65.14281940919676,100.0,100.0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark08(65.25040104223218,-57.53348133304192,82.25503678740762 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark08(-65.31515440343998,-91.50338687736945,23.26118169964903 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark08(6.5363266136212275,-70.74918373834291,10.351899732625554 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark08(65.48164515979872,81.10469466456564,-28.06239393918149 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark08(-65.67121900866327,7.311960925235893E-4,-32.71228921842622 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark08(65.73931100709981,-99.93256946574539,-41.10277377120999 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark08(6.578145999126253,-34.688044068373905,-5.341897430889141 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark08(65.8590085500394,-99.26677277938454,-8.468511683870111E-5 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark08(-65.92513610901665,0.017124867980438552,-1.3916207259478133 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark08(-65.94193391679765,-16.624580537794518,-59.87624340623437 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark08(65.96541496673764,-48.50305027061631,138.64194107431945 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark08(66.01715550368809,-58.69901261084456,80.65344128940951 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark08(-66.10354058575177,15.516805893275922,9.22416004361206 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark08(6.625459915291117,-47.96168554597515,0.0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark08(-66.29122859058445,-48.949643630284335,-19.892326550682142 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark08(-66.3050882126541,72.27374772913392,-9.110292784949081 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark08(66.3416435200691,-50.153190287737814,99.99999999971111 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark08(-66.38759947068081,24.14353117104398,0.02666180149444671 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark08(66.48459342099902,-110.86215377843612,-34.478154038978616 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark08(66.501318984164,-72.684288564859,-3.2497434265366104E-4 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark08(-66.51241199397057,90.88551303327715,-16.195413588562534 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark08(-6.653142391847734,6.1005424939673185,-6.187545860813713 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark08(-66.57794835192472,99.48806316950602,-0.002374894659950279 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark08(-66.58183591647635,-36.74226231668296,-46.00990456052067 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark08(6.691467010482622E-4,-34.27445393232164,-68.49013016591867 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark08(-66.97470068436138,53.339642666857124,-94.24481671936987 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark08(-67.24271388748737,-34.991644037415085,-1.1045220608848787 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark08(-67.26572174929855,80.78889537600918,-1.3770093010771234 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark08(-67.34252097678927,-22.832318058182768,10.377836533426947 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark08(-67.36434438381059,-64.14056295359379,109.51375876212555 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark08(-67.39587506005338,-100.0,-100.0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark08(67.42864209684144,-89.96616467208938,22.558962423287387 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark08(-67.43269627470814,-24.862581010169407,-57.63809986633739 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark08(-67.44120941299568,-39.41205486700585,-16.04143584158191 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark08(67.46058689656843,-39.58683742430378,45.29977385518555 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark08(-67.50175260991388,53.87397427133704,-93.18651296027268 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark08(-67.50547663784414,-29.527808042855526,-9.055155732575287 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark08(67.51801339219364,32.55534693668841,59.62829495168381 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark08(-67.57574348622799,44.992996318536434,-100.0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark08(67.68126927814995,5.179953149107732,95.46711480553066 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark08(-6.772112717542228,36.22918629142873,83.61992824242819 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark08(-67.84308939491012,31.520557587624516,-101.22759177672282 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark08(6.784570913005728E-4,-100.00000000000001,-23.152478571397168 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark08(-67.95383969147642,-87.91829044834279,74.84162397074962 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark08(-68.01188790195354,82.08162414405416,-53.58944567782198 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark08(-68.0722630288289,18.045347041577294,59.526124363237734 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark08(68.09074575912506,-58.20020703221006,89.43231564357748 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark08(-68.13832812099551,58.15413829344204,45.36232098102349 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark08(6.816859051403997E-7,-24.578494227707804,-29.734823438662247 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark08(-68.1764240843032,-65.6305509903051,67.06307417789996 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark08(68.21979755362906,-0.9092573912908364,66.20627134410142 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark08(68.28528758867084,-93.2752864044154,19.722843601227723 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark08(-68.29563197587522,7.500495986099013,-51.23042168881391 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark08(68.54959308296779,-69.6654784259152,36.18236017619313 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark08(68.54979773908188,-92.12321095634182,22.002616890465056 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark08(-68.55670158345131,-70.50559731030276,-89.7153781384674 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark08(-68.63486110551435,-92.5846552270443,61.85862439598452 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark08(-68.71599306200696,74.23890213531183,-57.670174915397205 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark08(68.77364777463558,-128.64561692009778,-49.53318816816259 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark08(6.878308996744622,-71.29972996659464,-90.07412159518856 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark08(-68.80292367202972,86.81913997998869,-33.72692282473467 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark08(-68.93579935875702,153.15830860001532,105.7193295613944 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark08(6.900762248376589,-17.309785405293876,-12.348003467454117 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark08(69.08822673593446,-23.417857289596796,54.77698126247469 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark08(69.18715526466045,-236.41502403492692,150.9812310744626 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark08(-69.2269579943159,88.59725304356766,-28.940547002781116 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark08(6.924040596560058,-11.152763149828576,0.02034125725131956 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark08(69.37717693121843,-80.28931154982888,49.12370402079242 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark08(-69.44054642559863,99.46325107264103,-9.395137131513806 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark08(-6.961745351869126,-7.8864305586941885,13.607385617638721 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark08(-6.9728258367319595,10.121845401009182,-4.1781457813994606E-10 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark08(69.73537751565911,-100.0,10.776130160250593 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark08(-69.7590022755354,25.016339007189128,4.149904126469053 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark08(69.78193067812222,-62.46065760290988,97.99324455520252 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark08(-69.95039704002991,-11.75691714429542,-100.0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark08(6.99804176304806,0.37394784955661287,-0.9174963852410514 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark08(7.002641357149606,-24.983542369163732,66.78211213687493 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark08(7.008839968758194,-54.19791594723718,-85.79851566140488 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark08(-70.20317768475283,101.56920697782672,-26.33428724637063 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark08(-70.36051789837919,60.61228814137134,17.602211470213643 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark08(-70.40942030103471,-20.708746098642028,0.001077296639010683 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark08(7.062498455213365,7.017767758821775,36.19337729869803 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark08(-7.073363833452234,0.47412864398776833,45.48971003107357 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark08(70.75380867402944,-66.58166202065975,79.20774017373375 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark08(7.077841749718142,-17.912711800768882,-13.021481740657961 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark08(-7.102850575321809,71.04458259714185,88.92348508081606 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark08(7.105427357601002E-15,-66.51869163035187,-25.778385125710408 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark08(-71.05914617965809,11.834157799572536,-0.6089126966933226 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark08(-71.07824148632041,66.20827954252125,-80.8181653739187 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark08(-71.08262854261778,31.190474571303525,13.92958969662972 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark08(71.38190530210862,-57.85825611656037,100.0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark08(71.39913212205605,-92.4193262897139,30.644609258147742 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark08(7.142416717277938,-3.838460977502166,58.033922945997496 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark08(71.50755182374904,-93.46799698341206,27.586661504423 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark08(7.154371677114558,-14.26633416830482,0.4155274782511569 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark08(-71.62499116853347,94.99201022070883,-23.367019052175372 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark08(71.6329112479788,23.479104098449668,-50.858196065490716 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark08(-71.64757810018503,-64.933710438226,1.4057418450366868 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark08(-71.65895036173427,-76.33919739266679,35.38573280957641 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark08(7.174775436062087,-13.304644885378334,26.71914274526105 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark08(-71.80189285590369,26.770505704917365,98.54862671026231 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark08(-7.194923337829646,-33.25983615438685,-0.006564076006999634 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark08(-72.09733242656984,50.401113826881556,-1.9891118376838222 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark08(-72.20032372650269,-2.110535343607566,19.31903487923769 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark08(7.234792128489437E-4,-66.68671498146428,-32.38240786491837 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark08(72.4754962644045,-163.0811783114961,-7.707919766708763 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark08(-72.63903165639913,4.750550398255314,50.00176779836366 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark08(72.66023376733853,-98.0319903018526,21.916721562185543 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark08(-72.67373043447785,0.4686630472251174,9.439330524564129 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark08(-7.277310328894556,0.09675027866780597,-20.06838103593425 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark08(-7.278126512690634,9.687593370548962,-2.459192796973976 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark08(-72.84350022024104,97.57930062045628,-87.60016360899598 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark08(-72.94742911180168,12.607518182847485,58.93439381302524 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark08(-7.310828657362832,0.010552113596986424,-20.3616896452936 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark08(-73.14666266346201,3.552713678800501E-15,-60.80732010211849 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark08(7.322594569229162,-64.32078402061344,51.87017704713264 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark08(-73.24326285526715,77.2623267145454,-26.016964673215465 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark08(73.31754383373372,-163.03626924433158,-5.180296308175556 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark08(-73.31963409544488,-5.6843418860808015E-14,0.0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark08(-73.32551791577218,82.89079254941379,-9.641875171588126 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark08(-73.33976162631612,0.0011733726076812445,-18.253428024349745 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark08(73.46314586694251,-116.09510770810556,-5.852821172514546 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark08(-73.48439829059711,-260.8402403706011,-212.98665955111147 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark08(-7.358238791612432,-4.354264913709519,-29.212449875461438 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark08(-7.381399532182895,-48.067156931359214,-11.208146144118999 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark08(7.382301281032461,-67.74989622351795,44.727381084650744 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark08(73.86183108215941,-320.0185179649719,153.8575583939712 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark08(7.387232764067121,-68.01685495725172,38.335375288642894 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark08(-73.97707749425899,6.464959980604519,18.41489302448049 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark08(-73.98278613325941,-86.8047905132604,31.979909898039693 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark08(74.1168838792028,-56.26626930518483,128.79776367822362 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark08(-74.20166210378432,73.6237512318229,-73.78668752091349 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark08(74.2903665592078,26.07971353938943,-32.978703319624 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark08(-74.49512197002441,27.578641811212876,-10.109844438514244 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark08(74.49796637378357,-61.746949560675354,100.0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark08(-74.68976358666691,100.0,-23.739440086538202 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark08(74.69208293130717,27.539314566914626,81.2525410332515 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark08(74.77831778029363,-68.31867042013926,89.26840882739728 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark08(74.78283151143032,-213.01908286006693,-206.82200954186692 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark08(-7.479079588964865,-9.480370452210584,103.61528239382967 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark08(-7.486168538460316,30.202334673611038,-18.709376849734895 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark08(-7.494959371708201,2.213684768160063,-24.899496531122608 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark08(-74.97041771784802,-67.43591930721999,-89.23645601985493 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark08(-74.99150613085439,78.98130713578068,-66.803521965555 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark08(-75.08460930673999,-20.934771765744607,-40.6398993589485 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark08(-75.11154177392345,-58.70811503949776,2.911577486544634 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark08(7.511282232914525,28.021476294186257,3.6730407928530013 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark08(75.16658226704672,-100.6221134359988,25.219395388116443 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark08(-7.518215011127401,-24.255245531497472,-69.49433976958225 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark08(-75.22149152011431,19.046003097867526,52.72574355857893 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark08(-75.22493315950338,75.61283606305153,-72.87833102561217 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark08(-75.28548778268717,-18.125094934375117,2.1017355701987412 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark08(75.39745030291056,66.04940167356895,-38.81320928203997 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark08(-7.539802350194504,-47.56225079899139,-73.43919639735611 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark08(7.540385131890818,-18.95633993120487,-13.720728139942391 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark08(-75.49224269265915,2.674438427034907E-4,-62.0731831826362 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark08(-75.52300264866702,-92.35850897324657,-13.874555213385364 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark08(75.64241724466882,-73.23005232780265,1.509903313490213E-14 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark08(-75.69666009488992,69.66996705520064,-87.36470221609109 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark08(-75.73603312086543,-122.17519851684189,-12.805011829177928 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark08(-75.92117049718826,60.40971744984975,-74.47248508269037 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark08(-760.0084445679381,-703.132069129677,-581.450114341141 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark08(-7.617304111473761,-98.952876842246,63.555660007524665 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark08(-7.622100834296171,-0.00960577620686412,-21.45421966026726 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark08(7.624549327783669,-70.25780328517243,71.48723559136324 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark08(-76.25752228943652,-51.54078022434363,-12.308652643465905 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark08(-76.61564636336036,112.80492521452965,13.356690048406609 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark08(-76.62515580164768,-75.32996521562183,-2.880496404688529 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark08(-76.6914039051047,-62.71251967282545,156.57973012173994 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark08(-76.7912617677562,23.493244667608096,-32.10869535356487 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark08(7.680282022820641,-34.80341408500251,-32.85974135203331 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark08(-7.688451284124653E-4,8.397384220470952,-66.15738446992785 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark08(77.07539742785053,28.46436794093063,-49.703680984772866 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark08(-77.1466396377476,158.87982349720875,86.40087788023958 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark08(-77.15187738236399,-70.39630594732475,50.13492325055412 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark08(-77.23773267814069,26.238905354383803,-72.02192459490486 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark08(77.36891587955664,-100.0,69.84433760915223 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark08(-77.4077417563849,97.92919540445001,-36.36483446025464 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark08(-77.41461702443142,74.02938009247185,-19.824759042583977 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark08(77.46279389637436,-33.81980790641859,66.7331622139045 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark08(77.49777428217695,-233.1283511309594,-232.4028024457376 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark08(77.53394555722915,-91.35917599496854,23.411913431726234 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark08(-77.64456208664825,34.23608925635986,30.352215553088172 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark08(77.67313429440372,-75.04357084000046,82.93226120321025 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark08(7.767670150928535,4.3368086899420177E-19,23.50749680048635 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark08(-77.80340814969375,-98.31588555752076,22.665745354798347 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark08(77.90637356742363,-40.28081187936684,162.60616303134492 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark08(7.794842799468147,12.122374264046623,49.19988737148645 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark08(7.847966488927385,5.7762980593763045,-46.584913407799846 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark08(-7.8527563389451105,34.60611681825381,45.653964619672294 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark08(78.69523578181432,-62.74880923546585,85.19176220183074 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark08(-7.872356340724153,-43.60886459387436,21.941651010945147 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark08(-78.75830784371458,-14.087899268956548,-100.0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark08(-78.81520882869526,-133.3280338326941,-314.07379093037025 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark08(78.90340043457161,-358.3495862564778,130.371138399944 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark08(-78.95340690786773,-0.7649462550505923,-100.0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark08(79.07893746467676,-87.7219127173027,62.00326245915093 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark08(79.07985612683777,29.419715830332905,-38.79169733208525 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark08(-79.28387122378919,58.21396923569142,11.323984435770612 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark08(-79.3194438407624,-19.819930906923716,0.024088516550888155 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark08(79.3426343129342,-82.36785772281031,73.30956869793123 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark08(-79.50001590454643,-22.83447444503557,8.65289913150491E-4 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark08(-79.50937490411897,-100.0,-29.815790368105713 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark08(79.64480981222204,-100.0,39.83832889618921 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark08(-79.75200441956775,31.955652172482484,44.61236468663486 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark08(79.77868224329211,-119.0295727883809,0.7511386846686747 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark08(79.82326740702996,-72.82639673159122,95.38780508470234 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark08(-79.8430731006754,-31.314030235081542,101.06353710132036 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark08(79.86847331207066,-135.97151173491991,-36.7965193706403 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark08(79.87453041669542,-78.38094697538602,82.86169729931433 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark08(7.9900295659320255,-62.77044251229548,-100.0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark08(79.93130809895011,-100.0,20.94355340911124 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark08(-80.00549647473952,26.303001386264427,-64.77574451993641 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark08(80.2652543123847,-216.05403018220755,-190.31150604403263 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark08(-80.33787960271538,-84.87029764451682,-70.83321443374251 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark08(-80.54728223357085,-95.31168394748839,60.44590486290966 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark08(-8.057618253176635E-9,33.15283772732061,67.55680989516675 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark08(8.077619347823639,-9.387671106008902,6.411793605561164 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark08(-8.08280317780987,37.95361942045985,51.820626399592975 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark08(80.83393837993155,-71.10431512671417,101.25849089731936 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark08(-80.84128733827653,86.39876490636807,-61.99617550572043 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark08(-80.88106547305694,-79.97342620903974,63.49312908227269 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark08(-80.96536018071998,100.0,-28.763143719022338 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark08(-81.00021905855188,108.46316177320324,-32.7867235819992 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark08(8.108540743099951,8.20933593582484,99.83900633056328 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark08(-81.11662419393406,-79.75903585281124,-26.488759728722442 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark08(8.11680756864423,15.893820356172796,57.67082319529348 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark08(-8.121615897369722,-5.852999928259635,8.92911767540691 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark08(81.31411992677825,-216.876061432841,-189.297215486852 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark08(-81.36090672059419,-88.92245809254999,-82.55761174232788 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark08(-81.38532766495345,4.2759390974925203E-20,-17.59556548952655 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark08(-81.43904560085613,90.4223424453857,-70.15081555942002 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark08(-81.45425546238502,0.01268608821735037,-17.579076008500216 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark08(81.78432440640269,-86.79360646975508,73.33655660649282 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark08(-81.93302294586307,93.75083808777003,-38.946959383587895 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark08(-8.197437607022685,53.035676557758336,83.04983662124351 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark08(8.201486599167191,-10.371783332178206,3.860893133145167 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark08(-82.04839313086022,98.68027697494954,-48.784625442681566 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark08(-82.17808518525621,30.27665139292489,-2.5349891856033935 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark08(-82.24531128248341,73.63017014637998,-97.9047972278954 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark08(-8.226712981120437,-11.76428665187422,-46.63791592031487 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark08(-82.49884285801099,73.66547508020092,-22.15494321950446 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark08(-82.5238743383745,75.46156987856921,-64.90318856626227 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark08(8.252532401590958,-47.8118353406432,-70.8660734765135 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark08(8.259216951700818,-10.969854746296837,2.838438726084151 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark08(-82.61199427186116,6.216779245384654,60.389475031909484 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark08(-82.87142114284451,20.396241214015042,18.534983314652926 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark08(-82.92109438620433,93.42229413398408,-58.776681548963545 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark08(-83.00711342082327,-201.0631204004539,-266.9693179801641 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark08(-83.09057717908962,-31.663704339718766,-86.10330570612814 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark08(-83.13895816818277,16.157061445256943,-85.02845923267776 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark08(-83.17469517139317,33.10247094712605,-24.974253333655213 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark08(-83.17864604571184,54.671144009413815,-88.60418838103841 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark08(-83.19771863789204,55.64440946784808,-136.60048419770018 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark08(-8.331395406360869,-9.0369622979299,-41.6881205392211 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark08(-83.4701355786704,28.182036904918753,-10.722382744307396 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark08(-83.4763420338578,-48.496150946667704,-7.807039900329954 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark08(-83.56871944031359,89.8520279429018,-1.0408018177078064E-4 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark08(-83.57144300829027,27.802774533869584,82.92066677927298 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark08(-83.74035777820797,-11.072064680925884,4.171544825725521 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark08(-83.8546162450881,-19.35261366104854,5.695380362366691 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark08(-83.88694101058815,46.389565214570226,-165.59733289016572 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark08(-8.391628729281011,11.248380461531651,-1.2980105471275192 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark08(-84.37776503617961,-54.41401075075563,-28.732839302012234 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark08(-8.443782002357182,-51.78797547764787,60.23175748000097 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark08(-84.4416956224592,-5.594607815774168,-43.539231539838326 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark08(-84.49117410313386,27.210805406768927,-47.58605805675088 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark08(84.49967932901164,-100.0,52.25568152865496 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark08(-84.55523968773592,75.84378831301008,-101.09505237878994 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark08(-84.55575593856892,-171.88443641256575,-36.774098089837764 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark08(-84.67511631910953,80.09278592739318,-93.14737650502498 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark08(-84.74430610311765,19.272539559516062,40.59280731317821 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark08(8.491823324722528,-1.2265924756461857,23.938192269652678 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark08(-85.07415384815603,-0.939286521094324,-68.0267875986481 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark08(-85.11834812097288,99.87209955975311,-10.265638294599341 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark08(-85.14829219326164,77.98077657234812,-97.91252710829382 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark08(-85.1543795556658,2.710505431213761E-20,35.0771202097262 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark08(-8.521051478655576,0.3581961428733139,-23.275965823425203 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark08(85.26962014167609,46.64377725008927,-75.05067735900673 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark08(-8.532487345351962,9.94645222563351,-4.8148614414541635 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark08(-85.33312081954574,-26.69886389134186,-90.08039320411301 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark08(8.539053353169827,-9.316023157697558,6.989227004035868 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark08(-85.7056893750453,60.41356459707325,-60.300961079703654 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark08(85.74559195151257,-302.29987178231306,131.5256598219352 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark08(-85.76091162237013,-184.4923250270998,40.64991401384893 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark08(-85.76754071224067,91.31492217658662,-5.547381464345956 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark08(-85.76892814426026,-0.24759116167103967,-30.475218019346777 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark08(-85.99712705721268,-91.012872367445,-54.45383529036676 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark08(-86.04003024765454,5.65163676130868,-72.41720220986477 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark08(-86.19813275203575,34.91941674306835,51.2787160089674 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark08(8.629004169860856,-61.838252773900805,-46.2782304556642 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark08(-86.54914055030129,81.02753653024122,-97.59234859042138 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark08(86.66436896950088,-45.744516608257136,-39.14060312013925 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark08(-86.71356410346546,79.86666252542442,-98.83657093275266 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark08(-8.68836794864373,16.51135714520993,7.171610110988837 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark08(-8.689618491738798,2.7755575615628914E-17,-24.858620486804142 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark08(-87.22337581427585,-79.98504108053109,100.0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark08(-87.29876475880965,-6.819065908404011,-61.87098387879096 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark08(87.32935449781053,-90.24123241109163,81.58310230613347 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark08(-87.36802987435193,1.9238904513330919,-0.009345165462967374 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark08(-87.41372298524544,-60.50130896544662,26.32982543134254 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark08(87.44869246087032,-131.9580153334088,-4.0264528422462496 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark08(87.5088831244887,-131.98948597067903,-0.0218875673368224 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark08(-87.52772285790087,100.30347144930083,-23.161048062363523 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark08(-87.81782483307494,-167.20958076386742,-257.81140632092934 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark08(8.782862699172394,-64.58902410605363,-96.59442885789662 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark08(87.88243137966043,-100.0,44.79773819128596 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark08(-88.00247198649589,88.20422912290681,-86.02816138687916 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark08(-88.20056130087333,85.66020464398424,-100.0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark08(8.825170175409468,-25.464589211037726,-24.45366789584703 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark08(-88.27675388362425,-18.312011530001286,-100.0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark08(-88.328084982467,35.42010314795617,19.904942026554835 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark08(-88.59206261709207,-131.02402494809118,-37.543646835941296 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark08(-88.69233851191379,-205.5410828802652,-180.6470691438065 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark08(-8.877282107893018,37.4244568054107,49.78786361393722 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark08(-88.86457853614908,-15.403086668036664,-38.23755077997863 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark08(88.89078702873496,-89.76749033492489,88.70817674315 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark08(-8.8932014963421,11.88008137561823,-1.4160835524812359 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark08(-89.06793562286643,68.61711537598578,-92.03178929511459 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark08(-89.16791051231662,-75.51525505131872,9.40860082714974 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark08(8.936630882164115,-15.558115315741283,2.02056051483411 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark08(-8.947153869409803,-29.22486240141629,34.613346620372965 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark08(8.955715550585381,-14.491653545559247,4.710597683621046 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark08(89.73540447416559,86.27982840526315,-61.33111930156756 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark08(-89.86775729403067,45.688244066250434,36.32023649691115 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark08(-90.0070721548735,-53.66230803278154,-24.05470900698134 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark08(-9.002365712134193,2.1724343004638453,2.4727213483889843 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark08(-90.30296345290907,95.24524929137245,20.13945341566285 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark08(-90.38685826804902,50.71079703533147,29.36202920505724 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark08(-90.61342548161682,-7.152935448538926,-47.62993367220645 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark08(-90.78042744078907,127.80193275456823,-15.487815465046523 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark08(-9.084497060795833,-42.00057488780706,-9.992803715292098 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark08(-90.85853150223734,-7.736866442282644E-4,-8.080365079553454 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark08(-90.88806013286693,-77.28268887989165,13.65307848481379 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark08(-90.92008233266931,50.78900714057547,-95.13687610233774 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark08(91.07377287406187,-86.16350583203139,100.90964782121794 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark08(-91.13175347145827,-100.0,-14.383668032484051 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark08(91.33462259618932,37.06122194107988,-43.97207285781355 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark08(-91.40764554891311,97.78968887712064,-47.22593969736599 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark08(91.4312128114693,-56.31801985411895,85.72405851234564 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark08(-91.5181356789357,-67.61332068098947,7.815970093361102E-14 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark08(-91.55720673290074,5.386455719475245,0.0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark08(91.77619463038376,-100.0,76.72626155324672 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark08(-91.79559631604141,-34.73518616564907,-66.83587179551971 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark08(-91.84511557670088,100.0,-12.240824949875034 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark08(-91.88700867950242,-50.00340135861481,37.026721518959874 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark08(91.97191409750695,83.2733282798315,-47.04440847721234 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark08(-91.97961247423545,30.90270736281339,-74.833076709843 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark08(-92.071020396297,-1.9596420858326128E-4,-87.0603006860305 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark08(-92.24686120327132,60.57307445483301,-70.9132783505231 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark08(92.28257740801394,-94.11439011234128,-10.213447843547556 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark08(-92.47557917498936,-66.31729034875825,-0.09195185460142717 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark08(9.256400477135077,-12.674817506205613,3.9903627457889015 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark08(-92.9015024104609,22.806701460695272,-11.608826886739768 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark08(92.97666118647501,-100.0,173.07790761706534 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark08(92.99650622353673,-140.36803549868725,-0.006790880672392197 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark08(-93.00578523459099,-175.18512813705706,-245.12098406608288 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark08(-93.02726507879716,-231.5649831394682,-357.62664921867076 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark08(9.303497511750107,-0.29529382242501606,27.910492534996518 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark08(-9.309335452710272,-68.49657047489316,9.865509751651231 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark08(-9.335833368695152,34.687799187364874,41.63393700260461 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark08(-93.35910663010928,-4.8328689754210075,0.0010167466701836362 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark08(-93.37549036585939,17.814747231277074,-36.461713869809216 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark08(-93.53285279026923,-98.63745154981405,-20.638183005689697 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark08(-93.74379888400833,100.0,-13.645300233106854 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark08(-9.389264537433718,-3.979979050100752,-34.55695538570778 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark08(-93.9703870727441,98.14789587159322,-84.04457314825098 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark08(93.97105248581087,-158.67456986255112,-72.11231518594425 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark08(-94.03810140169142,74.71753148019832,81.24536657525772 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark08(-94.1568582062323,15.072611406192609,69.23529688225892 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark08(-9.44016289984512E-5,22.750357410722795,45.5017988489855 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark08(-9.458534908887742,-3.209055627198847,166.81618749098584 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark08(94.83771471837991,-221.41316518508444,-153.76578403408988 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark08(-9.488897529086731,11.456617816615227,-3.9826606291270092 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark08(9.492718135172765,-87.9303279653013,80.00840615692343 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark08(-94.98685113380263,0.5809555818722174,12.725079598457498 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark08(-9.506723485913584,9.594232881290244,-7.76090836836537 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark08(95.22855410113917,-66.65484377812804,153.41002638188684 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark08(-95.38293419378819,-73.68107909304135,-42.495807760306434 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark08(-95.49167868229048,93.04840337099316,-98.80743714481133 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark08(-95.60750199218052,12.96321550057884,97.25293859507747 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark08(9.577155513764367,-9.49720765975131,41.377488046979295 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark08(95.85428275877675,-214.89009947926678,-159.93239569564741 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark08(-96.04282919186768,59.40913537417482,-100.0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark08(-96.0561930672854,61.87832026764114,2.8421709430404007E-13 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark08(-9.606941411671134,52.51354422178066,77.77706053534281 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark08(-96.09904086215266,99.39420276798077,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark08(-96.38472997656767,96.95353904856243,6.677514369330534E-4 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark08(-96.64776118194698,-178.37982230813776,-350.69685715121034 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark08(-96.65894299102692,95.81106572846988,-96.79149497536586 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark08(-96.90164162642053,21.901168609344722,100.0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark08(-97.03513914403482,22.71334619192625,24.850847005673444 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark08(9.78525249205899,-36.49295344741228,-43.60161680898264 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark08(-97.85947454720761,56.87267904430963,-84.34444725395494 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark08(-97.91118818462408,-1.3091618387084443,-0.012254461133258992 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark08(-97.92099936881705,-214.693175952503,-175.0829284546408 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark08(-98.08111281187719,76.28686596779215,20.039944374050435 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark08(-9.824086845528877,-12.434984720304822,-54.34222997719627 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark08(9.8299677829544,-73.58652577167263,-79.82253259652686 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark08(-9.836613569070327,19.48455291107532,9.459265114939663 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark08(-98.45996955173557,54.83493977796033,42.050995406988285 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark08(-9.856538099517849,-17.203615006307388,31.821610766815223 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark08(98.71610795762497,-100.0,97.71912019966979 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark08(-98.92414140379012,-181.59880331222647,-194.3801213604891 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark08(-99.02944942194407,16.04156217533277,-12.156604341971388 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark08(-9.9164332050027,-32.828261781061,-93.83502685033521 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark08(9.924769245826184,-105.22018614156896,40.67507691496486 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark08(9.930278029103254,0.005127830077398105,30.847845959019836 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark08(-9.932201796757235,17.550179022905375,5.303752655539057 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark08(-99.3653103151368,-68.83608033635223,93.48999712710965 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark08(-99.36677828739793,-156.18156133080765,-257.57406773736164 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark08(99.5905084404319,-100.0,99.61122655617234 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark08(9.961810087673607,-1.7813149486068705,-12.672431505457752 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark08(99.62414419694312,-100.0,100.0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark08(-99.65026318833874,18.263720509464996,77.20093794660106 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark08(99.80451417571567,-100.0,100.0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark08(-99.8342273692762,74.00186597531976,63.399950149778306 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark08(99.9100498727379,-100.0,100.0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark08(99.97232455173437,-47.80445408132599,81.71087023162762 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark08(-99.99471599278117,103.13990237610858,1.8677006423102398 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark08(-99.99604766808402,100.0,-98.42920367320511 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark08(-99.99800105541487,95.82753105383935,-0.001372394770467514 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark08(-99.99926636043267,-27.522985098339117,3.6757005857142993 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark08(99.99999969259089,-100.0,100.52452534958202 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark08(99.99999999999999,-100.0,100.0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark08(-99.99999999999999,99.99173566493603,-99.99999999999999 ) ;
  }
}
