import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(-0.0012973407779619302,84.06923869263696,1210.7693627163997,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-0.0022592371554269134,14.800184374261168,100.0,-40.49281819330283,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(0.0027122951855197627,-0.3904945911116897,-32.66393755540719,-96.26581146638567,-29.251730265931798 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(-0.0031457967132928035,7.758947011028212,3.9159912661341614,-14.06042448380952,-15.517894022056424 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(0.003564711358182926,-34.981945007732534,-38.87600707089316,-18.276370667263716,8.236291040773937 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-0.003677719012971261,155.1933853065341,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(0.005555236770764414,-31.21622923146176,-282.7595499525139,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(0.0056516402374005605,-100.99637534649422,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(0.006634042953003183,-12.78010474966743,-43.34361227385067,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-0.007515214145902083,4.831690603168681E-13,80.83217346315547,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark26(0.007935782937507702,-0.14959812545697687,-3.552713678800501E-15,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark26(-0.008189438444969617,12.880122864292261,191.80743715124697,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark26(-0.010770375268814258,-33.42663744582161,1.6189941059025816,-27.927520830577564,92.40591809976796 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark26(-0.01399594766668546,3.0063684758548845,14.585132353456927,-94.36695150330631,-6.012736951709769 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark26(-0.01569295365452417,24.023621081526464,64.43907690077461,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark26(0.01879995505023868,-13.644521499474203,6.771293477252032E-15,-71.58252387251736,28.8598393257433 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark26(0.02096948316132341,-0.6792568395151051,-11.580818141840348,-0.3818199830182339,88.40729595788261 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark26(-0.021783499631801817,15.021991443755823,51.093437859187134,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark26(0.023885643816358382,-3.552713678800501E-15,-39.39506210339139,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark26(-0.026100353302760837,1.3002242195629532,90.83210976409669,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark26(0.030575456947773638,-3.552713678800501E-15,-51.37441868744528,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark26(0.0314630384004736,-5.995884424883421,-7.623321123786923,-51.94127734297624,-200.95367727498515 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark26(-0.034803737622540964,16.400329869631936,2.8421709430404007E-14,-9.351492663527111,-32.80065973926387 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark26(0.03610533419119883,-2.042810365310288E-14,-1.3088601827844228,-76.08089032108317,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark26(-0.03927249950438246,-15.089868866886667,1.775858584296533E-13,-7.777437822942495,27.573948995300352 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark26(0.039967784968800935,-3.410605131648481E-13,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark26(-0.04265738686878393,12.979657479005837,9.2146857475615,-71.19671133225067,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark26(-0.043102183465987175,-10.536071970690895,1.687538997430238E-14,-98.43682780051749,-95.91611148380876 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark26(-0.04369195263685466,11.772264280226379,35.95161653338192,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark26(-0.05459197319023712,28.773393504593173,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark26(0.0640289250598703,-24.532604995728448,0,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark26(0.06415967377247966,7.800878442171079,-2.9618283514665684,-120.56585994998161,-15.595345842882983 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark26(0.09246853962089699,-0.29476882726949327,-1.8279532067585922,-24.48387336304486,0.5895376545389865 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark26(0.09335578385865309,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark26(0.15868940579397872,-1.2789769243681803E-13,0,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark26(-0.1672654004464979,0.641586791600011,-19.242332592651966,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark26(-0.17434204174080392,0.3965500428991065,1.7763568394002505E-15,-2168.530082915266,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark26(0.2586398299544044,-1.4842850667394786E-14,-6.0732963173994206,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark26(0.3092050172504486,-1.7408297026122455E-13,-6.726041546402229,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark26(-0.34491213691087097,7.105427357601002E-14,4.440892098500626E-16,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark26(-0.36118018407623254,8.881784197001252E-16,0,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark26(-0.3959135845698217,0.0016110528238360913,1.5343536807751355,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark26(-0.40930838376242795,0.9698636729506531,2.220446049250313E-16,-100.0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark26(0.6204164930887788,24.6331658153792,-7.969218662620629E-4,11.531184744292151,-49.2663316307584 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark26(0.7683926595680788,-2.3043414980251862E-5,-7.33923473555249E-15,-1.1521707490125931E-5,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark26(-0.8553727606025916,3.8349547414068566E-13,7.105427357601002E-15,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark26(1.0997489324527414,-0.45542075214257277,-1.428322665693878,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark26(-1.1102230246251565E-16,0.8599451254604076,0,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark26(1.1102230246251565E-16,-4.822986272338014,-25.763049868212182,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark26(-1.1102230246251565E-16,78.95608718752288,44.61379943392333,-66.37199830132252,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark26(113.5229804952846,-2.6645352591003757E-15,0,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark26(1.1368683772161603E-13,-1.2799588773387676,-75.1433669908994,-0.9296322851443555,-77.91729195803059 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark26(-1281.8780482214474,1387.6964622376017,0,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark26(13.298267437071416,-8.881784197001252E-16,0,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark26(-1336.5355898367698,1277.9352048452845,0,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark26(-1.357765455622939E-8,42.9073022503586,7.964586522613502,-77.50659942545522,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark26(1.3877787807814457E-17,26.596483858451126,-7.474118054979297,-7.73876044915076,-53.19296771690225 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark26(1.4210854715202004E-14,-41.318150388534065,-86.3805591908137,-28.52709776392235,81.06550445027324 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark26(14.886392458500936,-41.13687668373836,-54.40204849417469,6.155356418559464,79.71773390703089 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark26(1.5007439735370554E-13,-27.26291210452898,-95.29047923591784,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark26(1.5743406567225015E-18,-38.89395836657268,-2.3995149022330095E-240,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark26(-16.52470186553971,35.46332574029495,0,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark26(-1.7241976914087704E-15,8.046502052030627,30.696562974127716,-54.20585596411039,-16.093004104061254 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark26(1.7489147977286679E-15,-1.3195137113557251,-56.41911761154361,-100.0,-61.30920622019047 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark26(-1.7763568394002505E-15,46.67914598634627,0,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark26(1.7763568394002505E-15,-92.41382856828469,-43.93793024373511,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark26(-17.865629339571143,39.54423503177989,-87.35255845947358,42.74444644419964,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark26(18.774168232071247,-11.812765494194409,0,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark26(2.184720549718211E-4,-21.346322588576477,-0.8234541822054254,-38.00432427542383,42.692612434723856 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark26(22.157469751110796,-17.81894339673991,0,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark26(-2.220446049250313E-16,10.403598313535142,0,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark26(2.220446049250313E-16,-21.462817453808345,-93.35422554147559,-100.0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark26(2.220446049250313E-16,-38.45806980386726,-1.3430817318256985,-2156.2440524313047,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark26(-2.220446049250313E-16,87.34781821341747,26.337805071515287,43.673909106433335,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark26(2.2732356642742815,-86.10013702593831,0,0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark26(-2.2987763251160746E-4,14.206552591289977,-0.9132387033321094,-10.903998225960862,-28.413105182579955 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark26(23.25711050334187,-0.024520985271930126,-2444.930838302735,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark26(2.3645737452754365,-0.03155491883605436,-1.4210854715202004E-14,-0.8011756228154755,72.29133672730356 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark26(23.824104265946417,-8.881784197001252E-16,0,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark26(23.840119016272993,-55.75605820382214,-77.76839849349615,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark26(2.6226904229544666E-14,-13.363669990910013,-53.205663204932556,-7.467233158852455,52.452498212063716 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark26(-27.45140360830893,0.0207929077702923,0,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark26(-2.7755575615628914E-17,27.53973181081735,34.224880638084045,-63.57478138648319,-69.50869190683585 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark26(-2.8421709430404007E-14,54.69788589856849,-5.551115123125783E-17,0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark26(-28.850608339212158,-88.71140310891323,-7.2736524479000195,-84.79056155262113,-75.23726740199646 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark26(-29.31578510250607,-2.0253060307407793,36.39714966997553,-9.278622306781756,-51.78100972301787 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark26(2.967719234105534E-10,-10.28233028378105,-0.014875324160873223,-60.34586438622951,-1876.8292082853789 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark26(3.3285006695304986E-15,7.181263695678281,-50.798943018353555,2.805233684441692,21.986439589282707 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark26(3.5304956750300255E-5,17.172033984456192,-8.430848056607918,7.892126360044924,-34.344067968912384 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark26(3.5350014749108567,-0.10678888020279775,-11.00471384601525,0,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark26(-3.552713678800501E-15,105.15422847672048,27.58529429145709,-64.62742866068908,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark26(-3.552713678800501E-15,-13.158922577965617,85.8948532947231,-90.45496063814785,26.317845158162115 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark26(3.552713678800501E-15,-91.40147124195668,0,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark26(-3.552743079229393E-15,4.651016427385822,51.39181007930807,0,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark26(35.85648284513168,-3.019806626980426E-14,-0.015700112127181545,-58.73976069904955,-69.08734695904343 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark26(3.7618459890262517,-1.1969591984239969E-15,-0.04187613925603914,-14.988077658812385,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark26(-3.779115420599055E-8,70.9676028505248,88.75047552357967,34.69840326186495,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark26(37.895894741723424,-43.09642272162293,0,0,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark26(-3.791069114819699,1.9081958235744878E-17,0,0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark26(-3.8082550915401754,0.0,0,0,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark26(-3.8561136533512145E-14,53.08191002454094,3.952962667431393,26.464493163957595,-64.56520020782267 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark26(-39.77577961984559,0.014345336598135054,0,0,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark26(4.127703719917875,-3.197442310920451E-14,-86.97204987127354,0,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark26(4.147322624047405E-15,-38.733104786000695,-61.4362773673746,-165.46734028990932,77.46620957200139 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark26(-4.1901767002152076E-5,0.3166043509675541,12.689026076924534,-77.51955195295159,-55.0916013378706 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark26(-43.65440901708766,44.544661511129874,0,0,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark26(4.369402727197172E-16,-88.61542671082404,-28.703035466301188,-100.0,-81.50826474042653 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark26(-43.89904446890034,80.12664844826827,0,0,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark26(-4.440892098500626E-16,32.23596333171491,18.215737098355724,16.115743047825426,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark26(-4.440892098500626E-16,99.69831487909866,28.68089932898419,-37.207805254149086,-1877.659098788927 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark26(-47.89153488602207,-5.789395193177498,63.82969176112684,-84.5811452559255,-55.61022411905603 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark26(-4.950404250684848E-15,-28.19549653662812,72.6313056117712,-31.983664373275968,56.26136493660002 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark26(49.74927416002964,-4.440892098500626E-16,0,0,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark26(5.329070518200751E-15,-26.723792660617747,-0.26821982894315965,-40.809676109675394,-80.42187763778435 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark26(54.158074133529055,98.20339823851612,72.81826989765113,-89.03515419883654,30.15484487866297 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark26(5.541747616355508E-14,-13.32361162033493,-30.76611949993608,0,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark26(5.551115123125783E-17,-21.63477377345231,0.0,0,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark26(5.551115123125783E-17,-37.5607031321569,-1.2553748474181008,-19.5657497294759,-73.7106391102105 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark26(-60.72306605184079,-91.61211720144478,-96.16423398115748,54.50521752432181,82.16027609312852 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark26(615.2159328437618,-3.552713678800501E-15,-1486.214527008238,0,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark26(6.250225942793187E-4,-14.351561900697446,-2.8472262004553897,-18.36253619855497,30.27392012818979 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark26(6.576129407313815E-5,-45.752811663649815,-3.1083923E-317,0,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark26(6.628330469563015E-8,-4.493088890910143,-34.061831888250126,-2.24786850520917,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark26(6.938893903907228E-18,16.065886170573357,-44.623196471151786,7.24754492188923,-80.50950610442833 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark26(6.938893903907228E-18,19.768940603541715,-10.41467877245356,-14.307426133957385,-39.53788120708343 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark26(6.938893903907228E-18,-73.0397190282834,-44.73318282767315,-36.519859513531834,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark26(-7.093100832795953E-15,100.0,91.79769948129743,53.08720162946463,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark26(-7.105427357601002E-15,12.042421356452152,0,0,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark26(-7.108607247437061E-15,23.18966841898677,0.04475297087735151,-56.30540061392135,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark26(-71.4555566966669,3.552713678800501E-15,0.004771243551255466,-61.75813566127752,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark26(-7.216449660063518E-16,7.226727340681201,59.48489439716749,2.827965506943152,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark26(-7.479274968999246E-4,37.33415982104642,79.1179512861034,-20.786738116550247,-74.66831964209284 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark26(-75.15631572712687,-77.70782742107272,-55.558423054539574,0,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark26(-77.68068133632802,95.34526174005387,0,0,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark26(83.4180244091207,11.999251704525335,0,0,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark26(-84.28699028616657,70.56505127346207,0,0,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark26(-8.625374203064679E-14,22.660010405601813,33.855575235747665,-47.34959261545655,-45.32002081120363 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark26(-8.84170003809262E-4,10.071374265282822,4.640942934129612,0,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark26(-8.860001725916788,-91.16890667705351,47.72473330387294,0,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark26(8.881784197001252E-16,-12.087363926809147,-30.39696104662724,0,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark26(8.881784197001252E-16,-121.1015461773354,-47.84561658552555,-90.21144039459958,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark26(-8.881784197001252E-16,25.832665141694072,59.32936484895001,-39.018045902861736,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark26(8.881784197001252E-16,-52.09043589523483,-36.2828198505065,0,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark26(9.049501092054234E-17,87.12297776421468,-22.93281775844033,43.544286044853386,-82.25561755773839 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark26(-92.98718693145356,9.344363180888735,32.30283397168762,-79.85378672198937,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark26(9.35252493165224,-5.329070518200751E-15,0,0,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark26(9.381814216502875,-73.13903766942047,0,0,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark26(-95.99500558186548,68.23282854403598,-50.392631998866165,0,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark26(-9.605812990118181,-91.78030489595346,0,0,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark26(9.664600093307885E-9,-14.6138263662435,-67.16169490820218,-42.97059065298072,0 ) ;
  }
}
