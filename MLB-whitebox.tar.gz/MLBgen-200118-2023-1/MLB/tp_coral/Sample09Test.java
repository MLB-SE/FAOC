import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(0.002808866624890322,-202.7808172826757 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-0.0031952885602691728,175.7148128071484 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(-0.0036004452565350786,158.5346549501192 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark09(0.00553356096884158,-102.6227238471132 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark09(0.005671207759072831,-100.64807938060146 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark09(-0.0057056348756209145,100.04076902098384 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark09(0.005715103785918301,-99.87505717266734 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark09(0.008998596794559121,-3.1480124218221436E-14 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark09(0.010999513086570989,-4.618527782440651E-14 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark09(-0.014627923687314137,35.414166901968464 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark09(0.01599296527693328,-98.21795393130914 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark09(-0.016394841802870846,4.239424129155175 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark09(-0.017453549321982995,89.9986757889099 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark09(0.0,-17.598320475312335 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark09(-0.017599556473908484,89.25204047747533 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark09(-0.018959229037989904,82.85127647582001 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark09(-0.023426935892202478,-29.566037618531123 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark09(-0.02446353933020884,64.20969204792033 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark09(-0.028816635393446255,54.51005314632047 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark09(-0.02961280272103798,53.044500434231026 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark09(0.03305956094042273,-47.514131528415 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark09(0.03336903475526665,-47.07347210715926 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark09(0.034921447466433886,-44.98084818233061 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark09(-0.038022304797451945,41.312496314009955 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark09(-0.04576935083297151,34.31982971590054 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark09(-0.04587535972138368,34.24052337321964 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark09(-0.04896260977912004,32.08154822386001 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark09(0.05121558907886237,-30.670277449628976 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark09(-0.05273375723682703,1.81186163325728 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark09(-0.05309387111225661,29.5852665079507 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark09(0.05731134480074502,-9.959447360358661 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark09(-0.05900159411194533,26.62294723452017 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark09(0.062054757997043394,10.809284463186811 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark09(0.07222291483901237,-21.74927902447944 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark09(0.13247222099391642,-11.857552587323056 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark09(0.1428221051206262,-10.998271769403004 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark09(0.16414314585608483,-9.569673583398469 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark09(-0.1665178284023555,9.43320208932461 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark09(0.175291822314243,-3.263845061751141 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark09(0.17983503150534474,-4.301510701561036E-16 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark09(-0.24088102059857608,6.52104646057856 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark09(-0.284648634224567,5.518369448966521 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark09(-0.30301462609436985,17.452306972361736 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark09(0.3084124061309339,-5.093168418549376 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark09(0.30968849643665614,12.006034967946178 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark09(0.33468248266266565,-4.693392717473472 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark09(0.368500579847165,-4.262669891717351 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark09(-0.4028595325361337,3.8991166893984257 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark09(-0.45685707914137785,3.4382663605586856 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark09(-0.5334697181933308,2.9444901429730947 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark09(-0.5887868232615574,2.667852378376171 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark09(-0.5999131055002378,2.618373081690038 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark09(0.6584335850856313,-2.3856564464138166 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark09(-0.679460206549644,-5.471266615888038 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark09(0.6853742721134939,-2.2918810797362146 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark09(-0.6989789935000958,7.105427357601002E-15 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark09(0.7159422108952214,-1.0658141036401503E-14 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark09(-0.7584211632785998,2.0711398927799665 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark09(-0.7899539406695812,0.722564772349967 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark09(-0.7913703212366414,-33.743415489457234 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark09(0.8888244123805151,-1.7672740587624882 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark09(0.9180506201549186,-34.52639688970031 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark09(0.9324211988212951,-0.5676993511693899 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark09(100.0,-0.0057079576816371005 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark09(-100.0,0.015707963267948963 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark09(100.23914185776466,-0.00569433849478331 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark09(-10.277959371731455,15.318862068185755 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark09(1.0296342468074335,-0.5543680468738682 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark09(10.308655395727028,32.30380767394276 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark09(1.043350319283146,48.65621979427074 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark09(-1.1091293430524093E-16,82.63293365461504 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark09(1.1102230246251565E-16,-57.55143995862928 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark09(11.175170690310551,-85.49199470591648 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark09(1.1335881106266896,-1.3856852520501661 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark09(11.650396803222138,-0.04899351863916819 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark09(-1.1835864167979435,37.55615699621673 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark09(-1.1968857700674267,1.3124028759289248 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark09(12.28866486928867,-0.12782481608075802 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark09(12.359435240187949,-76.7733853647728 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark09(-1.2503754211699203,70.6939275850502 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark09(12.64622393194081,-0.1242106999882792 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark09(1.2662475575826184,20.08900408388961 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark09(1.2722330388243819,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark09(-12.72291084207788,0.12346202424054066 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark09(1.2908141505297408,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark09(131.7593000254349,-0.0043315139349724115 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark09(13.63501921766617,-0.11520308858528727 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark09(-1.3698831685804224E-15,0.04469895051037184 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark09(-13.716355692092025,1.0367336696174719E-16 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark09(13.91708152305314,1.8556845584822046 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark09(-13.938301008739954,0.11269639863638581 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark09(-1398.8706613318068,1236.011551824777 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark09(-14.13372403740857,0.0403847315809655 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark09(-1.4210854715202004E-14,35.11560270348959 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark09(1422.784133221656,-1287.5873265251853 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark09(-14.294529326499301,62.431117529219335 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark09(14.459935155110188,-0.10863093851702178 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark09(-1.5083809392170764,8.881784197001252E-14 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark09(1.517667820754312,-1.035006676239718 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark09(-15.34456958490744,0.012617345371290278 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark09(-1.7200227486418456,6.028576934580035E-4 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark09(1.7763568394002505E-15,-17.92712863746688 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark09(1.784003851591828E-16,-0.3432298641212651 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark09(-1.831262390679285,-1.7190219110379177E-13 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark09(-18.43220205017463,78.40260316560229 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark09(1.8530315947601287E-16,0.8192434952312116 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark09(18.583112982447037,-97.4609671966825 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark09(-1.8952359284999858,4.263256414560601E-13 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark09(194.22449614454615,-76.80011380332492 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark09(19.537294476142208,-0.08039989000079108 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark09(-1.9721522630525295E-31,-6.182785493090151 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark09(1.9812007518641495,-0.30661791178859693 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark09(20.072174701366045,-0.02843718598592135 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark09(20.339865690227526,-34.66889302010074 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark09(20.408310172653458,-61.672139679948465 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark09(-20.684333843882925,0.07594135439171668 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark09(2.0899108406073736,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark09(2.1018171296261405,-0.08893047333100945 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark09(21.121395860634706,-50.93570007732329 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark09(21.750251017696186,-0.07221968728162631 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark09(2.220446049250313E-16,-15.546774854839768 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark09(-2.220446049250313E-16,3.400552685549446 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark09(223.57708654283402,-0.002553017941123563 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark09(22.569222632626904,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark09(-2.3475789375046787,0.6691133157228566 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark09(23.80971148426501,58.46478341484084 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark09(-23.837153822557667,1.942890293094024E-16 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark09(-24.373589205148875,16.815546455208576 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark09(2.4998886794618134,-0.628346509866617 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark09(25.109789797460877,-33.914484618371944 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark09(-254.93552751080367,91.73305901793849 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark09(25.583557617945807,-0.02231105743619124 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark09(-26.268192158077568,13.160674543801429 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark09(26.531892018242388,-0.021513589826864937 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark09(-2.6645352591003757E-15,5.277276439749173 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark09(27.58556375217856,-1.59621215336567 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark09(-27.901396473648575,92.75812918777098 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark09(28.93317935547722,-0.05429048455048324 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark09(-29.57489424702719,0.053112491753129154 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark09(-29.99484922677685,0.0028011421402347088 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark09(30.570312766699402,-26.9587089478631 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark09(3.0865916475140125,16.509477138051658 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark09(-3.1166742821249107E-15,-0.042208676157973635 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark09(-3.1554436208840472E-30,1.1533659916239287 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark09(3.155443620884047E-29,1.135489974529392 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark09(3.2977662819776583,-0.476321301293946 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark09(3.3056638697050147,-0.43089933965205773 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark09(33.47787463540109,29.958504069879154 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark09(-3.3735033418337674E-80,6.1427581497165044E-238 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark09(35.06136929857813,-100.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark09(3.552713678800501E-15,-5.575210220804891 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark09(3.552713678800501E-15,-5.6690841077405025 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark09(35.95174728214482,-12.199607308164275 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark09(36.73938019024837,-85.51318850246147 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark09(37.47023202356749,-36.2257647634524 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark09(37.52978744877052,-18.11284856277446 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark09(-3.7982270983039195E-65,7.6784476871456305E-239 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark09(-3.820388401210133,74.39684803294534 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark09(38.330336819354045,-0.04098049892433395 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark09(-3.907985046680551E-14,4.344979914705235 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark09(-39.188354480394864,74.077490643318 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark09(4.035896705995,-0.38920627588451495 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark09(-42.0197856595292,-21.240541900339124 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark09(-42.529316375911264,6.938893903907228E-18 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark09(43.12917747282816,-0.0364207346125373 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark09(-43.47970111512859,52.6115238366817 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark09(439.43520308778403,-698.4756622204753 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark09(-44.22867328183659,0.035515339037762494 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark09(44.45603432682915,-0.013663318825909796 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark09(-44.55486664115302,18.509045896360455 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark09(-44.721988377484465,0.12453690687665642 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark09(45.506289632226064,-10.079321738043637 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark09(-45.9128335952691,91.01135016658276 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark09(4.618527782440651E-14,6.41694343296435 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark09(-46.21781022870548,0.03398681848019032 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark09(46.30570315094678,-61.73004248661486 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark09(46.413207615276775,-18.646489670900678 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark09(4.674625312956223,-0.02657783428784527 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark09(-47.09667971322269,85.68459711762239 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark09(-47.19562844529786,4.807995653053069 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark09(-4.722114178259943,0.3326468330703767 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark09(47.709343544741955,-0.03292429134602951 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark09(4.784772343088989,-0.32829071357255213 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark09(4.826025393284118,-45.61864580637565 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark09(-4.963409030466153,0.3164752929192636 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark09(5.01737785265604,-5.6843418860808015E-14 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark09(-50.2889063570872,1.899697563201297 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark09(-51.8415445552358,-33.071664120729466 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark09(5.191895181833189,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark09(-52.040843637540576,49.36259918672056 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark09(5.2634975373353585,-1.0771185978374673E-13 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark09(-53.241954613652645,69.36308866765225 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark09(-5.329070518200751E-15,71.30595677553092 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark09(-5.329070518200751E-15,90.7291345618724 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark09(-5.355340396943205,4.440892098500626E-16 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark09(53.838495766441355,-3.978549060882483 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark09(-54.09682954634156,0.029036753909011725 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark09(-54.36144888068271,-55.04332848577369 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark09(550.6230919214652,-236.7818723281566 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark09(-55.30236713541703,0.02840378103433694 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark09(-56.23915933221721,9.992007221626409E-16 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark09(5.70338175314302E-15,-2.7412131728794122 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark09(-57.100681573925335,5.028814537786104 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark09(-58.36211702829249,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark09(-58.53399203604566,63.884686434030584 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark09(-59.3462411472405,35.50379273801559 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark09(-59.73017010108743,63.98118314431977 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark09(-61.409805551535996,0.025578917123856737 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark09(-62.01540263906812,100.0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark09(63.15710790043258,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark09(-6.320265392860307,65.2498566813126 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark09(63.5707822767005,-9.209790967030614 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark09(63.68873168517894,-0.024663645910858012 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark09(-63.933932771754456,26.41206302965631 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark09(64.07188810665946,-0.024516154794439915 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark09(-64.55649510617741,97.02633495786779 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark09(64.8103024180523,-2.4324902542403892 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark09(66.79279854822376,-81.84286085819271 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark09(-67.11031718914484,-52.749240145469045 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark09(67.11816064163392,-37.82170803949423 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark09(67.74425835903074,-42.8576015167877 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark09(-6.8585611363297464E-18,8.927869671237664 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark09(6.916134867779377,-92.95960630761024 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark09(-69.28607948595814,17.05491571520696 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark09(70.21865310719497,-83.93497208595394 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark09(-72.0308228739923,44.582004760839936 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark09(-72.05963168132092,25.335229834937635 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark09(-7.2697063150437495,0.2160742482188489 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark09(-72.80083050879314,1.6255325748817394E-16 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark09(72.90886796002582,-0.0215446539048737 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark09(-7.2911220195563975E-304,1.4210854715202004E-13 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark09(-73.04105093429581,1.2509477902975732 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark09(74.60832251841366,-1.6697754290362354E-13 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark09(-7.706948828948134,0.03915981310061125 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark09(-7.815970093361102E-14,0.8419334027169612 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark09(-7.815970093361102E-14,2.0524095280635635 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark09(-7.888609052210118E-31,-0.5734998302653764 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark09(79.55107288667162,-66.01533621421352 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark09(80.03810600785363,-2.3175905639050143E-15 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark09(8.043375442243487E-15,0.019950564390004352 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark09(81.40138771452544,-79.8955106630743 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark09(82.01510886725333,-0.019152523827497547 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark09(82.15824034442576,5.333933993798496 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark09(-8.300576946550393,0.18923941515266576 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark09(-8.356648541651097,0.18796965302127444 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark09(83.69902658298815,-17.284541229866687 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark09(-8.55657601113284,0.06670812654577586 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark09(-85.817240035862,18.208861866017642 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark09(-86.86140817603511,-5.989166141933808 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark09(87.02883473957067,-76.65674867993064 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark09(-87.08387775349198,8.881784197001252E-16 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark09(8.832539624879203,25.973330302149478 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark09(88.36431324685338,46.9414611540644 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark09(8.881784197001252E-16,-7.112874885047233 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark09(8.881784197001252E-16,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark09(-9.122166601433826E-16,0.06712477707625197 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark09(9.23563179598078,-0.17008000768052334 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark09(-9.237055564881302E-14,7.282231311389523 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark09(92.49406771642762,-0.016982671057464063 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark09(-92.56140765096139,0.007483989816691442 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark09(-9.296073792207094E-4,-1.4244161405940758E-13 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark09(-95.55925834480739,-82.21282110629437 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark09(-9.584381661683892,54.422628552602305 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark09(-96.22032291654857,3.268496584496461E-13 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark09(-9.631865064067757,0.05925945877255334 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark09(96.95633197890955,-23.070716553186216 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark09(97.24237460853358,-1.8104864594438119E-16 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark09(-99.06294263467308,-61.23700477854026 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark09(-99.20104866889368,-31.999463127241114 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark09(99.44001820508214,-57.378338803986985 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark09(-9.954979185532851,0.1577900161838277 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark09(-99.69056214456945,1.6666824062238267E-6 ) ;
  }
}
