import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(0.011594855769490486,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-1.0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000018,-0.6159002496191339,-94.28236703429937,-1.00000373777561 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark11(-1.0000000000000029,-3.944304526105059E-31,-37.46239918979893,-0.999999999999993 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark11(-1.000000000000007,-0.9094551010411348,-56.19423502954936,-1.0232916608054539 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.004896099164507117,-0.2293706585709927,-0.4751573568458217 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.008509190945630962,-45.972995585133916,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.011665172257390943,0.0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.01828823356957865,-100.0,-1.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.021416706284354513,0.0,0.016440840366157613 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.025306635443645066,-1.5707963267948966,0.008230476713261643 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.027374475613069802,-0.8521156654029345,0.8052904727434654 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.07760431617207354,-2.4421496807876863,19.060528822310566 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.08318404783397781,-93.60030917636435,51.29686033976725 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.08758713156973741,-4.628370456132174,-1.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.11378843696783451,-46.90218041136281,0.09857754481442504 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.115449873966523,-9.595601474663479,-1.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.11632982418424209,-9.05370979271996,0.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1217309635237612,0.0,1.0000007676328788 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1253765239258513,-1.5707963267948966,-0.04829561836598964 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.12753832622684544,-95.02618316382183,1.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.13030903155472193,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1368631923703747,-32.56911218655483,-0.5611394323302547 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.16875164900791353,-96.55128593803485,-0.5457450413564198 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.18001873334787216,-46.078241117416326,-0.001945623597522178 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1981690573604765,0.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2079207030487643,0.0,0.9228793891809546 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2144858830093611,0.0,0.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.21974051484851287,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.22293154074179133,-25.043264299953123,0.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.23700530260144484,-3.552713678800501E-15,1.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.23805757641441305,-44.641344989192945,1.0000000018031592 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.24577516757069717,-50.43053939229449,-1.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.25150713881458314,-8.337823093914754,54.07720503147587 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.26239019664500907,-36.08415115586097,-0.36258043045830846 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2627302756596589,-7.229544911076624,-1.0000000246089966 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.26551976955222356,-73.4730373740827,3.469446951953614E-18 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.28397277722592906,-58.89129501064593,-1.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2854612667672591,-34.893409539458354,0.025624326164240277 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.29002705393390193,-1.1257383442218005,-1.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.29821699245378525,-64.61269479648307,0.03491874452381449 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.31041008801510905,-0.14506626989804808,29.175440273316035 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.31050071922054434,0.0,51.27533929737655 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3170738762840495,-64.95842607888241,1.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3290184859979575,-53.970176419887395,-1.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3377683833639803,0.0,0.8642183342278892 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3500794046349238,-100.0,-100.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.37301804735411537,-47.00430775433519,-1.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3855340171603161,-57.85918826978929,0.1591122845752848 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3956951258954495,-23.343055095694524,0.06258020782758705 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4241984283183573,-38.83880016105257,-92.85560590978997 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4288532517538933,-1.5707963267948966,1.8991135491519597E-65 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4505168944788474,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4547046176458926,-78.43085778551573,-1.0000018204691754 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4775435298829784,-0.09290591917594804,-1.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5162579369557898,0.0,1.0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5253409393765464,0.0,12.712227334787299 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5276247492026797,-3.635290516087508,0.9713631793811782 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5530054292974399,-51.268663042752465,1.232595164407831E-32 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5547541220490064,-81.80483882642176,-1.0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5936636419785657,-73.30553498965006,-1.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5995922311386616,-77.82484661091472,-0.9736815002821266 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6164534118200191,-70.42982424177318,0.9017823884957608 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6192120665846077,-10.860199809530304,1.0000005328673642 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6232699375293718,-5.4140281597822195,-3.464154741279182E-10 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.62501500553226,-40.54036746414035,-1.0000070230703115 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6463883386711181,-51.56976477140186,-1.0000001407628578 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6690707691447382,-36.293075354456796,66.92926299293617 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6739519945860925,-45.53119207223595,0.0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7049028235347533,-56.00057118234548,1.0000000006977336 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7237274096052007,-61.89629833383473,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7503593712342268,-55.03478750255606,0.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7763379711375942,-1.5707963267948966,-0.9040284753954168 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7880098861377294,-1.5707963267948966,0.7055146430879322 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7947749728467142,-3.901466973563512,-0.062552538183327 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8016210749734254,-10.995906869978816,-31.714952275246667 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8109443514504868,-42.96307126077704,-1.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8214268562151695,0.0,-1.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8221788093296415,-51.794908784364104,1.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8424395770013686,0.0,1.0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8639135635455174,-0.006782260705759338,3.5209526323528135E-8 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9038719052567727,-43.092962694043365,0.8848224961149916 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9106417198158248,-97.29195991820741,-2.2818384853674794E-8 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9193323135541399,-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9453557593142721,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9523969911446638,-95.64971652114752,-1.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9674295637839843,-24.106739425161493,-1.236937779178349E-8 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9692297839866686,-44.236767540662036,-1.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.002199293612982,-23.12165092702534,57.83706811599464 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.037450486877127,1.5707954318803476,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0380155068224401,-0.5553590095186534,-0.9992894020060568 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0564377427240714,-23.611284975963958,-0.8978002548873905 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0597208552219548,-100.0,-1.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0655049189081574,-51.61498477221751,0.06255253378259468 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0717769174062195,-0.0030323655534439976,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0739001372932702,-49.37027669113581,1.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0745856039004873,0.0,0.19850130165755708 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0751516356285753,0.0,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1102230246251565E-16,0.0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1102230246251565E-16,0.0,-44.45374247124807 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.128206619225063,-78.32916221302298,1.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1413117897636775,-0.6147193766173346,0.7456185850022257 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1497346243871116,0.0,-6.270036435557562 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1544799079924588,-66.67192560990532,-1.0000000089434944 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1685410031083976,-9.243542069566615,-1.0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2062052150880553,-83.39653659202659,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2347683356045491,-20.182992750405937,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2419805348049593,-56.424836560785145,-22.350919658265926 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2442538276619892,0.0,0.9999999999999926 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2645848691850072,-48.36066401069916,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2781128864992513,-1.5707963267948963,1.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2839976955144032,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2870319548484783,-93.32813186099625,-1.0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3102087122751045,-45.1166807533423,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3172798237368777,-64.29286026790086,-0.023272277454715606 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3299700728322368,-7.490856106009414E-4,-1.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3442229350339137,-67.26333346921705,1.0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4138157428061957,-1.5707963267948966,1.4021449563789234 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4211792903575846,-65.30151848628925,5.551115123125783E-17 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4218962431568105,-86.71264409273158,8.552847072295026E-50 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4236008154008601,-39.49849061667905,-100.0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4298069461570684,-19.70754558227171,0.19576583907630796 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4433265707974199,-46.52286711644182,0.192727568610366 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4581577759290667,0.0,-4.1002661789349907E-143 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.468628638801276,-1.5707963267948966,1.0000563952163697 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4950959929322682,-2.220446049250313E-16,0.3738810647755687 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5030672812518744,-59.31596855946265,0.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5099373876925597,-90.47714258401321,-69.66313184693878 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5130124212994698,-80.47981449599399,0.06255407986976273 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5144484218098255,0.0,-0.5537593539667358 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.522710650344392,-1.5707963267948966,-20.14116242350741 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5229549726453364,-6.233474943065118,0.06255780062086715 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5407950370394445,-8.881784197001252E-16,0.0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5507693574174088,-28.551347474191495,-1.0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5534452770455367,0.0,0.06255609887684062 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5594564634900452,-1.5707963267948966,0.7055894189829175 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.570796326789763,-51.68953620481669,1.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267939897,-1.5707963267948966,-0.06255811282417975 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267947598,-67.26248911827848,0.3960207031110947 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.57079632679487,-40.265612433131935,-1.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.570796326794877,-96.57990206037515,-67.61814118219067 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948877,-10.814933199050966,30.232865046552387 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-100.0,6.284869152773261 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-1.5707963267948966,-0.9424088566735788 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-1.9466462350873286,1.0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-67.04794409485413,0.5784319875946191 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-67.75314391784681,0.010508307455368888 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-88.45624671847713,3.361399316724982E-7 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,0.0,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,0.0,1.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,0.0,-48.196888112911985 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-1.5707963267948966,38.4904393936324 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-50.16716748402115,16.020074556677358 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-91.23754126728294,0.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-95.49902558386253,-1.0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948961,-1.5707963267948966,1.0154097257294436E-16 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948961,-72.28962902540759,0.7352101634269941 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,-0.10960467952522877,-11.329788332638424 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,-0.3022282857236493,5.345529420184391E-51 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,-28.416528302267764,0.10853995474393296 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.570796326794896,-32.893062627393675,0.6967961615705673 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.7763568394002505E-15,-1.5707963267948983,-1.9075869922873476 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-2.1903962064182675E-16,-68.40098781301947,1.0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-3.552713678800501E-15,-1.570796326794897,52.618393619437285 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-3.6495110088603755E-12,-58.06986357026076,1.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-3.9179180385423364E-16,-59.024063593014844,0.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-4.439813995968825E-14,-1.3893227462777362,1.000000016782806 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-5.906859123037104E-17,-1.5707963267948966,22.61074968689103 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark11(-10.029381415998927,-1.1921210066837282,-28.27308713463853,-1.0431556318944297 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark11(-10.040469602560648,-1.0293775197406083,-88.10887359350124,0.09504553901194279 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark11(-100.88235796050742,-0.08708063257611703,0.0,2261.3018031432475 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark11(-10.123170943720964,14.470384280898095,0.0,-100.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark11(-101.38166284320221,-0.27194432559797405,-2.197261945775338,-2198.213599060077 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark11(-10.144072508765099,-0.6428252889485526,-2.0514731828873254,-1.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark11(-10.178358843947567,-0.9451092151321613,-4.102025588720334,26.480971391762978 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark11(-10.201795415811588,-0.28453607712300855,-25.82262780348499,-0.21926644387711036 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark11(-103.02483464252713,-0.36107616544736576,-71.91281466837891,-94.98596201482528 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark11(-10.339917080649236,-0.19314528635061753,-24.06648404425149,0.9962169507846946 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark11(-10.387029468729928,-0.03446249214640851,-37.57770230081549,-0.6890002681598926 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark11(-10.455689629991195,-0.8468734699885327,0.0,-1.0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark11(-10.51438076309157,-1.5707963267948948,-43.649153752460585,64.6643235202489 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark11(-1.0546733168880058,-0.22710276414174757,-78.23328129510664,71.21523292779787 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark11(-10.598608457210553,-4.930380657631324E-32,-1.570796326794863,1.7126901521350487E-14 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark11(-10.598759263461035,-0.10063530564194426,-36.8877730279391,-15.481185292130117 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark11(-106.1201707003749,0.44110864697382346,0.0,97.49044931708748 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark11(-10.634303161182237,-0.9545649852296689,-80.30847468307036,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark11(-10.663791481231556,-1.5707963267948948,-22.670520302408438,0.9738322568689157 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark11(-10.772248309619698,-0.8558014602127837,0.0,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark11(-10.793614379029533,-0.7333623134387456,-0.5712256705677403,-0.00830112089183821 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark11(-108.15097084216347,-0.30727462545173956,-88.30381854840594,78.39809293869047 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark11(-10.815743167742252,-1.3621730186703103,-100.0,0.9630889795934934 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark11(-10.895685728446061,-0.04283904146231654,-88.41329143636617,-1.0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark11(-10.92901691797643,-1.5707963267948912,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark11(-10.932965742247871,-0.10103970676471952,-52.745342066397534,1.0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark11(-10.94716880421962,-1.5707963267948912,-49.9721557628771,55.944820560096986 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark11(-10.948174360382849,-0.9780409663973306,-1.5707963267948966,-24.588240918160743 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark11(-10.968918273797183,-1.3223404004269999,-17.278759594743864,0.0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark11(-109.74209657387956,-0.5332685229753003,-1.5707963267948948,66.534845064887 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark11(-11.007282084897776,-1.5707963267948948,-100.0,-0.3620929553982625 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark11(-11.048246066991183,-1.461302502633233,0.0,-1.0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark11(-111.01247810289574,-1.5707963267948912,-39.709309016680876,-0.9999999999999964 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark11(-1.1103861772878356,-1.4068246807997724,-9.889455415462578,-52.494227304830446 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark11(-11.104806828955036,-0.14584968889092353,-85.87523317495264,22.287205006652748 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark11(-11.180805862148134,-1.5184559331591365,-70.12583649756824,-1.0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark11(-11.334328559147224,-1.3877787807814457E-17,-55.62631095350565,-1.0000000000000009 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark11(-11.343126586100837,-0.5414920663428582,-6.447851635603726,44.148732965216965 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark11(-11.393862345007095,-0.4450653546046455,-6.156590096283139,-1.0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark11(-11.39879874912876,-1.3218186657006248,-80.82705826711853,1.0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark11(-11.437357668905953,-1.346681804770753,-33.41280661385897,-1.0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark11(-11.50160779652418,-0.3333393583423565,-1.5707963267948963,-56.731313594564114 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark11(-1.1529456953969535,-0.10444373960496552,7.105427357601002E-15,-1.0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark11(-11.534250001021206,-1.3960961378443486,-95.7478834887971,1.0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark11(-11.600443982943284,-1.2145056419745768,-1.5707963267948974,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark11(-1.160365878530217,-0.11669252256504481,-36.4772942847599,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark11(-11.704520282309787,-0.7491151350093199,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark11(-11.733261818987906,-0.004733417828949441,-23.56194490192345,0.0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark11(-11.756630568300613,-1.5093644650907754,-1.5707963267948983,3.469446951953614E-18 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark11(-117.69493265878006,-1.0638932271805048,-72.33479928792255,1.0000000043065316 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark11(-11.776790802433215,-0.9228797816195007,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark11(-1.1787382704508567,-0.1936872726317737,0.0,-9.631909245852219 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark11(-11.804310570938014,-0.7911997835021367,-1.5111487713237417,1.0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark11(-11.884544316000909,-0.41295496179747526,-77.96750824654157,-0.9021565692053846 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark11(-11.928889297114424,-1.5568867370660604,-90.58269018900205,-0.003024025791756646 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark11(-1.2058997683507329,-20.310919096877782,0,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark11(-12.059768320704954,-0.0018413713831810033,-1.5096297556762754,1.0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark11(-12.148175038131301,-0.17083670565529221,-46.967073187928094,-1.0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark11(-12.183743969631228,-0.39738656384292737,-73.78770277442214,-34.7723532355066 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark11(-12.432937807221787,-0.4813126459395299,-1.5707963267948966,34.729598548554314 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark11(-12.437719393345526,-1.0563333264876391,-74.58997842980024,-1.0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark11(-12.470066270892747,-0.7005080909166187,-100.0,1.0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark11(-12.545000456474607,-1.5605728873493467,-35.49786040011766,-0.04601638326023694 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark11(-12.625287531708675,-0.20595052918919962,-58.85154533382915,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark11(-12.66271447105948,-0.6885578920205094,-1.5371503899197418,6.938893903907228E-18 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark11(-12.677931677043407,-0.8025637682194084,-4.6654347298782,0.04449956387895612 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark11(-126.91174883269059,-1.7763568394002505E-15,-0.652476951102548,94.28209845270408 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark11(-12.764402569674454,-1.5707963267948912,-9.93281507203149,1.0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark11(-12.767375261166038,14.429228795990468,0.0,-95.17156529802064 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark11(-128.83401995114016,-1.5707963267948957,-83.63345088734575,2248.91933771783 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark11(-1.2891565188540735,-0.05954001200324946,-29.16043826857538,1.0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark11(-12.920315476206065,-1.2775569507967621,-73.36961949810737,4.839181673635983E-16 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark11(-12.98199340053295,-0.6747589775891408,-79.89316665029806,-0.7578542595470823 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark11(-12.985490165750686,-2.220446049250313E-16,-98.88351617172698,1.0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark11(-130.59550514735452,-0.718915583270344,-9.417251757988467,-0.32053306462874787 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark11(-13.061095027550852,-0.3324121267341782,-125.34927593803408,-0.07463563055120787 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark11(-13.094148734768474,-0.2654482928960696,-26.71643131407926,35.558629064093935 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark11(-13.123740778468076,-1.5707963267948963,-34.19708231930956,-0.8363935231633958 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark11(-13.155042829828204,-0.41889842028613294,-23.911325527962752,100.0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark11(-13.201994446591689,-0.9686960307590186,-0.027912663447436474,-0.012123380445610997 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark11(-13.261565570077835,-0.15924018415975782,0.0,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark11(-13.29799877685108,-0.7622662681302117,-3.0299951747370875,-1.0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark11(-133.39045648675966,-1.5707963267944538,-0.919090423724265,0.058112032260106465 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark11(-13.357302754663388,-8.881784197001252E-16,-100.0,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark11(-13.42826302605669,-1.2324762869924077,-100.0,1.0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark11(-1.351105125284441,-1.4806441526227074,-66.2790736149682,-0.9937994455084862 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark11(-13.51210714371065,-0.6172653264522536,-54.76139980976053,-33.877525436514865 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark11(-13.531525313326762,-0.055140462830012726,-158.53648085294878,-0.7639677188845013 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark11(-136.24575032125537,-0.8469042448755952,-0.26141828076500784,-1.0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark11(-13.70373798570184,-0.047709369038301294,-50.3257373805719,0.014578327270563365 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark11(-137.6843437433534,-0.5125552365568026,0.0,-84.32329970213064 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark11(-13.803503333708576,-1.4881308124368202,-73.71153027124208,-1.0557127194925742 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark11(-13.915270541283945,-1.5707963267948912,-1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark11(-13.916686899245425,-1.293332975051377,-5.9598828903246925,94.72351565709036 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark11(-139.72702838787475,-0.7342526356569934,-105.4913715753885,0.23214721100971936 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark11(-14.016642025838065,-1.3912957436556255,-28.74330492635518,1.0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark11(-140.84982884407896,1.2403087503138355,0.0,0.14427632935829876 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark11(-14.095217000485633,-0.10730773689020312,-84.10708568527687,-2400.789952669293 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark11(-141.217810309017,-1.5113607720085493,-26.06786519535052,-2102.537406210211 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark11(-14.13912904799135,-0.1485509847232116,-52.61231008109861,1.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark11(-14.140440729404483,-0.19940191889784353,-1.5707963267948966,0.989998675478562 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark11(-141.52716726205537,-1.4060850027202967,-17.759991985935628,-1.0000000622577172 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark11(-14.157982066495542,-0.2996268863560143,-9.483836709414522,1.0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark11(-1.4300008226459227,-1.5691906160914857,-24.468528137778605,-0.8373715739483468 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark11(-1.4323561429291165,-0.2663418158262374,-44.99378122786537,1.5922302674712485 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark11(-144.11043035543722,-1.0285722900255934,-100.0,-0.8714691216301975 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark11(-14.420738227058933,-1.5516483423950898,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark11(-144.38637790658888,-0.6229866606165856,-94.76355207874053,-1.0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark11(-14.444846937109292,-1.394718936797522,-11.734103501392283,-1.0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark11(-14.57660196019868,-1.5707963267948961,-45.362313159285065,-19.765397979046796 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark11(-14.591681881195711,-2.220446049250313E-16,0.0,-0.036549713850988416 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark11(-14.591938171451165,-1.5707963267948948,-23.597712949617545,1.0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark11(-14.620182262228248,-1.0403428488911501,-62.02750340528493,0.698446938002327 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark11(-14.73129864457974,-2.220446049250313E-16,-0.39283806009228345,-1.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark11(-14.764646036750289,-1.1864692448744611,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark11(-148.24528457777205,-1.364830760995517,-129.43942344311304,-0.33912659047487814 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark11(-14.834973528188936,-0.024598731880038388,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark11(-1.4835272983028363,-1.5650152877633865,-88.30754984493586,1.0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark11(-14.880772611017312,-0.05586392291698191,-44.41853386714325,-52.10350321036379 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark11(-148.93821856745072,-0.04111425496451296,-58.87078709716458,-2172.2764579757686 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark11(-14.94096715125717,-88.97086433613318,0,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark11(-15.018096825088463,-0.22804531989053758,-71.4021671088797,-1.0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark11(-15.09386749367512,-1.3280135083329867,-45.934578379653445,-68.25392569669688 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark11(-15.101139545888032,-1.0375333138028557,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark11(-15.12909312886621,-1.5196707903465758,-145.95448224402915,1.0000002904355716 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark11(-15.155757270528555,-1.3354130215796087,-100.0,-45.18016157629532 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark11(-15.160747306936447,-0.9019798608984151,-73.65634133148538,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark11(-1.516214464186036,-1.5707963267948877,-39.70669328760665,1.0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark11(-1.5172110575730002,-1.567655398706796,-60.77108720741671,0.9972370152059207 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark11(-15.245229123738493,-1.1271320844732848,-100.0,1.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark11(-152.7006668817392,-0.8728002257949754,-47.20715427468387,0.33146574083421587 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark11(-15.488327011716123,-0.7624640324033712,-9.730520022920839,-1.0003165698820093 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark11(-155.0190353931895,-0.5700448032780479,-137.38813021752136,1.0000019127667665 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark11(-15.542172271519267,-0.9222555202346528,-42.52446121450693,-1.055637246082304 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark11(-155.6116731848577,-1.1930557353243252,-130.29109371677762,0.9684571284386729 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark11(-1.5575275194468352,-1.5707963267948912,-1.5707963267948966,-0.16949616791684083 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark11(-15.66558468776887,-0.7078620513999165,-80.40860390621577,-1.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark11(-1.5696651639570787,-0.021616657056698376,-18.351214284668043,9.294437506388411E-7 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark11(-15.716963803519313,-1.7763568394002505E-15,-1.1572298997433568,-0.8402140744029445 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark11(-1.5731033131728016,-3.552713678800501E-15,-73.46649663326318,0.0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark11(-15.753645575153115,-0.34321239840619017,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark11(-15.803967827234537,-1.5696001053146764,-40.4795647036587,-0.7974757630470467 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark11(-15.808721551192349,-0.0909560966289007,0.0,-12.655206745461015 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark11(-15.828060852040029,-1.4769590284835021,-29.845130209103036,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark11(-15.87992353151784,-1.3537948379911144,-48.90598889251679,0.023415333514521477 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark11(-15.887254878838625,-1.3159415965738006,-90.43459127098434,-66.26467938612946 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark11(-15.89764321676047,-1.2495493439644716,-1.5707963267948966,99.89429755324588 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark11(-159.3901213365918,-1.54780190304833,-44.619037753701164,-1.0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark11(-15.959296095722934,-1.5707963267948963,-23.569152745033932,-0.26092142935464685 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark11(-16.02529518389808,-0.6123224117665522,-1.2210198968263009,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark11(-16.065193198392652,-2.7900842910686474E-5,0.0,-34.3282054078437 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark11(-16.081199390349195,14.429245701407737,0.0,-1.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark11(-16.130846490892917,-0.5580286148797575,-48.575161461461356,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark11(-16.191207775050316,-0.28660890281417783,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark11(-16.2575392820404,-8.881784197001252E-16,6.43241619568903,-19.673365297598878 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark11(-16.271402542378894,-0.6283525331701072,-39.11171975020777,0.5208130058577531 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark11(-16.30966664648895,-1.5707963267948948,-78.21534426446075,-1.0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark11(-16.342525679792363,-0.6504151960676134,-32.31190229895445,-70.41078882391912 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark11(-1.6482547385622461,-0.2251637806331237,-73.31448226581963,-1.0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark11(-16.491622016587687,-1.2693612077759937,-3.044063883552818,-9.0409877152965 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark11(-16.492192940231188,-1.201168729393856,-29.171245245758605,0.0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark11(-16.5021665790019,-1.5707963267948963,-89.98550604834537,100.0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark11(-16.523158084959107,-0.486586596269607,-9.528967067213216,-0.511047865378199 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark11(-16.56925475166956,-0.013436891655625336,-32.87778189624517,-0.9999999999999991 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark11(-1.6593858091234779,14.47065684809344,0.0,1.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark11(-16.73916018276166,-0.2429890572351351,0.0,-100.0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark11(-16.816716668294315,-1.0965607008185936,-100.0,-1.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark11(-16.857078283047322,-0.18578840896538984,-4.440892098500626E-16,-44.46976389258451 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark11(-16.857760484019956,-0.0012278927133605516,-1.362244505317129,-1.0000190608835906 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark11(-16.87711608926272,-1.2276990147471416,-95.32799671488795,-38.321990445773935 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark11(-1.689501748788707,-0.20979169779799234,-28.222042465050183,0.7686448308595786 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark11(-16.899184687974582,-0.5009775705251481,-10.699020363908051,-0.5979164176187927 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark11(-16.915823480166637,-0.4679189326458242,-180.64527358416333,90.83263877484382 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark11(-16.96155085503012,-1.5260080863335974,0.0,1.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark11(-1.6964698756057581,-1.1102230246251565E-16,0.0,1.0295115178936058E-84 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark11(-17.021604460364003,-0.2073733583702022,-5.715952324154324E-15,-0.0378122580935497 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark11(-17.06125160000946,-0.00215075213849759,-88.64791753170839,0.02187106068305699 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark11(-1.706779230017645,-1.4555524163216949,-75.43786758139342,-1.0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark11(-17.14554722698292,-0.786425250029894,-77.86104679738159,-0.4372057071286566 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark11(-1.718831024793429,-1.1277250615300876,-60.691265272025326,-1.1704190886730496E-97 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark11(-17.194977932710657,0.0,0,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark11(-17.25630351173332,-0.7199749734064304,-81.19556292592367,48.11457184882141 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark11(-173.70723370897272,-0.8165597302413659,-95.2783193517463,-74.25018241820689 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark11(-17.394736130371864,-0.03840617789537362,-96.2706153437725,1.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark11(-173.96645448777878,-1.5600376964512541,-101.63962641002107,0.9400052676749198 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark11(-17.51535279434889,-0.1836863418266869,0.0,-1.0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark11(-1.7536803654310198,-1.248582213135264,0.0,-61.805236570371974 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark11(-17.64307846925121,-0.6201960611550109,-31.45960346453983,1862.157403278897 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark11(-17.767697386202094,-8.881784197001252E-16,61.823250403984,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark11(-17.833591347503045,-1.289625195542376,-11.638441284622594,52.95782845037506 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark11(-17.840326409645215,-1.5707963267948912,-88.40474295020731,-17.000909628571915 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark11(-17.934993900405246,-3.552713678800501E-15,0.0,0.9000794717339138 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark11(-18.004234680831004,-1.4629339805584363,-73.30130327072521,0.9713908234607658 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark11(-1.8091591393710829,-0.24122262979358627,-31.389029221332116,-0.001152979270792831 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark11(-1.823021600057821,-1.5297996852473903,-0.8031540829918592,-1.0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark11(-182.36131249360864,-0.6402258622244844,-4.278737661664599,2098.990732647938 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark11(-18.247877778585163,-0.903062668791585,-31.81228980636874,-1.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark11(-18.257146326884467,-1.08851978685087,-10.308353153527634,-0.5987273406464513 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark11(-18.274316725428754,-1.4892786605843547,-77.255251432025,-0.9942200482183439 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark11(-182.7844021417936,-1.5707963267948948,-58.86415136954307,2223.022504736855 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark11(-18.32163748354691,-1.5707963267948952,-7.20334248282431,-0.9999999999999996 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark11(-183.5112637558577,-0.6928151001344627,-109.4026073564665,-0.18921215424378668 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark11(-18.464062422196328,-0.17453601923871015,-72.74580525899297,0.9055079587977239 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark11(-184.74888657223738,-1.2929462636928974,-31.822457257782013,-2163.778129512179 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark11(-18.555563702277205,-0.7863059924216458,-53.847158201194695,44.66921610717853 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark11(-18.5657352617525,-1.3591073650205407,-100.0,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark11(-18.59383342007939,-1.5701179832266863,-186.36152352343447,26.34972739703977 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark11(-18.65113015068468,-4.644195190867445E-6,-44.22058539552511,-1.0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark11(-18.68719528156233,-0.3112463910558154,-1.5707963267948966,0.15276504968629512 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark11(-186.94926739109079,-0.6531213022857116,-60.742608717386055,1.0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark11(-187.6223837184329,-0.072858127903908,-193.13508136622542,0.979675053988089 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark11(-18.86035710712642,-0.04212360964732817,0.0,34.68440391083522 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark11(-18.86639074063672,-0.07179640020100592,-84.98636203121269,-0.5894623849380709 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark11(-18.997429767282423,-0.047095383435900286,-66.31360090885252,-0.950914888812085 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark11(-19.006377441287142,-0.7916598516662169,-30.10375518315603,0.1663768809818018 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark11(-19.007856222075386,-1.5707963267948521,-79.05924737164561,1.0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark11(-19.059521970934764,-1.090209167857903,-45.0033972199781,-62.71270799163925 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark11(-19.100708200933866,-1.2938457450452985,-44.856997718846884,-0.33640645892695886 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark11(-19.14361312667876,-2.220446049250313E-16,-1.5707963267948966,2.7179998781012813 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark11(-19.14553910434314,-0.7468675166774001,-45.52494842725491,-1.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark11(-19.146618702747737,-4.257518819833565E-14,-1.5707963267948966,-2.6528173546687534E-15 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark11(-19.17948897171487,-0.02973617472637793,-50.95822580836518,1.0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark11(-19.208741979423934,-1.3035555196236042,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark11(-19.275118169050426,-0.8146029044354296,-100.0,0.9999999999999991 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark11(-19.28812387507716,-1.4583576914777148,-38.024984503985216,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark11(-19.30544648486216,-1.0712374569884289,-100.0,-90.70691195776601 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark11(-19.388607443180405,-25.734108248835213,0,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark11(-19.42618290202647,-0.04967803265683511,-49.97043809365945,69.93647358979315 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark11(-19.4283420510138,-0.6081979244778566,-135.59127725415357,2.3332373731142866 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark11(-1.9437873214586574,-0.02469224442668702,-81.0788199570306,1.0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark11(-19.50579508729227,-0.7995003870071627,-74.34661174234472,-1.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark11(-19.51305367573751,-0.4533648020215036,-0.3875805894634032,1.0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark11(-19.519965964758196,-4.440892098500626E-16,-67.12817485871658,-0.04140923734271773 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark11(-19.528226013433954,-1.2286956410641525,-37.8531152084642,-0.397495898011029 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark11(-19.612156121790306,-0.6886298214267034,0.0,-0.8739533319548265 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark11(-19.623179853482256,-1.5010159968147962,0.0,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark11(-196.34891416745913,-0.12261024252661568,0.0,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark11(-1.9685883708869412,-0.9354907382249285,-44.05807426275001,5.57125451454651 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark11(-19.68752483583626,-0.6133901918667195,-63.38948736262395,-2.996272867003007E-95 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark11(-19.740544623174635,-1.556239506668456,0.0,-0.910641305975997 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark11(-19.791537310527808,-1.5707963267948957,-59.71071856062507,-0.06002996771270483 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark11(-1.9818865596198236,-0.3869177028028854,-55.239352884395146,0.11566579534355326 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark11(-1.985544683029015,-1.5707963267948841,-55.35046005647794,-1.0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark11(-1.9864505637540688,-0.9863116077003901,-57.54969199228558,0.16333584447225075 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark11(-198.6729608204878,-1.096900979091164,-130.00863099438936,2116.4730300788215 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark11(-200.58310009631128,-0.31445062540892366,-136.597310380296,-0.9999998974596784 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark11(-20.08139815848196,-0.05038959808799004,-0.1573372118936186,-0.4318813352050265 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark11(-20.08526978582521,-1.570764826177049,-78.49648849091545,0.3247255068470527 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark11(-20.19430805273207,-0.015454763103733171,-32.6065992679126,57.08737139169335 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark11(-20.20690619098002,-0.9048880725515023,-77.9681169096497,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark11(-20.235104668299595,-1.570216561667649,-100.0,5.647508502382066 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark11(-20.240562531044553,-1.4072606076698262,-0.3315738410895612,-36.52656017957072 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark11(-20.240774081669613,-1.0690189034546311,-0.5703536721725598,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark11(-20.242757239347224,-1.5486513747765571,0.0,-8.370776323740833E-17 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark11(-20.24482428849776,-1.491497187610552,-53.921778004752575,-81.0018903857289 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark11(-20.25458765260593,-1.5707963267948963,-1.570796326794897,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark11(-20.279474277372607,-0.23653365772122711,-24.163559726920163,-1.8033161362862765E-130 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark11(-20.434590722111622,-0.3898217558411674,-58.98619650431327,-1.0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark11(-20.52108286266907,-0.21114426960303148,-100.0,-1.0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark11(-2.059125108042204,-1.0740898323996642,-32.55847335219261,34.97640063415364 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark11(-20.62957190041977,-1.5598527365139176,-158.3456733913775,-61.00395338835578 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark11(-20.6444067835111,-1.5707846976613755,-1.3298521848410993,-0.43988391354456474 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark11(-20.681361333459975,-8.042538800644847E-14,-33.174617296226494,1.0151767349262597E-115 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark11(-20.82698304624767,-0.8351367660057669,-32.60701167261972,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark11(-20.839502168051773,-0.550148894268203,-18.6740545242734,-0.1815053333830191 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark11(-20.84708749493248,-1.417015670610567,-0.15460550865431022,0.0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark11(-20.851931511863615,-0.08298993651659003,-67.25118509005841,0.8311451835249066 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark11(-20.919157072335096,-3.552713678800501E-15,-1.5707963267948966,49.995580861817444 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark11(-20.92678607311357,-0.7521029560371536,-26.77839111948819,-6.755413863566706E-4 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark11(-20.94152552444561,-0.505326459565928,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark11(-20.98856871363366,-1.5707963267948912,-1.5707963267948273,0.6610042242636319 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark11(-21.013058617450344,-0.18891627272811645,-1.5707963267948966,0.2468971285099183 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark11(-21.057503417537973,7.819015309002865,0.0,0.6471403047476088 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark11(-21.087714659100506,-0.4353138968326569,0,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark11(-21.111978985076448,-1.4210854715202004E-14,-32.95628463257802,0.6145294733843336 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark11(-21.117344864826343,-0.041855818950312915,0.0,-0.003626939146592789 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark11(-21.127510942945914,-0.02202695434933052,-1.5707963267948966,77.33980091806251 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark11(-21.16450470870118,-1.1354445322295814,0.0,-1.0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark11(-21.166333444124877,-1.4474862359052612,-61.92868253593276,-0.5786484628599213 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark11(-21.204834035567462,-0.26475713146402746,-1.5707963267948912,1.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark11(-21.24764068317505,-0.4963184722697851,-65.8643118391849,1.0000054408192203 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark11(-21.261277004755996,-1.4145883818565277,1.7763568394002505E-15,0.03894074075024856 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark11(-21.262826156970252,-0.42666955045444116,-94.3839152720446,-1.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark11(-21.274945563465977,-0.2192550708834169,-0.07924635147566139,100.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark11(-21.282428430628936,-1.5115414394982924,-47.805920303369646,-40.713496963327664 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark11(-21.289385053106187,-1.2469848427889914,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark11(21.301191152906668,0,0,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark11(-2.1359108964339413,-0.3236329347613555,-25.048245293895924,-84.2707396241576 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark11(-2.138434820973743,-0.9989440544980155,-52.753704968601184,1.0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark11(-21.436204834923164,-1.5707963267948963,-1.5707963267948966,-7.138819458420206E-17 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark11(-21.62185040413017,-0.11772006891675729,-67.3313781168956,100.0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark11(-21.695772955310748,-0.22355144629272522,-38.64827204135398,-80.69097273303865 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark11(-21.743780085137672,-1.4477420533677248,-4.525744145168787,-0.21383931298032532 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark11(-21.76817403750118,-1.5707439527650524,-12.476019733454615,-1.000000000000092 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark11(-2.1795404282381172,-1.5707963267948948,-0.25208989937249265,-1.0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark11(-21.975090557833138,-0.048274085437461964,-73.51767787612299,7.14310482415047 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark11(-22.017338114113976,-0.46454975939834703,-57.35473231190229,0.7121590842380263 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark11(-22.117615446894206,-1.1272755736520244,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark11(-22.18217609908611,-0.225222138926112,-72.29950377456991,-0.95181488301192 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark11(-22.182445030942223,-1.7763568394002505E-15,-79.9397985083974,-19.91840810148945 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark11(-22.19309639832619,-0.4881005256299762,-96.95866141544568,1.0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark11(-22.27672947130697,-1.0616835253160644,-0.882640706195536,-1.0000000000000009 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark11(-2.227781537551394,-0.07834790064989863,-92.21970532702562,0.36209217176563524 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark11(-22.372956081896668,-0.7050589568930001,-12.1491433138873,-0.7560269704671518 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark11(-22.564285655716912,-1.2522695041082792,-90.78314833982375,-1.0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark11(-22.645260367473888,-0.34040277931575663,-1.570796326794894,1.0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark11(-22.870511276145173,-1.1100725814861583,-123.9744589607626,-0.0019263737033482912 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark11(-2.288063612404738,-1.5707963267948948,-1.5707963267948966,-41.71521112606078 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark11(-22.89824327941188,-1.5707963267948963,-39.52084521982436,-1.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark11(-22.900034253880296,-0.6422310153894997,-0.05294698012116328,-21.176359530769894 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark11(-22.959638043307717,-1.5470934172601376,-2.220446049250313E-16,0.9719655187838873 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark11(-23.00667016129319,-1.0972564189308274,-61.26105674500097,-7.490682167507517E-96 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark11(-23.04884890540923,-0.39088447177895436,-115.17443519185925,-41.26075064142996 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark11(-23.06354048295582,-0.818183774531504,-43.137701533510665,-0.6412213729010365 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark11(-23.199473299681756,-53.06598274624839,0,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark11(-23.251688879672678,-1.511960723689109,0.0,-0.9999999999999911 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark11(-2.363437650862127,-0.028261554067497897,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark11(-23.754531719044635,-1.4603366048938113,-52.23382343273161,-0.06263836722908037 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark11(2.3820903089900582,0,0,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark11(-23.877519106026774,-0.7629360403532386,-1.5707963267948966,94.16230636840548 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark11(-23.937912811445894,-1.561273757476204,-66.8598781960454,1.0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark11(-23.9482459074772,-1.5707963267948948,-98.56809271583957,94.82841953271226 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark11(-2.395653073839071,-0.9879484683153475,-37.88933894758087,0.06257839266558957 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark11(-24.037072751662727,-1.5707963267948963,-50.637728293446685,-0.8966926269055647 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark11(-24.06711821990774,-1.5707963267947935,-1.5707963267948966,-1.6139918309805564E-15 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark11(-24.18990881313306,-0.26260524134908164,-1.5707963267948966,0.9909070582127688 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark11(-24.202439546722907,-0.4242961697817549,-161.39459898398462,-1.0391101372363651 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark11(-24.262435921138568,-1.5707963267948961,-15.585905737215938,-0.21539680325921673 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark11(-24.337538112341583,-0.528032791681321,0.0,-0.5795047242416123 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark11(-24.375010852910343,-1.0368435132967635,-61.39607004624029,82.04397177626831 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark11(-24.540333479466526,-1.5707963267948948,-52.38230730482084,0.9090434149235732 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark11(-24.610024461248983,-1.5707963267948957,-89.43486964385066,54.32730688809659 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark11(-24.716814376990598,-0.09543564691410433,0.0,-174.47359065689105 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark11(-2.4727502546939584,-1.371489836927873,0.0,0.0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark11(-24.891998478831006,-0.4932401771628973,-67.17561209474017,-91.38871881771047 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark11(-2.4918090589598325,14.429207239593637,7.105427357601002E-15,0.0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark11(-24.927033518666935,-1.0265134876960174,-32.53147478136469,55.68704597388225 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark11(-24.993536712307424,-0.4259380893774539,0.0,47.819304167250905 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark11(-25.02441693680875,-0.26981203254263164,-21.696522520873657,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark11(-25.088017645178265,-0.22533824144001613,-1.2775584565313047,50.39469670267761 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark11(-2.510880126801566,0.43208847494610647,-78.886532147632,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark11(-25.15291195106901,-0.10833207995979088,-4.834111951066177,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark11(-25.245016318006535,-1.5296597288840346,-45.88863139428251,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark11(-25.265574429365707,-1.3802522282075476,-13.161478649700626,0.776347144227289 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark11(-25.323719642526783,-1.547484467565508,-32.9220001891408,-1.0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark11(-25.334046112840507,-1.5107004893586913,-16.683194537429216,0.027755919846484678 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark11(-2.5556364793633355,-1.570796326794892,-66.4846401388688,0.1803849430763408 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark11(-2.5564500314194385,-0.04252136322287969,0.0,-0.6533738454712554 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark11(-25.601900319825077,-0.914317360889454,-9.441230257834118,-1.0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark11(-25.60332748555512,-0.3677900728749775,-4.710693430137198,1.0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark11(-25.672396561506886,-0.14660956210257886,-11.77111799664796,0.9999999999999999 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark11(-25.6885625704575,-2.1940210491472315E-5,0.0,-0.48432486553589926 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark11(-25.843954288987973,-0.09199367631674563,-4.30049500436789,0.17032890354484698 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark11(-25.9682744481704,-0.1275095666821333,-54.52092359428431,-0.946114053472789 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark11(-26.189139514608883,0,0,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark11(-26.218732885155916,-0.1518226989294127,-20.08071933082225,85.7377186596511 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark11(-26.305392841170054,-0.05128377315142907,-67.5244405114906,-1.0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark11(-26.329814564546908,-1.3859003185935475,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark11(-26.428607850553565,-0.0764161687714835,-0.2922243994986986,1.0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark11(-2.652970951168001,-0.05076874571298928,-73.27963913460766,79.26010843929282 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark11(-26.5333350886969,-3.3330498087772566E-15,-77.1056645298616,1.0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark11(-26.540003706389463,-1.3959479605081497,-1.5707963267948966,-0.8932669937055451 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark11(-2.6603361311213707,-1.5707963267948912,-12.02761245243343,0.6940499399280209 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark11(-26.62333968227675,-1.0032997476718775,-36.061748697132366,-50.471819677919996 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark11(-26.625116632588977,-1.5707963267948308,8.881784197001252E-16,-2118.690987797363 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark11(-26.669373090930847,-1.4060830722283604,0.0,-1.0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark11(-26.736733935071708,-1.5707963267944827,-19.311721658262442,-1.0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark11(-26.759802229519096,-1.1562330866781334,-2.299013644921061,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark11(-26.778652783046148,-0.06577769478345785,-32.34400898166556,57.62803907985791 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark11(-2.6820563955029897,-1.4123144871807594,-7.006020640916759,0.9769976851350934 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark11(-26.856008814688096,-1.2002885554893403,-38.919499228818324,1.0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark11(-27.008464732245137,-0.5113913846379969,-29.901963365043926,0.819959825001391 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark11(-27.086181182402584,-0.0181613042861396,0.0,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark11(-27.243200442905056,-0.36122049210538876,-58.815802602648475,88.68808662744732 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark11(-27.378104369073,-1.5707963267948912,-34.92691157801548,0.13637783805736647 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark11(-27.41772143742697,-0.03384952938279074,-61.46831128038579,62.192789807943996 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark11(-27.42327039845957,-0.8179949251102457,-1.523296076665522,1.0000088435030852 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark11(-27.461080611847187,-0.26740062192289815,-53.947998915604565,-1.0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark11(-2.756090661631453,-0.24809513781816528,-41.2592098593493,-0.424178434966767 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark11(-27.62444090151739,-0.07154752680007476,-14.11950709398851,-0.7336103513050991 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark11(-2.7627170070689324,-1.5707963267948957,-74.47560082827933,23.401438189714032 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark11(-27.64566561531143,-1.2061524127502936,-3.0873690570261836,6.776263578034403E-21 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark11(-27.674058352947746,-0.5415283096018517,-1.3224759901444263,0.0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark11(-27.739957624208017,-4.440892098500626E-16,-1.755351179115607,-100.0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark11(-27.759593972785346,-1.0558006098754156,-73.64679142994424,100.0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark11(-27.851220596953958,-0.6885502065323581,-1.5707963267948974,-1.0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark11(-2.789061662518657,-1.2370391146168007,-76.0353175554658,0.01237336361379019 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark11(-2.7898623042890875,-0.7731110389072431,-71.43776290600476,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark11(-27.97096558362312,-1.5707963267948948,-86.9049198201044,90.31934877190213 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark11(-28.03316613636359,-0.0691533971650451,-72.33665195018914,-64.89086281813277 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark11(-28.091668625603322,-0.49645187161607174,0.0,1.0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark11(-28.101130067548276,-0.23006631278584272,-1.5707963267948966,1.0000053363726786 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark11(-28.170099078824368,-0.4567094424570892,-72.63513001171388,10.786350249163338 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark11(-28.247540896728964,-2.3048844520366486E-4,0.0,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark11(-2.832600354999106,-1.5707963267948948,-67.89994491001414,0.9999999999999996 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark11(-28.453155812157103,-0.4604095516707155,-44.87172186508165,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark11(-28.467308767956954,-0.9322417280899683,-8.623576960378099,1.0041092014839859E-16 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark11(-28.632848207225237,-0.1286516098811264,-0.9591692278010622,16.273092737467437 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark11(-2.8668862057816766,-1.3699070149120498,-53.83199713237637,1.0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark11(-28.707600826458428,-1.5353893992910397,-1.5707963267948948,0.06304694696405226 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark11(-28.82288919730931,-1.4742696627349687,0.0,0.6509876420270684 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark11(-28.845532661130008,-3.2707142460327933E-19,-63.41412392794962,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark11(-28.875006598123562,-0.28798326651994555,-100.0,1.490481261704834E-6 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark11(-28.905313539156083,-1.4606988679802364,-32.45405786180121,-34.77405359890362 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark11(-28.909882131139195,-1.3969918953384877,-96.07273675431627,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark11(-29.001798264649175,-1.5392713430406135,-1.2750199615630837,1.0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark11(-29.025746922927187,-0.8238694117919647,-44.00479795277944,0.8635954923950043 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark11(-29.07974253249742,-0.08500943493624646,-0.7710154871738467,1.0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark11(-2.911368546022956,-1.0661263360889741,-65.80126690144282,-16.4619257976052 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark11(-29.15149974357401,-1.4658297485508154,-47.38822975818354,-14.345359243653496 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark11(-29.18951850234508,-0.6175425165913289,-19.27885639281067,0.0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark11(-29.23696308753229,-1.5707963267948963,-36.09094913701591,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark11(-29.259320114778703,-0.8058370068297781,-0.707306318463722,48.23094791709599 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark11(-29.381769799986152,-1.5689044779454222,-1.0679128385222594,-0.06255591662633701 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark11(-29.394602062941257,-0.4392814465842218,-0.6988502101720309,0.024182243948616112 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark11(-2.941199266139847,-0.746641459791566,-0.12133896084297646,-0.22188186581087166 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark11(-29.4185099995521,-3.552713678800501E-15,-66.8525396664203,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark11(-29.457911161049562,-1.0764615573785221,-73.32398438773514,-1.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark11(-29.564723175035347,-1.3673333769089615,-46.346409876541905,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark11(-2.9723153421297335,-1.0925595053418669,-1.5707963267948968,-1.0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark11(-29.774782868323893,-1.5707963267948912,-71.05496863462031,-0.33094543617171945 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark11(-29.838058221186184,-0.618665685860561,-71.8803243210743,93.61232130799098 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark11(-2.9927831161297203,-0.08292686579489317,-0.06289360942020394,-1.0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark11(-29.998832933041843,-1.0683300670056135,-0.964652884235644,-1.0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark11(-30.011318682091886,-0.13122790120615624,1.5707963267948966,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark11(-30.06958156350173,-0.7319341314537039,-28.88052131860559,36.30470397246967 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark11(-30.16397031540641,-0.12275781473704184,-1.5707963267948966,0.026537230138377055 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark11(-30.34640028582325,0.11320612257860885,0.0,-100.0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark11(-30.444466409641976,-1.7763568394002505E-15,-1.4598223626405442,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark11(-3.0546843231391207,-0.014905887217417368,-23.756330377933285,-1.0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark11(-30.59764023554363,-1.2549927442893782,-1.8698262607816337E-16,5.551115123125783E-17 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark11(-30.608272046358724,-1.4769752685310535,-1.5707963267948983,0.2722972049281557 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark11(-30.648681810415493,-1.2902934516094322,-36.65451606442007,-1.0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark11(-30.66070449147567,-0.2193263261154108,-7.573070863643526,67.4031057589257 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark11(-30.698884336264165,-0.8909954178599866,-60.16569524741247,-4.573202577105444 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark11(-30.70470354798121,-0.8431355112870986,-3.469446951953614E-18,1.3234889800848443E-23 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark11(-30.785580614838963,-55.78769590052999,0,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark11(-3.086905994401345,-0.22466383658617672,-31.7416289884368,1.0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark11(-31.023804036706593,6.43468256387126,2.5741478254805445E-5,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark11(-3.1075571173957135,-1.5707963267948912,-24.049798348264318,3.469446951953614E-18 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark11(-31.11671380481712,-0.7854330255813784,-85.78958440079452,-73.15657333973928 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark11(-31.209346065793067,-0.8412606817215238,-59.855114419903636,-0.9804269305337286 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark11(-31.26549238596614,-1.4179243797310233,-66.05641330271786,1.0144851701841127 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark11(-31.312087435190396,-1.4248963183951886,-49.90145116069738,-0.01666552434159239 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark11(-31.338652661881017,-7.105427357601002E-15,-38.00225987459627,1.0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark11(-31.364728233975217,-0.4925862525372422,-67.1005163190018,-35.62910420704797 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark11(-31.380999783792532,-1.5707963267948948,-1.5707963267948983,26.036957115282867 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark11(-31.426747694018484,-0.2563120382532449,-33.11672271937786,-37.567654798446966 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark11(-31.482859537160394,-1.054581880089987,-64.64131016076297,58.148213874587924 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark11(-31.499385552876724,-0.8114825322662672,-100.0,0.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark11(-31.509911357683904,-0.7389002380034899,-94.33035402671746,-25.41038094880446 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark11(-31.61010528274779,-0.43241581726464773,-62.409255519288344,-69.63402247217944 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark11(-31.76926250829608,-1.5707963267948912,-30.049358929687045,74.13438238184263 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark11(-31.807830096003375,-0.22431589963219845,0.0,86.24832522752475 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark11(-31.815734578459256,-1.5548181712609972,-67.42036328819007,-0.18770957069091554 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark11(-31.826722058468903,-1.4396112147946445,-96.59540783772064,-40.1925826786536 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark11(-31.92575323262119,-1.4985726996661453,-26.01527053504695,-20.979688153712083 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark11(-31.95742357897677,-1.5327991538025323,0.0,0.25024980436366057 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark11(-32.050911521981156,-0.28101057141553265,-84.92426673286835,1.0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark11(-32.08128410786928,-0.2837071256022412,-30.18894588896591,-2207.408335178381 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark11(-32.227833576152506,-0.9029050196127462,-95.4768658783511,0.23537115251969007 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark11(-32.34068137872423,-7.105427357601002E-15,-29.347992409817067,-40.916115350018934 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark11(-32.342578231146604,-0.13986684006561356,-15.548170460148771,1.0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark11(-32.35595618036593,-0.31824346269248094,-24.773373259577156,39.45862975417097 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark11(-32.381787377452014,-0.17328674486866547,-1.5707963267948966,-2109.2371115171527 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark11(-32.39099970923299,-0.16376527496140625,0.0,1.0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark11(-32.41211013680545,-0.9226523938151896,-67.56047290278455,33.06832843278366 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark11(-32.51281719451426,-1.1532573934237522,-35.25311914520519,-5.293955920339377E-23 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark11(-32.54639676465717,-1.0014568229221827,-7.392900019365367,-1.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark11(-32.57116305155655,-0.9475267412269887,-5.137452069640602,1.0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark11(-32.59256312479546,-0.48487146979067774,-24.797513450870355,-1.0000000000000036 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark11(-3.2673866418087854,-0.2615309090226547,-186.92799491859427,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark11(-32.695221272276726,-1.440769308955288,-1.009530661778763,0.9106914971443372 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark11(-32.753466250689584,-0.459646632890506,-1.5707963267948983,-0.574145489819042 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark11(-3.2756100311934233,-1.5707963267948948,-24.254511215822554,100.0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark11(-32.77207224870774,-0.38605977259150154,-80.03684921666856,-0.8067945324893027 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark11(-32.79738893301469,-1.5385076756014848,-45.58094475859104,20.677351607679803 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark11(-32.821642902933306,-0.2755019171380005,-2.893913571853574,76.04233926029434 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark11(-32.882527987376605,-0.5923586473877895,-39.33617571824623,-0.9999999999999778 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark11(-32.91400545584817,-0.6057687669679166,-1.5707963267948966,-64.69302172981665 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark11(-32.94867341152767,-0.45295533150343203,-31.794163706805247,-0.062058307781057614 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark11(-32.96245060459323,-0.09752851245236384,-1.5577653646574832,1.0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark11(-33.0654321489559,-0.4234126111369253,0.0,-1.0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark11(-33.08607792834507,-1.940732330655617E-4,0.0,1286.0593789780933 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark11(-33.20197046765405,-1.7763568394002505E-15,-44.36721406867895,0.7211603472600091 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark11(-33.30924671638331,-0.36073724395544277,-28.211417553226436,-71.59646422842381 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark11(-33.31348082877924,-0.007091001692105886,-5.888182080386914,-28.070240297124776 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark11(-3.33610798204828,-0.5148942694948717,-98.4727716885905,0.9960702656805256 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark11(-33.37552619502292,-1.124160685334795,-32.238663978978295,1.0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark11(-33.61503434625013,-1.2341595458421644,-80.8152916085649,2.220446049250313E-16 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark11(-33.635233002158245,-0.9605680343291341,-45.99809976407152,-2136.587997941918 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark11(-33.749896476165866,-1.5076395034638852,-1.3139800229136311,-1.0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark11(-33.764841813634845,-3.552713678800501E-15,-39.16961780808859,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark11(-34.002398177310795,-1.4047272562730404,-99.64320711283472,-53.78776734156542 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark11(-34.013771867764014,-1.4165988034250714,-73.4566041480122,1.0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark11(-3.403420188641519,-1.0475913796909992,0.0,0.784021905636834 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark11(-34.077258813240825,-1.3581553284834869,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark11(-34.089958653352724,-0.13615098035986103,-45.55303209904693,93.5821632262429 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark11(-34.11254096303463,-1.5707963267948948,-22.936873068246825,32.646505774468295 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark11(-3.4115716842571633,-1.441430365605694E-14,-32.714161955342675,2.465190328815662E-32 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark11(-3.426620743940968,-0.6285777176801849,-0.9258285724575703,-1.0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark11(-34.29778549872415,-0.5933501578328374,-45.303958048051626,2.9525368302428774 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark11(-34.348119526904995,-0.9659369550351814,-28.99618414923242,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark11(-34.375423263577716,-0.9038542285181508,0.0,0.02767100860838262 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark11(-3.4411891083524333,-1.5707963267948912,-83.94251464021103,-0.8435370475959161 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark11(-34.42431269282952,-0.9102507746605966,-100.0,65.39115296785563 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark11(-34.42782148954423,-0.9320290161113447,-30.932299633526902,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark11(-34.491420649237696,-0.9771319240647589,-78.31333879439988,78.09438672958012 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark11(-34.608856299772555,-1.311253188340051,-28.840495627285957,-1.0000000660700008 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark11(-34.73856232964843,-1.5707963267948948,-4.405662704211942,43.77356930078048 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark11(-3.4743303533846346,-1.4003031741365866,-68.19877580902981,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark11(-34.885503612780504,-0.2782686495080283,-128.84186734544525,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark11(-34.98548007082958,-1.5707963267948912,-58.78811289667596,-0.8889385025251206 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark11(-35.07365017362642,-1.3060416520601592,0.0,-0.06255292476023666 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark11(-35.228218622205375,-0.9400890886876992,-68.93038444601937,-0.03704105221536329 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark11(-35.24865154907096,-1.5707963267948948,0.0,1.0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark11(-35.332748660883944,-0.4479305381477994,-1.5707963267948966,-13.73867364806251 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark11(-35.49589528128823,-0.30175497177721183,-97.31078330374446,1.0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark11(-35.50164679362521,-0.7270795785448527,-0.08513833149216561,-1.0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark11(-35.50513817662698,-1.5689838561516771,-4.377303911961846,0.18292475779117856 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark11(-35.51354785808479,-0.01989334273691477,-28.285192034307606,-0.015380717315685022 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark11(-35.55448462184723,-1.5583347610828604,-27.58374168710209,0.9085389008972207 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark11(-35.60532435731973,-0.8789757758693519,-1.5707963267948966,-29.897039602148404 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark11(-35.62732818231747,-0.9709662206840148,-1.5707963267948966,-8.329837733583465 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark11(-3.5630174258501137,-8.881784197001252E-16,-53.83495010166153,1.0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark11(-35.66680253679955,-1.0156422363282562,-71.96666692310663,0.5458375742630182 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark11(-35.76149691183346,-0.0510642639510097,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark11(-35.77278499686646,-1.287516151765352,-79.04816596019862,1.0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark11(-35.82567719700657,-0.07724918474674358,0.0,-3.542610917923579 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark11(-35.892137052010895,-0.2132655678358867,-17.268615310895512,53.218095303462064 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark11(-35.89664542404457,-0.08073171256047806,-88.20689254191701,-1.2862751774167211 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark11(-36.04773587554152,-1.3297898490007156,-1.5707963267948912,-0.9745003654652857 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark11(-36.077889241166005,-0.0035249748998982316,-4.241328237039795,1.0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark11(-3.610925766953695,-0.011640964046875464,-33.718282272463355,1.0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark11(-36.11761617905669,-0.16477207539187377,-49.098310484432155,-1.0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark11(-36.27611608052044,-0.558790884159279,-1.5707963267948983,-47.826927211325874 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark11(-36.415598152087334,-0.8223298470113513,-88.86376301271031,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark11(-36.417849934388656,-0.9082278927534588,-1.5707963267948983,0.01746702435691297 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark11(-36.5075004602037,-13.792785380322115,21.83516376561427,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark11(-36.55445231416304,-1.5030258811160462,-66.98530120903541,-0.9822226533159426 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark11(-36.59140549366748,-1.3241789106809132,-22.71205877395061,1.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark11(-36.637087577987344,-1.142256506463921,-52.78177222064255,1.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark11(-36.675247803062305,-1.5707963267948912,-83.91011830231591,-13.169146249823726 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark11(-36.75496647753871,-0.5178826939515635,-20.34061219131046,-0.0625613679075226 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark11(-36.7575092027735,-0.35839015832076204,-82.6863278420329,1.0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark11(-36.87440478106577,-0.039850210453465935,-32.91591632276713,-1.0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark11(-36.957422603258046,-1.4768600622422008,-32.91007283620084,-3.4219431353186043E-15 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark11(-36.98014405037456,-0.7631117043016612,-35.93331083569493,67.38211323697007 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark11(-36.992762385858065,-0.3163215447996022,-58.748434838053576,0.3986585559157182 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark11(-36.99549356150473,-0.013127631888085009,-53.92256597386401,1.0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark11(-37.0088437370652,-1.424024375277554,-58.75506030591032,-1.0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark11(-37.01514661308246,-1.5034157039866913,-40.79146525964302,9.495567745759799E-66 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark11(-37.04960156253402,-1.4802598823698148,-66.09688012959482,-1.0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark11(-37.17678593049351,-1.5707963267948948,-85.23465944980785,-26.80715564625931 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark11(-37.201296286741695,-0.35977753873923457,-16.066882435447567,-68.29277450352394 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark11(-3.7232971861357065,-0.3024522677760111,-38.951484950977715,-1.0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark11(-37.27833267394372,-0.9270546821107218,-59.28250220100813,0.020503887170263413 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark11(-37.34569894925739,-1.5707963267948912,-40.75386222070533,86.88188122359435 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark11(-37.34691491779937,-0.6177073607331101,-78.33244692251048,-0.4560436061315829 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark11(-37.35392795263733,-0.8750382438373615,-10.700371984562128,-65.1577196991536 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark11(-37.47403396486889,-0.07820250404336371,0.0,1263.8256202038312 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark11(-37.47855272906706,-1.5236065518353161,-58.09989623172353,41.90869436509555 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark11(-37.53317950467012,-0.23983817563060938,-0.16062107160824868,0.0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark11(-37.55914787663404,-0.15468060635470376,0.0,-26.47012845564347 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark11(-37.60830892360088,-1.5707963267948841,-5.2114242413677285,-45.918461318270246 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark11(-37.61981653816611,-0.07465703841217985,-46.767345057951104,82.9530583586924 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark11(-37.70005774839322,-0.42590715896641873,-93.93575025060842,-0.037465884533724514 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark11(-37.83045440114923,-1.5080921059792776,-30.048438905569153,1.0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark11(-37.844168674886916,-0.5432261486117858,-100.0,-61.04207947473597 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark11(-37.93726319142077,-1.009518327760999,0.0,0.9659786706309573 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark11(-38.11977573052627,-0.23720797303383934,-71.52075098391745,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark11(-38.1592300912176,-1.5311424500068378,-40.70307849028501,0.8707873204620767 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark11(-38.161614529022174,-3.2383020937368256E-4,-73.59661752804773,-0.9835103500006094 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark11(-38.307822130281835,-1.5705292472199552,-53.58175898301065,0.8519385712229772 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark11(-38.49405837347244,-0.29369985947146576,-36.13160968101907,-67.53446017740416 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark11(-38.59520704528995,-0.8065779880246797,-101.8930632215805,-0.7992421767150191 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark11(-38.702128693625426,-1.507641957171854,-71.9430733820237,0.41292105856087025 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark11(-38.84597747357831,-0.5242780913994592,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark11(-38.89182476277628,-0.15412326633719386,-123.83601845596517,-168.02941225679587 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark11(-38.90512373064315,-2.7610131682735413E-30,0.0,0.0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark11(-38.92871700966788,-1.0077883441268263,-73.3250717632471,-1.0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark11(-39.179372526617584,-1.57079632679487,-45.61820709980968,-0.662372644167867 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark11(-39.20542255521897,-0.42310002844609834,0.0,70.77467296379673 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark11(-39.212110969702984,-1.5707963267948957,-74.96962372831848,100.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark11(-39.22502851881367,-1.144116353985905,-64.5267198885858,0.0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark11(-39.458581244481984,-0.27361089678580086,-19.3938357407726,42.314803930562846 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark11(-39.47896026073939,-0.33360606995231823,-17.365192690460887,-46.47974561815951 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark11(-39.48118832078291,-1.5707963267948912,-75.7824240124384,-66.17972015611599 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark11(-3.9494997614098217,-0.16158325220483405,-1.5707963267948983,2226.1848279129704 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark11(-39.505597106390454,-0.015048228303859882,-0.04434541952162402,0.8609330713925566 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark11(-39.618212922493655,30.22752156037768,0,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark11(-39.622513448536466,-1.5444760837044647,-100.0,-1.0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark11(-39.64295480051525,-1.5707963267925393,-94.17825842419325,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark11(-39.66803116161793,-0.032185625812028454,-14.312454154437814,1.0000053293568842 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark11(-39.67107468638894,-0.007261135847835602,-50.39746806601477,-28.501876556774143 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark11(-39.72333013516581,-0.9608173006646297,-9.588128068075108,-31.985915721500074 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark11(-3.9736518310182873,-1.1470041741930852,-47.20795920475608,68.12114353980623 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark11(-39.827331591007095,-0.5386870355145914,-46.57905773608853,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark11(-39.842736877430106,-1.2142424441604638,-1.384697442848826,-0.19243708109308366 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark11(-39.871575680493116,-0.29059905441754813,-33.14874964338546,-0.02537221524947117 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark11(-39.96893370637112,-1.1396959986571331,-12.675439514947385,-1.0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark11(-39.975122427392044,-0.597771266537096,-80.10348560181247,0.05014819055053092 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark11(-40.000708688610814,-0.07097745164264109,-74.62359832025993,0.016114103843761995 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark11(-40.017737354065765,-0.03688381515880748,-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark11(-40.04545900519723,-0.2793419384640655,-1.5707963267948966,78.35221888053532 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark11(-40.06053941736699,-1.5707496434536286,0.0,-0.37265155850460463 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark11(-40.079292245312864,-2.193604522951202E-4,-93.28981245891954,0.5772167436492803 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark11(-4.0228556889415055,-1.5358750078716492,-9.855235835973106,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark11(-40.25109088452319,-0.037030387809352305,-74.3661642943598,0.5169411506045534 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark11(-40.334216871531744,-1.5329556681124359,-17.37108088733575,2253.452104220424 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark11(-4.044307083529376,-1.4064763580872945,-1.5707963267948966,-59.0687585227726 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark11(-40.51111472724545,-1.2643890487898908,-78.84381245250364,-1.0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark11(-40.54416536695958,-0.039764901455505486,-73.87036250483243,13.506574075197271 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark11(-40.607885330925136,-0.5725062049411456,-90.46642191666115,-0.18876163111119126 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark11(-40.63768906133022,-0.8206259439086478,-39.50258761598587,-1.0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark11(-40.705759379876355,-1.5707963267948957,-28.56351751323983,100.0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark11(-40.887140851913564,-1.5707963267948948,-26.410108183922013,33.231176654053456 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark11(-40.899250374296045,-0.554234188046677,-65.6902180616724,1.0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark11(-40.97679564852456,-1.4289232197584454,-66.19387800328182,47.63654148778974 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark11(-41.07577555491493,-0.017044387601311373,-1.5707963267948963,-0.246287874438458 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark11(-41.091629165705235,-0.7100128062849668,-94.50261047321627,-7.439183053759699E-16 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark11(-41.149648501968464,-0.2570834319578492,-8.059357388689719,17.434386623636556 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark11(-4.1193059580840306,-1.5707963267948948,-0.0011383025983918646,-100.0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark11(-41.23753109358432,-0.2694739426695474,-95.47363310602644,-1.0000000000000007 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark11(-41.246517119920235,-0.4923045895959156,0.0,90.7931835514654 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark11(-41.251420226991236,-2.220446049250313E-16,-27.656499406291648,0.25561652600294726 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark11(-41.39175453189654,-0.8247775082455701,-4.093136953584999,100.0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark11(-41.426620127014786,-1.5707963267948948,-40.94194253753933,-1.0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark11(-4.149444488750746,-0.7997642994338481,-0.9474034811762237,1.0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark11(-41.592283411198174,-1.5707963267948912,-1.5707963267948966,-1.4426529090290212E-129 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark11(-41.79592071225365,-0.77125510714679,-75.43205616407292,-2256.868067413519 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark11(-41.88517631858835,-1.098360898776285,-91.16155995966349,8.470329472543003E-22 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark11(-41.904772149304506,-1.4600862365914176,-71.44086592854795,-61.24641389780518 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark11(-41.90932207996085,-0.07319211920312149,-33.055760307683116,0.6687273303977201 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark11(-41.93427689020899,-1.5707498509308013,-95.27319709549528,-0.8084739485508571 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark11(-41.937394682244665,-1.365536594340931,-2.9335313802056797,-1.0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark11(-41.971851041074146,-0.25259838240612403,-53.511263903661266,42.10051540383729 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark11(-41.9978778780853,-0.9643730406293565,-1.3167938149776937,-0.9999999999999998 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark11(-42.04374273358745,-1.5707963267948963,-0.6484713053757732,0.6021058320431971 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark11(-42.19516494372338,-1.4434999953094898,-73.80987333260285,1.0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark11(-42.21900282734112,-0.059017467741804094,-83.30051169005182,1.0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark11(-42.25461951840944,-1.3796023464221285,-94.51650890413534,1.0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark11(-42.28543077312521,-0.7328132969473033,-1.6443888509572133,-1.0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark11(-42.301797729587285,-0.7897503328030382,-1.5707963267948966,-14.579623948837295 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark11(-42.30587152534621,-1.3770210336744917,0.0,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark11(-42.36896357852507,-1.5707963267948963,-1.0573603199719868,8.881784197001252E-16 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark11(-42.38288792241663,-0.9209925677050996,-0.7810766926159438,-0.9727771980007396 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark11(-4.239091338864171,-0.13991318961599358,-28.17959890073402,-0.11276194469471079 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark11(-42.46337209458846,-0.5789696198809127,-60.12988084780484,0.26974438531015066 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark11(-42.47789457267734,-0.05873537484125227,-7.086872501533776,84.87680058859343 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark11(-42.48378707533468,-1.3855176406488705,-16.05399215499288,-0.9638173580859363 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark11(-42.504465144014475,-1.5707963267948948,-67.61017220645245,-1.0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark11(-42.52255777859133,-0.022883577924713183,2.0771716689536648E-4,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark11(-42.5675977180958,-1.4826148085454562,-15.318463891329941,6.001079713518351 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark11(-42.605283641855465,-0.776698316453418,-61.75212621610806,-0.8470554779714019 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark11(-42.62107065676214,-0.08307155795453601,4.712388980381542,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark11(-42.686851026703906,-0.5303228101152879,-45.50291827282805,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark11(-4.279466833817253,-1.5707963267948841,-93.69879779136706,-93.18157582507729 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark11(-42.825034718622604,-0.8035785859963998,-0.39852541373047845,0.05454527210027878 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark11(-42.89768678183393,-0.8854408084985081,-37.8820192306923,1.032525714863101 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark11(43.00481869294853,-79.8639371672708,-69.80630689651741,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark11(-43.07246783859115,-1.5707963267948912,-74.9361313549926,-62.18532318081505 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark11(-43.12818464196467,-1.4855817376405127,-9.904069245084074,-1.0000079228834091 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark11(-43.14720778710537,-0.3744729780037202,-0.2001290023710254,1.0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark11(-4.31481331260925,-1.3690126867494357,-4.642736150655971,-56.11322767442677 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark11(-43.1776461891097,-1.5348751435323058,-30.407409452930292,-0.029320409273911507 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark11(-43.19230971070673,-0.4359193919737123,-98.54563125500249,1.0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark11(-43.25568896912461,-1.7763568394002505E-15,-1.5707963267948966,-0.9999999999999989 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark11(-43.33125871788713,-0.2017262939562951,-40.4656061179777,-6.865194209231361E-16 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark11(-43.349315043690375,-0.5227482889934083,-88.23877192497427,31.405535680032187 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark11(-43.365074627907035,-1.5707963267948912,-49.8410374052483,-83.38297897388647 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark11(-43.36670788701321,-0.9176413603137877,-62.6654787519949,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark11(-43.37622693789307,-1.020057754463568,-44.361388149660954,-75.01103175202857 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark11(-43.48793855380784,-0.11925740097611821,-53.831810558073244,5.852095443365248E-98 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark11(-43.48990347274312,-1.160628138519936,-123.72323796213317,-0.3987149518438309 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark11(-43.52123357591394,-0.9971129404441483,-1.2035128362308374,-0.00414730157193853 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark11(-43.67737679603176,-1.5707963267948912,-30.694190319860436,-0.427417845872621 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark11(-43.70699958054297,-2.220446049250313E-16,-61.747606730679394,0.9821062016212909 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark11(-43.81346482091715,-1.5707963267948912,-214.8092848277539,-0.9999999999992258 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark11(-43.91485731853609,-9.398663353116871E-16,-34.34510690898311,0.5235603675945413 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark11(-4.402986405507576,-0.5110811821174234,0.0,-72.42719746462242 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark11(-44.040756984814635,-0.2660983323439967,-86.47532926336177,2125.6975944739256 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark11(-44.13207565014858,1.3179330770448459,0.0,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark11(-44.14860280010005,-1.5707963267948948,0.0,-2.0499375455304634 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark11(-44.19203077973659,-0.04730210315889305,-55.72489875136044,-0.036558144132822185 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark11(-44.26246018993858,-0.13071270762666734,-1.5707963267948966,75.00782176244064 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark11(-44.27735433114488,-0.9346025783916414,0.0,0.8282524958537074 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark11(-44.460108288858585,6.504103985853981,0.0,-0.9700229220664591 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark11(-4.449812779148271,-1.3741373442522418,-0.01019446800234686,0.044617286338086454 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark11(-4.46520209795951,-1.002918881812736,-95.79614902012754,-40.32909477988467 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark11(-44.70301124883714,-0.8768223952025207,-35.59582249257514,-6.348414552405401 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark11(-44.7103514520687,-0.8191526541972216,-72.28029664326522,-78.14909272045335 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark11(-44.712575649750576,-1.4872811395115744,-40.19766038995181,0.9999999999999727 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark11(-44.74195292288138,-0.19921509939345916,-71.94753678425901,1.0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark11(-44.79702271208215,-0.025609883015331736,-27.667890991924565,1.0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark11(-44.824638681968125,-0.03084079878880948,-45.45528865219401,0.656623345417259 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark11(-44.89115196749421,-1.1853529519143382,-12.417465081844021,-1.0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark11(-44.90493457292662,-0.3525488469660827,-156.16295067526116,0.002276567085940706 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark11(-44.90625164748277,-1.7763568394002505E-15,-4.71238898038469,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark11(-44.911732942055565,-0.3691949236368352,-0.21638449271839622,0.20545767901407008 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark11(-44.9159818313366,-62.31586438485941,0,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark11(-44.98953377718752,-1.5707963267948932,-14.946892270008917,-1.0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark11(-45.1080125140296,-1.1919034902743062,-0.6450664514852158,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark11(-45.118459307304114,-1.1877664291127774,-101.69716719563671,-1.0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark11(-4.515652360396138,-1.1073197833938553,-89.89965518928196,-1.3832918996118426E-7 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark11(-45.19015157254711,-1.5707963267948948,-77.35109275449162,67.3991175852783 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark11(-4.521966420155538,-1.1577247423448256,-81.27985179628125,-0.18855109651751523 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark11(-45.25242539259915,-1.5707963267948963,0.0,-1.0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark11(-4.525895123027258,-0.6289958692305678,0.0,1.0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark11(-45.40443553514548,-0.09389768212068383,-12.480200580524617,-1.0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark11(-45.48300160210331,-0.15750129798101664,-20.201067209542973,-0.950654857378612 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark11(-45.53978852529625,0,0,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark11(-45.540924733508994,-1.5707963267948912,-21.30454296163042,1.000000003173042 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark11(-45.5580723535703,-0.571185038127493,-52.20469940990742,-1.0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark11(-45.640612788877874,-0.009958163296800668,-67.61335064427777,0.23336815676922396 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark11(-45.65092056025345,-1.5392098781783288,0.0,1.1059468197005092E-16 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark11(-4.566370894011854,14.431689070361209,0.0,0.36267769153639406 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark11(-45.80789839165277,-0.3957121179766257,-22.30164881001879,0.0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark11(-45.85721975658336,-0.657190641456447,-1.5707963267948966,54.403606452496604 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark11(-45.986110627895556,-0.867594981738175,-44.99441185366937,0.0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark11(-46.03147409091968,-0.5637641268030709,-24.646910308391213,-1.0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark11(-46.09167413621767,-0.7393500967702383,-2266.543043465292,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark11(-46.18670539911187,-2.7755575615628914E-17,-9.801203380176345,-0.3994924882060942 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark11(-46.198208634740226,-1.2388875203093912,-17.988533972284543,-0.23541225670701404 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark11(-4.622663599043655,-0.2235894947359696,-74.97978650216439,-0.9924604938934798 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark11(-46.331768887797004,-1.5707963267948957,-49.64286160810537,0.03722389684150294 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark11(-46.34976328020277,-1.0105391669189094,-85.04633572911182,-28.60780077506257 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark11(-46.445394979676365,-0.9851389669536581,-47.12340234880074,-13.41341975298134 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark11(-4.6481525788095865,-0.4640715496523747,-64.73387005340342,-0.06342371103084585 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark11(-4.657041439310986,-0.05629130443466279,0.0,0.9791691108819351 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark11(-46.66547975254272,-1.5707963267948961,-71.69798743562063,0.057742621045451914 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark11(-46.6789777200491,-0.43786268614855006,0.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark11(-46.71728178460204,-0.5672622317921974,-22.052968431244814,-25.79184620170964 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark11(-46.727832733785874,-0.022581198005851885,-34.89374104702779,-0.3621997483478382 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark11(-46.786133096440295,-1.5705458665117362,-0.3350871952269566,0.0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark11(-46.80167412015687,-1.252223370812011,-11.246160725440774,0.9999999999999999 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark11(-46.81844524004029,-0.005690656021316256,-100.0,-1.0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark11(-46.85221436892288,-0.6425407132610201,-85.02217921324541,0.005609279991578342 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark11(-4.686118436444403,-0.02870988198799687,0.0,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark11(-46.88997878350124,-0.4583083068419338,-1.5707963267948966,0.5085927938603736 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark11(-47.1295281503798,-1.5707963267948912,-75.40015322965859,0.04249451272344018 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark11(-47.40715179049353,-1.1074310571196326,-1.5707963267948966,62.91968524201289 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark11(-47.45897431310021,-0.20313736451208964,-14.838250342871984,5.551115123125783E-17 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark11(-47.63349192120101,-0.8443777421780365,-79.71659244955703,-64.21310681034771 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark11(-47.64277708832564,-1.5707963267948912,-60.8460513358869,-2296.5197264555122 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark11(-4.766933612893669,-0.0011543425599073447,-60.80754578118424,-2156.083563448057 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark11(-47.70770854326252,-0.22424454256074847,-43.84987295487333,0.7480109083463828 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark11(-47.75044141435495,-1.229405839035921,-6.196145992376993,0.5784945414898193 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark11(-47.770178610394424,-0.1228687452846115,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark11(-47.78271247021044,-0.6599090855987646,-39.584673366399215,1.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark11(-47.798635161539224,-0.2042716872746344,-0.7786362517325786,1.0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark11(-47.85477278965694,-1.5707963267948912,-25.265667364463006,-15.655863969972659 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark11(-4.789632420722049,-2.7755575615628914E-17,-48.358587424216125,1.0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark11(-47.91935907719121,-0.0790107820856216,-9.69457759319667,1.0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark11(-4.797918955576689,-1.4954445546791841,-31.950531202837148,-0.9999999999999929 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark11(-47.99779152414486,-0.07848782807200827,-44.5232827735939,1.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark11(-48.03489585285921,-0.4436806987585779,-32.95253604473715,0.0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark11(-48.03655738623769,-3.552713678800501E-15,-20.816788617298016,-71.40343468217588 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark11(-48.03933944156698,-1.0447807443087958,0.0,-0.9999999999999993 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark11(-48.10875441332374,-1.1382987193678336,-12.946018063224571,1.0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark11(-48.11241732123537,-1.5707963267948952,0.0,-100.0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark11(-48.14166411196415,-0.09713039628406302,-84.58005242909275,-42.47636848489071 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark11(-48.29848802820612,-1.5347283127415916,-1.5707963267948966,-0.3921823027592679 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark11(-48.32284409583677,6.452395902510529,0.0,-100.0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark11(-48.406207994383294,-1.5284932599184913,-96.41478811425745,1.0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark11(-48.41843683116878,-1.165574487242509,0.0,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark11(-48.49115380555122,-0.43560494303516073,-113.70952340358193,0.3678862554258794 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark11(-48.537474660057065,-1.4210854715202004E-14,-68.4171431657083,-29.8096098956852 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark11(-48.53828831002102,-0.06310588979981946,0.0,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark11(-48.54886330120149,-0.7257735505597884,-49.12539174362727,0.9999999999999996 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark11(-48.6043370528378,-0.5906517891799403,-39.67224559178884,-53.18389596801039 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark11(-48.634178106972,-1.5671210266811522,-1.5707963267948966,0.9819912335228412 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark11(-48.66627871396153,-0.5860898136692768,-67.90628153473631,1.0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark11(-4.872436029849581,-1.1379227873776672,-31.334387503434797,37.327447637547294 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark11(-48.72682269046824,-0.263169032841013,-44.93972870003251,1.0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark11(-48.76421782680517,-1.0759282900345621,-94.79735034975062,-0.901612965393132 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark11(-48.7987848156928,-0.9628849907329828,-10.047732871452098,-0.10933194655705947 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark11(-4.880299957093182,-0.12602901802632438,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark11(-48.96497011398111,-0.4260053371709728,-5.546028338319459,1.0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark11(-48.9990939112425,-0.3237906335872099,-1.5707963267948948,1.0000000000000009 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark11(-4.905716810230203,-0.6633575959299804,-1.5707963267948983,65.64553903011705 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark11(-49.16842237057532,-0.029109996374987568,0.0,0.03536948634351523 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark11(-49.18550396265689,-1.1561402082572052,-1.0393699569152748,-0.9934818983419955 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark11(-49.21716820572337,-1.3032874727035333,-101.8212658569137,-0.9995187567162378 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark11(-4.931313171437964,-1.5699513231003994,-95.78748633143776,0.40173123601263927 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark11(-4.933141927668403,-0.3868413522264662,0.0,0.5685483412289 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark11(-49.360257904191336,-0.34822612064203323,-0.1493932391723283,0.8148348133547656 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark11(-49.42918879215825,-1.7763568394002505E-15,-54.30806060175547,0.7847515803241123 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark11(-49.43598723926688,-0.1186714657280678,-46.93747342307321,1.0000000006002052 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark11(-49.44962448904727,-0.5237502290225406,-95.25253367015537,-0.007840395473911771 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark11(-49.56980383891859,-1.1102230246251565E-16,0.0,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark11(-49.64266946632873,-0.3733311550015778,-95.42279333091737,9.619224615916682 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark11(-49.645123957986954,-0.7798390918039738,-20.93566570504168,-0.8771274124647217 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark11(-49.684462014880054,-0.15174404303673228,-134.05087559800518,-18.68723201333247 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark11(-49.69567704590718,-0.09986546768501149,-45.38190811897262,58.7805097517004 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark11(-49.871370180640284,-1.5707963267948961,1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark11(-49.87566534959649,-0.472232977499059,-87.08890797756277,-14.761352828398046 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark11(-49.87825834792192,-1.5707963267948912,-6.961718584536342,-56.20472149651818 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark11(-4.991135006099131,-0.030282315462475406,-47.47412864932951,1.0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark11(-49.925295213028,-0.5586502270164273,-92.73759580334465,-33.223612253295116 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark11(-49.98313738297495,-1.008789176276453,-82.2545192113112,-0.019446662225930184 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark11(-50.12191242771451,-0.7364904059943808,-0.3062561112072237,-0.06033082066129375 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark11(-50.148791165161256,-1.3707359289207488,-8.299406933627935,0.9999999999999986 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark11(-50.17332083725992,-1.413870063147299,0.0,0.009304807309312935 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark11(-50.18241427315675,-1.4699729969515118,-24.10113886490941,-2257.8198411187213 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark11(-50.21169864004531,-0.01271430104746507,-73.7764768551603,-3.3087224502121107E-24 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark11(-50.23326041052805,-1.5707963267948912,-8.501284615194976,-0.6327470981701993 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark11(-50.29425726641063,-1.382918041141544,-17.094730012602874,1.0190026500582152E-5 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark11(-50.322753768239494,-1.5707963267948957,-15.012900513846366,83.30899400167544 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark11(-50.33481188468444,-1.5707963267948963,-0.015877580827305345,-5.852095443365248E-98 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark11(-50.363978045910564,-0.052862151748235164,0.0,-48.385683538216384 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark11(-50.388951846558015,-0.1309396722783136,0.0,-0.4710003487575425 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark11(-50.42410611893898,-0.14518738680551155,-11.634618081719992,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark11(-50.456204206186015,-0.12053112048431558,-1.5707963267949054,33.87402408928705 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark11(-50.48403220360842,-1.5230350147837495,-70.6914017147206,-68.83441886748167 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark11(-50.66716517289625,-0.507377818030661,-85.28587580354217,1.0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark11(-50.68003126197563,-0.08550706324568493,-1.5707963267948966,-0.4364438574068146 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark11(-50.7453082556533,-0.13208044111253028,-14.905119025666444,1.0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark11(-50.76111602577501,-1.0554342275907826,-26.82292122268734,-0.006250159372870656 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark11(-50.81684149349872,-0.924379993094436,-16.972780192017623,0.9516804748513371 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark11(-50.85664049578344,-1.5707963267948912,-75.2559040830864,-41.81043292320436 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark11(-51.05982843192481,-0.1293473127153929,0.0,13.711650737740097 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark11(-51.064066612306156,-0.3204062512089745,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark11(-51.08365100025682,-1.5378659534036558,-37.77097332862694,0.9993310518009273 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark11(-5.110174713302193,-1.5459643397997809,-39.1882976768523,-0.8815986568338229 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark11(-51.13928889290965,-1.5707963267948948,-5.828170884821141,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark11(-51.2426467242214,-0.6259629582902075,-153.3357654997546,0.9999998843874948 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark11(-51.30760221773362,-1.570796326794893,-68.58764061419988,-89.65413528349345 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark11(-51.57038383783309,-1.5707963267948963,-96.61737059653198,75.47094322370111 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark11(-5.159334121501309,-1.1676404655376116,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark11(-51.59522486302994,-1.5707963267948948,-12.502281124903774,-0.9999999999999858 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark11(-51.68009564673535,-1.5707963267948948,-59.33480060322836,-1.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark11(-51.79143469615416,-1.5273078676234606,-93.3215572830953,0.0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark11(-51.79966300880879,-0.19625572354307913,-4.138600868986913,0.6698144144072722 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark11(-51.856860942485554,-1.4209785013091414,-75.79996770141639,-46.34480275854551 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark11(-51.96596637510631,-1.5707963267948788,-93.23719908589031,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark11(-51.96713756381028,-3.552713678800501E-15,-1.5707963267949094,81.61036437721765 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark11(-5.20668630837364,-0.5439903925759038,-34.43277251994176,-1.0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark11(-52.08801783656718,-0.3830344801518262,-50.43035868571803,0.6768395382535175 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark11(-52.10517869643921,-1.51028075564221,0.0,0.5228751642813778 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark11(-52.17326022379357,-1.5707919383710425,-31.978155512908497,-0.10602130918088717 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark11(-52.189469060844054,-0.7610346037951707,0,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark11(-52.26220099352061,-1.3318056008606842,-120.75404721206137,0.03308765953896528 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark11(-52.31433242710945,-1.5707963267948948,0.0,0.11100258665733853 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark11(-52.36407150388939,-0.6238204465675856,-22.482313790507302,-0.5690524888957356 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark11(-52.38137147225683,-0.044609953919412165,-0.04941138168583768,-49.163833689344585 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark11(-52.404958746946484,-1.5707963267948963,-33.76391210413438,70.7811327315885 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark11(-52.443366485051946,-0.045625198955447276,-84.91752115197565,-5.403553307257669 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark11(-52.47342011966545,-0.8251540368871355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark11(-52.4967825483573,-0.23836422891738818,-43.729552050435,-0.2510258599193751 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark11(-52.53421894698466,-1.038511934085689,-73.6039228308714,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark11(-52.542694424860734,-0.35339393070514474,-35.25108125021271,-1.0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark11(-52.55065623434456,-0.5869343426769258,-4.247764603941889,1.0000000000000018 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark11(-52.63374069176108,-1.2440082652625806,-0.03806175709515963,4.976877430476906 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark11(-52.64128484134191,-0.0173045083327842,0.0,-0.9999999999999996 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark11(-52.72613118011043,-1.5707963267948963,-84.40503332124554,-1.0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark11(-52.759697917214396,-1.1196227226804147,-83.78384157594377,-1.0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark11(-52.88329696950113,-0.6460021486411255,-73.3866554446115,1.0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark11(-52.926358011147116,-1.256721686744116,-157.55798041264532,42.83286356713734 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark11(-52.98655533794913,-0.18825135567956974,-1.5707963267948966,-0.04042437665690646 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark11(-53.023897019524505,-1.570796326794891,-28.73391828873343,-0.3087769757284945 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark11(-53.02643900189426,-1.5707963267948877,-13.646346535429316,-11.090980339852962 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark11(-53.18419015901402,-0.10325130095084867,-68.04135682794754,0.8695110371815343 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark11(-53.20093962452561,-0.44986841021408797,0.0,-0.04405011469500717 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark11(-53.224054934701435,-1.5707963267948948,-90.76580386510578,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark11(-53.23274008640409,-0.8784115758846912,0.0,0.764350807528632 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark11(-53.28737447337717,-0.44086598223906265,-31.597924187388692,0.0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark11(-53.2954063919958,-1.0230351117154726,-2285.4227017938047,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark11(-53.31163194891958,-0.7208842703724352,-1.9442640431333018,-0.39204767757334547 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark11(-53.35303595035249,-1.5707963267948948,-84.74706002076863,-1.0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark11(-53.46699467882716,-46.80866538336441,0,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark11(-53.59507280255436,-1.5707963267948912,-61.89114810508062,-1.0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark11(-5.368625341335513,-0.48188180429529837,-1.5461601977751513,-0.21513458343384984 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark11(-53.70140216032909,-1.5707963267948948,-31.975611029264122,-1.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark11(-5.376927292629639,-0.24834739031052422,-95.55104661876925,-1.0000000000000004 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark11(-53.807780249296506,-0.046323682844130167,5.551115123125783E-17,-1.6157642949382904 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark11(-5.383896879995149,-1.570796326794896,-1.5707963267948966,0.3153874577778577 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark11(-53.8646202639244,-1.5707963267948957,0.0,-1.0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark11(-53.90788011028987,-5.329070518200751E-15,-38.19788798962645,-1.0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark11(-53.91898490674347,-0.6453818919472937,-42.38885198510882,2308.8169424911734 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark11(-54.03225776612707,-1.5707963267948963,-0.9332563101793715,0.12496544445392277 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark11(-54.06563797697909,-0.7815381363026828,-53.55691373015736,-100.0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark11(-54.10876584944405,-0.8639141132171516,-23.860431583051948,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark11(-54.13362570673013,-0.4929688573977167,-100.0,2160.594541766279 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark11(-54.161314453380086,-1.3145160724983669,-61.46585223510458,0.5553631363698428 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark11(-54.173382120922746,-0.0022767732694693476,-1.5361492021171599,0.7057893546888754 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark11(-54.17593779503705,-1.3162681482601346,-74.60173387879657,-0.11236105794832874 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark11(-54.1813803600234,-0.29465017005453653,-46.52071102555781,1.0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark11(-54.29573710599411,-0.20502055166228672,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark11(-54.32327284197838,-0.7238311236120385,-75.27113943142263,-54.53080932190062 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark11(-54.333902666510056,-0.08603564241213224,-11.04455548262358,22.273898499966506 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark11(-54.35950113195288,-0.16806382727816577,-91.57454617041228,-0.03262743863938769 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark11(-54.52053193815332,-1.4335533824598239,0.0,-0.053410133384809017 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark11(-54.53975545338838,-0.830176180443587,-77.53508895343745,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark11(-54.562902185451044,-0.08948113943072257,-0.9983682540873408,28.37272951775969 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark11(-54.571112593509184,-0.44837179338058714,-33.4787793729117,-39.96240744933421 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark11(-54.71980657087858,-0.584482475836718,-10.927194848984819,-0.7468030180855906 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark11(-54.87678080052846,-0.9208295881685131,-1.5707963267948966,28.056466862291288 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark11(-55.044418766782684,-0.3743495054785165,-34.24822671166068,1427.8086810975774 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark11(-55.083481779968366,-0.21964733846420473,0.0,-0.5964844125101181 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark11(-55.100467150067956,-0.4011409712537819,-73.76860394751026,72.6203166841905 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark11(-55.13753549534328,-7.105427357601002E-15,-37.75509072589662,-65.14776469495564 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark11(-55.17970248748899,-0.3797193326730106,-59.387714712780095,1.0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark11(-55.214017865422306,-0.005035351954696843,-67.32826895177476,97.82344980291606 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark11(-55.54156757699804,-0.1960170484151632,0.0,-15.58775836175488 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark11(-55.58457444978,-0.23172441362539153,-83.22873743522909,1556.4468374445512 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark11(-55.901284134268934,-0.8002030458117595,-60.04808448679761,42.19743022009504 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark11(-5.591141261079272,-1.5270761578040914,-61.36489787510095,-2326.446987162207 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark11(-55.92824494899391,-1.3537133895102032E-16,-80.54255745995562,-1.0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark11(-56.0139052462234,-0.9903122745469379,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark11(-5.607430752536139,-7.263151439723347E-16,-37.131114040161336,1.0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark11(-56.10256710892301,-0.30142909331927337,-56.11166452118279,13.759116705543317 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark11(-56.14306311122246,-0.22044336621156238,-56.288418594163275,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark11(-56.31531400437025,-0.7658267207802797,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark11(-56.34422372575693,-0.10955265895601046,-8.881784197001252E-16,7.561179890716048 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark11(-56.36189971894718,-7.105427357601002E-15,-19.82772331975859,1.0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark11(-56.40250419584585,-1.5707963267948895,0.0,-0.9383339389358479 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark11(-56.42686118196058,-1.5707963267948963,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark11(-56.44582202754513,-0.07718958901726242,-51.04859456955779,0.1974314652662965 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark11(-56.45024261032854,-0.610500460731974,-24.98003989201807,0.831197757811464 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark11(-56.71212643279701,-0.21723847624742354,0.0,-4.630108892385795 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark11(-56.73862981717207,-0.4743588554946143,-1.5452345747386786,-1.0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark11(-56.75504094028985,-0.6655247600639393,-1.5707963267948963,27.01887357795621 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark11(-56.78593078120666,-0.30649383938651376,-1.508289145193302,-18.068147510674763 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark11(-56.84603122392895,36.686245898814946,0,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark11(-56.855976980983456,-1.291617287301011E-13,-1.5707963267948966,11.84651351944482 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark11(-56.94807872431052,-0.8210984276746112,-36.710711333992194,-1.0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark11(-56.99858769975624,-1.5707963267948912,-1.5707963267948966,-0.9888969935901545 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark11(-5.710465637457,-0.08917093065161175,-47.850271730483456,-1.0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark11(-57.195307407076115,-0.6906333324753087,-1.2284445143256466,84.64341833438944 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark11(-57.383445578640746,-0.8715975290566927,-73.68079690228294,0.06230628620687211 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark11(-57.533997014974695,-0.2067106433163078,0,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark11(-57.56615115351,-1.042285706702672,-39.66284793325549,0.0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark11(-57.633693517912604,-0.9053714759317136,0.0,-1.0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark11(-57.65956728900286,-0.6696228864354925,-76.74544929285928,1.0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark11(-57.67553004635386,-0.8156908642041301,-40.55033979812488,-1.0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark11(-57.7058740464421,-1.5707963267948961,-97.08197077322419,0.0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark11(-57.81980856863942,-1.5707963267948948,-74.93337997186798,-6.720974592010346E-4 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark11(-5.791925825119453,-0.07396951480008213,-58.93353293321388,-1.0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark11(-57.92713805963161,-0.12437654375912782,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark11(-57.94834671021152,-1.5707963267948948,0.0,-63.694891816410106 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark11(-58.00977417997685,-1.2467461266468027,-1.5707963267948966,-19.226106593106287 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark11(-58.03818024169538,-1.369376344782146,-99.45062463618996,0.7134176336574654 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark11(-5.807440736653292,-1.5707963267948963,-1.5707963267948928,0.4184839877261277 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark11(-58.207952493267385,-0.05439132139210234,-20.66679646642937,22.70192326653316 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark11(-58.386923678430925,-0.8579541699355633,-45.060747290494724,-35.07421994258047 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark11(-58.395679050346104,-0.0036268761002516275,-60.6312501762805,73.44619529373705 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark11(-58.43923658274204,-0.8532695036346833,-34.48531083705542,-0.3620991862092825 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark11(-58.51435320726628,-0.2182557064653956,-100.0,-1.0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark11(-58.59780037317551,-0.27839414992190875,-66.45231819107457,1.0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark11(-58.64603604439711,-1.5155510958063303,-136.92562593408087,-83.6459219833875 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark11(-58.72679006169836,-1.0090895630587133,-52.06585243975752,-0.8502691827384294 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark11(-58.75370068228416,-1.5707963267948948,-88.15041403257229,0.3677592608942037 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark11(-58.83218619429218,-1.5674055796554034,-26.163186100193688,44.224622620895786 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark11(-59.01846034677487,-0.23068514791260952,-36.70774790007598,-42.778441043745374 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark11(-59.11933144715239,-0.386363448892743,-9.477636908154777,0.0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark11(-59.15204839051151,-1.5707963267948954,-38.01059633702854,-0.8792817793267687 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark11(-59.156861345574626,-1.5653119807261429,-92.48624196634015,1.0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark11(-59.40890871548008,-1.4081003783849981,-5.7023339720526,1.0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark11(-59.56225727866481,-1.3254279821602872,-1.5707963267948963,-0.38286830196263066 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark11(-59.57658462688839,-9.860761315262648E-32,-1.5707963267948966,6.3108872417680944E-30 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark11(-5.957743799110544,-0.8859415910535855,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark11(-59.579718235971946,-1.354282340822774,-27.459008855712327,0.06255266406427888 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark11(-59.74503447586967,-2.2766588744906376E-15,-74.55070492972303,-1.0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark11(-59.79426273166703,-1.5707963267948957,-67.44885710036431,0.9951098909453806 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark11(-59.82377566399601,-1.3655530024785905,-1.5707963267948966,-0.005164882663868535 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark11(-59.82834988638355,-0.19331628046469973,-50.298898679926005,-93.28833698789032 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark11(-6.000952384973083,-0.531352513086441,1.734723475976807E-18,-1.0000000006760619 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark11(-60.12342237241357,-0.6290610936485592,-9.496520139715443,-1.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark11(-6.01504555094553,-0.749006267697335,-1.3290821455886852,-31.99693555741898 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark11(-60.16771189727306,-1.2464307792282896,-62.58898374802153,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark11(-6.022867392389756,-2.220446049250313E-16,-1.5707963267948966,0.00614465305381211 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark11(-60.255049971830054,-1.5655974791903555,-80.18710051244594,-0.3988929019312527 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark11(-60.326051896786616,-0.46545981860430313,-1.5603976726964917,0.04120279195636063 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark11(-60.36923851237169,-0.006767878836282187,-44.54073328306718,-1.000000045000232 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark11(-60.37118887677309,-1.1281423884561157,-2.3279501526773827,-92.20782614288684 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark11(-60.373508901723724,-5.611671674118359E-17,-1.5707963267948948,2150.8180866699117 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark11(-60.4463322217743,-0.8229945431437251,-1.5707963267948948,-0.3111537289365387 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark11(-6.045585336679039,-5.49956527127427E-4,-166.80110782849835,100.0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark11(-60.472305744040014,-0.2096131949559138,0.0,0.0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark11(-60.50764735264978,-1.0739637014423091,-6.043662454169287,-1.0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark11(-60.51498953180754,-0.33771173289510165,-30.67958291849844,-1.0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark11(-60.91374734371186,-0.7083316359624341,-0.3167206530727958,-23.939846775986293 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark11(-60.92494149222229,-0.0718326123934871,-0.006769567196606535,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark11(-61.16799320320987,-3.601399798124989E-18,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark11(-61.174478317072634,-1.5707963267948963,-57.20353586045028,-1.0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark11(-61.27087346763547,-0.022077067770406703,-77.80372490790958,-43.54131169443476 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark11(-61.30050986068068,-1.4277512694379082E-5,-15.387842422573263,-1.0795210693868056E-78 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark11(-61.353948498767366,-1.5707963267948948,-38.9466079740171,-0.005114458720548315 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark11(-61.49022991610735,-0.8857697908672835,0.0,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark11(-61.55474816798396,-1.0487404473045827,0.0,-1.0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark11(-61.5759467645077,-0.7052067689211508,0.0,-20.185570534586017 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark11(-61.61823871392315,-0.3947706979226747,0.0,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark11(-61.80174110927616,-1.5707963267948961,-77.673624661999,-0.16455141955658448 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark11(-61.89879254828026,-1.0296256039763179,-13.647266796990493,-4.186895972934041 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark11(-6.195249419112487,-1.5707963267948961,-46.36087360507611,56.56377618990708 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark11(-62.0460147576677,-1.507277480639496,-27.618236753431546,-0.04711451932857072 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark11(-62.06532907318447,-1.2507013403914855,0.0,-0.04739948911411476 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark11(-62.06954483182524,-0.8241923337666127,0.0,1.0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark11(-6.214013239400387,-0.232971137837922,-12.642096736915718,0.43449374783812167 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark11(-62.20930274739892,-1.5071727173599943,-43.291842908399914,-0.06255252542929597 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark11(-62.21239889641712,-0.9871332663525634,-1.5707963267948948,-63.595982581087874 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark11(-62.2281261593987,-0.8856698507217975,-19.362024497607667,81.18429575678186 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark11(-62.256767355036146,-1.2195266849568247,-32.45692435637307,-0.6235687075917629 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark11(-62.43663375895456,-1.5707963267948912,-89.44676092453386,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark11(-62.62050538113122,-1.434533951552747,-97.83370149059891,5.852095443365248E-98 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark11(-62.64048546244351,-0.44079550403452683,-10.34231290980695,1.0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark11(-62.655382295390204,-1.570796326794806,-74.54318082828158,-99.1647658497254 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark11(-62.73027451699886,-1.0575151210198515,-58.38410899962959,-0.8207688617222009 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark11(-6.281097200059683,-1.4405722902073803,-45.043391153904786,-1.0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark11(-62.961164980104954,-1.5707963267948963,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark11(-62.98272932333552,-1.4452159884705473,-39.16649226474676,31.067189870694513 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark11(-63.032427324906415,-0.3476951148588805,-94.21837413034613,0.2274581908518929 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark11(-63.07183328027004,-0.7441890698087384,-1.5707963267948966,0.004404399838379804 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark11(-63.23730253716881,-6.719687186375544E-9,-45.922340256834126,0.05700655831739568 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark11(-63.38614712886357,-0.5626799891898084,-89.63094231454504,100.0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark11(-63.452508988308495,-0.902578173786026,-15.45917663535495,0.6405158520352785 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark11(-63.47972540870127,-0.1575114477545173,-80.69621552631536,-1.0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark11(-63.544249814423104,-0.004913500706411947,-1.5707963267948966,0.590280716076391 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark11(-63.56158419225585,-0.7315920893894075,-72.37095384145148,-42.90159943066514 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark11(-63.58945119386511,-2.3066067535279476E-4,-95.67453397945829,0.4205344637381704 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark11(-63.60403011371644,-0.3426592181311991,-100.0,-103.42111245982986 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark11(-63.62409087535531,-0.1744155131882219,-89.86709301704857,-1.0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark11(-63.76485165522879,-1.5707963267948957,-1.5707963267948983,-90.39088554394851 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark11(-63.77926567951746,-1.558381386461964,-89.70357681328622,-0.3326477074467378 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark11(-63.831999554719545,-0.8993920773591184,-140.72749197145808,49.8324615444333 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark11(-63.89034463618519,-0.4558078869279034,-9.818060572173579,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark11(-63.9304212439487,-0.14544194834392687,-31.216509134143365,1.0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark11(-63.9445391384018,-1.5699174584174658,-1.5707963267948966,-15.177662430890724 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark11(-63.94504631343641,-0.7492347773391399,-39.64180905936511,1.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark11(-64.11519345302264,-1.1583165604139083,-144.90506204255857,1.0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark11(-64.15410775118394,-1.32115182921481,-66.50078069773599,-1.0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark11(-64.16206849531352,-0.41111403188537077,-1.5707963267948966,-4.3513317283903925 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark11(-64.30846904132892,-0.6653275858883181,-53.158717012316906,0.3522642738389674 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark11(-64.31085601453711,-1.0220671774919543,-1.5707963267948966,-0.1425386676028606 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark11(-64.39914214360567,-0.5789822072216978,-6.765050001380459,0.9655173779917683 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark11(-64.43078638874746,-1.5584619101274966,-1.5707963267948966,-0.012563048870553206 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark11(-64.43593078289774,-0.13776767087756633,-1.5707963267948966,-29.733876531927283 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark11(-6.44740595464863,-0.1746183933176419,-68.49598835560337,-0.6683015790069611 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark11(-64.5334379302648,-0.556597081159623,-89.72596036362121,-49.462319007100106 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark11(-64.53953180230363,-0.12428523189471674,-101.68997485571688,-4.00059072337348E-5 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark11(-64.65992743415202,-0.6588192432629445,0.0,-1.0006361664921943 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark11(-64.68515901893737,-1.35907510721299,-53.65798857247773,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark11(-64.76314703779227,-1.5132534166141618,0.0,-1.0000163503748882 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark11(-64.7742341113024,-1.5707963267948912,0.0,0.9747611718390443 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark11(-64.8638612916478,-1.4210546197747052,-66.47557517759952,6.776263578034403E-21 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark11(-6.491162876710977,-1.5678665022988663,-57.69140076687839,1.6472184286297693E-83 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark11(-64.94400201940316,-1.3041425823471005,-38.46333163916682,7.447292083529941 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark11(-65.00237591039347,-1.5707963267948963,-76.91006864040577,-0.17094601723193126 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark11(-65.07269551977106,-0.029581952625479385,-72.52764971573806,-0.5302760464569145 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark11(-65.10500053962409,-1.5707963267944722,-1.5707963267948961,1.000000000000007 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark11(-65.16478655892854,-1.0370757051947779,-100.0,52.72930285881552 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark11(-6.523936185688614,-1.4609618325873335,-83.344274424693,0.013949831968885329 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark11(-65.25623303648388,-1.3443058477908278,-72.39729927309318,-0.06237000692734253 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark11(-6.536786156839468,-1.5707963267948963,-18.809932132001364,54.47288952239305 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark11(-65.39672837058366,-0.30782031649014563,-40.51472000852958,1.0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark11(-65.40518736331275,-1.5707963267948948,-32.963560918091744,73.77501224043039 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark11(-6.543453296565595,-0.3646237454691191,-45.367817001424896,0.19635626532152806 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark11(-65.54145978393024,-0.3447885168345306,-66.14740432642562,-1.0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark11(-65.61726364442545,-1.209325805069341,-61.585368662907854,0.016771132147368473 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark11(-65.657640503793,-0.2679971933636003,-54.977871437821385,-16.030782353990404 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark11(-65.68300525898997,-0.6314140432968154,-100.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark11(-65.69965106888853,-1.5419179861359862,-84.67826085764516,0.844303582796552 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark11(-6.576160905976256,-1.5707963267948957,-1.5707963267948966,1.0342099118753243 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark11(-65.77216687159033,-1.5707963267948823,-32.70233159473105,1.000000000000001 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark11(-65.78625744818301,-1.5687646484384448,-11.105695365213192,1.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark11(-65.80767512951665,-0.6557028668153756,-1.5707963267948966,20.04612713789217 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark11(-65.86013286179393,-0.49222546730244443,-100.0,-0.508378622808707 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark11(-65.90512685568187,-0.24649672229835407,-1.5707963267948966,0.9141927722793781 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark11(-66.0386494788648,-0.48034120584073037,-60.07895825946161,0.9481645277018604 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark11(-66.22295173144522,-1.0780759068663406,-1.5707963267948983,-0.3383839149294101 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark11(-66.24605621280126,-0.09920988398432003,-1.623428731414208,-83.32263905764785 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark11(-66.25117754046359,-0.6807656503012833,-48.232960630732926,1.0000003480429775 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark11(-66.27853462066287,-1.3566868846370883,-9.891225078590423,0.0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark11(-66.28200936509339,-0.6304801919210375,-0.6329969133005279,1.0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark11(-66.40500893365525,-0.39234234572606486,-94.33105513885761,0.02297225159917704 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark11(-66.43766553604905,-1.03808556806362,-9.590515352469726,-2.3738919364399497E-66 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark11(-66.64982267354591,-0.44248733088595515,-37.27937378754919,28.44029413887455 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark11(-66.6773961906156,-8.350120993309874E-4,-23.331623935973965,-0.026548797537321853 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark11(-66.82955017318423,-0.8699421062889847,-1.5707963267948983,0.920195585364656 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark11(-66.85106089162473,-1.446786933512824,-32.76237101370639,1.734723475976807E-18 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark11(-66.8748003128886,-0.02400701809665181,-9.513338171878495,1.0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark11(-66.8901687015392,-0.8536381038491783,-22.5707448631578,43.99844930362116 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark11(-66.90740898928554,-0.14689698799174433,-21.465412724670333,65.66875786406484 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark11(-66.95631392158572,-0.5437503873578322,0.0,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark11(-66.97096223923828,-0.7793543768840223,-39.26153128721444,-43.171215018802926 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark11(-66.98783581650686,-0.0010367693593082256,-0.24371310843185437,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark11(-66.99448157071637,-1.2938746739968456,-25.72091017975294,-3.3087224502121107E-24 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark11(-67.08098666818873,-1.4207707408896546,-1.2709119934925899,-81.36078407998527 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark11(-6.7126471907873935,-1.5357417202457482,-81.77315507301653,74.23363363089567 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark11(-67.17141118214114,-0.21504131265549056,-38.85515162872293,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark11(-67.23072047198698,-1.4453103476009055,-11.664054295711727,45.69347994833519 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark11(-67.25684886008108,-1.3191879683319285,-0.7715180190430397,-75.07514488312592 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark11(-67.479248585653,-0.6539862555915765,-76.85648917655072,-97.25417243404988 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark11(-67.48440771600721,-1.258555972540907,-9.64274563568302,0.18317113658966677 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark11(-67.50277766035356,-0.3127086881247629,-27.711221042543407,-68.33318594426936 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark11(-67.51091317210633,-0.6313783387147341,-100.0,-0.989194419201954 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark11(-67.56749492551042,-1.440374276045036,-135.60568838910788,-0.9104623679778285 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark11(-67.62513259068504,-0.45701496310925926,-7.289581088434236,33.82723332145872 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark11(-67.7761281914471,-0.13812555725022563,-63.006592651341165,-97.11038694439952 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark11(-67.82755224324818,-0.5678419357469008,-31.54985398623822,1.0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark11(-67.8767013631159,-1.3428390865169988,-40.08192969011178,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark11(-67.87818689407275,-1.5707963267948917,0.0,1.0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark11(-67.9605641249097,-1.4009896629241965,-74.36340432715257,15.461474263698676 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark11(-67.96412708533568,-1.2769909726837194,-4.250741862144096,1.0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark11(-68.14680870411308,-0.577090543108938,-88.14574299326368,51.50172178925732 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark11(-68.22601248248357,-1.5594874302912296,-7.597896371483515,-1.0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark11(-68.2386502081878,-1.5067438546182814,-1.5707963267948957,-4.808691235431155 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark11(-6.826913013846818,-1.0872038056466238,-1.1292923637066372,-1.0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark11(-6.836545774798974,-0.2572422614447642,-1.5707963267948983,-1.2309882682209815E-4 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark11(-68.38741445577531,-0.8889768178824553,-62.83714873561331,-0.545510198588029 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark11(-68.43147453108674,-0.9241709788486593,-4.427731526631355,5.534643607540943 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark11(-68.54341674121189,-1.5707963267948957,-1.2576830503548995,59.32068658661049 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark11(-68.65339252207966,-0.35104304080190274,-78.3245124568712,-1.0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark11(-68.74529700695342,-1.5707963267948912,-28.45390773739385,-77.24793224815822 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark11(-68.76701026055775,-0.47643212937103624,-94.73026291828717,1.022467104534934 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark11(-68.79002047286284,-1.0795129402749117,-89.60251456384582,1.0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark11(-68.80129345030743,-0.5791451669758108,-19.42862704027397,86.55064186721958 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark11(-68.92067476940332,-0.031766996098403055,-77.61335386582122,-71.22257092398874 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark11(-69.00001297198716,-1.551322392341489,-7.43241517107278,-92.82344747044682 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark11(-69.0520697960191,-1.2727102736190892,-83.67479919357932,1.0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark11(-69.28918065043808,0,0,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark11(-69.30680936712331,-1.5707963267948912,-137.53561625945494,1.0000417635786012 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark11(-69.35999001363193,-0.19092708461143276,-0.514726704448699,-1.0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark11(-69.4904700592812,-1.5707963267948841,-1.0061704111772902,-0.026426452657675067 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark11(-69.50301983138958,-0.002303870620867343,-163.65113798119114,0.9999999999958576 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark11(-69.55890848756462,-1.5707963267948957,0.0,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark11(-69.57145473209845,-7.57594729955287E-15,-1.5707963267948963,-2245.3551408362823 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark11(-69.62195641201023,-0.43492557902430873,-1.5707963267948966,0.6596766680221767 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark11(-69.67178025384219,-1.031102750322125,-95.26249467171542,-0.06268791014743205 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark11(-6.968044378360382,-0.07685149577891082,0.0,-1.0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark11(-69.78370751626122,-0.9568380537047583,-16.333897992744337,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark11(-69.82784027813427,-0.4292321168203807,-54.418402533169164,94.87909798885846 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark11(-69.83750997644282,-1.2954225119175697,-50.25914418809633,-0.017893945789951904 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark11(-70.05991255041111,-0.7525222340259989,-24.282343308494532,1.0000000187321847 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark11(-7.013978500129081,-7.105427357601002E-15,-52.43951523598809,9.597442716224577 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark11(-70.17366410697078,-1.1342726138395554,-0.009709655754489566,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark11(-70.40686782970782,-1.5076292646474885,-122.15876652117325,-21.516295847250547 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark11(-70.65656691698919,-0.11259921720329231,0.0,-0.9981680612633039 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark11(-70.69997596795663,-0.7717150299739437,-52.89217163988884,-1.0000000015264336 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark11(-70.71458822479777,-2.220446049250313E-16,-87.7775834238376,0.0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark11(-70.72206500162069,-0.5030746559592731,-51.11836621107656,-0.5047975796262546 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark11(-70.84624849592093,-0.8011372837308239,-1.0096325612055472,11.5269452542408 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark11(-70.90686293906283,-0.8311106938243604,-100.0,-68.36666505078404 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark11(-70.93956728024504,-1.5707963267948948,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark11(-71.02281435269947,-1.326184586601226,-52.83076967773957,0.892700143308174 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark11(-71.09190467150981,-1.3766560817000544,0.0,-0.4208343083613215 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark11(-71.11701675648163,-1.2178224773419168,-4.46065551738657,1.0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark11(-71.29439977557745,-1.2492962932533405,-40.63659733529767,1.0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark11(-71.31975387295762,-1.816382932426924E-8,-9.568579187643039,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark11(-71.43204409170235,-0.004317554522408684,0.0,-47.18618993485541 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark11(-71.64428875187753,-1.2061864530822355,-165.162094347412,0.06278610250031767 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark11(-71.67716515370994,-0.45182011768971364,-1.5707963267948966,80.20290802836797 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark11(-71.6889284119161,-3.552713678800501E-15,-10.672710048382172,-20.408431279274282 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark11(-71.70524397605242,-0.13382732953034981,-55.30170344034476,-76.34870839321862 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark11(-71.71253320886731,-0.7431403232087774,-54.71183557491357,0.7480163666532728 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark11(-71.75666145709822,-0.83833757844994,-38.762837241474806,0.8309405758512295 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark11(-71.7743285802535,-0.28882928414657627,-3.218024323749086,75.76981382858136 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark11(-71.92693926124387,-1.102320645336846,0.0,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark11(-71.96851242261751,-1.5707963267948957,-25.147883315308874,-0.047038907077444514 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark11(-71.99595875555976,-2694.112009085425,0,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark11(-72.1218253035627,-0.5492139029427288,-0.8848043930252009,-1.0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark11(-72.12978510718504,-0.06814899210511545,-35.25677197518482,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark11(-72.22469681719652,-1.1102230246251565E-16,81.59168392594773,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark11(-72.30075414580814,-0.3244903752395679,5.551115123125783E-17,-888.415644284023 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark11(-72.30284156863983,-6.6888867700601044E-15,-15.59474244340601,0.41507650775756366 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark11(-72.30299571418976,-1.5707963267948961,-12.837665014767826,0.9021649937986274 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark11(-72.405363966194,-1.378264228624019,-73.50328103979062,-89.96229341356704 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark11(-72.40941677077693,-1.5707963267948912,-21.219106586440166,0.03976678048878224 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark11(-7.2490790960385,-0.22679519520918434,-73.73697804581309,-1.0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark11(-72.50427559461555,-1.1406203469122511,-36.270149588878326,0.49902675512545613 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark11(-72.56078429386258,-0.9266642089219204,-7.53928195711633,12.386411991411528 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark11(-7.263656498744012,-1.5699166753157587,0.0,-1.0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark11(-72.6712873357044,-1.041708089476434,-30.37023932784426,-1.0000000000004066 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark11(-72.76074105960485,-0.7493340679090945,-31.926291308945352,0.06232283213600691 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark11(-72.84706483862026,-0.9814090258163729,-53.910113228824436,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark11(-72.88911457778433,-1.0083596937409323,-28.680706750413407,0.9999999999999999 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark11(-7.2970260935465605,-0.008470685440885257,-62.09349392027103,55.79391716724525 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark11(-73.07771005103277,-1.0811452673213438,0.0,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark11(-73.23647707198364,-1.4983185433265334,-32.9071856794934,-58.256657995840065 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark11(-73.29405850155783,-0.22746070057377077,-74.39209074683141,-25.65315326667321 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark11(-73.31010757846363,-0.24116132889049968,-0.9638279073523162,89.31252155124945 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark11(-73.35196914338395,-1.3304709974477194,-1.5707963267948966,-86.64652191113127 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark11(-73.36288795815713,-4.332498629829839E-15,-1.1103138117156537,-3.2033329522929615E-145 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark11(-73.3869118540674,-0.7397556262432015,-88.25874502923445,-0.955669331754109 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark11(-73.41706601701088,-0.5301686715197027,-77.23962761912287,-1.0000000010573216 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark11(-73.42648829458074,-0.34529279071431673,-90.58297681433157,0.33807368931871223 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark11(-73.49382341363679,-0.5402451261736712,-71.24060630429916,1.0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark11(-73.51930116388188,-0.6472226092238724,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark11(-7.357520069789132,-1.4190197230501802,-45.71019342101921,-1.0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark11(-73.60787139016922,-1.4087018871114951,-36.07556469393565,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark11(-73.60857618169669,-0.3398927836714275,-30.773258945335648,1.0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark11(-73.66151108220478,-0.9967415116865149,-4.4335928858958695,-1927.2204839122328 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark11(-73.6893937119,-0.7680408256024975,-5.205674495251571,45.80665438350567 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark11(-73.70429239855248,-0.312876037493782,-30.48150826546727,0.786995177294976 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark11(-73.74008084535718,-1.2039995407958268,-82.68034738430782,-40.05603227313042 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark11(-73.80497658133987,-1.5707963267948948,-1.5707963267948948,0.6129707945493612 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark11(-73.87394672034395,-0.6086135002420152,0.0,-1.0587911840678754E-22 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark11(-73.92110119507117,-0.1252760917111444,-16.78336242489333,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark11(-7.42637575828988,-4.461453200751116E-15,0.0,1.0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark11(-74.31988759499741,-1.188141474862595,-9.185592265756561,0.0028605971647417544 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark11(-7.432533490245586,-5.562194128623466E-16,-18.71627944943168,-50.35187798353968 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark11(-74.32802662702707,-0.09597559693472812,0.0,64.90140530833139 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark11(-74.34465492519067,-0.17361424101110345,-44.99751424130687,0.0029238246749068286 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark11(-74.49479340536385,-0.010387712717935055,-9.386538387287516,-74.62747621448192 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark11(-7.456013527109921,-1.5220584430412167,-114.6819547517641,-1.0000027397863491 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark11(-74.58935318244983,-1.397101526193504,-0.14211581607727294,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark11(-74.72073179487165,-0.22301507749148897,-24.758511557877974,2183.381805002996 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark11(-74.88279817458843,-1.5707963267948912,-46.57478793012455,-62.53286408502634 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark11(-75.01291326999404,-1.5707963267948912,-78.3935969128058,2449.5629868704164 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark11(-75.04662341116932,-0.26704516727273164,-1.5707963267948966,-0.9930217786715385 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark11(-75.09013334088846,-0.05070634640029227,-3.1886659579702155,0.8014509497439277 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark11(-75.13569475292029,-0.8369218185641288,-32.896009848215556,-0.21169301061945406 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark11(-75.39698014736899,-1.434171554854529,-10.806834998148151,90.69420544763074 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark11(-7.541607758321543,-0.871673095667302,-13.510367590462392,-1.0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark11(-75.4307969541314,-0.9080875827742976,-80.23628242038312,-0.07910925962699872 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark11(-75.44444837557724,-0.8691440370155508,-0.9518434590908251,-2071.6386838902663 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark11(-75.46135901535413,-0.01012888857757312,-50.420500993220806,0.683377871513031 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark11(-75.47933827323533,-0.30445820723237704,80.02053544229207,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark11(-75.5712818463123,-1.2178786173382603,-136.22901927509236,0.016675159045780454 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark11(-75.60771302139894,-0.06961938486979728,-43.14940915750168,-1.0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark11(-75.65824609219725,-1.1011616168935667,-0.33872298446138105,-89.98497827379325 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark11(-75.79109219742234,-0.3935531773044813,-100.0,-69.48932087776471 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark11(-75.91839754098632,-8.881784197001252E-16,-34.061087711535244,1.0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark11(-76.01413505420611,-0.8475382168141127,-1.5707963267948966,40.995973141734055 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark11(-7.6062536647318915,-1.5707963267948961,-100.0,-55.72272400676486 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark11(-76.1438686197811,-1.5707963267948912,-21.714154928715473,-0.8716264311891639 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark11(-76.26112377783375,-0.062003351781390756,-0.674224277182714,1880.9870489938917 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark11(-76.29184980051242,-0.2908088198487213,-31.703681860813397,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark11(-76.44468251120415,-6.109578666999563E-4,-26.305053180551795,1.0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark11(-76.55687237412332,-0.006016877760861683,9.027934206335317,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark11(-7.660343745693311,-0.8229960334371522,-66.46910659208751,0.03304451038045714 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark11(-76.76921197115963,-1.1976143282127947,0.0,0.34324958826291085 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark11(-76.8107170489772,-1.5485487905258735,-45.43670264577179,0.055471858755850256 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark11(-76.82869737890515,-0.162431935709312,-56.711291786492374,-0.9999999999999964 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark11(-76.87057902355569,-0.6951814892439181,-72.66644266379025,-117.68015472487836 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark11(-7.689216598456849,-0.43451067884073136,-73.45264325638539,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark11(-76.93110643640402,-1.3177569341419968,-101.95234896061753,0.5957505940831673 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark11(-7.6978274845537555,-1.5707963267948948,-0.4043986438419414,47.64519301914339 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark11(-77.04131795556458,-1.502610156071644,-36.95293659551546,-0.19013457530181488 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark11(-77.08125461030922,-0.760014545510586,-100.0,0.0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark11(-77.11510015595239,-1.4589645232437884,-100.0,0.019739008124747385 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark11(-77.12203937912808,-0.5380819045768238,0.0,0.0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark11(-77.18786272670319,-1.5442643491940213,0.0,-1.0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark11(-77.1882479389807,-1.5707963267948948,-77.99302553928004,0.5480218197911876 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark11(-77.25418945918881,-0.9202188710056054,-1.5707963267948966,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark11(-77.31254414046528,-1.5707963267948963,-1.5210159451417142,-0.5043458082732184 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark11(-77.40777310204824,-0.2980937180547358,-19.55402452275052,44.09054975459236 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark11(-77.57266757307046,-1.5588011176141794,-63.16019793040128,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark11(-77.61999752390675,-0.32136620431343405,-54.814163459152624,-0.671458043220909 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark11(-77.64721080655454,-0.022168949095337225,-46.62499967768216,0.9999999999999982 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark11(-77.67081463406637,-0.11085677726780263,0,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark11(-7.768475085966754,-1.3251168132284565,-98.37590984091997,-0.9026908844070547 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark11(-77.70159462589768,-7.477068932182731E-6,-1.5707963267948966,0.8240223618703016 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark11(-77.71905616741785,-0.06996831282767096,-47.86954188707735,1.0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark11(-77.71963811922797,-0.8750062948785633,-73.6982921628379,14.895497406587202 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark11(-77.79531866742262,-1.122177819865797,-45.57155318421614,53.03384897008206 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark11(-77.85182197524648,-0.15130300786251383,0.0,1.0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark11(-77.9096835583315,-1.5643434690047684,-7.2022892717702,-0.052200653571762234 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark11(77.93718689996476,-17.611864629834614,-68.02935811812569,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark11(-78.03607452605863,-64.64661070139374,-92.1611513510499,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark11(-78.1040494065913,-0.7906359405449623,-28.914166744428773,78.09694594628047 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark11(-78.15333457397962,-0.40057355475619394,-136.53945415985606,66.11456656440703 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark11(-78.1866500169563,-0.03914684501371137,-36.97643533784594,-5.306497207578367E-6 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark11(-78.28909745235887,-0.06867624306527881,-74.8230190741433,-2145.956408401183 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark11(-7.833529560531062,-0.30159638413928147,-100.0,-100.0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark11(-78.34996300009988,-1.5707963267948912,-94.77359746126358,-41.549367543378274 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark11(-7.842469957227726,-1.0753699427869932,-1.548721152437253,1.2526894207380381E-5 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark11(-78.56596592330658,-0.07625973931203633,-65.82504589663212,0.43318781548334073 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark11(-78.58200953140272,-0.4467864684822374,-83.6068921646715,0.008095558973337025 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark11(-78.67515048476223,-1.5249335492474728E-16,-1.5707963267948966,0.3563391491534258 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark11(-78.74009109605059,-1.5707963267948961,-84.84633533375205,-82.61295291801913 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark11(-78.8056869253507,-0.022462388052240493,0.0,-1.0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark11(-78.82197665252649,-0.9411879224667756,-33.743589449702995,-28.561681333448817 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark11(-7.884077156998937,-0.94445991046478,0.0,-17.660595223650105 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark11(-78.90609921964283,-0.07094334098901889,-58.64026810896256,-43.58263090028059 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark11(-7.900946457129615,-0.17108191360362973,-32.65376442898013,-0.784992399114673 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark11(-79.0221879035858,-1.5511298658367147,-61.94136157181116,-31.067593503186593 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark11(-79.31804987212325,-0.7548479302671249,-1.5707963267948966,-86.04383856485637 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark11(-7.937577871242112,-1.325728798670923,-106.59522587559503,1.1772030973917254 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark11(-79.38567490000852,-1.5707963267948948,-0.2772910785724259,7.074584241031673 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark11(-79.43338114129716,-1.0744812838529345,-45.2878749147918,-0.08865488845650837 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark11(-7.94397997100141,-0.2431065029906433,-88.36938675002082,1.000307332172429 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark11(-79.46324335876815,-1.5707963267948912,-66.67102058443018,-83.27594064317921 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark11(-79.5253985380801,-0.17708754431410156,-49.57098435815043,0.9779004353079216 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark11(-7.962386357270319,-0.404533285536023,-10.849339927370508,1.0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark11(-79.6287988403885,-0.05473427953611454,-46.66909365704754,0.050220717623546074 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark11(-79.73019155837221,-1.4764965412498974,-0.0171161017712764,-85.04095267964605 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark11(-79.80822156375218,-0.16255235550625424,-100.0,-1.0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark11(-79.81305449536471,-1.4547381657136786,-1.5707963267948961,-54.72267791270748 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark11(-79.89752928716155,-1.4274981373135416,-20.43929723083346,-0.062304253783934366 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark11(-79.93308601182144,-1.334021136431197,-36.61412138829476,-31.95357251031112 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark11(-79.93898787707151,-0.5810209510399496,-1.5707963267948966,0.5729431731824175 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark11(-79.97810407427657,-1.489770402291748,0.0,-2122.9637447016235 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark11(-79.98776883127357,-0.43149673249789733,-8.275995226742964,20.026821825819212 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark11(-80.02705027761351,-0.6664544524684536,-9.508978314950276,-0.06283500232084564 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark11(-8.01098073599285,-1.2549453353655937,-1.563062736108242,-10.4332815818968 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark11(-80.12436337725238,-0.10122367507250063,-45.547913667824574,-0.055547358743270325 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark11(-80.39567357792762,-0.009060356285808313,-0.8175802015895715,-1.0301785629251117 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark11(-8.04712091927209,-0.6380143033631124,-61.42642311610429,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark11(-80.67196542679429,-1.1219338800124934,-0.34819170901930196,0.0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark11(-80.71020385422875,-1.3066869312408034,-62.3666240932579,1.0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark11(-80.72012324944414,-1.114768177771026,-96.99010114973836,8.829514733838991 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark11(-80.86486416227285,-0.02508151485825849,-0.021613326061792053,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark11(-80.87037896478009,-0.7114774005178157,-38.83086775371815,0.022386901519582558 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark11(-80.91257789113996,-1.431608262229517,-44.328347478956815,70.9413144890155 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark11(-80.93663926698649,-0.690801863543101,-0.4781806124974963,6.312862641171661 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark11(-81.04969071224573,-1.270208034154976,-69.95111667629823,-1.028964469363198 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark11(-81.1505941170219,-0.6463931680898666,-98.30236460942197,82.40733517231034 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark11(-81.23779277995108,-1.5310731470469605,-51.52597825392381,1.0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark11(-81.24192101343507,-1.5342718089543916,-72.39582850913295,-0.12019905501698427 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark11(-81.28392138304132,-0.5339716589932602,-66.53730614916077,0.8394460929830238 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark11(-8.13104223468071,-1.4674599189784983,-63.07190031026468,0.046290287735683854 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark11(-81.3407065393396,-1.4689459394048836,-100.0,0.7785697588270823 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark11(-81.42297657498345,-0.01611755803751228,-62.65292973370846,0.9027179408922557 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark11(-81.4855546708561,-0.7544567623373144,-53.30309866145889,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark11(-81.51836218557662,-1.570796326794893,0.0,-1.0000000000000004 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark11(-8.154158616360347,-0.12529285448488703,-24.53267987006385,100.0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark11(-8.156385981917321,-1.0638194496617992,-41.73320616897119,68.4248009295388 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark11(-81.58947781209443,-1.5707963267948952,0.0,-0.05009650500647986 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark11(-8.159120752316472,-1.1816902189688379,-78.14343227404801,-0.03705392462089756 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark11(-81.59545421757849,-1.4760201143375928,0.0,-0.2625019463357847 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark11(-81.65262909877917,-1.5707963267948948,0.0,35.81697008656383 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark11(-8.165377606064467,-1.0848986168240458,-68.29630405482577,1.0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark11(-81.66270608184325,-1.3354524398255982,-74.40720581425379,-0.9815438659703969 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark11(-81.7999861104012,-0.5598694583852188,-1.5707963267948966,61.7321986795691 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark11(-8.186657134715318,-0.043957474976919875,-68.44253308021881,-1.0000032173189644 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark11(-81.9807584015393,-1.5707963267948912,-76.10170085583152,-37.746128444240256 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark11(-82.04695793667241,-0.19610382490721914,-17.614006615015978,-11.03678713583237 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark11(-82.11176576929915,-0.5047160205870185,-5.411512547876715,-0.630352641350802 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark11(-8.211802782323865,-0.5842467093646183,-1.5707963267948966,1.0000000000000002 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark11(-82.15264163575202,-0.014331319728577322,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark11(-82.44586389722204,-0.931353164430191,-77.10710532650714,-44.202974799027395 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark11(-82.52495758382408,-1.524878977561944,-25.844141508282533,0.9580829207845695 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark11(-82.57842998198959,0,0,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark11(-82.59337368581245,-0.21463989782224485,-1.5298940151523477,1.0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark11(-82.59651095372135,-1.459928740634533,-12.815308217345091,0.0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark11(-82.66010179729702,-0.16578979610537778,-36.22774361138573,0.9106557362532665 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark11(-82.68304678977296,-0.9312657345311948,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark11(-82.9417488990217,-0.5176940046244423,-1.5707963267948966,0.057280546272458155 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark11(-82.97449233472204,-0.08135878889094883,-17.549192730905133,1.0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark11(-83.02028391905415,-2.438571017440029E-5,-27.601227553785186,1.0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark11(-83.05737870597302,-1.5707963267948912,-31.518645685884096,2230.564594114525 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark11(-8.314992226966652,-0.9107070257027559,-0.2680112337456591,-44.3969030907231 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark11(-83.2209244381284,-1.5707963267948912,-5.105575857047896,-1.0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark11(-83.3780315965525,-0.538079485857085,-7.231118173884795,1.0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark11(-83.49541323505055,14.429210383543591,0.0,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark11(-83.50113209207908,-1.7763568394002505E-15,-38.71621294600087,-1981.2625615476913 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark11(-83.53105501794369,-0.600122666708105,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark11(-83.61474205623783,-1.5707963267948912,-45.32438082448473,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark11(-83.67483871981706,-0.27215590903093434,0.0,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark11(-83.68456286607984,-1.5707963267948963,-100.0,100.0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark11(-84.04763537260379,-1.5707963267948961,-74.70302357967162,-1.0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark11(-84.13026789811077,-1.5707963267948961,-96.04795341525814,-0.032893891756860694 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark11(-84.14855338604625,-1.453718572239492,-26.53577161740625,0.2688863503098975 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark11(-84.3478925867647,-1.3293804110224474,-1.5707963267948983,-0.02587376771333172 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark11(-84.40371560266243,-0.9164769621942268,-136.57023736326457,-0.9630356988293158 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark11(-8.454017108145349,-1.1459602980512074,-1.5707963267949066,-1.0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark11(-84.57141418297375,-1.1302081278026321,-32.809915386902375,0.012795179615752626 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark11(-84.57938513035889,-1.4500284992399555,-73.4546153452606,-0.012075839341360833 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark11(-84.608342470677,-0.3836678512594323,0.0,-1.0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark11(-84.61667371365581,-0.21110526227467952,-38.10006164349809,-1.0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark11(-84.63240429329565,-0.5103488298288494,-1.3582247533083818,1.0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark11(-84.67402641955782,-0.35561840659979405,-0.3353073835282702,-1.0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark11(-84.68184919956266,-1.2194338238899782,-35.068084140035566,-1.0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark11(-84.74525563128735,-0.002354506859930882,-1.5707963267948966,-0.8468273399656849 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark11(-84.82950284025748,-1.0272501190871488,-1.5707963267948966,-1.0000000000000018 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark11(-84.8427950209273,-0.07332994930589798,-8.230628672307773,1.0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark11(-85.09011173681924,-1.5707963267948948,-44.463659573407476,-1.0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark11(-85.09726368613019,-0.06447437875303902,-70.75733181205493,-1.0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark11(-85.09856648110768,-0.41670739958388786,0.0,-0.02219724672129389 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark11(-85.17562834096034,-0.20623873583677532,-44.70172834288172,0.9764271938594878 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark11(-85.23637336446757,-0.17022649189773098,-15.257098134884345,56.98017123742753 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark11(-8.528734754936758,-1.0233996447441565,-1.5707963267948966,-1.0000000017552049 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark11(-85.62418593211495,-0.04157623151619585,-88.09807861782113,0.4891737895135051 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark11(-85.84735642063787,-0.547814521141864,-0.1689701367547704,-1.0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark11(-85.99670643649428,-1.1663673746079544,-1.5707963267948966,3.2701710756235274E-8 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark11(-86.02149598015822,-1.5707960952167275,-31.728957641490126,4.70197740328915E-38 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark11(-86.06067572872429,-0.28497664591642063,-31.65454593187051,1.000000447047564 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark11(-86.15323401727764,-0.22847336834417487,-7.727968184039218,31.482119719948475 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark11(-86.18247477944723,-0.05719512679140237,-197.119746070725,-0.7888252952155085 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark11(-86.21732219646393,-1.5707963267948912,-71.16686006775531,-0.31315862510001147 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark11(-8.622878353651018,-1.5707963267948912,-1.5707963267948961,-0.722804512197901 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark11(-86.27078648997237,-1.2949264792931816,-33.17218533395034,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark11(-86.37382931882925,-1.1933038274422825,-4.8280120970390925,-99.85325595482644 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark11(-86.40017492377882,-1.4956968290182924,-1.520128722305654,-100.0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark11(-86.54749747638782,-1.1689745966787992,0.0,0.14017056254618615 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark11(-86.7953878580982,-1.4086402678527272,-1.5707963267948966,2094.072159265789 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark11(-86.84005422496958,-0.17280481663722647,-1.5707963267948966,-23.29584407194974 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark11(-8.690703989615065,-0.16912440042921179,-17.441241778898085,1.0000070202259168 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark11(-86.915579851302,-0.3168220044026664,-2.724640585952642,0.0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark11(-86.98116272757166,-1.5707963267948912,-43.18641787544995,27.21462991023256 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark11(-87.0535441148343,-1.4220475339363963,-90.66599608993674,0.5138979785666041 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark11(-87.22140233772451,-2678.9180362816037,0,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark11(-87.26639792197619,-1.3494655314514148,-100.0,0.7605544281326937 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark11(-87.28814420285275,-0.614490294153434,-58.99768188031469,18.036818935099753 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark11(-87.29231934578073,-1.5707963267948948,-110.47544851919736,-1.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark11(-87.4084798663466,-0.7655922946042082,-49.907451311567485,-0.04981979681865645 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark11(-87.4587376394353,6.604687415163309,27.232416042351495,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark11(-8.758508866361174,-1.5210115354145766,-1.5707963267948961,-0.9999999999999999 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark11(-87.68904222789908,-1.5707963267948948,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark11(-87.7004029683295,-0.0056328692936327375,-15.077545882541518,0.8571269025243898 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark11(-87.72938116232717,-1.0327676145239433,-37.91305483513341,-75.46750211631172 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark11(-87.76941137687044,-0.4679218740050146,-123.90031585812406,85.85356836295831 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark11(-87.7810070815244,-0.550188952859108,-1.5707963267948966,-63.933109643943084 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark11(-87.87698761903894,-0.20998683793508272,-37.14351431038846,1.0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark11(-87.89450504354767,-1.5707963267948912,-58.702111015793385,-0.06830339364532267 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark11(-8.803071232951874,-2.220446049250313E-16,-22.54930628336489,0.00725928221286809 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark11(-88.0516305516262,-0.6746773060497167,-73.41818992133464,16.62310783651017 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark11(-88.07658907508149,-1.3814092517836651,-1.5707963267948957,-2353.7666401449837 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark11(-88.08974632877663,-1.409843360470326,-19.040181077973592,-97.4193906663751 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark11(-8.809597802348657,-1.5707963267948912,-56.49557667954008,0.6026117146207604 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark11(-88.14926307537412,-1.2166517032510689,-53.328922716720825,24.01062456698439 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark11(-88.29320597761638,-0.7479627704908645,-34.508306402385166,-0.06255380622264844 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark11(-88.3627203384498,-1.5707963267948948,-94.66302703884946,1.0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark11(-88.37961516317279,-93.54004234321651,0,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark11(-88.39765715055229,-0.4550918405193317,-68.223596709402,0.026952171567926734 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark11(-8.842175953261716,-1.061250830034296,-88.47438394596546,1.0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark11(-8.84339142436417,-0.0737638371507732,-7.660278678121744,8.673617379884035E-19 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark11(-88.43811188549324,-1.1099039370054,-31.53031473486311,78.51310023187008 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark11(-88.45934741867194,-0.45271971787668625,-2.34717954673836,-8.972343051934644 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark11(-88.54426732098167,-3.378959335188606E-16,-82.8340459846242,2.7444715510984264E-16 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark11(-88.57164548447072,-0.1684349360105502,-43.75909324288519,-0.051530073217591496 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark11(-88.57766080851198,-1.355025745459658,-158.37221576351624,-0.8786148712544595 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark11(-88.7117381882352,-0.8756578844743184,-88.47854602078189,-1.4772765788457177E-126 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark11(-89.08548470061908,-0.4477900052697391,2.220446049250313E-16,-0.9117093908291692 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark11(-89.15227862802595,-0.8898373643396398,-73.1726038195574,2203.557063960715 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark11(-8.916527706700354,-0.005332860918065996,-1.0072923742519686,1.0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark11(-89.18637720830675,-0.5486660499548037,-9.779173446709649,-0.7450823768142261 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark11(-8.950844980273422,-1.131823805549285,-67.06925876539573,-22.1596833328801 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark11(-89.52881008348578,-0.6722367920221469,-73.4670244095116,-38.68093717292442 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark11(-89.59144424118209,-1.5641677097271593,-8.881784197001252E-16,-6.077016398992825 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark11(-89.59325811514387,-1.5698748505607885,-1.5424828330283178,0.6485536604388384 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark11(-89.5956468840885,-0.07483254697705947,-73.82742735936014,0.0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark11(-89.657923111847,-1.5707963267948912,-20.906013004845533,1.0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark11(-89.74408226532812,-1.5707963267948948,-1.5707963267948912,0.6835084497495969 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark11(-89.81434464867162,-0.30303849582488174,1.6095792352961273,10.596107239660343 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark11(-89.81478428599999,-1.570630562787002,-85.74195916196845,0.5280023434324495 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark11(-90.01439944206115,-1.5706538151019638,-0.017564298858079475,1.0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark11(-90.15875092121784,-1.2045428612937734,-30.017902670393305,-0.24049189606613197 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark11(-9.024934574977328,-7.105427357601002E-15,-1.6917898783330259,0.10285823681206141 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark11(-90.26233968044691,-0.24391325777205086,-45.96105945423987,-71.01872718684601 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark11(-90.33095741125577,-0.19348480479565489,0.0,-65.11827950621938 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark11(-9.039351567271495,-1.5707963267948912,-54.918425955606075,0.06129603099260805 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark11(-90.4686561092909,-1.5707963267948948,0.0,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark11(-90.58216889408453,-0.34020999513757544,0.0,-1.0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark11(-90.62474998235285,-1.4605371319554572,-97.16413063362378,0.04592979112631328 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark11(-9.06496005891995,-1.4889612889036388,-36.06915972050816,1.0701329085895046 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark11(-90.84439243552562,-0.7540019101147544,0.0,2.7189673881189975 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark11(-90.85334787458285,-1.4979360625876965,-42.53880676033744,0.01294539539319467 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark11(-90.88668241409594,-0.8366145902612914,-9.087751546059232,-1.0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark11(-90.88760862401479,-0.21167766248286457,-7.284272011001491E-16,1.72741464496405E-16 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark11(-90.91211664623307,-0.024704320975536653,-7.6093800104052605,2222.9844656963573 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark11(-9.09235780010107,-1.5355606916125486,-78.338111186304,-20.912981026646136 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark11(-90.94937872045614,-0.6103145537651018,-45.230481932155115,-100.0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark11(-90.95815570552077,-0.4174414325399881,0.0,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark11(-90.99560344602365,-0.42549931926944456,-25.487036317496287,17.605647503866777 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark11(-91.01409166351324,-0.9183811444826517,-72.31891879261781,-1.0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark11(-91.03451812262233,-0.999711412684796,-52.579368352319754,-0.695021168893911 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark11(-9.104402435647186,-1.5069816440541468,-28.589364486937225,-0.6213084575153924 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark11(-9.139783505950064,-1.7763568394002505E-15,-26.46001440787426,-1.0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark11(-91.6310009516485,-9.943110769071106E-4,-40.40175519839865,-0.9999999999999268 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark11(-9.185624442309802,-0.8942155331419741,-82.75635345882803,-0.05354125747894232 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark11(-9.188638184809847,-0.9749463991125323,-0.019873991186488506,-1.0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark11(-92.07086553511017,-1.5499617596078297,-18.387837977619625,-1.0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark11(-92.23964928065851,-1.4200548833723405,-7.1939415264029805,-94.91038337024803 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark11(-9.228705834069846,-0.32645531842832154,-26.705310029959946,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark11(-9.24694649408455,-1.3674916861497137,-104.19069548114197,-1.0000000000002525 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark11(-9.250592128576328,-0.5202207694385018,-63.683227379031266,0.0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark11(-92.51928598729097,-1.4783721341341476,-31.582894369454422,-21.042478752690783 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark11(-92.52432749663609,-0.11661566006907197,-0.29952022904903425,-0.7284894576500173 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark11(-92.59210545203358,-1.4645564116714107,-2.9475797974040887,-1.0223415268753104 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark11(-92.59806395330168,-1.4066059612034627,-77.24116006179365,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark11(-92.63601294429824,-0.1794077218905325,-32.144594405361886,-47.55186217197836 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark11(-9.264219777396931,-67.93943405488,63.33647115531335,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark11(92.85646742773991,0,0,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark11(-92.8666475442178,-0.8707720075267588,-58.37243780483062,-0.018935247927380328 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark11(-92.96063910971111,-0.0019056479806738302,-78.08208262214605,-40.14752147864007 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark11(-92.98632953203564,-0.9193271630183077,-52.376592875725315,1.0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark11(-93.19704770366036,-1.57079632679489,-19.80395456860063,1.0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark11(-93.66975597628051,-0.04326072498959953,-80.65425369422728,69.65703949443409 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark11(-9.366991074018177,-0.12045571680779332,-1.5707963267948961,-0.036611784640660075 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark11(-93.6703139184221,-0.18833925452753075,0.0,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark11(-93.69535391786695,-0.2129220655801767,-72.77248496248376,0.0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark11(-93.82355347662744,-0.07445282666358968,-99.08527166868247,0.056674794536986026 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark11(-93.92499485328777,-0.10040792155607216,-100.0,-1.0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark11(-93.95622691092629,-1.5678717572632057,-67.09909305035316,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark11(-94.07289683191208,-1.1643602947647553,-27.074263086284247,81.79919900025914 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark11(-94.14931075645272,-1.4059341642713727,-30.510423370118573,-0.9994788035144917 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark11(-94.1513366998344,-0.09006100533615487,0.0,2177.3093418330327 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark11(-94.19589546368435,-0.22009582944489062,-47.3372349048453,0.02247279563745193 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark11(-94.20166030444973,-0.40640202722600904,0.0,-66.5628454955013 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark11(-94.22330452250299,-0.5143346399615457,-100.0,-0.06255256580305028 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark11(-94.39211238638701,-0.11989190116352211,0.0,-41.0072123768708 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark11(-94.4579062763213,-1.5707963267948948,-163.82172019003144,1.0000092237304248 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark11(-94.56439144990273,-0.6088418753942457,-100.0,-0.6363117488591881 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark11(-94.60229191503865,-1.561283466072774,-72.47937793003001,-1.0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark11(-94.60854213530497,-0.06556999185180779,-91.86370164185955,-56.175450958185834 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark11(-94.69150733568259,-1.1858825231402166,-0.002246646472318777,98.01928867835858 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark11(-94.72264604818163,-1.2616807314964205,-5.784435249114409,-1.0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark11(-94.81624169688207,-0.41397029697837406,6.605796096563367E-16,0.867792984462868 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark11(-94.8512169935182,-0.6359542535489826,-65.22530413888954,2.1921636063236294 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark11(-94.96882564698659,-0.36499420097650775,0.0,8.645163535653227E-224 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark11(-95.03494643529417,-0.5005480124466404,-43.01210807258239,1.0142708694755458 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark11(-95.04298532824693,-1.428082028728299,0.0,-60.5674096862607 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark11(-95.04572689653193,-0.15213547927894633,0.0,-0.058897847834450776 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark11(-95.04669871067973,-0.06907268928627897,-0.011803518022688142,30.963742084576296 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark11(-95.14755562988958,-1.5017585595717322,-62.39300854445409,-0.8677225073671175 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark11(-95.23700040049415,-0.10522740370306721,-47.04941265629381,0.5472015844190408 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark11(-95.28575169166285,-0.6971051836147617,-1.5707963267948966,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark11(-9.529774560149566,-1.2592917039316172,-77.1181568451857,0.037678136418039854 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark11(-95.31120556633026,-1.5135972229240025,-94.42034863464326,0.0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark11(-95.33658921430019,-87.88002888973409,-6.2164612058834905,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark11(-95.34118732475551,-0.3214945798291817,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark11(-95.4205649070664,-1.1103002913788376,1.5707963267948983,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark11(-95.61736513299859,-1.5589474384936106,-15.293832649819155,0.9511113250552781 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark11(-95.62232609616328,-0.08490144703275682,-6.076342446421279,-1.0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark11(-95.79937661688962,-0.427645573200494,-84.413054199528,-0.8619305968321628 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark11(-9.58603386134428,-7.105427357601002E-15,-44.19997182632318,-1.0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark11(-95.88576136627907,-0.9284878632157396,-1.386763157841694,-1.0000000000000018 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark11(-95.92719967869563,-0.37310275451331487,0.0,-0.1893018449300623 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark11(-9.592944226516465,-0.1594793260180012,-1.5707963267949054,82.26947954272043 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark11(-95.93210477795456,-0.5295878298009191,-70.19251072237851,-0.9999999999999998 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark11(-96.11638413554647,-4.440892098500626E-16,-1.1426306062984248,-94.00938249638 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark11(-96.149562399597,-8.881784197001252E-16,-13.466021963340312,25.01952382334406 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark11(-96.17005239658023,-0.8961797059803748,-80.08799711745058,1.0000256507584342 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark11(-96.19877559356935,-0.11114648720427096,0.0,1.000000000000007 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark11(-96.24263378013883,-1.1520997612437078,-52.45027927545827,-1.0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark11(-96.29954663635237,-0.845631153209199,0.0,-63.72840922078922 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark11(-96.3105093457589,-1.5707963267948912,-67.25362210933156,-2302.76294453047 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark11(-96.35700518495804,-0.7692709749203717,-25.225543084832694,86.30844405080276 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark11(-96.36672161755656,-1.429129182525416,-100.0,1.734723475976807E-18 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark11(-96.39188086290758,-1.5707950889169242,-64.52138955441168,0.13175970036649498 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark11(-96.39408898681766,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark11(-96.42524733945515,-1.4040272383679289,-73.52831188176887,1.0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark11(-96.50725975900134,-5.758458895985223E-17,-6.358712802937276,-0.3754564102666883 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark11(-96.53536967464238,-0.637331221846086,-135.4793270818004,-1.3145071126041614 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark11(-96.64699653539832,-1.0471303454849705,-83.1200633637816,-0.4130273323572019 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark11(-96.69234121644155,-0.5056383253951586,-38.940657028553886,32.47875686633039 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark11(-96.69622464758574,-0.8617384899337607,-69.93188620322108,-1.0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark11(-96.70433432402199,-1.2180437830125719,-11.445091356502019,-76.48374042051144 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark11(-96.72375197446505,-0.030950371240777486,0.0,74.04200510670364 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark11(-96.73980349545228,-0.9255555316458257,-18.425742434591342,1.0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark11(-96.75552836760721,-0.6735137817749148,-51.03554790912912,3.666860342335184 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark11(-97.18266093250112,-0.15084725786189682,-5.551115123125783E-17,0.0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark11(-97.19407382804913,-1.26217205552377,-84.08350976466753,-1.0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark11(-97.25447732049388,-1.5261425811190095,-100.0,1.0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark11(-97.53481433109101,-0.5453929807757627,0.0,-0.7855630544997931 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark11(-97.60005909415212,-0.7652764517798556,-57.295509701745594,-0.2650667881416666 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark11(-97.64926494956318,-0.5086997299038628,1.570796326794897,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark11(-97.68865786386657,-0.807386873690362,-66.28111469407413,0.9999999999999999 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark11(-97.85497379154585,-0.05006638853791601,-55.48214992551364,-25.988159425380033 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark11(-9.789709737588753,-1.5707963267948963,-44.41490976299647,-0.49391873270305897 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark11(-9.791681583724753,-0.23694487607344827,-86.77651523615695,26.45261255335731 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark11(-98.02351882008855,-0.6363402082207407,-74.16116794355926,0.0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark11(-98.1561271292123,0.175322310016547,0.0,-0.15320372871420568 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark11(-98.22585754152466,-1.0023518160302853,-1.5707963267948966,0.0625634820459325 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark11(-98.2290572546361,-1.5707955153519113,-100.0,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark11(-9.824314872276972,-1.0069992696234056,-1.4946401688421385,12.60626247672887 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark11(-9.829040573509378,-0.4646590683418287,-80.23935315756904,1.0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark11(-98.42831952547037,-1.5707963267948963,-26.11114366591615,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark11(-98.79683498714891,-0.3143157727582766,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark11(-98.8226633022276,-0.2852864099861655,-1.5707963267948912,-0.13541217676763173 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark11(-98.95987423296259,-0.04210766511875627,0.0,1.0430409894447978 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark11(-98.96896906313418,-0.47445180794346964,-67.10877204750616,-90.18523169360037 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark11(-99.16855415688126,-1.5707963267948912,-100.0,2.710505431213761E-20 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark11(-99.37957188419385,-0.016805052305518493,-1.562972553903512,1.01351378244372 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark11(-99.41439705895968,-0.09597703462875856,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark11(-99.4932814680462,-0.022424764816691756,-11.769964089896316,-0.0380739545124589 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark11(-99.55984172902863,0.18174205069346297,0.0,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark11(-99.56046465474552,-0.9685870936036414,-3.2111203812921474,0.06255316297024946 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark11(-99.7603168512923,-1.5611422304991907,-28.588863780694574,1.0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark11(-99.78877006014636,-0.42560215878641916,-0.12265566704633588,0.8696561378101352 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark11(-99.85905488463564,-1.5504667811045736,-8.198722313922747,-0.3621038711447574 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark11(-99.86381203954389,-1.2844800452912155,-17.278759594743864,0.0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark11(-99.8640502629198,-0.16902141591063602,-55.6839674781608,1.0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark11(-99.87376645901242,-0.0013976350358842447,-100.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark11(-99.87382936755166,-1.157233618444859,-50.087794854378146,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark11(-99.94820500449194,-5.551115123125783E-17,-81.5298990167519,1.0658007727243861 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark11(-99.97274892702191,-1.5707963267948963,-1.5707963267948966,-0.054094845469856934 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark11(-99.99456054325316,-1.1942319027793487,-12.99605839842259,-1.0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark11(-99.99778509510178,-0.203877576582843,-1.5707963267948966,-1.0000054478870577 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark11(-99.99999999993959,-1.026034588948057,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark11(-99.99999999999936,-1.0709754512477072,-1.5707963267948966,-52.204762238288794 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark11(-99.99999999999999,-0.0011419959538899935,-74.90738298003713,0.9999999999999999 ) ;
  }
}
