import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
//    0.8447494747825337;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.002344677036660867,1.0000000000000144 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.01440990055242252,0.9982104223108921 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.024720229412837802,1.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.042486048862859255,0.5168825344253238 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.0463453117970718,-2270.973653435115 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.0493280731091743,-1.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.05283283787177229,34.50042174396098 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.07287846772041112,-6.588873714519077E-83 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.08029740072529212,1.00000000000006 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.08577880720246553,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.10404056968783326,-2.5448967192452905 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.10688186466290303,1.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.11507780379464805,-3.093661116344009 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.12513404081111373,0.9999999999999999 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark54(0.001345862370527584,-0.8317552337163221,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.13973970457880425,1.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.14960310379844,1.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.15806226038992638,48.03178933230578 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.1635773661425617,0.8232778815822349 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.18486935782004144,-1.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.18491974180272738,-72.18856143580446 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.18645931188415676,1.298488542026277 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.19645650494142752,-0.598575873800107 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark54(0.0020774008898785112,-0.48115933048685133,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.22512953759295068,-0.9999945522737289 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.22558842017620986,-1.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.2550090563717977,34.695840712850924 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.2594726894442303,1.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.261498942738588,1.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.2868425223475603,1666.6771158874744 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.29433744381743193,-0.9999999999999992 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3103834350378136,-64.15576764113811 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3119643179418452,-74.05077145740948 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3123942089580798,-2.4623959591869334E-4 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.33620015217105625,-21.379753247656705 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.33916685304075755,100.0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3418479660377358,-33.60824974656743 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.42929849297129374,-77.78570883995157 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.4488354357805473,0.756003262807536 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.4857527877412764,-0.8438490471339548 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.49202686545877505,-0.8686343313779341 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.49422753448422196,-7.820768168536631 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5209897933351325,-70.24742529940468 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5492357065006065,-1.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5527445545798315,3.552713678800501E-15 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.555074789709675,0.9999999999999991 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.059005668071810236,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5903260562609772,-1.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6076992913801507,-1.000000000367529 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6143697685590443,-100.0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6406171499793134,-0.08195549533833146 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6529465487695819,-11.890996556163863 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6551459669378308,-1.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6606807816472929,62.99424921607321 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6761838686520116,0.28425631548505814 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6842456244950009,-13.6694476737762 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6929401027923214,0.1613528220878926 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7022796396400495,1.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7686020674522945,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7734314417809904,-1.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7799042470115755,-1.0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8069052599210305,-6.909279942531092 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8517786288940091,1.0000001195120773 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8568692338139292,0.0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8923092145181031,-1.0000000000610307 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9048899831482125,100.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9354561469078191,-0.057995987329473336 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9472890495448412,-0.04994923349433789 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.966463599842809,1.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9778301890725576,0.9999999999999999 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0313030479200593,35.27309189798476 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0677885714976834,-1.0000000056312341 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0718939773223275,1.0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0979318450236135,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1085810624526193,0.019761063241274173 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1258698559994311,-1.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1404773794492216,-0.991923219377376 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1560050147507699,1.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.160460542886331,0.2462757211081723 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark54(0.011974852238127998,-0.8387294008237447,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.2132085645526645,0.06255340791853858 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.2256220245711669,-1.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.232164295021948,64.06377968764369 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.2718351769848344,44.42200919827352 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.2933865032052294,14.351769759411923 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3301755217006304,-16.814983775507685 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3427611199166742,-0.9798695611090033 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3501679975255075E-9,0.602481637738236 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3657711113515366E-16,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3712214780376968,54.538287453704605 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3714766046975186,0.27501776830572766 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3805598404353823,-91.89242136037191 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3820322908254317,0.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4073785439057004E-6,-0.0296622722011331 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.423719807374188,-0.8107863695636366 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.431234732603467,-1.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4320561272389403,3.469446951953614E-18 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4433433062152763,0.9171100782785269 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4582479691243233,0.004273497236686869 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.478094280576707,-92.21169279063066 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4791413570099359,1.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4942559245025282,-0.49159738559705807 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.494713772104846,1.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4968624356709566,-1.0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4995826096168727,-1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4997637584203714,1.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999929745386367,-1.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999946913372229,-0.5095653576274732 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.499998786332718,-23.15273897000865 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.499999992022832,1.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.499999999998972,41.22218809625042 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.499999999999872,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999507,1.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999991,-1961.1601725281669 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999996,1.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999996,5.729771854359264 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999998,0.9999999999999973 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999998,80.32345612769392 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark54(0.015502147543109468,-0.09732031906508865,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark54(0.015728151518068913,-1.120481369092726,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.7763568394002505E-15,34.75807247864972 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.18254106117947,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.8986635233650311E-16,-1.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.21084226250123805,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark54(0.0,2.1175823681357508E-22,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark54(0.021189008559930944,-1.103432061517449,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-2.220446049250313E-16,-0.06255255807665568 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-2.220446049250313E-16,-1.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-2.220446049250313E-16,80.6346117853507 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark54(0.022208289949123355,-1.108570862350379,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-2.7755575615628914E-17,3.3246326400964695E-8 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.3066432183645329,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-3.4766779039175E-310,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-3.9331307177696174E-17,0.01262444917511713 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.40289208876675753,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark54(0.04268108373837265,-1.4090371528999919,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-4.337425709944281E-4,5.0052077379577523E-147 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-4.5091864600705484E-4,-0.9752611557418213 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-4.546776639775083E-8,-0.9987301851487688 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.4579214812682971,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-6.6944572973981415E-6,-1.0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-7.105427357601002E-15,2384.278835723104 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-7.179375847517111E-13,0.037386149656151405 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark54(0.07805299612197761,-1.4467449527158966,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark54(0.07961961996385725,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-8.48617107122074E-15,8.168475604373678E-17 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-8.700293655581654E-6,-1.0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-8.881784197001252E-16,0.0038133898560999135 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-9.466472984343405E-7,0.03898487596598274 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.9639738800803004,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark54(0.0984534094397933,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.1060053484662307,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark54(0.12367028239558756,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark54(0.13046818668629978,-0.1545609371922465,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.3385223321127486,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark54(0.13613603822998233,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark54(0.1410556860207271,-0.5049437399224912,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark54(0.1479281220237443,-0.670033524620834,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark54(0,-15.19326077266598,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark54(0.18416372735599396,-0.297202473885829,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark54(0.22184433401577353,-1.3079414868087451,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark54(0,2.3293156403881454,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark54(0.24468330641849434,-1.006490257679875,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark54(0,25.19450974181167,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark54(0.2666414922355784,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark54(0,-2731.912102119382,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark54(0,-2745.0152530766904,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark54(0.27943443989589234,-0.5171447298770318,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark54(0.2853012288285579,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark54(0,-31.127075838004473,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark54(0,-34.29487109402511,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark54(0.3452542165980077,-1.499999999999993,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark54(0.3534942211445418,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark54(0.3714290029199682,-1.6213326681133857E-8,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark54(0.4071138537703263,-1.3294632392554746,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark54(0.4155614006685795,-0.9512007085207088,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark54(0.4163656559158433,-0.7383606488846439,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark54(0.4219740737731284,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark54(0.43138511313604544,-0.7675638585653053,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark54(0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark54(0.4638488831450196,-0.10155418276201189,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark54(0.465921937389453,-0.36395913133185753,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark54(0,-4.659454180167799,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark54(0.47528552633144616,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark54(0,-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark54(0,4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark54(0,-4.9E-324,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark54(0.5032060246933412,-1.2414886192439525,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark54(0.5195225213767336,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark54(0,-54.06890582678137,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark54(0,-55.869394520896584,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark54(0.5883780907483009,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark54(0.5986790427819955,-0.22845398508125214,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark54(0.6061622979558194,-1.187717832491197,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark54(0.6090084404476386,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark54(0.6106387169684488,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark54(0.6154429721268002,-1.245819597416883,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark54(0.6722567049421286,-0.0929944260329324,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark54(0,6.776263578034403E-21,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark54(-0.6839110288972705,-1.1763184599924221,-0.9778349334113114 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark54(0.6875019936033908,-0.23347954204446708,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark54(0.6911545760790511,-0.11689299138151898,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark54(0.6955995505304031,-0.09617886566668832,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark54(0.7333492699192052,-0.9154522424064706,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark54(0,-77.75621354939418,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark54(0.7812504457561431,-2.132699272924997E-5,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark54(0.7865063332685871,-0.02783247191273282,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark54(0,-80.19378314346291,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark54(-0.8137250968353995,-1.4418471532347577,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark54(0.8266358227967796,-0.7233281804931128,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark54(0.843181619334977,-1.2864878245359597,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark54(0.8438482626064653,-0.19184848219071515,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark54(0.8546643661560047,-1.2959848375183327,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark54(0,-89.25409987219143,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark54(0.8951650231792627,-6.164533594408032E-7,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark54(0,-90.20758518833662,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark54(0.9021957197996073,-0.8534566811533182,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark54(0.9139117850855598,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark54(0.922615053520289,-0.9576653991480555,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark54(0.9469983903382015,-1.4874214155799959,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark54(-0.9806007286013219,-0.23704186636818037,-0.022435922069624636 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark54(0.9892384971992101,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.0014445837438210216,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.00994859164656521,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.020317605694763152,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.020848496847786106,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.02410098710345599,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.045402848504470183,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.05135900245054642,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.06061263180953369,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.06596790235220928,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.07116851986635941,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.07302964085394359,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.09368744352281622,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.09400266388268036,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.11086828946536242,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.11898318624302973,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.12093444298283468,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.12257359154435776,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.12591363171473813,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.12617446952760764,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.1322351166407784,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.14261688849995213,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.16045742875446875,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.18474599860591923,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.19666696817877424,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.19831503199480283,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.23173639066417462,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.2359719623309711,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.2432391243759917,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.2724407267750384,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.2759939396044697,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.2901102846328476,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.29596156023789555,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3014494272762397,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3023506848941858,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3030967085794898,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.30542291640981856,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.30645068534141157,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3083499236971068,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3085904136813802,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3177412155929664,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.31849897272881267,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.32768153653190435,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3303102397932558,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3614452108447821,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3802923063507442,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3811676854341519,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.4057580862179064,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.40715482169437334,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.4277070659228439,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.4315342158632224,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.433709700784217,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.438178550313194,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.4695489846731995,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.4727638854141878,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.48079015652758006,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.52951994292351,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.532040577868083,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5399677812583381,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5885823029335255,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6358481680770511,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.6394004869191354,1.0000000000000002 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6548221011029469,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6713267192026761,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6905386693658233,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7000968056784742,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7095664089752485,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7105498993371834,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7405595261054447,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7413334384891733,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7565686892613889,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8056443901364854,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8183634625483478,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8225890380044556,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8263126676349692,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8346122175412081,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.840217448329326,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8459476785248605,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8740410398366996,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8788115143748882,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8828150309183583,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9084555376950014,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0202475659630217E-7,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0213487200051112,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.0220289027105451,0.9803976810059952 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.0422409038092635E-5,5.840139751765074 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0422551284133874,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.059683567673923,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0691807338847172,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0860501582709605E-8,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.1809960183163342,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.1861005672506506,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2085327072990603E-9,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.211744938456451,41.90925324561161 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2447793264860518,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.253914839959261,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2833236115675173,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.295560369696702,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.3039766420240728,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.3075347706661848,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.3187281507987945,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4005076075283953,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.4015753535125373,0.9999999999999999 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.410417264104842,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4184401366328516,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4360428541472938,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4560229436056596E-9,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4579050903836495,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.463556767659945,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4654499930453566,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.478317681143099,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4855599228197436,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4939158097741094,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4976040354351903,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999901047916,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.499999997386408,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999978900351,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999537086,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.499999999967515,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.4999999999999876,-1.0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.499999999999993,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999967,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.532224545338211E-7,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.6384517462868022E-8,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.8081450741188848E-8,-23.137304299192873 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.9560064588700447E-16,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-2.286477647161518E-6,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-2.3544615063370884E-9,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-2.3866667562250046E-9,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-2.6456192493600976E-7,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-2.8928788187320526E-9,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-3.0616481826697645E-9,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-3.2857673436243635E-9,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-3.6053263946581165E-9,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-3.7406639002814123E-7,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-5.404078469365617E-5,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-7.934125730266233E-7,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-8.065602746972151E-8,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-8.805613169244541E-10,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-8.863780438743779E-16,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-9.329339458296594E-10,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-9.589783402807487E-5,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark54(10.03433068274191,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark54(10.062468769683349,-0.7885152642839444,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark54(10.07238761924242,-1.2144253187746736,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark54(10.09223135408807,-0.10945772916345775,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark54(10.10143986093482,-0.4877683071122198,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark54(10.111627152608932,-0.7837121727825282,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark54(10.1629833495183,-0.6982105098418643,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark54(10.171480418987883,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark54(1.0211332495390764,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark54(10.223764830694842,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark54(-102.47514710403107,-1.471919012534883,-1.0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark54(10.266291221395264,-0.8094513899650506,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark54(10.278043524960779,-1.433635313896024,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark54(10.327813308811471,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark54(1.0358464729981776,-8.102415856581879E-7,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark54(1.0415098939128833,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark54(10.42179531453248,-0.4704862436111661,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark54(10.426121762971661,-1.307147818963287,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark54(10.432160831588064,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark54(10.440371309777646,-0.564332037694242,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark54(10.488279308647881,-0.7229958356869189,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark54(10.516101312949488,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark54(1.058793120563024,-0.7196153186974525,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark54(1.0632704623102267,-0.10056695740530941,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark54(10.635995509618652,-0.04551006098258448,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark54(10.648443458556917,-0.7106929220423561,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark54(10.657273390128807,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark54(10.685455931036088,-1.1364189413886319,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark54(10.710083340365244,-0.08812020373159957,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark54(10.750097185932383,-0.16416720394603446,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark54(1.0808886952729004,-1.2271680955562179,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark54(10.882645526497086,-1.0866191383550508,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark54(10.926040444343158,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark54(10.969044234174858,-0.8704974691813121,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark54(10.99486805742859,-0.08121537376075999,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark54(11.01578939348002,-1.3314386144437291,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark54(11.063785196872313,-1.2648656354825244E-8,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark54(1.109642026668297,-1.499999999999993,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark54(11.128759353111064,-1.0516197833874585,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark54(11.17256034622875,-0.37657853723803214,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark54(11.178602175933477,-0.8114708972134972,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark54(11.22849412936533,-0.9105574134872425,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark54(11.246750648154276,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark54(1.1254043310376822,-9.34448325078195E-8,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark54(11.259962589573774,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark54(11.305858076805327,-0.22837680281251194,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark54(11.305875777906408,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark54(11.31526732258159,-0.8671434358919567,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark54(11.362136338836052,-1.1226187295793215,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark54(11.400780255099136,-0.29535746911636096,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark54(1.1407594461982313,-1.0612757055460378,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark54(1.1422526864636597,-1.384948493313694,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark54(11.43627006380575,-0.2091678564816992,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark54(11.437704905074732,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark54(11.443492549903425,-0.7926732571885573,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark54(11.463280620085598,-0.5087647824740742,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark54(-11.466991972097121,-0.008278580964062823,-0.0436023226710042 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark54(11.481924632691914,-1.0198573254023318,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark54(11.516853626366029,-0.8231985285239318,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark54(11.5274981803997,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark54(11.535199370360763,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark54(11.547110683433687,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark54(11.580278361985336,-1.1775092318870806,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark54(-11.586436126951824,-0.05093407302289277,-1.0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark54(11.586901723424639,-0.6437840847458176,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark54(11.590980854455449,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark54(11.594852982043008,-1.3855831008644799,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark54(11.598785972400094,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark54(11.613662537550283,-1.4905562056513526,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark54(11.672788954723094,-2.47843441261949E-9,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark54(1.171140112484494,-1.3109633393386702,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark54(11.728756904754418,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark54(11.733008524669785,-0.5026839007861241,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark54(11.752249040800118,-1.0253359396772352,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark54(11.853885064949587,-0.6864498636646541,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark54(11.857299907725885,-0.03804800282562563,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark54(11.90045817670387,-1.4200164279521061,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark54(11.939201624131895,-0.0045558301569723,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark54(12.030495191625855,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark54(12.049490457574231,-1.492626787293024,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark54(12.049955698886997,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark54(12.1429530175932,-1.2641613131617002,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark54(12.151977987053646,-0.17240378808704637,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark54(12.174601473772555,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark54(12.203021216252797,-1.103173700572201,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark54(12.205928891659411,-0.22401659292130205,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark54(12.217464422507817,-0.14120209169976938,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark54(12.232336179160672,-1.3903881028742517,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark54(12.240859713143081,-1.2947619202116254,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark54(12.324646688507457,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark54(12.329348368748882,-0.28284465990427154,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark54(12.331703650865137,-1.4262009454039655,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark54(12.3964360485848,-0.25794930878587924,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark54(12.399788258201752,-0.9170189298548065,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark54(12.405696573417064,-1.4959491238005125,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark54(12.41498331885711,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark54(12.418808101285943,-1.5185519329256499E-7,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark54(12.445915447485142,-1.3239570374263065,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark54(12.468763947273473,-1.2430422847760525,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark54(12.498696713356509,-1.499999999999996,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark54(12.553703597915174,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark54(12.594165077718447,-0.8460306298538448,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark54(1.2635782664846005,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark54(12.650363146721787,-1.0240493388298892,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark54(12.686830680405762,-0.009202851312494431,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark54(12.702800140436125,-1.0924786686274452,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark54(12.718066927132334,-1.0455651454655008,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark54(12.727146629947143,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark54(12.747574556029932,-0.20407049139490052,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark54(12.759246716413013,-0.06014647206264212,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark54(12.775342349154705,-1.4999999883489123,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark54(12.778895292274342,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark54(12.78839817156015,-0.6343907350181568,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark54(12.792051283139742,-1.4767467214935248,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark54(12.792190215900206,-0.2718178796437032,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark54(12.803993801602573,-1.2118211743845677,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark54(12.851025720389941,-1.4679670503830806,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark54(12.853743750052544,-1.1721478201574764,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark54(12.867885515255793,-0.7271453291517513,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark54(1.28764381145821,-1.0799698505875268,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark54(12.90617980502943,-0.00930737808067783,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark54(1.2944871763085501,-0.04860064930928498,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark54(12.948193493762512,-1.499999999999993,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark54(12.96639095986069,-0.25785949987419343,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark54(-13.022573123738724,-1.4999999999999998,-0.27389498943118573 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark54(13.042089683025921,-1.3159108547912612,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark54(13.069601777071881,-0.5353304945389898,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark54(-130.6972964375735,-1.211508061773468,-68.52622467572142 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark54(13.073276048622775,-1.2450358168960698,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark54(13.082991028029696,-1.2757127203826917,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark54(13.149226993072645,-0.7824025012234325,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark54(13.233940992557908,-0.14776790142241314,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark54(13.238980327024152,-0.6884063452508966,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark54(13.25181349773532,-1.4999979917665975,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark54(13.269369037848918,-0.48876356339526295,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark54(13.287160375294675,-1.2066855954648004,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark54(13.295206730230827,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark54(13.297117201820628,-0.41300833333388765,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark54(13.337468456042757,-1.243092430008602,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark54(13.344122313251063,-0.7207099230322314,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark54(13.373383434768797,-0.06021218780367471,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark54(-13.375359236529023,-1.4999999999999964,0.05775415375534229 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark54(13.388423607233065,-1.210666401540064,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark54(13.423733978605082,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark54(13.437388624636014,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark54(13.464234471372764,-0.407777435934898,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark54(13.548084471251467,-1.0791715140211249,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark54(13.573424437450846,-1.4840620444490804,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark54(1.3634833308520087E-17,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark54(13.63747284628245,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark54(13.647172968394415,-0.08745704279893751,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark54(13.647344196578686,-0.8649128289734733,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark54(13.661793508457029,-1.4999942438155682,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark54(13.665654957503776,-1.3181690330661127,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark54(1.3697551548224567,-0.20179882873499366,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark54(13.769066747416641,-0.2064499847652681,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark54(13.808056146085054,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark54(13.82857348516741,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark54(13.839497456073914,-0.9398604594171758,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark54(13.841263567621255,-5.420568990222057E-6,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark54(13.859611338191442,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark54(13.886975712936891,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark54(13.890533459797823,-1.4560936232177217,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark54(13.899434120720784,-1.2047979957379154,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark54(13.90469711033316,-1.1055434724561568,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark54(13.909043116579497,-0.6520989643358639,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark54(14.001024096690713,-0.3655448568703008,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark54(14.004295983327749,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark54(14.006978972260015,-0.6447992872675741,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark54(1.400744286351923,-1.3959102182746932,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark54(14.011078111403204,-0.7985618204013178,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark54(14.029086739259796,-1.104334791501702,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark54(14.077120633436483,-0.24720363078062602,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark54(14.081930359621133,-1.0393797262941362,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark54(14.156783088952636,-0.06586752292867892,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark54(14.193099218830781,-0.5062455736018032,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark54(14.206871090588027,-2.783026945431343E-6,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark54(14.256109134530732,-0.4021250906907179,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark54(14.262589168053609,-6.899180241869826E-4,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark54(14.271012598879238,-0.7219647571805439,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark54(14.326560405052689,-1.416238859404075,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark54(-14.330268354546082,-1.1102230246251565E-16,0.018684394134546714 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark54(14.388106295465462,-0.22336211162924657,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark54(14.43342521764663,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark54(14.440018871086732,-0.3865002656276457,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark54(14.468065885187542,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark54(14.508325383986673,-0.9078287225921429,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark54(14.52103786177956,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark54(14.534849796941572,-1.0659494128023341E-9,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark54(14.544483022996097,-0.15649866461206496,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark54(14.554651767236793,-0.9670956826128829,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark54(14.568437416080144,-1.3128359697318772,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark54(14.570187322236933,-0.12990786634940266,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark54(14.573589776260661,-0.8535873867043205,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark54(14.6098154151086,-1.0565897811879599,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark54(14.620667753889165,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark54(14.623182961108313,-0.25183965290872834,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark54(-14.672358008911218,-0.9037870813463493,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark54(14.693694430699196,-0.5686723722211582,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark54(14.714055123591713,-0.17886225503115125,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark54(14.727946060454514,-0.4397068139353699,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark54(14.729378241366803,-0.05593219441047581,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark54(14.731601128207444,-0.2764775575046561,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark54(14.75154553340915,-5.058137721993667E-8,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark54(14.780240576681425,-1.450059543670773,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark54(14.83541569436941,-1.36406511404114,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark54(14.855086776788042,-1.4673979385352283,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark54(14.92528085264414,-0.9706104370883827,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark54(14.941620106017082,-0.7861609280481527,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark54(1.49449663576749,-0.9057798408463389,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark54(14.95462359165851,-7.83501564911686E-8,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark54(1.4964574103497252,-0.13820863600353595,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark54(14.988100033277853,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark54(15.001718193661702,-1.0747480472656576,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark54(15.010429414228476,-1.098256809655796,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark54(15.018022816670227,-5.417258425348927E-19,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark54(15.025899593572703,-0.8354582782560578,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark54(15.077197078192572,-0.4282542186205376,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark54(15.101933678235625,-1.0071048498387085,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark54(15.164723963612037,-1.3844079060892047,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark54(15.17363507004157,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark54(15.182268506216516,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark54(15.214205204388193,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark54(15.227189231081503,-0.8509432318320612,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark54(15.237712016194473,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark54(15.247213449878387,-1.0153766828846562,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark54(15.280433029723369,-0.5899869043346584,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark54(15.29881870758958,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark54(15.328281246067373,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark54(15.33248071326698,-5.2754975932931504E-5,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark54(15.342458759663945,-0.8618876438097083,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark54(15.349434934319904,-0.8771433206864034,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark54(15.38739036657794,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark54(15.43235817094402,-1.937419572766798E-4,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark54(15.464951746709053,-1.4999999889953624,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark54(15.471245024312182,-0.6282432755559455,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark54(15.516339203034889,-0.20071071346409397,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark54(15.543146532816479,-0.2421500752183844,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark54(15.56106500541409,-0.9475660975917384,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark54(15.567587149605416,-0.9137594381198649,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark54(15.62512900332979,-0.5427295628607283,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark54(15.65483543534458,-1.1241081775712456E-9,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark54(15.677200434534242,-0.9074978236345548,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark54(15.685290056342103,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark54(15.703609212481211,-0.039458402579389096,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark54(15.71185310821403,-0.39267002802968287,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark54(1.5729667867680774,-0.7441321590262504,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark54(15.730857756251519,-0.528644152311118,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark54(15.757159559277667,-1.0465368205881584,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark54(15.777464086509498,-1.2806688462224116,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark54(15.8087452479339,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark54(15.833700434231474,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark54(15.86192563691433,-0.3793832016495189,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark54(15.867561374408126,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark54(15.873643569236709,-0.22328027644557757,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark54(15.8846426317278,-1.150792461870239,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark54(15.905048999726773,-0.09558374551332452,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark54(-15.942550857650238,-0.24213903740084475,45.51862159602943 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark54(16.014315242641942,-0.30513241193554563,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark54(16.02202280081518,-1.1137196068241764,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark54(16.02248235606903,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark54(16.039883252306332,-1.0950363972896748,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark54(16.064423488586925,-0.6929474764021348,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark54(1.607485063743553,-4.663009462204273E-10,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark54(16.095789629051566,-0.6916309918906904,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark54(16.09854194815577,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark54(16.113391933386197,-1.1132878129580348,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark54(16.117964328705355,-0.06549800933767902,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark54(16.17815993986357,-0.5486514256521247,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark54(16.20334907879682,-0.855084843819327,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark54(16.21457230746597,-0.7226758128986186,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark54(16.225322419692155,-1.3571088475332629,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark54(16.229343158412036,-1.015653681104868,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark54(16.24261119894741,-0.0912922674998935,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark54(16.24722555319255,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark54(16.29150165296214,-0.43872486645099595,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark54(16.30105601664326,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark54(16.3315427289685,-0.27827666344875013,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark54(1.6334172538738017,-0.4784965966274797,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark54(16.359722504657952,-0.004098746494148764,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark54(16.36258332468175,-0.05861066899647582,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark54(16.37594684760431,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark54(16.406790515867172,-0.17054409403667137,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark54(16.440538330124234,-0.8355830261582042,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark54(16.448607855381304,-0.30286532516564696,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark54(16.514525151574574,-0.2667547141539899,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark54(16.521931121111606,-0.6811914074198733,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark54(16.52373682340344,-1.428027364199626,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark54(16.545400254292915,-0.024295636116083597,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark54(16.547209942012223,-0.5346223813864697,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark54(16.575628370190806,-1.540613439821144E-8,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark54(16.577640987378246,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark54(16.590794458997017,-1.4163208880827604E-5,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark54(16.595674915140762,-0.24848185732407035,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark54(16.5958648870363,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark54(16.60106776087045,-0.952253854819987,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark54(16.613764364354935,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark54(16.660649953545928,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark54(16.6879200995413,-1.1919682997238965,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark54(16.695068850876368,-1.0393731633367158,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark54(16.70682273141828,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark54(16.77199662023357,-1.3867103425090021E-7,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark54(16.839226431470777,-0.010583237104795362,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark54(1.6863266925006513,-1.4999999999097577,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark54(16.872627256432565,-1.466238342728535,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark54(1.6900290543540337,-0.8118002039351045,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark54(1.6947441213897712,-0.6524543094204696,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark54(16.958513492167597,-0.9593322318564983,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark54(16.96220926364647,-1.3494240679046818,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark54(-16.973789063389418,-1.3846990535597402E-9,-1.045139773367016E-10 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark54(-16.977871633480653,-1.499999701927604,-72.93121120244572 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark54(16.990119735090133,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark54(17.045439812315877,-1.1769488149659435,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark54(17.054547817197047,-1.1818554128555547,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark54(17.06026974593168,-1.481600603926288,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark54(-1.7079305258901687,-0.5491038919606552,-5.708623825595475 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark54(17.115428898862074,-1.4999999707874674,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark54(17.119751567374394,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark54(1.71287624765084,-0.9935981652354352,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark54(17.18663632513263,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark54(17.196998132283966,-0.41390320318504337,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark54(17.204932081918002,-1.4999999510078803,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark54(1.721965764743615,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark54(17.25036867237712,-0.5201791285879258,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark54(17.31404116864681,-0.6759745180814072,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark54(17.37086319711129,-0.957048629349714,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark54(17.371920899270137,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark54(17.377331181553075,-0.4676110232449471,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark54(-17.39167268251821,-1.4999999999999991,-20.017599616265628 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark54(17.40292724102875,-1.4908793445868382,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark54(17.430297654692872,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark54(17.471123963004004,-1.458150186318667,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark54(1.7490691200217938,-1.4999999998842677,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark54(17.54729385921503,-0.2821867108384879,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark54(17.56021332843285,-1.1529052932565307,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark54(17.581910693890325,-0.2952477687155082,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark54(17.61698175090436,-0.5987560142940698,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark54(17.64963997619222,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark54(17.668838622031586,-1.19139588123058,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark54(17.709761807538356,-0.5374094300770693,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark54(17.71220487679676,-1.40953989368586,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark54(17.718773056055454,-1.0409600011592666,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark54(17.745619626561336,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark54(1.7763568394002505E-15,-0.05611602345569766,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark54(1.7763568394002505E-15,-1.2115778155907435,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark54(1.7763568394002505E-15,-1.4716706503730468,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark54(17.770869932396977,-0.8662997618074931,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark54(17.786049900289626,-1.4423935549546671,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark54(17.792622119402424,-0.8955791882243691,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark54(17.79845630314305,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark54(17.800337401464475,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark54(17.821632184447438,-0.7992705436289509,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark54(17.852208890682107,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark54(17.86465503676746,-0.6653026536195439,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark54(17.891821849083684,-0.7165877580259266,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark54(17.916814953169762,-0.3045615034651661,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark54(17.923944361119553,-1.9948715950427565E-9,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark54(-17.959002479872794,-1.2364302436038224,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark54(17.970212664564883,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark54(18.045432484375446,-3.9677202631969783E-7,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark54(18.055829028858,-0.469208583778872,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark54(18.075167558576055,-1.0063246036670108,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark54(-18.097479457223542,-1.3675202928103456,-1.0000000000623253 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark54(-18.10131857310924,-0.9064028424352131,1.0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark54(18.1319254016979,-1.4999999959228527,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark54(1.8147647464315766,-0.7062875030168403,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark54(18.161910706773153,-0.12762433635110781,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark54(-18.193107749748467,-0.6975244282920379,-1.0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark54(-181.9345109518606,-1.4646054789062612,0.8667901148686425 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark54(18.21465072832129,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark54(18.218693610376953,-8.790994286323062E-10,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark54(18.22212730510821,-1.3178889881839093,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark54(18.288812705926183,-0.5261245306418245,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark54(18.297232205733295,-1.347460126367254,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark54(18.321236167315256,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark54(18.33472650200822,-1.4098796226494872,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark54(18.416211479852223,-1.0561804655030127,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark54(1.8443310105743605E-15,-0.7916089583466608,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark54(18.486500433883073,-0.2337238683655466,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark54(18.49319957781436,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark54(18.509467007379662,-3.1225570868508653E-6,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark54(18.524915619923476,-9.42256595886347E-7,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark54(18.53378980795389,-1.2599000354328411,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark54(1.8607729668752224,-1.4027758574055254,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark54(18.619702629203186,-1.2514967827251313,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark54(1.8643109751026241,-0.06302221045293079,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark54(18.672215584355747,-0.8232957614229601,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark54(18.727240913872606,-0.11935477073309657,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark54(18.749177775777795,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark54(18.76263296702632,-3.299524988647475E-7,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark54(18.787954244491928,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark54(18.829929853543565,-2.999464475067299E-9,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark54(18.879540022284488,-0.3476733458138721,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark54(18.960227795245046,-1.4999999999999503,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark54(18.992720097590833,-0.3261472752196967,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark54(-19.005029143873692,-2.618558495129573E-7,-2431.947674761936 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark54(19.006962152351917,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark54(19.02813762496318,-0.7798316160575229,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark54(19.06719367347381,-1.1855737814432885,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark54(19.07099519690523,-0.3164112981219702,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark54(19.114352418785955,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark54(-19.114788602582188,-1.1971008377233954,-0.36286329213145424 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark54(19.15740285527403,-0.016311284061941933,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark54(19.16332220715327,-0.9445974664854333,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark54(1.916364036462852,-0.0013665431893495894,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark54(19.16968541213579,-1.0033909756549786,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark54(19.17767867579056,-0.8397625904397104,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark54(19.201485723584028,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark54(19.22481087346975,-0.10112840298531212,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark54(19.22565304776387,-0.9457255948758396,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark54(19.230117493705308,-0.5833577052183185,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark54(1.9231218952711577,-3.2435808045052704E-6,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark54(19.23210811264839,-0.6345549081580231,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark54(19.234131627691323,-5.407158803367849E-8,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark54(1.9255847602959903,-0.22073187437013395,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark54(19.310375794818277,-1.425944237378903,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark54(19.318373257397894,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark54(19.32421012530762,-0.034999913166389854,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark54(1.9337549244989054,-0.6493084928760924,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark54(19.34222491511356,-0.08429112841680242,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark54(19.354785533996477,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark54(19.367981428606655,-0.10399040948033189,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark54(19.373668209572756,-0.5888431286963822,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark54(19.382522717881685,-1.1138301671861586,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark54(1.9399760224213338,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark54(1.9404138234548032,-1.4252317202210874,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark54(-19.407218456307262,-1.4708971638617379,100.0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark54(19.411388264677115,-1.208252857042254,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark54(19.450762598070245,-0.211500237055108,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark54(19.478358437604143,-0.12709225580467162,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark54(1.950029551437325,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark54(19.547759853847513,-0.9258010053162402,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark54(19.55559688919493,-0.4811300945590382,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark54(-19.575584820216022,-0.8385716830330252,95.3704247494839 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark54(19.585692074392597,-4.749461073260231E-10,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark54(-19.614949220395097,-4.789650337398165E-9,40.951297297186336 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark54(19.636758381216666,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark54(19.639337948057253,-1.4999999999698679,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark54(19.660181014205506,-0.8867474399778816,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark54(19.675363411770835,-0.5565837831967997,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark54(19.692417512177823,-0.03996516023345009,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark54(19.716559649888808,-1.0124580311051837E-15,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark54(-1.9721522630525295E-31,-1.1102230246251565E-16,-0.06255253273042635 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark54(19.732134818499198,-2.7930096381017446E-8,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark54(19.733220217855894,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark54(19.73702297241256,-0.16833502995766159,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark54(19.754893827004786,-1.1340269155540188,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark54(-1.97606068944574,-1.4838956306411395,-1.0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark54(-19.76975747947722,-0.8454969151822471,87.53250900534186 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark54(19.773861519154124,-1.4392225114066832,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark54(19.77798404230846,-1.2353121912132785,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark54(19.78584967100028,-0.31388328974409563,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark54(19.800003063561803,-0.04144496935050458,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark54(19.814991172049744,-1.3385105490327334,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark54(19.90866039116898,-1.2353866344124906,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark54(19.91225441651776,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark54(19.926721546557328,-0.22975257709937935,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark54(19.95672905722345,-1.1157297167967801,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark54(19.958813963702738,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark54(19.963346095938732,-0.29356726109297426,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark54(19.981746217681916,-0.14887492724525397,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark54(2.0070253205573194,-0.12161259399983344,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark54(2.007075002163321,-0.1968242023538025,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark54(2.0099128171707186,-0.21320172692427103,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark54(20.113366006877115,-1.1637989703290326,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark54(20.11490550122916,-0.6453399410908518,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark54(20.169191345574,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark54(20.17099032939072,-0.15724234522001668,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark54(20.174033517219982,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark54(20.185418714773434,-1.1832272856628325,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark54(20.19064155756102,-1.4382250235902975E-16,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark54(20.20151092411554,-7.993668822375316E-9,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark54(20.205644332386342,-0.6980446192225727,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark54(20.233367223529704,-0.47819124148697845,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark54(20.278870736870235,-0.8171549825214285,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark54(20.316739329566673,-1.2027992026843757,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark54(2.035580339665689,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark54(20.36238927786694,-1.359147672701967,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark54(20.36386500145873,-1.404172330533045,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark54(20.424519106197693,-1.499999999999993,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark54(20.50536785677965,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark54(20.50540315387022,-0.14561344249182184,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark54(20.506604520894594,-0.22378408939222572,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark54(20.547153344483533,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark54(20.551019488414042,-0.1925833569060551,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark54(20.693498134663262,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark54(20.703780560492135,-0.6018451041834276,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark54(20.731607359409274,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark54(-2.0732360013291427,-1.4999999999999996,-1.0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark54(20.78860348393577,-0.7601930614050082,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark54(20.86159641341503,-1.492973534331649,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark54(20.86938958544377,-1.4807977227945912,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark54(20.87395740228027,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark54(20.934605564792136,-0.9429091061544241,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark54(20.95758420974117,-0.44836664082427546,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark54(20.98258586836005,-0.10966738911700458,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark54(20.99105404494954,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark54(21.011477148671744,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark54(21.041196806057727,-1.499999999807252,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark54(21.071999714681056,-1.311021314959632,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark54(21.07228922766049,-0.05646691237272994,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark54(21.073770589646106,-6.456990988297621E-8,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark54(21.087557598678416,-0.5906066024679852,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark54(21.087927156284223,-1.3678214159302176,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark54(21.09199974421409,-9.264653524808782E-4,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark54(21.09683424442828,-1.4999999997911402,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark54(21.12808243865025,-0.00889531284045253,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark54(21.130025131004665,-0.8214463761941029,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark54(21.16377163595368,-0.4710563488454027,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark54(21.171566397393107,-1.0532562225381392,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark54(2.122617550141928,-0.8400127995215695,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark54(21.24188172583206,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark54(21.300259074683964,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark54(21.30701803729545,-0.6260852860920945,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark54(21.32268645408528,-1.1950134588719712,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark54(2.1342353316547706,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark54(2.1400398844433823,-0.8203220328463807,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark54(21.408282549306932,-0.9879888194453512,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark54(21.410114831939637,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark54(21.414092378406316,-0.07318773765259837,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark54(21.42417572315334,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark54(21.47015521899207,-0.20635197594245963,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark54(21.472102035328348,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark54(2.1507411417458837E-16,-0.17167472069290515,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark54(21.55739743755325,-1.4092124582583179,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark54(21.56024349593369,-1.3245277852726334,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark54(-21.56159272340045,-0.16381388789490456,17.00819848280845 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark54(21.56968570413856,-2.340750893452223E-9,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark54(21.575816830396317,-2.4553601601239723E-16,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark54(21.611986132323338,-1.0681769403680477,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark54(2.1637108101164984,-0.7994733525900853,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark54(21.674499099330006,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark54(21.684147002890384,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark54(21.71705590223496,-1.336244366848234,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark54(21.764811346448482,-0.7049877289722986,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark54(21.768008567314702,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark54(21.80402402453217,-1.1384527128578534,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark54(21.80538491907445,-5.436257060460453E-7,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark54(21.873484189926273,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark54(-21.876406912090047,-0.10023688770267147,35.01370814781143 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark54(21.8931788120245,-3.6133932813356437E-7,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark54(21.91504555493475,-0.4264597246398836,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark54(21.919476633448173,-1.0505907137275812,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark54(21.922210107360335,-0.7250366137262639,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark54(21.923747643229056,-3.4700971498063433E-6,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark54(21.92501068272858,-0.523873341595928,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark54(21.927977399179262,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark54(21.939371544422254,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark54(2.1939826712796675,-0.042785345393444155,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark54(21.949331463474337,-0.26593613833461605,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark54(21.9557571099311,-0.2777010497179211,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark54(21.997279550644407,-0.28351943319586326,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark54(21.999683200549526,-0.8918033927451887,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark54(22.01991019125588,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark54(22.031738416801343,-1.006933723377622E-8,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark54(2.205128904327026,-0.7550558134510279,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark54(22.07442416314433,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark54(22.093988290420125,-1.4999999836319755,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark54(22.12802714848803,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark54(22.146596774703937,-1.3385243303919623,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark54(22.17644383609405,-1.3668179135961651,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark54(22.217453979405906,-0.8691081119717765,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark54(22.232693059985394,-0.2290270108931871,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark54(22.271852437062066,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark54(22.28794479775975,-0.15596374633062737,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark54(22.29421307979578,-1.3591800573675408,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark54(22.32224293699818,-0.7506949955709312,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark54(22.32662167071315,-0.016232896623936233,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark54(22.348482427189083,-1.24294061479371,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark54(22.392961815317918,-0.31077697807039006,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark54(22.393690107045728,-8.982475547667333E-9,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark54(22.399952984675004,-0.5763459359469685,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark54(2.2452919648851832,-1.646661603594864E-7,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark54(22.46868277526963,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark54(22.493053244139617,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark54(22.537261484369555,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark54(22.561430854242985,-0.9078729128371181,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark54(22.563938632622722,-1.2572066823151502,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark54(22.569945993643657,-0.35102789563331216,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark54(2.258489736097232,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark54(22.599005577717435,-0.18999819370843163,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark54(-22.638651876435027,-1.4665718057131232,0.034414432522409305 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark54(-22.641302344886583,-0.8253097365141732,1.0000000000089382 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark54(22.671528617983398,-1.1523330350123273,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark54(22.693497080881247,-1.919151691790521E-9,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark54(22.74954860436819,-3.6016681239424757E-7,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark54(22.76475108318455,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark54(22.794392746644547,-0.8647697010882425,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark54(22.809122635107855,-1.065536849215234,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark54(-22.8716144802311,-4.608401482430033E-15,-1.0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark54(22.877818163744063,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark54(2.2883219497499,-0.47877871530249827,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark54(22.903026345569593,-0.669620143681038,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark54(22.906179138265475,-0.1235682618735648,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark54(22.90929807231945,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark54(22.92120484083089,-0.22849857833041992,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark54(22.929569500456324,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark54(2.2936638503851157,-1.0700819774004628,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark54(22.958037333906272,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark54(22.984943862176976,-0.8060420820796566,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark54(23.00956854568659,-1.410167677551267,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark54(23.02006623259618,-0.2835722501310506,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark54(23.03811793412447,-0.7304942799145882,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark54(23.03993611538162,-0.9251999429275795,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark54(23.05008802845734,-1.0064694189340675,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark54(23.12571567387303,-0.4637075178396799,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark54(23.12696020832432,-0.7744208986382477,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark54(23.143575361468965,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark54(23.146175601907103,-0.9728589285912275,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark54(23.17380955451307,-0.334510651431124,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark54(23.284929586498222,-0.9956056653439163,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark54(23.297143085498817,-0.7524471992848598,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark54(23.333244858991023,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark54(-23.43744445008543,-1.1027738984117015,0.0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark54(23.442666408103854,-0.7513203594921142,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark54(23.460187429124893,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark54(23.466710191810037,-0.8957544488628009,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark54(23.50451423456208,-0.9045824964258191,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark54(23.52501585069832,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark54(23.53187714292747,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark54(2.3534617172260006,-1.4190155199466739,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark54(23.546557616353496,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark54(23.551044915995305,-1.2775971501024936,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark54(23.580181600154226,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark54(23.58145451088798,-1.4999999999999467,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark54(23.587127750297938,-0.8921973448749387,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark54(2.362612770270033,-0.4359811695846876,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark54(23.62878479638909,-8.052779167966453E-8,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark54(2.3630554113494795,-1.3602184068718298E-7,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark54(23.630742934230646,-5.931160937343961E-16,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark54(23.6383229899652,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark54(23.662638115327766,-0.6754710274459654,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark54(23.666373065641558,-1.751967491718128E-8,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark54(23.672374007849978,-3.7194548184441522E-6,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark54(23.67470578215675,-1.420804878126546,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark54(23.676115356436412,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark54(23.70218514727637,-0.646803519807662,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark54(23.727205180315863,-1.0716339604386729,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark54(23.760052677743495,-0.15419178182695428,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark54(23.762734351224708,-0.11420694226562489,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark54(23.766831136062624,-0.16395967484634033,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark54(23.774937162516665,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark54(23.794763923463066,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark54(2.3797587231385364,-0.19068906468984892,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark54(23.836568842095375,-1.2454003278503478,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark54(23.865021264419784,-1.873298647074885E-9,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark54(2.3869375998381486,-0.8890191956737681,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark54(23.92011909487171,-1.4341504187762837,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark54(23.955488577898198,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark54(2.3967864811784665,-0.9953606829869557,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark54(23.986733874310076,-1.0973794446174008,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark54(23.987203589668425,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark54(24.007857314876134,-0.38641971346856874,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark54(24.065954408061202,-1.2256570766881596,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark54(24.086293954839242,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark54(24.10960710703823,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark54(24.190872381725267,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark54(24.231336042063802,-0.08856257908959453,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark54(24.246824235213353,-4.101486778188398E-10,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark54(2.4295394441941323,-0.5226283864706361,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark54(24.319490463808926,-1.4999999998939284,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark54(2.435516439788657,-0.10088113399643817,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark54(24.370690739857817,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark54(24.423361490403067,-0.36964028805463833,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark54(24.502155030532705,-0.8955456774033415,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark54(24.52785485616691,-0.31701291541132903,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark54(24.529165125212728,-1.0353419892537847,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark54(24.54508627123459,-0.9189616638002026,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark54(24.642364790884685,-0.9651899706637561,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark54(-2.465190328815662E-32,-2.0371336972796696E-17,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark54(2.467976919511434,-1.0413133770337613,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark54(24.68416875420699,-2.066062607493527E-9,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark54(24.709690796181178,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark54(24.716512745727695,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark54(24.72081047910865,-0.8996864395408544,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark54(24.785749721401746,-0.18590223982509374,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark54(24.78722481455594,-0.07998105250099004,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark54(24.803773695740666,-1.0809883989549522,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark54(24.81146169712183,-0.3684436483021756,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark54(24.846568847015618,-1.4999999999999805,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark54(24.860411863644533,-3.3388208838352705E-9,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark54(24.924181128046186,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark54(24.962165701033385,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark54(25.05081619310968,-1.1154791290403382E-9,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark54(25.057345285666386,-0.8248573955334548,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark54(-25.06308832310832,-1.3613641706505706,73.74717785336243 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark54(25.081711052157537,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark54(25.122802887984317,-1.1748684552633497,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark54(2.5128148785517226,-1.092778021657736,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark54(25.156336518120252,-0.6016735790527948,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark54(25.201394785020707,-4.3597704191769453E-7,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark54(2.52145255622699,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark54(25.222082016608272,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark54(25.241710754563186,-1.8304641726380817E-6,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark54(25.241996540473608,-1.013571001270924,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark54(25.2826814269078,-0.4949816289001303,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark54(25.28714513124592,-0.20235094497893158,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark54(25.296732013446594,-0.680729746143988,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark54(2.5344986816369004,-1.4498468686951371,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark54(25.36632768574232,-0.6133392882514812,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark54(25.381624082225837,-1.0415622099837676,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark54(-25.38304023418209,-0.5236412691990713,0.0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark54(25.391958394929787,-0.2297419299760174,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark54(25.40668582651751,-0.2141718977765663,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark54(2.543201070596836,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark54(25.445561535889667,-0.23140907734671903,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark54(25.451471435726702,-1.4999999999995595,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark54(25.457884131366356,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark54(2.54756893174077,-1.381380997530756,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark54(25.48097212001141,-1.0130268581426374E-7,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark54(25.50043153580305,-1.0682549421572323,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark54(25.504813531045187,-0.32412516512680356,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark54(25.536456312031987,-6.26639223112783E-8,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark54(25.54140138798907,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark54(25.639135311758736,-0.9674705523882602,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark54(25.642847503287108,-0.29570704833601136,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark54(25.64474600952444,-0.8789927485691114,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark54(2.5653355008114852E-290,-1.4999999999999938,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark54(25.693391390461784,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark54(25.755351220561735,-0.06580991213745878,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark54(25.802108903063697,-0.22071621829049226,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark54(25.80899767185441,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark54(2.5809621885472116,-0.936794259396881,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark54(25.821364987347433,-0.9773230140052769,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark54(25.86325468663553,-1.1200229356266354,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark54(25.906137673097078,-0.09301166511034306,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark54(25.927906115319672,-0.852802247046176,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark54(25.948791767088906,-0.792920223125277,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark54(25.958561684630812,-0.689372475752327,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark54(26.005922491685197,-0.6145163168921322,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark54(26.04480828787613,-1.328410764036035,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark54(26.050717133995008,-0.5838680424077656,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark54(26.052879958043885,-0.6646454183938927,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark54(26.0842374516949,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark54(26.085734615598085,-0.2137271837462813,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark54(26.0984604166691,-0.5597038499190926,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark54(26.099745942876524,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark54(26.191224659149228,-1.3371781449922429,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark54(2.620176976580254,-1.4777868140144932,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark54(26.233831217056238,-3.0709253798782927E-9,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark54(26.244998219894182,-1.4877656677956286E-4,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark54(26.26968840103052,-0.5041933024848995,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark54(2.63310142769042,-0.1946529710195648,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark54(26.334192232616147,-1.470443265070287,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark54(26.36883372513263,-0.6784553465022749,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark54(26.373136056891173,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark54(26.377335668635894,-0.22694341616226144,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark54(26.395733788817722,-0.4687158922215716,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark54(26.403796437903253,-1.2661158556898622,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark54(2.640606760640665,-0.9129663133803207,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark54(26.43832732906399,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark54(26.485129345087003,-0.5487281693900297,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark54(26.493154469878924,-1.1803633934792956,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark54(26.497980991926376,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark54(-26.498798229032673,-1.197686457706333,-1.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark54(26.52353386531125,-1.263229979466769,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark54(2.659966776848833,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark54(26.614020337893265,-1.1921779277275908,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark54(26.66502074866233,-0.758097183733739,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark54(26.67868695914204,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark54(26.694048600050984,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark54(26.71447727218358,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark54(26.775783273297435,-0.891803786936606,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark54(26.780466773256492,-1.235433210583082,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark54(26.790977170222675,-1.3259147346199427,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark54(26.797003031967037,-1.0162490899930492,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark54(26.840454284924157,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark54(26.852447648454117,-0.3761708127371577,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark54(26.87233998899408,-1.4999999999558802,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark54(26.884190503261763,-0.1510132634332395,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark54(26.893500265055437,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark54(26.923853071615028,-0.9937373462054052,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark54(26.94329524090078,-0.47676028152095284,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark54(26.945700725130806,-0.8795558243599613,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark54(26.96668176088197,-0.012766645004520294,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark54(26.97137163144833,-0.17124776754013737,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark54(26.985680599616273,-0.26598682700405796,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark54(27.005820424932537,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark54(2.7015948563465315,-1.2635700725361052,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark54(27.055016171837295,-1.0043482514631221,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark54(27.061194217238196,-1.4999999244313207,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark54(27.08824178815439,-0.2626253941398893,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark54(27.10658628925735,-0.5952324703302878,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark54(27.117056801589868,-3.0297067533834786E-9,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark54(2.7118876894236053,-1.0814567679246547,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark54(27.172105798506603,-1.4968967051625062,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark54(27.21531716557704,-5.781974428128063E-8,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark54(27.222557467763238,-0.6147580492703355,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark54(27.27696614909634,-1.499999999999563,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark54(2.728926796758876E-16,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark54(27.294655608592194,-0.40547334696132964,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark54(27.312143857059382,-0.7546889091466511,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark54(27.313285648542582,-0.14912671861112503,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark54(27.32703132360463,-1.066105373964235,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark54(27.35469975013649,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark54(27.355313548089242,-0.6787632425038055,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark54(2.7386150686411526,-0.9113635795603944,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark54(2.7437691446354573,-0.8862976284672995,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark54(27.457571109058215,-5.194284776667229E-10,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark54(27.478984727014392,-8.991589931951863E-8,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark54(2.7490264563891262,-0.24087369480949436,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark54(27.494871151781993,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark54(27.503550686992725,-0.06603365870117317,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark54(27.512818188471016,-1.268160919885256,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark54(27.523774309672007,-0.5927115498197102,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark54(27.528203369571163,-1.5136545944266008E-9,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark54(27.606630119655755,-1.249741946196595,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark54(27.626562861056602,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark54(2.7634298378562505,-0.9444048505056839,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark54(27.656021636237085,-0.7768714141981201,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark54(27.715314943452587,-1.8413675181777571E-7,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark54(-27.74579740268631,-0.6332993265179141,-2333.994389986732 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark54(27.759903439054263,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark54(27.823540869853616,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark54(27.82637668104531,-0.3956746662853887,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark54(27.868122542489445,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark54(27.87673302564796,-1.296694810884233,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark54(27.940797780191083,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark54(27.953166891998613,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark54(2.79828437780181,-0.36304131998506917,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark54(28.0047862779534,-0.8479566136398677,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark54(28.0090800222826,-0.24724373725305449,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark54(28.016154085249497,-0.6916775674047273,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark54(28.03175614045801,-0.03425250256171375,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark54(28.104232372743354,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark54(28.13402444766338,-0.7712510945236604,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark54(28.157859242741978,-0.43835883040443946,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark54(28.248466720713992,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark54(28.309664749983845,-1.4999999827292125,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark54(28.3336802584528,-0.29564005973415775,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark54(28.342586383033165,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark54(28.363658890541785,-0.6869787275235433,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark54(28.39141443461027,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark54(28.398594065136066,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark54(28.398648135693456,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark54(28.418497434633252,-0.10390949839523245,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark54(28.431785670672042,-0.07974312541795903,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark54(28.446429540629993,-0.7053452155223425,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark54(28.491597961206214,-0.14742464471483352,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark54(28.49457008653752,-0.924699955526801,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark54(28.540455963815837,-3.0241213788469365E-8,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark54(28.549616730053742,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark54(28.558927059223844,-0.7029292592696867,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark54(28.584199017636195,-1.2124770946787977,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark54(28.5933344178911,-1.1493752366279586,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark54(28.594079880635803,-0.27231670517746565,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark54(28.60206280944287,-0.9930702937566709,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark54(28.651663258574843,-1.3419645421358648,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark54(28.652263982184422,-1.3302025566414784,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark54(28.663789532232023,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark54(28.766576724080096,-0.8477395728662316,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark54(28.792251426844018,-0.26966604000657934,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark54(28.796639825480185,-1.0787712877391957,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark54(28.80845219927022,-0.16884383968418365,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark54(28.82164395645117,-1.2533027052095296,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark54(28.85523277579912,-0.40264039274339813,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark54(28.857659947355074,-1.0076870388106602,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark54(28.914703604024854,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark54(28.92538314673218,-0.8335894544262882,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark54(28.941787859041476,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark54(2.895612487697207,-0.41346115424509455,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark54(29.021785935432405,-1.0677364225158623,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark54(29.024188351202028,-4.362688197798131E-9,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark54(29.03782733506702,-0.6321272167288545,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark54(2.9057455982565727,-1.055193355400089,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark54(29.060285021408212,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark54(29.066952040275638,-1.0688436470460442E-5,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark54(29.074300803521126,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark54(29.07993859604838,-1.1276289987000732,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark54(29.102696812615505,-1.2315559688432103,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark54(29.110388366019492,-1.4999999999999822,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark54(29.221404275259054,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark54(29.22363836081533,-0.9242606054608323,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark54(29.23753003653607,-0.30652956117612007,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark54(29.25074991324277,-0.7865262871110228,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark54(29.289736633221654,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark54(29.30453948445072,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark54(29.305015444994126,-1.0935804407507943,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark54(29.306916720212257,-0.3116943132306531,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark54(29.32084345595906,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark54(29.32205657083435,-0.45673264841432104,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark54(29.37499196965817,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark54(29.39927178015148,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark54(29.404482665370494,-1.2784116624291215,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark54(29.423949844556205,-0.30216642666744864,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark54(-29.473530462061454,-0.3218227907124138,-1.0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark54(29.503712164252125,-1.1649597801535805,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark54(29.51963741205509,-0.06281866455316454,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark54(29.52843826961484,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark54(29.549559008212036,-0.9144796270401764,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark54(29.58662895142922,-0.7344178159518289,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark54(29.592331339409945,-0.18009336276848503,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark54(2.961005131304768,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark54(29.62573062377416,-0.7625497563909587,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark54(29.64720531046109,-1.4133555457599747,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark54(29.65752122910854,-0.5152147522756083,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark54(29.678299459175065,-0.28056198068569094,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark54(29.679526165953206,-0.47101688247778917,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark54(29.695288309828868,-0.39695978796628406,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark54(29.76587762859526,-1.056458342146739,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark54(29.76696403193671,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark54(29.778872695345314,-0.8098482332286685,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark54(29.794907971020677,-0.8245881687043664,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark54(29.807494180457745,-0.42920464710054773,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark54(29.824862378454924,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark54(29.847101619247212,-0.9033243265957651,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark54(29.874829643883018,-1.499999952363231,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark54(29.956579301846602,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark54(29.963832012439468,-0.4774880930961327,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark54(29.98501167291382,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark54(3.003664464678889,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark54(30.06270772514297,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark54(30.081054769021847,-0.9604353619916575,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark54(30.093854907716604,-0.45638310605610855,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark54(30.15406690155837,-0.4308482205345842,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark54(30.16471073321449,-0.1880448143757535,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark54(-30.167793255407375,-1.3855844005809965,-1.0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark54(3.0168056494964617,-0.15286852778666304,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark54(3.017082952951128,-1.0526036245938943,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark54(30.174365102484444,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark54(30.231948320505104,-0.21778560602778896,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark54(30.233576753979406,-0.5269507382471854,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark54(30.247771508324597,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark54(30.25319376358675,-1.370522269713889,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark54(30.271700152231695,-0.7720690727091153,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark54(30.27286182389711,-0.28716816479723795,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark54(30.288838428296117,-1.491696149502804,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark54(30.31452725444953,-0.9841784514444263,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark54(30.33498458910978,-0.9699474713885792,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark54(30.335544045932494,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark54(3.0376055170706024,-0.46659470355794674,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark54(30.393536667899554,-0.032593556813086205,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark54(30.419279676813215,-0.5855306246580092,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark54(30.438014328369974,-1.076998974670122,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark54(30.455640781643808,-1.1668539328068617,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark54(-30.455663087457868,-1.1974589947825383,-0.3866193030481501 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark54(-30.459254711133,-1.0087293638355561,1.0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark54(30.491659098056775,-1.0047541947474061,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark54(30.494238458640467,-0.40212311788210453,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark54(30.531013742894686,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark54(30.571379598004285,-0.9428809791174757,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark54(30.583768183203432,-1.0919630977004289,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark54(30.58901998011322,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark54(-30.631833534370557,-9.939017615748218E-10,-93.82743274186535 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark54(30.64890782746377,-1.4999999994616042,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark54(30.660560774652758,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark54(30.697126746357497,-0.546734436507748,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark54(30.721638573870674,-0.06164342774823428,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark54(30.760262033718746,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark54(30.764616007128893,-1.2525736505379794,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark54(30.768534930585503,-1.3144132715467058E-9,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark54(30.83542394087835,-0.5084478772738947,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark54(30.846033984522734,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark54(30.869366972579996,-0.7975347527228052,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark54(30.946925298110166,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark54(31.064115390906,-1.3478296859176553,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark54(31.115476015322457,-1.441555131401194,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark54(31.12118981562199,-0.45439149749775254,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark54(3.113083928279998,-0.22955428853761514,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark54(31.136839691780068,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark54(31.18946636620018,-1.47094062412188,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark54(31.201118863216415,-0.07209701456087929,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark54(31.24129373758575,-0.6353085417764441,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark54(31.24284185640633,-1.4999999999999432,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark54(31.29586045274782,-1.2766919580476455,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark54(31.30881420023809,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark54(31.330791759954927,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark54(31.333480743360052,-8.367429148720644E-9,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark54(3.1340934181185247,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark54(31.383154946797816,-0.45108823525106345,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark54(31.394739778452987,-0.5776928306702356,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark54(31.400160956472405,-0.39973319979836663,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark54(31.401131863285052,-2.4250466745101537E-8,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark54(31.402793848558503,-0.5614470915623831,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark54(31.403854087092746,-0.5792113115633843,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark54(3.141081968642689,-1.1214322789101033E-8,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark54(31.4319738634009,-1.1288957633094263,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark54(31.47152858912554,-0.18078007910520097,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark54(31.48235846339648,-0.3714704014080652,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark54(31.493480842450452,48.90216642593742,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark54(31.495681941655874,-1.4987867639435422,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark54(31.501765619375732,-0.6675685072282436,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark54(31.51645677328588,-0.43740442683989134,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark54(31.516577756491415,-1.3493116658870292,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark54(31.604784747776534,-0.03456751553942983,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark54(3.1628276198515124,-0.4305381367194367,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark54(31.65013588555837,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark54(31.65919908424459,-1.0430054168351575,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark54(31.670055962620626,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark54(31.711416391412968,-1.5123977686338324E-16,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark54(31.7240622359725,-1.4496461851287528,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark54(31.732196742417642,-1.4999999999693103,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark54(31.754515524457176,-0.36128525533868583,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark54(31.764871730750343,-0.5815636469833834,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark54(31.785946841967803,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark54(31.838473028226108,-0.5050134130798176,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark54(31.885887359589077,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark54(31.91396104743889,-1.0970699542312936E-5,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark54(31.922111971617397,-0.028132057020944456,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark54(3.193167511756286,-1.0734509372630754,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark54(31.932046036096747,-0.4408924979970692,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark54(31.949712004551515,-0.15052182594894192,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark54(31.952736064325734,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark54(31.987834543083633,-0.8912311142733834,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark54(-32.074159616155,-1.1917367845547655,0.8335041554144403 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark54(32.118290075428064,-0.024703028221281897,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark54(32.128319261872605,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark54(32.13575357205352,-1.1233547117723641,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark54(32.145344039040715,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark54(32.15630412790393,-0.26797052605068605,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark54(32.16948394777984,-1.4998364693494324,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark54(3.218770723061294,-6.783519445992007E-8,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark54(32.20888880291185,-1.140962867920553,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark54(32.2248334026001,-1.085271070946085,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark54(32.25102910414731,-0.7229303527533659,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark54(32.35376734023891,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark54(-32.36234574815427,-0.7453102346928517,-1.0000000000000002 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark54(32.371996816393924,-0.44787619950676316,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark54(32.41055281601172,-3.336223975678218E-8,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark54(32.44953901228689,-1.0508314390962843E-8,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark54(-32.46021846122434,-0.2799538974182201,0.051178386044375454 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark54(32.46151140001098,-1.151795657920954,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark54(3.252739808064276,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark54(32.538605905429066,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark54(32.55724431553796,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark54(32.64545072730499,-0.7578017734688989,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark54(32.65243697745502,-0.7179450828833206,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark54(32.66074313900543,-1.0138724823945395,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark54(32.679972370610585,-0.669898225087036,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark54(32.6876068110208,-0.9161909560571218,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark54(32.68798439204909,-1.257023622205411,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark54(32.736096388261544,-0.129339510560111,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark54(32.743540329625574,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark54(32.78636632481593,-1.4738092393587432,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark54(32.786934250880854,-0.5833769170156184,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark54(32.790098642385146,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark54(32.793075694488444,-0.0911406141571244,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark54(3.281371434992642,-0.4617218542355952,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark54(32.82113070501463,-0.7453163432912522,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark54(32.95902809183218,-0.6431295957121195,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark54(32.986589808667176,-0.14661764887603557,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark54(32.99884261364693,-0.38567435260672855,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark54(33.02559358381828,-1.1440368055363876,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark54(33.07116310311608,-0.7731729639274949,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark54(33.07914887521214,-0.7284648383479118,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark54(33.09110882241495,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark54(33.097355059621236,-1.4808801007760146,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark54(3.3149381978529817,-0.7566491003171052,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark54(33.19190010565967,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark54(33.20578517723706,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark54(3.3206244319600415,-1.2361133837091993,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark54(3.3209311469903753,-0.9809023803577439,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark54(33.23801503998132,-0.33338390142238694,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark54(33.246539814003825,-0.9929132576278912,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark54(33.27039244940647,-0.01964886471040294,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark54(33.27913716199776,-1.2753674801475386E-7,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark54(33.288608309680484,-1.2602555377997078,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark54(33.389225580912694,-0.28557913953848924,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark54(3.3425007609905037,-0.7926398969511492,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark54(33.43236397337563,-0.1417518789799317,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark54(33.43703953727173,-0.5245008678785414,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark54(33.46481367637992,-0.4205820338748225,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark54(33.56261679019843,-0.1957868242422895,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark54(33.56356576453706,-0.2989571903516759,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark54(33.61534590073954,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark54(33.63374809322672,-0.2245934233571814,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark54(33.64547654305229,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark54(33.707753273391816,-0.8025392268529343,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark54(-33.7383433341595,-6.00342540665767E-7,-1.0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark54(3.379868583107964,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark54(33.8109698519946,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark54(3.382830101508179,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark54(33.832501201876845,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark54(33.83998375992151,-0.8673697475829836,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark54(33.84421435827454,-0.03362529251386581,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark54(33.88158827859256,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark54(33.89612889711222,-0.8608113530867172,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark54(33.92318913128884,-1.1710885048998492,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark54(33.94310427752254,-0.2262192833689447,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark54(34.028615948208774,-1.499999999799532,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark54(34.0346825099178,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark54(34.07927731291871,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark54(3.4132895243729138,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark54(34.1541106468287,-1.1660806812209092,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark54(34.15735636097061,-0.288715711175926,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark54(34.211779924444464,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark54(34.230366420449954,-0.12168130127759724,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark54(3.424481023187358,-0.21976951824946095,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark54(34.28448236829222,-0.08814609084691107,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark54(34.29831400458724,-1.181339539609993,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark54(34.3584404576158,-0.021825100817354226,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark54(34.366110525191,-0.9466683836727108,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark54(34.37539077852177,-0.0011722371858530335,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark54(34.3794000741354,-0.5569637349546825,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark54(34.39777122638398,-0.0988716000505434,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark54(34.398734555422294,-0.557876896210858,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark54(3.440819912610806,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark54(34.42001085564373,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark54(34.47283942265358,-4.466701979905427E-8,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark54(-3.4488556805952784,-0.1298199578732533,1.0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark54(3.450711018007456,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark54(34.54023305363197,-1.3092623337686256,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark54(3.4594103386550614,-0.9446772195751691,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark54(34.595136896508706,-1.424576440060818,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark54(34.62775617537443,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark54(34.64923778795851,-1.2208387383556182E-9,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark54(34.68221415186804,-1.2153385114365562,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark54(3.469446951953614E-18,-0.49211859943128083,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark54(34.74835162041211,-0.4280418480474294,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark54(34.75464007509755,-0.5576231620686327,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark54(34.78588851316246,-1.3272811541687146,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark54(34.846128976391256,-1.2593675179751842,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark54(34.87046451131337,-0.5905798291033761,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark54(34.91980428798078,-1.2857966459204282,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark54(34.95291227214918,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark54(34.994189850156324,-0.033098089484644044,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark54(35.02487072649278,-1.3620684315106373,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark54(35.030268655592806,75.87825740534831,53.644191895818494 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark54(35.10016503993714,-1.3799866376753158,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark54(35.107520121492996,-3.348699357163301E-8,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark54(35.126408462044395,-0.11379034634020502,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark54(35.13459339256149,-1.4193926475438308,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark54(35.15225815873079,-8.381451876396831E-10,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark54(35.237021517041455,-1.3529357039080168,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark54(35.25259107486178,-0.6523184817572841,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark54(3.5351081139291365,-8.742938674796036E-9,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark54(35.403807705848486,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark54(35.42577336842561,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark54(35.46133668992147,-0.9699241265326748,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark54(35.46538630104481,-0.005033428566775304,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark54(35.46787006120869,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark54(35.471549017106895,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark54(35.475535005765096,-0.009283098670749695,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark54(35.51945017746709,-1.29594730468055,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark54(3.552713678800501E-15,-0.28467693437517383,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark54(3.552713678800501E-15,-0.46317671133111604,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark54(3.552713678800501E-15,-0.9075897946235187,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark54(35.532247068139526,-0.08079465021968879,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark54(35.53565914774387,-0.49634551503972935,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark54(35.53759154393924,-1.1870417172050054,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark54(35.54195751091196,-0.9487273370856979,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark54(35.54328155544005,-0.8464603748257207,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark54(35.550030083769144,-0.8974699574640681,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark54(35.55508144006504,-0.6606855009147985,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark54(35.62690232796937,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark54(35.62742624599988,-1.956991684884273E-9,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark54(35.648216221200016,-0.39391742993986445,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark54(35.65875184398253,-0.2035635970335523,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark54(-35.68992945249678,-0.013893940630830551,-8.00881845508082E-9 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark54(35.699619485237235,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark54(35.705117961984826,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark54(35.712549101294144,-0.7831255230050697,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark54(35.7382765784273,-0.6150103361640262,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark54(35.74423336241702,-0.29310040725928843,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark54(3.5784363663313314,-0.17394325559974738,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark54(3.5805036872324965E-11,-1.378793213618215,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark54(35.89438487746091,-1.1456296747695254,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark54(35.90857233959842,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark54(35.919130986945696,-0.20034756627659966,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark54(3.5930911914548602,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark54(35.997366103116605,-0.2993067608287845,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark54(36.002732541293405,-1.0490492008324745E-16,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark54(-36.00836389737655,-2.7755575615628914E-17,1.0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark54(36.06131753861831,-0.2835166665597164,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark54(36.06970106751021,-0.7595713870969689,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark54(36.07338778308036,-1.0071634397261064,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark54(36.07685348377464,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark54(36.098554008726694,-1.3261097449610624,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark54(36.10304915930271,-0.23715757094105117,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark54(36.13165432173166,-0.1614678603288448,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark54(36.195885584772725,-1.0987719734203191E-8,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark54(36.21319115219313,-0.08267905460985503,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark54(-36.25402998882704,-1.3287606426155558,13.195493255372103 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark54(36.25427640898013,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark54(36.25909746627275,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark54(36.26378452851211,-0.7696714064404775,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark54(36.265342234632264,-2.1072193552359008E-4,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark54(36.28455990888611,-0.15982679811298572,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark54(36.286173743674084,-1.4479210625688024,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark54(36.29064649673296,-1.4365891702140203,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark54(36.331946672034434,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark54(36.352948898235525,-6.84163601268988E-6,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark54(36.386734862848755,-1.3870088816967443,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark54(36.38721484868276,-1.1220366123111347,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark54(3.6415276670481407,-1.4807745675541075,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark54(36.41782767985811,-1.3580226902925374,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark54(36.420660400607375,-1.2359418465101117,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark54(36.42822257088043,-0.818261364397495,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark54(-3.6440224593359885,-1.435936758997069,0.9999999999999993 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark54(36.44781262729265,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark54(-36.59882275863857,-0.9044835039613588,17.149656826608876 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark54(36.603045449502645,-1.3427459867870084,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark54(-36.69288872323384,9.116806114467963,-50.753716407093144 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark54(36.709694318752526,-0.5988576278411095,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark54(3.672096962451075,-0.5618782380896308,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark54(36.72321366425493,-7.060077316088881E-5,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark54(36.725257262091816,-0.8743594979747371,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark54(-36.78080826585994,-0.4529810301951134,0.9701151583048291 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark54(36.79915238808212,-1.4999999999999938,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark54(36.819313643439884,-9.00356891769086E-9,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark54(-36.82045325877898,36.53593962270193,-74.09440136778025 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark54(36.83326063454517,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark54(36.841773870770965,-1.0850698764270739,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark54(36.85458577387984,-0.4871811341262316,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark54(3.6886911929082657,-0.5795863454430332,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark54(36.913363475566456,-0.7101992583838665,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark54(36.95422977792063,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark54(36.95458316714212,-0.978605902901279,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark54(36.95685887213244,-0.7121543539760604,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark54(36.98597870935879,-0.715613346009304,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark54(37.03179762554578,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark54(37.07634429966461,-1.0984722835881475,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark54(37.08015270654317,-0.13949988831856408,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark54(37.095910124288224,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark54(3.7097609997108667,-0.9206245284281661,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark54(37.112669814807475,-0.7061612120027361,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark54(37.1410368061707,-0.9228518803101995,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark54(37.14342743447857,-1.3477067055186291,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark54(37.17785171690556,-1.0644024376824177,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark54(37.187146745925276,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark54(37.27258131899711,-0.4024434359013007,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark54(37.28318830770067,-0.20383176096979705,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark54(37.312971487615215,-0.0076178024566493745,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark54(37.388755622339374,-0.3330812948761116,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark54(37.3985552912991,-0.6569369643021048,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark54(37.41892108553975,-0.5382821099960293,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark54(37.51057957585161,-0.8026654897296678,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark54(37.51456899804941,-1.429505826638612,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark54(37.586094082551334,-0.004128056117520271,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark54(37.60047077631236,-3.149545479196177E-7,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark54(37.60402562516872,-1.9177777976211928E-4,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark54(3.7702996785486107,-1.301561891784545,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark54(37.70900843717152,-1.0539557753006632,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark54(-37.71939120943504,-2.752312966380033E-5,-3.3087224502121107E-24 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark54(37.735486266280645,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark54(-37.76679870869268,-5.5665215353307995E-18,-0.6950796722049777 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark54(37.786415475133396,-0.37214413113656164,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark54(37.81572798888007,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark54(37.83992474408822,-0.01653037306920735,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark54(37.84078034810361,-0.5250062997638025,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark54(37.87432508406588,-0.8267160921607635,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark54(37.92320200578746,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark54(37.928234343968825,-1.2338331381768484,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark54(37.94776069966147,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark54(3.795441068482076,-2.231337566665421E-8,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark54(-3.797824190607656,-76.40009680358384,17.60863643945474 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark54(37.99782250742834,-1.395190986984332,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark54(38.06595051958172,-0.7604912958624608,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark54(-38.11296501545386,-1.0971173680053576,-1.0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark54(38.11910858484529,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark54(38.166275417284226,-0.18594851713143612,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark54(-38.17026993422177,-1.4926136010058946,0.5611796214961222 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark54(38.20833718499338,-0.254523788894204,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark54(3.82336643593867,-1.4999999999999984,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark54(38.24428272550058,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark54(38.24945317390811,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark54(38.27673664801,-1.0277129535422413,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark54(38.30975091501668,-3.3719688106371828E-9,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark54(38.32178326804374,-1.1420912239208607,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark54(-38.32219237540213,-1.2493819779910034,1.0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark54(38.331197695730054,-0.3316716353540947,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark54(38.36873765034107,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark54(38.39010293582692,-1.445064347330447,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark54(38.432432090096796,-0.7193999668348292,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark54(38.436609551638895,-0.5634857663039665,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark54(38.46322869243144,-0.19065726967837415,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark54(38.47254394364225,-0.16027281723613473,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark54(3.848094806143152,-0.6556050943474017,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark54(38.48487577861218,-0.8954572106664518,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark54(38.514452081238744,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark54(38.520731977930524,-0.6978943540383717,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark54(3.861745716090057,-0.6642318704671206,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark54(38.66955412329238,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark54(38.705777342511446,-3.5998592650270184E-8,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark54(38.707770474791005,-0.20939688561763603,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark54(38.72110006199725,-0.20237212633648483,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark54(38.734610087320334,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark54(38.74314339308731,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark54(38.74787691903714,-0.7470209358124872,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark54(38.78381585024272,-1.076581338175909,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark54(38.86327038161053,-0.05691792118424388,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark54(38.866762941680165,-1.143653279887232,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark54(38.86680778146144,-1.0982894179659484,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark54(38.90380037749662,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark54(38.90396670804225,-0.49160946603022904,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark54(38.90818769436672,-0.0186014744981593,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark54(38.94031252105627,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark54(38.95792590326326,-0.10867311128789936,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark54(38.98604250705765,-0.09916538576436837,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark54(38.98952837214918,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark54(39.094210959681504,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark54(39.13930773544621,-0.5549078435191035,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark54(39.15363891216285,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark54(-39.18028171390682,-0.8026635897038292,-29.790131566177553 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark54(39.20016503208639,-1.64644856354834E-9,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark54(39.23468748629783,-0.9150801148770673,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark54(39.247529813923336,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark54(39.284230726867776,-0.037376187908449765,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark54(39.3201535719252,-0.7139018448222032,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark54(3.9335619288425008,-0.09851555208022816,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark54(39.33580681220408,-0.8014619691007825,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark54(3.9341710375145382,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark54(3.9355750747636478,-0.2876101479678539,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark54(39.360589022571844,-0.8144858902668657,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark54(39.50896223841048,-0.34289023983673195,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark54(39.51557424917947,-1.4487882887268224,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark54(39.531810984355495,-0.8243887618152055,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark54(39.608536958901325,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark54(3.9612871614927774,-0.024246320045114848,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark54(39.67603520125016,-0.07035984443490795,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark54(39.69427127130836,-3.689679909977669E-8,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark54(39.80241918199382,-1.9243795038526826E-5,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark54(39.80832825913555,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark54(39.845935099470154,-1.433944709563221,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark54(3.9857853957090157,-0.5894643269364566,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark54(39.889429733041716,-0.5625761059835694,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark54(39.89024850769856,-1.2016612402303064,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark54(39.909128972361366,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark54(39.934606011034234,-0.5241897372631872,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark54(39.9457101518702,-1.4742925103096929,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark54(39.98973671316193,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark54(39.9989197783765,-0.103793705625715,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark54(40.022274333927214,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark54(40.063304941093435,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark54(40.091978471138184,-0.006816933345053675,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark54(40.115803461305205,-0.5032028057976303,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark54(40.11869429622166,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark54(40.1365042985698,-0.8087425511131414,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark54(40.18221185189091,-1.352661398577652,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark54(4.020525561316216,-0.38063838207932577,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark54(40.245200669473185,-4.376206417253923E-4,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark54(40.259362977469216,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark54(4.032367971243202,-0.33319562305416617,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark54(4.032962293712188,-1.493503256580537,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark54(4.033997561552273,-5.9531141565475204E-9,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark54(40.363330221092184,-0.9109478921280072,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark54(40.40281731412426,-0.5129978797514606,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark54(40.459959115800146,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark54(40.46606601869189,-0.9372532177035255,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark54(-40.502868211995384,-1.0795258896746542,0.943979368712686 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark54(40.5271995242735,-4.315367733924366E-4,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark54(4.053320912241773,-0.16714911626954176,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark54(40.550993672544195,-0.6634828174328256,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark54(40.60186764168549,-0.11091749603699164,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark54(4.060781056722392,-0.6994640183464611,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark54(40.63297326316996,-0.24830947591295316,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark54(40.68152742073097,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark54(40.70434518443396,-0.01780039492679486,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark54(40.74001171621914,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark54(40.781985349213926,-0.8412808981771767,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark54(40.81537307568584,-0.061176727215537796,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark54(40.81582426607591,-0.20484784950522794,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark54(40.82548660818847,-1.499999999999999,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark54(40.83096721988727,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark54(-4.091496177932566,-1.2206034612027314,-0.10153035945663202 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark54(4.0E-323,-0.4380106803824253,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark54(41.024412487112784,-0.7146868264689186,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark54(41.03686913933554,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark54(41.037488873400974,-5.260851389338064E-9,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark54(41.073637681939516,-1.4999999999999707,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark54(41.0817724972958,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark54(41.10034610888264,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark54(41.13503798003278,-1.20889486249947,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark54(41.14022677944479,-0.8301026641645954,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark54(41.1649447813882,-0.3080931874835642,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark54(41.20755572670646,-0.5648752169382107,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark54(41.21816615497323,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark54(41.23284460411729,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark54(41.277722407301226,-0.08944171054572836,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark54(41.29734427120414,-1.4999991547440266,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark54(41.31153925431025,-1.4999999999999503,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark54(41.314291129950675,-0.41341335492479203,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark54(41.33711760057665,-1.0952065410343463,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark54(41.39948494687598,-0.4929386582304791,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark54(41.45735754259178,-5.877864126064128E-9,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark54(41.486447847631894,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark54(41.5435415129496,-0.6528926082498145,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark54(41.54369611597429,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark54(41.57234227758221,-1.1004644782256885,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark54(41.579317179453135,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark54(41.587143149667824,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark54(41.62382116803148,-1.2089912286528488E-9,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark54(41.63144886339495,-0.20787539797639454,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark54(4.163836170150595,-0.12815429509173004,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark54(41.69247425655087,-1.4899445092623216,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark54(41.72177890453921,-0.8487824430958637,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark54(41.72467801461747,-0.8955184484223935,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark54(41.74311369242306,-1.1501143779970606,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark54(41.754654477581624,-0.22746337286374452,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark54(41.77453716181085,-0.7259704190154104,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark54(41.7947876475094,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark54(4.180061810758081,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark54(41.8154806623677,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark54(4.187582603618864,-0.0872583726744165,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark54(41.88243334695488,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark54(4.189234806216916,-1.3231136688813612,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark54(41.91528302142482,-0.09349712296021748,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark54(41.92774719422644,-0.7546161243436842,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark54(41.94939772971028,-3.9220764964560304E-5,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark54(41.96953669498126,-0.8375462784237153,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark54(41.99151077702808,-0.7424266313077226,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark54(4.201775849407824,-0.13736855795257163,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark54(4.202075034731893,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark54(42.023062106605124,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark54(42.02418042719842,-1.5138483431354736E-9,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark54(42.036480103700775,-1.4238091808714923,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark54(42.04478419001593,-1.7499529677577897E-5,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark54(42.10326415418456,-0.5455706442407475,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark54(42.11855220257178,-0.1844192808134295,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark54(42.13790655449825,-9.81795277703585E-10,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark54(42.13829019434612,-1.4999995104902821,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark54(42.154910762192046,-1.0952492251433776,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark54(42.17725668468873,-0.39820045015514527,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark54(42.200453757295165,-0.38544144908192557,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark54(42.20228052004887,-0.5735996565124424,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark54(42.24381383527141,-7.24970606414265E-10,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark54(42.24448894067979,-0.20549550921384707,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark54(42.26043216652064,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark54(42.27047875991772,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark54(42.324282375484216,-2.844027121510764E-8,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark54(42.339819698472866,-1.4957234106469013,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark54(42.375246828108345,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark54(42.39425028065281,-1.2054775011905812,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark54(42.39967580988888,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark54(4.241042869108264,-1.4999999983721835,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark54(42.42007169382741,-0.8668347347036656,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark54(4.247162208087403,-0.17558446970089348,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark54(4.2480106677714105,-0.46925338060259303,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark54(42.516684126234985,-0.7245457155376105,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark54(42.55697273823269,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark54(4.261563788968886,-1.4999997312696234,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark54(42.64654449093081,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark54(42.66065850484904,-1.432145962367855,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark54(42.670885915993814,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark54(42.72868107667668,-0.008231024683635013,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark54(42.75017695103316,-0.31659900812290687,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark54(42.751826231925975,-0.06976828483018949,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark54(42.75421143128176,-0.7716517942102485,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark54(42.772020785287424,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark54(42.78051069724253,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark54(42.780572563098886,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark54(42.79127036456049,-1.302098414354266,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark54(42.79585188340144,-0.22617845013553506,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark54(42.81110324044286,-0.44698096245367935,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark54(42.84920987716393,-1.1705736672413773,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark54(42.92092752662384,-1.3316272875401198,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark54(42.920972597305706,-0.8159179443603444,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark54(42.92937634465926,-1.2236418929759827,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark54(42.93830311031678,-1.3389793381300894,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark54(42.96321762375047,-1.3005590382045928,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark54(42.97008056798947,-0.4072551474354835,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark54(4.300425765165656,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark54(43.01168596039136,-0.37982501866927665,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark54(-43.02422443225747,-1.2620143854944361,-0.9609400954779028 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark54(43.031234833838,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark54(43.08293157632224,-1.0052696334516348E-8,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark54(43.096990396899486,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark54(43.10558828165975,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark54(43.12806501675944,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark54(43.14740762236711,-7.06934595851939E-9,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark54(43.15455058597379,-4.266955662500153E-6,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark54(4.317291815898258,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark54(43.188101869429055,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark54(-4.3191245033853636E-17,-1.2757344824602541,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark54(43.20974281550289,-0.47317902849749627,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark54(43.2885816738252,-9.653703901324036E-7,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark54(43.29685211288597,-1.086026632391257,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark54(43.33749959991529,-1.3238265792014956,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark54(43.36257393411387,-0.02605018218990729,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark54(4.3368086899420177E-19,-0.27756986044147836,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark54(43.39022858292992,-0.12837809788082338,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark54(43.45092007990677,-0.7581459302128678,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark54(43.463675590360644,-1.6022372544543397E-15,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark54(4.347090548892256,-1.4999999997292806,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark54(43.50653650720599,-4.548016297737724E-8,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark54(43.50730183731662,-0.8051280869922302,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark54(43.50760405622765,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark54(43.5483330827401,-0.9896016943712502,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark54(43.56002446265478,-0.7363302061226391,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark54(43.563740077200976,-1.0055954680838681,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark54(43.57134427190616,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark54(4.357344199402656,-0.18065918254624003,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark54(43.596014346167436,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark54(43.61652263177058,-0.4750641356090066,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark54(43.66039924323303,-1.36634321050317,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark54(43.676134321562316,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark54(43.68163614458635,-1.2172880639141177,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark54(43.73392533359191,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark54(43.736309964697796,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark54(43.74650549926113,-0.5929738012373416,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark54(43.79133726102563,-0.4435999110138358,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark54(43.8242302949856,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark54(43.845277548635096,-0.28439490806717926,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark54(43.8991860527633,-1.2626931476787178,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark54(4.395724125896747,-1.3642128750359603,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark54(43.95742675579393,-1.4064002867585828,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark54(43.965370351923696,-0.7017843788835734,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark54(44.00207118661315,-0.0011475706315246367,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark54(44.02756011610981,-0.7923272556117951,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark54(44.10683020140439,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark54(-44.108438005633865,-0.13477209705957804,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark54(44.11849421514292,-0.40703584127845815,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark54(44.12288092795328,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark54(-44.13046208106854,-1.4406431485026276,-31.930389907335467 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark54(44.13060219841597,-0.551284411140391,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark54(44.13977300032502,-0.16283737096659934,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark54(44.20288968325311,-3.4740181659448846E-8,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark54(44.20858439121068,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark54(44.2440016058969,-0.8437907579160577,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark54(44.26072308613968,-0.9169386668073578,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark54(-44.27393135709802,-0.18877730188382125,1.0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark54(44.309554618975056,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark54(-44.31638167937516,-7.301735280246691E-8,-90.10981587490973 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark54(44.31923509118464,-0.17660581440420975,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark54(44.34046633175101,-0.06202728742285046,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark54(44.36106945368155,-1.0778636253741878,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark54(44.39993915769807,-1.4999999995246658,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark54(44.402895842665544,-0.930076734666172,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark54(4.440892098500626E-16,-0.8503601698430807,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark54(4.440892098500626E-16,-1.0445982247498855,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark54(4.440892098500626E-16,-1.4999999999999996,-0.4727364595724737 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark54(4.440892098500626E-16,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark54(44.46473789348906,-1.390335379713965,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark54(44.464777477320325,-0.3732136776668966,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark54(44.489316787917396,-0.5875127467784853,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark54(44.53281043911343,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark54(44.537815519650394,-1.4332831223823765,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark54(44.54118543902953,-1.19632547105937,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark54(44.56589479170748,-0.335152188535889,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark54(4.458636826651599,-1.2323173967858294,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark54(44.610016443821145,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark54(44.62024563450036,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark54(44.6226166171279,-0.053933181890556625,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark54(44.64095600715916,-0.2715451031405305,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark54(44.65846692263912,-0.4479427800103907,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark54(-44.66481092264265,-1.4016342372645336,1.0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark54(44.68141157966946,-1.2379835282566205,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark54(44.72814344412484,-0.7339040826064434,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark54(-44.7396309680149,-1.1215625608351019,-0.98743101502205 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark54(44.75145443239384,-1.2595207447945844,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark54(44.80912144469926,-0.13269027585255222,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark54(44.81310805414239,-1.4456154815525792,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark54(44.84928141560465,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark54(44.87505474863941,-1.4257080555321797,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark54(44.882848198241845,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark54(4.48866716745313,-1.2702130191467766,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark54(4.488857639824275,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark54(44.976708116547975,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark54(44.98643006682896,-0.37380117578356115,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark54(44.99533787398771,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark54(45.000941833899475,-1.3886209606322524,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark54(45.00419312705197,-1.4999999990724564,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark54(45.02723694003092,-0.6847492946172622,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark54(45.08372715605422,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark54(45.12482179939107,-0.5938103556619971,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark54(45.14814905912515,-3.1580890953350983E-9,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark54(4.515026200142586,-1.3768694354532727,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark54(45.15176504729172,-0.2521620780090448,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark54(4.515515380864926,-0.931099571753478,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark54(45.20540728680888,-0.9395726600467569,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark54(-4.526703788843427,-1.3150392028992712,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark54(45.322391008024084,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark54(45.34564580748716,-0.44587560347423355,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark54(45.37217032462761,-0.5049590022955829,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark54(45.37498556486292,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark54(45.39158680412544,-0.02106634821951614,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark54(45.42496286679716,-2.4732598784461678E-9,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark54(45.449546433618394,-0.06768699236001186,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark54(45.46555442040096,-0.347778843632106,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark54(45.5024033238979,-1.4936241803525314,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark54(45.56433949864518,-0.6854096648009245,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark54(45.58263943239565,-1.0503481772116998,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark54(45.60495049588559,-0.9327352259848064,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark54(45.61002862191549,-0.644101426267568,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark54(-4.564364500879956,-0.8212604400816947,90.0814882075491 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark54(45.64732275105793,-0.3076082540941229,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark54(45.65952315341181,-0.7998402369644178,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark54(45.695584593950656,-0.4467793816509987,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark54(45.722151985811536,-0.23306729458451514,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark54(45.766601334830966,-7.756056600866841E-10,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark54(45.77679631317188,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark54(45.788117579785336,-0.23731813605598528,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark54(4.580166314242831,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark54(45.80891699048442,-1.006001476566392,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark54(45.88407113600334,-0.9298399722895851,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark54(-45.88549654621765,-57.97912479975016,-96.45615058698019 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark54(45.9037885728541,-0.018279666082557877,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark54(45.96881456301372,-1.0976623799833691,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark54(-4.598211598951265,-1.4999999999999998,1.0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark54(45.9932392804005,-1.1610271860577939,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark54(46.00109881219283,-1.230153121530435,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark54(46.05145674263693,-1.084022995451794,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark54(46.06775479585866,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark54(46.06992629256639,-1.3103938583841677,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark54(46.07438488835305,-0.6473576768755214,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark54(46.08426989722554,-0.5917843573492944,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark54(46.087776491227785,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark54(46.10359744908422,-0.6372320036550487,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark54(46.13384528331625,-2.2246610580474315E-8,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark54(46.165201981737226,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark54(46.172723965301856,-0.49938676935034293,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark54(46.22562790279528,-0.7979809211775399,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark54(46.29292057487359,-1.2673988834785286,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark54(4.631346176661146,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark54(-46.314954799008476,-4.809888351922094E-10,-1.0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark54(46.3251440632165,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark54(46.3268731146775,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark54(46.37093027955822,-0.6553043901148357,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark54(46.41889216704794,-1.1677108441674993,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark54(46.425789797880554,-0.18515826497888632,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark54(46.42666791750469,-0.35366040471389226,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark54(-46.427387331646564,-1.4999999999999998,2361.7607033312042 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark54(46.51705542690934,-0.4816694735498803,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark54(-46.60264998187574,-0.6496056876167224,1.0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark54(46.6158050991223,-0.47983368792784353,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark54(46.666203476771535,-0.5982701865792439,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark54(46.67145020239718,-1.0241554257324594,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark54(46.68398554725968,-1.4681722474089787,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark54(46.71624302116598,-0.7794903646626837,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark54(46.73346109358326,-0.3388002382349971,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark54(46.771679347188034,-1.61538245149118E-6,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark54(46.803630111164495,-1.4554091932150897,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark54(46.82147027147673,-0.3748187924327036,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark54(46.82625922463632,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark54(46.86323789468713,-1.038411849580811,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark54(46.890772716448694,-0.6961851301564508,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark54(46.92154570214714,-0.05305652832554131,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark54(46.9257520435246,-0.09070805645820901,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark54(46.950362422399564,-0.28925962891070567,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark54(46.96545904128656,-4.015617791097787E-5,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark54(46.98561986634274,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark54(4.700604162676431,-3.521653531584656E-4,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark54(47.01253322248334,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark54(47.028522344997384,-1.2590305197792993,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark54(47.03742976845817,-1.022927792147982,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark54(47.05187999572439,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark54(47.055886378005596,-0.3408329858098509,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark54(47.099841314391085,-0.08576525920552736,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark54(47.10216955494181,-0.8311895115208472,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark54(47.12646105608525,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark54(47.163528160620665,-1.479124549708956,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark54(47.198235893887215,-0.5483460299021656,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark54(47.23687663012547,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark54(47.28056462237974,-0.8264033430600333,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark54(47.294449243019386,-0.938960365236858,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark54(47.30082739003515,-1.4330566211380358,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark54(47.302722926288844,-8.16990433789138E-10,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark54(4.7331693402347526,-0.9807498320570771,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark54(47.33401613546536,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark54(47.369724499094104,-8.279973413507664E-5,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark54(47.37494211153381,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark54(47.47532841261818,-0.9919485802710142,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark54(47.475419940822825,-0.8613074937081386,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark54(47.48908819080066,-1.4990551672651808,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark54(4.751503402117435,-0.8127336492568767,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark54(47.54442852908224,-0.9432460962584415,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark54(47.55715551167813,-0.786092064132049,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark54(-47.56199759436869,-0.6803012999347898,2.1612908839133068E-224 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark54(47.56813241143834,-0.8849378085887345,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark54(47.62455752034846,-0.08057945147648504,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark54(47.66303839249099,-0.20849688005002065,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark54(47.69246546213182,-0.5734620431822623,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark54(47.69632824290136,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark54(47.69809112564133,-0.5385252224176824,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark54(47.71131967636023,-1.0249432810835613,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark54(47.71310049501065,-1.465819654015803,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark54(47.714306034586514,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark54(47.74827676126725,-0.9881847946958828,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark54(47.774059326428386,-1.1049808031578436,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark54(47.803610299340846,-1.0130038997605917,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark54(47.81070971261852,-0.03120469767519296,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark54(47.81645081186394,-0.05615290095603037,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark54(47.82103050828198,-1.1125050455054368,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark54(4.786075403826942,-1.499999999999968,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark54(47.89410967278664,-1.3438578360524849,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark54(47.89702887793044,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark54(47.92360597592909,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark54(47.938491874462244,-0.7281208512795985,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark54(47.942753338587735,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark54(4.796364687310994,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark54(47.971872820783325,-2.0597756954938606E-5,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark54(47.98805996869388,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark54(48.02979376176738,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark54(48.037628450616836,-0.3120716305557649,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark54(48.061846814657116,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark54(48.0925681276876,-1.3360285569619919,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark54(48.09602743247089,-1.2519526748850747,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark54(48.12291572881045,-0.8995433760075751,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark54(48.140266482535054,-0.18441332007729727,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark54(48.16762499736278,-1.8677684991199725E-9,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark54(48.251415952121775,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark54(48.25649581621707,-1.4627293523904026,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark54(48.28356448542311,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark54(48.338475438306915,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark54(4.836024391640166,-0.28895533683852115,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark54(4.837954378797003,-0.8424676737537109,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark54(-48.38198864128594,-0.30311772482420946,1.0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark54(48.39350505503495,-1.4999968645799588,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark54(48.42928959185895,-0.17444023467313208,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark54(48.43929750723598,-0.6819934551453666,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark54(-48.4776257872347,-1.4999995165107,20.304632945511973 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark54(48.52349985134978,-1.1877021320411956,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark54(48.53362413949673,-0.679856264611614,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark54(48.578878445726495,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark54(48.58043516183668,-0.389874607720456,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark54(48.59092194625907,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark54(48.65951425417981,-48.52001129011967,5.7686787578155645 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark54(48.66767834706698,-0.17966241770064972,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark54(48.68616801022873,-0.9689048050089326,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark54(48.69794837541636,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark54(48.698560932549555,-0.14702397917443477,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark54(48.69996248094196,-1.2601174842105962,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark54(48.73763790367271,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark54(48.739987761729736,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark54(48.7431330440088,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark54(4.876576350566069,-0.9432931340016211,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark54(48.7697908862458,-0.6122750834298936,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark54(48.77116109726808,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark54(48.776718875927884,-0.5361417842978842,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark54(48.80060844097579,-1.0369750893890393,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark54(48.834949213070956,-1.1250303833907118,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark54(48.840359738459185,-6.256025671650574E-10,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark54(48.844044177146195,-0.47746934283254117,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark54(48.93859416431633,-0.04051661688093944,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark54(48.984971941173825,-1.0345853640533829,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark54(48.98712149905583,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark54(49.001897181850495,-0.8638793373468019,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark54(49.00830879845978,-0.9890578039811428,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark54(49.03331365626545,-0.19815192110869084,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark54(49.04314316915479,-0.8284673720114655,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark54(49.04835183339688,-1.2977639758595758,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark54(49.05208184935384,-0.6918075973246545,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark54(49.06615171060042,-1.233568207159987,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark54(4.907709818533431,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark54(4.908403318308608,-0.13822687369457282,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark54(49.08680542307336,-0.535177990097404,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark54(49.12446178353241,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark54(49.159000742153125,-0.036655147849861125,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark54(49.16571356095338,-0.08452842773286764,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark54(49.17405670975654,-0.5724820228271073,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark54(49.17550206995104,-0.7271411029859759,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark54(49.185096709973806,-1.4461753701828854,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark54(49.41390736132408,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark54(49.416197613467475,-0.322059337168211,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark54(49.41627262322473,-0.4078450891815878,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark54(49.424299430861794,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark54(49.46474516558371,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark54(49.491838153619426,-0.09660132671427046,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark54(-49.50276819131911,-0.8334248985945717,1.0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark54(49.5390504405467,-1.2525653909947887,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark54(49.553578140192215,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark54(49.608229047680354,-2.034307364959762E-6,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark54(49.629932044007376,-1.229180665001338,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark54(49.633747038003975,-1.2196404973639474,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark54(49.64450159421395,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark54(49.64938870273474,-0.07653621076310912,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark54(49.687367438442664,-0.3645044864162479,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark54(49.69726744086368,-0.13158455483803674,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark54(49.71389291543568,-0.052936582503572804,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark54(4.974172422502958,-0.6988223265089051,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark54(49.7617290062139,-0.4736331007776329,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark54(49.79687467289261,-1.0723959423782645,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark54(49.82942163103051,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark54(49.88291659098101,-1.3602637399048092,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark54(49.887299067048374,-2.593954284931853E-9,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark54(4.990650855190168,-1.1555160855958058,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark54(49.92254555913306,-1.411547377713127,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark54(49.95243997862187,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark54(49.99243789130908,-0.1762036972822627,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark54(50.018798866269464,-1.205414273798496,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark54(50.04880227067852,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark54(50.05867914721726,-1.4999999993499444,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark54(50.063857658035566,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark54(5.006429626647829,-1.1788497856516322,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark54(50.074839403661244,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark54(50.07776261513706,-1.0452374026878752,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark54(50.12720646499213,-0.42050560234664136,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark54(50.159026787449854,-1.1166920554142553E-9,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark54(50.1602256654439,-0.47636568658704836,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark54(50.16949826845678,-1.0622320044065745,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark54(50.20551247027012,-8.740600269890683E-8,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark54(50.240053509658196,-0.8498753100652067,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark54(50.24407047844923,-0.9736824765573431,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark54(50.29229002350249,-0.8640266483333363,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark54(5.029986208069673,-0.3632101017041793,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark54(50.300613147244164,-0.06686286626616678,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark54(50.32723591550848,-0.9641445039122658,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark54(50.3772092424529,-2.2731689643058068E-8,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark54(50.39374755103972,-0.0032702142210965235,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark54(50.40858754460669,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark54(50.41722804241141,-0.0498783179375728,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark54(50.45568485112896,-0.14019651785769027,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark54(50.457103949551794,-1.1222617607379903,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark54(50.4953818787578,-1.4999999999991882,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark54(50.51778095025755,-0.21964540534721966,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark54(50.52216446019057,-0.26464692311957894,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark54(50.529123055390386,-1.3952006707819118,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark54(50.545933702200074,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark54(50.54900122614318,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark54(5.054956624750062,-0.35031480174714,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark54(50.58451224308958,-0.5609920059553699,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark54(5.058460812450395,-1.21910448916762,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark54(50.59370786923202,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark54(50.61289938813897,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark54(50.635801056420206,-0.055253661032394485,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark54(50.67198935878028,-1.1312582784871248,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark54(50.697332084618246,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark54(50.73981261570128,-0.6150547152660506,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark54(5.075933024525906,-0.9398297862554297,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark54(5.076528463630254,-1.3158362123928553,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark54(5.078638269656356,-0.13152124977933677,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark54(5.085968653003633,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark54(50.887729731208495,-0.5733126539391318,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark54(50.893317934473885,-0.5383767838617171,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark54(50.956090638851975,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark54(50.98252680630086,-0.4756212060416116,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark54(50.99234386124837,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark54(5.101611797328176,-0.35918624171210234,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark54(51.05814053646456,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark54(-51.07959725705857,-1.0953630126822809,-15.355242337168406 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark54(51.08093490084747,-1.018463160128519,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark54(51.08098953403095,-1.1069295453139376,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark54(51.133321080397366,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark54(51.1936656582925,-1.4874664087797758,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark54(51.20701704289762,-0.2282375749031882,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark54(51.21915815224392,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark54(51.22541951425876,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark54(51.23171398111819,-1.4604728183748872,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark54(51.28320439493476,-0.8898119705519516,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark54(51.31241304988012,-1.3517579372760968,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark54(51.358882902313695,-3.240329733236475E-16,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark54(51.38107660925681,-0.5699094602274926,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark54(51.410338290932145,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark54(5.1412904687300385,-1.4999999994442272,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark54(51.42493233655475,-0.8892654430839553,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark54(51.493584977672725,-0.8466111792955537,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark54(51.55817710923144,-1.2707344330325058E-8,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark54(51.603967976339305,-1.216986027698049,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark54(51.61026454054345,-0.41526112354317046,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark54(51.61167969461849,-0.4357547042625072,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark54(51.61653723557073,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark54(51.62095585957496,-1.0278809050518176,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark54(51.624580512705776,-0.692171503384539,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark54(51.6444372471671,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark54(51.66911851255384,-0.2188612320661465,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark54(51.67985127660431,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark54(5.169207559095717,-4.5004625754490793E-4,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark54(51.699610977275555,-1.4438227504171859,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark54(51.7281564589447,-0.3941584154628198,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark54(51.7287514886778,-0.09710548813798558,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark54(5.175312203954236,-0.014802007586323447,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark54(51.761910931843204,-2.8348891455797203E-4,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark54(51.779536350600736,-0.11180159862887917,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark54(51.78228245401598,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark54(51.784424779805704,-0.6877765344164356,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark54(51.78606067322738,-0.39112956266498067,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark54(51.80392395905861,-1.2734757202432547,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark54(51.80980378529844,-0.26759969737035494,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark54(5.181641261163151,-1.1498669779381274,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark54(51.870464562473586,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark54(5.190250733551231,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark54(5.195195958892313,-8.970165345874218E-10,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark54(51.99581217786903,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark54(51.99659371770126,-8.716904658534696E-6,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark54(52.08248391333639,-7.188673112592083E-5,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark54(52.109917673366084,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark54(52.117044049618386,-0.13000992543870593,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark54(52.123582721148864,-1.1708968846623868,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark54(52.152187552270064,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark54(52.15881989042754,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark54(52.16103719968709,-1.392565431832483,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark54(5.217145308792782,-4.288949301172096E-9,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark54(52.206546046851685,-0.1582642843623887,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark54(52.21852084525659,-0.8615382006822383,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark54(52.23107231486597,-1.4036930475261986,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark54(5.223656392791273,-1.3825527266265376,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark54(52.2704045724902,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark54(52.28950260934229,-0.6029684787629961,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark54(52.36200724565296,-0.11452146654811823,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark54(52.411501712733156,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark54(52.45377546035007,-0.814666458503071,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark54(52.46141546932404,-1.2803749147907695,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark54(52.48412408862158,-1.3143359589325346E-6,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark54(52.50840936327339,-0.25482618754082864,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark54(52.517726792387016,-0.9177841148135828,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark54(52.5352496654028,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark54(52.53687292100007,-0.07578432945830245,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark54(52.556744840475886,-0.2881593324803813,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark54(52.57241890013313,-0.9251996609251449,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark54(52.59040902157399,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark54(52.6077385082381,-0.7293695637418758,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark54(52.622123373711666,-8.021401471397755E-4,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark54(5.26273985939476,-0.03244242221766758,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark54(52.63748768297333,-0.9282407037036355,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark54(52.66265224840089,-0.21421514576668088,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark54(52.70280579332692,-0.9381392944895595,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark54(5.27241752925584,-5.73410222861633E-9,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark54(52.75793585943859,-0.7364097939403464,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark54(52.77664657564233,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark54(52.78412326526623,-0.5502989269976499,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark54(52.78854439379433,-0.6670829995598317,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark54(52.79257624992971,-0.1207426187091829,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark54(52.81524086423252,-0.18750558744978818,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark54(52.821142149538304,-1.4518280643900967,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark54(52.85091678077856,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark54(5.2888630040595075,-1.0459288753273046,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark54(52.93072495416174,-0.7067207151853259,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark54(52.94653034987935,-0.973540621642667,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark54(5.294944450109529,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark54(53.03949187400022,-1.0295378784285845,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark54(53.046257067519605,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark54(53.06293912205956,-0.1626459782261384,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark54(53.11218689065317,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark54(53.126827377766034,-0.3350872078605107,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark54(53.147307885820794,-0.5250098775114633,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark54(53.148613757748215,-0.9427597671689916,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark54(53.15256473536435,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark54(53.17285447087369,-0.0019370428592321628,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark54(53.20138940393056,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark54(53.22814190236011,-1.388863610886848,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark54(53.272378541208354,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark54(53.32136434241459,-5.343868076288333E-10,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark54(53.36162942121873,-1.107095632917007,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark54(53.366525101755,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark54(53.37870432443714,-0.20055279078434518,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark54(53.42108019793346,-0.46091389401012745,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark54(53.42972706867054,-1.27874894164797,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark54(53.44100370721405,-0.33827553749366857,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark54(5.344601608724826,-0.40213707633151763,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark54(53.44811809099892,-0.9071131120764839,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark54(53.48095607411358,-0.5561155857296023,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark54(53.502305484010776,-1.4999999976867886,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark54(53.50884751744849,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark54(53.522128199674235,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark54(53.55908802778703,-0.23368999912834454,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark54(53.57746975291636,-0.8834009951986133,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark54(53.603723367691344,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark54(53.61016625479846,-0.9195868982807127,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark54(53.62219495865128,-0.4436103504539268,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark54(-53.65427485834773,-1.3005427564455252,-1.0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark54(53.660758317293244,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark54(53.66480427550425,-0.5066483501744985,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark54(53.673336983219954,-0.31571340405673576,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark54(53.74406201873322,-0.5732379846005102,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark54(53.76243166538515,-0.9498310252199618,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark54(5.379759385739405,-1.4999999999998703,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark54(5.380225203388318,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark54(53.814441762214905,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark54(53.85534289958463,-1.4658857389064504,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark54(5.388511580253834,-1.3568617994842462,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark54(53.989296338329524,-1.3416579237695263,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark54(5.401548279613394,-1.1801757854600328,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark54(54.03850015234265,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark54(54.07607132580759,-0.18969337848907797,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark54(54.08856789304437,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark54(54.10599479628695,-0.8617836824766414,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark54(54.13551223519363,-0.7214258329767315,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark54(54.14439113754429,-0.7855140607969542,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark54(5.415167083955154,-0.22002706730919863,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark54(5.415889761396286,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark54(54.179334992898326,-0.7960384918152048,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark54(54.19717291951605,-0.5311254631688078,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark54(54.25480284026696,-0.5965275067684894,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark54(54.25543016377347,-0.004776811792122082,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark54(54.298678976047334,-0.5418509090692392,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark54(54.32404024538292,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark54(-54.342844839297,-0.5677554765687802,0.989393519397489 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark54(54.40082582352218,-0.8922515797563353,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark54(54.43647907238892,-0.799005386991126,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark54(54.43942917404644,-0.16608442774190735,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark54(54.45223902372891,-1.2560289629340016,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark54(54.492199766458214,-0.2778783350260792,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark54(54.56562834155204,-1.4975754300666992,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark54(54.58304969837752,-1.275525720885364,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark54(54.61124074239818,-0.40294018988790237,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark54(5.461974601025759,-1.2824833373457167,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark54(54.656571315483376,-0.616631700474084,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark54(54.65662207033273,-0.25674590453934887,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark54(54.682413468578744,-0.03702233596923976,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark54(54.68534860143998,-0.09334164084484797,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark54(54.69357113193297,-0.8006510639095374,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark54(54.72591508909656,-1.1167303330901603,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark54(54.742875974137576,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark54(54.768704776569855,-1.4179742125332215,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark54(54.790215942597335,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark54(5.479714620919481,-0.9746747692898603,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark54(54.84216677045542,-0.5697217353928015,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark54(54.89419393935583,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark54(54.92410110684347,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark54(54.9303421747027,-1.3482441247482626,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark54(54.93064846064486,-1.3800771200480488,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark54(54.932235497367515,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark54(55.00197748469918,-0.6200381835813586,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark54(55.02022088993959,-1.054181600979393,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark54(55.0498385583777,-1.3062918414165665,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark54(55.06719488132437,-0.1704833690513805,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark54(5.514131610598082,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark54(55.168630611276285,-0.1166140312394548,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark54(55.18492316571667,-0.8779259960202777,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark54(55.190201225347984,-0.5751387712199669,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark54(55.20698593632753,-0.6065376336000359,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark54(55.22190005299868,-0.5222299035462079,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark54(5.52265638572189,-0.8759718583172713,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark54(5.524740738907667,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark54(5.525762220722214,-0.8428272203944402,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark54(55.25874232277707,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark54(55.28620761584181,-0.9099659125853271,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark54(55.31964547915629,-1.493340681341974,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark54(55.32800198243308,-1.1916411423076685,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark54(55.33094566125777,-0.9609153820228951,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark54(55.34213292057416,-1.0215934358588892,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark54(55.344269145566045,-3.4052990221302223E-4,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark54(55.351999215643765,-1.0597836568753323,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark54(55.38176434687593,-0.012592915229415677,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark54(55.39544760418465,-0.2835799985229599,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark54(55.398581456427756,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark54(-5.5399211230601395,-1.4999999999999982,61.20852273465752 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark54(55.40178106069624,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark54(55.42238273310801,-0.8927644267380721,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark54(55.45350683403453,-0.9333465200057507,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark54(-55.47224279472661,-1.4999999999999947,-23.100121536037335 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark54(55.49743778463318,-0.9138888618136463,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark54(55.49993720424965,-1.4371202896699282,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark54(55.54406192035912,-0.13838460867111524,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark54(55.57809076638267,-1.086507750141763,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark54(55.63291481908271,-1.326085284660562,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark54(55.66492084174746,-1.499999999999826,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark54(55.667372012781414,-0.3895776232781749,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark54(55.685869002145125,-0.7905149611768962,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark54(55.70764428018248,-0.7118967523892152,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark54(55.709190562318526,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark54(55.73598281373217,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark54(55.74338575949679,-1.4404507665100965,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark54(55.75274296055764,-0.19881877176320017,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark54(55.75997153064486,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark54(55.76702343277715,-0.016930304236729254,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark54(55.7920178289948,-1.0207573749023453,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark54(55.8316607789247,-1.4509912169838528,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark54(55.845559758818354,-0.4622956142327723,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark54(55.91826018994513,-0.24253591914987163,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark54(55.941324999227476,-1.3587264095572777,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark54(55.95895664123646,-3.2639815851272316E-9,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark54(55.98364213852537,-1.2804046327693541,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark54(56.00476275005325,-2.937029860894151E-8,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark54(56.03192591409639,-0.22088423152101105,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark54(56.048415457854276,-0.2546816428153278,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark54(56.073689801386735,-0.5883331349175116,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark54(56.094210777368176,-1.308188921861643,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark54(56.107092399341326,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark54(56.132134214639805,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark54(56.14022381972475,-1.306220608630909,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark54(56.160902198307525,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark54(56.20654361202503,-0.24532116738500065,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark54(56.209304279299346,-1.2547870889132202,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark54(56.26171764033613,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark54(56.29605486238654,-0.0886085522945499,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark54(56.298195908626795,-0.055000483595248784,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark54(56.34517543728884,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark54(5.63528361746302,-1.3748149095412354,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark54(56.35546871719947,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark54(5.638217917160503,-0.01874337096055001,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark54(56.3930735336271,-1.381499166838351,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark54(5.6417573912819705,-0.4412609848282605,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark54(56.42901549036495,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark54(56.48075268671057,-0.031021536400020377,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark54(56.54104858913976,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark54(56.543141922972175,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark54(56.55820322214928,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark54(56.57403671558606,-1.0543179558147129,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark54(56.63598319585471,-5.461484872567669E-7,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark54(56.68904585376262,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark54(56.7065871850636,-0.7858968513971121,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark54(56.71256530028651,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark54(56.77384720943624,-1.4107857997688757,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark54(56.78252099970632,-1.2765741570135702,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark54(56.791977093693035,-1.4278138054209952,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark54(56.8015401375013,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark54(56.83582242649233,-0.6309928316958959,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark54(56.8368057326725,-1.356877139716815,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark54(56.844876904234354,-0.38519036372902127,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark54(56.84600649742206,-1.3915451328477693,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark54(56.871415110020706,-1.2258256861647139,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark54(56.8728714706437,-1.1002175568823507,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark54(56.8776025176146,-0.07053042481179159,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark54(56.88889318457095,-0.15897997191301805,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark54(56.958904603455494,-0.06510600731332272,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark54(56.97766729204827,-0.6033667057798535,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark54(57.00150975324837,-1.2825432065191507,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark54(57.054853493875896,-0.7121990341368445,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark54(57.11401840280031,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark54(57.116984361403354,-0.3547686780770647,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark54(57.18441379726603,-0.1946437891967036,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark54(5.723607654289788E-16,-0.0054248944337259575,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark54(57.25218063603717,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark54(57.256062695490385,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark54(57.36600129015943,-1.253689637719885,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark54(57.39553453431574,-1.4515793814268532,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark54(57.425059229780175,-0.09278490559983599,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark54(5.743347088649983,-0.899674548607452,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark54(57.45495175914435,-6.514204783949906E-10,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark54(-57.48982689824348,-0.9337589553953116,0.017274025245279545 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark54(57.51260224176343,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark54(57.53001629526573,-1.4888544048826056,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark54(57.569423015617936,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark54(57.576450581172,-0.7500400669503904,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark54(57.58214233787019,-0.24257386486745441,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark54(57.58915965335362,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark54(-57.594837285707115,-1.1781199608723392,-75.9675540889271 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark54(57.597057149517205,-1.031881282230687,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark54(-57.598826484731575,-1.3688884926017135,0.8958396924869916 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark54(57.65861495112759,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark54(57.68431726943606,-0.07106359223978873,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark54(57.70643713258576,-0.9091652229663865,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark54(57.72246785753097,-1.4816555431147265,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark54(57.74725440319949,-0.7792855037104971,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark54(57.75161333394447,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark54(5.778387610720742,-0.7774710515329257,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark54(57.83271593582674,-1.1134145579804828,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark54(-57.83289856298589,-4.865811380873997E-10,1.0538697245341844 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark54(-57.86754236132229,-2.7755575615628914E-17,0.0626269680527834 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark54(57.90960284479405,-0.4084280899281847,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark54(5.792575526717112,-1.4896909886359517,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark54(57.940749703533285,-1.283667096467174,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark54(57.948143313715036,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark54(57.95661495176057,-0.5576903985164137,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark54(58.02279450011383,-0.36964331354002944,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark54(58.026262170785486,-1.062550952887897,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark54(58.057274939910144,-0.7921855423888502,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark54(58.09605755626144,-5.815308840948455E-6,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark54(58.110447831082716,-0.626762069743591,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark54(58.1383703011739,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark54(58.25012002255835,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark54(58.26215090813923,-0.4219342278066023,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark54(58.26848233223123,-0.22306745342405065,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark54(58.304061417141185,-0.04118133585286898,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark54(58.33261719658249,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark54(58.33801268525556,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark54(58.350679023348796,-0.13442970269785448,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark54(58.356637032576835,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark54(58.36046755157603,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark54(58.39785506331691,-7.487126860569733E-6,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark54(58.40241853833752,-0.37570502906144393,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark54(58.49616213212539,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark54(-58.498924355377895,-0.11484934479762465,-1.0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark54(58.52175710644207,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark54(58.53140690027354,-0.7030743399196808,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark54(58.6031567022913,-0.8373455713239508,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark54(58.612465149899265,-2.926301977954945E-9,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark54(58.61644226282394,-0.8933784464381915,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark54(58.63038930211415,-0.441374298395631,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark54(58.66184765162498,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark54(58.69928071416851,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark54(58.7079788588932,-1.0552607788796138,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark54(58.72106673086831,-1.4567921677476512,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark54(58.72293577838724,-1.4999999999997726,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark54(58.730248069957,-0.2405538752633254,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark54(58.75295181787172,-4.708726299678764E-9,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark54(58.79403808841256,-0.6259576360254906,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark54(58.82311655749114,-0.7722762587656181,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark54(58.86598206544208,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark54(58.91271925027249,-1.0309167592051267,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark54(58.944894627912014,-0.0034904344918263996,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark54(5.89589330618345E-5,-0.3033816145061072,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark54(5.8989703818324415,-1.3241123585168504,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark54(58.99334103932834,-0.21633505636457695,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark54(59.015077111427416,-0.3934295898980764,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark54(59.02014112853819,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark54(59.06190404447217,-0.2689696014986459,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark54(59.08170431497018,-0.03788338085867782,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark54(59.0838539044469,-0.15585617296814291,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark54(59.08529499846372,-1.4393393948285365,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark54(59.08767684923683,-0.006112202722352494,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark54(59.10878808949988,-3.005968757333437E-4,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark54(59.123514875150434,-0.7935552096225512,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark54(59.12893693581452,-0.8302225585661347,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark54(59.143665710379345,-2.3253162065195295E-7,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark54(-59.190652116975116,-0.7825354932721922,-0.4445554127442808 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark54(59.22771832127701,-0.9352757658337438,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark54(59.27623955564482,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark54(59.294796707652814,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark54(-59.29580482998475,37.749478180279596,82.6570125148009 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark54(59.33295123131796,-0.9641771572685087,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark54(59.34575008488889,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark54(59.38821052219636,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark54(59.400670331610826,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark54(59.41111485879608,-1.2297821396083464,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark54(59.43776839881977,-0.45430202761155236,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark54(59.450002202346695,-1.4730712231174894,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark54(59.47075392485746,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark54(5.94924469698519,-0.5650166602423559,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark54(59.492824906821255,-0.24285751160478597,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark54(59.5147713421102,-3.900016050801618E-6,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark54(59.52872258613027,-0.335702898370532,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark54(5.954106440128726,-0.9618724521942326,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark54(59.5436410091487,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark54(59.556660532832026,-1.158328671229417,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark54(59.57704067249952,-1.0294073676763182,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark54(59.58860295361116,-6.826732608480528E-7,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark54(59.63493342674662,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark54(59.65752071437933,-1.4999999999999853,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark54(59.66011172399312,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark54(59.66989655342104,-0.7826871694713002,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark54(59.67536913578823,-1.2559464801924305,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark54(59.68006301708114,-1.4999999999590938,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark54(59.68982589607765,-0.31215809588325116,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark54(59.71528360693745,-0.9091011209152325,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark54(59.73259217205552,-0.9230447998193507,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark54(59.73539920228035,-1.4633215572074079,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark54(59.74264364027971,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark54(59.77765123378208,-0.9811877431583955,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark54(59.795284282514416,-69.0214609036385,49.034649888762345 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark54(59.80760439423881,-0.24402057067265126,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark54(59.84075425356962,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark54(59.855915081940225,-1.1901344355209939E-8,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark54(59.90066713550351,-1.001974661387184,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark54(59.95707371360194,-0.7666736473679583,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark54(-59.98493584582248,-1.4999999999999982,-22.784325583432732 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark54(60.03725961723825,-1.3987955004721022,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark54(60.04026341635104,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark54(60.078017757876125,-1.1088352290422137,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark54(60.118579043523056,-1.368356333067411,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark54(60.187797928313614,-0.60444255549079,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark54(60.19463904588022,-1.2969551272127688,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark54(60.20483877749927,-1.3884614324564357,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark54(-60.20876419021653,-3.930658220966184E-8,-18.26756881014164 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark54(6.021535797171907,-0.37971094010647277,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark54(60.23061161405897,-0.6476622255059965,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark54(60.33950346524318,-0.9813276494343832,0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark54(60.35515796700872,-0.007255398890522791,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark54(60.40290792916187,-0.3925247107138632,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark54(60.41346797496027,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark54(60.43617506000936,-1.2913709192789042,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark54(6.045507613211669,-1.257466791206479,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark54(60.45509560328696,-0.4638548579407171,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark54(60.468209069700215,-0.180153377690628,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark54(60.47702177328526,-0.6092130473807096,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark54(60.47841188170936,-8.639129914699004E-7,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark54(60.56411477389372,-0.10440566512228666,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark54(60.58176971917132,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark54(60.591408840130526,-1.407967392993803,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark54(60.63987095683246,-4.198410221183676E-10,0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark54(60.64512664407582,-1.3753189929282279E-6,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark54(60.655892477490355,-0.3044576574820832,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark54(60.66711571684962,-1.3543590931883271,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark54(60.756805161458374,-0.6540970189151931,0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark54(60.78641167495897,-1.3386687903985441,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark54(60.79611911600374,-0.4799168522195796,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark54(60.85403319195066,-0.19410410701909875,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark54(60.937682100773515,-0.8360342095077522,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark54(60.947263207413584,-0.7883278374938043,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark54(60.959860148904,-1.360953643173643,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark54(60.97825372966943,-1.1293216693562071,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark54(61.003308526235344,-8.642228296147055E-6,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark54(61.043857394573195,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark54(61.111650859051224,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark54(61.11287658733245,-0.12625605029899045,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark54(61.12936552094173,-1.8408416658138643E-6,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark54(-6.113265521772653,-1.6530494634266187E-9,2386.8584811858204 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark54(6.115922531567676,-0.5465807352114362,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark54(61.251850620416256,-1.130983158279463,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark54(61.29771623450537,-0.6425446196852675,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark54(61.3011838728785,-1.4521745730946698,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark54(61.353527661856276,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark54(61.3727488328821,-7.408011544155323E-6,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark54(61.379571334307,-1.0568639740769301,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark54(61.41750476614552,-0.23784860910128547,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark54(61.4302809280839,-1.1593925446748727,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark54(61.44169802099418,-1.300931059519653,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark54(61.45705769679864,-0.3695869896403856,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark54(61.46687749771101,-0.7077245370255143,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark54(61.46768938047785,-0.6812034960687168,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark54(61.46804657370815,-1.0528726785794618,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark54(61.5427184678918,-0.45652167330684856,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark54(61.56589201464686,-0.7735161440797604,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark54(-6.159542757088261,-1.303463795175475,-1.0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark54(61.60334228343397,-0.10574102059430812,0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark54(61.610594158212784,-1.679525339560665E-5,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark54(61.61101416246484,-0.4279444396438019,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark54(-61.629978967956596,-1.394613721626042,0.0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark54(61.703757224706635,-0.013312028716683244,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark54(61.70480073134087,-1.1738753176172843,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark54(61.716812147374185,-1.1678782139005122,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark54(-61.81328217231494,-0.11179978292590476,-0.8459374105566384 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark54(61.85984495188205,-0.3849912361808663,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark54(6.187423418185205,-1.3288470920655584,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark54(61.90107868555404,-1.0540749890554153,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark54(61.908869898039484,-0.2703369506912956,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark54(61.91087530808716,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark54(61.91121996330884,-0.7001150899319288,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark54(61.91988155815485,-1.2031589626830685,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark54(61.948608625866626,-0.0212273977686408,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark54(61.96431043033668,-6.265261648071531E-5,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark54(62.036011865761424,-0.08239057757685053,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark54(62.05555013457293,-1.3340588548423558,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark54(62.094472100447796,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark54(62.10148882501065,-0.06401498626689309,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark54(62.10202788521897,-1.499999999999944,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark54(62.12664743379639,-1.1578840898966263,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark54(62.136194907299284,-0.6665326677450594,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark54(62.138238729596154,-0.20493555373265318,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark54(62.151754498551014,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark54(62.16415085604089,-1.2931937434324432,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark54(62.17416598403463,-1.343762276826387,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark54(62.19964663720046,-0.8650749444755395,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark54(62.215422572445505,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark54(62.27870269387893,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark54(62.28076801564326,-1.184539459332603,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark54(6.232645953165392,-0.44903833341611854,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark54(62.33748717233922,-0.38443819161032744,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark54(62.41276211273174,-0.3450039306915471,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark54(62.417178210930075,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark54(62.42031215875423,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark54(62.47810980270981,-0.06514030305097052,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark54(6.249393761250587,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark54(62.51453744293829,-1.439518106785774,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark54(62.51506463246966,-0.19742846582404772,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark54(62.52459926380715,-1.0789222354148746,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark54(62.58596112069833,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark54(62.58735566185567,-1.4315587983163311,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark54(62.659044184918145,-1.2349833096608513,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark54(62.67464984622009,-0.7121459091926567,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark54(6.268730680430377,-0.5779262764740473,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark54(62.71288995507787,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark54(62.756005748622414,-0.161744154113176,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark54(62.7935880497387,-0.5007785706314394,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark54(62.79686706864276,-0.9466777389403305,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark54(62.89108057557395,-0.28133491316117354,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark54(62.92916742290328,-0.1057225234858663,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark54(62.93619903174496,-0.03870906525843749,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark54(62.95713392870596,-0.230912442544303,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark54(62.97955542653611,-1.342947055406185,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark54(62.98461284451432,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark54(63.01079490916325,-0.7503765437254177,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark54(63.02629802646051,-0.8691168166701311,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark54(63.08348319158536,-3.1718298900901456E-9,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark54(63.17215149183967,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark54(63.26600378239592,-1.4449217657882714,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark54(63.267421012802046,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark54(63.30572368144871,-0.2853116877324924,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark54(63.3323600518164,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark54(6.334138550483658,-1.1222422362086313,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark54(63.356517282463415,-0.25654906436427893,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark54(63.36909079452104,-1.444398273544003,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark54(63.38205180739189,-5.626349594419637E-6,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark54(63.398698391234376,-0.919885143800002,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark54(63.41812803665262,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark54(63.430719166345966,-0.7024796526674306,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark54(63.44580690806668,-1.425548460430596,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark54(63.52446973826929,-1.2990412800951008,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark54(63.56610884482676,-5.942806757703016E-7,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark54(63.568996149617675,-0.18326324312520292,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark54(63.56943523504131,-0.6924680228762412,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark54(63.57721096826219,-0.3649423707760835,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark54(63.57832352018505,-0.4718402591817892,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark54(6.36300013157418,-6.099713094933234E-9,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark54(63.6768075632194,-0.18655982077975963,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark54(63.688136739283294,-0.02348399603384843,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark54(63.70564024765349,-1.2782177340077396,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark54(63.71420728186479,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark54(63.74967382970101,-4.18837607712137E-8,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark54(63.76682407406801,-0.06910471012792285,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark54(63.78414541192124,-0.8531755429275751,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark54(63.79377209532147,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark54(63.8039570408468,-0.6581257224955692,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark54(63.8051090719005,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark54(63.90836304334694,-1.465929001219548,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark54(63.925717449256524,-0.45336556025800784,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark54(63.92984447088489,-0.24453995353879004,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark54(63.94886803479599,-0.9290182253237926,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark54(63.965253374819866,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark54(6.396732444756324,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark54(63.98737808455758,-0.8470807986077582,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark54(64.01243669654615,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark54(64.02027652266247,-0.4800438542135428,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark54(64.0413488821923,-1.0568079218257704,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark54(64.10037638210676,-0.7378551845188541,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark54(64.10578972670422,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark54(64.10975655234509,-0.7299833768377981,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark54(-64.11545533547209,-8.042431693474257E-4,-100.0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark54(64.11549887307223,-1.043950607361828,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark54(64.12373566726862,-0.7689574566964126,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark54(64.12749504432686,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark54(6.413674301255103,-1.0939170366823703,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark54(64.18004448627411,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark54(6.418571485494111,-4.051362466603132E-16,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark54(64.20317868747532,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark54(64.24400840428278,-1.304043581405153,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark54(64.25120011767461,-1.367121086396448,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark54(6.427923910544962,-1.3541954315719082,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark54(64.31452909647928,-0.5519723272455934,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark54(64.33890309763217,-1.0328124843713056,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark54(64.34220540562248,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark54(-64.41668481032329,-1.217108674296205,-5.0758836746312984E-116 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark54(64.41957342794046,-0.9070347892271542,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark54(64.42316658717587,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark54(64.42847377921399,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark54(64.43453566995433,-0.6291248399420222,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark54(64.50170686138779,-0.055038480689105995,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark54(64.52418767574486,-0.9854234138223887,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark54(64.55016987704315,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark54(64.59264971032195,-0.5880969338823832,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark54(64.61909546156397,-0.31338695513952075,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark54(64.6333403365031,-0.342861207465154,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark54(64.6371238120349,-0.1587366434945352,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark54(64.68324211412809,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark54(64.68857844771836,-0.8583417242667366,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark54(64.68875674125016,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark54(64.6942743357477,-0.7042470065068905,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark54(64.70613815727091,-0.8102371957532832,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark54(64.70751715808774,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark54(64.71390937604738,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark54(6.472642083202757,-0.13279763053279225,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark54(64.73355516385988,-1.322897316078598,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark54(64.73872311817792,-0.9476977184950406,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark54(64.74761816985531,-0.5320738425929097,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark54(64.75868771372934,-0.8812697842905814,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark54(64.75973841372598,-0.07462707877772913,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark54(64.76221616141183,-0.7563718977258738,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark54(6.485409809990692,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark54(64.85555523994464,-0.04165505357548005,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark54(64.8869674904139,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark54(64.9559261317763,-0.303040494087367,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark54(64.95837648803621,-0.571116506236649,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark54(65.10124736278658,-0.38250460020401444,0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark54(65.12889937649452,-0.5110947840925917,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark54(65.13987305335374,-0.6875857351651185,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark54(65.14687959566547,-0.8740485429998355,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark54(6.515432813802418,-1.3266059156977559,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark54(65.16837679600188,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark54(65.16921568658267,-0.05820626637962856,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark54(65.17970671799321,-1.1939813383593503,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark54(65.18843883726939,-1.2448481777997218,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark54(65.25569471589333,-0.17979803683319062,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark54(65.27285453652775,-0.15293592467418904,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark54(65.28051447652143,-1.1358379827816878,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark54(65.3042901897272,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark54(65.34889850050716,-1.0370753722205528,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark54(65.40522392875502,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark54(65.4457548909347,-0.36343757025466594,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark54(65.4557521273367,-0.9888529894720701,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark54(-65.45916073800933,-1.4999999999999991,-0.029205999085384626 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark54(6.546744965712122,-0.8912280004710809,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark54(65.4746311291007,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark54(65.48418942927148,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark54(65.4871274552358,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark54(65.4880026770634,-1.0435326599340242,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark54(6.549463710223012,-1.2162086856972887,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark54(65.53041462728532,-1.3103833126944835,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark54(65.54580912341339,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark54(65.55922133431059,-0.43181830927304665,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark54(65.58303301735927,-1.0262596016681322,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark54(65.63299552960817,-0.9308362190989499,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark54(65.66099760878114,-0.2500650280699399,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark54(6.566259977656941,-0.35094310553602664,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark54(6.567106442218446,-0.6078390917538146,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark54(65.70045244195511,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark54(65.70354475313546,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark54(65.74010904391022,-0.30273583642824065,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark54(6.574686629121516,-0.18797276192503665,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark54(65.74874100244631,-1.1686843961018667,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark54(65.75491592589583,-0.4826717353354013,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark54(-65.80885500081135,-1.2864247705597585,-1.0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark54(65.87737267569995,-1.4157641294277417,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark54(65.95151244965365,-0.33947196244542965,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark54(65.96041173136996,-1.302257031223533,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark54(6.596795109106563,-0.008564280758588949,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark54(65.9701511433031,-0.701479350517026,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark54(66.03289944669513,-0.800386724505123,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark54(66.0338662556436,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark54(66.11409574853445,-1.172763850789238,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark54(66.12359239895872,-0.8197744839946353,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark54(66.20875419849338,-0.5344728484561756,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark54(66.21182366607735,-0.05925625616556207,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark54(66.24855242405121,-0.667000225158688,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark54(66.27228752186537,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark54(66.3275789863856,-1.4268517112290149,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark54(66.36943868162695,-0.49672141049275675,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark54(66.38788810570563,-0.0017252049479299706,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark54(66.43049380791882,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark54(66.47665569703229,-0.34338281262616643,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark54(66.5010601809559,-0.8881035183452299,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark54(6.65700445770954,-1.3056987577269568E-7,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark54(6.657687944126295,-0.615615776600487,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark54(66.60006375394062,-0.5934875618566302,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark54(66.63226911075427,-1.4311649658700674,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark54(66.64705243837236,-0.6193634085107738,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark54(66.66544447985619,-0.13764950670860027,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark54(66.68168870075888,-0.5459354687152143,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark54(66.68173659831763,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark54(66.69868383658329,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark54(6.677907401724754,-1.8415262634305206E-7,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark54(66.78554185334858,-1.4589734986770502,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark54(66.79408962569386,-1.4329769133614008,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark54(66.8141823417985,-0.4714824182441957,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark54(-6.684010929078909,-0.34626722653163233,63.93605421555952 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark54(66.8414267415784,-1.4718410963453294,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark54(66.86518838580685,-0.04976721290820934,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark54(6.687542446536327,-0.5897264664705633,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark54(66.87897969696718,-0.4854117599421386,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark54(66.91768764741033,-1.1593344668713712,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark54(66.91926345255666,-0.03962387736206674,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark54(66.92878088289248,-0.8327141140882102,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark54(66.93258682243471,-0.9330921618405577,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark54(66.93558588300047,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark54(67.0003658116508,-1.405451603616996,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark54(67.01608883258362,-0.23156647595268254,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark54(67.03316207551563,-1.4029478611940078,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark54(-67.06669177344587,-0.19349679799065284,0.9189407774952834 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark54(67.10592405932277,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark54(67.13319303755452,-0.7497634964660724,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark54(67.1339348171229,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark54(67.14412003885087,-1.2109340737532097,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark54(67.14968955509221,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark54(67.22351062704269,-0.6926942415544879,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark54(67.26993621430674,-0.5466488172234231,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark54(67.29411377032457,-0.7251871785860036,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark54(67.30163197128309,-0.2577600372936071,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark54(67.331900084743,-0.5628947483499154,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark54(67.36358187190376,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark54(67.39987001509414,-1.1863276495377317,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark54(67.40495504126201,-0.6102613358142577,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark54(67.41204707074695,-1.0359520235296493,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark54(67.42110187015189,-1.0687714588958963,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark54(-67.44945244813958,85.56114601627115,89.61376358782724 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark54(67.46762297437286,-0.5592986138565017,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark54(67.46913800694173,-1.1279340294333338,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark54(67.48215336593017,-1.0219022185715567,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark54(67.5157290389956,-1.3425739280879467,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark54(67.51888234313463,-0.017216883854743514,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark54(6.755284316824174,-0.32150546817569436,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark54(67.57769859194548,-0.529085673276505,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark54(67.59288324623452,-0.7197295883685229,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark54(67.60027847286355,-1.337179001605552,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark54(67.60433385784869,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark54(67.66927662427452,-0.7443013285929858,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark54(67.69417227799383,-0.2055513015157555,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark54(6.769668265841132,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark54(-67.70710386270798,-1.1814602595785955,-0.020570395768835098 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark54(67.72032923203088,-0.1192905809298582,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark54(67.77627339833364,-1.0429301149045238,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark54(67.81965148431505,-1.476630130602369,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark54(67.84102316484103,-1.3592708638844346,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark54(67.87368202271993,-1.381392484921614,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark54(67.89872780767047,-1.4383746966616737,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark54(67.92341591118381,-1.404275518777963,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark54(68.02806091418424,-0.7054926130874648,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark54(68.10925774503258,-0.8124696207794502,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark54(68.11182116681513,-1.3155831123879125,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark54(68.1519832454648,-1.23504077871667,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark54(68.17180181963022,-0.702926810240486,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark54(68.17471480733491,-0.4001637786449601,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark54(68.17801969795849,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark54(68.18612827835065,-0.7818286116459098,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark54(68.19743211981793,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark54(68.20842259862167,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark54(68.22901165571918,-0.0915835945153134,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark54(68.27148166507371,-1.1740968613052551,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark54(68.33004126082648,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark54(68.34806328291461,-0.7435443005714113,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark54(68.35322267136888,-1.2647971691427993,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark54(68.36438085217407,-0.12000653606471934,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark54(68.39379587537414,-0.28074795548490367,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark54(68.4189621739929,-0.3821334574516584,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark54(68.42330169645791,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark54(68.44734587252205,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark54(68.45854196662303,-1.3758675407955785,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark54(68.4889075390627,-0.804702055587029,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark54(68.4947718703583,-1.010215014303359,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark54(68.49763222781463,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark54(68.56818619763669,-0.30801722316811997,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark54(68.66042169656882,-0.1374534221926087,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark54(68.66816533652377,-0.26199850022625526,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark54(68.70257048915096,-0.08058823309007135,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark54(68.72065553517703,-1.273393954042926,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark54(68.73178500124335,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark54(68.74425756020244,-1.2973260029263116,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark54(68.74905204561094,-0.1894005005518995,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark54(68.7881963682589,-0.4161941525609807,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark54(6.8902622916650245,-0.2684222031934098,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark54(68.90547377848111,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark54(68.94181255331762,-1.4999915618705777,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark54(68.96417462369118,-0.20363671928667793,0 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark54(68.96720918235627,-0.8679639742311294,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark54(68.99111658520144,-0.6628615195714733,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark54(6.899580363248381,-1.3038773527155474,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark54(68.99720138086157,-0.03064380024365178,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark54(69.00178073304674,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark54(69.04169901066007,-1.2711517008074225,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark54(69.0525769079618,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark54(69.06239151656399,-0.19156826455041223,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark54(69.06361006581048,-7.030175906784879E-4,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark54(69.06871392720353,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark54(69.07408972576458,-0.11508213277191959,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark54(-69.09582000164697,-3.4030944249193185E-6,-0.6887265997572843 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark54(69.13743250245236,-0.6628053494934312,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark54(69.16634360727923,-0.6142848823772069,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark54(69.18306016834792,-0.5882285213758487,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark54(69.21176093424714,-1.075549444969381,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark54(69.36187940313593,-0.7159133262908028,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark54(6.943214448696155,-1.3211707919729354,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark54(69.43802009337176,-0.44444172038244645,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark54(69.4473449684759,-0.35329641502773823,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark54(69.46707151686314,-0.03561224402065988,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark54(69.51947411870216,-0.04585703953727582,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark54(69.5839982862662,-1.4032564470075772,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark54(6.958899450632706,-1.4999999999415519,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark54(69.5945122435145,-2.674727794553377E-6,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark54(69.59714751576115,-0.37643523834461234,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark54(69.63078536231365,-0.040222983794890865,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark54(69.64084145083609,-0.9794727053514141,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark54(69.66184156121568,-1.1495857897603372,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark54(69.69806066878456,-1.0244934508215038,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark54(6.9792605101910254,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark54(69.81079474700566,-0.921762987988231,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark54(69.86887260629021,-1.1329973737803374,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark54(69.89858718126118,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark54(6.990523729473054,-0.004428744646433086,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark54(69.90740589736833,-1.1414457564647758,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark54(69.94549322619119,-0.0010462394772265875,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark54(69.95567973962179,-1.2978459380895657,0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark54(69.9572255347077,-1.4999999998631275,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark54(70.01787949931115,-0.8984402933782762,0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark54(70.02491083566242,-0.6739676906944707,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark54(70.03075199853467,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark54(70.03763320944293,-0.031982392185089026,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark54(70.070943445603,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark54(70.14354453756343,-0.1649938829627154,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark54(70.14506409480518,-0.48024180214252077,0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark54(7.014674801437346,-1.3806029630585215,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark54(70.15783214868,-0.5309850675300725,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark54(70.15884694046689,-0.9633617534832604,0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark54(70.15901635781401,-0.6303140130891336,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark54(7.019076114895668,-1.326206809510062,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark54(70.1972535040486,-1.3101950625076597,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark54(70.19789903072439,-1.91296291555824E-9,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark54(70.20698909987811,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark54(70.25146674181008,-1.1713412609579201,0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark54(70.27425115809308,-0.726131275678555,0 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark54(70.278379333814,-0.9218531327941548,0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark54(70.28588942579933,-0.6470506188970666,0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark54(7.0299267364463995,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark54(70.30865282482361,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark54(70.35031120503665,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark54(70.35462576209008,-0.40293153080106264,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark54(70.3563337929193,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark54(7.036049524987856,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark54(7.0394162797747954,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark54(70.41145269125988,-1.4160198184446813,0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark54(70.41404415132513,-1.452825291944496,0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark54(70.42936327557604,-0.747952586669657,0 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark54(70.48647734180591,-0.24403773059127332,0 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark54(70.49700921194713,-1.4695140012872783,0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark54(7.053236493506539,-0.3828172384403814,0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark54(70.56305393597367,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark54(7.066138280297121,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark54(70.68591833538002,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark54(70.71283106419614,-0.2622726724193001,0 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark54(7.07461677702284,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark54(70.74868033448642,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark54(70.7730324619618,-1.4154187583833941,0 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark54(70.78929445815811,-1.1696030954974632,0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark54(70.80623563518068,-1.4999999993777942,0 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark54(70.86339906867,-1.4999999795387111,0 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark54(70.87695962218659,-0.502647258498798,0 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark54(70.90069746048886,-1.1658427742528037,0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark54(-70.92224291676739,-0.029195092943682943,0.5780751177654642 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark54(70.94895046091528,-1.4999999999999902,0 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-0.014886881522587658,0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-1.0709287239600315E-15,0 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-1.3633126772965865,0 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark54(71.0544800861231,-0.37927864455145655,0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark54(71.05467364052191,-0.948484750151847,0 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark54(71.0668641255748,-1.4108576376480784,0 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark54(7.111163527177258,-1.4242948358341128,0 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark54(71.14998157451936,-0.9059341321992367,0 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark54(71.15353935865308,-0.24232998027266817,0 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark54(71.15543505680614,-0.6697450923676627,0 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark54(7.118397046008979,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark54(71.1894889435876,-0.9898702520467717,0 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark54(71.22335186084473,-1.3016384898921558,0 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark54(71.22711512171568,-1.7347262319031373E-8,0 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark54(71.23764831751735,-0.1871683584538931,0 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark54(7.1263270335108695,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark54(71.27194581471142,-0.34314503396265,0 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark54(71.28942158325859,-0.022556939188419278,0 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark54(71.3661769300075,-1.3306292560450999,0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark54(71.42868480747003,-0.3194257691381077,0 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark54(71.43917653385358,-0.5692806506986081,0 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark54(71.50560102728176,-0.7555770437122504,0 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark54(71.55104080998572,-1.1212731456388003,0 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark54(71.557744277614,-0.5325261267368546,0 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark54(71.56503835353438,-0.6659099401195174,0 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark54(71.57380293861115,-0.7769230783607645,0 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark54(71.59857991386906,-1.1495856266642939,0 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark54(71.6326333463873,-0.22929292555892417,0 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark54(71.69686961636239,-0.5508301910630706,0 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark54(71.73707755310149,-1.4999999988877657,0 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark54(71.75122818472875,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark54(71.75922310703095,-1.3374516322817391,0 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark54(71.8449507527614,-1.4449641598595604,0 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark54(7.185503862702632,-0.281019438980195,0 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark54(71.89445909319836,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark54(71.90148965752213,-1.2411173603155026,0 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark54(7.195038141000841,-2.0266187336342355E-8,0 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark54(71.97349511029773,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark54(7.197823543526349,-2.598119730033766E-9,0 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark54(71.98723169384411,-0.21792499438026647,0 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark54(72.04156978473313,25.150353225734705,-84.63406795159418 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark54(72.05904079319626,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark54(72.06367644276426,-0.7786766197420718,0 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark54(72.07175844557733,-0.5905875375863872,0 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark54(72.08670690564142,-8.842613465860135E-7,0 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark54(72.09163773816832,-0.9193168435350968,0 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark54(7.210775831771446,-6.651555693518703E-10,0 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark54(72.11492909458522,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark54(7.213000916354034,-1.4828900502116822,0 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark54(72.20511468862392,-0.9832304784885975,0 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark54(72.24762675200921,-0.3688305457766319,0 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark54(72.28093338571921,-0.15156627840948078,0 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark54(72.29767484107958,-1.3329363352830432,0 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark54(72.33378832125666,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark54(72.3661939358793,-0.2763538676440973,0 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark54(72.42130053743855,-0.14449394624849055,0 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark54(72.42212396953971,-1.3094346824884293,0 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark54(72.43276418553062,-0.30340706510715804,0 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark54(72.46043469830478,-1.3392812534511866,0 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark54(72.47025574702556,-0.210967701169809,0 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark54(72.4930156861073,-9.923168897589044E-4,0 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark54(72.49447754844174,-0.3553919432391135,0 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark54(72.5156502445011,-0.7377482390712515,0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark54(72.54929081948994,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark54(72.56301256703667,-0.8318742647302795,0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark54(72.64217839900681,-0.3362781594313091,0 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark54(72.66592365519705,-0.6622286167072147,0 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark54(72.67010793757169,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark54(72.6907312446915,-0.8238992800819034,0 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark54(72.73049886223784,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark54(-72.76048126818107,19.627472454414246,0 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark54(72.76286180795216,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark54(72.77184268254408,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark54(72.80432129298035,-1.3634387061698616,0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark54(72.81709761283079,-0.11731370478329364,0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark54(72.90378438600044,-0.5049117449323708,0 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark54(72.90990121382498,-0.6761844464996569,0 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark54(72.9154845255967,-0.4041386894189998,0 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark54(72.92614907258,-0.7111753423840526,0 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark54(72.92617625146812,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark54(72.94308042825296,-1.0338113455281874,0 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark54(72.94620442326821,-0.3707790702056164,0 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark54(72.95900460884246,-1.4539485702273538,0 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark54(72.99446344013788,-0.7548219405505152,0 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark54(73.01346728894197,-0.6004772529402058,0 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark54(7.303558704599868,-0.5089095537629429,0 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark54(73.11910058315021,-0.8493017891591563,0 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark54(73.17443917414346,-1.2688382614773313,0 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark54(73.21907929300914,-0.8789179236552265,0 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark54(73.24302416508621,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark54(73.25648784422413,-0.8366362224902706,0 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark54(73.26247254782305,-5.604743791206416E-9,0 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark54(73.27174218820181,-0.9349127673279725,0 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark54(7.327605752079762,-1.499999999334533,0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark54(73.31796981865708,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark54(73.33957490431624,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark54(-73.36587417874941,-1.1229883454091838,-72.38376792703885 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark54(73.37311346776792,-0.622227127053435,0 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark54(73.39370072506108,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark54(73.45535410565498,-0.20479024839777643,0 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark54(73.48012172104501,-1.3446866134190915E-9,0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark54(73.49792675730609,-1.3650043527900693,0 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark54(73.54435415466145,-1.1835790310088086,0 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark54(7.3603502768089015,-0.1549731614504294,0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark54(73.62092347297602,-1.4350653546838412,0 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark54(73.64957236020066,-0.34971378132635156,0 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark54(73.66693678266392,-0.034312129913573575,0 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark54(73.69092005755567,-2.0207541448936786E-9,0 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark54(7.373678125921316,-1.1936946282824779,0 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark54(73.76715272796406,-0.13577871613117054,0 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark54(73.80820725620231,-0.2125154359135326,0 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark54(73.81623544010765,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark54(73.84035029778374,-0.7091645716223596,0 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark54(73.86721212165338,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark54(73.87069066723686,-0.32368400945527753,0 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark54(73.8923247122546,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark54(73.89581055695933,-0.5842352808659861,0 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark54(73.90088649087943,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark54(73.94225399135112,-0.4491076370333475,0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark54(73.97661356720317,-0.04285126118503551,0 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark54(73.9779447199362,-3.271458765053644E-8,0 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark54(73.99018197221531,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark54(74.01390017714357,-0.6532110022677431,0 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark54(74.04510708554378,-0.17294427135535972,0 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark54(74.05938354284126,-1.3878707586734436,0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark54(74.07186998331474,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark54(74.10032741308004,-1.263605805212677,0 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark54(74.10767198268246,-1.4062016766757068,0 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark54(74.12444292454819,-0.5243881357707495,0 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark54(74.14927981689095,-0.4206816991335778,0 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark54(74.17017249483877,-1.4999999999999902,0 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark54(74.17255332915522,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark54(74.17681945229603,-0.13943023402400279,0 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark54(74.1794679857291,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark54(-74.25402632952603,-7.105427357601002E-15,-1.0 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark54(74.312063066458,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark54(74.35978415476737,-0.011225681574948174,0 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark54(74.36287540970127,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark54(74.36577979909399,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark54(74.3956851102815,-0.6765619023147806,0 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark54(74.4284481344726,-1.0632142825232265,0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark54(74.44851198028115,-0.153118392709169,0 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark54(-74.47225199944785,-2.220446049250313E-16,-0.745007193405686 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark54(74.48856585450451,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark54(-74.51887744777339,-91.94506712974007,17.35382723925558 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark54(74.52809205208533,-0.002957347737636895,0 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark54(-74.5300956900052,-1.4009593761262575,-5.3890075260428554E-11 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark54(74.53390277292897,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark54(74.58989230414429,-1.4765658210442467,0 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark54(74.61359633317042,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark54(74.61965744381958,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark54(74.65668268723519,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark54(74.67659417369,-0.9392171540103789,0 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark54(74.70230458694098,-0.02970259503034356,0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark54(74.70403955287938,-0.5829834645986409,0 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark54(-74.72343078765773,19.07983588286028,-51.47630240426546 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark54(74.74578998086261,-1.4846114547527662,0 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark54(74.81457538181311,-3.087334766957364E-5,0 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark54(74.82436328645571,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark54(74.83534673975316,-0.25431260870408323,0 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark54(74.83667373347598,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark54(74.84767229372366,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark54(74.86494087776205,-0.3549384940974401,0 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark54(74.88235719100632,-1.1617330596556905,0 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark54(74.90758211548427,-1.194399708487243,0 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark54(74.91145185530931,-0.3255993403701751,0 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark54(7.491637683100748,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark54(74.92154143586009,-0.13046190849630557,0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark54(74.93486469235401,-0.14863529519458618,0 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark54(74.96038751194112,-1.1670930094700207,0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark54(74.96304519583632,-1.4209048773159054,0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark54(74.96537581227514,-1.3821921162016135,0 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark54(74.97291413044903,-1.4847804489787204,0 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark54(75.01565272529167,-1.8006901665735018E-16,0 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark54(75.07963935083198,-2.2195186773706447E-6,0 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark54(75.08238509747588,-1.4143111496209024,0 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark54(75.09478116525622,-1.408000423945893,0 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark54(75.20742345514776,-0.04576382751653796,0 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark54(-75.21043175562912,-0.17005339858664037,78.0317531022813 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark54(75.23774800136908,-1.136297623998877,0 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark54(75.24456251583271,-1.118328335603271,0 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark54(75.27183407160862,-0.7369023283077795,0 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark54(75.28750238988152,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark54(75.30633622971254,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark54(75.31866248157482,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark54(75.34439334180303,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark54(75.35540171005493,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark54(-75.37713006529253,-1.1609381628438866,1.0 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark54(75.38973449927028,-1.0741638730126124,0 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark54(75.39222101949525,-0.8699331715495155,0 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark54(75.4012567304329,-0.8445462642782137,0 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark54(75.42291913330422,-7.337385128314279E-10,0 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark54(75.43462910101019,-1.0140811754218657,0 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark54(75.46834602705076,-0.31311774725184094,0 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark54(75.47578339829494,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark54(75.49116285366583,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark54(75.49896318351446,-0.033367307521738665,0 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark54(75.50462176537418,-0.2504195334242212,0 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark54(75.53579825995232,-0.649973809577304,0 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark54(75.56225339795927,-0.2869196781410668,0 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark54(75.56681934182666,-0.2524164480456932,0 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark54(75.64362991294836,-2.009526086933057E-8,0 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark54(7.573877163785454,-0.2863319262568931,0 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark54(75.75789253355592,-5.329317153859836E-7,0 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark54(75.79220473560352,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark54(75.81210587167747,-0.04690927400356948,0 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark54(7.583223580324718,-0.3081934549932562,0 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark54(75.91097378108591,-0.50565472442689,0 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark54(75.94038414357387,-0.04535870572595633,0 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark54(-75.9445973241638,-0.7046840176770016,1.0 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark54(75.96695135322156,-1.233147892800996,0 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark54(76.07268598249524,-1.1705141721764605,0 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark54(76.08124631150147,-1.4374859507204576,0 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark54(76.10624307301765,-0.27252412557363925,0 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark54(76.16826004303573,-0.2602887102369258,0 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark54(76.22191318857486,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark54(76.22600197833829,-0.7255257378719905,0 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark54(76.29002610375474,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark54(76.31746935357552,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark54(76.33685699893311,-3.9481699636098567E-4,0 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark54(76.39207373889242,-1.3858171557452295,0 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark54(76.39908654150382,-1.5629200144524747E-16,0 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark54(76.46389721480128,-1.4122430925140113,0 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark54(76.50535480059075,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark54(76.58721051858365,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark54(76.59565812519654,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark54(76.66622747451063,-0.162288544130746,0 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark54(76.71921597534131,-0.4187337804587573,0 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark54(76.76265280123438,-1.065200057788429E-6,0 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark54(76.78500575218919,-0.8375802795142474,0 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark54(76.78958428361437,-0.11567029719900387,0 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark54(76.81505172454467,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark54(76.81981398274777,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark54(76.90377574941208,-0.46859097637453156,0 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark54(76.93980074031418,-0.09152478826487176,0 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark54(76.94246920145721,-0.38284124027012245,0 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark54(76.96930172034351,-1.1455469201185622,0 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark54(77.01483229512911,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark54(77.06389124545933,-0.40409657038610014,0 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark54(77.13353173211209,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark54(77.14564312873893,-0.18292791207883852,0 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark54(77.185295433058,-0.3655992778536218,0 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark54(7.718808004585981,-0.4897076348701006,0 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark54(77.2311400247076,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark54(77.23537650677173,-0.5970240898968682,0 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark54(77.29647004424339,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark54(77.35139011135388,-1.2387120698939498,0 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark54(77.35932193656444,-0.5659037585569824,0 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark54(77.5329638604648,-0.3245175428699092,0 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark54(77.55622842276159,-0.8143171334161492,0 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark54(77.57102904036242,-0.06545534025274202,0 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark54(7.757240362589997,-1.080621636780914,0 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark54(77.6246960900179,-0.2743032806317869,0 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark54(77.68615172253482,-0.15515421721264033,0 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark54(77.68648812334125,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark54(77.69906541915972,-1.4414567794687503,0 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark54(77.76171713333409,-1.063093152815634E-9,0 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark54(77.7888342703762,-0.9970887425573367,0 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark54(77.80150309203142,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark54(77.81390350087315,-0.9402001508849409,0 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark54(77.82743993897913,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark54(77.8743052816545,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark54(77.88185471803214,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark54(77.91859535234227,-0.6885921527576215,0 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark54(77.92664129263966,-0.8014134397576145,0 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark54(77.9526319781668,-1.3241596575237962,0 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark54(77.96998886135938,-0.04380998601953934,0 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark54(77.98162285386088,-1.1469637216438229,0 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark54(77.99872414040432,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark54(78.02421723907392,-0.019451979549924836,0 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark54(78.03378322953444,-1.2094886647026328,0 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark54(78.0383547732414,-1.4999978872060764,0 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark54(78.10088442732983,-0.3939639678050181,0 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark54(78.17301482331624,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark54(78.17639841895743,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark54(-78.23265253775358,-1.4999999999999964,1.0 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark54(78.27684738317143,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark54(78.27839418663694,-0.554447903837854,0 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark54(78.37142686349526,-1.0739368745114555,0 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark54(7.838346448338496,-0.08784877245339104,0 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark54(78.45424123993044,-0.018096625550458878,0 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark54(78.46924799567182,-0.9603517229822732,0 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark54(78.60016927231437,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark54(78.60133024266679,-0.5181007731714686,0 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark54(7.8605898663261655,-1.0623361997134184,0 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark54(78.61662542699614,-0.9171905910419502,0 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark54(78.63395702072228,-0.5895420125278292,0 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark54(-7.864011209545669,-1.4926250426349303,-1.0000002114137165 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark54(78.65551260348782,-1.0703168288217364,0 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark54(78.71062687672406,20.51290975584159,-49.90969679472268 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark54(78.7200441031464,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark54(78.72560335646669,-0.48079961821253714,0 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark54(78.738714912027,-0.4952455568938685,0 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark54(78.75103071040216,-0.15136981822523538,0 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark54(78.77458483709628,-1.2505895922590895,0 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark54(78.79626104436234,-0.42693894284666634,0 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark54(78.80947776945649,-0.4520775561152304,0 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark54(78.80957538091883,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark54(78.8104397910897,-0.6034470491087092,0 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark54(78.81203604105124,-1.4999999999995506,0 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark54(7.882896019469476,-1.4994232016910138,0 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark54(78.83776267040591,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark54(7.884115791409684,-0.4831822428352255,0 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark54(78.8539611755685,-0.65206162875924,0 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark54(78.87754949667641,-1.371586630388208,0 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark54(-78.89855515432123,80.48984398149634,24.273096988926724 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark54(78.94238500931189,-0.002922603541548662,0 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark54(78.9440040290217,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark54(78.95027794674063,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark54(78.96935827518553,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark54(79.00083664078775,-1.1238708484166455,0 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark54(79.02873285993319,-2.5275158014626653E-9,0 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark54(79.03845489064202,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark54(79.04788690761386,-1.3187757365893873,0 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark54(79.06966793979298,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark54(79.08106632326222,-0.07743096693287699,0 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark54(79.08734438536916,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark54(7.914727328192419,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark54(79.18615265206371,-0.5691408296138536,0 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark54(79.1884007953619,-1.0231826701046356,0 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark54(79.20611657809144,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark54(-79.24624701425209,-0.80008801643483,71.3780352369437 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark54(79.2826796754954,-1.4326122066884377,0 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark54(79.32567850692821,-0.036782102578902576,0 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark54(79.35755035780318,-0.8059276457707689,0 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark54(7.936326964862408,-3.1266944622445226E-17,0 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark54(79.38003769655664,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark54(79.38311030276907,-0.26779125711693874,0 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark54(-7.941165495096911,-0.3203593441896029,1.0 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark54(79.42815385324967,-0.3560494779136204,0 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark54(79.44400419679775,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark54(79.53008716199469,-0.012941826278358715,0 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark54(79.53842268051093,-0.18579793334687622,0 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark54(79.55607873316984,-0.22581143414038618,0 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark54(79.61217900309404,-0.872606292454364,0 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark54(79.62372772568416,-0.9383174058120018,0 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark54(7.963556811766739,-1.1148645785776163,0 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark54(7.966780238758247,-0.5481752611746797,0 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark54(79.67079039113547,-0.6587553623701238,0 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark54(79.67716021362457,-0.5153673550879921,0 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark54(79.68160440011391,-0.6509188149040774,0 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark54(79.70818052175062,-1.2194642872231714,0 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark54(79.71072065521523,-1.4999999999999978,0 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark54(79.71166670006886,-0.25845810671087577,0 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark54(79.74410917901909,-1.233306284746526E-6,0 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark54(79.74924422724075,-0.6738799483380018,0 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark54(79.75679457649147,-1.2222143571150972,0 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark54(79.7584381202359,-1.2742513302395393,0 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark54(79.76365491591224,-0.2743191421664517,0 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark54(79.77620337817581,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark54(79.77891079346097,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark54(-7.979398511081463,-0.6855950092630787,0.27293629350719373 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark54(79.8533760919056,-3.6167787703991E-8,0 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark54(7.98790096032856,-0.41829218440225935,0 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark54(7.990430590673556,-6.8506742017461355E-6,0 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark54(79.9104148452063,-1.0434468932144414,0 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark54(79.91868459624368,-1.346173979109679,0 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark54(79.92686059781425,-1.0959138755454703,0 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark54(79.93210549180543,-1.0325444852275183,0 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark54(79.97358573018214,-1.3264004624544836,0 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark54(80.00459115703484,-1.4186428080795657,0 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark54(80.03537354737492,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark54(80.05225538391014,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark54(80.07021175758474,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark54(80.07422013194756,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark54(80.09275320973421,-0.3339021080281481,0 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark54(80.11206137079952,-0.04661281168071696,0 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark54(80.11764618762703,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark54(-8.016673440035891E-292,-1.1754712681873434,0 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark54(80.19488554605554,-0.6807142733998648,0 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark54(8.01949341124699,-1.276279617180182,0 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark54(80.20968231809624,-0.9179673382360818,0 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark54(80.22323526078183,-2.3650694889996855E-9,0 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark54(80.22790523256441,-1.0703468575991053,0 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark54(80.23921699786212,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark54(80.24976316728237,-0.9339397779902958,0 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark54(80.25065045530143,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark54(80.29517173831562,-1.417343914140655,0 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark54(80.30362209190292,-3.066091839648224E-9,0 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark54(80.32951956195635,-0.9990272041828052,0 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark54(80.36268443435179,-0.30905569698278035,0 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark54(80.39749301741239,-1.4586504131610578,0 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark54(8.040175108602512,-1.216136528540193,0 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark54(80.46171433373706,-0.5129434055836661,0 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark54(80.51315482805194,-0.2986525749004798,0 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark54(80.6822822774999,-1.0616268404878237,0 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark54(80.70712305886939,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark54(80.72011886050636,-1.336057389309515,0 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark54(80.77390045668692,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark54(80.79851516911938,-1.0439129510712064,0 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark54(80.8027080707904,-1.2738646961397766,0 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark54(80.84095139357186,-0.40664073954846813,0 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark54(80.84170561818576,-1.066418664747033,0 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark54(80.87031115390539,-0.46169645738149256,0 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark54(80.88943807532664,-0.29852861712673473,0 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark54(80.89801447733939,-1.359628896349976,0 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark54(80.90525698536945,-0.05806900097162959,0 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark54(80.90835106279536,-0.9501035852066622,0 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark54(80.92251179238814,-1.4658115391734885,0 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark54(80.93270922913194,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark54(80.95781497927149,-0.3336639996044637,0 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark54(80.98199313908434,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark54(8.101038997221584,-0.41551187312489324,0 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark54(8.104886232632026,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark54(81.12128260771925,-0.5404955828641533,0 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark54(8.11246642512162,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark54(81.15729478810547,-0.27908105969675745,0 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark54(81.19216152334528,-0.6197097495408208,0 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark54(81.21817553393501,-1.3574760528161929,0 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark54(81.31559713445687,-1.6108224494859217E-9,0 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark54(-8.13411662837661,-0.5532872049067237,-0.9154299143964679 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark54(81.34441036112095,-0.6439736828354199,0 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark54(8.13487217878564,-3.4567818974906014E-6,0 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark54(81.35346006852774,-0.25659114224322277,0 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark54(81.38388918786728,-0.5861187256663438,0 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark54(81.41979211860314,-1.499999999999968,0 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark54(81.43398192736458,-0.8920822176833281,0 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark54(81.45157489834597,-0.36152762696830365,0 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark54(-81.4815663273881,-0.4615146540973125,-1.452272476562093E-15 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark54(81.51128783947331,-0.2184890759132685,0 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark54(81.5151247123051,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark54(8.153198958204941,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark54(81.55789362844669,-1.4524920069717866,0 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark54(81.61934951643312,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark54(8.162424758592365,-1.1136721800579599,0 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark54(81.65506820458828,-1.1938587180074682,0 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark54(81.69534984023149,-1.282472985258213,0 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark54(81.70638143261704,-1.4999999999999902,0 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark54(81.74766274009511,-0.6676012520896251,0 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark54(81.74874505179136,-1.0774150083875171,0 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark54(81.76634154214884,-0.27598031059346395,0 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark54(81.90005434219535,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark54(81.90574441864956,-0.09062972765212507,0 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark54(82.02502659285915,-0.12570428129406253,0 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark54(82.03441633482974,-1.4999999993811934,0 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark54(8.204223591131623,-0.4243991667519656,0 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark54(82.05677236802603,-1.4526697671116522,0 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark54(82.0635685643299,-1.1071396256553232,0 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark54(82.07541963135859,-1.499999999999936,0 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark54(8.211916428296789,-1.369927882251155,0 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark54(82.1352136213109,-0.2230752260088917,0 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark54(82.18853179960024,-0.8385733956057158,0 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark54(82.24415629874923,-1.105027477935323,0 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark54(82.26033062901786,-1.087495957795376,0 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark54(82.35632062714134,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark54(82.35754671231062,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark54(82.38414358720803,-0.9417780291178559,0 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark54(82.40327425181135,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark54(82.43601131900164,-0.07464340705641348,0 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark54(82.46758301559589,-1.001942984721012,0 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark54(8.248954982610229,-0.06943978708086007,0 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark54(82.5099233211601,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark54(82.5291491779846,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark54(82.56246822580576,-0.1835708869825307,0 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark54(82.56267758586492,-1.066403898531566,0 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark54(82.57218095712298,-0.2742183237991185,0 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark54(82.60627718331024,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark54(82.61939395527023,-0.26845396095237106,0 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark54(82.62157660810945,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark54(8.272442809167657,-0.3153965887795702,0 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark54(82.74688493512272,-0.44146351375846365,0 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark54(82.75054771674537,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark54(82.80082022369305,-1.0590958931897152,0 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark54(8.28054014063974,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark54(82.84128483983123,-0.07022015670744608,0 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark54(82.9241517739338,-0.9619628527339832,0 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark54(82.94124576029657,-1.4951087928373397,0 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark54(8.29683570354669,-1.0955547034484612,0 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark54(83.03709624995642,-0.7089032539535509,0 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark54(83.05556117149308,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark54(83.0891957576855,-1.4999999999999316,0 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark54(8.310497886701278,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark54(83.11614298539563,-4.224479861815454E-5,0 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark54(83.14282907041986,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark54(83.18290781053847,-1.2714222807171893,0 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark54(83.24667158737222,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark54(-83.28933812068597,-0.5725655074741285,1.0 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark54(8.3310670646908,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark54(83.32566172889074,-0.5191065404296182,0 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark54(83.36159621891595,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark54(83.4103780574194,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark54(83.43293975743785,-1.4174843293354054,0 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark54(83.50838722409301,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark54(83.5227242473971,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark54(-83.55358805091824,-1.4982817117801623,-0.3803397977839126 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark54(83.59126375340969,-0.08591396659496553,0 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark54(8.360698031391124,-0.26568185542661293,0 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark54(83.64692918700834,-0.7158913907846457,0 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark54(8.36682540546824,-2.544949935172333E-9,0 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark54(83.68204972447208,-0.3978734203034966,0 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark54(83.69608434733746,-0.5995383488832893,0 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark54(83.71225483210952,-0.5332058365644126,0 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark54(83.71551934657421,-0.61957327203082,0 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark54(8.375963437501326,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark54(8.389224681827187,-1.157943066978441,0 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark54(83.93057304226001,-0.4378975210500692,0 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark54(83.96553663808785,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark54(84.01992675686185,-0.8193626830846448,0 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark54(84.14788161863666,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark54(8.42192703017514,-1.426817201740679,0 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark54(-84.22318635988752,-0.40559354720664886,86.17505724953486 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark54(84.2237455087041,-0.8702586340224201,0 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark54(84.2238278857802,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark54(84.22564728261682,-0.06959853379456638,0 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark54(84.30820894284372,-1.2761002224438016,0 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark54(8.434141469810319,-0.1570502386920012,0 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark54(84.42954558677613,-1.1008574171484753,0 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark54(-84.42973392306337,-0.456082497297132,1.0 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark54(84.51789730776916,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark54(84.62114213526516,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark54(84.65856808597843,-0.2251436070294517,0 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark54(84.65884526084088,-0.658870915883676,0 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark54(84.65911013286777,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark54(84.71409369060129,-0.8085029809105224,0 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark54(84.73090514892513,-1.4138658084919742,0 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark54(84.74273317209068,-0.46994698764855514,0 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark54(8.478190351763956,-1.3281585896647812,0 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark54(-84.81763646700362,19.596638511678762,3.0830995561191656 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark54(84.86151683690869,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark54(8.490344729379416,-1.4941603430538226,0 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark54(8.492018303783027,-1.161599206527626,0 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark54(84.93472215126252,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark54(84.94706594351808,-0.3124419526578883,0 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark54(84.97492936114459,-0.8673061587489156,0 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark54(84.99443750651977,-0.4134645521548872,0 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark54(85.0449803432202,-0.737719877679142,0 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark54(85.04621114892078,-0.9898115041235371,0 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark54(85.05590101290952,-1.4999999999999671,0 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark54(85.10392099456463,-0.1313852598762802,0 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark54(85.16833447649529,-0.7599813016798427,0 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark54(8.518025862637373,-0.5751301979307848,0 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark54(85.21700112743557,-0.9574239965732447,0 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark54(8.524153090636702,-0.16830355557152554,0 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark54(85.296425017439,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark54(8.529972667379297,-0.1316097958893503,0 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark54(85.31250520864157,-1.1574356492642182,0 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark54(85.3612163622796,-0.12257780006621033,0 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark54(85.40165029437895,-1.2265877390665882,0 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark54(85.41096658459736,-0.14523757339856713,0 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark54(85.42668863368368,-0.22090438938606383,0 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark54(85.44727909948475,-0.9056697277527102,0 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark54(85.45091206116282,-0.46690417088619984,0 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark54(85.51428287807158,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark54(85.56340446753491,-1.4349494719761076,0 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark54(8.558718723914382,-0.0957295376670535,0 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark54(85.6046363364245,-1.3964196932077826,0 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark54(85.7210585459107,-0.8613505777815131,0 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark54(85.72707121567615,-0.11008670911060214,0 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark54(85.74776548590732,-0.9364772459844976,0 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark54(85.75100537717844,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark54(85.75723938207835,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark54(85.82627383876681,-4.3368086899420177E-19,0 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark54(85.84810292033265,-0.345603148009743,0 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark54(85.93406331123745,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark54(85.93612716155482,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark54(86.04859619277671,-0.4869504031689882,0 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark54(86.07135047416298,-1.4139370595151253,0 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark54(86.07147059227611,-0.7333545034498865,0 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark54(86.10333704353062,-0.6815642838484166,0 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark54(86.17238773666674,-1.1093795197239233,0 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark54(86.17496444727976,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark54(86.18265968124209,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark54(8.620190482621826,-1.1526039430125756,0 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark54(86.22411749345639,-0.7861211454174757,0 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark54(86.23297344673492,-0.0437969523153825,0 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark54(86.2705574492751,-0.3903021278208103,0 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark54(86.29798177472654,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark54(86.30138772856168,-0.5544998563341608,0 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark54(86.3106660732509,-0.0494114004376951,0 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark54(86.33279630436118,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark54(-86.34295985541472,-0.040266702254115216,0 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark54(86.37243950472612,-1.4523756373589514,0 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark54(86.3902459460441,-0.9810754764566068,0 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark54(86.39294398745378,-1.1289266740774426,0 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark54(86.3938328075144,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark54(8.642036752470219,-0.11901769617042657,0 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark54(86.4428996428679,-0.4181355229806185,0 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark54(86.50727656361394,-0.18864125020697697,0 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark54(86.57542439610847,-1.4248230044433006,0 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark54(86.59511399372687,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark54(86.60781962771313,-0.014418637776016485,0 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark54(86.61149215703023,-0.8929623079457123,0 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark54(86.63048326698372,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark54(86.65748719509193,-0.8597749892958788,0 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark54(86.6580282908808,-1.4907984511823928,0 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark54(8.668948702385038,-0.5915222986115225,0 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark54(86.68967909963337,-1.0048005396329711,0 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark54(86.7046775146193,-0.1729633676903905,0 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark54(86.70636365618202,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark54(8.67952832646084,-1.0403565454728807,0 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark54(86.81436004656314,-2.0791150340233704E-7,0 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark54(-86.81467799560512,-1.1574426103780233,0.5019641652587261 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark54(86.82910960447836,-0.38362247780750636,0 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark54(86.83645146514647,-0.7320844609349964,0 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark54(86.87018001532076,-1.1772360539531723,0 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark54(86.87371012277396,-1.3330553261154137,0 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark54(86.92731927161836,-0.018194309791727425,0 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark54(86.93744573149598,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark54(86.9658781957286,-0.48132315507922757,0 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark54(86.9766835310653,-0.5937504587422004,0 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark54(87.03154443526208,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark54(87.03310178562927,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark54(87.06702896675988,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark54(87.10586149138152,-0.3428024795376857,0 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark54(87.10608058217306,-0.7855222076108976,0 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark54(87.13331922261872,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark54(87.14886744796914,-2.9173708558579034E-8,0 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark54(87.1536185512123,-0.4738172271643425,0 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark54(87.16029100983366,-0.9793555197079415,0 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark54(87.16890592771455,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark54(87.2221112368521,-0.4405153590847364,0 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark54(87.22614629005082,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark54(87.24430370360295,-0.03405194202723034,0 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark54(87.2571444709277,-0.586213566407971,0 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark54(8.736037523599776,-0.5271822964947468,0 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark54(87.38954266226321,-0.2687581154166191,0 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark54(87.42947877417313,-0.5442993605325324,0 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark54(87.45660149158877,-0.692178130736897,0 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark54(87.46356842110254,-0.4793648234317902,0 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark54(87.46577795496633,-1.6073468755340444E-9,0 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark54(87.49000973140255,-1.3034487028761879,0 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark54(87.51187415544564,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark54(87.58653699642747,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark54(87.59779161952025,-0.44812179242651773,0 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark54(87.6717443967951,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark54(8.768295117294272,-1.125495968394688,0 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark54(87.75493335286296,-0.27226646513528274,0 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark54(87.78330265029189,-0.6161082770192505,0 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark54(87.79526604073459,-1.2026567093956544,0 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark54(87.79763056142397,-1.4181576301184462,0 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark54(87.8004908969803,-0.6671633974118745,0 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark54(8.788374650188402,-0.05706356505112109,0 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark54(87.90075883308529,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark54(87.90362161296571,-0.5569260398303859,0 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark54(87.93629901110143,-0.7147807883520835,0 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark54(88.00157529294094,-1.1511817119716508,0 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark54(88.01783393007949,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark54(88.03487767346176,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark54(88.05122183899036,-1.4340778201215523,0 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark54(88.07816213104863,-0.330392995684619,0 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark54(88.10196678249025,-1.235580030950917,0 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark54(88.16567896424007,-0.27927327065585494,0 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark54(-88.16571208881616,-0.3686879044427709,81.70182265822942 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark54(8.818468367612752,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark54(88.22924741078216,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark54(88.23359245034868,-1.1407130174178874,0 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark54(8.830250764130971,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark54(88.36597588075296,-0.6403292976895898,0 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark54(88.49401045677385,-1.499999999999996,0 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark54(88.50171266934754,-0.4343633763411101,0 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark54(88.53104655000689,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark54(88.5581752493491,-0.5583359521724346,0 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark54(88.58911828901485,-1.396409058291828,0 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark54(8.869838803855458,-0.802560802878518,0 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark54(88.70119791515532,-1.3879277475436473,0 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark54(88.70446860766117,-0.13524157635590583,0 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark54(88.79419918601417,-0.24816675341683947,0 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark54(88.79955320795989,-0.11843571343309356,0 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark54(8.881784197001252E-16,-0.22084381561634608,0 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark54(8.881784197001252E-16,-0.2684801727529648,0 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark54(8.881784197001252E-16,-1.3777652966806189,0 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark54(88.82826417488124,-0.33040981643734213,0 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark54(88.82876424623944,-0.4076017487380881,0 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark54(88.84199420804265,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark54(88.85363321606322,-4.029936309349975E-9,0 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark54(88.86582781844646,-1.4683199900843665E-6,0 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark54(88.9887959495646,-1.4002303950915471,0 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark54(89.03111587526335,-0.1659642694200656,0 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark54(89.04252733829492,-1.349266597918728,0 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark54(89.120966546554,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark54(89.12260459305872,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark54(8.913317256579495,-0.08986154427551207,0 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark54(89.15574950842651,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark54(89.15796134939363,-0.8143670034120074,0 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark54(89.17108348795884,-1.499999999999945,0 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark54(89.20482082065332,-0.24823618234623623,0 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark54(8.920768295619942,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark54(8.924266926617749,-2.461788228664162E-8,0 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark54(89.2669638916417,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark54(89.27783616791935,-0.7455551525828246,0 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark54(89.28549170480352,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark54(89.29292449769336,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark54(89.30797995066223,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark54(89.34788101475237,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark54(89.3626836011934,-0.07376448774779229,0 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark54(89.38334223883501,-1.01703719801651,0 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark54(89.40945540466555,-1.266395012080153,0 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark54(89.43162711469229,-1.2666196143502177,0 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark54(89.43995836732785,-0.8336584978178134,0 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark54(89.48131332370619,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark54(89.48866917750244,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark54(89.49769548701232,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark54(89.53955176453309,-0.9638039691190841,0 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark54(89.54645170830598,-0.9562191773402944,0 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark54(89.54952156111014,-0.8596393948272949,0 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark54(89.55784901062643,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark54(89.57881785955341,-1.4176376413923442,0 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark54(89.58897330695832,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark54(89.58979723092074,-1.4999999999999813,0 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark54(89.59912021320324,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark54(89.61487368232201,-0.03579923673003221,0 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark54(89.65658536837299,-1.0865690719607737,0 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark54(89.70942521264213,-1.277841349946425E-8,0 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark54(89.71188374279546,-0.42166151131061724,0 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark54(89.7175200033098,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark54(89.7410899293518,-0.21753346524715975,0 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark54(89.74685693973206,-0.48955954510186483,0 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark54(89.78409579647627,-0.33850107769781346,0 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark54(89.85010043085637,-1.3269774194366208,0 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark54(89.87060981992909,-0.2788474920093762,0 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark54(89.91510894056265,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark54(8.995251466798818,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark54(8.996112477359118,-0.6812360980807679,0 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark54(89.97831381734414,-0.09650641713308789,0 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark54(89.99347377405866,-1.2008799135313426,0 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark54(90.04194681528168,-0.4111121402582114,0 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark54(90.0928324402539,-2.6218010382582898E-5,0 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark54(90.11178641174902,-1.1744801151194428,0 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark54(90.17331397741805,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark54(90.22386024628102,-0.22813086560523765,0 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark54(-90.22897365824466,-0.7017697108237424,-0.28451929452148583 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark54(90.29838891253303,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark54(90.33732480690223,-1.3877787807814457E-17,0 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark54(90.3714307750944,-0.41374872739449264,0 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark54(90.38669431982464,-1.3113504232660147,0 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark54(9.044877508078654,-0.74191890069994,0 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark54(90.46658878468702,-0.6075426153620578,0 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark54(90.52501250372096,-0.08265389493823605,0 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark54(90.5549204103329,-1.4775139839746139,0 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark54(90.5570307995552,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark54(90.56501728575617,-0.0491770342851901,0 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark54(90.5994098099989,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark54(90.60212788194386,-1.2215851772519173,0 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark54(90.62721272801718,-1.1266320239229597,0 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark54(90.6642154180605,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark54(90.702219182319,-1.1526679444507408,0 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark54(90.77244834192385,-0.9812463175272286,0 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark54(9.079231656650805,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark54(90.83020758179396,-1.0459947485562964,0 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark54(90.86833657235579,-0.13156616275226746,0 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark54(90.89778733447167,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark54(90.91721483235293,-1.156768433152358,0 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark54(90.94732075752086,-1.4638878128897184,0 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark54(90.95967971673647,-0.41092229971110594,0 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark54(91.02669740511377,-1.4999999999999742,0 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark54(9.105675910235192,-0.7635174587701341,0 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark54(91.08176003236721,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark54(91.1140237763415,-0.047390959441344,0 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark54(91.12630746291524,-0.8840239868236495,0 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark54(91.13081972703094,-0.24446461236924222,0 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark54(9.113902524445497E-305,-0.07032960460715744,0 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark54(91.15089192107152,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark54(91.1886395680491,-0.6990112345171875,0 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark54(91.213422225257,-1.3044871649882879,0 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark54(91.22625027835934,-0.24142677391387224,0 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark54(91.2503237557001,-0.7677008505992694,0 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark54(91.26313421981092,-0.7134406931814801,0 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark54(91.28014527466343,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark54(91.29944516736046,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark54(9.130634252340613,-0.5867000355430179,0 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark54(91.31542661882199,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark54(91.32498662046106,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark54(91.41323873873421,-1.388960631628971,0 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark54(91.41525014421836,-0.3617335162467157,0 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark54(9.144016166550777,-1.1406356972426086,0 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark54(9.14815770517292,-1.0211436572544446,0 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark54(91.54417090495883,-0.6256679668980905,0 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark54(91.5724144619326,-0.8912109619401253,0 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark54(91.59379199443026,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark54(91.59821881146894,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark54(91.60301202457285,-0.32836679072805053,0 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark54(91.62150805498598,-0.5287265398397523,0 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark54(9.168707201924136,-1.3344146241995691,0 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark54(91.69769818137928,-0.8032115581182595,0 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark54(91.69976206324091,-0.3600519973291223,0 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark54(91.74483097320405,-0.2969406673894145,0 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark54(91.76386000058011,-0.03497803236230368,0 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark54(91.77195007458033,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark54(91.79908488102058,-0.08904221959728886,0 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark54(91.79942522697408,-0.5004698392321849,0 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark54(91.91846622648558,-0.3453157164428851,0 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark54(9.193023196066935,-0.8613111239983525,0 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark54(91.96526089671194,-0.8176609062596714,0 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark54(91.9714109059997,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark54(92.00921458085898,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark54(-92.07331381476675,-1.4999999995068491,0.9034432268030268 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark54(92.1116815918596,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark54(92.20318013259697,-0.7762615535046509,0 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark54(92.24265978955967,-0.35959679067357087,0 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark54(92.30595779298466,-0.969221756727352,0 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark54(92.33318041531018,-0.49409026339381157,0 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark54(92.35732785881366,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark54(92.37796778261313,-0.40688992481816055,0 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark54(92.38120030984854,-0.0037553403805623553,0 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark54(92.41199947617872,-1.4999999999999591,0 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark54(92.41342723443995,-1.3785824429341726,0 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark54(92.41344556741547,-0.7339348957492717,0 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark54(-92.41501679511572,-1.4774249984640124,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark54(92.43608434503466,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark54(9.255383544849828,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark54(92.56014117680894,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark54(92.58396351457506,-0.7395458724539035,0 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark54(92.58707547607764,-0.8347042140359213,0 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark54(92.60451120816319,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark54(92.61272110497669,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark54(9.261613105665674,-0.035358381082602364,0 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark54(92.61767050666302,-0.3846586115339944,0 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark54(92.63080910930695,-0.07842273715932307,0 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark54(92.66131316482094,-0.8660699442508941,0 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark54(92.69495254319544,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark54(92.74800269534964,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark54(92.75057631432554,-1.2498184939638133,0 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark54(92.75654966676322,-0.07969715273401909,0 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark54(92.7911456045326,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark54(92.82201893958559,-0.035236112239005024,0 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark54(92.82585113963603,-0.7585500002935051,0 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark54(9.285789346781439,-1.3849835379772193E-7,0 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark54(92.8691337229703,31.85196272808352,62.430200151046364 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark54(92.88892723187112,-0.6869193085774086,0 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark54(92.90205906083878,-0.7668288826105742,0 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark54(92.90490645910788,-0.11712726228899584,0 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark54(92.90572914887244,-1.4504165897697874,0 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark54(92.97814039326101,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark54(93.01051279420702,-0.8756121664759693,0 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark54(93.05189840695934,-0.7511458349932099,0 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark54(93.07727231451943,-0.946670801211452,0 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark54(93.13977271950554,-1.4999999999999432,0 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark54(93.14264011155612,-0.515221179549826,0 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark54(93.14749069807382,-0.8489904121876402,0 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark54(9.31626413569191,-0.5540413000067765,0 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark54(93.1647743162378,-0.3531395431810981,0 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark54(9.317261450558917,-0.9323369535268142,0 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark54(9.323126599467685,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark54(93.25712669477906,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark54(93.26376414420977,-1.236526808577107,0 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark54(-93.28807880077123,-0.0766423989661339,-96.10522565977048 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark54(93.31829805692969,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark54(93.33261248659349,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark54(9.336941789160095,-1.1458286999129499,0 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark54(93.3734155332618,-0.33003745108632243,0 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark54(9.339294278013284,-0.334888474532141,0 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark54(93.39558250895377,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark54(93.41524429764178,-0.9602387112278308,0 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark54(93.43764553001249,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark54(93.45100297076232,-0.16980907594698147,0 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark54(93.5112513447429,-1.262377379979284,0 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark54(93.51666294093383,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark54(9.363407306408696,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark54(9.365188435037886,-0.6938469599233437,0 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark54(-93.6564127487848,-1.3408025473052216,5.551115123125783E-17 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark54(93.6829601940432,-0.10689826592163731,0 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark54(93.68555960521735,14.38242333569076,53.13560708802038 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark54(9.370656814509944,-1.045216728402888,0 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark54(93.70988016500817,-1.1471998944167443,0 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark54(93.75756618526248,-0.2142015036567685,0 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark54(93.8234306898367,-0.6965548911507646,0 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark54(-93.87328663682395,-1.3098392131285634,-0.8318532222172526 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark54(9.387440922181469,-0.41172233428177174,0 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark54(93.87613973876573,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark54(93.91209180083374,-0.7989182682635771,0 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark54(93.95144033662456,-0.12818444127118178,0 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark54(93.97901802511365,-0.30881730338963376,0 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark54(94.07967664350736,-1.4345517727730055,0 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark54(94.11174721487728,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark54(94.13456983329519,-0.17109565907258328,0 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark54(94.14953219868707,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark54(9.422417598715441,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark54(9.42605943232889,-0.38843202718238956,0 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark54(94.2793898174613,-0.3979338138822617,0 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark54(9.43152355476939,-1.499999999049644,0 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark54(-9.432348300933603,-0.2440809387470324,0.01667118947657719 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark54(94.33438697920562,-1.45083968114518,0 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark54(94.37027724488361,-2.4007747085779275E-9,0 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark54(9.437584323492288,-0.5927271369244919,0 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark54(94.44836744768921,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark54(94.45079910551809,-0.6865915990680271,0 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark54(9.446355084849984,-1.0123351655459394,0 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark54(94.46778918997535,-1.2095612550994725,0 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark54(94.48833440600659,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark54(94.53292470220774,-9.234398230708305E-10,0 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark54(94.6430253332805,-1.0562059085832483E-7,0 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark54(94.69414061182658,-1.0287391352660222,0 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark54(94.69476552513106,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark54(94.7490362556679,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark54(94.75579722748648,-1.337940697024055,0 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark54(94.78459473502221,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark54(94.8055318820083,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark54(94.83460535495786,-0.4940607092960363,0 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark54(94.87202710740468,-1.4999999999997016,0 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark54(94.88633647357494,-0.6104990144058267,0 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark54(9.498774108948083,-0.7632186140394506,0 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark54(95.0135649550885,-1.856965746390078E-9,0 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark54(95.03584171515115,-0.6910673432601442,0 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark54(95.04564904279539,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark54(95.10089455955753,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark54(95.15201659907348,-0.10569527834537595,0 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark54(95.20573352643694,-0.17226548194799096,0 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark54(95.23278186402342,-1.3977737327370516,0 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark54(95.24313910852123,-0.720524113984963,0 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark54(95.28257968096244,-0.8355155007098318,0 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark54(95.31504739359025,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark54(95.31856651675659,-0.9465903928096946,0 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark54(95.33601675096001,-1.0201808382124198,0 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark54(95.35075767108839,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark54(-95.409487035172,65.95163877125756,-58.71045548409977 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark54(9.545877647947492,-0.014089179392243523,0 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark54(95.46943746750316,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark54(95.49583898251936,-0.3235677348078312,0 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark54(95.57410499563161,-0.8276428600127588,0 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark54(95.65285865097337,-0.9389564190312366,0 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark54(95.6566500615302,-1.184048114361829,0 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark54(-95.70311441607893,-0.4931817607664042,-1.2642636098044093 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark54(95.73346495692019,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark54(95.78318514505372,-0.9975869619740263,0 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark54(95.7953687464031,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark54(95.85194572156541,-1.4999999957042338,0 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark54(-95.85383636931238,-2.8533281604105907E-6,-26.22909475353385 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark54(95.86725948280892,-0.19852553568142728,0 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark54(95.95182517430837,-0.35106834621332794,0 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark54(9.596568958082358,-0.5472667645533936,0 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark54(96.03270119391695,-0.16811158972656415,0 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark54(9.605472388325339,-0.3145209060874379,0 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark54(96.06270980498144,-1.18066536325985,0 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark54(96.07595080836236,-0.523714496204061,0 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark54(96.09107267447335,-0.3176025910193232,0 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark54(96.17481055859716,-0.08262252295903849,0 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark54(96.18308962874264,-0.016453510854165576,0 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark54(96.21070500954853,-1.7176354423196325E-17,0 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark54(96.2329310941274,-0.3384659128379308,0 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark54(9.629583005634657,-0.023904227462065997,0 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark54(96.34264316401337,-1.2653674996567235,0 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark54(9.635889479838003,-0.6828483327661012,0 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark54(96.37752663910365,-1.200080606710678,0 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark54(96.38596032614191,-0.4676294000381773,0 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark54(96.39994199164556,-0.4201229560060993,0 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark54(96.43132364213031,-0.9579305308446759,0 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark54(96.4782701596358,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark54(96.48579103934856,-1.3901114848027447,0 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark54(96.49701325553556,-1.3368117167810336,0 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark54(96.52236486485357,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark54(96.5326330639394,-0.6957295915727446,0 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark54(96.53511959419171,-0.022007965047779857,0 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark54(96.54790794318244,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3992() {
    coral.tests.JPFBenchmark.benchmark54(9.654793987746558,-0.70140270425523,0 ) ;
  }

  @Test
  public void test3993() {
    coral.tests.JPFBenchmark.benchmark54(96.58152593635333,-0.6394621375494154,0 ) ;
  }

  @Test
  public void test3994() {
    coral.tests.JPFBenchmark.benchmark54(96.73284829838789,-0.7570469545443075,0 ) ;
  }

  @Test
  public void test3995() {
    coral.tests.JPFBenchmark.benchmark54(9.683813639505104,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3996() {
    coral.tests.JPFBenchmark.benchmark54(96.88812980905647,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test3997() {
    coral.tests.JPFBenchmark.benchmark54(9.689927404391128,-1.388204725643429,0 ) ;
  }

  @Test
  public void test3998() {
    coral.tests.JPFBenchmark.benchmark54(96.90142875353584,-0.8284271625286834,0 ) ;
  }

  @Test
  public void test3999() {
    coral.tests.JPFBenchmark.benchmark54(96.94526738247023,-1.0251138199765597,0 ) ;
  }

  @Test
  public void test4000() {
    coral.tests.JPFBenchmark.benchmark54(97.0357871021028,-0.608895449014188,0 ) ;
  }

  @Test
  public void test4001() {
    coral.tests.JPFBenchmark.benchmark54(9.705326676660391,-6.485792408277865E-10,0 ) ;
  }

  @Test
  public void test4002() {
    coral.tests.JPFBenchmark.benchmark54(97.10807008166898,-1.259238033376107,0 ) ;
  }

  @Test
  public void test4003() {
    coral.tests.JPFBenchmark.benchmark54(-97.15934179576571,-0.29231344431181644,-0.9801980198019802 ) ;
  }

  @Test
  public void test4004() {
    coral.tests.JPFBenchmark.benchmark54(97.18151892174217,-0.8380865943951505,0 ) ;
  }

  @Test
  public void test4005() {
    coral.tests.JPFBenchmark.benchmark54(97.18731977650319,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test4006() {
    coral.tests.JPFBenchmark.benchmark54(97.35861172230213,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4007() {
    coral.tests.JPFBenchmark.benchmark54(97.38151024432824,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test4008() {
    coral.tests.JPFBenchmark.benchmark54(9.738230029756707,-0.5792765582836721,0 ) ;
  }

  @Test
  public void test4009() {
    coral.tests.JPFBenchmark.benchmark54(9.745589500312805E-10,-1.2118912683969754,0 ) ;
  }

  @Test
  public void test4010() {
    coral.tests.JPFBenchmark.benchmark54(97.45806897744632,-0.13593731848298773,0 ) ;
  }

  @Test
  public void test4011() {
    coral.tests.JPFBenchmark.benchmark54(97.48872396604847,-0.024692395926766114,0 ) ;
  }

  @Test
  public void test4012() {
    coral.tests.JPFBenchmark.benchmark54(97.49567620815952,-0.2980527959550727,0 ) ;
  }

  @Test
  public void test4013() {
    coral.tests.JPFBenchmark.benchmark54(97.53585068521511,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test4014() {
    coral.tests.JPFBenchmark.benchmark54(97.57318432077702,-0.22094070039229052,0 ) ;
  }

  @Test
  public void test4015() {
    coral.tests.JPFBenchmark.benchmark54(97.64753624556846,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4016() {
    coral.tests.JPFBenchmark.benchmark54(9.765971673547824,-1.163748819676095,0 ) ;
  }

  @Test
  public void test4017() {
    coral.tests.JPFBenchmark.benchmark54(97.6860986714535,-0.666072749778726,0 ) ;
  }

  @Test
  public void test4018() {
    coral.tests.JPFBenchmark.benchmark54(9.770925234507548,-1.4845758777043747,0 ) ;
  }

  @Test
  public void test4019() {
    coral.tests.JPFBenchmark.benchmark54(97.71918696574195,-1.0889032674215673,0 ) ;
  }

  @Test
  public void test4020() {
    coral.tests.JPFBenchmark.benchmark54(97.75157423016222,-1.2830874912674588,0 ) ;
  }

  @Test
  public void test4021() {
    coral.tests.JPFBenchmark.benchmark54(97.7525687642802,-0.05403246100444263,0 ) ;
  }

  @Test
  public void test4022() {
    coral.tests.JPFBenchmark.benchmark54(97.77882103863413,-0.0676586751064967,0 ) ;
  }

  @Test
  public void test4023() {
    coral.tests.JPFBenchmark.benchmark54(97.7817408429616,-0.5365006089964535,0 ) ;
  }

  @Test
  public void test4024() {
    coral.tests.JPFBenchmark.benchmark54(97.81589836669207,-0.1317851387406268,0 ) ;
  }

  @Test
  public void test4025() {
    coral.tests.JPFBenchmark.benchmark54(97.87451317388121,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4026() {
    coral.tests.JPFBenchmark.benchmark54(97.90563129507893,-0.9450946408233669,0 ) ;
  }

  @Test
  public void test4027() {
    coral.tests.JPFBenchmark.benchmark54(-97.91326437147698,-0.8946264525860279,-1.0 ) ;
  }

  @Test
  public void test4028() {
    coral.tests.JPFBenchmark.benchmark54(97.95167556452148,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test4029() {
    coral.tests.JPFBenchmark.benchmark54(97.95643581496694,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test4030() {
    coral.tests.JPFBenchmark.benchmark54(-98.06631202768058,-5.551115123125783E-17,1.0 ) ;
  }

  @Test
  public void test4031() {
    coral.tests.JPFBenchmark.benchmark54(98.11107783593894,-1.1236920838484974,0 ) ;
  }

  @Test
  public void test4032() {
    coral.tests.JPFBenchmark.benchmark54(98.20009534729607,-0.20679002509097089,0 ) ;
  }

  @Test
  public void test4033() {
    coral.tests.JPFBenchmark.benchmark54(98.23396597429118,-0.7402799000410922,0 ) ;
  }

  @Test
  public void test4034() {
    coral.tests.JPFBenchmark.benchmark54(98.27718850126732,-0.0712830623865024,0 ) ;
  }

  @Test
  public void test4035() {
    coral.tests.JPFBenchmark.benchmark54(98.30173420226483,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4036() {
    coral.tests.JPFBenchmark.benchmark54(98.34621959946924,-0.1684430372910839,0 ) ;
  }

  @Test
  public void test4037() {
    coral.tests.JPFBenchmark.benchmark54(98.3729429111294,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test4038() {
    coral.tests.JPFBenchmark.benchmark54(98.37594743040904,-0.8754444179613845,0 ) ;
  }

  @Test
  public void test4039() {
    coral.tests.JPFBenchmark.benchmark54(9.83774046390213,-1.2168916447422369,0 ) ;
  }

  @Test
  public void test4040() {
    coral.tests.JPFBenchmark.benchmark54(98.42563266721231,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4041() {
    coral.tests.JPFBenchmark.benchmark54(9.842686438632876,-0.5816278204311658,0 ) ;
  }

  @Test
  public void test4042() {
    coral.tests.JPFBenchmark.benchmark54(98.472411089634,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4043() {
    coral.tests.JPFBenchmark.benchmark54(98.49483562100676,-0.9792487897969187,0 ) ;
  }

  @Test
  public void test4044() {
    coral.tests.JPFBenchmark.benchmark54(98.50763815112307,-1.4387865131410038,0 ) ;
  }

  @Test
  public void test4045() {
    coral.tests.JPFBenchmark.benchmark54(98.52967857150745,-0.925654588837336,0 ) ;
  }

  @Test
  public void test4046() {
    coral.tests.JPFBenchmark.benchmark54(9.855263142385738,-0.014493296599520755,0 ) ;
  }

  @Test
  public void test4047() {
    coral.tests.JPFBenchmark.benchmark54(98.56366078495918,-0.6723032069872517,0 ) ;
  }

  @Test
  public void test4048() {
    coral.tests.JPFBenchmark.benchmark54(98.58122666984602,-1.0046197911627814,0 ) ;
  }

  @Test
  public void test4049() {
    coral.tests.JPFBenchmark.benchmark54(98.61207875960011,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test4050() {
    coral.tests.JPFBenchmark.benchmark54(98.62909824150597,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4051() {
    coral.tests.JPFBenchmark.benchmark54(98.64994414929805,-1.2258760253364915,0 ) ;
  }

  @Test
  public void test4052() {
    coral.tests.JPFBenchmark.benchmark54(98.67369818305741,-0.12727705426868852,0 ) ;
  }

  @Test
  public void test4053() {
    coral.tests.JPFBenchmark.benchmark54(98.73642664513902,-0.06453022184949475,0 ) ;
  }

  @Test
  public void test4054() {
    coral.tests.JPFBenchmark.benchmark54(98.80462234753416,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4055() {
    coral.tests.JPFBenchmark.benchmark54(9.880628777894955,-0.4710993420455054,0 ) ;
  }

  @Test
  public void test4056() {
    coral.tests.JPFBenchmark.benchmark54(9.893171740591661,-0.3534221183867885,0 ) ;
  }

  @Test
  public void test4057() {
    coral.tests.JPFBenchmark.benchmark54(98.94847846264261,-0.51181812558514,0 ) ;
  }

  @Test
  public void test4058() {
    coral.tests.JPFBenchmark.benchmark54(98.95014687695212,-1.1916808991153722,0 ) ;
  }

  @Test
  public void test4059() {
    coral.tests.JPFBenchmark.benchmark54(98.98465515119847,-0.6620595640379099,0 ) ;
  }

  @Test
  public void test4060() {
    coral.tests.JPFBenchmark.benchmark54(9.90079517360004,-0.27721580960222036,0 ) ;
  }

  @Test
  public void test4061() {
    coral.tests.JPFBenchmark.benchmark54(9.901507734908758,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test4062() {
    coral.tests.JPFBenchmark.benchmark54(99.04379756549756,-0.8111917678241554,0 ) ;
  }

  @Test
  public void test4063() {
    coral.tests.JPFBenchmark.benchmark54(99.05056547516547,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4064() {
    coral.tests.JPFBenchmark.benchmark54(99.07019655314068,-0.446755825416993,0 ) ;
  }

  @Test
  public void test4065() {
    coral.tests.JPFBenchmark.benchmark54(99.08391268264606,-1.2988458190090437,0 ) ;
  }

  @Test
  public void test4066() {
    coral.tests.JPFBenchmark.benchmark54(99.164589198985,-0.40847353758874405,0 ) ;
  }

  @Test
  public void test4067() {
    coral.tests.JPFBenchmark.benchmark54(99.18025411083181,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4068() {
    coral.tests.JPFBenchmark.benchmark54(99.18029779503203,-0.5571927088705887,0 ) ;
  }

  @Test
  public void test4069() {
    coral.tests.JPFBenchmark.benchmark54(99.21626581599047,-0.6725289626099458,0 ) ;
  }

  @Test
  public void test4070() {
    coral.tests.JPFBenchmark.benchmark54(99.24081058499289,-0.5306338691769537,0 ) ;
  }

  @Test
  public void test4071() {
    coral.tests.JPFBenchmark.benchmark54(9.92522084279652,-0.08519095810216881,0 ) ;
  }

  @Test
  public void test4072() {
    coral.tests.JPFBenchmark.benchmark54(99.26041877348385,-0.9375937054292838,0 ) ;
  }

  @Test
  public void test4073() {
    coral.tests.JPFBenchmark.benchmark54(99.26617414679188,-1.1393176616953724,0 ) ;
  }

  @Test
  public void test4074() {
    coral.tests.JPFBenchmark.benchmark54(99.34512035043971,-1.1247125894717391,0 ) ;
  }

  @Test
  public void test4075() {
    coral.tests.JPFBenchmark.benchmark54(9.94035269693984,-1.4925997936303617,0 ) ;
  }

  @Test
  public void test4076() {
    coral.tests.JPFBenchmark.benchmark54(9.940743164263605,-1.0582937409804796,0 ) ;
  }

  @Test
  public void test4077() {
    coral.tests.JPFBenchmark.benchmark54(99.40851821956636,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test4078() {
    coral.tests.JPFBenchmark.benchmark54(99.4386082125801,-0.5909610949320534,0 ) ;
  }

  @Test
  public void test4079() {
    coral.tests.JPFBenchmark.benchmark54(99.47410081012248,-0.2692796595519103,0 ) ;
  }

  @Test
  public void test4080() {
    coral.tests.JPFBenchmark.benchmark54(-99.48604090775268,-2.220446049250313E-16,0.9578874848893738 ) ;
  }

  @Test
  public void test4081() {
    coral.tests.JPFBenchmark.benchmark54(99.49719548671743,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4082() {
    coral.tests.JPFBenchmark.benchmark54(99.56963726177142,-0.8221663650598359,0 ) ;
  }

  @Test
  public void test4083() {
    coral.tests.JPFBenchmark.benchmark54(99.61655837629974,-0.5589431098359139,0 ) ;
  }

  @Test
  public void test4084() {
    coral.tests.JPFBenchmark.benchmark54(99.62359140414898,-0.41539004942832286,0 ) ;
  }

  @Test
  public void test4085() {
    coral.tests.JPFBenchmark.benchmark54(99.6280901739157,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test4086() {
    coral.tests.JPFBenchmark.benchmark54(9.963593728032343,-0.04544306241793761,0 ) ;
  }

  @Test
  public void test4087() {
    coral.tests.JPFBenchmark.benchmark54(99.64231060120775,-1.1361361176924931,0 ) ;
  }

  @Test
  public void test4088() {
    coral.tests.JPFBenchmark.benchmark54(9.970486708590556,-1.0464295350629595E-8,0 ) ;
  }

  @Test
  public void test4089() {
    coral.tests.JPFBenchmark.benchmark54(-9.970713673670103,-0.5482465405419568,-2.4120542009041728 ) ;
  }

  @Test
  public void test4090() {
    coral.tests.JPFBenchmark.benchmark54(99.72854572513509,-0.928188665914325,0 ) ;
  }

  @Test
  public void test4091() {
    coral.tests.JPFBenchmark.benchmark54(99.73667002748273,-8.719794801338511E-8,0 ) ;
  }

  @Test
  public void test4092() {
    coral.tests.JPFBenchmark.benchmark54(99.748563997748,-1.283520926561721,0 ) ;
  }

  @Test
  public void test4093() {
    coral.tests.JPFBenchmark.benchmark54(99.75242947339532,-0.8687229526429325,0 ) ;
  }

  @Test
  public void test4094() {
    coral.tests.JPFBenchmark.benchmark54(99.75565519118982,-1.4469348356659628,0 ) ;
  }

  @Test
  public void test4095() {
    coral.tests.JPFBenchmark.benchmark54(-99.82617192502633,-0.05937079434531442,0.0 ) ;
  }

  @Test
  public void test4096() {
    coral.tests.JPFBenchmark.benchmark54(99.85679057991055,-1.4207891422166115,0 ) ;
  }

  @Test
  public void test4097() {
    coral.tests.JPFBenchmark.benchmark54(99.94587972739814,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test4098() {
    coral.tests.JPFBenchmark.benchmark54(99.96951102696832,-0.24784097485321865,0 ) ;
  }

  @Test
  public void test4099() {
    coral.tests.JPFBenchmark.benchmark54(99.99106699051441,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test4100() {
//    	UnSolved;
  }
}
