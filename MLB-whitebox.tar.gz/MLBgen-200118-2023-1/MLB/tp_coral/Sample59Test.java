import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-0.009079106842070996,-1.7456738402035619,0.6622576876015852,-4.725575910976889 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0,0,0.3620892721043075,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-100.0,-100.0,0.2607565906266158,-4.3148973846372485 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-100.0,-100.0,-4.186525379768151,0.19866839862609392 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-100.0,-100.0,-48.30956086217862,0.02084803951156188 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(0.0,100.0,-3.704755067277995,0.11595387755758413,-13.445307218592461 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-100.0,-51.81366600278856,-13.24107303186004,0.10031063927641176 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-100.0,-64.1382216972525,-1.0112369770624174,-2.130417195381774 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-10.792003444951462,-81.99941114857508,58.48963641244947 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-11.74219360426629,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-12.218973569612658,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-131.58340333945793,-98.6451760798221,0.02612097928190351,-20.00725636840011 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-13.331673961788542,-64.86362374513769,0.02497126172154951,-19.249640018431798 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-16.943573615698536,-0.19738685463005368,0.01728714513515553,-16.11921454388748 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-1.7597694303893562E-8,-40.10461549734363,3.469446951953614E-18,-19.91386617863003 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.931166754381934,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-19.445697597366184,-2.279853812778981,2.7755575615628914E-17,-7.322988274968769 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-1.9636373861190906E-90,-99.99999999999541,-26.463328752876073,1.5687744168720557E-10 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-2039.2042376863521,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-20.586799685449556,-45.6635409472357,-7.713458031673741,0.20364359543342658 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-21.137794741078082,-13.234988406055365,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark59(0,0,2.378961827668519,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-23.877037610121537,-77.12649707392339,-26.42509898460819,0.029413852694269826 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark59(0,0,24.07806644415001,9.289553711685201,82.250005307653 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-24.251247698583747,-60.905752728557026,-4.169912264202668,0.3766521692889079 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-2.465190328815662E-32,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-2625.915913729282,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-27.871505617872458,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark59(0,0,29.184148659194477,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-29.484861106428028,3.1554436208840472E-30,-0.004899504332646634 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark59(0,-0.31132392637039175,-52.074185574424845,-48.77710632922572,0.03220355705794509 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-36.081734481558094,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-36.11656445342706,-100.0,-1.0045964463661212,-2.2620096605886966 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-36.69401284531912,0.031068457215949224,-50.55919950825613 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-37.58267028039475,11.557196767095277,-82.82748929960273 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-39.0853701080079,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-41.35785467309566,-100.0,-13.725577792297244,2.0961010704922955E-13 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-41.59637094247448,-20.642707265661777,-4.15763556999574,0.3778100077194839 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-47.95662448376818,85.11902125835803,-80.01544205097025 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-49.722168563075996,-5.63319274346525,-66.48252813568064,9.447231605889203E-5 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-51.049255456050254,-31.31494357146153,-35.9764638625321,0.043661776565840076 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-52.38690396026109,-47.608807190500364,-41.67117187494934,0.03769503606732627 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-53.24303286754073,26.30022248088197,72.12349397794353 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-54.84216546934763,-37.05179470347002,-41.9714595721877,0.030951715220123382 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-56.27714915945781,-19.81982178724047,0.0718448879548409,-19.197544444238897 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-5.64809371253525,-8.406410329668997,-15.944747416514396,9.055821720798017E-14 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-65.59709051660599,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-65.81010925259578,72.2965282061298,-46.378965967794564 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-65.87101369549515,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-67.29308049082576,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-70.84864552932173,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark59(0.0,72.66083235252526,-13.982079109857892,-69.79789642318026,0.022504923605019655 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-78.92605196883694,9.733588819431218E-209,-1.2154326714572538E-63 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark59(0,0.7948682386858575,-23.033876556247055,6.784848998367864,-8.336452762205509 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-80.17493785582008,-16.216041371385813,23.275073850724382 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-81.42625969266919,59.5389025421446,-65.96724767187465 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-8.161285830316857,-6.4798521173910615,-46.009523938026334 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-8.198539559211554,-13.348158868034133,0.0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-83.71200052352681,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-86.24451363350917,-1172.998832434106,1441.6468798427709 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-86.94311260499,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-88.48315430610612,-54.87376598821938,9.42661787303247 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-90.09199401861214,68.15277994013985,-47.17655886613284 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-91.30428837257796,0,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-9.295589889340206,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-95.76694217484413,-78.58936807780967,1.1656221175468508E-40,-50.750923245375425 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-97.03878219800013,1387.6298194409576,-1177.8340330735368 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark59(0,0,9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-99.79277142585434,-7.993509828740471,-7.765738816517361,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-100.0,0.006597708097922039,-35.70318343408192 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-100.0,-0.6496144551400924,0.6496144551400906 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-100.0,-1.54335054373423,0.1118384857152609 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-100.0,-1.8437892854770563,0.34378928547705645 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-100.0,-2.2328553754437803,0.6620590486488835 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-17.725283869454454,0.05005846229825117,-4.717703648921223 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-1.7763568394002505E-15,-0.40966801880679504,0.4096680003292118 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-19.46463587856617,-6.770216505035791,0.05287995068884355 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-49.479843964859334,-1.918423906858746,0.8187952210035476 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-6.38303808565959,-16.26895340640789,0.02764360753366399 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-70.2926011522951,0.3317332215496607,-1.8317332215496607 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark59(0,11.578050544837687,-69.84787277109251,1.7961861295641777,-1.796186129564178 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark59(0,123.4141635865176,-0.014226770378023557,0.16078963392145953,-1.6607195798688645 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark59(0,14.102227582512768,-1.3378404061155704,8.881784197001252E-16,-65.71136205834648 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark59(0,-14.510931343030798,-41.43748500073538,-2.12439247267541,0.5535961458805154 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark59(0,-14.605873484849923,-77.94858969864136,-84.48102654107194,-51.454466009621356 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark59(0,14.807370629875123,-61.336072342155326,8.881784197001252E-16,-32.75004868576576 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark59(0,20.774419864246802,-22.284545630998764,-0.8304585616851463,0.8304585616851463 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark59(0,-23.105606854777363,-37.87358209980201,4.440892098500626E-16,-10.382298340295023 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark59(0,-23.154605247056367,-25.62482639413497,-0.5166660735740294,-1.0541302532208672 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark59(0,24.60164860592499,-99.33348043679716,-136.25872306283532,0.011486950934949437 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark59(0,-2.7755575615628914E-17,-89.78523245426798,-6.292314533981137,4.791989732674386 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark59(0,29.760530119694177,-53.07538409718554,-2.041588890737357,0.4707925639424607 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark59(0,-33.497457117635676,85.61902408595446,59.81241270124323,-14.317206015334946 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark59(0,-37.05479708669633,-21.42516086854191,0.001174100955523094,-939.1349873987975 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark59(0,37.37552822840121,-3.8413368616820946,-13.089647704761916,0.12000294906511044 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark59(0,47.15020064815551,-21.7694955851002,-1.9904403600738851,0.4196440332789885 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark59(0,49.12992246064163,-25.368928452261414,2.465190328815662E-32,-1.4998881166257527 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark59(0,51.95456383570678,-16.853998720324828,6.938893903907228E-18,-28.682403057086717 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark59(0,52.431157889817,-40.04616198735458,-2.050583416256726,0.7652933023315427 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark59(0,-54.64335936945013,-47.8657440253206,26.989984816135745,-9.769962616701378E-15 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark59(0,-56.97637119590084,-45.329354568427114,0.037721243699331886,-41.642219946812574 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark59(0,60.75525912607961,-49.71385520978062,-34.50853058581946,0.04551907311406511 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark59(0,-61.41000570425132,-75.55795777341154,-3.729623083783646,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark59(0,62.93117459152913,-74.25427978476003,-59.44558748621542,0.026424103002752553 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark59(0,67.90532857085338,-36.376321703008415,0.06045063176341259,-25.984779331050028 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark59(0,68.87923538629505,-100.0,-2.126747925938732,1.5622913528533553 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark59(0,-71.47291574459143,-5.125023362025132,1.7763568394002505E-15,-39.122656652598664 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark59(0,72.14353855442224,-77.68089691588598,-1.8881776168731221,0.3173812900782256 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark59(0,73.62385860323974,-75.07552480224737,-0.33454568765079173,4.695311835657364 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark59(0,75.61266851144885,-25.71981384364463,-0.7132890063186181,4.440892098500626E-16 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark59(0,83.3329665810941,-19.934800069988185,0.33719163647336003,-0.3371916364733636 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark59(0,-8.964051438711863,-86.68985519024147,1.2820979697597323,-2.852894296554629 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark59(0,95.14296161371846,-49.57821380942311,0.020533792075766544,-46.7637302940108 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark59(0,96.75200531096746,-45.73581222500848,3.5585455799674617,-5.058545579967461 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark59(0,-99.45398248795289,-99.87808542703554,-2.122270292562709,0.622270292562709 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark59(0,-99.69117881142863,-98.57821418363153,-3.468059712264493,1.968059712264493 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark59(0,-99.92319754725337,-21.051239497679468,0.014693402049371612,-1.0773600610023317 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark59(0,-99.9933726172424,-19.27793297646985,-1.6192537275823267,0.11925372758232686 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark59(0,99.99411143647403,-99.89414816194414,0.5074130856033778,-2.0782094123982744 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark59(0,-99.99999999695173,-53.28604887714833,-1.951342614528825,0.45134261452882846 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark59(0,99.99999999992099,-10.443895290957727,-0.022351390512346872,-62.73870535448862 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark59(0,-99.99999999999679,-100.0,-2.162302266684323,0.6623022666843229 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-100.0,-24.528252522235178,-0.35324764567158673,-2.7883543902036205 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-19.969701529538558,-24.819618667836,-15.945625726190508,6.291411590252372E-4 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-44.68646767446641,-78.0924323694598,0.3704961099175945,-4.172162440221885 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark59(-12.86640568627727,85.18350358140626,-6.726357288027216,-4.1678650768673435,0.3768827200077073 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark59(-17.522930818772284,-25.273193183114213,-52.653524413512315,0.1473074917497913,-10.170207023831583 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark59(-18.076151066993212,-63.329583221958906,-35.22796939517825,0.004092591592935069,-47.56871852147222 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark59(-19.076339000181996,-85.515318516824,-46.828678328845335,0.025820300730146073,-60.83570997919991 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark59(-20.610250581208575,78.3321172555346,-100.0,-2.8106037856790778,-0.3309966328868624 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark59(-25.68301312135468,-84.23768780845839,-32.468071382892035,1.256675351214709E-31,-6.874752036893518 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark59(27.453045805011953,-41.988249082280696,69.71473941893785,-48.17419779854926,47.96102868650317 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark59(-30.56863989524759,-60.37884994226661,-68.01664574279386,0.03328925119094511,-31.764287557588183 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark59(-32.58809870127254,100.0,-64.93213963740014,-12.596470232304323,0.01695611413396736 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark59(3.3881317890172014E-21,13.288884884677756,-99.524720537948,-1.6255562807706927,-1.5191604033398027 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark59(-3.6731599670026918,55.03176459188455,-16.71699189892867,-3.032784255860358,-0.40792659959242666 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark59(-37.80328793110179,100.0,-100.0,-41.59013808356511,9.752178925515054E-11 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark59(-38.55554023945718,27.221090744548718,-1.8730954376943316,-6.841008343621707,0.2296145388815347 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark59(39.25367018439733,-1.581181051455281,-36.93606191001242,1.231616618767456E-39,-78.83636588876928 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark59(-40.64711365982274,39.797799730430086,-14.287657568293,0.024538012397187003,-64.01481510969313 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark59(-41.720898672567834,-100.0,-96.36485909575477,0.09419594676883364,-10.382457973690443 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark59(-48.1240238350702,3.07754889708049,-52.05607288441867,4.440892098500626E-16,-15.90919898081087 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark59(-53.29682559451235,-99.04734172128575,-99.57071370855319,-3.7538215670759754,0.3664896518532613 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark59(-54.21481091759878,-86.4453954369961,-95.75873782552792,0.12306450044858723,-12.76400847579147 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark59(-54.76711843715207,10.816445464733224,-46.47562358735337,-4.187421959516776,0.375122531710673 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark59(-60.531138438647645,100.0,-45.66225340701717,-2.8320077927251055,-0.31215676643417584 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark59(-62.26290238392628,-45.052144555828306,-0.03048680704148537,-7.284340715536077,0.15019083362480734 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark59(-6.302391629492849,-77.34916256395103,-18.666846371274268,-3.8041784024654413,1.983954830949633E-15 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark59(-67.2820578482781,-100.0,-27.855899459791804,0.14880025431621569,-10.556408885275046 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark59(-7.386382894228589E-127,100.0,-71.17711559523735,-10.173987006950133,0.15277106841706434 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark59(-75.12176623596675,65.07140878277941,-70.52349628532247,-82.0938665488943,3.1616171228768576E-43 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark59(-76.05899555400279,46.75395875106631,-34.195014724048065,3.552713678800501E-15,-84.89503105875811 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark59(-76.95934138309457,-24.505742051254103,-30.93154906024853,0.007190314881227306,-36.02689340167859 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark59(-83.79541535809423,-96.37388921144543,-43.483859582751386,0.23071197186938264,-6.808473414132891 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark59(85.62237131369116,-79.71950395943144,-5.064061358018861,27.51969408983608,64.44774561043678 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark59(-8.693697233808344,63.50317962923063,-66.19408364024648,-7.952240366904881,0.19752877859830975 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark59(-91.73476825189586,-16.938546231221956,-52.93043592214046,0.21465939603558756,-7.3176151978778625 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark59(-92.05110693892857,100.0,-100.0,-9.924789920165471,7.772910014273576E-33 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark59(94.4548542264775,42.910950260769454,12.097477313038468,-37.99373589142236,28.187984215680643 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark59(95.79865634914847,-67.70934259187305,34.89454299453422,-48.35032957372787,-59.98068966763606 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark59(-97.79805404661272,59.857375473563934,-30.846152057336912,0.06243437798096799,-9.593139019849323 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark59(9.976717734557514,-27.243740622601564,-48.01421561806572,0.11854815503925276,-13.250280666744956 ) ;
  }
}
