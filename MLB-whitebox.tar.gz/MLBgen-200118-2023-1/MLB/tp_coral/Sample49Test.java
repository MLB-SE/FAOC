import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.021717524516988315,1.932234733749019E-5 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(0.03968649399523837,8.303638866792873E-6 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(0.07465231192593111,0.07778747650847324 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(10.96155788148701,39.03844211851299 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(14.970777920060698,55.09465579804066 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(16.056161561417028,56.23052279437519 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(1.7550029277058066E-9,4.1892754920665014E-5 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(18.428211717058073,21.43067051207756 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(21.72703296858481,91.31224955858917 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark49(2.3297474447866876E-4,2.7797832582248917E-5 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark49(2.499252502875081,5.249485507217747 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark49(2.7643749082269025E-5,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark49(-2.9429694035273954E-37,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark49(-32.47799276210084,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark49(3.329451309442197,5.428895460401082 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark49(3.594346329044649,5.562925886959158 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark49(36.1787834190894,97.44738240927978 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark49(4.204786952358736E-9,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark49(42.89330091106473,88.35685440945048 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark49(4.4477762431439784E-38,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark49(-4.528166989595047E-19,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark49(-53.81488878654572,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark49(-5.585473776779428E-9,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark49(62.39788558444462,68.39884876529209 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark49(6.603783616402773E-4,6.8831480460814E-5 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark49(68.28683481428922,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark49(97.64965588056455,28.618831376924163 ) ;
  }
}
