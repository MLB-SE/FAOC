import org.junit.Test;

public class Sample29Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark29(-0.5670299144951798 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark29(-13.217443754604517 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark29(13.418000497722105 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark29(-14.415004113395753 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark29(-1.4638709603065507 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark29(-1.494140625 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark29(-15.007860532733176 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark29(-22.94499589121088 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark29(-25.332423143429224 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark29(-36.73252776761014 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark29(-40.00814420711912 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark29(-40.19108037742779 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark29(-40.19140625 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark29(-47.217213055023244 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark29(51.652155229680886 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark29(55.38022325472264 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark29(58.01961527542397 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark29(-709.169701813011 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark29(-709.1801642193944 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark29(-709.3716563235266 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark29(-709.4408439508682 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark29(-709.5023939937535 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark29(-709.5468271386154 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark29(-709.6832110884566 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark29(-709.707759292931 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark29(-709.8691662038799 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark29(-709.994180400621 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark29(-709.9952947045012 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark29(-709.9973606741075 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark29(-709.999507844877 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark29(-711.377911996554 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark29(-716.803111740184 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark29(-719.4906798701684 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark29(-720.2958428184811 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark29(-725.6327612004476 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark29(72.74319575453276 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark29(-734.4643880046236 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark29(-741.275889837974 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark29(-742.8008032421822 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark29(-745.3631278494752 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark29(-745.4954350934948 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark29(-745.9999999999757 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark29(-745.9999999999974 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark29(-746.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark29(-746.0000000000001 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark29(-746.0000000189196 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark29(-746.1914062500014 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark29(-746.1917219317094 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark29(-754.2464978026796 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark29(756.661260211522 ) ;
  }
}
