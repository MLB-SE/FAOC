import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
//    0.9999999663302725;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(-0.06493243193996534 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(-0.09961502386821053 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark28(-0.18766405647954798 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark28(-0.21108673428831537 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark28(-0.25016518213791983 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark28(-0.2824034026967013 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark28(-0.29940129320871733 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark28(-0.4195472912672926 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark28(-0.4274835832855217 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark28(-0.4725357843603035 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark28(-0.48815013259894613 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark28(-0.5427815642355256 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark28(-0.5573337235055646 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark28(-0.6362629273967855 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark28(-0.647732220132923 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark28(-0.7244218376636127 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark28(-0.7271593499228004 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark28(-0.7686806584811023 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark28(-0.8466966904908872 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark28(-0.8595428303920869 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark28(-0.8731367562576224 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark28(-0.9059769542038225 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark28(-0.9157779990975712 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark28(-0.9214205310386774 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark28(-0.9476189401967758 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark28(-0.9614388934193983 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark28(-0.9849554170457111 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark28(-10.022294812676407 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark28(-10.056094976564196 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark28(-10.057319836138205 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark28(-10.057404662057152 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark28(-10.0984087368672 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark28(-10.139046173227669 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark28(-10.1442530530677 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark28(-10.168681205213701 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark28(-10.176182506025071 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark28(-10.207634104697988 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark28(-10.216998836632541 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark28(-10.222909741880187 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark28(-10.250442146714207 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark28(-10.294710750295337 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark28(-10.317183281470705 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark28(-10.390191920351995 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark28(-10.397967796490093 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark28(-10.442570719579464 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark28(-10.463332548290907 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark28(-10.497830366480173 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark28(-10.581496017824747 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark28(-1.0641644811105806 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark28(-10.833647671848937 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark28(-10.836907570513972 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark28(-10.836915391811957 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark28(-10.837760684982527 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark28(-10.855885681693977 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark28(-10.871055790079026 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark28(-10.907694051517993 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark28(-1.0957809612796439 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark28(-10.977445251398436 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark28(-10.991345462021627 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark28(-11.038506509056447 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark28(-11.064603939533612 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark28(-11.09522269208523 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark28(-11.114419113927767 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark28(-11.135642616222512 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark28(-11.227843659228128 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark28(-11.269791910924923 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark28(-11.31049664779951 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark28(-11.333784413754472 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark28(-11.350007317050228 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark28(-11.360109301379808 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark28(-11.370653854457814 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark28(-11.400992784324842 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark28(-11.402754571631306 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark28(-11.429348227542164 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark28(-11.510669403679728 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark28(-11.520661936034386 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark28(-11.521103748804393 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark28(-11.555597659816513 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark28(-11.63566629919164 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark28(-11.638712083965913 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark28(-1.166433566476428 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark28(-11.706694179343799 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark28(-1.1706729322922058 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark28(-11.720694391553835 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark28(-11.73467686031411 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark28(-1.1741221350856534 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark28(-11.758931628630307 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark28(-11.763147580548264 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark28(-11.773275204074963 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark28(-11.788636178517848 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark28(-11.802835565127864 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark28(-11.81859472870481 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark28(-11.831077361718783 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark28(-11.91161407350343 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark28(-11.917761131519569 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark28(-11.981999495977107 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark28(-12.018410863573408 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark28(-12.030960389404228 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark28(-12.035152494765256 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark28(-12.051336066701367 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark28(-12.060187208747337 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark28(-12.076874223086591 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark28(-12.084482624264098 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark28(-12.117223038057773 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark28(-12.132044283843868 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark28(-12.154501475000302 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark28(-12.304155923134957 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark28(-1.232595164407831E-32 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark28(-12.372838862587116 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark28(-12.376954452831797 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark28(-12.398933779889603 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark28(-1.2404684495131733 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark28(-12.404785216158729 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark28(-1.2448440267812657 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark28(-12.454088142069338 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark28(-1.2462764327113973 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark28(-12.524290738693196 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark28(-12.568183592037599 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark28(-12.60385469117486 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark28(-1.2668601637425354 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark28(-12.717232872606061 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark28(-12.758762341495895 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark28(-12.825661677596784 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark28(-12.837302463255853 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark28(-12.860553779819497 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark28(-12.881068177691901 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark28(-12.896732426345253 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark28(-12.898496033727568 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark28(-13.011162118208546 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark28(-1.3086534201344477 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark28(-13.090894590635102 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark28(-13.233498121246186 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark28(-13.249813854492658 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark28(-13.285964963221957 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark28(-13.383428923069033 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark28(-13.395061590295398 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark28(-13.414802044033252 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark28(-1.3526518318936809 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark28(-13.535530220639828 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark28(-13.592185394069517 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark28(-13.606632932539469 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark28(-13.62611873825081 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark28(-13.666997703539096 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark28(-13.673503414450366 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark28(-13.728621871882282 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark28(-13.869702747177072 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark28(-13.887944127944792 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark28(-13.894419238268014 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark28(-14.001107204126043 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark28(-14.038069382424908 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark28(-14.054538767940159 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark28(-14.056936386672376 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark28(-14.1515027431399 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark28(-14.160120003014384 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark28(-14.161902727361934 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark28(-14.174660827130594 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark28(-14.310699194767665 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark28(-14.325538229991253 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark28(-14.374979150160442 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark28(-14.3901850832127 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark28(-14.46276673151479 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark28(-14.515480646967575 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark28(-14.520830824220383 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark28(-14.525040575039412 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark28(-14.552414198869485 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark28(-1.455838972583635 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark28(-14.583239809728951 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark28(-14.59885295412171 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark28(-1.4611801154616302 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark28(-14.653108999115489 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark28(-14.674672594641194 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark28(-14.675565899323956 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark28(-14.687711604996153 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark28(-14.696769416472264 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark28(-1.4709837044761542 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark28(-14.812955761671432 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark28(-14.827642741801867 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark28(-14.904813739757387 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark28(-14.91125511527487 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark28(-14.95034429673909 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark28(-1.498561039809104 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark28(-15.054116914213836 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark28(-15.069158776224995 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark28(-15.110756192991843 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark28(-15.176907978930345 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark28(-15.191688102979214 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark28(-15.219026893243353 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark28(-15.228732619508591 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark28(-15.28180354695317 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark28(-15.333624647492101 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark28(-15.347561726205655 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark28(-15.375371657967236 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark28(-15.378391268315866 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark28(-15.393312683391613 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark28(-15.40862276295303 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark28(-15.413086188843891 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark28(-15.437104914387945 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark28(-15.450054427438118 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark28(-15.48626934864727 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark28(-15.506962322919776 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark28(-15.54252111427266 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark28(-15.544161101030454 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark28(-15.554699599160514 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark28(-15.62327850483571 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark28(-15.63516504036697 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark28(-15.651338898764891 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark28(-15.6698447072759 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark28(-15.694880590386333 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark28(-15.830399466952699 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark28(-15.867126336040087 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark28(-15.909019372032304 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark28(-15.923404125815921 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark28(-16.044319938272693 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark28(-16.127952018774437 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark28(-1.6129222070497207 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark28(-16.155031996166258 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark28(-16.20942747516665 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark28(-16.227469682630712 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark28(-1.6275605709174812 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark28(-16.314428499394978 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark28(-16.361136697449425 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark28(-16.363149756465603 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark28(-16.532319897893274 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark28(-16.558533004364406 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark28(-16.56736013858415 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark28(-1.6577259922649432 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark28(-16.632219522936566 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark28(-16.646112721429773 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark28(-16.657782818605796 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark28(-16.72026309059092 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark28(-16.726281221833588 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark28(-16.730703728129967 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark28(-16.762634641972568 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark28(-16.841855208689722 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark28(-16.846974897083783 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark28(-16.876104613840326 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark28(-16.900471120108108 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark28(-16.97212709518898 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark28(-16.98817373535222 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark28(-17.099934171350228 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark28(-1.7171015146649609 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark28(-17.21107070591583 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark28(-17.221138439251376 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark28(-17.280683622311543 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark28(-17.363147634840615 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark28(-17.392497903721278 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark28(-17.40525596804443 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark28(-17.406807384250627 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark28(-1.7470869530324222 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark28(-17.486865565296597 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark28(-17.497389105406455 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark28(-17.541817378396303 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark28(-17.561439264525518 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark28(-17.581699972071846 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark28(-17.67006238040048 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark28(-17.713967293397076 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark28(-17.74554071672334 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark28(-17.774240708060802 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark28(-17.800197405576597 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark28(-1.7829216792910216 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark28(-17.833282504333695 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark28(-17.833471654812016 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark28(-17.870129937016884 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark28(-17.87707583174219 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark28(-17.925238129193616 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark28(-17.998897563409358 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark28(-18.00710942874717 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark28(-18.04913383310867 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark28(-18.058173657030423 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark28(-18.064617909881207 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark28(-18.077426578847238 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark28(-18.106296973881754 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark28(-18.10817068543848 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark28(-18.117439248510195 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark28(-1.8122074482361796 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark28(-18.15501784902429 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark28(-18.186906313278726 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark28(-18.24802341646064 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark28(-18.279621961787186 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark28(-18.33382850414526 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark28(-18.347547030651285 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark28(-18.35863314451744 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark28(-18.387653164916088 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark28(-18.41976987248708 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark28(-18.422742078869405 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark28(-18.51900826163812 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark28(-18.560337909188846 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark28(-18.566334141419645 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark28(-18.696464993924565 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark28(-18.72885368178865 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark28(-18.75072038637893 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark28(-18.77192833926729 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark28(-18.77298627382416 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark28(-18.803915794004425 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark28(-18.852026318153634 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark28(-18.92448145223993 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark28(-18.92487215148924 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark28(-18.938240798392926 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark28(-18.95937000955624 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark28(-18.989147738981572 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark28(-18.998788780603192 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark28(-19.062294756079766 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark28(-19.080744431980662 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark28(-19.129117320773915 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark28(-19.13996798188515 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark28(-19.155421264533842 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark28(-19.1595876167423 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark28(-19.22425803153726 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark28(-19.315646716781004 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark28(-1.932144598456503 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark28(-19.34453755514754 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark28(-1.935613606643301 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark28(-19.40752588248 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark28(-1.9511934970163622 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark28(-19.59401219689478 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark28(-19.608489017308827 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark28(-19.610794247688546 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark28(-19.63883763261731 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark28(-19.64266440351612 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark28(-19.66367541427016 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark28(-19.722601128700433 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark28(-19.72699565295997 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark28(-19.757582192149954 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark28(-19.793138764604052 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark28(-19.793441582347356 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark28(-19.817677227134524 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark28(-19.837103553068047 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark28(-20.017920503910915 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark28(-20.020333939456776 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark28(-2.004286563426234 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark28(-20.05521215295221 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark28(-20.064860643414974 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark28(-20.071373633525113 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark28(-20.073367280057667 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark28(-2.0142264824203977 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark28(-20.175028915697666 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark28(-2.0179172259690006 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark28(-20.21775117650222 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark28(2.028675490808965 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark28(-20.291477407614394 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark28(-20.312179757058033 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark28(-20.322448912684592 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark28(-20.351640127127595 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark28(-20.426263350745003 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark28(-20.54902595783487 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark28(-20.56541637390987 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark28(-20.582208356735293 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark28(-20.619887677169885 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark28(-20.64666954549159 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark28(-20.68860948305678 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark28(20.725092647627122 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark28(-20.78444123899041 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark28(-20.809360765259527 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark28(-20.85982628860785 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark28(-20.87230065199573 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark28(-20.883284016286723 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark28(-20.89059422624007 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark28(-20.907464859593958 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark28(-2.0937179364276517 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark28(-20.9495601699671 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark28(-20.962375404844266 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark28(-2.0997658678985687 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark28(-2.1048082149094824 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark28(-21.05534020177832 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark28(-21.087303708326772 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark28(-21.15502937967193 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark28(-21.189757626294025 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark28(-21.266300201876916 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark28(-21.29738721124623 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark28(-21.30530235615997 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark28(-21.363259352310692 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark28(-21.408159876165357 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark28(-21.431794719598685 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark28(-21.472989686145766 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark28(-21.495993165848205 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark28(-21.56079438595806 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark28(-21.572777604977716 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark28(-21.581519718395327 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark28(-21.58845789077506 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark28(-21.59798607021 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark28(-21.663498541248714 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark28(-21.667962400247134 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark28(-2.1706717239273985 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark28(-21.72343799616523 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark28(-21.795587406696143 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark28(-21.797176314235628 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark28(-21.80177314419514 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark28(-21.82295084176735 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark28(-21.837582780143165 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark28(-21.856158554912966 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark28(-21.881982138596 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark28(-2.188476447034816 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark28(-21.933121672388722 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark28(-21.959295175008748 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark28(-21.974995516000135 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark28(-22.050242384010673 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark28(-22.08621442444918 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark28(-22.10238732840277 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark28(-22.140115000034385 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark28(-22.141973917105148 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark28(-2.21511499793867 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark28(-22.159102110202866 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark28(-22.189290612670476 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark28(-22.21025533527967 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark28(-2.2378206044735265 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark28(-22.399738230955364 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark28(-22.41090335079005 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark28(-22.4275032073933 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark28(-22.485622346539813 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark28(-22.494065513874745 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark28(-22.550735486785484 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark28(-22.560847042351213 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark28(-22.595023448153412 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark28(-22.597461710348156 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark28(-22.602496810197707 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark28(-22.608711783135433 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark28(-22.643640314088458 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark28(-22.657446051752103 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark28(-22.66037762579552 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark28(-22.702071711036822 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark28(-22.70419436417461 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark28(-22.74641408495907 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark28(-22.75028449586118 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark28(-22.75514707974584 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark28(-22.82580654661635 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark28(-22.8388393254576 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark28(-22.850906743858772 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark28(-22.904329895788436 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark28(-22.90734441326667 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark28(-22.91140175777626 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark28(-22.919062662466345 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark28(-22.967147119269768 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark28(-22.974564794270464 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark28(-23.003988234986622 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark28(-23.082897449721074 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark28(-23.132385288113895 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark28(-23.145180262738748 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark28(-23.184813032638445 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark28(-23.200251670691927 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark28(-23.24213431570361 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark28(-23.246364616638644 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark28(-2.3258020895723206 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark28(-23.273672627455966 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark28(-2.3274447095754596 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark28(-23.300000113298452 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark28(-23.340746966294603 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark28(-23.358048373893553 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark28(-23.363457726603215 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark28(-2.3378767251358568 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark28(-23.39172551874202 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark28(-23.394435454577916 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark28(-23.44538219551606 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark28(-23.480177172911027 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark28(-23.4842038437628 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark28(-23.502140847037566 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark28(-23.513201665413106 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark28(-23.51663850435874 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark28(-23.530473310528023 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark28(-23.563813582335456 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark28(-23.630089771319746 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark28(-23.637198843889934 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark28(-23.653102342694794 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark28(-23.687986839584468 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark28(-23.705209656908835 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark28(-23.76831900791055 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark28(-23.795382983381685 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark28(-23.829986839767002 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark28(-2.387048607188575 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark28(-23.877717953638225 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark28(-23.88853900802775 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark28(-23.919365026018653 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark28(-23.931844580483983 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark28(-23.937655005618723 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark28(-23.966617452894013 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark28(-23.996051361335063 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark28(-24.01183456671106 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark28(-24.024275662457157 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark28(-24.066656746502858 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark28(-24.073049526945752 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark28(-24.078994671473254 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark28(-24.122871723775916 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark28(-24.165521825416846 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark28(-24.168928640063527 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark28(-24.177834706945077 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark28(-24.17943140645542 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark28(-24.204107168252875 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark28(-24.26927151351967 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark28(-24.324102686615646 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark28(-24.324790643788475 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark28(-24.335293048977775 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark28(-24.401461810003838 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark28(-24.47479469455496 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark28(-24.53991301953829 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark28(-24.564518915150074 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark28(-24.569079669946305 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark28(-2.4570533779300945 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark28(-24.5824049173371 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark28(-24.583512868392262 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark28(-24.601151143141365 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark28(-24.68634831163898 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark28(-24.710961728933853 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark28(-24.719703478373603 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark28(-24.7344938168859 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark28(-24.750740617053353 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark28(-24.763559521093327 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark28(-24.80460465647414 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark28(-24.860969700174195 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark28(-24.887757584835327 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark28(-24.957960241584388 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark28(-24.966313856314628 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark28(-25.046038515077157 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark28(-25.081969538071533 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark28(-25.10873808250267 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark28(-25.14645285912944 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark28(-25.162319190636524 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark28(-25.19781161465437 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark28(-25.212470357784795 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark28(-25.214972782762814 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark28(-25.224202729151088 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark28(-2.5246454252389583 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark28(-25.249342151673645 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark28(-25.268190930242994 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark28(-2.535766258632094 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark28(-25.36716857765076 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark28(-2.5448811004189054 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark28(-25.526140348362475 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark28(-25.55547870208457 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark28(-25.58081267996512 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark28(-25.642309682543868 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark28(-25.66450662788688 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark28(-25.66573727932861 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark28(-25.66616683413588 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark28(-25.68549860749792 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark28(-25.68788609187041 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark28(-25.69461970418456 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark28(-25.70536498697544 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark28(-25.767831812853558 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark28(-2.577539793051969 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark28(-25.778718785725175 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark28(-2.5804470833658826 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark28(-25.812072529537147 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark28(-25.840390186026156 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark28(-25.84425623826219 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark28(-2.586794497360117 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark28(-25.870712079661473 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark28(-2.593691800835373 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark28(-25.941414509738593 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark28(-25.949277220164603 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark28(-26.009316873978918 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark28(-26.025103265654764 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark28(-26.03817659304069 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark28(-26.05498242731548 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark28(-26.09990719083308 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark28(-2.611513053370132 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark28(-26.1228008287365 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark28(-26.13402599037309 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark28(-2.633564341522529 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark28(-26.418021454182977 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark28(-26.44089043583506 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark28(-26.455514212098635 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark28(-2.6461782376105276 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark28(-26.46543224843805 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark28(-26.480310521481158 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark28(-26.491156631546488 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark28(-26.50129711131757 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark28(-26.60405116148719 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark28(-26.626902396209417 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark28(-26.644013529841956 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark28(-26.645704136190474 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark28(-26.663575507225914 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark28(-26.71053029048585 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark28(-26.713305119857694 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark28(-26.71455557310138 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark28(-26.76361151613797 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark28(-26.769972827102578 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark28(-26.86398535262353 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark28(-26.865002491197913 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark28(-26.87227309573288 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark28(-26.885693289879 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark28(-26.88908560238484 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark28(-26.91479090881481 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark28(-26.934629240135365 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark28(-2.6948215173948853 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark28(-26.966800141746745 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark28(-26.976067613108512 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark28(-27.009568631927166 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark28(-27.03276314332625 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark28(-27.039060037005086 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark28(-27.05740427595518 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark28(-27.064276954798558 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark28(-27.073387930665945 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark28(-27.09250666211696 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark28(-27.109723280298198 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark28(-27.121036652879283 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark28(-27.121806121675164 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark28(-27.15443176001719 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark28(-27.160804121756783 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark28(-2.720924357174013 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark28(-27.255448749610608 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark28(-2.733949720791486 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark28(-27.380605314372076 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark28(-27.40752762027465 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark28(-27.41725604313399 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark28(-27.431951161218436 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark28(-27.439961516023544 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark28(-27.445093992379824 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark28(-27.498184074254723 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark28(-27.543998098904396 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark28(-27.610562024441847 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark28(-27.64216663613621 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark28(-27.698497473485602 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark28(-27.741955324281165 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark28(-27.761161835943653 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark28(-27.77270093817073 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark28(-27.773003108112505 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark28(-27.778126607887074 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark28(-27.803238777999468 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark28(-27.845010470204883 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark28(-27.904322961089917 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark28(-27.968042805086128 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark28(-2.8202513816888626 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark28(-28.240310367968632 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark28(-28.294835112226878 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark28(-28.31631952215021 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark28(-28.33353707363402 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark28(-28.387894848842052 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark28(-28.416947240368316 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark28(-28.45475803827911 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark28(-2.855241078698299 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark28(-28.553610087400187 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark28(-28.558745688856433 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark28(-28.6100645972911 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark28(-28.6476081569689 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark28(-28.650768518491603 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark28(-28.665326714712293 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark28(-28.671133405688565 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark28(-28.70590775451464 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark28(-28.759161318938965 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark28(-28.77123195244539 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark28(-28.812604922550506 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark28(-28.857347327416846 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark28(-28.921880724085042 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark28(-28.92954699262718 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark28(-28.930382230562685 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark28(-28.93523784386751 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark28(-28.941184704139758 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark28(-28.964856604736283 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark28(-2.900374355166562 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark28(-29.0235260660791 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark28(-29.079775725177058 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark28(-29.103659292520945 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark28(-29.122168565825078 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark28(-29.14799387706688 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark28(-29.20058110072155 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark28(-29.247248648112787 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark28(-29.248589534753535 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark28(-29.252319062835383 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark28(-29.264220019021806 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark28(-29.32231250054744 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark28(-2.9360615970138753 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark28(-29.369992824494105 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark28(-29.390160851929963 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark28(-2.9411913852487572 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark28(-29.439715119225667 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark28(-29.45079876666408 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark28(-29.456737759275015 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark28(-29.48492867359296 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark28(-29.48971823327109 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark28(-2.9522358763810246 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark28(-29.593328681189107 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark28(-29.625195179863823 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark28(-29.63452576658156 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark28(-29.670748430904737 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark28(-29.726795502452703 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark28(-29.727764584317455 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark28(-29.73424534616977 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark28(-29.797370156823604 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark28(-29.854848344808758 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark28(-29.869542912321222 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark28(-29.886583654855528 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark28(-29.927777827275094 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark28(-29.972552218939313 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark28(-29.986675175368063 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark28(-30.043014615643074 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark28(-30.066685772085847 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark28(-30.091372206402852 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark28(-30.12791104501416 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark28(-30.17300519927106 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark28(-30.1732046395733 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark28(-30.19124102392807 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark28(-30.206605632932096 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark28(-30.222799151798725 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark28(-30.22628371526872 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark28(-30.30188940323694 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark28(-30.304500647995525 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark28(-30.325931519032594 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark28(-3.0403546345105354 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark28(-30.406762211375238 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark28(-30.48506469300216 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark28(-30.636071224296344 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark28(-30.639115409341855 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark28(-30.679168214523315 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark28(-30.686023394821788 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark28(-30.777262883495254 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark28(-30.790854059783484 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark28(-30.86239786147229 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark28(-30.869208363658345 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark28(-30.907182208482922 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark28(-30.91589375145611 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark28(-30.935268722735174 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark28(-30.936027678496686 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark28(-30.94863018446661 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark28(-31.125885783340323 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark28(-31.141261407237437 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark28(-31.143874335428976 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark28(-31.214409338453677 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark28(-3.1258554455326504 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark28(-31.29742313440292 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark28(-31.32782931973665 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark28(-31.388408195931675 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark28(-31.415768825829787 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark28(-31.420472474485067 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark28(-31.422764755885808 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark28(-31.496241350845338 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark28(-31.511467244501134 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark28(-31.545519021694474 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark28(-31.569906604286928 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark28(-31.5869475316848 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark28(-31.595301625365295 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark28(-31.72108115333768 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark28(-31.731980891874173 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark28(-31.87785267191383 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark28(-32.06129579421409 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark28(-32.06176621239803 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark28(-32.10774351751246 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark28(-32.11428607636388 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark28(-32.142824144917114 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark28(-32.16141628578177 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark28(-32.177838985449455 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark28(-32.28848745520337 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark28(-32.31135538935483 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark28(-32.34485912341532 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark28(-32.42403190042941 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark28(-32.42615142271458 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark28(-32.43901140318685 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark28(-32.46206355862056 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark28(-32.47211835284598 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark28(-32.4819791350631 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark28(-32.5055462069368 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark28(-32.511687115224916 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark28(-32.51898367515619 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark28(-32.559761608679565 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark28(-32.61648726104511 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark28(-32.62469817426425 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark28(-32.6481733665847 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark28(-32.64873170755409 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark28(-32.66780328829681 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark28(-32.67977156233624 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark28(-32.68293265939437 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark28(-32.702013279271384 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark28(-32.71210048299416 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark28(-32.7191247253818 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark28(-32.760721128233854 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark28(-3.27714890499999 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark28(-32.795448352619076 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark28(-32.79993393814719 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark28(-32.82644992918698 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark28(-32.82987741954216 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark28(-32.838904270500265 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark28(-32.89636362483306 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark28(-32.9689439910984 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark28(-33.055567045362096 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark28(-33.05680349505158 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark28(-33.07700744467128 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark28(-33.09158216925066 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark28(-3.31061674674838 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark28(-33.117296871831 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark28(-33.12461263109121 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark28(-33.1307149220203 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark28(-33.160905927514904 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark28(-33.16761517082651 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark28(-3.3168162715157052 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark28(-33.17709147367066 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark28(-33.22637492009264 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark28(-33.22866215918758 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark28(-33.24653226975644 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark28(-33.31008764526706 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark28(-3.33913062524816 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark28(-33.4283500657518 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark28(-33.45154814864786 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark28(-3.3462926729403932 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark28(-33.658497255003 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark28(-33.67384139894685 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark28(-33.68748779990504 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark28(-33.689978149808695 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark28(-33.77150054648304 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark28(-33.83269855981112 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark28(-33.87953107960686 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark28(-33.905228737662995 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark28(-33.947797795852665 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark28(-33.99442451684891 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark28(-34.002681859395395 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark28(-34.04504175758409 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark28(-34.186941550187115 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark28(-34.22888493821428 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark28(-34.26723325022947 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark28(-34.28118287908417 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark28(-34.31909659516546 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark28(-34.36189884356739 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark28(-34.43389775150243 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark28(-34.434733586829395 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark28(-34.56668711645246 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark28(-34.64133213276756 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark28(-34.70178624156976 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark28(-34.72109212668852 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark28(-34.73966597163454 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark28(-34.74566507767027 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark28(-34.76460667360621 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark28(-34.82565282145667 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark28(-34.83096596115077 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark28(-34.900980594480146 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark28(-34.91242582975815 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark28(-34.915015823958726 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark28(-34.95132782129788 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark28(-34.970938564605206 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark28(-34.9831822415624 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark28(-34.99274390700762 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark28(-34.99809256467982 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark28(-35.02127386420766 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark28(-35.02822850669132 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark28(-35.12196975514624 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark28(-35.14399558042798 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark28(-35.21605869850764 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark28(-35.221740221809455 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark28(-35.25131150212894 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark28(-35.25441288761118 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark28(-35.261508936896504 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark28(-35.26209031491496 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark28(-35.35343563065727 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark28(-35.37389076150288 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark28(-35.423866833441224 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark28(-35.55387450940857 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark28(-35.600395026012066 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark28(-35.65052536478231 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark28(-35.74213619642248 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark28(-35.77112130774087 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark28(-35.82598058223276 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark28(-35.843006996531315 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark28(-35.90000260605348 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark28(-35.91561013507662 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark28(-35.93373649680831 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark28(-35.97353723441334 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark28(-3.5989868728716345 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark28(-36.015654593827406 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark28(-36.05164297098571 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark28(-36.05507673621362 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark28(-3.605729519288687 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark28(-3.606612547488197 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark28(-36.108030714149294 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark28(-36.14015961838064 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark28(-36.23574128028866 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark28(-36.2448942301981 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark28(-36.26078795224868 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark28(-36.31326144843452 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark28(-36.318250810691445 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark28(-36.38503140650222 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark28(-36.397268770110244 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark28(-36.41487114924939 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark28(-36.49127988125167 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark28(-36.50284930649019 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark28(-36.504035111668955 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark28(-36.52349691688996 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark28(-36.532962997698526 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark28(-36.5554782553968 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark28(-36.575691728038784 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark28(-36.585319396559754 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark28(-36.59597505731198 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark28(-36.620642431578055 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark28(-36.65571891443591 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark28(-36.66834634084779 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark28(-36.69171953036494 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark28(-36.70236311447817 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark28(-36.71837324751663 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark28(-36.78760036760198 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark28(-36.80175422619325 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark28(-36.810774065864834 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark28(-36.82665766621962 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark28(-36.88102526005039 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark28(-36.94254766489466 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark28(-36.96859303818516 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark28(-36.98755214119325 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark28(-36.988385336882644 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark28(-37.00754466672331 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark28(-37.03049955119124 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark28(-37.0799520905031 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark28(-37.28483400657343 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark28(-37.30970500203177 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark28(-37.309979027990714 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark28(-37.319723024564325 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark28(-37.3925523346923 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark28(-37.41664972246912 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark28(-37.430740421567336 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark28(-37.454366571869244 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark28(-37.50932364827653 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark28(-37.53784753014142 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark28(-37.53823580446456 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark28(-37.556738019975676 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark28(-37.561318306856094 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark28(-37.6123382138045 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark28(-37.634144404000544 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark28(-37.64849873808886 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark28(-3.7652036797183825 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark28(-37.662452687606816 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark28(-37.6634216698484 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark28(-37.71450283065816 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark28(-37.73458580327726 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark28(-37.73506266800719 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark28(-37.757877772593204 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark28(-3.776012165842957 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark28(-37.795811139674186 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark28(-37.82579752806478 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark28(-37.867181792067804 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark28(-37.87286774097423 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark28(-3.792687347178486 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark28(-37.947226223639085 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark28(-37.97506497063268 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark28(-38.0566665697188 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark28(-38.07925913001351 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark28(-38.083289465629335 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark28(-38.155787391115226 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark28(-38.16333851586471 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark28(-38.16702805222896 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark28(-38.167567182737415 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark28(-38.175185307603044 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark28(-38.18650997136941 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark28(-38.325144455086324 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark28(-38.34544772812818 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark28(-38.350012695090506 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark28(-38.35942342169354 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark28(-38.405528499332945 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark28(-38.41026701331103 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark28(-38.4110286640692 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark28(-38.431479185628525 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark28(-38.469216790867435 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark28(-38.498587676794635 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark28(-38.50414694279161 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark28(-38.57424492629078 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark28(-3.857967459049533 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark28(-38.58772056720543 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark28(-38.6103507513585 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark28(-38.654620100593085 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark28(-38.68404836041175 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark28(-38.69834433440018 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark28(-38.70473177417368 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark28(-38.716982631077634 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark28(-38.728885293761614 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark28(-38.91277712341814 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark28(-38.97574777587953 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark28(-38.980461954137446 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark28(-39.02460874589093 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark28(-39.092420278173634 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark28(-39.10032164854906 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark28(-39.134373189613505 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark28(-39.1436815554971 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark28(-39.17382789322059 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark28(-39.20530604020767 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark28(-39.225216292245335 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark28(-39.24818612443883 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark28(-3.9268854273339713 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark28(-39.30609137704748 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark28(-39.325389092664565 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark28(-39.33848957504962 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark28(-39.359513560939206 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark28(-39.362871816525 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark28(-39.39523512383274 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark28(-39.56239351231004 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark28(-39.5765079595694 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark28(-39.66425024638276 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark28(-39.67138391606228 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark28(-3.9676762170770132 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark28(-39.67798425302078 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark28(-3.9680788203129964 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark28(-39.72656443507927 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark28(-39.749717098586615 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark28(-39.81218396952932 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark28(-39.856853128762395 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark28(-39.92385797168056 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark28(-3.9966354270802924 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark28(-39.97277922030336 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark28(-40.00302020387074 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark28(-40.03483681593247 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark28(-40.09066583558143 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark28(-40.12983127141994 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark28(-40.27272826820201 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark28(-40.336137110169105 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark28(-40.34407006579119 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark28(-40.41412282114407 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark28(-40.44078950292287 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark28(-40.450976524624394 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark28(-40.47403154166274 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark28(-40.48043707382752 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark28(-40.52713144079474 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark28(-40.55394555291456 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark28(-4.057614609577342 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark28(-40.57687713390561 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark28(-40.58060763774787 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark28(-40.58809719041956 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark28(-40.68180302220301 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark28(-40.808467947609614 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark28(-40.82086930089082 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark28(-40.8325845541406 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark28(-40.86274604713003 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark28(-40.88924489244184 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark28(-40.89416160649151 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark28(-40.93360086300408 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark28(-40.94893685520966 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark28(-40.957252606429215 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark28(-40.975448764217326 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark28(-41.00611619479588 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark28(-41.05749213315535 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark28(-41.067234139481876 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark28(-41.07006800164401 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark28(-41.07052375115465 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark28(-41.108808585761025 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark28(-41.14970067743826 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark28(-41.16829460688729 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark28(-41.19387230261864 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark28(-41.30422175743895 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark28(-41.31732082938873 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark28(-41.32319550470229 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark28(-41.37027124318116 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark28(-41.404620726611995 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark28(-41.46292121104871 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark28(-4.146947077606498 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark28(-41.47505468575356 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark28(-41.476303428344366 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark28(-41.48078936132615 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark28(-41.52183142144437 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark28(-41.57395029783289 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark28(-41.574176758496975 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark28(-41.61362823902608 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark28(-41.61454566585729 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark28(-41.65886503061116 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark28(-41.690348716638546 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark28(-41.722464587202325 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark28(-41.767326901935654 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark28(-41.838965701598774 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark28(-41.946784168344095 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark28(-41.95205992226898 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark28(-42.0093162213733 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark28(-42.06489940488698 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark28(-42.07056538562841 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark28(-4.207068258415944 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark28(-42.075368198976705 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark28(-42.09746810458883 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark28(-42.11057895733978 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark28(-42.230070686164424 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark28(-42.26365348716581 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark28(-42.300195190025306 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark28(-42.34673229339994 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark28(-42.361391720592344 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark28(-42.495430682524436 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark28(-42.54327238845504 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark28(-42.586968710679244 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark28(-42.6461920084285 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark28(-42.68622702956404 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark28(-42.73431017742071 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark28(-42.75695422426185 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark28(-42.78091917505322 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark28(-42.78872832367202 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark28(-42.79876295531562 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark28(-42.83457505764736 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark28(-42.88688930682702 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark28(-42.97527975785729 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark28(-43.0226655769041 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark28(-43.13350002785135 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark28(-43.161075189959575 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark28(-43.1774107880756 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark28(-43.23553553388828 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark28(-43.30337350642479 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark28(-43.31859632436761 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark28(-43.3936354365285 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark28(-43.429046416563196 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark28(-43.42942309033195 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark28(-43.44593852204073 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark28(-43.46913490961799 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark28(-4.353170499917169 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark28(-43.54770428023029 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark28(-43.61371711037649 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark28(-43.63739359378413 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark28(-4.364773887481448 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark28(-43.65123001045945 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark28(-4.365378607881553 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark28(-43.691601423834015 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark28(-43.705904389812474 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark28(-43.79245256433997 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark28(-43.80665569962603 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark28(-43.83448227685558 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark28(-43.84442790750705 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark28(-43.86134855886803 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark28(-43.935277909949846 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark28(-43.967561433949776 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark28(-44.00200504432128 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark28(-44.00708761448857 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark28(-44.080782322205266 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark28(-44.11769826531786 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark28(-44.18985374770035 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark28(-44.19525069262973 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark28(-4.428506492722107 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark28(-44.405023143080705 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark28(-44.4246897605195 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark28(-44.43248334776826 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark28(-44.44101694719351 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark28(-4.446431869528595 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark28(-44.46709383699516 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark28(-44.47199956823713 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark28(-44.50187232741267 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark28(-44.51630019846009 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark28(-44.52487818028301 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark28(-44.569543745431226 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark28(-4.457057923739157 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark28(-44.58020727525336 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark28(-44.582241688347324 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark28(-44.590669711036846 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark28(-44.5947114215536 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark28(-4.46489222712907 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark28(-44.670381248328404 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark28(-44.70832892487875 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark28(-4.473721536856303 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark28(-44.761288456130856 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark28(44.82432528740733 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark28(-44.842445508166826 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark28(-44.86848085467263 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark28(-44.88726789384303 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark28(-44.93622872310355 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark28(-4.494267850067786 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark28(-44.95782293693627 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark28(-45.01767004900952 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark28(-45.03430831207362 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark28(-45.041686555715565 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark28(-45.066663396939234 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark28(-45.12234706024909 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark28(-45.126370382028625 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark28(-4.513943285863959 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark28(-45.197246685704464 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark28(-45.25885770832802 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark28(-45.28992271741985 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark28(-4.530457494035417 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark28(-4.536152469749837 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark28(-45.414156394833704 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark28(-45.44526267471463 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark28(-45.49858001492129 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark28(-45.5280691554161 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark28(-45.62578784455849 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark28(-45.6768813433535 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark28(-45.70390927102517 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark28(-45.70926889366458 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark28(-45.75101522999938 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark28(-45.752088670021074 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark28(-4.579194512740159 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark28(-45.79514492444239 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark28(-45.80686105438847 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark28(-45.88026003810779 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark28(-45.88640061183939 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark28(-45.88967480863333 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark28(-45.94504840677423 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark28(-45.946756360987706 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark28(-45.970761545424125 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark28(-46.012455488315204 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark28(-46.02269035511961 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark28(-46.02387125553384 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark28(-46.03551279456577 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark28(-46.08117653145214 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark28(-46.08203204016805 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark28(-46.1418154263838 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark28(-46.14564952944129 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark28(-46.254011837845525 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark28(-46.27591853827988 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark28(-46.27857162878033 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark28(-46.30048455725435 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark28(-46.344179088343715 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark28(-46.36438830732781 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark28(-4.638621460882831 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark28(-46.48226036887999 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark28(-46.487771891974326 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark28(-4.650706684421252 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark28(-46.60491363217345 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark28(-46.62314503391993 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark28(-46.67085140696139 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark28(-46.702925576818764 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark28(-46.73745459169558 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark28(-46.761156837438065 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark28(-4.681467073399233 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark28(-46.90731188060926 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark28(-46.92158407454063 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark28(-46.94926189256847 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark28(-46.95714598229086 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark28(-47.0068647780268 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark28(-4.702850419747961 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark28(-47.0797859756025 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark28(-47.09030933988188 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark28(-47.14163286105904 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark28(-47.157355965085124 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark28(-47.26828678603088 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark28(-47.27207755266125 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark28(-47.282168051083694 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark28(-47.32659278102116 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark28(-47.367446447955764 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark28(-47.39479802572299 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark28(-47.436236303138735 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark28(-47.45470697746932 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark28(-47.455229538237845 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark28(-47.49580207578441 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark28(-47.50544659881566 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark28(-47.56519998608471 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark28(-4.7589099547897575 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark28(-47.604693607414994 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark28(-47.606177353931336 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark28(-47.61402791971692 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark28(-47.70006985018404 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark28(-47.71273677454033 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark28(-47.713676171629984 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark28(-47.76499843850559 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark28(-47.76697314135292 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark28(-47.80270269143425 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark28(-47.827673646307154 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark28(-47.92546493980523 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark28(-4.795258049442964 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark28(-47.994607339519455 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark28(-48.04231399877024 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark28(-48.058673628172286 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark28(-48.09310521377701 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark28(-48.09734398321153 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark28(-4.809872953498811 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark28(-4.811099735210988 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark28(-48.1330996102896 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark28(-48.13348702481972 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark28(-48.21836514048103 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark28(-48.32447701470903 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark28(-48.38350277487391 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark28(-48.40258943902111 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark28(-48.40654099596704 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark28(-48.48787728125361 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark28(-48.564267672237804 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark28(-48.565471462367626 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark28(-48.654858198212466 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark28(-48.73441790397868 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark28(-48.76016947799546 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark28(-48.855779771189844 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark28(-48.901946241768826 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark28(-48.91384535786327 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark28(-48.96104998752235 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark28(-49.02329492707238 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark28(-49.02937992062175 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark28(-49.03172213711604 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark28(-49.12183340317766 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark28(-49.17794041370005 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark28(-49.197662727647675 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark28(-49.20860609747917 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark28(-49.269993657691025 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark28(-49.27144394870646 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark28(-49.295746707071466 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark28(4.930380657631324E-32 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark28(-49.30747080097262 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark28(-49.350713095374175 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark28(-49.40393568653456 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark28(-49.419387136818656 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark28(-4.943330842164045 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark28(-49.48862400208709 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark28(-49.524728548528344 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark28(-49.54866458717944 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark28(-49.56615859603926 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark28(-49.57164841923169 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark28(-4.959778658004879 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark28(-49.63175386047731 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark28(-4.964297571226695 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark28(-49.64796628249213 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark28(-4.965133485439097 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark28(-49.66652544694021 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark28(-49.672852789211966 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark28(-4.971060764167177 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark28(-49.71269819532671 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark28(-49.76633840976381 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark28(-49.83533679527421 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark28(-49.840602879297165 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark28(-49.87973733437781 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark28(-49.92972080675313 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark28(-49.94891171554929 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark28(-50.00299925087839 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark28(-5.001259631890235 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark28(-50.015370411571865 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark28(-50.0596696891799 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark28(-50.12231625043888 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark28(-50.188544152552936 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark28(-50.2154225668096 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark28(-50.21921839467276 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark28(-50.251209267660826 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark28(-50.25979544107204 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark28(-50.36061985760804 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark28(-50.383316228631394 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark28(-50.425352260287525 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark28(-50.4279902821642 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark28(-50.500580486470255 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark28(-50.506352964311475 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark28(-50.53411759657844 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark28(-50.56043256014861 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark28(-50.56367545416305 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark28(-5.058149401444908 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark28(-5.059261174689794 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark28(-50.72234429855389 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark28(-50.736519591014954 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark28(-50.78776321209209 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark28(-50.855144111029624 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark28(-50.85697577378119 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark28(-50.92586532314405 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark28(-50.96580235843522 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark28(-50.98490975142842 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark28(-51.00032832856527 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark28(-51.025465009733104 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark28(-51.026074450525584 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark28(-51.06225439957326 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark28(-51.11598038376908 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark28(-51.15579847463436 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark28(-51.19608660376515 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark28(-51.20508824718186 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark28(-51.211881215781084 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark28(-5.122272608895216 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark28(-51.22967635383389 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark28(-51.24505252281772 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark28(-51.28702375930823 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark28(-51.300538361762335 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark28(-51.318563258696706 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark28(-51.35156546260278 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark28(-51.382537908895486 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark28(-51.41625178612652 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark28(-51.44063668285484 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark28(-51.44078442285136 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark28(-51.519750443106524 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark28(-51.59972658958174 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark28(-51.677902009067054 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark28(-51.68491830398547 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark28(-5.172311709254629 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark28(-51.76299329481693 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark28(-51.76325280036424 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark28(-51.78052316422548 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark28(-51.79415442464843 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark28(-51.81575891193426 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark28(-51.838245863629574 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark28(-51.90850874307487 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark28(-51.96879007892636 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark28(-52.04166942271486 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark28(-52.04745300886131 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark28(-52.13727887225652 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark28(-52.19268620763364 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark28(-52.229438943504626 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark28(-52.26120955286555 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark28(-52.2773511921302 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark28(-52.283425841427665 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark28(-52.305969147542996 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark28(-52.349055526669865 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark28(-52.40118419192441 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark28(-52.47968851222142 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark28(-52.54591393550165 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark28(-52.56328675062119 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark28(-52.62860140995522 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark28(-52.63366208050033 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark28(-52.65751797760929 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark28(-52.69047106122324 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark28(-52.7025338144264 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark28(-5.2721270062585575 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark28(-52.74880961014337 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark28(-5.276672405489876 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark28(-52.80970211864462 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark28(-52.84159093348117 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark28(-52.84228717709445 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark28(-52.870957424500034 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark28(-52.88993910762818 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark28(-52.91748948042236 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark28(-5.293452657925684 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark28(-52.95903375503419 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark28(-52.96649664960613 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark28(-53.05824381897122 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark28(-53.162485668537585 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark28(-53.175001022971124 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark28(-53.39476469064219 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark28(-53.41579152817337 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark28(-53.564494490074146 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark28(-53.60670526274427 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark28(-53.650717048656475 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark28(-5.371457979323509 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark28(-53.75845750427564 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark28(-53.76927063851189 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark28(-5.37959167052577 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark28(-53.810274079859525 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark28(-53.829560623435846 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark28(-53.91627461047543 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark28(-53.96204572418035 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark28(-54.02358132195555 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark28(-54.033684711550656 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark28(-54.05316185797891 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark28(-54.117417202282915 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark28(-54.15417943230094 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark28(-54.161964962408796 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark28(-54.182892675200534 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark28(-54.186937335667665 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark28(-54.26363500133391 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark28(-54.28420039209543 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark28(-54.289387871359665 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark28(-54.304595818846856 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark28(-54.31261419176998 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark28(-54.3159367786392 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark28(-54.32139106399989 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark28(-54.333163633693694 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark28(-54.35822145729217 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark28(-54.411311092800815 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark28(-54.42859092335905 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark28(-54.519353674426995 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark28(-54.5510873099158 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark28(-54.563126218199606 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark28(-54.60440267235131 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark28(-5.465016097500964 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark28(-54.650392119423174 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark28(-54.68106908636776 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark28(-54.68443269492342 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark28(-54.78044176871979 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark28(-54.80057182722244 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark28(-54.82066627249722 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark28(-54.86164142882155 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark28(-54.86238460636923 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark28(-54.929480456321755 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark28(-54.9424839669975 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark28(-54.94589325582213 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark28(-54.97537588367783 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark28(-55.06781450735821 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark28(-55.10317726594896 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark28(-55.122304834586004 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark28(-5.516886985454732 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark28(-55.18088697747796 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark28(-55.18325222622258 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark28(-55.19295798392463 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark28(-55.19734933788902 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark28(-55.24893771237724 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark28(-55.26009183910197 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark28(-5.535131477917915 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark28(-55.35337567912351 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark28(-55.41413082847222 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark28(-55.45864999353653 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark28(-55.481906217055844 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark28(-55.4835727321519 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark28(-55.50229870064294 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark28(-55.52025973408232 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark28(-55.52804194306964 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark28(-55.55851762274286 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark28(-55.561897446095145 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark28(-5.559028960971176 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark28(-55.62794458757998 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark28(-55.63583421200053 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark28(-55.642419031440895 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark28(-55.654019952371605 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark28(-55.66456584786141 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark28(-55.724656067201565 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark28(-55.791609552255885 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark28(-55.86112700702197 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark28(-55.91468142941467 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark28(-55.91560594516582 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark28(-55.96254635362732 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark28(-56.025197785877666 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark28(-56.05790934762247 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark28(-56.08427160060015 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark28(-56.085732181229496 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark28(-56.121856069158184 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark28(-56.122568390318776 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark28(-56.129867214154515 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark28(-56.161497220064895 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark28(-5.620137179027765 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark28(-56.22310730682101 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark28(-56.22841860631793 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark28(-56.24761249867609 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark28(-56.25254954255854 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark28(-56.30007123242458 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark28(-56.40526536290249 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark28(-56.435317824604425 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark28(-56.43798022519151 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark28(-56.44545735781048 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark28(-56.47076182679582 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark28(-56.52936721729627 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark28(-5.654484735375547 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark28(-56.60693036539932 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark28(-56.71390385088766 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark28(-5.677068805053764 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark28(-56.87927374465494 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark28(-56.89091081496704 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark28(-56.896015212546125 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark28(-56.9476758176219 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark28(-56.99245372223161 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark28(-57.00267105035242 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark28(-57.00593002158683 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark28(-57.01187658297666 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark28(-5.701483204465546 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark28(-57.12111570020353 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark28(-57.20922177070713 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark28(-57.22161335361369 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark28(-5.723552286928182 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark28(-57.239349355651 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark28(-57.24802681851129 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark28(-57.29381198847003 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark28(-57.298591073004566 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark28(-57.30801332394402 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark28(-57.37293602901439 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark28(-57.389807487843655 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark28(-57.39054019140828 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark28(-57.40886671996399 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark28(-57.413205130575705 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark28(-57.450984834342165 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark28(-57.50164493610272 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark28(-57.502023871599526 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark28(-57.54125987329659 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark28(-57.55045057520742 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark28(-57.5874726916588 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark28(-57.625544215424405 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark28(-57.62911486047864 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark28(-57.63802897874195 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark28(-57.64078073654697 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark28(-57.714282025674436 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark28(-57.732811936741555 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark28(-5.773443374049194 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark28(-57.7390904154609 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark28(-57.74800907255164 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark28(-57.801343803018426 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark28(-57.85948601395086 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark28(-57.92930017226738 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark28(-57.967110022836586 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark28(-57.97969769795179 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark28(-58.02739878834782 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark28(-58.05659424708944 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark28(-58.083505162913454 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark28(-58.09229745880542 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark28(-58.10645230723112 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark28(-5.812688374818293 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark28(-58.192831872905955 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark28(-58.20178064745474 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark28(-58.234805982726655 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark28(-58.24286945499117 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark28(-5.82655447841212 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark28(-58.293305902339945 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark28(-5.829337523467032 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark28(-58.312570138125544 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark28(-5.832591233758251 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark28(-58.36908698640562 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark28(-58.432704288067704 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark28(-5.8454981113492295 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark28(-58.468348973400495 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark28(-58.56843915503078 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark28(-58.654823464114216 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark28(-58.65891386493598 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark28(-58.66591661162774 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark28(-5.867175888234925 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark28(-58.70712855896305 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark28(-58.736576138397844 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark28(-58.74871471357635 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark28(-58.7819574507769 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark28(-58.85754756947714 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark28(-58.925407518272266 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark28(-58.928115467352995 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark28(-58.95556731755038 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark28(-58.99072745179481 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark28(-58.999734855779586 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark28(-59.07659047209868 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark28(-59.11665730612088 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark28(-5.914185243802407 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark28(-59.168809756464725 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark28(-59.28089795937097 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark28(-59.31456933798949 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark28(-59.36705511202782 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark28(-59.40895868412277 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark28(-59.442796710944414 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark28(-59.46038055399612 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark28(-59.52170272072581 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark28(-59.53261877252456 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark28(-59.5485687191212 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark28(-59.57067338377793 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark28(-59.627101722726 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark28(-59.672909528245995 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark28(-59.697498481268376 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark28(-5.972671835023817 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark28(-5.975730381911774 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark28(-59.78883851736463 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark28(-59.82253516841078 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark28(-59.85921783961279 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark28(-59.879118846859036 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark28(-59.881595235977784 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark28(-59.88397665030063 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark28(-59.891911015692266 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark28(-59.93163617201136 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark28(-59.991069767947614 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark28(-60.03330045540973 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark28(-60.090858389575644 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark28(-60.10432921017708 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark28(-60.16596087652246 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark28(-60.203206782821894 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark28(-60.307241427258695 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark28(-60.31670512172156 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark28(-60.31681110976614 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark28(-60.32734490511611 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark28(-60.35969998137634 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark28(-60.37143880751885 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark28(-60.39059785350436 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark28(-60.47189279526468 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark28(-6.048478141860485 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark28(-60.49987626265554 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark28(-60.54069391927932 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark28(-60.541619777605945 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark28(-60.54257981043023 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark28(-60.54515242773832 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark28(-60.56843791180475 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark28(-60.591176031076934 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark28(-60.62491308428408 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark28(-60.62938317416353 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark28(-60.69809432921911 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark28(-60.72645345993235 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark28(-60.72943313533072 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark28(-60.77490426099688 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark28(-60.79251823494651 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark28(-60.79853600714673 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark28(-60.821227888640415 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark28(-60.8424751527602 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark28(-60.86177465883773 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark28(-60.8740387910447 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark28(-60.95393844800865 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark28(-60.98615346462677 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark28(-61.06262285398423 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark28(-61.07930653901445 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark28(-61.122285337309656 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark28(-61.173302592602965 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark28(-61.2429102096129 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark28(-61.254990165144974 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark28(-61.36830108039864 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark28(-61.380190089560635 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark28(-61.38691259814 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark28(-61.398777198591816 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark28(-61.404397993815294 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark28(-61.434567197227196 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark28(-61.45244960135774 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark28(-61.46601369826441 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark28(-61.48096129481115 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark28(-61.48164545006403 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark28(-6.162591533949069 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark28(-61.707576905611575 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark28(-61.713622316727346 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark28(-61.73324400824638 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark28(-6.178043851616181 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark28(-61.801310303204396 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark28(-61.92016396649957 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark28(-61.97224686509026 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark28(-61.987968166238105 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark28(-61.99502940617301 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark28(-6.201226931902994 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark28(-62.04030013886008 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark28(-6.211971988456284 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark28(-62.151996452792616 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark28(-62.18607922346884 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark28(-62.18639900156118 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark28(-6.21886723999468 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark28(-62.25997707926374 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark28(-62.26073005875763 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark28(-62.27031163246784 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark28(-62.28163153517612 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark28(-62.33841644953089 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark28(-62.338879147815376 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark28(-62.34436944348503 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark28(-62.350741770325556 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark28(-62.35200273919514 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark28(-6.249488736752667 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark28(-62.50899852335794 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark28(-62.536940703588485 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark28(-62.55897833016184 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark28(-6.258449260845907 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark28(-62.60040811228473 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark28(-6.26494306321446 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark28(-6.26971661032492 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark28(-6.269838591140896 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark28(-62.77928366376408 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark28(-62.78019187843387 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark28(-62.844653658686546 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark28(-62.859523916052005 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark28(-62.886779206660684 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark28(-62.921535221284586 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark28(-62.94512146603102 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark28(-6.296114676384846 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark28(-6.2965866055731965 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark28(-63.01193614726917 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark28(-63.03963298819233 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark28(-63.07339100255582 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark28(-63.088560537847414 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark28(-63.10993114959737 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark28(-63.11484600739581 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark28(-63.149166734096276 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark28(-63.17870657416702 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark28(-63.22842380060993 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark28(-63.32068479401245 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark28(-63.355891456761945 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark28(-63.360054418950625 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark28(-63.3636198276992 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark28(-63.364863046710916 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark28(-63.37440326896624 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark28(-63.3876752794444 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark28(-63.42365466660092 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark28(-63.43660759264387 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark28(-63.46766038039073 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark28(-63.50658896246743 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark28(-63.51709738284734 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark28(-63.52529429786693 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark28(-63.54577919379951 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark28(-63.58382405861924 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark28(-63.5990779094135 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark28(-63.61656773311473 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark28(-63.66092182069194 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark28(-63.664167135341934 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark28(-63.67389595338959 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark28(-63.705041693013854 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark28(-63.71909205601083 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark28(-63.72241353885062 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark28(-63.757811470440394 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark28(-63.84124040938257 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark28(-63.84343141258202 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark28(-63.95800466358597 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark28(-63.97044027106708 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark28(-64.01759488369696 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark28(-64.05417972796288 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark28(-64.09011458531265 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark28(-64.09782611190357 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark28(-64.19634682574684 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark28(-64.23017464540254 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark28(-64.26697217462345 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark28(-64.3001380817466 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark28(-64.30044669000262 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark28(-64.40386484755783 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark28(-64.4070635115946 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark28(-64.42861970418636 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark28(-64.43966724525183 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark28(-64.43994414470654 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark28(-64.4523151692593 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark28(-64.48258260965409 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark28(-6.449406366763526 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark28(-64.50181636513236 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark28(-64.53208827315396 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark28(-64.55126684326042 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark28(-64.58920707913566 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark28(-6.471977132944787 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark28(-64.73960303556798 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark28(-64.76854830669066 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark28(-64.77820849974552 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark28(-64.80815515190577 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark28(-64.83538944707007 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark28(-64.86958433668536 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark28(-64.87048062087963 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark28(-64.88203700838292 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark28(-64.88448861149152 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark28(-6.4973565589624656 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark28(-65.17841075037119 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark28(-65.19520504810092 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark28(-6.52740303554755 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark28(-65.28340879984118 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark28(-65.28873703192914 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark28(-65.31569988953751 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark28(-65.44439205658514 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark28(-65.53273801591558 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark28(-65.53538480615731 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark28(-65.61507992444702 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark28(-65.65446147616032 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark28(-65.663572441904 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark28(-65.69680409080674 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark28(-6.571172115754379 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark28(-65.73793295269766 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark28(-65.81057217757353 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark28(-65.82234654030405 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark28(-65.85550979556129 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark28(-65.86413119098026 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark28(-65.90005581647537 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark28(-6.590006084981056 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark28(-65.9085745692793 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark28(-65.92830926486434 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark28(-65.93216893961275 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark28(-6.603187760737384 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark28(-66.0815005275507 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark28(-6.611570874485622 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark28(-66.17198345977688 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark28(-66.17989127971626 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark28(-66.22466789163542 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark28(-66.22606547092344 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark28(-66.33420337020172 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark28(-66.36708359033881 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark28(-66.39110180816408 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark28(-66.46902931296836 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark28(-66.52030495852492 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark28(-66.53837643994896 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark28(-66.56237120287909 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark28(-66.57486177035918 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark28(-66.57747287371461 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark28(-66.59226253197738 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark28(-66.6238006184078 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark28(-66.67308322815069 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark28(-66.71946988805925 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark28(-66.74515134119261 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark28(-66.7739650729051 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark28(-66.80822192583729 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark28(-66.93189383385615 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark28(-66.95549611116058 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark28(-67.01047489253881 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark28(-67.01406534907818 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark28(-67.09818704794617 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark28(-67.12172011987172 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark28(-67.12174344698849 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark28(-67.23071251117247 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark28(-67.2318539574559 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark28(-67.32671706353115 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark28(-67.37183227077783 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark28(-67.38135491264174 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark28(-67.38667915466854 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark28(-67.39384818144119 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark28(-67.42055653953192 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark28(-67.44236577882678 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark28(-67.46021540586986 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark28(-67.52593374423171 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark28(-67.54940258171735 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark28(-67.56001974992947 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark28(-6.756354814998119 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark28(-67.6375459651201 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark28(-6.769046555798354 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark28(-67.69783173595403 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark28(-67.73158204284731 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark28(-67.75605282514306 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark28(-67.76962745529245 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark28(-67.87672644737066 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark28(-67.88474766362229 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark28(-67.90143691662094 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark28(-67.91644774355527 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark28(-67.99886947191058 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark28(-68.03692198729419 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark28(-68.09718608073815 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark28(-68.14013707948388 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark28(-68.14898660842472 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark28(-68.22725784198111 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark28(-68.23260857681441 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark28(-68.24186621192223 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark28(-68.2449882307075 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark28(-68.32242867279973 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark28(-68.33260121923661 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark28(-68.3411820439396 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark28(-68.35709700953922 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark28(-68.42227986408523 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark28(-6.846004267860835 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark28(-68.53325389715565 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark28(-68.53429669201347 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark28(-68.54067191276968 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark28(-68.54469855050309 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark28(-68.55087665494032 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark28(-68.59641221652726 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark28(-68.61901070799769 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark28(-68.70323004016905 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark28(-68.71209910260494 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark28(-6.87613620279437 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark28(-68.7756247881423 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark28(-68.78208914848463 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark28(-68.82585356002926 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark28(-68.85045197804311 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark28(-68.87142416923047 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark28(-68.87302657070236 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark28(-68.908917584248 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark28(-68.91544357846047 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark28(-68.96396820455728 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark28(-69.00067811164328 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark28(-69.00426075356962 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark28(-69.01237783484166 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark28(-69.02560540242028 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark28(-6.907046311923011 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark28(-69.07430973044575 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark28(-69.15564019950011 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark28(-69.2138403548472 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark28(-69.2292437184637 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark28(-69.23864520986167 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark28(-69.27503642160286 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark28(-69.28793245745506 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark28(-69.50620815036828 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark28(-6.951119488078049 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark28(-69.59477992100547 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark28(-69.60296937101474 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark28(-69.61423690332025 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark28(-69.6296928445566 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark28(-69.65184955218203 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark28(-69.66631861840588 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark28(-69.67620881954525 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark28(-69.71541889666528 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark28(-6.978465365050738 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark28(-69.78590023593661 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark28(-69.79368847112497 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark28(-69.86548450010105 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark28(-69.91548004559533 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark28(-69.9269175107954 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark28(-69.99285185726265 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark28(-70.01414493790081 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark28(-70.15431567679778 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark28(-7.016074966984775 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark28(-70.16175768686202 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark28(-70.16950217230433 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark28(-70.26942698655262 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark28(-70.28235516999419 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark28(-70.28749417002473 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark28(-70.31427938201963 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark28(-70.34255338031159 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark28(-70.42838398908908 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark28(-70.43326602171899 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark28(-70.44472350851515 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark28(-70.48219296533394 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark28(-70.5420828336025 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark28(-70.63027162816336 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark28(-70.65801139089633 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark28(-70.66000256049762 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark28(-70.68399673632449 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark28(-70.68792865457046 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark28(-70.70638677068231 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark28(-70.77342503701978 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark28(-70.78864207998825 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark28(-70.81032146771838 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark28(-70.82355831424877 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark28(-70.85325710785389 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark28(-70.86273760865456 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark28(-70.87286828282532 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark28(-70.94229048936074 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark28(-7.096056898451721 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark28(-71.0021474345352 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark28(-71.07451857488985 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark28(-71.08561573089517 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark28(-71.08953875643076 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark28(-71.16180274587933 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark28(-7.116378454192301 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark28(-71.17054014868273 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark28(-71.23225949295625 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark28(-7.127472915425415 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark28(-71.28595799374139 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark28(-71.28760821349927 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark28(-71.38284698287478 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark28(-71.39809048174364 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark28(-71.42483783663636 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark28(-71.4394183862045 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark28(-7.169544032927291 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark28(-71.71817441417213 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark28(-71.75618762424823 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark28(-71.76720494719606 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark28(-7.179335027467133 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark28(-7.181409892237795 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark28(-71.81794185976872 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark28(-71.85645658249024 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark28(-71.86066479084117 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark28(-71.92278151419933 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark28(-71.97566707256311 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark28(-72.00629478568416 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark28(-72.05349346407348 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark28(-72.15555115293796 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark28(-7.218596301468793 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark28(-72.19346355254524 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark28(-72.29079621545114 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark28(-72.29924174715221 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark28(-72.30179536025267 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark28(-72.3317390890737 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark28(-7.23378665321124 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark28(-72.34885454945442 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark28(-72.41183096311426 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark28(-72.41856298306936 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark28(-72.42069977416696 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark28(-72.43176341821777 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark28(-72.44843911112291 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark28(-72.54915422608978 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark28(-72.54961985070909 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark28(-72.56838392609843 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark28(-72.57957888434805 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark28(-72.5949747721906 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark28(-72.70415458415545 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark28(-72.73117157626383 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark28(-72.74524216143269 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark28(-72.75784398099674 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark28(-72.77169784513131 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark28(-72.82190373863979 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark28(-72.85059266139785 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark28(-72.92057625475638 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark28(-72.97164318634859 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark28(-73.02267154338027 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark28(-73.06683788282547 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark28(-7.307974573408217 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark28(-73.08209382585858 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark28(-7.3100572558850985 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark28(-73.10475360151815 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark28(-73.17558512286595 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark28(-7.317588018370458 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark28(-7.330537702379175 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark28(-73.343550722144 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark28(-73.36212425830993 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark28(-73.38762731794793 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark28(-73.39603201969753 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark28(-73.39940971926755 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark28(-73.4242188097029 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark28(-73.4840618073807 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark28(-73.52017362305965 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark28(-73.59656539138659 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark28(-7.36012515173536 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark28(-73.6138523229325 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark28(-73.68284342461429 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark28(-73.6868980024018 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark28(-73.71689234336105 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark28(-73.74429615373984 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark28(-73.75377639626235 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark28(-73.77487777536662 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark28(-73.79521878993785 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark28(-73.8440493478553 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark28(-73.86792536985422 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark28(-73.88318759042447 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark28(-73.946197020883 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark28(-73.95235737524328 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark28(-74.00675290053445 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark28(-74.02257312810164 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark28(-74.16743009178619 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark28(-74.27409166432608 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark28(-74.29249874125381 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark28(-7.431810058643023 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark28(-74.34666437522387 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark28(-74.34699067795279 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark28(-74.36437261525697 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark28(-74.46670673137312 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark28(-74.51671584799988 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark28(-74.54178758067025 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark28(-7.45828020549493 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark28(-74.61844602939824 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark28(-74.62076927201693 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark28(-74.64548327511946 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark28(-74.65865854138593 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark28(-74.69202784661697 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark28(-74.75740601383498 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark28(-74.78849267059766 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark28(-7.4829291700593785 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark28(-74.88229431185405 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark28(-74.89953660064417 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark28(-74.94291676434759 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark28(-7.502579465057039 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark28(-75.08406077691714 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark28(-75.09827547719769 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark28(-75.09959666631138 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark28(-75.11154458772013 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark28(-7.522888092053151 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark28(-75.22961099451479 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark28(-75.35285563225278 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark28(-75.35416721866046 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark28(-7.537845476797543 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark28(-75.39400523700826 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark28(-75.42419433034104 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark28(-75.4629338906987 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark28(-7.546508499681053 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark28(-75.47365992221138 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark28(-75.5229708301967 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark28(-75.53803494199971 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark28(-75.55490907182805 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark28(-75.56020179570315 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark28(-7.5585599311644955 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark28(-75.58973129772504 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark28(-75.5907661791746 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark28(-7.559241858102752 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark28(-7.561419270577801 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark28(-75.62856589749288 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark28(-7.563538477604467 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark28(-75.66077479455022 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark28(-75.68012677732452 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark28(-75.70132395166397 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark28(-75.7728039174723 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark28(-7.577533281849625 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark28(-75.78513053541599 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark28(-75.82728222520056 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark28(-75.85975424318221 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark28(-75.88571496920366 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark28(-7.590571015341723 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark28(-75.93817247637517 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark28(-75.98052871991251 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark28(-76.04661467460762 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark28(-76.07313683136493 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark28(-76.21700357421517 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark28(-76.34267408108002 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark28(-76.35851579250743 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark28(-76.38651711184926 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark28(-76.4227678207254 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark28(-76.44348456124641 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark28(-76.4729385276739 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark28(-7.657210530840402 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark28(-76.6116259156579 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark28(-76.61269088555969 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark28(-76.673623164378 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark28(-76.72407677233991 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark28(-76.82622071909759 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark28(-76.83874575517915 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark28(76.87198271389252 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark28(-76.88451759422628 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark28(-76.89080348774107 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark28(-76.9132006277105 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark28(-76.92927952480477 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark28(-76.95465177330503 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark28(-76.95734238913137 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark28(-76.95972055922155 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark28(-7.69806510933806 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark28(-76.99064338518444 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark28(-77.0004697513194 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark28(-77.0295971093371 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark28(-77.03757534187766 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark28(-77.11406234148001 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark28(-77.15128420267345 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark28(-77.23415713410087 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark28(-77.2635174297146 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark28(-77.28769047786861 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark28(-77.29000883670435 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark28(-77.36171050301834 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark28(-77.36664947999623 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark28(-77.37003366890008 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark28(-77.37060063117025 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark28(-77.3756080089085 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark28(-77.38441084252135 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark28(-77.38604121176812 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark28(-77.42187121196642 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark28(-77.42802901572223 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark28(-77.497353132713 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark28(-7.750393764123629 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark28(-77.52730532034269 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark28(-77.54584735734807 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark28(-77.59927883304583 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark28(-77.61013379791287 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark28(-77.62261726743736 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark28(-77.72266280227993 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark28(-77.76374529930057 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark28(-77.83175748871926 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark28(-77.83635555728353 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark28(-77.97942813486556 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark28(-78.05712232706192 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark28(-78.09630495435103 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark28(-78.16254038156794 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark28(-78.17460144169404 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark28(-78.20960422106158 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark28(-78.21927812185672 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark28(-78.28120201366593 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark28(-78.29605638346074 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark28(-78.34959779696422 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark28(-78.50838848679132 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark28(-78.52495521451581 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark28(-78.52976281007575 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark28(-78.55543556628204 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark28(-78.57411388595885 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark28(-78.58752148665566 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark28(-78.60951361244008 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark28(-78.62571543410435 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark28(-78.63191981230739 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark28(-78.64294227906436 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark28(-78.67147734024329 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark28(-78.68141679447285 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark28(-78.7119482321233 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark28(-78.72517396484952 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark28(-78.79369305309268 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark28(-7.884836736132186 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark28(-78.87011716482147 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark28(-7.890863775430674 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark28(-78.99310226816307 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark28(-79.0209474464138 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark28(-79.04022974362404 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark28(-79.07577766306756 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark28(-79.07965536482197 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark28(-79.08892646627244 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark28(-79.16659666464365 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark28(-79.17530139778268 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark28(-79.18402876025677 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark28(-79.22163635021029 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark28(-79.22945732979917 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark28(-79.32140174065678 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark28(-79.37989719320683 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark28(-79.39614894589391 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark28(-79.40429971038776 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark28(-79.42961954470317 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark28(-79.44726048272055 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark28(-79.46013559720832 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark28(-79.48701997634046 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark28(-79.5131672623193 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark28(-79.51323562356878 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark28(-79.53082569381897 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark28(-79.5925783780578 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark28(-79.62321597010902 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark28(-79.62902929666313 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark28(-79.6644964114661 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark28(-79.67002891750226 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark28(-79.68169822841679 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark28(-79.7751447376815 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark28(-79.79532284047717 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark28(-79.80305197165605 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark28(-79.9253664957165 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark28(-79.98814112118669 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark28(-79.9983356483049 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark28(-80.0222678684887 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark28(-80.0502141650139 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark28(-8.008468935147818 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark28(-80.18073754223047 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark28(-80.21527615810813 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark28(-80.25256339158425 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark28(-80.26493934167294 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark28(-80.34520430569052 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark28(-8.041921091397626 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark28(-80.4209915829579 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark28(-80.425007985704 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark28(-80.46559921439278 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark28(-80.46742395420196 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark28(-80.47972081098243 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark28(-80.52493777689405 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark28(-80.56617625873761 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark28(-80.59102179989046 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark28(-80.65642214190407 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark28(-8.068156953315835 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark28(-80.6870584603322 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark28(-8.073402902811509 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark28(-80.76200416822601 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark28(-80.81684064063938 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark28(-80.94103265683803 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark28(-80.94750635560075 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark28(-80.96889343627582 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark28(-81.05115991198424 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark28(-81.06796941052022 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark28(-8.11201376508886 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark28(-8.112798471093924 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark28(-81.14433244111252 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark28(-81.23494583896833 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark28(-81.23554454801574 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark28(-81.24289753656733 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark28(-81.28310369140708 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark28(-81.34955993588211 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark28(-81.43849541286588 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark28(-81.48536967818714 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark28(-81.514542518469 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark28(-81.52310059120171 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark28(-81.55613158259287 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark28(-81.55726244709382 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark28(-81.5786955473319 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark28(-81.58967751876037 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark28(-81.64831670105374 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark28(-81.6827704767406 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark28(-81.70255094235041 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark28(-81.71399711389688 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark28(-81.72714665220312 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark28(-8.174286223116084 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark28(-81.75722842314383 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark28(-81.85987081500909 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark28(-81.87625178149085 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark28(-81.89237302826642 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark28(-81.9208189079178 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark28(-82.12298968842259 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark28(-82.20269488260526 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark28(-8.226455625987768 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark28(-82.28520234807534 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark28(-82.29228597853648 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark28(-82.3252138323352 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark28(-82.3564772703612 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark28(-82.40913195135755 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark28(-82.4300770797142 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark28(-82.44923635125174 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark28(-82.47009788962566 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark28(-82.47140386810712 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark28(-82.57204367952677 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark28(-82.590010558254 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark28(-82.64569375028287 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark28(-82.65984526816344 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark28(-82.74088732379079 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark28(-82.83104496423877 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark28(-82.84014915881642 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark28(-82.92831897899397 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark28(-82.93085936678948 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark28(-8.293087429554419 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark28(-82.94928118529661 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark28(-8.30230386672217 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark28(-83.04741715534298 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark28(-83.21231339027177 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark28(-83.21578165535027 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark28(-83.28687174479244 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark28(-8.335314233620437 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark28(-83.36782102610161 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark28(-83.39538644812694 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark28(-83.48176755817782 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark28(-8.34968173152177 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark28(-83.50558691002776 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark28(-83.52113245070876 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark28(-83.54905195419883 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark28(-83.5538765973621 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark28(-83.56117789961435 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark28(-83.5920982368126 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark28(-83.60678800359543 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark28(-83.62910988384418 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark28(-83.6597494708223 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark28(-83.66245642125548 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark28(-83.69437454979416 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark28(-83.75200115931356 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark28(-83.7672681597686 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark28(-8.378500093505863 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark28(-83.79237217400488 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark28(-83.83479299605476 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark28(-83.85629964228005 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark28(-83.8714008787779 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark28(-83.89578442554625 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark28(-83.92575060641809 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark28(-83.94534056536381 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark28(-83.94833922458335 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark28(-83.97897376251457 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark28(-84.00836405676515 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark28(-84.03155429390839 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark28(-84.05174355981055 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark28(-84.05342208250283 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark28(-84.10230328225373 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark28(-84.11451156441984 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark28(-84.11764476389578 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark28(-84.15042380329768 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark28(-84.19071776440524 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark28(-84.19243536495907 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark28(-84.24817405115918 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark28(-84.25284087045269 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark28(-84.30532392437111 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark28(-84.31095874687374 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark28(-84.34557417396147 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark28(-84.36256860138505 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark28(-84.42720967101911 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark28(-84.446999889217 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark28(-84.47154293338284 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark28(-8.449276150352873 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark28(-84.58379695288937 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark28(-84.59744440384702 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark28(-8.470324521057222 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark28(-84.72638853153794 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark28(-84.75418755431122 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark28(-8.477651972174712 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark28(-84.81869095415668 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark28(-84.82188705440484 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark28(-84.82593794716871 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark28(-84.88417637512703 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark28(-84.90118119297445 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark28(-84.90505669719744 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark28(-84.93307378642905 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark28(-84.93599634649931 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark28(-84.95708238381341 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark28(-84.97947737500114 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark28(-85.05921384860189 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark28(-85.1660563451145 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark28(-85.18906288457035 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark28(-85.21329356175636 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark28(-85.21899214507746 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark28(-85.2385616023634 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark28(-85.26345258976518 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark28(-85.29575686427123 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark28(-85.34276896188153 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark28(-85.38096276213723 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark28(-85.38715735006038 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark28(-85.4823430549329 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark28(-85.48706486675883 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark28(-85.48838524238165 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark28(-85.51088841679508 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark28(-85.53028516750709 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark28(-85.55772393659846 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark28(-85.60003492971491 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark28(-85.64128457248441 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark28(-85.72870555506142 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark28(-85.7810505156545 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark28(-85.78507932922088 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark28(-85.8123217375092 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark28(-85.84087969048133 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark28(-85.84135691530719 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark28(-85.89598305118322 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark28(-8.590325734200263 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark28(-8.597874667421195 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark28(-86.01823054005304 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark28(-86.0464538040747 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark28(-8.608068435185245 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark28(-86.08221218866976 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark28(-86.10732536562007 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark28(-86.1409507397696 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark28(-86.20059449665804 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark28(-86.25135721479127 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark28(-86.27244241161536 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark28(-86.28789709038449 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark28(-86.37321879737372 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark28(-86.45879400625647 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark28(-86.49138683032729 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark28(-86.54094880541979 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark28(-86.57882226675262 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark28(-86.5907638414045 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark28(-86.60788542147814 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark28(-86.60854276076773 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark28(-86.66086068534324 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark28(-86.70708313816073 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark28(-86.71526167608283 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark28(-8.683863820667057 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark28(-8.685503898811703 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark28(-86.88003661711537 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark28(-86.91550574998534 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark28(-86.91649090200036 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark28(-86.92916665106635 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark28(-86.94695427902226 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark28(-86.9710643498629 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark28(-86.97883323438123 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark28(-86.98915717091597 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark28(-87.02171256307147 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark28(-87.08954454849929 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark28(-87.1206522197655 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark28(-87.19884892401777 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark28(-87.24889628876787 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark28(-87.2669591528646 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark28(-87.2911149934896 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark28(-87.29539546591212 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark28(-8.730273117493368 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark28(-87.3308069784345 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark28(-87.36272173726844 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark28(-8.744426152397239 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark28(-87.5112969642119 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark28(-87.52560738806041 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark28(-87.5766925247335 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark28(-87.59487587447636 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark28(-87.61919471579083 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark28(-87.63586727566388 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark28(-87.64640483200559 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark28(-87.64736874142022 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark28(-87.65569101640445 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark28(-87.70216715617838 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark28(-87.72376216030374 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark28(-87.79420930529935 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark28(-87.81220427146201 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark28(-87.81588674943357 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark28(-87.81750006285745 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark28(-87.8209470113259 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark28(-8.7837312475381 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark28(-87.83993838991444 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark28(-87.85530064379003 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark28(-87.961055880342 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark28(-8.797868937853309 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark28(-87.99615832640944 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark28(-88.01042419834786 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark28(-88.01474017645066 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark28(-88.06048559975761 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark28(-88.11198666246516 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark28(-88.20371532935224 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark28(-88.30662532377474 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark28(-88.32344007984398 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark28(-88.32785374068159 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark28(-88.33506932457517 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark28(-88.35992991689601 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark28(-88.37816295567384 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark28(-88.38292998969555 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark28(-88.41652583672241 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark28(-88.42353191106622 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark28(-88.43710061834571 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark28(-88.47514486645854 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark28(-88.47862919362922 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark28(-88.47880216538076 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark28(-88.49122031861174 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark28(-88.49614789004603 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark28(-88.55838598697581 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark28(-88.57786862963559 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark28(-88.65113526856257 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark28(-8.865268899403716 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark28(-88.73566560070395 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark28(-88.7527498147413 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark28(-88.7670205652155 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark28(-88.81479011652935 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark28(-88.92036572083268 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark28(-88.94929267545699 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark28(-89.00862475523309 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark28(-8.904586021923791 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark28(-89.0629232346754 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark28(-89.10235772671618 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark28(-89.11880528009159 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark28(-89.13400349698584 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark28(-89.22871594439867 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark28(-89.23449917532835 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark28(-89.28929634667352 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark28(-89.29079064625506 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark28(-89.2943769474666 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark28(-89.31282739197759 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark28(-89.36873418835678 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark28(-89.37624076470632 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark28(-89.44956873910598 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark28(-89.45033640818174 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark28(-89.49015907584459 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark28(-89.49305886972658 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark28(-89.51963615506482 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark28(-89.55533705368678 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark28(-89.59120517848262 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark28(-89.60662412277895 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark28(-89.61546250649329 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark28(-89.68830212079641 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark28(-89.72347195096984 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark28(-89.73836252173457 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark28(-89.74599910699787 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark28(-89.7927023935072 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark28(-89.80752361047884 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark28(-89.85027422915581 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark28(-89.86181475515956 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark28(-89.88245532124748 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark28(-89.88815790787814 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark28(-89.90590289886076 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark28(-89.90722428805849 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark28(-89.95313374614264 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark28(-8.997046151480362 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark28(-89.97393813889703 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark28(-8.99984066149051 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark28(-90.03021948839304 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark28(-90.04053697230066 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark28(-90.1126381194846 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark28(-90.13004760057642 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark28(-90.14572076224188 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark28(-90.15775565338855 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark28(-90.19775833105494 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark28(-90.21386418220294 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark28(-90.22678529812352 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark28(-90.25755246441705 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark28(-90.28739400446983 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark28(-90.32416553848574 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark28(-90.33298770812158 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark28(-9.034454987754415 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark28(-90.45150502463339 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark28(-90.55612506361284 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark28(-90.63065395547518 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark28(-90.65292244008494 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark28(-90.69800042183103 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark28(-90.76203793218869 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark28(-90.77016354080214 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark28(-90.80374070930739 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark28(-90.80982575716021 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark28(-90.91740540524384 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark28(-91.04477533884521 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark28(-91.05363502360235 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark28(-91.08082935427346 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark28(-91.11786907364456 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark28(-91.16254506387753 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark28(-91.18595365397482 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark28(-91.25878246220614 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark28(-91.26425866869985 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark28(-91.26875427033346 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark28(-91.2909927634497 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark28(-91.30079708288153 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark28(-91.33794096464227 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark28(-91.35787107336218 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark28(-91.40289463893221 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark28(-91.41867120285885 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark28(-91.44739198561658 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark28(-91.44883037247367 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark28(-91.53837704823071 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark28(-91.55926567693278 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark28(-91.58485433969197 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark28(-91.5952459721627 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark28(-91.64704977000373 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark28(-91.73644756997983 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark28(-91.76854958588942 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark28(-91.77132128673169 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark28(-91.8305444440333 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark28(-91.92032944935751 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark28(-91.93334177299573 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark28(-9.197592825396072 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark28(-92.05269093302984 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark28(-92.12742384349437 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark28(-92.18119580610329 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark28(-92.22571384365479 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark28(-92.24991218123276 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark28(-92.25198940877306 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark28(-92.34092946861657 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark28(-92.34169910385523 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark28(-92.35059708314044 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark28(-92.35110377217899 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark28(-9.238362409727003 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark28(-92.40617154577 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark28(-92.42577083896974 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark28(-9.24405215996238 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark28(-92.44096560658224 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark28(-92.45483015622773 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark28(-9.25339647516192 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark28(-92.54305193615843 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark28(-92.56507031533671 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark28(-92.57633574384798 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark28(-92.60207777730317 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark28(-92.62653125655922 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark28(-92.63749579031453 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark28(-92.66584606445332 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark28(-9.267053668462054 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark28(-9.27113245460869 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark28(-92.71419152986917 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark28(-92.72804150555227 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark28(-92.79590326337062 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark28(-92.87243796423918 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark28(-92.8738813036398 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark28(-92.93150340558363 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark28(-92.9354372823521 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark28(-9.295034650637547 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark28(-93.05910787295173 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark28(-93.08236865100699 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark28(-93.12112754483677 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark28(-93.1603397106995 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark28(-93.19163765591199 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark28(-93.1965245538274 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark28(-93.1967800395022 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark28(-93.20111625390555 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark28(-93.20368459986146 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark28(-93.26186912376357 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark28(-93.28998347835108 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark28(-93.34264722753969 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark28(-93.36966975033056 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark28(-93.41147584565155 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark28(-93.43106562572787 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark28(-93.44723261547168 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark28(-93.54512132877059 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark28(-93.5467204351053 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark28(-93.57859069839354 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark28(-93.63646880686656 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark28(-93.66942202401877 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark28(-93.74565333826675 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark28(-93.74707921034233 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark28(-93.77442537454056 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark28(-93.77477500750256 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark28(-93.78589188648667 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark28(-93.80344797047809 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark28(-9.380813652694187 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark28(-93.91921502194813 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark28(-94.02027265725839 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark28(-94.1136456882624 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark28(-94.16654340049936 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark28(-94.1782087749806 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark28(-9.426023896875762 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark28(-94.2702078761266 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark28(-94.34551937784632 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark28(-94.40487760577369 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark28(-94.40860196751319 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark28(-94.46444940155845 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark28(-94.51299697594993 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark28(-94.52572702511752 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark28(-94.5306028744864 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark28(-94.56835554864607 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark28(-9.45761610116351 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark28(-94.67838070527156 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark28(-9.473760247982298 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark28(-94.77617186163701 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark28(-94.80819078495955 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark28(-9.48299461464859 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark28(-94.83605333939758 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark28(-94.88936047056717 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark28(-94.90181365753094 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark28(-94.91315476977861 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark28(-94.98585824841985 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark28(-95.00988365809665 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark28(-95.02687416162135 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark28(-95.03737089215858 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark28(-95.04849143112327 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark28(-95.09653581844279 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark28(-95.10920642189045 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark28(-95.22802556529912 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark28(-95.25121851435028 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark28(-95.28065581796558 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark28(-95.33077897965212 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark28(-95.36294772336862 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark28(-95.3960334653857 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark28(-95.40771104439816 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark28(-95.40927561656882 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark28(-95.55441992524574 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark28(-95.63620372040486 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark28(-95.64226762438798 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark28(-95.66147562315797 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark28(-95.68704796131253 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark28(-9.574798942459338 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark28(-9.577260517253677 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark28(-95.86055402608125 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark28(-95.86127663069108 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark28(-95.86577473209597 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark28(-95.90009578085039 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark28(-9.599770903594404 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark28(-96.02099189855689 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark28(-96.0660190353459 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark28(-96.08908611583595 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark28(-96.13466464400592 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark28(-96.14318625010421 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark28(-96.21971753937642 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark28(-96.24651270926326 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark28(-96.27705696388718 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark28(-96.29530826139425 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark28(-96.33134293372115 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark28(-96.35625009590318 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark28(-96.35859427240443 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark28(-96.42127930396424 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark28(-96.45649564057473 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark28(-96.48640394131087 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark28(-96.498785158414 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark28(-96.54740752724966 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark28(-96.6685652849818 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark28(-96.67603179418833 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark28(-96.70354202572912 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark28(-96.72681757211954 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark28(-96.75405670799107 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark28(-96.94568368073256 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark28(-96.98265251712041 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark28(-97.0050409637883 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark28(-97.010834826271 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark28(-97.11190581349074 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark28(-97.11569828401802 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark28(-97.11848622936195 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark28(-97.14371149694753 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark28(-97.17984478650656 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark28(-97.21028214694326 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark28(-97.21067429780015 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark28(-97.2118880027519 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark28(-97.24111524350478 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark28(-97.25358274703608 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark28(-97.26667043331219 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark28(-97.27481097897765 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark28(-97.33987202251552 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark28(-97.39419444915418 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark28(-97.43733618704182 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark28(-97.44403428724068 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark28(-97.45217259881753 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark28(-97.45732988166532 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark28(-97.49560433781986 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark28(-97.5086975617361 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark28(-9.751394929977124 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark28(-9.754095439419473 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark28(-97.60131847025637 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark28(-97.60942738405657 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark28(-97.61072448825755 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark28(-97.61695173480047 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark28(-97.62967915109526 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark28(-97.67184440963193 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark28(-97.67541985892096 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark28(-97.703211442057 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark28(-97.71153086697038 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark28(-97.71988754978416 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark28(-97.73690519989088 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark28(-97.75347659842208 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark28(-97.77182269152638 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark28(-97.774337955296 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark28(-97.77446507789507 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark28(-97.78413639341572 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark28(-97.79891473816737 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark28(-97.827664931071 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark28(-97.86271608990702 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark28(-98.00049927567433 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark28(-9.802041534091586 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark28(-98.08055564542421 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark28(-98.14514016045817 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark28(-98.21304056103897 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark28(-98.22505213018088 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark28(-98.25292916234329 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark28(-98.29696577385663 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark28(-98.3341694485878 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark28(-98.34397355297253 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark28(-98.37016947994803 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark28(-98.40394691354848 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark28(-98.46125608383913 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark28(-98.47038218248446 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark28(-98.48608057326447 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark28(-98.50773704687128 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark28(-98.54296341750364 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark28(-98.56469137235288 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark28(-98.56631340213062 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark28(-98.61226527874713 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark28(-98.63490743030158 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark28(-98.71915782634568 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark28(-98.84497475596321 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark28(-98.8597413688309 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark28(-98.90159036782684 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark28(-98.9106397987068 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark28(-98.92291034599413 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark28(-98.95585139010457 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark28(-98.96555789441442 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark28(-99.02463264798548 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark28(-99.07197877951639 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark28(-99.0817760919743 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark28(-99.0849863900993 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark28(-99.10414807678411 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark28(-99.14108267786597 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark28(-99.14421836304719 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark28(-99.16559099442269 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark28(-99.24153932227331 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark28(-99.25322116201907 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark28(-99.35916223230595 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark28(-99.36249241319315 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark28(-99.38065043532384 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark28(-99.43089684039074 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark28(-99.44045050182883 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark28(-9.948916285434237 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark28(-99.49320212659572 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark28(-99.50511954665984 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark28(-99.5587812871313 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark28(-99.59880710311275 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark28(-99.61010728957618 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark28(-99.73622442233308 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark28(-99.75369767800066 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark28(-99.81147286697289 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark28(-99.86214225917765 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark28(-99.92167559765662 ) ;
  }

  @Test
  public void test2796() {
//    	UnSolved;
  }
}
