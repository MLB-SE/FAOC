import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,0.0,-1.0,48.593044294565956,-38.47124713385739 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,0.0,-1.0,6.938893903907228E-18,-84.13563906856284 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(0,0.0,-1.0,-85.94011016898756,0.018277802107842023 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(0,0,0.36208927206005576,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(0.00559465299140083,-75.20744590970342,-1.0,-96.24226088768688,39.60531873829218 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.9999210035026413,162.0159935954897,-34.88374977392107 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.9999999999999982,-1370.6812300686317,1198.368668085757 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,0.0,10.767292379886984 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,0.021470161698813335,-73.1618303033887 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,0.08810164628691297,-17.82936406976347 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,-0.4571098836910665,3.4363648278856838 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,-100.0,100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,100.0,-100.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,100.0,-5.363458113212067 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,100.0,-79.25846710177403 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,1229.8574201815593,-1302.060263098381 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,-19.151521762798772,6.436641799342624 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,-20.857532622431034,21.097913909919136 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,27.878719079318994,-100.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,-3.1554436208840472E-30,6.11884356745 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,34.62417190039676,100.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,4.180544565216833E-199,-1.3706755226270512E-43 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,-58.325982457029006,21.49987501521861 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,75.26554901576415,-0.8696085351902485 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,-76.51277656737332,100.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,-84.24155028240918,0.01864633689110562 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.0,85.49483759358375,-87.69772249365151 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark56(-0.011051465589066112,21.99693085368333,-1.0,5.484157896133839,-17.915400096665728 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.232595164407831E-32,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark56(0.01287886753119949,70.82609982700376,-1.0,73.11273111171958,-72.1539362745642 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark56(-0.013464489563595236,89.76596314212662,-1.0,7.6002769161747805,-14.584015078321857 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1857.0474602789714,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark56(0,0,1.961298519581618,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark56(0.019644438157719355,4.856965426666008,-1.0,12.204091531211368,-8.55291228798336 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark56(0,0,21.2994553774452,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark56(0.02501417766312386,-99.99999999994789,-1.0,-28.13804172806502,27.1338512498278 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-2622.2764062523293,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-26.55421737273042,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-27.576065600582893,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark56(0.03290682623026779,-63.4776154861004,-1.0,0.12128956454119702,-12.950795336241498 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-50.991668164619306,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark56(0,0.6558021773020108,-1.0,98.95938064769977,-67.09372749092839 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-7.359107644445899,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark56(0.07404018165628656,-34.60177929449932,-1.0,0.7396390265709958,-1.440220258896145 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-81.80744352006096,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-84.5469374571828,-25.79875039933512,28.23320498909203 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark56(0,0,97.7273278395947,69.15253283738718,6.7853700348004224 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-0.005385477070611669,28.836309695561795 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,0.028832215981044067,-54.48059656002948 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-0.03883894273423533,1.6096352695291318 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,0.04333582122243653,-36.24706495654542 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,0.07300694698759777,-20.493359195321254 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-0.19985100554157187,1.7706473323364684 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,0.34470099165291224,-4.556982326225977 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-0.42822846033778145,9.851937722060768 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,0.5493736151102575,-1.936412683724379 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-0.5618027884630052,2.1325991152579022 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,0.5794298590095812,29.265700350093454 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-0.6869358997816364,2.257732226576533 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-0.7850919967501857,0.7850919966815646 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-0.9943512841089153,-0.5056501823898749 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,100.0,-100.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-100.0,100.0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,100.0,-1.1106277387165242 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,100.06170679950446,-100.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-100.0,98.5 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-100.0,98.5 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-100.0,98.50000001360797 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,10.059761738841802,-11.626397124316535 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-10.140399122080353,11.640399122080353 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,11.684418577361527,-13.255214904156418 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-11.84820035838091,10.462985060164574 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,1.1936215809444644,-1.3159918954816392 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-119.98954429093149,100.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,12.392282327068063,-6.109097019895309 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-12.486477569357142,100.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-13.338333599689776,11.58526637931177 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,1.4918184337737808,-1.0529406871728546 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,1.570796326794936,-3.9843366741630014E-14 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-1.5884788472063422,0.988868268253906 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-1.5961104291149368,0.025314102320041165 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,1.6757548336880532,-0.7268213016378695 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-1.8681980727329808,1.8681889954413629 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,2.0109662379623714,-0.4401699111674747 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-2.188236378434309,-13.44893056271976 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-22.492124533196602,22.4921245331966 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,2.3333069776361026,-2.3333070358915307 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,2.5785330754083664,-1.0785330754083666 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,28.44099369237862,-26.870197365583724 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-28.7585561519037,27.444082244903313 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,31.77898666622413,-33.349782993019026 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-33.021059873390506,31.52105977935658 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,3.465954054345344,-4.655217086209545 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,3.578324579759168,-3.578324579759169 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,35.93465833976834,-37.505400050985024 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-3.9842858737131133,-47.78119658372358 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,40.4657055022257,-42.03124108568631 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,43.248619266999896,8.516863190436794 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,45.20064218364616,-15.658213506169758 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,47.41669921962307,-45.91669921962307 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-47.60685917554849,47.606858674439 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-4.914382136427866,6.485178463222763 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,51.09486695931441,-52.59486695931441 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,5.253401878976599,-5.253401883884388 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-5.285807105261568,31.918548333979913 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-5.457273883223679,7.028070210018576 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,54.9630690470714,-0.02857912329185197 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-55.718582021175294,29.042543178486362 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,5.588851626807459,3.835926391725323 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,56.13136392070773,0.34650751711365757 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-5.628188507381482,7.19898483417638 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,5.844679303985167,-7.415475630780063 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-58.661231985087106,60.161231985087106 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,59.09080150324344,-59.09080150324344 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-6.166845748015959,0.2547163316513319 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,63.34702924750455,-64.84322686578253 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-63.77712004196674,47.0574135912006 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-66.72856883254443,68.22856883254443 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-7.282550304306752,5.782584616250034 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-72.87833475093646,74.37833475093672 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,7.498540826000695,-6.917901239291377 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-75.3051783829437,84.65916001691818 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-75.6391938889877,74.06839756219281 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-76.06563335664671,76.04464265908335 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,76.41676343237422,-37.214146124510954 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-76.99851214403562,39.137680484200956 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-77.42962471266169,79.00042103945658 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,80.15983285738605,7.733965116333267 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-8.206429346527443,6.635633019732547 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-8.220585388025867,6.64978906123097 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-82.775479587849,81.18224190390116 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,96.41765745719931,-97.9884537839942 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,97.22762077622974,-97.22762003228895 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,97.64499351099974,1.244378750283771 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-98.49999569612808,100.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.0,-98.5003380681661,100.0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,98.5,-100.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.0,-99.99999999999388,98.49999999999388 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark56(0,100.63285211422465,-1.0,2.186335654411172,-0.6155393276162757 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark56(0,10.071327132877855,-1.0,-6.89596575434868,77.12279083076095 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark56(0,101.33917123611164,-1.0,100.0,-28.87520427384436 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark56(0,10.757121052231076,-1.0,-2.4469450739022127,-39.964555748597625 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark56(0,10.781543761020671,-1.0,-40.16713040416133,38.596334077366436 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark56(0,107.96055206650135,-1.0,-3.1339838137425393,4.634958684749581 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark56(0,-108.05201073156428,-1.0,-10.26328108032352,93.44468863044986 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark56(0,-10.99886695668588,-1.0,0.028055805220396985,-49.088934345129495 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark56(0,11.056007978352111,-1.0,-67.83958650012052,65.08123494936363 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark56(0,-114.01076975052295,-1.0,4.950191286851155,-0.2612285452359675 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark56(0,-11.433235842301311,-1.0,47.48586014354624,-45.98586014354624 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark56(0,-11.491332144590647,-1.0,-65.81552933635473,64.31552933635473 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark56(0,-11.652479496874573,-1.0,96.55576673903248,-95.05527193996546 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark56(0.11900395038911175,0.11161982697578703,-1.0,0.019381282241381033,-81.04707971493674 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark56(0,11.943177979034632,-1.0,0.032994122810509695,-47.60836758159084 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark56(0,-12.115766154900328,-1.0,23.07915346832864,-29.28867538319144 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark56(0,1.2438761439675616,-1.0,71.15933320913396,-94.52469800599346 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark56(0,12.551857626787324,-1.0,-80.08806156535414,78.58806156877907 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark56(0,13.054965863071136,-1.0,-3.080772529021895,3.0807725290218944 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark56(0,13.218960371042794,-1.0,44.74626186891862,-0.03510452630426303 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark56(0,13.705391410033354,-1.0,0.03716522107898178,-42.26522219406994 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark56(0,-13.84371931481685,-1.0,6.427758294831641,-5.550888581234055 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark56(0,-13.949547978369756,-1.0,36.898627853963916,-91.86888036650072 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark56(0,1.4210854715202004E-14,-1.0,1.6034485281158894,-0.032652305517131275 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark56(0,142.47390480455033,-1.0,4.765503344944617,-538.6465724783683 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark56(0,-14.439423384276905,-1.0,-50.227743644038576,48.72550929959514 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark56(-0.14495383230605594,-100.0,-1.0,72.2119122159682,-70.7083341533174 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark56(0,14.725902127475942,-1.0,-0.028081602334165744,55.93684819344416 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark56(0,14.951432372682202,-1.0,-11.537409651235187,10.037409651235187 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark56(0,15.243272467278459,-1.0,-53.298726018715584,43.21610974107776 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark56(0,15.374838936330036,-1.0,-7.7148755815561785,6.144079254762155 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark56(0,-15.653497417868365,-1.0,-0.02908686751639067,54.00362641008303 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark56(0,-15.78604455568534,-1.0,-58.80010596152508,3.822057146711429 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark56(0,159.58021523403914,-1.0,89.21070820985605,-89.21070821015493 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark56(0,-16.003280298380567,-1.0,-100.05979223722782,100.0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark56(0,-162.47417634502034,-1.0,-44.969655934547035,100.0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark56(0,16.30915910500223,-1.0,56.022136272812396,-57.59293259960729 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark56(0,-16.844513729844635,-1.0,-28.372766728335606,8.3271559735457 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark56(0,1.7116141672887224,-1.0,-4.3950420342039385,0.35740188934948613 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark56(0,171.92005360735214,-1.0,100.00000000027076,-100.0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark56(0,1.747466284185387,-1.0,62.333906731319274,-60.833906731319274 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark56(-0.1759674682069036,4.483589410962797,-1.0,-100.0,100.0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark56(0,17.638172836306563,-1.0,66.29848126234549,-66.86344265684693 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark56(0,-1.7684317247972903,-1.0,0.2824136688808479,1.288382657914049 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark56(0,17.766665803795494,-1.0,-1.1187960764934064,1.4040059308378832 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark56(0,-17.808219114721837,-1.0,-42.976665390496805,41.476665390496805 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark56(0,18.167001434252487,-1.0,-43.739133326800626,42.16833700000579 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark56(0,-18.522544823975153,-1.0,-71.93944278381731,70.36864645702242 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark56(0,18.62415703054449,-1.0,0.06206275206820806,-25.30980780659813 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark56(0,-18.6536331877858,-1.0,-30.563411808810706,52.52746554099731 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark56(0,1.9543560869235677,-1.0,-57.601809509509486,8.13917557832199 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark56(0,-19.75523413629663,-1.0,41.242148864525205,-41.53726852996713 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark56(0,-198.82303627856538,-1.0,-524.1883663604699,4.083747153379271 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark56(0,20.25775056876043,-1.0,1.8766650732632102,-1.8766650732632102 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark56(0,20.815664518082365,-1.0,-18.997982774885195,0.08268226923920816 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark56(0,21.169991175124707,-92.73495830909624,65.54770571612278,23.740547264646494 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark56(0,-21.44031874628529,-1.0,-80.30358841873485,81.80358841873485 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark56(0,21.446601805054197,-1.0,0.48083582126788116,-5.141130740021765 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark56(0,21.45238109817869,-1.0,5.2012394910977555,-6.772035817892647 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark56(0,-21.585469144818134,-3.8231238191371233,-13.132992141378836,-15.985787758613498 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark56(0,-218.26871272388803,-1.0000000028609604,-249.68570185205073,0.0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark56(0,-21.844805526425944,-1.0,4.779221653125859,-0.3286719974093515 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark56(0,21.926494905148296,-1.0,-51.537718740319164,0.003883248563754528 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark56(0,22.032535609708333,-1.0,31.711061728539676,-28.631636833787475 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark56(0,-22.38407230045658,-1.0,-60.714946646413956,59.14415031961906 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark56(0,-22.834418321263655,-1.0,39.71660358922472,-53.09293712188137 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark56(0.22997000875226709,-5.309118151490853,-1.0,-48.96140488122167,4.4384402009189285 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark56(0,23.0610338938326,-1.0,-0.1160308131160086,1.6160308131160086 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark56(0,-23.479507574676063,-1.0,-24.67130545427562,23.100509127480713 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark56(0,23.60319625906908,-1.0,-100.1912891174319,101.69595918118192 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark56(0,-23.719861701799367,-1.0,-21.820207706555298,20.320207706555298 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark56(0,-23.81380103379356,-1.0,75.31432219073915,-76.81432218796223 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark56(0,23.99425838229965,-1.0,-82.48931105671274,83.98931105672234 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark56(0,-24.003567709188076,-1.0,12.840484513726508,-0.2741138965545673 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark56(0,-24.572472523003057,-1.0,100.0,-1.1106277387164103 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark56(0,-24.59058451941943,-1.0,-53.950501892228814,45.0243073804977 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark56(0,24.5930244931705,-1.0,-100.0680268892625,98.49989598139321 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark56(0,2.532329814693796,-1.0,-62.67447885490635,64.12675083632142 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark56(0,-2.5518302033061033,-1.0,-66.07570581822519,64.53292806452306 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark56(0,25.544796764399898,-1.0,2.463430127687868,-4.034226454483286 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark56(0,26.474484642039386,-1.0,-0.1867694708492138,-1.3840268559456774 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark56(0,-2.660934098392148,-1.0,-0.0044480758816132174,352.8210162237512 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark56(0,27.085964286063962,-1.0,-37.95409684365515,0.041386739704688535 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark56(0,27.960571554408503,-1.0,-3.3083852028189824,0.13113743192238728 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark56(0,-28.081320689315234,89.59180874104624,41.86590729459377,69.28458089045586 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark56(0,28.46281913576982,-1.0,24.143182558806128,-22.57238623201124 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark56(0,28.67969486727324,-1.0,-27.938307296202098,22.828013325891902 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark56(0,28.96501783441379,-1.0,-8.808385232439512,7.237588905644617 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark56(0,-29.08031448169738,-1.0,2.3534261148724966,-49.69178110201233 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark56(0,-29.12446027289087,-1.0,-48.29859333752558,46.79859333752558 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark56(0,29.477297171232692,-1.0,35.55028891957215,-37.05028891957074 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark56(0,29.683051047232574,-1.0,19.50652176920812,-8.565642455278173 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark56(0,-2.9994142036140743,-1.0,-2.8662993139368367,0.5480224340693233 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark56(0,-30.041244589970347,-1.0,1.8394261972259578,-1.9512158166154592 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark56(0,301.06449142482194,-1.0,2283.8570154765384,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark56(0,30.309401009908647,-1.0,-4.595580500552944E-5,81.92870762399545 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark56(0,-30.608357618707117,-1.0,702.2548668322684,-4.068100527409783 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark56(0,-31.086057247954656,-1.0,-19.174685790095822,17.878575011765598 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark56(0,-31.0901459544742,-1.0,3.3407918990202004,-4.9115882258150965 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark56(0,31.33216151780359,-1.0,-0.02629606912913962,59.735024238059395 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark56(0,31.3991503924728,-1.0,2.457946748432736,-0.5387599167014482 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark56(0,3.1696672982346143,-1.0,-100.0,100.0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark56(0,32.219923038351155,-1.0,16.40305848581124,-17.903058485811236 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark56(0,-32.6950187572528,-1.0,-3.7699445922691526,0.41666297430897375 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark56(0,334.39468940683844,-1.0,-849.5580739512047,6.881984835273702 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark56(0,-33.61565624271435,-1.0,-89.72301983575474,87.08923282041246 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark56(0,33.651550874706295,-1.0,-0.10094186695365082,15.561395625029746 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark56(0,-34.18134406085852,-1.0,-7.203060410635857,-0.6509090682362689 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark56(0,-34.38807226093259,-1.0,100.0,-29.437001344787845 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark56(0,-34.52880904526789,-1.0,0.09684102775671022,-16.22035993609181 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark56(0,-34.58576199007619,-1.0,4.433712913184592,-31.066454141902938 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark56(0,-34.742382321327455,-1.0000000000000018,23.77537396918568,-5.638796096718579E-10 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark56(0,-34.82475293098804,-1.0,-10.985725645653954,0.14298521349077353 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark56(0,-35.22296752349708,-1.0,5.551115123125783E-17,-39.73196705810584 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark56(0,35.386593881037065,-1.0,-1.5566332128030984,1.0090985557004106 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark56(0,35.43685559123607,-1.0,0.08241570204732594,-13.927500864630629 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark56(0,-35.49065041794203,-1.0,3.712844002515695,-23.215948871823482 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark56(0,-35.49402177439994,-1.0,68.0111446469303,-24.085994396638597 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark56(0,-3.552713678800501E-15,-1.0,-7.671843668936717,6.101047342141819 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark56(0,35.67884407322467,-1.0,-26.287698356603826,27.858494683398725 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark56(0,-35.722006396133146,-1.0,52.16957574819217,-50.653647652143434 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark56(0,36.13309963155896,-1.0,-54.82936491335985,31.82014026468567 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark56(0,36.13980126382715,-1.0,-96.81165081701464,83.3098133345359 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark56(0,-36.16753071225851,-1.0,-100.0,98.5 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark56(0,-36.60387407868645,-1.0,98.5,-100.0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark56(0,-36.726972291411954,-1.0,-2.059957510374093,2.0718730980335502 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark56(0,-36.882392659762544,-16.796782303357432,17.597353298406034,45.291060744541284 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark56(0,37.214190725462856,33.031902294752115,-34.30254364153723,74.57171064721152 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark56(0,-37.80521747599501,-1.0,84.06017629880179,-85.63097262559668 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark56(0,-39.188168083774144,-1.0,-91.5039223275576,14.534902369502062 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark56(0,39.57387483166264,-1.0,-17.4005200529166,49.697443953408396 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark56(0,39.96866272435583,-1.0,0.17602555780449114,-8.923683278649476 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark56(0,-40.15410221791409,-1.0,1.964750422109053,-91.50014066706846 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark56(0,-40.29176492493758,-1.0,0.7562062995162556,-1.99269991737388 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark56(0,-40.95782804415131,-1.0,25.497001752747558,-53.11406250844314 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark56(0,-41.05748110376818,-1.0,-25.987131753199066,9.814699067080596 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark56(0,-41.55431053255472,-1.0,100.76766362047988,-99.30588129877316 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark56(0,-42.091351964891196,-1.0,8.433101406452138,-10.003897733247037 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark56(0,-42.42622246817868,-1.0,0.4753983429502728,-3.304168704179105 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark56(0,-42.45967338300666,-1.0,16.531932654946406,-0.01831960494117979 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark56(0,-43.01738533770737,-1.0,-60.496299710472165,65.27846541966474 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark56(0,-43.26440954201269,-1.0,42.97151381693332,-41.47151381693332 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark56(0,43.29048586965815,-1.0,-2.7360062241222725,4.306802550917169 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark56(0,-43.43767677545145,-1.0,8.881784197001252E-16,-1.979489657046102 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark56(0,43.606797013504064,-1.0,-0.02318688621630899,67.74503105509848 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark56(0,43.61881829998406,-1.0,0.017586335297913536,-89.319138989762 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark56(0,44.1748470132342,-1.0,-9.815413576300793,67.03875587075349 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark56(0,44.189459444625754,-1.0,74.61986053585917,-3.999931696488332 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark56(0,44.33983551549864,-1.0,0.7089888467553532,0.8618074800395433 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark56(0,44.76310678905893,-1.0,-26.436197282740785,21.753456208163932 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark56(0,44.862174065728425,-1.0,-12.493458689752503,10.922662362957608 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark56(0,44.94630456314445,-1.0,-31.30089356763229,4.336618896413851 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark56(0,-45.57502916986602,-1.0,1.479060639848351,-1.4790606398483512 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark56(0,-45.906943862152744,-1.0,31.258223589586777,-92.4096553341693 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark56(0,46.24070721859715,-1.0,56.6508940826005,-124.17722851228291 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark56(0,46.95671747137386,-1.0,0.5444668004320699,-2.88501764579285 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark56(0,47.445777397242466,-1.0,2.5889912363207834,-0.6067213765571319 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark56(0,-47.64376910941796,-1.0,-69.82086157894685,68.35573143103446 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark56(0,-47.79745854826946,-1.0,-80.67138486715359,0.013952443645386666 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark56(0,-48.13700939865302,-1.0,-7.941228118604186,0.1978026954187273 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark56(0,-48.15475665981772,-1.0,15.361503042703816,-0.044388807127538676 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark56(0,4.826762020018071,-1.0,0.7206920946886454,2.4209642884353144 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark56(0,48.78577105637621,-1.0,52.938165949531935,-54.43816595802349 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark56(0,-48.87671493419561,-90.4611208336584,-54.74027294686144,90.77217796858145 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark56(0,-4.892544199947927,-1.0,-21.918503309895932,25.942873340534472 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark56(0,49.03677165842659,-1.0,-0.6962027919214449,2.2669991187163414 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark56(0,49.155921697243485,53.225877466296794,53.15100304180419,-38.58686603347099 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark56(0,49.35197635071225,-1.0,-41.02686520452538,29.638136355167774 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark56(0,-4.950075740260019,-1.0,27.973055767895147,-76.94317189511852 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark56(0,49.76987873722685,-1.0,-0.07477758349718978,21.00624616806357 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark56(0,50.6869087421681,-1.0,-40.098249306968675,36.459429324108456 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark56(0,-50.906920738849735,-1.0,-2.1647660033251555,2.1647660033251555 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark56(0,50.954595235337315,-1.0,5.000801698406871,-0.3141089012378373 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark56(0,51.07016560469732,-1.0,0.02090484387624647,-75.14030413686689 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark56(0,51.25883173151345,-1.0,-54.508287254293755,48.37247128392821 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark56(0,51.375243411569095,-1.0,-2.731969403381395,0.22344107688253934 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark56(0,-52.03221437098021,-1.0,-0.0037642980150766506,61.19402471622115 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark56(0,52.25877877591647,-1.0,9.860761315262648E-32,-79.09816582534863 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark56(0,-52.284944268898144,-1.0,-38.59973057569086,2.97648336654041E-4 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark56(0,-52.713656197670744,-1.0,0.09697306641349818,-17.37573266115736 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark56(0,52.7541337789396,-1.0,-0.28133858655338784,2.795236738953265 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark56(0,53.982960165761845,-1.0,-100.0,98.5 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark56(0,-54.081799629419685,-1.0,-33.550773854433935,-7.219134315438478 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark56(0,54.09252514070499,-1.0,9.196115353767603,-7.625319026972705 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark56(0,-54.22494084565345,-1.0,-25.01229418823917,62.70349645464813 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark56(0,54.61876696200062,-1.0,32.99293428004351,-82.18792748890522 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark56(0,54.7796086026215,-1.0,9.91752743964058,-34.674160647753865 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark56(0,-54.876944045874886,48.2483394981011,-75.96196578478799,-18.73257836563147 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark56(0,-55.01863240828801,-0.9817777191608408,50.069198354828124,-51.63999468162302 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark56(0,55.049217029132734,-1.0,-8.990185385808532,7.419389059013714 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark56(0,5.524895337990376,-1.0,24.73207318803658,-26.302869514831478 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark56(0,-55.31686056997234,-1.0,73.55120358722787,-18.686555149458876 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark56(0,-5.546337481256733,-1.0,-100.0,100.00000000995337 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark56(0,55.541057182410626,-1.0,28.21133903236467,-29.78213535915949 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark56(0,-56.03787802326715,-1.0,-90.53850029636986,90.53850030497703 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark56(0,56.20834820757705,-1.0,9.544233463031098,-9.544233659985231 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark56(0,56.81631026075316,-1.0,-10.930795041364505,0.1437037581301874 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark56(0,5.684684241961542,-1.0,33.37220720307777,-34.94300352987267 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark56(0,57.09386762034843,-1.0,99.94977025160566,-100.0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark56(0,57.502659068123904,-1.0,7.1767936876558345,-5.605997360860936 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark56(0,-58.028993754115405,-0.9999999999999998,100.12493277011335,-54.63978992010459 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark56(0,-58.06278041555246,-1.0,-50.57206954593889,43.06274462261342 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark56(0,-5.819558559539335,-1.0,26.95967948380131,-26.959679483909508 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark56(0,58.53381012444643,-1.0,-79.66593752771256,36.954790093813784 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark56(0,-58.589223231369814,-1.0,86.79908495602403,-49.127864490201496 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark56(0,58.68561309381031,-1.0,-64.23615032707978,-0.16649479439641723 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark56(0,59.15648006960063,-1.0,3.323795573984665,-4.894591900779561 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark56(0,-59.188959248265846,-1.0,-69.8534564588728,0.022487023640980375 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark56(0,-59.47216639043969,-1.0,-72.08253120306793,20.89654889072279 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark56(0,-59.6345447525801,-1.0,19.042960116606995,-20.292012281043032 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark56(0,-59.76321473721996,-1.0,86.03537743689198,-84.53537743689198 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark56(0,59.924808651245066,-1.0,35.398642999593044,-33.827846672798145 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark56(0,-60.00748923949788,-28.965136236593906,-94.80488113327785,-93.87706671092147 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark56(0,-60.71885848517509,-1.0,-87.0248181994206,85.4540218726257 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark56(0,60.914410563364285,-1.0,-94.01141465473785,94.01141465473772 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark56(0,6.098755365642162,-1.0,1.569438760130578,-1.0008650013615095 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark56(0,6.1337535497335836,-1.0,-14.524985991462447,8.972468705752934 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark56(0,61.974920665152844,-1.0,2.8250553398871716,-4.018052822003785 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark56(0,62.640997739913345,-1.0,1.6797804115803074,-0.10898408478540844 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark56(0,-62.908017978023175,-1.0,-73.91110932693752,61.17334875338103 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark56(0,62.98604837777388,-1.0,-18.776426241998085,17.276426241998085 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark56(0,-63.11619452236608,-1.0,-285.0667821043005,1.136421147721629 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark56(0,-63.918760637662395,-1.0,-8.450003650443076,8.45000365044308 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark56(0,63.94482682797357,-1.0000000000000029,-1.2499403588460323,1.2499403565838914 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark56(0,64.33500498257126,-1.0,-0.08035952849129842,5.246805158029304 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark56(0,-64.78657406437416,-1.0,22.173169744908975,-23.67316974500438 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark56(0,-65.47093457949,-1.0,30.206710063945145,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark56(0,-6.555424937839502,-1.0,-2.5641300403491343,0.612604002947142 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark56(0,66.10496843922004,-1.0,1.9035248601959438,-45.28408886517836 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark56(0,-66.93949345918877,-1.0,4.1570205778188,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark56(-0.6714551854040444,4.232880752880966,-1.0,0.1526476158285064,-10.290343011708906 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark56(0,67.20228890366315,-1.0,-76.7880546190734,78.3588509458683 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark56(0,67.22617119915651,-1.0,2.961209930776658,-0.5304576046666547 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark56(0,67.35092268205696,-1.0,-3.0469406266328534,1.5424012494692436 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark56(0,-67.4402030947989,-1.0,-57.562546011865045,56.059468675772536 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark56(0,67.47429548455752,-0.9999999999999999,15.160219871347559,-16.731016198142456 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark56(0,-67.49510930755528,-1.0,0.019041964261590303,-59.638506055672764 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark56(0,67.56498224786189,-1.0,0.038783015774658,-40.50217074200048 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark56(0,-68.52511435182849,-1.0,0.15468843563025,-10.154581500517292 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark56(0,68.53885991634735,-1.0,-1.0942504349489095,1.4354998422899712 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark56(0,-68.60886475634493,-1.0,-73.11820050932224,72.24636502245069 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark56(0,68.67232213116736,-1.0,-57.33381604370707,36.448470470767376 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark56(0,69.27409097883628,-1.0,-100.0,98.9435956307859 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark56(0.6981213680845161,1.7482006421267506,-1.0,9.739550711240189E-4,-55.47095010979779 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark56(0,-70.55917667907349,-1.0,-0.45815691882390003,3.4285116348939333 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark56(0,-70.66565149637754,-1.0,-89.9336853594956,91.4336853594956 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark56(0,-70.69294431282525,-1.0,0.2532061376906398,-6.203626583151788 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark56(0,70.94652552895585,-1.0,4.440892098500626E-16,-7.216189661561213 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark56(0,-7.105427357601002E-15,-1.0,-72.47769033089808,67.76533824129662 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark56(0,-71.05797969749308,-1.0,-0.05899749620948569,26.624796435719055 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark56(0,-71.21565787432124,-1.0,47.317844779296884,-0.03308939292943072 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark56(0,71.33353178181652,-1.0,-24.462634464504568,27.615153354132843 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark56(0,71.5846855938872,-1.0,23.007232817916144,-23.00723281791614 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark56(0,71.72977957271554,-1.0,2.170668789952516,-0.5998724631576196 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark56(0,-72.03414379992594,-31.75848707326196,71.21169614485973,-97.53556783713302 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark56(0,-72.045417658811,-0.9999963443691602,168.62226915834674,-94.55251791131676 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark56(0,72.25397543573432,-1.0,-98.29195070523124,66.5898766049319 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark56(0,72.27045132097382,-1.0,-2115.6837788675552,5.551115123125783E-17 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark56(0,72.60166185954256,-1.0,99.9998727767919,-99.99987277676748 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark56(0,72.8252600531598,-1.0,70.97474324748809,-0.022131764835238155 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark56(0,-73.85501998963443,-1.0,13.89190554117287,-0.015946900291472277 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark56(0,-74.17229575856749,-1.0,-15.033670709140335,16.50885822317512 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark56(0,7.432064844961918,-1.0,98.5,-100.0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark56(0,74.9052310730024,-1.0,60.937985601656024,-62.43880552376523 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark56(0,-74.9279675388165,-1.0,9.732254055485448,-15.276359458167242 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark56(0,74.94750228428973,-1.0,-76.42718229838943,137.02498526829908 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark56(0,75.06184907696095,-1.0,69.45609966599449,-46.73262307778734 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark56(0,-75.22434450804273,-1.0,3.469446951953614E-18,-1454.0143503795791 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark56(0,-75.272875415408,-1.0,33.94748127085282,-0.046271365886092174 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark56(0,-75.5685663838869,-1.0,0.020628937489957064,-76.1452851151262 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark56(0,-7.568624979597871,-25.657710762804427,81.81393642090319,44.23636983272556 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark56(0,76.39554019606263,-1.0,-14.13451555711745,2.9240576005945513 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark56(0,76.46386004984431,-1.0,-80.95118834263985,79.38039201584496 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark56(0,76.48544337951422,-1.0,-60.192755285303704,60.192755273547846 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark56(0,-76.86338596577455,-1.0,100.0,-98.55238675050634 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark56(0,76.99952693673717,-1.0,-83.30331482242046,66.18615021048817 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark56(0,-77.246872394998,-1.0,5.202753167860108,-6.702753167860109 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark56(0,-77.26973781878634,-1.0,20.4584296519183,-17.09426227627052 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark56(0,-7.72953282801501,-1.0,85.94056081518778,-78.5666023523605 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark56(0,-77.37409246300552,-1.0,-65.83974305323481,67.33974245856164 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark56(0,77.51783034968221,-1.0,6.592726377264896,-88.3601821254689 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark56(0,-77.53166341943142,-1.0,-1.3629525512282843,0.9842795553150214 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark56(0,-77.57041203373088,-1.0,0.004385891601462501,-2.0917813377280083 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark56(0,-77.80632339638628,-1.0,-8.870178174733509,7.463651819138505 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark56(0,77.87931415082005,62.290409883177574,-99.54169141445917,-51.91955930003878 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark56(0,-78.03491593155846,-1.0,71.45095217936898,-69.96794172328079 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark56(0,-78.35482171356925,-1.0,27.64212219167569,-26.071325864880794 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark56(0,78.46992209991176,-1.0,-39.92285875673675,39.91937539973258 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark56(0,79.10159648535807,-1.0,-0.5956945954700397,2.6369155247336744 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark56(0,-80.0955898727428,-1.0,-100.0,100.0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark56(0,-80.11099404785273,-1.0,-0.5593855305069999,0.5593855305070008 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark56(0,-80.56514702263685,-1.0,-6.524984516104426,0.24179920613782455 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark56(0,8.063738482102423,-1.0,-3.517360884158447,0.4465645573635504 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark56(0,80.99680626738905,-1.0,-2.0150273508270438,0.5150273508270438 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark56(0,-81.02774145186415,-1.0,-2.363915092620999,0.7931187658261022 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark56(0,8.104816049953643,-1.0,-88.19970317259056,0.01780954209926464 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark56(0,-81.29609004470755,-1.0,0.9501371132761631,0.5498628867238369 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark56(0,-81.45219688235696,-1.0,-44.075096850913866,42.575096850913866 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark56(0,8.153052735572729,-1.0,-21.450169990000802,0.07323001764214812 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark56(0,-81.86012102643632,-1.0,-0.3381602262867944,0.33816022688105574 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark56(0,-8.190573077287127,-45.260060683833814,63.594312186423764,-82.41599323829196 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark56(0,-82.09827920109463,-1.0,-76.89304590094788,75.39304590094788 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark56(0,82.78079674016767,-1.0,-53.812016403381946,8.881784197001252E-16 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark56(0,-82.96545248911737,-1.0,77.21191145200328,-75.64111512520837 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark56(0,-82.9866825703601,-1.0,43.66966568754066,-94.62146401913625 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark56(0,83.04098960848631,-1.0,88.07803906733696,-89.57803906733696 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark56(0,-83.08663189234434,-1.0,-18.383132385740254,0.021505400097903138 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark56(0,-83.33247702481385,-1.0,-0.6931153866283359,2.2639117134232327 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark56(0,83.42112283992344,-1.0,71.6548802673038,-75.27998120612548 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark56(0,83.50757672395329,-1.0,20.481128936450972,-21.981128936450972 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark56(0,-8.369183595018242,-1.0,100.00000000040085,-100.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark56(0,-8.36931463623215,-1.0,-21.274671330921734,19.703902530402775 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark56(0,-83.7729937307265,-1.0,41.225568302257685,-39.57124973172184 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark56(0,-83.99524456035573,-1.0,-99.99999791877444,100.0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark56(0,84.25457616823319,-1.0,91.94855551344536,-99.80253714741984 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark56(0,-84.42848560108555,-1.0,-90.59748371089279,1.2978157780434039 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark56(0,8.484983948528333,-1.0,-46.95419862264221,45.45419862264222 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark56(0,84.9247585460575,-1.0,-67.68195516103876,0.023208495130754264 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark56(0,-85.36671798340855,-1.0,52.60421428594111,-0.02986065561699114 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark56(0,85.83325718877916,-1.0,16.242664062188727,-13.032639503321604 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark56(0,86.44288137531089,-1.0,1.3731304746978705,-24.864279049826422 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark56(0,-87.2512114388825,-1.0,30.54356720028528,-32.021086606422145 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark56(0,8.742500845458224,-1.0,-36.657132255938535,0.04165809477288006 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark56(0,87.62792711755458,-1.0,-97.43334346900197,75.94771037879678 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark56(0,87.79685867034482,-1.0,-14.218993869719867,15.789790196514755 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark56(0,-88.04225107727115,-1.0,5.356570005694385,-33.63090844183031 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark56(0,-88.09760461813576,-1.0,78.98194971050651,-93.36085570145966 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark56(0,88.13774996187306,-1.0,-68.16518251972043,63.00963203564106 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark56(0,88.32645781830618,-1.0,32.84401367299797,-31.27321734620307 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark56(0,88.39462907653659,-1.0,55.01852832915781,-47.235343021978224 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark56(0,-88.53282438456272,-1.0,88.74127221669853,-90.24127221669853 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark56(0,88.67047547562099,-1.0,-173.14394962260272,100.0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark56(0,88.68209870451551,-1.0,94.33444987543112,-92.76365354863621 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark56(0,89.37372409577395,-1.0,1.897140464173509,-0.147077799796469 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark56(0,89.94309862905611,-1.0,-51.69770422792046,20.99169497915487 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark56(0,90.02564982503159,-1.0,-98.57764312805293,95.132725730896 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark56(0,-9.012441167642024,-1.0,5.593651596990738,-5.59365159668531 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark56(0,90.16132655779764,-1.0,-0.05206295179605474,22.694873092759746 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark56(0,-90.21375255279213,-1.0,-0.035686244210966944,44.016857518230125 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark56(0,-90.22939849563194,-1.0,4.142249731916147,-5.668914438646086 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark56(0,90.4715611436435,-1.0,-22.118377668389062,20.618377685673437 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark56(0,90.94293280937816,-1.0,-0.593441886412122,2.161455626650139 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark56(0,91.36588958897549,-1.0,-10.997030279987499,579.0765366031557 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark56(0,-91.46248044068112,-1.0,0.43326904631105956,-3.62545245308654 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark56(0,-9.165977366634266,-1.0,-99.99784102165427,100.0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark56(0,92.01820511058504,-1.0,-2.91102248600515,-26.93410772309788 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark56(0,92.19829485764082,-1.0,49.48784791068109,-50.988049357544 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark56(0,-92.26293214673798,-1.0,-33.261567170794905,23.896138756337564 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark56(0,92.35899538602743,-1.0,86.36616914199993,-37.22727433830697 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark56(0,93.24316063856077,-1.0,-1.6928729502940545,-21.792494322793587 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark56(0,9.387744581042568,-1.0,-0.08793134021479057,10.194320792023916 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark56(0,-93.89898295983522,-1.0,-0.22291560434521487,4.935303368354258 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark56(0,93.97321653658457,-1.0,-99.4959165575515,97.9251202307566 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark56(0,9.469077132122036,-1.0,-2.2575320255391587,2.435519654330472 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark56(0,94.73939356161456,-1.0,1.9827553308508277,-1.9139823521676234 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark56(0,-95.19090037756281,-1.0,-98.5,100.0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark56(-0.952487002453763,-0.7582611214802814,-1.0,35.43987942595983,-7.198804441882572 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark56(0,-9.54586622905677,-1.0,-57.96469998012486,59.47094100753887 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark56(0,95.48651651585783,-1.0,-2.9204568652033216,1.3496605384084253 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark56(0,95.63639995096597,67.22246540885669,84.38954006237392,26.808104667230964 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark56(0,95.79132713850895,-1.0,100.0,-98.5 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark56(0,96.1230501780734,-1.0,-98.49048873332754,100.0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark56(0,96.21282785498899,-1.0,-99.36128759713051,97.86128759713051 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark56(0,96.22681102597548,-1.0,-19.10800742732374,79.8173787337187 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark56(0,96.8338336029611,-1.0,14.686157601776515,-37.51874460943545 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark56(0,-97.11654971479653,-1.0,-12.965330177474328,40.52932430504407 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark56(0,97.48017935505251,-1.0,-35.94609307396868,35.94609307396853 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark56(0,97.55092301272512,-1.0,-88.82732963817175,87.25653331137686 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark56(0,97.67432972678482,-1.0,-3.9930668258145436,3.9930668258145436 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark56(0,97.96611709125436,-1.0,-56.03161997117726,57.60241629797215 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark56(0,-98.16533571022786,-1.0,-20.33132990214715,-9.51777704127532 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark56(0,98.26144516799114,-1.0,0.010128881827475462,-17.154083855038543 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark56(0,98.7314401650278,-1.0,0.06648616434135947,-48.69037596818826 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark56(0,98.73569723658186,-1.0,-61.756433208941544,60.18563688214665 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark56(0,98.91689622238133,-1.0,100.0,-98.50417386905576 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark56(0,98.9368883450086,-1.0,52.322315559301124,-50.751519232506226 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.24328801523893,-1.0,1.7525264617665997,-6.4654037085587035 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark56(0,99.35622603748573,-1.0,-78.13516177881175,79.65193422608283 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark56(0,99.94383771651992,-1.0,-100.0,98.42920367320511 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.97340232175411,-1.0,9.473305139761248,-11.044101466556151 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.99915777182548,-1.0,15.798893598563037,-0.0988536025020651 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.99982021497975,-1.0,-19.336731424547146,20.90752775134204 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark56(0,99.99998695386294,-1.0,38.6331070539151,-37.34163118097921 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.9999999718443,-1.0,-14.427126215498339,15.92712621550285 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark56(0,99.9999999999753,-1.0,-31.12784421510307,32.62784421507496 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.99999999999999,-1.0,-19.17832102581159,20.74911735260649 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark56(100.0,-0.02504870237281409,-1.0,6.240644824117622,-21.797278582623008 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,0.16687543160334284,-1.0,-75.64546507923637,74.14546507923637 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark56(100.0,-0.5704364541132136,-1.0,33.022953394893705,-3.5665630913160697 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-100.0,-1.0,0.17214152864998503,1.3986547981449118 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark56(100.0,-100.0,-1.0,-0.25306224540271316,1.8806336469451406 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,100.0,-1.0,-100.0,98.62927780651619 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark56(100.0,100.0,-1.0,-10.729039483719127,0.08645072044979807 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,100.0,-1.0,-5.6478117925256495,5.363094602883802 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-1.1368683772161603E-13,-1.0,-25.956675845259294,24.385881256993123 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark56(100.0,1.1368683772161603E-13,-1.0,-64.03723272902992,62.4664364022352 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark56(100.0,176.85898261859654,-1.0,100.0,-100.0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark56(100.0,36.99157025930742,-1.0,-17.940077288955216,25.778598054522185 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-43.730036401998916,-1.0,-7.743941086316387,0.20284197791360725 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,52.62679133966221,-1.0,-63.29922325515714,61.79922325515714 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-7.244382004007022,-1.0,-0.019313225417061958,20.276672031732748 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-79.43573960572982,-1.0,0.47180291287761905,1.100003702964463 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,92.81267835033664,-1.0,-28.74654008204627,13.927578256797258 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark56(100.0,-99.99456575587035,-1.0,-63.9911737462567,62.4203774194618 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark56(100.0,99.99999833478388,-1.0,99.99998887700141,-100.0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark56(10.61603258246286,-37.925560555550256,-1.0,0.04810028357451307,-32.65669576275046 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark56(-1220.6765419202025,977.5665586875677,-1.0,-80.08163454360005,78.51083821680525 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark56(1.284553989535413,0.22462987168755433,-1.0,-0.29749682005595446,5.280044090889625 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark56(129.67094626803282,-45.63802248298475,-1.0,27.646129062030838,-16.70700848462223 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark56(-13.554946800133477,1.01714462367539,-1.0,30.877950031643067,-33.89745005470882 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark56(-17.338258819393005,-18.864257209018888,-1.0,0.02336121848100789,-62.20703548783519 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark56(1.7928758093369659,53.998426913227405,-1.0,-74.93402608837354,55.8042992254595 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark56(-18.17671221406332,1.3079785087338003,-1.0,-92.56482895384153,4.936949713170931E-13 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark56(19.29163120413763,-27.046456438375472,-1.0,-39.79226801223276,25.533990217403158 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark56(-20.510106349747588,-100.0,-1.0,-0.9685542498386297,-2.173113595483153 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark56(2.211626460536587,-77.08856912610386,-1.0,-92.53001546655634,94.09362531353865 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark56(-2.242867883790717,1.164876126638256,-1.0,-59.87950005957289,59.462735808473056 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark56(-22.742088689890462,79.69752918975618,-1.0,-1.2923466666056778E-12,7.952374958266519 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark56(-2.53012388716904,6.129205507325892,-1.0,-42.81289558502587,41.31289558502572 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark56(-267.54274031816294,294.94046324602397,-1.0,-32.16065576824998,30.58986304033164 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark56(-26.775596120249606,-30.400251501979543,-1.0,-46.409039716150055,44.909039634998884 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark56(-27.855309633214215,-0.9803968427727773,-1.0,-97.96667170109012,85.07923433020022 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark56(-30.62604266901773,-1.237524019575984,-1.0,83.41554807953803,-81.91554807953803 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark56(34.9335715765676,-24.334624793773962,-1.0,-63.060861407195205,0.018035133475046546 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark56(-3.545699373371022,100.0,-1.0,38.77463846367906,-36.703728345314936 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark56(35.753624867912684,-68.29246772521743,-1.0,-0.044341435981522626,35.425021585892125 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark56(37.89050514794366,16.855196614091337,-1.0,-1.6505341818639436,1.4193623437276997E-16 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark56(-38.568907647378325,82.49740298988308,-1.0,-93.57535351105662,86.65519510045765 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark56(-38.71959291375049,86.57035691720493,-1.0,-4.514907938512906,3.5985208646626576 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark56(-39.072437301960974,91.00983854758216,-1.0,76.91985404038604,-76.6683517788545 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark56(-39.6439711083187,-88.13272666967572,-1.0,36.86134626032475,-91.14881571733846 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark56(40.406243013055985,1.7763568394002505E-15,-1.0,50.42560601852999,-79.81498797809495 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark56(-41.89376186408694,-53.32164151437956,-1.0,-100.0,99.24479822308695 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark56(42.60774940022682,-38.28433326532839,-1.0,55.277085990480025,-58.396426612761665 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark56(-4.27818743080713,3.6331844131509095,-1.0,-100.0,98.5 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark56(4.370568636733463E-4,-65.34135319770938,-1.0,-12.097880388241336,31.46400845814881 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark56(44.91896388994378,12.408742872767391,-1.0,-19.29608049792251,0.08140494267548347 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark56(45.44742836259022,-52.35780497762678,-1.0,0.1678375366584116,-4.391402839221507 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark56(46.408225092585035,-29.767547222615878,-1.0,30.84259034434616,-56.134630446424026 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark56(-48.51738375599538,-74.81539223781844,-1.0,-11.105375828055472,10.034579519223033 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark56(49.86245555416059,85.76832574605626,-1.0000006667742312,5.962644097092029,8.974375223854366 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark56(-51.46033013649374,-1.3012948111346732,-1.0,-1.9222864255326536E-16,1.6123752667961726 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark56(-53.273425733601634,-0.2378597102069249,-1.0,-99.99999999999999,98.4999999999878 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark56(53.51351413220515,45.494770024685565,-1.0,71.72025639411191,-39.74036947715021 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark56(54.67584096384701,2.452907980329144,-1.0,-59.08240843474378,60.58240843474378 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark56(55.179225243771654,-36.04050250911492,-1.0,0.02265246782815961,-69.34327591637575 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark56(5.704854554719721,32.660963247219726,-1.0,-35.74592026276466,34.55581418904859 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark56(-60.831644844406725,-75.33470079248173,-1.0,-2.4417617972430974,2.326520475547674 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark56(-61.74957883031794,-100.0,-1.0,17.297226354223152,-21.661744683163192 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark56(-69.49695648613287,100.0,-1.0,-100.0,33.844877859749204 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark56(73.09887495088444,-53.993677101917285,-1.0,-45.24320187074363,46.743527748204514 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark56(-73.83947930447744,38.05105942330971,-1.0,100.0,-100.0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark56(7.464131351010717,-1.075329327456905,-1.0,53.98618842248593,-0.019503327852278554 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark56(74.78426582707554,-75.12867828303716,-1.0,2.3765833473963314E-13,-32.99234771753518 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark56(-76.53373824495145,0.6502113107578822,-1.0,-91.86563627239536,48.88048560707233 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark56(-80.56501252344268,-99.40131557971404,-1.0,-98.55690381320915,100.0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark56(8.105789239552536,93.91577964116951,-1.0,48.79263683229169,-97.04118712218003 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark56(88.55721079895321,-56.1534868540596,-1.0,-9.489595595935299,0.15679945396868356 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark56(89.01208356393792,-107.26698381267175,-1.0,-98.5,100.0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark56(-91.13000607107388,95.13309616883927,-1.0,24.289015272113193,-25.789015272114813 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark56(91.58247201541955,30.428851093310655,-1.0,-25.933354160401574,0.06057050380291313 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark56(92.88486589478852,-36.2288333167512,-1.0,-51.67000203390184,58.55458474925487 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark56(9.856147724919948,-44.696593945300826,-1.0,-44.1109432907664,72.58235894813964 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark56(-99.99999999963515,-100.0,-1.0,-99.99999999993724,98.49999999989117 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark56(-99.99999999999967,-100.0,-1.0,-98.49999999999977,100.0 ) ;
  }
}
