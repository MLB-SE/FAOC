import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(-2.8376480483658604,4.451611778335703 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(-49.78639309472066,-0.7342014564377735 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(57.739233553473156,96.40683648373488 ) ;
  }
}
