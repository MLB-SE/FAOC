import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(0.11754495519237551 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(0.1604714343556104 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(0.3232993236470061 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(-0.49999999999999956 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(-0.49999999999999994 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(-0.5 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000002 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000009 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000018 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000414 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000003751 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000298397 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark31(-0.5558395530385307 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark31(-0.9405313808726667 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark31(1.0023046177833939 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark31(13.760684371357883 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark31(2.5 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark31(-25.5 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark31(-2.586023944866909 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark31(-2638.8101348091645 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark31(-2718.4202646300578 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark31(2732.6715140948545 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark31(2.9102968426700513 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark31(31.21045750544647 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark31(31.60314330009743 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark31(-32.58707600006858 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark31(-38.56441283935879 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark31(-41.48513789713317 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark31(490.8878456075386 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark31(5.157411773815369 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark31(-53.5 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark31(5.415557568531431 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark31(-68.50825945844667 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark31(-78.26011422731669 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark31(-81.5 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark31(-84.21100136495623 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark31(96.57117393565272 ) ;
  }
}
