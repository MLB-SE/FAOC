import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(27.511676689168922,-76.61782696747346,-6.987588600859425 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(49.84670122935154,99.57915067349703,77.38149742775641 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-75.36236413280933,28.65760392041621,-46.704760212393126 ) ;
  }
}
