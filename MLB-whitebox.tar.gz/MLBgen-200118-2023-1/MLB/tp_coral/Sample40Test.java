import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(0.9626906278709857,33.038558661343075 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(1.2110001783534485E-39,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(33.9643107654945,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark40(3.43622242256434E-11,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark40(4.8628795444470165E-9,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark40(6.262759446262137,32.9593964354835 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark40(6.830331347805008E-5,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark40(-7.26335708140849E-10,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark40(72.93747496532816,57.46062514044502 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark40(-7.355130986317376E-5,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark40(82.79839699888623,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark40(-96.87470786514427,0 ) ;
  }
}
