import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0,-0.0850006116700257,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(0,-1.3043957822388421,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(0,-13.445475232030503,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark14(0.15658057085656196,-0.3496992881855121,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark14(0,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark14(0,-25.242853775288964,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark14(0,-2625.824778113324,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark14(0,-2629.184516525112,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark14(0,-35.289528296610825,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark14(0,4.3368086899420177E-19,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark14(0,44.60189325585614,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark14(0,48.165199684899676,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark14(0,-4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark14(0,-51.52261494422188,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark14(0,-52.49036950456378,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark14(0,-55.060197904064644,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark14(0,-57.447970276060325,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark14(0,-57.96397864233398,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark14(0,69.80345146694836,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000004,-0.1774244355600989,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000009,-1.5707963267948948,-53.70888739262935,-0.10231564995010556 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark14(-1.000000000000007,-1.4102241851450321,-53.95710023941973,1.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark14(-1.000000000000007,-1.5707963265216829,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000122,-0.7035039810630475,-96.56682581331579,1.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.003035973499837776,-0.4415116239016063,0.6703589957942866 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.009218091579572976,-1.5707963267948966,0.336410744093013 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.014770463272720136,0.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.029761295963798673,-32.630985728846596,1.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.03181261523065875,-2.95960342071206,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.06250891591202998,-98.56671905747417,5.852095443365248E-98 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.0978981626892857,-1.5707963267948966,-3.499060014766859E-15 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.10253206248189883,-1.5707963267948966,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark14(-100.00102567334513,-1.5707963267948912,-31.864206564993907,-0.2789065205648029 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1213363823464988,0.0,1.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.129475002145811,0.0,1.0137510061039208 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.13436993274339756,-87.92849414923688,-100.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1379551729971756,-2.9395577419318712,-0.9412531891600158 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1537023898300134,-1.5707963267948966,0.9895003835417058 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.17245229810693274,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1727230571304021,-94.34651407654069,7.244841452308409E-9 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.17320422424148563,-66.29589925092712,100.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.19090727538226665,-0.023255611315975363,24.097104346089154 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.19683462694859036,-1.5707963267949268,-100.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.23419186013879312,-17.372707186134328,-6.748003408058821 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.2779148247700572,-75.25771342067105,-2154.605940211835 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.30320299873002243,0.0,-0.6038951699806048 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3073946973765792,14.444191930228769,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3266351952862201,-31.497287897592596,-1.0000003348863302 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3478976570444505,-32.871960730738515,79.42970120342548 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3539057157524905,-68.75753320889345,1.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3874279716486002,-0.5471290726300548,-31.583998198598284 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.39689442829608956,0.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3970965618829204,-36.41757791317378,-39.417623010859884 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.41176098942827977,-38.092704520443355,-1.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.41225654856778693,-67.09118876660924,5.3864439191627085 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.42732316269522413,-47.04680751727999,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4285291904906237,-1.5707963267949054,-0.8734944562790875 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4298184718197544,-47.167582931744626,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.43083073797672056,-42.613781692188745,1.0000003397004633 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4366913331782266,-37.17239918100925,-65.95032206823151 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.45053587462257305,-26.23183203935189,-100.61999421321413 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.49901277185981435,-0.2404973639573304,0.7487288884357644 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.513440093843013,-20.50290259460364,4.6816763546921983E-97 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5150577428863811,-72.44262344250126,-0.011047853578293187 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5236359472080767,-4.696237016119272,1.0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5268086911974733,-45.27321469119104,0.06260799924114151 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5368498552921346,-59.71572061850759,0.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.568246797644778,-94.24662153681022,65.94610305175567 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5827081964822564,-54.74259880257674,0.06256711818841908 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.590663595190764,-68.44853854586549,-1.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6174163685668279,-32.92129180150777,-2.3858463847700513 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6267000535864611,-88.07078117075659,-11.64220586064911 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6962883639230945,0.0,0.779458406080517 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.715544861597198,-28.845758299124384,-100.0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7281197102928271,-46.30034635471484,0.9886169219173827 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.735292975894178,-14.772042345646069,0.06255257095786723 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7761039484081246,2414.974830636323,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7774088504080902,-61.40816217486962,-1.2424250693264272 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7942326008048175,-63.39891841850148,-1.0000964630663782 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8126078518260957,-6.147289258838214,-1.0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8392167921732865,0.0,1.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8487480967573462,-22.27418019589294,-10.65389639605732 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8522783835144487,0.0,-2232.2003894760546 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8743869325943647,-24.691854972080996,0.05965348524469827 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8775235964659771,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8787869254533485,-43.138130682610075,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.879898025680539,-36.77885656637265,-1.0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8837196216213332,-36.57393755161924,1.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8848043756549817,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9323634039037291,-57.525097867832145,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9460240229503682,0.0,-1.2634920662350609E-175 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.952975767442045,-3.20539157796334,-0.34472857638357435 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9779819294614714,0.0,-0.9999999999999996 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9781348493874042,-67.43324792831642,-1.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0251169780167715,-67.42150602846063,-0.5797149433669437 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0266372322508139E-5,-55.54849977671506,-0.6452219942585821 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0304013187252674,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0356954694368865,-73.61185416874625,-0.867579274419604 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0559684303895123,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0735599950159127,-100.0,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0829967035376447,-100.0,0.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1102230246251565E-16,0.0,9.41686799148175E-7 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1458229969647815,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.167729045911567,-1.5707963267948966,-0.3300819739638762 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1788614698616282,-55.31643501841845,-8.31553046141174 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.188033390315424,-56.067122922446956,1.0282033095334786E-5 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1954133327321181,-0.11872269778469795,-1.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.200214536135863,-6.818239298469436,-0.9999999999997397 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2026701335370449,-66.12621979046762,-0.809353600919123 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2159939746088906,0.0,91.98784914651753 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2870523602860915,-100.0,1.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2938839780178955,-14.46728821785058,-65.94309010325904 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3148919476343508,-9.634011976272483,-699.7624123242576 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3354076032090862,-1.5707963267948966,-32.36659090915264 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.33943768217504,-12.157391622568348,2.710505431213761E-20 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3536024939520743,-21.04151422377494,0.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4131836645378222,-1.2015260464665303,-5.460205143797353E-15 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4148826809536152,-6.645509334857095,-29.898439139345705 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4244655508161095,-71.34658704082622,-1.0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.434848387030793E-14,-6.796450552752759,0.026851584485022166 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4436930853625003,14.430808524266176,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4721602778455127,-1.5707963267948966,-0.00872484617114444 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4770395453520524,-1.5707963267949125,0.06255793094786759 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4838877622872713,-59.05734243783471,-2171.027076117235 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4860214986182962,-10.598937186536139,1.0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.486923528247322,-4.301380340354569,21.401016568587796 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4885373521706275,-124.03023950683574,0.30125891528512144 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4928358933731762,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.516737012912388,0.0,-1.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.521289201305441,-100.0,0.06221700274242315 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5228218036447925,-1.5707963267949197,-0.40606907094533357 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5288876717206676,0.0,2.710505431213761E-20 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5443176696311014,-99.88372228996596,0.562336060699135 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5493134409209628,-24.592626317720374,-0.06255503852952984 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.557802128525969,-73.06322974837022,0.8262599030784799 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5645333909638015,-16.31224497999958,0.019784232506793675 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5655527105841363,-55.28889948470772,0.767042423350344 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5674386483443625,-66.01858778726626,1.0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5683832136288876,-100.0,-0.018485657184315663 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5705328982751372,-1.5707963267948966,-0.49349383341368147 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707482366828018,-1.5707963267948966,0.06255259942985152 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963250917512,0.0,-0.013513438073663453 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267942167,-1.5707963267948966,-0.0012930347686325172 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267946425,0.0,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.570796326794678,0.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948877,-80.38262843512192,-0.9999999999999998 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948877,-87.30521617516106,1.0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,0.0,81.50998164154265 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-30.674399178955046,4.927237505618237 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-32.268496208174426,8.470329472543003E-22 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-54.599917769700376,1.0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-88.45238589742783,0.9666388355287578 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948934,-81.94151380237595,-0.9999461862507841 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.570796326794893,-82.27136711487474,0.03505422686456883 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,0.0,-0.9999999999999984 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,0.051908218247471605,-0.03815886285955861 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,1.5707963267948948,-2.3353699699265578 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-5.6504418907426786,1.0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-67.52703525830256,1.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948952,-61.99682611158672,-1.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,100.0,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-20.91092717614034,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-51.409004503817336,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-55.81312822896243,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-95.68880301735732,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.8596235662471372E-15,-1.5707963267948966,0.015133285514230902 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-2.040782984265948E-16,0.0,-47.79702698030065 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-2.220446049250313E-16,-54.929092212868504,1.0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.2566125165915046E-15,-1.5707963267948912,0.02428105488403865 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.552713678800501E-15,-31.580153132377855,-1.0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.552713678800501E-15,-36.341709064926874,-0.03770796799746845 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.552713678800501E-15,-38.76984581825651,0.06313837989218563 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-6.003273051517649E-15,-26.03909730913989,-1.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-7.105427357601002E-15,0.0,-1.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark14(-100.1745034182713,-0.7188674376815167,-1.5707963267948961,-100.0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark14(-100.36117258908784,-1.5707963267948912,-23.319593467377313,-0.5120002429484292 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark14(-100.63477405416423,-1.541151916279246,-1.5707963267948983,2160.6979464700235 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark14(-10.069469232009476,-0.08301362194691103,-71.30367518219326,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark14(-10.090632627384316,-1.0194181457026008,-43.897929976772154,-0.0011274233479287438 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark14(-1.0098107124858906,-1.5633524820379359,-52.518033826842334,-0.3314757841458822 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark14(-101.06101521698818,-7.105427357601002E-15,-124.81942263012787,2123.17279376949 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark14(-10.139886455716676,-1.182876536184334,-4.513649935517627,1.0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark14(-1.014285428768462,-1.0854516477562814,-2.9044614650672855,1.0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark14(-1.0149099566306972,-0.9938302259491838,-8.61783998912554,-1.0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark14(-101.54297668950028,-0.4939206373615197,-1.2244745903650165,-1.0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark14(-10.15693232315397,-1.5707963267948948,-48.49271280774221,0.7632380877040728 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark14(-1.0,-1.5707963267948855,0,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark14(-1.0158923299520861,-0.10668126534206683,0.0,1.0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark14(-10.162052941686895,-3.552713678800501E-15,-100.0,0.9797044170406789 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark14(-1.019789250984566,-0.3180591635899166,-36.403031425440844,0.9968789990498311 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark14(-10.216483346054797,-0.5147906576206778,-70.16855549654908,0.1545210462027755 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark14(-10.226204509677244,-1.5707963267948957,-45.999646874120856,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark14(-10.241330404280147,-1.5451192151385515,-73.6516511981608,1.0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark14(-10.301518656063877,-1.5707963267948912,-67.08487212879444,0.013257817950289151 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark14(-10.308598940703902,-1.5707963267948912,-0.8330455242178931,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark14(-10.353334249075782,-1.5243642943680222,-6.604784673592677,1.3841950242605598E-4 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark14(-10.357365201413753,-1.5707963267948963,-10.716500982134452,-1.0000004226392327 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark14(-10.37954712854469,-0.49101604571508073,-0.09505038039094953,0.9999999999999998 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark14(-10.394915290264507,-0.6871525494000551,-63.96727494753228,-0.30070301746121997 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark14(-10.411377443709677,-1.50365711112327,0.0,-0.05354697025387595 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark14(-10.427378601422589,-0.47251537409726563,-100.0,-100.0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark14(-104.3633811480543,-0.9660460820684803,-49.11544665766458,2117.7477102450503 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark14(-10.501742656893796,-1.5707941997247128,-72.95652938396934,-0.7432193233108698 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark14(-10.512720309726275,-0.5407990209841742,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark14(-10.514086732136095,-0.3700448748744236,-44.130497169434804,-1.0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark14(-10.591758295012257,-1.5678190420829081,-46.58826670056795,-0.8532348540826674 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark14(1.0,-6.477269291344825E-15,0,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark14(-10.657281703197892,-1.1491593592792135,-0.025238891535151325,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark14(-10.69733947829128,-0.6662717548536237,-0.35896515100273324,0.13423427659240028 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark14(-10.69870051993847,-2.220446049250313E-16,-55.158009676837416,44.476519394812925 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark14(-10.708351241175817,-1.333227358867578,-23.099774991593527,1.0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark14(-108.06614162490553,-1.5707963267948948,-119.48603349708522,34.61259577876248 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark14(-10.817958679251252,-0.04377575166132153,-45.038446204778154,0.4040901157484225 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark14(-1.084761283989737,-1.2805399752207984,-60.79939164137651,1.0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark14(-10.860761648751229,-1.3809609737739899,0.0,61.329111339617384 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark14(-10.917453025230909,-1.474043410815137,-48.504663290906294,1.0000000000000002 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark14(-10.919747358196162,-1.5620573629555932,0.0,0.8836655919777155 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark14(-10.96804634577518,-0.8440731004651397,-31.593424410052847,-1.0316157210624082 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark14(-10.999811126013952,-1.5707963267948948,-53.158173087737694,-2.8451311993408992E-160 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark14(-11.003846692466393,-0.8083192497613034,-6.776263578034403E-21,0.023330085470953332 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark14(-1.1038309762054392,-0.10246756326339568,-36.77676624410009,-1.0000106297247675 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark14(-1.1066773916154204,-0.6999130415031178,-33.13381942557754,37.04515218534394 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark14(-1.1073195946473062,-0.024830841523695416,-74.59547935326466,-1.0795210693868056E-78 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark14(-11.186360906255757,-1.5707963267948963,-28.14511675195107,0.2700585757207745 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark14(-1.1293368222278244,-0.8729046434095981,-32.726222058311635,-93.27263373681431 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark14(-11.341811473007432,-0.5606963927749145,-32.89366525725674,-31.643478763094564 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark14(-1.1364059085548366,-0.6133952313743264,0.0,1.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark14(-11.392514689426578,-1.436560192952458,0.5769815671878344,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark14(-11.423382550762478,-0.35515451954840505,-16.50632592038663,-0.05731977182253849 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark14(-11.456582667777303,-0.044949890110720626,0.0,-7.7078179957789 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark14(-11.45747100630753,-0.5542611100542285,-78.33611152667487,0.061972119678639845 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark14(-11.521958900847872,-0.7432138470020155,-18.68389833212469,-31.153142607203925 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark14(-11.628558166816644,-0.9889416213592067,-26.318351532410645,16.91470506157924 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark14(-11.654876418910831,-7.105427357601002E-15,-66.9908375541431,1.0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark14(-11.68299220795611,-0.2742684291399635,-90.72932343059361,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark14(-11.684616610564774,-1.5105322950688649,-36.996222969472996,0.0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark14(-11.73265943115484,-0.008886145240290126,0.0,-65.02436663098678 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark14(-11.792798980775231,-0.16757363929076208,-186.57539820244267,47.605461382018035 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark14(-1.1799459333326592,-1.3395154147571107,-1.7763568394002505E-15,-0.36216514486243007 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark14(-118.18771612868024,-7.105427357601002E-15,-122.95417480249631,100.0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark14(-11.90294988722178,-0.6884029474428228,0,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark14(-11.914508630444296,-0.1395315792886862,-6.646359793160769,0.6815328185871616 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark14(-12.062967994791407,-1.37173442427681,-0.6127968124262395,-1.105460256506979 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark14(-120.84640754025995,-1.3710298400337717,-36.620204528071206,1.0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark14(-12.090007412633682,-0.25794342264666736,-59.58734635304607,0.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark14(-12.126920917444263,-0.13108166597686072,-15.670473165223967,-0.9423901056073309 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark14(-1.2211999096756816,-1.570791797781778,-1.5707963267948966,-2251.2328927090357 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark14(-12.315818464508611,-0.030971181364704337,-55.02944760443762,-0.9317714859223563 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark14(-123.70078609571065,-0.17610605384967803,-15.106668796626625,0.0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark14(-12.382384134881566,-0.645934498818187,0.0,0.9616382746112917 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark14(-12.388116412692156,-0.17851622255061983,-19.149401926219326,-1.0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark14(-123.92737974686214,-0.9138845632344892,-18.231967521954644,0.0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark14(-124.55661967350927,-0.788391944034271,-134.81774236097758,-0.9999992454648288 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark14(-12.456868084400313,-1.5707963267948963,-100.0,-1.0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark14(-12.470120080296782,9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark14(-124.87874998564774,-1.3544826715771852,-70.90656110210213,2131.026845903865 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark14(-12.561247400442426,-1.1284720430582693,-40.83229203090677,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark14(-126.81240537203904,-0.7835068007457335,-1.2908187879282504,1.0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark14(-1.2789695891866482,-1.5707963267948948,-100.0,-1.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark14(-129.13358893420315,-0.4344061703998081,-89.75112868755286,-2051.702308472556 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark14(-129.59191910328457,-0.6820095430853996,-221.10134428307947,-1657.4557844168244 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark14(-13.081061687080142,-0.6796781492950039,-4.4112010843169855,-51.364261889301474 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark14(-13.10909763050806,-0.28979040962916613,-79.4364426844999,1.0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark14(-13.194666621847269,-0.8591504289534235,-54.51402287572881,0.920744838397997 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark14(-13.251539928059474,-0.45792288043201634,-1.5707963267948966,22.451363572675138 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark14(-13.25938458304989,-0.3611350019511175,-66.42869985347201,7.105427357601002E-15 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark14(-13.302729207687248,-0.09661655265897576,-21.303967965350576,-0.03600350776080186 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark14(-13.309029948376413,-1.5707963267948948,-32.79918989504702,0.06169430788182673 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark14(-13.346446829527808,-0.2110125106186329,-97.98193870411777,-30.355738717301183 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark14(-13.40106337460685,-1.5707963267948712,-54.97787476434397,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark14(-134.83729271708867,-1.4565705583790276,-63.67354778436504,-2197.434682211664 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark14(-135.2328205762592,-0.5978391431577723,-100.69238566256115,93.3222519970518 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark14(-13.532737683201832,-1.480962466285554,-9.721105190661703,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark14(-13.621718813905662,-1.3609870911907787,-39.59154096123572,0.09297372336277299 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark14(-13.71538899010889,-1.5707963267948963,-10.725218455221492,-1.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark14(-13.759827775268004,-1.4137064869228522,-13.366600971053465,-0.06256608144970112 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark14(-13.823463025771552,-0.6419599064390139,-71.44159353497187,1.0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark14(-13.824033641766306,-1.5707963267948912,-36.39528753286178,1.0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark14(-13.879051569219666,-0.7862136544571658,0.0,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark14(-13.985783078905854,-0.24712199976210592,-23.433337284816538,98.62196238513421 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark14(-13.992872543461504,-0.3835466311341421,-98.23834211796083,-1.1704190886730496E-97 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark14(-13.99774146997958,-1.859250197994752E-6,-30.23460500428473,0.06267077905784954 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark14(-14.092995194404496,-0.9221940829534129,-58.45090952422632,-1.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark14(-141.44744024756648,-0.32713839122303057,-83.79909018736282,49.513805697854224 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark14(-14.169524024707243,-0.6189136269584897,-13.688308537788824,34.463416256686685 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark14(-14.233916574967822,-0.14066594438897706,-58.4429520357517,0.9580449108228324 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark14(-143.0678025826957,-0.7158509165622443,-21.632467310796386,-1.022237973434498 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark14(-1.4335405543117632,-1.3279606966771624,-95.50906770099543,1.0000566231320482 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark14(-14.341404439780248,-0.5835682139462904,-50.3072528074123,-0.5406731018017054 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark14(-143.47107536898932,-0.25145965837007,-44.54517238681988,-0.39475895026577656 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark14(-14.352641191591188,-1.2915487636626617,-1.5707963267948983,-0.3404267477802473 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark14(-14.371544812513747,-1.5707963267948957,-27.951192944319615,-45.995508652323245 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark14(-145.92339112696652,-0.9981839397820319,-1.5707963267948966,-0.9506168740142653 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark14(-14.598696936655514,-1.4210854715202004E-14,-61.4174651685669,-36.618170956640014 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark14(-14.627261574690937,-0.2862700802762316,-72.36963604648919,1.0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark14(-14.628163404996222,-0.34510872675073334,-10.858283497302395,-1.0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark14(-14.635151330268059,-0.022230510676039483,-45.24761888376419,0.7453900081741345 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark14(-14.651615944022785,-0.38474788119948605,-78.4717897590148,0.056039290602372144 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark14(-14.675593080607547,-0.07501956942251943,-43.92451698866107,-0.2315350021243725 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark14(-14.700289474355662,-0.2198213745521264,-5.678438157354989,1.0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark14(-1.4722917718367916,-0.7392049072179286,-18.166140559665884,-1.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark14(-14.896162037459481,-1.3026415618139013,-37.069842234468894,1.0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark14(-14.944941013660948,-1.0224098587871358,-74.85305678532478,1.0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark14(-14.993385811230551,-0.16905159234596423,-0.39480727102011337,-0.9394637950322873 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark14(-15.011299207345695,-1.5707963267948961,-18.775051407942616,0.010845669651864787 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark14(-15.244700163371832,-1.4463596393621259,-1.5707963267948966,20.90004281941387 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark14(-15.349140609983525,-0.0014191406008079207,-45.48584629664403,-1.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark14(-154.84835203399172,-1.308086483702058,-1.5707963267948966,2003.939389750878 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark14(-15.492420667653485,-1.197417060754291,-66.99023764341949,-46.86426990896872 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark14(-15.528105853493884,-1.0017061573894779,-96.16471526807385,-10.610430143990541 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark14(-15.534970366733328,-0.5918153391387941,-4.203169003673427,1.0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark14(-15.70613607656309,-1.5707963267948912,-66.50210796991743,-4.418052297126877 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark14(-15.764395139995607,-1.2031803315751848,-95.58766796165537,1.3669393784155592 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark14(-15.783015971341648,-0.019490460511482458,0.0,0.0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark14(-15.948640896401464,-1.5232641431567615,-27.268037270006246,1.0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark14(-15.961050714712158,-0.556209961731722,-20.82373747409816,-0.3652205582177471 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark14(-15.981144324823171,-0.7422624390376505,-64.3175780800036,35.36995500575671 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark14(-16.017342020306025,-0.23316406905747858,-29.176216499730458,-17.248522808200946 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark14(-160.21832642240062,-0.8763128609807798,-0.2648769857652111,14.18270724346283 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark14(-16.062379518508628,-1.5080414282307044,-59.03283966372535,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark14(-16.0784921941803,-0.47667099283664527,-1.5707963267948983,61.882298124968315 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark14(-161.2098437792285,-0.9729159600558184,-122.75451013736985,1930.6843065336718 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark14(-16.121719668435613,-1.566271024927914,-1.5707963267948966,0.6359796651291085 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark14(-16.199475139945342,-1.4337391711502123,-69.40309177898067,-81.85672670017013 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark14(-16.298853861185677,-0.8552923483116478,-51.22264125826146,-1.0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark14(-1.6341148569620465,-5.59642434592611E-4,-95.25238639925261,-32.19993555906042 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark14(-16.53393362377188,-0.05775780870194963,-1.5707963267948966,-1.0166628297728793 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark14(-16.56698365139438,-1.4749952310693706,-0.012424707116743358,15.788991591166535 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark14(-16.602220461437614,-1.2703074128187968,-73.30138440261831,-0.03552452805423534 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark14(-16.607713796194815,-1.0471975511965943,-72.02805349276731,19.549542165719203 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark14(-16.660771358314364,-0.33296529359527227,0.0,-95.94466676171653 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark14(-16.66484169523958,-0.6325821832453447,-88.47485577934717,-67.99943986805715 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark14(-16.714948483660464,-0.8287790271449571,-1.527968821607188,0.9999999999999996 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark14(-16.729668236276794,-1.5E-323,0,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark14(-16.784161771476608,-0.8966005327280471,-37.90497219623173,1.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark14(-16.86248823926226,-1.5707963267948963,-45.660132864638584,-1.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark14(-1.687838552208376,-1.7763568394002505E-15,-1.5287695691011767,1.0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark14(-16.89475258885891,-0.02073999815870893,-83.59888044289582,0.029233667763775784 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark14(-168.9806786779176,-0.07636853107163144,0.0,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark14(-1.6961194349646858,-0.0018585236097012011,0.0,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark14(-169.65290288201436,-1.231549091986312,-5.987465375955255,-2117.711781674453 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark14(-1.6979619441793132,-1.5707963267948961,-1.0745816040510086,-0.8513912004191029 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark14(-17.047356211857554,-1.5707963267948912,-1.0271660480745375,2.220446049250313E-16 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark14(-17.048673851915673,-1.5707963267948957,0.0,48.41672901973132 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark14(-17.054817273400534,-0.17334152311659612,1.7763568394002505E-15,-1.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark14(-170.92558039210576,-1.3996435154788078,-36.24091955812467,-1.0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark14(-17.11594959997728,-0.7939745378757405,-78.19473013094527,1.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark14(-17.14910442283716,-1.029701776952067,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark14(-17.16846528990462,-0.44880275712469286,-66.5189035038704,17.528744149364655 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark14(-17.21681194779118,-7.105427357601002E-15,-17.62076740406637,0.8135482634308324 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark14(-17.242411123818158,-0.3870765013744555,-1.5707963267949,-8.28701844226893 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark14(-17.264995088558578,-0.19827319141773359,-97.82800405394102,4.416459982111888 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark14(-173.5504164530715,-0.5967425253438821,-4.894227750733847,-0.530329496271932 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark14(-17.393188702240074,-0.7431722995801957,-83.15558170213389,84.78718894832274 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark14(-1.7401992697546405,-1.5707963267948568,-1.374554903687028,-53.57722397755143 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark14(-17.408726155695575,-1.5352563363369174,-67.37830751859124,1.0530754349757003 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark14(-17.449726410120387,-0.3535826454468151,0.0,-0.9305505335125778 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark14(-17.480416588509147,-5.879401113621942E-18,-1.5707963267948966,1.159357831526685 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark14(-17.506850506086483,-1.3950289701477068,-52.76671644999825,-0.9700309246868135 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark14(-1.7516821154540028,-0.737626923759805,-119.30803631615969,63.38104923670127 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark14(-17.537448856902135,-0.09551210880740693,-0.03614514613328505,-1.0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark14(-1.7551152034830322,-0.016770516201177085,-53.9518524621974,0.8676379782328568 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark14(-17.669377853583555,-0.05953468561445162,-71.66312834076835,0.0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark14(-17.673826088978345,-1.5707963267948963,-5.254233614203141,-0.36208931660298715 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark14(-17.673988757853753,-0.48634187566889986,-83.36113755562184,0.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark14(-17.713831573950234,-0.2842934301860036,-44.46853068589923,31.93374039503871 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark14(-17.747896660077714,-0.5010198428362179,-14.354638000589823,2178.6901265790825 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark14(-17.777914654517346,-0.8964003149258843,-1.5707963267948966,89.3594198517182 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark14(-17.800801629246216,-0.966329102155818,-0.7908364923431067,0.1388576525265477 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark14(-17.800988251442288,-1.3322452569327463E-16,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark14(-17.88653390654308,-1.5707963267948948,0.0,1.0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark14(-17.943147696815682,-0.529587158665052,-45.5000013201896,0.0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark14(-17.9448125900592,-1.570796326794893,-2503.483718886346,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark14(-18.026650991195933,-0.5122688598599336,-67.70085783279981,-0.32649663750854424 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark14(-18.049531987983993,-5.413874610265293E-16,-44.72070371440549,1.0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark14(-18.081430880293325,-0.7647072105345749,-6.915446328407803,-1.0178587966879564 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark14(-18.131169291384065,-1.1002175749880947,-4.524770435480212,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark14(-1.8148675482136554,-1.5707963267948957,0.0,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark14(-18.18047664462467,-1.5634988323105339,-38.80868243650265,-1.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark14(-18.20363513014516,-1.5707963267948963,-20.478532726246705,-72.5544090316814 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark14(-18.245708479322744,-1.547374589665509,-97.19890216727305,-1.0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark14(-18.32539789192046,-0.7204182224341414,-10.764546811093382,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark14(-18.34169679128672,-0.7150056332121864,0.0,-34.88692478673643 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark14(-184.1963535991125,-0.15473251377138225,-53.754818057106036,0.6811568356615652 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark14(-18.4550068762264,-1.1360009739376338,0.0,26.302460630166262 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark14(-18.4691002475033,-1.0401164724437348,-45.40627683790782,1.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark14(-1.8520630626153523,-1.570796326794891,-13.704822746454255,1.0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark14(-18.586391830900695,-0.18373056614124073,-65.67129453247446,0.5175479043823934 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark14(-18.636021525027758,-1.5707963267948912,-67.53220062053734,46.17627503340631 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark14(-18.662418532215007,-0.17505834226036646,-18.817415646799077,1.0245383242803878 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark14(-18.7065517758692,-0.33304588930388346,-33.98335565078051,-77.28053886133277 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark14(-18.823597715753603,-0.40928852695734297,-1.5707963267948966,-46.01897292038776 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark14(-18.837295803193626,-1.3251074612511258,0.0,49.20443337414908 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark14(-18.854418404505253,-0.16643678722802607,-46.815133075282304,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark14(-18.94840894851086,-1.5707963267948948,-0.25811055354101564,0.07449444041884079 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark14(-19.076866605515793,-0.5956884150069258,-1.5707963267948968,-53.846297203616324 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark14(-19.103276804602018,-1.2236981714448945,-40.062722579943575,0.06191756471590716 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark14(-191.7429746753356,-1.5160988811910698,-55.83941171158374,-85.12318006409326 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark14(-19.17524114754506,-0.2189685817744405,-89.75297717994495,-1.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark14(-1.9183819068073344,-1.0801807779929389,-63.631658944143,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark14(-19.316155801988202,-0.04847915606754152,-21.47320105164323,0.5429273069043887 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark14(-19.367189517161584,-2.655548551112422E-4,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark14(-1.9373489592583608,-0.7770901724213957,-39.10247341129583,-100.0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark14(-1.9378371709043023,-0.832341432720411,-1.7119739729767929,1.0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark14(-19.415882705454298,-1.2938702324140792,-57.579716939362484,0.9288119907126874 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark14(-19.432038197748852,-1.463149764786675,-53.85146006184567,-0.4921433628178079 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark14(-19.435914475899438,-0.33926280563427924,-53.83520792816054,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark14(-19.49865948909632,-1.5707963267948912,0.0,1.0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark14(-19.506473046649354,-0.032334160856253576,-0.0595257769716806,1.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark14(-19.510512154820724,-0.12954177430507652,-92.48576696292099,-0.17148964107685105 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark14(-19.529529861095746,-1.5455859162190482,0.0,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark14(-19.591659652539185,-0.007308016733641967,-45.574688234324,-0.9999999999999991 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark14(-19.60075937732008,-0.867848735571101,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark14(-19.60607709661511,-1.3285146875836489,-14.414230873032976,30.31457234265578 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark14(-19.617454887591308,-1.5707963267948912,-37.43930538227838,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark14(-19.640492457822884,-1.1536707747214325,-41.620883009299476,0.6810511706149915 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark14(-19.659901253570844,-0.558897587657177,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark14(-19.69430750791228,-0.7582477989449563,-10.011162944072026,49.566903917213 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark14(-19.70970323350228,-1.8212194049489182E-16,-1.5707963267948966,-1.0000013191097332 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark14(-19.710765452206868,-0.31841019976450546,-35.00513310571567,-1.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark14(-19.71241736651622,-1.3604639798134477,-89.84724925748766,-0.10290346426258934 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark14(-19.712554662178356,-1.4215770913514547,0.0,16.533880559788923 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark14(-19.718557396443202,-1.5574398794204938,0.0,-1.0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark14(-19.729666107477016,-0.1800888522364127,-3.177162946321289,1.0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark14(-19.87194295586727,-0.21892928628436908,-59.72607761821318,-75.90333514383218 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark14(-199.32630785163846,-0.5625225183452011,-94.95237089256769,1.000000342042894 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark14(-20.014283918218606,-0.6762347146551673,-169.28675923041592,-1.0000000026805211 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark14(-20.033430297742953,-0.725469807248852,-95.55326520632364,0.9999999999999991 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark14(-20.066615307461205,-0.4380902124113959,-80.11266585853612,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark14(-20.141200013579144,-1.3663876000446997,-25.830739017334242,-34.95583904251551 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark14(-20.1783165055146,-0.6439783787067921,-1.5707963267948983,0.5375680244532393 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark14(-20.25850235386747,-0.48089422802494597,-77.2937646673312,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark14(-20.285077871206195,-1.1523389029244169,0.0,1.0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark14(-20.30395799873665,-0.027094884632594785,-1.573840008308627,-0.9607355624870833 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark14(-20.328602067901457,-1.526442077855031,-14.474649584168418,-5.752262051204042 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark14(-20.499629363410087,-0.08141662183281628,-77.84004230796968,0.3993641697833126 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark14(-20.553585681541804,-1.3860913709134337,-34.24115575037898,1.0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark14(-20.659344575956478,-1.300642553286309,-57.19775198772505,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark14(-20.66510613831727,-0.5127403093595091,-100.0,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark14(-20.669199776007616,-0.030459607128596106,0.0,1.0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark14(-20.70708853511212,-1.7763568394002505E-15,-65.54482061569448,-0.053264091537378766 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark14(-20.771623364042085,-1.5707963267948948,-86.37843654006167,37.40131797161939 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark14(-20.797502810445003,-0.02850649368716045,-35.10615764756364,1.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark14(-20.836667258200908,-1.5707963267948963,-0.04152686973294467,-0.015208815001322916 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark14(-2.0884515857056534,-1.5707963267948961,-97.63757715156196,-100.0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark14(-21.027897012565816,-0.7378292732358168,-1.4570304631863447,0.9684226700182887 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark14(-21.04035119803514,-7.105427357601002E-15,-5.763312399397577,69.90622619404019 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark14(-21.058907278993175,-1.555624350312955,-10.545326964575288,-1.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark14(-2.1090458201376263,-0.3461013225634474,-67.07172213886216,-1.0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark14(-21.15559810763519,-1.4318288068207152,-1.5707963267948983,0.9103218153736381 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark14(-2.1182448121558184,-0.07706094228354222,-32.533436382083394,-1.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark14(-2.1184436689711106,-1.2710662726505046,-1.5707963267948983,-18.49585524822386 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark14(-21.241948213767614,-0.8170080783041916,-100.0,1.0000000000000002 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark14(-2.139247031996162,-3.552713678800501E-15,-14.508337697878497,-66.35749060542607 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark14(-21.553812725849486,-1.5697144212137333,-32.496040808798604,0.5448806051840419 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark14(-2.1604372694633867,-0.7234928023214211,-88.15370055386371,-96.6769488935434 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark14(-21.606317441769615,-0.2963136583374555,1.4409104131695623,-1.0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark14(-21.620311748195583,-1.4665483620062831,0.0,0.5139322294535705 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark14(-21.630853267636155,-0.18347229647275864,0.0,-0.06256711670992231 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark14(-21.6553425901039,-1.5707963267948948,-58.89631454293114,11.413520614319737 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark14(-21.723830419836816,-0.38216129132714594,-98.58131815814646,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark14(-21.740660343588797,-1.3717861862918463,-49.82061379811529,-1.7782935326173401 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark14(-21.77204713154252,-0.22684455164364836,-66.21362142743996,1.0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark14(-21.79985511085954,-1.5262734790787036,-70.41017722438475,-1.0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark14(-21.84207802225001,-1.5707963267948912,-12.357697687821176,-1.0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark14(-21.918240900429627,-1.5707963267948948,-1.5707963267948966,-0.37748407907834125 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark14(-21.941699336768828,-1.3607608917642253,-3.4102613382051916,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark14(-21.947520788693073,-1.419323215286998,-42.524611916019865,-0.6355888673866879 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark14(-21.97634845074778,-1.0016366261877656,-36.39622462078954,1.0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark14(-219.77254628095787,-0.3869650889398584,-0.9435982472588609,-1657.459832873103 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark14(-22.039734419946015,-1.5707963267948963,-73.21458508022592,-1.0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark14(-22.052213070912586,-0.6162412099440608,-40.62451861373263,0.9406575475993495 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark14(-22.062771317670084,-0.18630683703744766,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark14(-22.093037468236673,-0.7423669026803363,-75.44538092778559,-37.30750975618524 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark14(-22.12740032170936,-0.5168732273745746,-163.76416454649447,68.28037050809536 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark14(-22.14957512673997,-1.0046467071077498,-7.8678087948754225,-0.06261300165125105 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark14(-22.156398516615575,-0.029434154972765348,-1.5707963267948974,-1.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark14(-22.180628202309997,-0.3262229715509939,-80.09420847424856,0.9890474489436283 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark14(-22.220912184655848,-1.570796326794568,0.0,-1.0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark14(-22.34212898481914,-0.07960595392074638,-61.15374298780699,1.0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark14(-22.349783300567303,-1.5707963267948957,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark14(-22.385915990665538,-1.5278943461380126,0.6970629674123056,-0.023706959668859398 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark14(-22.389175892021427,-1.163826587753699,-49.465839567508596,0.21725624894417395 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark14(-22.52703700009881,-0.45571698787447984,-1.5707963267948966,-16.79956159749673 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark14(-22.58177010478898,-0.4662063263506402,0.0,-1.0001549890389447 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark14(-22.60758625907443,-1.5707963267948841,-49.44431404173513,-31.35583427621774 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark14(-22.67824747631728,-1.1447674313353389,-38.031716082485815,-16.42317472770243 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark14(-22.827151530316044,-0.2724197932882628,-19.237352170744614,81.69386569849598 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark14(-22.875546985765272,-1.5707963267948963,-1.4807074151274355,-1.8175504980315845E-8 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark14(-2.288994283365532,-1.3428360894832145,-29.7577950065929,1.0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark14(-2.289892848858983,-3.552713678800501E-15,-10.93628587837638,-0.04199042214892815 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark14(-22.917250748324577,-0.05250895391998445,-1.5707963267948983,-0.020091489779480942 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark14(-22.962069507175016,-0.39663586686781804,-30.23347264767959,20.30488923280747 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark14(-22.970211713296713,-1.5707963267948912,0.0,83.73184152404052 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark14(-22.973299205135493,-0.005340654435883607,-99.03945916827035,-163.57620388251829 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark14(-23.0388789386681,-1.1689174823632942,-14.24822234619782,1.1376711995324168E-5 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark14(-23.165687708059608,-0.04223205729777893,-88.17449723534175,-0.3503769046562478 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark14(-23.314513543422137,-0.44741665736034153,-65.8587272450793,-31.753885758018612 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark14(-23.335285826971326,-1.3364558150352486,-48.014426077126664,97.52006598303343 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark14(-23.34176481045834,-1.2317818782770367,-1.7358932356235357,0.9560357613687266 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark14(-23.450621787819845,-0.6562143099244983,-24.575320076855846,2.710505431213761E-20 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark14(-23.457372087323332,-1.5707963267948948,-1.5707963267948963,0.04239358809424873 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark14(-23.512540459741956,-0.010010328687265257,-18.299578812513445,0.22297630830570458 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark14(-23.515336646790043,-0.45751968033341006,-44.225541618960655,-2.308244654446434E-128 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark14(-23.619876798499178,-0.5125643233712935,-167.79653389509477,0.21394934483650763 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark14(-2.3634779910218526,-1.541284327524607,0,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark14(-23.706556333226906,-0.8049401295088984,-55.25282085847114,-0.7191826532497458 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark14(-23.71974706826717,-1.5701215744286887,-100.0,1.0000178796250694 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark14(-23.724846487321724,-0.9385144488404116,-99.43911798588267,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark14(-23.746339105788365,-0.11001752455248237,-39.99950123331718,0.41111368858817166 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark14(-23.75807076325472,-0.04525444681982103,-54.77035244625077,-0.0625729993944132 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark14(-23.77624048271501,-1.1185629579606438,1.7763568394002505E-15,-0.4809267936603946 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark14(-23.850361460311134,-0.07740069634925373,-100.0,-1.0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark14(-2.3856282319943602,-0.028088329646266296,-1.1266915908036652,59.072761060606545 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark14(-23.879149278989686,-1.5707963267948912,-37.36220977164837,47.85275900801386 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark14(-23.91046799747658,-0.21450026715418313,-65.24364355927774,-90.17735970365935 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark14(-23.941681216297226,-0.31171465971882384,-10.848369418148437,1.0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark14(-23.942642305290423,-0.17135944678892434,0.0,1.0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark14(-24.05647400868702,-0.600631781763866,0.0,-12.168240032297618 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark14(-2.4079326567125143,-1.4998465582520921,-9.818660031138595,-0.9683025540079687 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark14(-2.4089267453844343,-0.6059471673070249,-25.069589935744887,-2196.0804025240695 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark14(-24.176160714758836,-1.3136485390713206,-14.5851394642349,48.12854312803495 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark14(-24.21079280067335,-0.25163117081637526,-2.8298494794656124,-35.71165385331224 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark14(-24.22689527497522,-0.3390618849848578,-83.34655389823295,84.7704004164159 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark14(-24.24945557248581,-1.5707963267945886,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark14(-24.29117537390166,-1.00393110145861,-36.26662130444531,-0.8969652280494511 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark14(-2.4474825406839966,-0.09241792139668803,-88.33926451503937,-2165.6755961573567 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark14(-24.640036172600915,-1.5707963267948957,-7.961456972623036,0.4149848494255512 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark14(-24.68347744983759,-0.3431304485678144,-86.2391061247662,51.31447993034121 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark14(-24.73870519250388,-0.8592215021991837,0.25757757826187344,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark14(-24.810891183998155,-1.231432293612218E-11,0.0,0.06146157800075965 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark14(-2.483411120137262,-0.7267703605504175,-33.724549751953575,1.0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark14(-24.872000987501213,-1.5707963267948957,0.0,-0.01882454013302169 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark14(-24.875586943295353,-0.11845859399793834,0.0,-12.07919877191905 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark14(-24.878895870234427,-1.7763568394002505E-15,-1.570552717279571,0.08123224027899573 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark14(-24.962607267997463,-0.11271700278961383,-1.5707963267950618,0.9460082877004368 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark14(-25.01643576481689,-2.220446049250313E-16,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark14(-25.060742630667093,-1.1086330356859964,0.0,0.8140793190261956 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark14(-25.124592451722524,-0.0433356799377651,0.0,70.06114068786171 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark14(-25.12766632717901,-3.552713678800501E-15,-1.5707963267948966,-70.23866544216972 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark14(-2.519316665048928,-1.3408272715886271,-0.99962990743094,-1.0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark14(-25.25707759736932,-0.11606281971304398,-10.565211762109882,0.9128693627223026 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark14(-25.404386139928796,-0.04756887481278244,-99.22724911425875,1.0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark14(-25.407382411983768,-7.521237368142792E-4,-64.87456054963461,1.0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark14(-25.40786874238919,-1.3041097853346635,-4.711554851437892,-0.029606016508177513 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark14(-25.459548837857927,-0.06571596523114308,-48.54482850698641,32.61877936735692 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark14(-25.49972112714596,-1.5501792366626186,-70.29975252349084,1.0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark14(-25.549868187544426,-0.9370266294235368,-28.742382169264477,-0.06196289526907606 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark14(-2.55659172828922,-0.3576510722871973,-94.71556823946933,-30.983204413255436 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark14(-25.617090691986178,-1.5707963267948868,-31.775883953155535,1.0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark14(-25.628755438107564,-0.18919512099487323,-25.667715134761224,0.9281027705557646 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark14(-25.64710448976446,-1.5600257750261435,-1.5707963267948983,-58.22740548114653 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark14(-25.744186347965112,-1.5422224733750545,-67.78296121153593,0.2520339784732738 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark14(-25.752883349053846,-1.5636235506386844,-1.5707963267948966,34.59710623004941 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark14(-25.77818646322989,-0.4878460065605381,-44.30774885441156,0.43990879491265833 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark14(-25.80799601986119,-0.6307430290134107,0.5482745451379831,-0.010787209980242074 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark14(-25.8529629193699,-1.5707963267948912,-63.251576457221844,0.4319568854313065 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark14(-2.598096577834884,-1.2145784385233194,-63.854266985239335,-1.0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark14(-26.110309971647688,-1.5707130609478552,0.4021188086264163,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark14(-26.212696164393904,-0.13960113545842653,-32.04876462568461,-0.8540661282711028 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark14(26.2330994765596,44.52477794103007,83.0102777407013,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark14(-26.24036916696752,-1.570796326794893,-1.5707963267948966,-0.9999999999999997 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark14(-26.256259114344427,-1.5644069487404695,0.0,-0.6524451002610938 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark14(-26.310130196460534,-0.13939754381467206,-98.44201080032177,-95.55462038324232 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark14(-26.355989529659453,-1.5707963267948912,-68.64925360286902,17.497973711073328 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark14(-26.403510795570384,-0.8687946680075525,-1.5707963267948983,-17.994546960462827 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark14(-26.423953163208324,-1.7763568394002505E-15,-3.4993982525301344,1.0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark14(-26.591890171334622,-1.5024814283476227,-31.96585693263361,-0.9999999999999964 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark14(-26.743040300334375,-1.5683273020559338,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark14(-26.814936453974326,-1.3954042666037316,-4.570402838455962,0.08405069909187546 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark14(-26.833056035780828,-0.8285823677190031,-0.477717397874085,0.7293184639886072 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark14(-26.990761626268117,-1.5707963267948937,0.0,2200.642631036052 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark14(-27.01487146916716,-0.2332898096842235,-1.5707963267948966,0.6476004642158193 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark14(-27.049679022953754,-1.387213189779479,-28.347360599971676,1.0422584337581604 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark14(-27.068994358388366,-0.5076758974302666,-0.2059053429055009,-1.0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark14(-2.715314897741554,-2.91183823900801E-15,3.944304526105059E-31,3.597490619321058E-15 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark14(-27.16085897170083,-0.5032460420497356,5.701117129507395E-16,45.02891744474391 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark14(-27.189227621540805,-1.412083622780293,-50.45392420954255,1.0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark14(-27.201143784527176,-0.7719463008005387,-1.1405417782296867,-0.09171409803438024 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark14(-27.26912904559707,-1.472986639605396,-40.220574650364,1.0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark14(-27.377939006131463,-0.9527117329594894,-83.84143974857935,-0.8988427438765765 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark14(-27.46271153863849,-0.2453591024394814,-39.82296634942099,-1.0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark14(-27.524143654984307,-0.04888337401918301,-45.17773331597963,-1.0000000129842532 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark14(-27.635772650745892,-0.3470439552400766,-100.0,0.9999999999999896 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark14(-27.641727550854313,-0.025872771809522598,-43.50197575646314,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark14(-27.75050345121422,-1.5707963267948963,-37.71638772866376,83.17377641149302 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark14(-27.784256998483617,-1.1102230246251565E-16,-4.15757628594411,-1.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark14(-27.82201144618837,-1.468854284585532,-81.47547817978676,-1.0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark14(-27.93272650099027,-1.5120815671447934,0.0,-1.0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark14(-28.049133956956368,-1.5707963267948948,-80.6419039809451,1.5074788280781246 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark14(-28.06882578866825,-1.5707963267948912,-67.53043789523176,-7.921753063745413 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark14(-28.215442662226394,-1.4210871713351776,-72.40253024741597,-1.0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark14(-28.407693586625566,-0.02634038064092422,-41.801686308789925,-0.2585406171123936 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark14(-28.450249362806908,-1.7763568394002505E-15,-59.223995640099105,79.15098031227369 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark14(-28.544212048203605,-1.5707963267948912,-160.23274210920658,33.8347617022897 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark14(-28.64043933791473,-1.5707963267948948,0.0,-0.3692147682247068 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark14(-28.69079636452627,-1.5707963267948948,-24.187523613964885,-9.136737608982934 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark14(-28.695415826494894,-1.4107308446726419,-19.355907666176424,0.016922166209204385 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark14(-28.9341486089164,-0.8927965083084753,-0.021224274836997903,-7.52316384526264E-37 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark14(-28.975735341034706,-1.5597385822213028,-1.5707963267948966,-0.06255253654820948 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark14(-2.8980200489900056,-1.5165640958166198,-49.56081004503687,0.26428123899241973 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark14(-29.073704256260466,-0.42281694751436394,-69.44558787902345,0.6262046501976126 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark14(-29.120509332539186,-0.33800171896526265,-0.0262774433122793,1.0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark14(-29.16339194591224,-1.5580170114143077,-1.5707963267948966,-0.9999999999999883 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark14(-29.26816085630046,-0.07573174344301403,-88.4430587292237,0.23739328351646272 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark14(-29.287464131807823,-1.5707963267948912,-49.41395252960046,-1.0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark14(-29.322705137415383,-8.881784197001252E-16,-39.758943963125134,-0.18085175059595837 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark14(-29.339251028138392,-1.2962538861729889,-77.34072902551408,-93.83467953913338 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark14(-29.387059012291154,-1.4800113037467924,-101.74611506233717,-0.9993938207557376 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark14(-29.400674192333092,-1.0734696983777199,-93.24625393129625,0.02937904286840376 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark14(-29.450576463173327,-0.23593839191255128,-88.52676984401691,93.38307697541393 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark14(-29.629954347268963,-1.418279105672422,-46.81160140451872,-25.593281311082166 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark14(-29.697767479718184,-1.5707963267948948,-10.034917370683495,0.057575966788780214 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark14(-2.9714494324029594,-0.3714749164013342,0.0,1.0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark14(-29.770456509184218,-0.927415238312871,-32.80303564017082,-16.727399421523685 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark14(-29.807578661713563,-0.2935940894953844,0.0,-1.0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark14(-29.843859548031418,-0.47925861080743104,-72.70446410164782,-35.02250801951365 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark14(-29.88066194175383,-3.552713678800501E-15,-18.770539604142535,51.72274988378186 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark14(-29.967037922736157,-1.3023989777115887,-1.5707963267948966,0.037346058980002775 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark14(-30.07193892085416,-0.014830242036811722,-6.9689270838351405,-0.740693344707522 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark14(-30.091372172268702,-0.29790150823144496,-1.5707963267948966,0.01665458712513776 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark14(-3.017195673360833,-0.03424331150434614,-94.3378679220195,-1.0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark14(-30.173235679615914,-0.785336956343528,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark14(-30.216095486235133,-1.108492962418791,-90.5518879643971,-1.0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark14(-30.27363515177118,-1.4973485538176166,-1.5707963267925986,-100.0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark14(-30.329707569420787,-0.14200252410265263,-1.5707963267948966,0.17623124103738608 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark14(-30.426074682561048,-1.27621751944762,-36.176576597929724,-0.8462848187483516 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark14(-3.0486865295528016,-0.8773713686735788,-9.914439377347204,-0.9349494830514207 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark14(-30.59271576732084,-0.5695415759613385,-29.713858689800617,0.9087879284764195 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark14(-30.644329274160384,-0.46686062478649415,-28.842715791551598,-31.6954993382287 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark14(-30.67493178768211,-1.0466060781259987,-1.0956236182120092,96.41783533152008 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark14(-30.738531439667277,-0.5171962859146522,-31.56047580973734,-0.9999999999999982 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark14(-30.79406567362136,-0.14276809336143614,-164.6994825130326,0.9986781535365741 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark14(-30.809246535707807,-3.552713678800501E-15,-40.03739335054318,1.0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark14(-30.8580052778769,-1.5707963267948963,-0.8999785469843591,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark14(-3.0874019183212043,-0.2538952504273793,-40.784571695956686,60.62261492097588 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark14(-30.93228636059023,-1.5497811776033747,-1.5707963267948912,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark14(-30.932830216816697,-0.028310524364957148,-25.49532422206366,0.3672007847713522 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark14(-3.094099475674625,-1.4166905543872645,-1.0087922010718768,-61.37525778876731 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark14(-30.975416589005945,-0.6136895799512398,-23.527670339774325,0.9421593340083487 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark14(-31.044925742416023,-0.10855619616396052,-1.1832851375394524,0.0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark14(-31.051669436806595,-1.3269393492347261,-52.01370807570885,-1.0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark14(-31.072615449186557,-0.911724576694811,-23.55556278467334,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark14(-31.11127955336904,-1.5707963267948912,-14.87198951448542,-0.059798479496580105 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark14(-31.117991340429505,-0.6688661680469273,-0.8967502324933605,0.052916029762121314 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark14(-31.187998702397337,-1.7763568394002505E-15,-81.78214534452408,-0.9131475775182324 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark14(-31.21428474226575,-1.5136418460875483,-34.17340848042598,-0.04375804456864918 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark14(-31.22420166386621,-1.7763568394002505E-15,-88.93432113249696,-68.60909810283557 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark14(-31.233552395279066,-1.5707963267948957,-37.834842879764366,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark14(-31.27204485006866,-0.21242053066773092,-24.74704487184418,-0.7368956445764614 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark14(-31.33338898560019,-1.5639940878825245,-8.204322537526128,-2.926047721682624E-98 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark14(-31.407890555909688,-1.5707963267948957,-66.50487649615347,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark14(-31.466955678208954,-1.5411487129918648,-45.424215518443916,100.0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark14(-31.523551358288202,-1.192017628689896,-54.11784679892333,1.0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark14(-31.543825975639574,-0.9961743931970186,-12.809024593570228,-1.0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark14(-31.56382932011948,-0.8676248578903611,-97.51287348382425,-0.7760517467434767 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark14(-31.6674462249447,-1.457276375490007,-0.4438384095790583,-0.06357579223904732 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark14(-31.69074004505897,-1.5707963267948963,0.0,0.7872658261243585 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark14(-31.743644925807132,-1.5546478164887518,-74.0248687361259,-22.04732750864653 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark14(-31.793647239625187,-0.37262204754382755,-67.53156336563472,-0.021731423663339647 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark14(-31.838361656303945,-1.5707963267948912,-53.971103478673484,-0.8709432549155129 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark14(-31.865358911877113,-0.0645270937888685,1.5707963267948963,-0.8563489941848563 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark14(-31.89301018329038,-0.45330168188042885,-37.02805936385911,0.0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark14(-31.89435166732806,-0.5535718989809633,-19.351878024871848,22.955083461866327 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark14(-31.901832597231824,-1.4772441899439122,-95.90910273440431,-0.9791712409988893 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark14(-31.97540650594641,-1.570796326794877,-44.34870163551306,43.29312067312307 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark14(-31.981898161989548,-1.4995801402487527,2.2766307664141643E-6,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark14(-32.139035981499674,-7.105427357601002E-15,0.0,-10.93479486362834 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark14(-32.1421852023821,-1.5707963267948841,-1.5707963267948948,-6.023678443145553E-4 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark14(-32.36367535493265,-1.3759225432012343,-3.880693331908674,-1.0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark14(-3.245127551650448,-4.440892098500626E-16,-1.5707963267948983,-7.1813096067474795 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark14(-32.47011391355423,-0.19153914370726055,-2.6392196743283876,-27.483375299434215 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark14(-32.49780054812388,-0.3596640929559162,-52.83371229473061,2.710505431213761E-20 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark14(-32.56684739292268,-0.6194996085390658,-10.619513097361583,-42.39736640322852 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark14(-32.59289633249823,-1.151178728867895,-44.3065735828041,52.45031287256015 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark14(-32.59448156450827,-2.220446049250313E-16,0.0,-0.9100004536451429 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark14(-32.64692225222568,-8.881784197001252E-16,-20.07373218524407,75.65261226630076 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark14(-32.77576552609263,-0.4980699810216862,-60.50898328267577,-56.82489914974835 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark14(-32.77820525710662,-2.663015958311451E-5,-71.49731942290421,-0.016142214642788165 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark14(-32.87325952178337,-0.8340161315786171,-1.5707963267948983,0.17579757566154158 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark14(-32.92823652373452,-1.5707963267948912,-4.572838979701348,4.440892098500626E-16 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark14(-32.941806731495475,-0.05700819542197434,0.0,0.41334602426804395 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark14(-32.957576133898485,-1.5575699531320295,0.0,0.362094730805232 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark14(-33.078368061078905,-1.570796326794877,-98.9867930859329,0.9999999999999982 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark14(-33.08999086877329,-8.881784197001252E-16,-13.805443247872498,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark14(-33.1792623094036,-0.6079280076751401,-30.81825888011541,1.0000039515852557 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark14(-33.3276089612474,-1.0332412109256353,-100.0,-1.0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark14(-33.38588601896717,-0.8257305098948806,-31.456094213903317,0.24197667833612413 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark14(-33.4020260865743,-0.4908297321586925,1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark14(-33.42727560104588,-0.987967983515295,-48.5405540869009,-1.0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark14(-33.44412105909957,21.475572729041787,80.36821992972423,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark14(-33.62761945494966,-0.5310118436463175,-1.257653990650966,14.371264951146678 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark14(-33.65791090602869,-0.6913859920465679,-34.04593328588963,-29.470604973111165 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark14(-33.762618226806495,-1.5707963267948963,-1.5707963267948948,-0.9983850731736956 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark14(-33.772309513400366,-1.0359769926245668,-27.287679649942888,73.18055567485223 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark14(-33.89463254183923,-0.6907011460638492,-120.98935687976473,0.0011865575469811255 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark14(-3.397418931208701,-0.11797445919173766,1.2837826489982205E-15,1.0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark14(-34.04334247605475,-0.04386235585335049,-19.916418796133534,0.9564765634549043 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark14(-3.4086649333561585,-0.24565991538594956,0.0,-1.0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark14(-34.23934561270969,-0.0014539636814466309,-4.146575748718701,-0.24834290479870885 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark14(-34.33451265876168,-0.12587776814571633,-1.5707963267948912,-0.05434111641232832 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark14(-34.34662613729379,-0.3098801957401817,-25.179043605863832,-1.1869459682199748E-66 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark14(-3.4355507536017447,-0.1992775699223689,-17.27092937210348,-0.8578372112550856 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark14(-34.3760875093831,-0.5769276974479904,-10.848562520982577,-1.0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark14(-34.412524854298574,-0.411023057453757,-70.67888157918175,1.0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark14(-34.51332214535529,-0.401788625643674,-55.21265312368285,-1.0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark14(-34.535844406498896,-1.5707963267948948,-7.074217457302851,-92.59714656233665 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark14(-34.577835206930956,-1.0229802507257226,-86.4654538943971,1.0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark14(-34.61345209353961,-3.552713678800501E-15,-0.10241673797011952,-95.88224920656631 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark14(-34.61686322554603,-2.82341291097154E-17,-21.87662822111833,1.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark14(-34.67618816239491,-1.1311905384687293,-9.635355958545361,31.47542630968212 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark14(-34.77305568548563,-0.6715144340879959,-92.38173604623495,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark14(-34.81587257404273,-1.3596511579873194,0.8417265399948424,-98.78620149923758 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark14(-3.4952198751150743,-1.5707963267948393,0.0,0.6377730868566538 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark14(-34.96034558512271,-1.5707963267948912,-0.7621370803499343,0.32356098358754526 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark14(-35.07916759437552,-0.1735455852285638,-27.791187091637084,99.19681745466647 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark14(-35.09252679347426,-0.34817479780938426,-21.0049718714544,0.9999999999999964 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark14(-3.511828425790469,-1.5310681465961267,-45.05786579809318,-71.94494178077056 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark14(-35.14138411766756,-1.5537907995588967,-100.0,0.9019957557830031 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark14(-3.52946060459719,-0.4363423739986638,-72.34599293403167,100.0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark14(-35.41150035008569,-1.3980432301139683E-15,-4.224363477943797,1.0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark14(-35.54116092049754,-1.5707963267948948,-50.90376935246581,37.86598950407422 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark14(-35.554593307077006,-0.7545927912068614,-23.322027076414955,-23.89574994964204 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark14(-35.57800560686488,-1.5707963267948912,-1.426677936989634,-0.9224500853405111 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark14(-35.663171189042245,-0.9269029692198091,-0.8547400552987312,1.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark14(-3.5678594206377454,-1.4759412437397017,-0.13014079231643552,-94.19133651409791 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark14(-35.74492665307199,-0.1655959674875782,-27.26220040777168,-39.78469248927007 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark14(-35.75715957860707,-1.168109018914579,-3.0145404820317534,1.0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark14(-35.78368442573634,-0.010852735688875856,-51.2607984150883,-0.04192567623882962 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark14(-3.58211571624269,-1.5639457671153496,-74.35682143814326,-0.3067620769396213 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark14(-35.83846510867795,-1.5707963267948957,-5.085789703435054,1.0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark14(-35.839567821790126,-1.441267521471879,-27.965323139217993,-1.0000006767413256 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark14(-35.98163866639014,-1.5707963267948957,-37.958583981838224,0.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark14(-36.02929214596323,-1.3097913939792034,-1.5707963267948966,-0.8093685488199365 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark14(-36.04017477147371,-0.6966865148562862,-1.5707963267948966,0.36295839467103 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark14(-36.119228092860936,-1.5707963267948961,0.0,0.3010056258554634 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark14(-36.15037329149495,-0.5811989337886518,-74.08989721185918,0.01831240163433079 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark14(-36.285860484060194,-4.440892098500626E-16,-6.744805388586329,-0.3865977247476743 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark14(-36.380965382618264,-0.2783019946673788,-94.46482585611932,0.023380246992249526 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark14(-3.640338173380603,-0.7228012940401052,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark14(-36.520564786281184,-1.09686612033874,-54.20223058437115,64.33057460500012 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark14(-36.53823553564894,-0.3477660963039959,0.0,53.509505855647284 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark14(-36.61793652741626,-1.5143530825355147,-1.5707963267948966,-0.027942348760500717 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark14(-36.77127843615437,-1.393949684699554,-49.73150528579454,0.3717103145874666 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark14(-37.05646309137867,-0.8660436662838578,-164.95065711239405,-94.82954386934665 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark14(-37.08338338106007,-0.1610593171395609,-85.04395512061569,-36.993070254743046 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark14(-37.11593598446165,-1.5707963267948957,-7.284933975993988,-65.89347192078044 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark14(-37.22715608781043,-0.8689901353438756,-31.567518044362316,1.000003442532742 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark14(-37.22821586818497,-1.4483506283111465,-25.866127503073535,-1.0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark14(-37.29726539488141,-1.4878373922422605,-1.5707963267948966,-1.0587911840678754E-22 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark14(-37.366108670708044,-0.011367647006483824,-44.14879331554383,-0.34847284856031047 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark14(-37.41569415667729,-0.050105247227825646,0.0,25.335315435550044 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark14(-37.4434258594645,-0.2436811658962455,-12.068869690928992,-1.0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark14(-3.757686279276711,-0.01526882726161905,-1.5707963267948983,0.011418350272665495 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark14(-3.7735479075591014,-0.5622075429212678,-2.105979934166009,-51.477125817195784 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark14(-37.76073380717189,-2.220446049250313E-16,-1.5707963267948972,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark14(-37.81214697269402,-0.14658997725017783,4.440893047198632E-16,-1.4693679385278594E-39 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark14(-37.82783823942218,-0.6805161900615782,-88.65871581179883,0.9959739359974473 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark14(-37.83637629271503,-1.3909037035663232,-50.01483244912215,60.0774758629358 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark14(-37.87439668747844,-0.5910566320703321,-0.07740020335237537,39.97266409719275 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark14(-37.98287392385756,-1.51933609723137,0.0,1.0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark14(-38.00163872038327,-0.9394729464510156,-9.271483251219236,3.3087224502121107E-24 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark14(-38.01147887697103,-0.070594036782302,-80.33473896257057,0.06099031055592477 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark14(-38.027755188484,-0.8967059768370973,-46.024516804084726,103.82974343876097 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark14(-38.238801457433865,-1.550647697951946,-1.4951133038738462,-94.69834871038466 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark14(-38.30154783770682,-1.5707963267948948,-1.5528436211995367,-66.40255976845869 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark14(-38.41950985800395,-0.11280248526590242,-1.5707963267948966,40.72383014169165 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark14(-38.42458510203991,-0.5367986512608942,-31.546499454899305,-0.9347334978651527 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark14(-38.53011182830575,-1.5707963267948963,0.0,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark14(-38.53360086778892,-1.2482419601435242,-1.5216788174420073,-44.27784163777779 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark14(-38.56205351024813,-1.5707963267948912,-24.218478663548254,-98.17935434050212 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark14(-38.59018369138142,-5.551115123125783E-17,-66.0793945247447,-1.014982081756846 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark14(-38.60464324209211,-0.041319095302746696,-100.0,0.12922468182140823 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark14(-38.611354853924354,-1.5707963267948912,-45.484492447110554,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark14(-38.623950874490504,-0.09650331954476336,-45.7408543713014,0.2438483036754846 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark14(-38.662419733596195,-3.2977096404065433E-12,-1.5707963267948983,0.0043930017985479575 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark14(-38.70313649573624,-1.5707963267948948,-59.99975665438494,30.525215095195534 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark14(-38.7903708797343,-0.8059796867803858,-53.857625269430095,0.04903666293897814 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark14(-3.883731013219914,-0.522769542821596,-100.0,-59.67667840680206 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark14(-38.85615805935181,-0.4401718587169732,-22.284849768674952,0.0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark14(-38.97213947840137,-0.6708408421710375,-65.5782422997913,-0.8000747424391137 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark14(-39.18764969401808,-1.0455554248079908,-1.570796326794895,1.0000000000000009 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark14(-39.21405824295583,-0.16556679471430136,-95.25319531664785,-88.71311584210417 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark14(-39.30434933132613,-1.1292212806560968,-27.172691023278844,-1.0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark14(-3.9357334587153816,-1.3086820030506061,-19.422413409704806,-1658.931380387093 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark14(-39.36340343592781,-1.1266865236861872,-27.982353625523487,-1.0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark14(-39.364917462825915,-0.41725368801325224,0.0,1.0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark14(-39.39257795440457,-1.5707963267948957,0.0,5.2749732430003275 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark14(-39.42548693765195,-1.5583374534030738,-80.70532863437265,-0.7377869437059505 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark14(-39.43167723119643,-0.9426973420433749,-68.12109935628098,28.17026923755936 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark14(-39.45147985916561,-1.4907900469241828,-20.404890797866695,0.0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark14(-39.54372825606698,-1.231755606631154,0,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark14(-3.962508708139751,-1.5707963267948948,-92.11432653320912,0.5809217013339332 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark14(-39.71010278675693,-3.552713678800501E-15,-6.951257667066088,-1.0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark14(-39.75867586968784,-1.1259264736495858,-15.473752083211068,1.0000839018034549 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark14(-3.987170942779386,-0.15648235554577328,0.0,20.632077963564377 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark14(-39.884737918833146,-1.1737773742598878,-1.5707963267948966,-0.16607263375510983 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark14(-3.9974625464140177,-1.0619380099945221,-41.89642383903913,100.0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark14(-39.98794333599163,-1.0421466894099711,-1.5707963267948966,-37.97693199405667 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark14(-40.00802619509149,-0.40517172722271866,-1.5707963267948961,-0.6683184507756756 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark14(-40.042051027296864,-1.5409154168678492,1.1954473954776557,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark14(-4.0119039120314,-1.3089803112348755,-73.53394133942922,0.613827065263198 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark14(-40.17510172441017,-1.5707963267948957,0.0,0.45618796074009893 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark14(-40.20249669115,-1.5707963267948948,-1.5381656948400388,1.0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark14(-40.269811567632885,-0.8965035014950294,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark14(-40.34382557506551,-0.10299994351841818,-72.60500820523782,-1.0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark14(-4.039346609585195,-0.4229366105749355,0.0,-1.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark14(-40.4604300851509,-1.3731331347235642,-0.9365775989129134,-0.8642547858691603 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark14(-40.64698002217115,-0.02634710851213631,-66.0896580017984,1.0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark14(-40.667959975268914,-0.3101962801364948,-34.58626039028306,0.0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark14(-40.689943444912565,-0.006123593623950394,-1.5707963267948966,1.0000000000000324 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark14(-40.73632459125363,-0.34164257798400804,0.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark14(-40.73834873875476,-0.026503725083014684,-1.51320813524667,1.0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark14(-40.78437560292924,-0.10906652663554056,-21.787272564359135,-0.040625404665549744 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark14(-40.824547956137536,-0.3250117690217378,-9.706337758616987,-89.38402272372545 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark14(-40.82916270181818,-0.09625622719767761,-100.0,0.07060139421100142 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark14(-40.84025671617239,-1.5170515045260582,-13.24045153403387,-1.0000140500229882 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark14(-40.902489690877175,-1.4249920952729807,-0.6132568373351432,-0.04320552616052063 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark14(-40.94851341908765,-1.5707963267948948,-52.631575587075005,53.627772730570236 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark14(-41.046358125104376,-2.220446049250313E-16,-66.0734928260499,-99.743112050824 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark14(-41.06430004516325,-0.348405780178783,-1.5707963267948912,84.90683885409396 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark14(-41.074370916018935,-0.011970827560005864,-1.0801408137567279,1.0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark14(-41.08348267412847,-1.5707963267948912,-8.8717010205837,42.94575364252614 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark14(-41.12952065488364,-1.5707963267948912,-1.5707963267948983,92.28463755291403 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark14(-41.13461633177237,-1.4164639802163155,-2.220446049250313E-16,73.2714250606571 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark14(-41.13998663315015,-2.220446049250313E-16,38.061536555496964,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark14(-41.15040135561862,-0.26467753245133685,-48.265518030996766,1.0000081290250766 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark14(-41.197458496442806,-0.6705225883012957,-1.5707963267948912,28.614147174408316 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark14(-41.21733923099296,-1.5310330997068775,-1.4029394086885367,-1.0000000000000007 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark14(-41.257947246341175,-0.22069516223065022,-54.43891645947711,0.0010610181317411704 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark14(-41.258355825607396,-0.45413316530298947,-40.12883915329811,-1.0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark14(-41.33478692064837,-0.2886212330308291,-80.4329684125018,-1.0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark14(-41.43647137525535,-2.220446049250313E-16,0.0,-0.32027997444599593 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark14(-4.146129570346106,-5.000084279423015E-18,-2.907584806846251E-17,0.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark14(-41.536467363153335,-0.5938799285405238,0.0,-14.613239465268839 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark14(-41.55697828016191,-0.853878008519275,1.3936929289857487,-1.9988133668302452E-17 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark14(-41.55905268412469,-1.1622803278710947,-84.42262948763445,18.69851893187331 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark14(-41.60329917518175,-1.1681176368944546,-81.67254745388055,1.0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark14(-41.64754254339511,-1.3543237867391515,-1.5707963267948912,-14.940006475645774 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark14(-4.1664819039554075,-0.5471291851547458,-4.159382983649901,0.058168711713349364 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark14(-41.78991461292579,-0.010222403040437388,-44.44230773801318,1.0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark14(-41.83444147575379,-1.3306516525722856,-86.84040079875024,-100.0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark14(-42.01362947388492,57.3207815086603,0,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark14(-42.06807446680259,-1.0447795017713704,-71.45892191906199,1.0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark14(-42.07071204207743,-0.08855553005422884,0.0,-1.0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark14(-42.10843320566864,-1.1845539768016382,-92.28596660791895,1.0000000000000002 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark14(-42.21724399941984,-1.2891883766374252,-0.45061356247573253,0.8246368628607762 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark14(-42.21914443734497,-0.7478829799635357,0.0,-79.18539309797288 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark14(-4.229634339379491,-1.3578374910298436,0.0,-99.01722016458504 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark14(-42.35936887851453,-0.008346775644406536,-16.646372639747156,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark14(-4.2540939116577485,-0.05912169820471429,-1.5284561744343257,0.48795134783929184 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark14(-42.67567441429934,-0.1212836050052366,-88.3847184839374,0.0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark14(-42.67741875407061,-1.5707963267948952,-4.286231314174217,1.0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark14(-42.74543128623421,-1.5707963267948948,-8.078729617594064,0.3916733639336606 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark14(-42.772827522557144,-1.3000405646000366,1.5324505768278582,0.0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark14(-42.80339319012212,-0.547036392335563,-96.81653398469356,-38.3121005178886 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark14(-42.88898122728801,-0.08917974708349749,-0.023630515905920704,-1.0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark14(-4.300516343827283,-0.3165113588513744,-49.6830420519403,1.0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark14(-43.020882056445615,-1.2727623963940353,-45.19450695397827,8.30528587043446 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark14(-43.03110596763804,-1.0906926617726571,-31.657049474110238,0.012335136749061122 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark14(-4.317302455544205,-0.5161865678686504,-55.50855428655149,-1.0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark14(-43.17316421053339,-3.552713678800501E-15,-2.220446049250313E-16,-0.9004885041089918 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark14(-43.19872024234079,-0.9725140891282702,-10.85395248240188,-1.0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark14(-43.20655452400748,-1.5707963267948948,-82.54366823524524,-1.0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark14(-43.35779955652328,-1.5707963267948912,-39.27916926304749,1.0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark14(-43.3786592273042,-1.4431509840336465,-100.0,12.73588193499036 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark14(-43.3806064657772,-1.371467191742981,-1.5707963267948637,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark14(-43.50905757955792,-1.3849746164771506,-88.28530550355872,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark14(-4.3572943826123165,-0.9968123475903335,-1.5707963267948966,-2.805515966730756E-191 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark14(-43.59471447198929,-0.444500409443636,-101.28690373934829,39.85738803866829 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark14(-43.621342132342605,-1.4516135019081067,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark14(-43.675969725698586,-1.4326709289695703,-0.020251624141961688,0.5211810991578965 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark14(-4.367601285806563,-0.23862489268867784,-75.75402353882748,0.00958959872818706 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark14(-43.75038466503564,-1.136936135045301,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark14(-43.81718026245936,-0.00235631998735371,-87.66615774935946,-1.0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark14(-4.38557030230367,-0.2805743683590084,-0.8916174118189368,-76.0913715128051 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark14(-43.85829788061181,-0.6878305620864794,0.0,-1.0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark14(-43.891813084167126,-0.704940844180717,-29.927969522953116,-58.88304055017703 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark14(-44.05615416436309,-1.3620931379576224,-146.422844475778,-86.54434853387593 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark14(-44.10870749998905,-0.0860674238135981,-1.5707963267948966,-0.8044683893792122 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark14(-44.12753541371738,-0.5055831060225356,-24.165538457348493,0.9999937526362226 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark14(-44.212372549508984,-1.5707963267948912,-82.8573647373039,-9.841727528496264 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark14(-44.21784091473711,-1.5707963267948912,-25.094406529441926,-1.0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark14(-44.227924515703336,-0.7925777519181305,0.0,-1.0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark14(-44.23421173354779,-0.7666707995340261,-93.65260953723522,1.0000000000000142 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark14(-44.23605240955523,-1.5684232225761015,-9.978785202188538,-0.0625543239000778 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark14(-44.27328446835388,-1.5707963267948948,-1.5707963267948983,13.610117812189259 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark14(-44.27407898970352,-0.9285551274597886,-100.0,-0.9639832689453273 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark14(-4.43525934954685,-0.4122229026216455,-38.523319149528284,1.0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark14(-44.39426097571526,-1.1805937187647313,-60.683418684564174,-1.0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark14(-44.39908344665394,-0.39617797583808256,-88.42530988355409,0.8978038918941006 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark14(-44.45972681968059,-1.3077816854964812,-64.23145072152954,-0.9231808914385118 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark14(-44.50062334421372,-1.452703827824553,-61.470974324802505,47.131312549681695 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark14(-44.568555336826094,-0.45684206229114227,-28.513581607926806,-1.000000000036566 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark14(-44.76424676273333,-0.9801671265591024,-39.664844941681395,2153.0519322209525 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark14(-44.83918465015983,-0.9396649473941465,-29.94028363356171,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark14(-44.87620365303198,-1.1575074110302892,-44.253093534224455,-1.0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark14(-45.01083000311621,-0.6356507340474593,-161.80247850821127,-82.07763399626245 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark14(-45.06200097956682,-1.5707963267948963,-72.39956285562272,-2196.5268210074305 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark14(-45.15100848423499,-0.806744545767283,-69.37682760147905,17.375616368978527 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark14(-45.16422201194476,-1.2497275938977999,-55.97867852080591,-1.0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark14(-45.24095015591993,-4.434140138926413E-15,-75.15775470308522,-37.2966208659244 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark14(-45.33350778353184,-0.8297994311284288,0.0,-0.9233112714905535 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark14(-45.34595566464251,-1.5707963267948961,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark14(-45.464844838350075,-0.008671991302810017,0.0,0.0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark14(-45.664111121060834,-6.265040042896519E-4,-11.076549067842446,-0.003600410844360691 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark14(-45.66799537503759,-0.3449569066795606,-62.33136583863157,1.0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark14(-45.713106063710434,-1.5545753447224329,-32.08278009126954,1.0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark14(-45.84520623292098,-0.7308165574131689,-135.37140375992408,-0.6335369238503055 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark14(-45.928182816455966,-0.027111141799560257,-14.568791734695811,-1.0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark14(-46.016380482009694,-0.21325659076475195,-1.3568872542700778,-1.0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark14(-46.19812288603171,-0.01912078565370228,-63.91139589222363,1.0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark14(-46.27691668555516,-1.5707963267948948,-1.5707963267948966,-0.9877126198254537 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark14(-46.28591417240935,-1.5653092609921513,0.0,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark14(-46.385631786398235,-1.3859529236805321,-1.5707963267948966,-43.02490531546896 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark14(-46.52357303041757,-0.38341304739054116,-125.53336670472382,0.028615020775614536 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark14(-46.57244510487863,-1.3187801362328828,-64.74691795255572,0.9387477853623954 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark14(-46.79248417259084,-0.4381139151924028,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark14(-46.881656777280796,-1.5685536643044897,-79.78536478364965,1.0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark14(-46.995197590978655,-1.4402184213002016,-71.20626501476403,-0.5144637473473206 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark14(-47.00264046329178,-0.32689817261909976,-25.806420161560084,1.0265159360809788 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark14(-47.01010770173917,-0.9889473621681901,-0.4975945822421813,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark14(-47.31723354983032,-0.12738984465816827,-1.5707963267948966,0.9072427333671589 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark14(-47.32173247901091,-1.5707963267948948,-69.98647753529053,-0.9999999999999982 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark14(-47.443701856800736,-1.570796326671917,0,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark14(-47.453499081420844,-0.28605711128285893,-56.14187001305366,1.0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark14(-47.52740950566497,-0.15753920971048352,-75.89412169471524,33.78743407434728 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark14(-4.753040423459609,-0.30763576171496165,-24.22391242426592,99.67238494252177 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark14(-47.53541702117382,-0.8127441550739327,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark14(-47.604012149740576,-0.7197780818437253,-1.5707963267948966,0.42609996777022335 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark14(-47.636720019629976,-1.4844005083832252,-58.90036579405522,0.3806032602501812 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark14(-47.64083081675845,-0.8875681658168281,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark14(-47.687358511423476,-1.561740782770813,-1.5707963267948963,-0.9295993010802619 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark14(-47.73503744107891,-1.1675813716621593,-3.2464942091852436,-1.0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark14(-47.98458723737394,-0.5019905681092468,-44.37389468548041,0.3842895748286619 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark14(-48.00363308645501,-0.15111967923271918,-34.14916028580902,1.0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark14(-48.02795381054533,-1.0364969516768423,-65.49010882588681,0.0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark14(-48.032035349576155,-0.41774711433219786,-56.13318087886006,0.9999999999999993 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark14(-48.13066113733642,-3.552713678800501E-15,-98.38638566178946,1.0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark14(-48.141023919338785,-0.020931836118130542,-0.7387214967212744,1.0000685678151686 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark14(-48.14691613809029,-1.521133399484981,-18.033282999601102,0.03411711229354586 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark14(-48.17305196704602,-1.4820322397210832,-1.5707963267948966,-0.9798206985422816 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark14(-48.20504745642378,-1.7763568394002505E-15,-0.8129658283859058,30.36227800108537 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark14(-48.24255868012641,-1.3374003441085236,-1.5707963267948983,-0.03620783161715113 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark14(-48.278548405200176,-0.05700287740525539,-9.788726604545436,0.0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark14(-48.328779899820624,-0.5123137761292502,-0.021579614275000138,-0.2440388611462555 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark14(-48.3360008907873,-1.2674037196934131,-64.35270196947509,51.40737642889289 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark14(-48.336754280115954,-8.881784197001252E-16,-9.653234301003762,-0.6081955527972739 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark14(-48.39302497522818,-0.719842322948713,-2.2262698708727857,94.02946953035456 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark14(-48.507353417627,-0.08316658529270471,-1.5707963267948963,0.9999999999999991 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark14(-48.51771972626015,-0.6079306971661457,-86.33157912531921,3.469446951953614E-18 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark14(-4.855623111227413,-0.021945170453032816,-100.0,0.36208945953850663 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark14(-48.708221731815996,-1.5706915743588992,-88.37959502998667,1.0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark14(-4.879341682419039,-1.5707963267948948,-45.22477619632744,-0.2749664201669326 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark14(-48.87370293761449,-0.0012313347925485343,-87.81250071298278,1.0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark14(-48.900730964060976,-1.5398271247369024,-15.152201623187572,30.466017286136797 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark14(-48.936071806500614,-1.5707963267948877,-90.76739784491586,0.7811008003471471 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark14(-48.94179712183521,-1.5707963267948912,-26.978806813482933,-1.0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark14(-48.9896328508283,-1.5707963267948948,-9.048595687281555,1.0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark14(-48.99720715078982,-0.5014548474827552,-0.0745184728097773,-93.42385154324963 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark14(-49.19637547411374,-1.2565111298462681,-70.91637456681691,1.0000000175323525 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark14(-49.24137311298238,-1.2503857724095067,1.5707963267948912,-99.45062533962927 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark14(-49.269107735283576,-1.5707963267948941,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark14(-49.3741120140607,-1.5707963267948961,-39.51287530807137,1.0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark14(-49.41696332664872,-0.8633544713799671,-99.62154373320111,-0.7740387301561582 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark14(-49.48672678488879,-0.708669111719928,-58.8937104115394,-0.21925002144336547 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark14(-49.55549201162231,-1.5707963267948912,-73.25806432129221,-0.0388159204454516 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark14(-49.66012927455864,-1.3591998244776593,-85.58015926730991,-1.0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark14(-49.67626527648661,-1.3020584289391337,-72.38461289237969,-0.46267912596559313 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark14(-4.976203182865119,-1.3764638293072513,-31.79720619665678,0.20698627059627706 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark14(-49.81203119208618,-0.8862372671279143,-39.587850776022336,-0.6950037339845769 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark14(-49.90388826555842,-1.5707963267948912,-9.576469077497293,-57.23300894414368 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark14(-50.02052444465195,-0.07702355697444249,-4.8134206230405985,31.050831309775948 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark14(-50.15887362599434,-0.33520734919496536,-89.39773716825098,-1.0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark14(-50.34181990267645,-0.24446305485831665,-17.874216667306026,-0.8245938897568402 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark14(-50.422780144631574,-1.5660403932575304,-1.3869257499711931,-0.9999999999999998 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark14(-50.517200800968475,-1.5707963267948957,-40.1392148990267,-96.5244539685004 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark14(-5.052485542220467,-1.5548654229766887,-53.805881120561,0.8764109066348157 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark14(-50.54172491827531,-0.5110125329092433,-1.5707963267949054,61.940763119210125 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark14(-50.61644511789227,-1.5707963267948948,-100.54990419435893,-32.30553691870341 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark14(-50.65234856977365,-1.5707963267948912,-45.03307305422799,61.90428958698868 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark14(-50.66089782365041,-1.0802123635981733,-1.5707963267948966,0.06392632039019298 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark14(-50.82665873897562,-0.8628473299573438,-0.5213926121801097,-58.553192272539036 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark14(-50.91750741499108,-0.9620188368233036,0.0,22.4972174170653 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark14(-51.031270815948794,-0.517936702981868,-66.51053396656037,-3.4063322509746072 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark14(-51.10330882708127,-1.4868774164699536,-44.68898643158387,1.448908652612274E-70 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark14(-5.114327092717552,-0.03796494242948145,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark14(-51.19256466966003,-0.4903407276289794,-72.6899360271401,96.76225108886067 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark14(-51.1946912240944,-1.4664029962846197,-32.84994416723021,1.0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark14(-51.7173355314829,-8.881784197001252E-16,-4.394311719086346,49.4580235603411 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark14(-51.74618245769824,-1.501302311851834,-94.65164261525368,30.489237146142898 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark14(-51.76993812899215,-1.0353594732466425,-64.68168696133438,14.845016664239154 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark14(-51.770254928433644,-1.0898983644794784,-45.78070969245344,8.881784197001252E-16 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark14(-5.178281117135785,-0.4736356480805275,0.0,-67.87923442730556 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark14(-5.180628372515633,-0.7176561865204314,-32.61932606281799,0.5441172013600557 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark14(-51.83079896510701,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark14(-51.83372620434803,-0.004091401616783313,-1.2364028815626122,0.8288354320665179 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark14(-51.90467110952588,-0.109197349123491,-87.61852458808555,-0.03457852975152331 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark14(-51.93563495895356,-1.5707963267948948,-57.41577945789005,-48.78093878553766 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark14(-51.99895897540138,-0.2826772992200389,-67.26976529023932,-1.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark14(-52.00902900243214,-0.4528187151468135,-95.6956815345841,2127.898928017221 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark14(-52.175222239921396,-0.4620635626985461,-57.71325359391226,0.9020490213432518 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark14(-5.217644344783981,-0.44210679741979186,-103.08240347103569,1.002695397287018 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark14(-52.22358237338862,-1.5458306486157254,-0.275547673660137,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark14(-52.25014577247665,-0.36508084929034607,0.0,8.846013370572429 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark14(-52.43806339302953,-1.4519219922865974,-42.389652197898926,-82.66023375665036 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark14(-52.498271559240074,-1.3983572473787655,-78.71644262346945,-76.191952788885 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark14(-52.66901562160946,-0.8773794704683056,-65.08345344039563,1.0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark14(-52.70735129724058,-1.1253455938488486,-23.605870277849064,-1.0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark14(-52.81676118813961,-1.5707963267948912,-46.838848947637416,2.064227536522374E-16 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark14(-52.86959313954753,-1.5707963267948961,-1.5707963267948966,67.51573607881085 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark14(-52.87364885594733,-0.008340163528131939,-35.46290434063292,-0.9999999999999996 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark14(-52.94817140670165,-1.5707963267948912,-1.353833159913311,1.0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark14(-52.96403404903903,-0.005690711003748604,0.0,-1.0000000000000009 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark14(-53.02389317449645,-1.5707963267948912,-36.978265755923445,47.48985362335509 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark14(-53.03115048523572,-2.868675472437938E-6,0.0,0.9218214101249469 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark14(-53.035382794415334,-0.41436814858981713,-49.95591163958896,-44.95109504026953 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark14(-53.12438089402851,-1.22664450721782,-72.26832696231264,-82.44346636754389 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark14(-53.12878747445403,-1.569679205614139,-64.13335508577914,-0.02919508094610051 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark14(-53.19482390814744,-0.10897481346103968,0.0,-1.0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark14(-53.26230395906598,-0.3057594610284373,-1.5707963267948963,73.81996930181006 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark14(-53.295357034057965,-1.4057577085965058,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark14(-5.329934748075036,-1.5700911298936782,-46.95484762340145,0.9326521932060802 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark14(-53.31434118233509,-0.25636277502023536,-39.112253617275485,1.0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark14(-5.332560016729992,-0.8282704458704362,-95.29089914544504,-1.0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark14(-53.39705851822642,-1.020810654724758,-3.664478958568985,79.12650389752169 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark14(-5.34222385213467,-1.306343997196114,-4.824972630618092,-0.989016555858473 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark14(-53.435905629849614,-0.1251570136883617,-16.39519452736647,-0.9690064577398914 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark14(-53.44013423077611,-1.4410277685556347,-3.99344358987476,-57.00719701786939 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark14(-53.44996714082267,-1.5707963267948897,-100.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark14(-53.49690407378231,-0.10012729983160447,0.0,1.0250665447337477E-143 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark14(-53.50753170957673,-1.5707963267948957,0.0,-1.0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark14(-53.52100437210534,-0.037579608347157345,-14.954858678795574,17.101407121299737 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark14(-53.58597219667169,-0.4104690009393767,-1.3698483543563782,87.80035982435766 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark14(-53.640396154304796,-1.7763568394002505E-15,-1.5707963267948966,39.86110465040899 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark14(-5.368606954075219,-0.8656839238465047,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark14(-53.82839577392451,-0.2990070078077598,-32.869236695015886,0.6366920994828664 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark14(-53.85047238281024,-0.12742595409966362,-48.718389668203834,-0.32464506365319257 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark14(-53.8830133667067,-1.5707963267948948,-23.250668733909407,-8.545713291437906 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark14(-54.02711668814343,-0.37244161192941466,-44.41527248358309,0.021406941115906325 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark14(-5.407577355236579,-1.5707963267948963,-37.91945812303841,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark14(-5.420048710778867,-1.4529390413327399,-14.595976441339753,14.171406085097765 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark14(-54.24082672470435,-1.184692353134403,-50.74648482653195,-0.9999999999999977 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark14(-54.36628266133345,-0.8704343804049731,-1.5707963267948957,-1.0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark14(-54.36970823471001,-1.5674241442198382,-0.9741617156103649,23.55445356785876 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark14(-54.37310244377594,-0.2502088505515847,-73.50613332327767,0.06223907420914118 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark14(-54.45668292237789,-1.5707963267948557,0,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark14(-54.476076654774275,-1.5707963267948948,-37.46418138817813,33.94289396053918 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark14(-54.50139623840571,-2.220446049250313E-16,-0.37966884978395254,-0.8107499007861346 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark14(-54.51069281306058,-3.747457406510037E-16,-44.49591131573325,8.283276333498038E-17 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark14(-54.51752860634805,-1.5707963267948948,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark14(-54.55511134780318,-1.5707963267948948,-5.177174797903611,-0.699985661920952 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark14(-54.63947330297785,-0.579560751421615,-34.47128089899327,0.49141890376327124 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark14(-54.658583549140396,-0.009208030283971332,-60.49410388932501,1.0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark14(-54.66977000852064,-0.7417168741131173,-17.358061053958764,1.0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark14(-54.6775431840046,-1.5707963267948948,64.9633604270557,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark14(-54.89787305696674,-1.2659527352482176,-5.5342044322647155,1.0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark14(-55.134166170700965,-0.07337271553997854,-37.85743247577195,-9.506792170786852 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark14(-55.15707402331537,-0.07792586069952506,-64.60617894835661,0.5291588401199192 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark14(-55.15743760756486,-1.4195404843566415,-77.92511343846199,1.0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark14(-5.523638367478215,-0.21535968519416665,-17.464636850597035,0.9972320063264463 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark14(-55.30115148787226,-1.5707963267948963,-3.435888581689024,0.43679872339089343 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark14(-55.4154389386691,-0.1161306234703301,-1.5707963267948966,-35.42630944365639 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark14(-55.46193813260996,-0.09889857050082185,36.499494556767786,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark14(-55.512294788979275,-0.056321001218937114,-3.7359964144126416,1.0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark14(-55.573783233682256,-0.0011403667386212493,-0.0016539186949946119,0.015931238464468228 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark14(-55.60921739592269,-0.06364650433821277,-19.256147178225117,1.0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark14(-55.67963223581446,-1.546229044795187,-50.85579481272593,1.0008541797039399 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark14(-55.819951844774536,-1.5707963267948948,-1.5707963267948983,-48.21742633768682 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark14(-55.89068866964962,-1.1100688001849008,-71.48601633063356,6.285792731839385 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark14(-55.92445987425671,-0.4302828284749878,-65.01734627328055,-92.00984659370451 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark14(-5.598925134241853,-1.2627358804707804,-1.5707963267948966,-47.234632122714345 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark14(-56.00601360142254,-0.8137035308714957,-86.03973717885476,0.30357256781086994 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark14(-56.050918756774294,-1.5650189052669614,-6.800097511820306,0.0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark14(-56.05203614903858,-0.34350289589202077,-37.05969237344817,3.2033329522929615E-145 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark14(-56.08116327451353,-0.9677366337733025,-1.2532852154937444,5.672303345786126 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark14(-56.09252446389945,-0.24787421195150305,-71.81457443604683,0.7126892640202074 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark14(-56.14780695687199,-1.4476866427386292,-127.87308417804583,16.619430678803937 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark14(-56.154838542172,-0.1406773232201295,0.0,-44.22496001791548 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark14(-56.16760801109474,-0.9349067693126454,-53.68481988192205,0.2531652858073852 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark14(-56.20538955550629,-1.3162311203124228,-68.73644116906846,1.0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark14(-56.20898918465564,-1.372487250627545,0.0,-2215.6429674524907 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark14(-56.30397164690021,-0.7373200858525272,-32.648317744774744,55.026295044167206 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark14(-56.3064543191331,-0.6240615255584793,0.0,1.0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark14(-56.4498150697864,-1.1409765105855723,-92.34546043861144,-1.0000625287291365 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark14(-56.491082516412995,-0.005253238985397929,0,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark14(-56.53131864032838,-1.433213056699421,0.0,-87.65878122882442 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark14(-56.57827986479123,-0.9322724425433458,-97.17906716731603,-0.6361562586328633 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark14(-56.643048056280385,-0.37188174704041677,-88.3634776085302,-24.427235981179393 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark14(-56.686050369201794,-0.10388741354579266,0.0,1.0423957057213458E-16 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark14(-56.72828899091118,-1.4346330735358777,-0.5434653588174478,-1.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark14(-56.84137346437471,-0.7413301465520533,-42.014158976554484,-0.64805346979579 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark14(-56.849036832296,-0.16275660561766683,-14.455251897633556,-32.313876039624986 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark14(-56.909201869767784,-0.28549255728554235,-8.79846133739693,-0.8626979336613259 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark14(-56.94982524889456,-1.0828272197171043,-1.5707963267948966,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark14(-56.98538944326653,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark14(-57.012906585194074,-0.8259367040684563,-63.5544795515129,-1.0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark14(-57.06685585251489,-1.5707963267948957,-46.9134806943684,-74.32962337041745 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark14(-5.707225294860123,-1.5091994888303888,-61.77560899045992,-1.0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark14(-57.20094676793435,-0.769193421847546,-76.99087209562136,0.8342503423133394 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark14(-57.21412030565584,-1.5707963267948961,2.7755575615628914E-17,1.0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark14(-57.229137560097186,-1.5579144263185938,0.0,0.36953673638760165 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark14(-57.24697939770509,-1.554125708967698,-53.88098550953161,-1.0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark14(-57.27166076901514,-0.12198849954883695,-1.5707963267948941,0.7620005865559056 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark14(-57.27963300459844,-0.4791005438897843,-35.77062009475249,11.246740957225192 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark14(-57.282459778351594,-1.5707963267948948,-15.186838232634733,1.0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark14(-57.53155964549211,-1.1671746647631718,0.0,-0.9999999999999957 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark14(-57.54063607503732,-0.7229405329550866,-82.57816177288677,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark14(-57.593242271203444,-0.43413855307227617,-10.695113064005088,-4.1002661789349907E-143 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark14(-57.60663834299059,-0.7292395044071674,-0.5919276358838738,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark14(-57.632442086936166,-1.5707963267948961,-78.13420665538553,37.93499312055425 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark14(-57.74634237569221,-1.5039371516385844,-62.46055600752164,34.55273408487737 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark14(-57.873307590805034,-0.15393399403840657,-62.53125773394983,0.026397739582277757 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark14(-57.929417918395885,-0.4249185870610486,0.0,0.00833851022047738 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark14(-58.02665964814802,-1.26713209417504,-49.88423366572111,-44.93775111330793 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark14(-58.11172045628606,-0.8475255920022718,-78.12937873574454,-0.6057208680262332 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark14(-58.165403298849526,-0.016086268957378323,-0.35114232933129075,0.9850218629125261 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark14(-58.2366927392448,-0.031300985727252616,-1.5707963267948966,-0.8385130255584441 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark14(-58.242577973612796,-1.1133848059959766,-67.2210659402583,1.0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark14(-58.339442573060595,-1.5707963267948948,-20.1062665346212,-1.0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark14(-58.35513430868477,-1.5707963267948841,-20.35351323800125,1.0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark14(-5.839973583234263,-1.4134590262955657,-47.055097139086605,-0.06299308808478421 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark14(-58.42808527998824,-0.3743239878738005,-1.54978707100301,-64.43493109706745 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark14(-58.4510902230617,-1.5707963267948912,-87.33779252358758,-1.0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark14(-58.48650017745576,-0.2604668692914497,-59.34354608260649,1.0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark14(-58.52134817471836,-1.5707963267948948,-1.5707963267948948,1.0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark14(-58.526837199076155,-1.546972635774209,-56.20470824200565,99.0102646816407 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark14(-58.7329407252639,-1.164509460921485,-37.30625629998814,-1.0000000514488179 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark14(-58.75269140524525,-1.3921588782534642,-21.974942639863258,-9.600809185883577 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark14(-58.78561607567331,-1.4285515907498727,-30.148657253682188,2093.5022548862403 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark14(-58.80250793608358,-0.020795345684818112,0.0,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark14(-58.91104456711035,-1.523231788841696,-13.467585787718207,-0.023158734859763927 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark14(-58.91530716375409,-0.001279388347800883,-35.16917431511447,0.9997659301168454 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark14(-58.92208779205703,-1.1921743356411805,-1.3308269314101393,-1.0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark14(-58.92499425341211,-1.176852664840582,-175.45662127258322,22.001064230929174 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark14(-59.10606002988801,-0.14744326211580017,-1.5707963267949054,-1.0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark14(-59.22055912014834,-1.2565164133355349,-95.04055675306023,1.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark14(-5.928712186354019,-1.5707963267948912,-67.12852418315376,24.59789594798555 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark14(-59.29236210111317,-0.38088343770323435,-0.11445945360096266,1.1113793747425387E-162 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark14(-59.314612205179905,-0.15561028502672514,-0.05404232123087256,-58.40834975147191 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark14(-59.40312691265381,-1.4804382396799067,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark14(-59.435649057120706,-1.5707963267948948,1.5707963290963327,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark14(-5.943999287744624,-8.881784197001252E-16,-74.34562588443762,0.5744475728389775 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark14(-59.475397839920106,-1.4140766583356879,-19.909965203850334,13.346438513799235 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark14(-59.49824479424443,-0.7161986895679721,-44.05439000637095,7.386382894228589E-127 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark14(-59.55097234996442,-0.5166658213662904,-60.94704842547979,-0.7858303069539926 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark14(-59.62977335319468,-0.9134209306567146,0.0,-0.7998320545226125 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark14(-59.71766807965875,-1.0470418575336566,-1.5707963267948948,-74.20102653510958 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark14(-59.801507020500566,-0.15034281299570562,-45.28798998549114,0.0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark14(-59.81743949235658,-0.8698779241802964,-22.639744787617957,-0.026873175943753543 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark14(-59.86772141322742,-0.714980739022081,0,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark14(-59.91454034795302,-0.701338481872267,-67.97537120414435,1.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark14(-59.96791792837834,-1.5707963267948948,-59.255213076422194,41.22569423679036 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark14(-60.010542502588194,-1.5707963267948957,-0.5604850775139634,-49.689473330799785 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark14(-60.26306721475116,-0.5999899664966575,-1.5707963267948983,-18.25658913971576 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark14(-60.28116195602905,-0.023490515881786744,-1.5707963267948966,-0.9765468467089549 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark14(-60.38540913899697,-0.8229777427682101,-36.50770986630534,-0.22517223203305126 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark14(-60.396851083170084,-1.4654910813490432,1.2403021285388351,-2239.9469803185593 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark14(-6.046781495620358,-0.449219716462677,-38.05481661184457,-1.0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark14(-60.48289044939246,-0.5507999895049472,-8.821844245791082,1.0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark14(-60.490463344828015,-0.20868455312377757,-34.25053889938007,-0.8363689909608141 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark14(-60.508517787613194,-1.5707963267943654,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark14(-60.67494359258483,-0.21502220467729996,-17.960515186055176,89.27462729477699 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark14(-60.75118143036907,-0.12216654737355037,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark14(-60.79407230443468,-1.4382686258134925,-66.18294650918216,-1.0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark14(-60.86407192718301,-1.4132426997744458,-36.77122555432443,5.257768403810491 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark14(-60.930214793353606,-1.5542673552281712,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark14(-60.94383573828896,-1.5707963267948961,-0.21078631344232568,-2.8627786646231065E-17 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark14(-60.956809948046626,-1.4141940107470286,-62.573266270351915,-0.9734533817965149 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark14(-60.96806464850952,-1.015375807661055,0,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark14(-60.97924935105947,-1.5127708723056106,-36.68699464531749,0.031230351917281317 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark14(-60.9868259018693,-1.5707963267948912,-37.341063841400015,-2339.011780097338 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark14(-61.01284733154429,-0.1754640315387359,0.0,1.0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark14(-6.113947260990699,-2.220446049250313E-16,-83.61192199169456,0.9013432175016138 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark14(-61.16454400348129,-1.1554677626253986,-61.45731693555079,100.0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark14(-61.18261145809457,-0.3752295809529027,-56.794710179565286,-59.39508292882372 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark14(-61.193836534137,-1.562255592492553,-36.42546494837795,0.6690880106167203 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark14(-61.262171043051765,-0.23887357614790988,-42.933566342390606,-0.21578333864279853 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark14(-61.337803813821125,-1.5125928493229552,0,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark14(-61.42202675897633,-0.28798236562368934,-35.60489533072298,28.141539754195428 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark14(-6.147377935702441,-0.009264489149018118,-1.5707963267948966,0.238258467037455 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark14(-6.148169566243114,-0.88326526114566,-35.547026099568896,1.0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark14(-61.58815674899521,-1.0133042001952461,-44.102473193829965,-1.0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark14(-61.764295505462385,-0.3091272314991613,-21.450221635075025,-1.0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark14(-61.812521063654856,-1.2312300709821844,-54.29102627356371,-4.907242272057408 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark14(-61.84088357048848,-0.7989596280153574,-13.202202609620329,-73.76877808440653 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark14(-61.856658003791765,-1.5707963267948912,-52.2402398837537,0.043866779442359435 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark14(-61.888634811711164,-0.248868221533195,-1.3914842895100301,-1.0000000000000078 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark14(-61.896050720516484,-1.2381087889315001,-71.35185341448812,-1.0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark14(-61.925172932689364,-0.32964521774778843,-1.5707963267948966,-0.9860764808434812 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark14(-61.92630880157659,-0.391115538202524,-72.28215616901227,0.18515140751342818 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark14(-6.193570216074456,-0.026356172018866086,0.0,0.0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark14(-61.985552317961535,-0.9597414353844871,-1.5707963267948966,25.992320332406944 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark14(-62.07352928657862,-1.282202752227594,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark14(-62.07876294852218,-0.30809982415165504,-42.429419801210145,0.8620568611620034 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark14(-62.07884395789062,-1.1105615041000547,-32.73095698431505,-1.0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark14(-62.15833421598101,-1.5707963267948957,-45.75734158849052,0.8085926454064918 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark14(-62.247567716498004,-0.989372256247159,-31.91748420347458,-1.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark14(-62.30988624904421,-0.9394979442628859,-1.008342401729652,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark14(-62.33142421235488,-2.220446049250313E-16,-75.7071576026055,75.97737908628454 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark14(-62.376453881141266,-1.5707963267948948,-90.29576344430788,-31.79415250058361 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark14(-62.40771283655192,-0.43480210143608927,-54.39927527253713,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark14(-62.523654471468305,-0.5028878221709032,-73.77908796231465,82.4258595823558 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark14(-62.525648881842315,-1.5109740702911925,-73.60638890269365,-1.0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark14(-62.65781742723262,-1.4229130107721737,-0.8396155614254425,1.0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark14(-62.68329038609191,-0.24035534199887298,-44.45825571580285,-0.6581720367053279 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark14(-6.273916852493891,-0.538807065643783,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark14(-62.76745235341512,-1.5707963267948912,-30.600092863450826,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark14(-62.7773296801958,-1.1852909686050563,-50.35501799927289,0.9798582141842859 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark14(-62.78943484202251,-1.5296838079842416,-4.573768453671505,-0.14071834030310537 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark14(-62.907712793163455,-0.955412250328125,-1.5707963267949019,-1.0000000357654968 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark14(-63.011714808097445,-0.8470424198504496,-2.220446049250313E-16,-0.6642971880501609 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark14(-6.309877762801518,-1.412550208370614,-3.258157477836235,0.5236218337597325 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark14(-63.20048618370819,-1.2634903574037328,-37.23912425284625,-0.5847758720076099 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark14(-63.207694338393694,-1.2896171740516222,-15.418252382010095,-2195.2923420368797 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark14(-63.26639373992611,-1.5500647475360565,-3.275447963682815,1.0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark14(-6.336943519697471,-0.8704035798025935,-90.8194405703903,-0.09250103094936168 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark14(-63.4884937953755,-1.5558322683378318,-100.0,-1.0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark14(-63.51553053300541,-1.381183083590701,-0.9521871418702043,-0.6160419247001994 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark14(-63.58703380453664,-1.3676683820318682,-12.104396460994721,1.0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark14(-63.797647539748475,-0.2242350360618629,-59.958771336901215,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark14(-63.80399439156326,-0.7532132772450761,-52.09483840644964,-0.1344184928407397 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark14(-64.04358478340761,-1.5581944547025692,-29.9441180790227,-0.06256308646792906 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark14(-64.13495879140862,-1.5707963267948948,-1.5707963267948983,-73.54207840957281 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark14(-64.14920656066715,-0.7031918573226612,-30.684049239701377,-100.0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark14(-64.17930484155961,-0.9363578241000611,-1.5707963267948983,-2162.3293761012374 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark14(-64.20609545188941,-1.4048572181491354,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark14(-64.32266660575733,-0.8702006673071486,-13.81117948927825,1.0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark14(-64.42614763372164,-1.533746168133251,-4.659423972996622,-1.0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark14(-64.4787810601399,-3.892645220192458E-17,0.0,-46.26997516014229 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark14(-6.448065710280172,-0.078419859012544,0.0,-32.144237333019916 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark14(-64.49378492181444,-0.6891862974467609,-66.63445426758206,92.55957395013922 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark14(-6.44945532006777,-0.08791056126841851,-7.202379122010755,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark14(-64.56343491427624,-0.07523714195874473,-97.76426564516896,-0.05325759400016991 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark14(-64.59149919563849,-0.9953013706997395,-1.0210824076745224,-0.576717768105747 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark14(-64.66636948450311,-1.5707963267948308,-71.7136166155448,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark14(-64.73110197963823,-0.22306790328566886,-29.745758969190607,0.43782309168972444 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark14(-64.76772469531286,-0.10950130892126497,-35.22468333194508,-1.0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark14(-64.76800916839858,-1.515792052657999,-100.0,84.04987596015971 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark14(-6.486280722322761,-0.5900813864784059,-1.5707963267948966,48.311367131166364 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark14(-6.491988076996488,-0.03928887538930326,-1.5661081557755474,1.0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark14(-64.95131213455967,-7.434232425492489E-16,-91.4843682285568,-1.0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark14(-65.0683173229587,-0.9007359092342466,61.32951759598498,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark14(-65.10175540066956,-0.1940643011469545,-66.69368656770456,1.000000000000007 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark14(-65.10691833749654,-1.1915389701652828,-164.63515606276206,0.2744947311998067 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark14(-65.40243128356971,-0.37541945285670764,-30.181563213715815,58.99130901608419 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark14(-65.46171632101667,-6.938893903907228E-18,-1.5707963267948966,-1.0000000155830415 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark14(-65.46688037191758,-1.5427951990313,-95.29853921734576,-0.06255274926749418 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark14(-65.48216859324656,-1.5707963267948948,-32.39451896716044,-0.3966885603728586 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark14(-65.537130186748,-0.28892431873274677,-72.40714280001025,87.58661175639891 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark14(-65.5623707398518,-1.2763026455322513,-14.751549919720699,-1.0000357080059623 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark14(-6.58511515584758,-1.0395827555028128,-36.79234603119171,1.0000094349809332 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark14(-65.88452898240229,-0.7706311268666823,-9.455685222112251,-0.9770352920528317 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark14(-65.89865014583658,-0.10062337401767261,-46.27754613847593,0.0863146279828868 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark14(-65.99825776872068,-0.7858614590444191,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark14(-66.15298944951599,41.22051404335872,0,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark14(-66.32662906248619,-1.224963340256527,-1.5707963267948966,-4.06326069975718 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark14(-66.37684310919673,-1.4690765735820506,-0.03383235254073613,-1.0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark14(-66.44319040576016,-0.6150706426962387,-84.64893270691688,56.47897102917857 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark14(-66.47045231141044,-1.5707963267948948,-100.0,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark14(-66.48387234633017,-0.16861965604079482,-0.23392220543393527,1.000000006752053 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark14(-6.6593562907320205,-1.5707963267948912,-10.498325584524558,67.59929441345997 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark14(-66.5967300845449,-1.1015877044304851,-25.766404728979623,0.36209715013026544 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark14(-66.78345007289043,-1.047670616245051,4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark14(-66.81265959851174,-0.4896263308312391,-55.58279944741705,-0.05407577881729486 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark14(-66.82973235112777,-0.046700178132079544,-54.638015696824915,0.05439840546412954 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark14(-66.925566017336,-1.5243587752517724,-44.10632915708487,-0.9999999999999964 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark14(-66.94769294275852,-0.5253342915914656,-135.10081882850227,-38.16220179772609 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark14(-67.03129539278515,-1.5707963267948961,-88.04726803496385,0.048057156334649936 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark14(-67.07480842708422,-0.43388824785092384,-45.22900399817615,0.031078566330367347 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark14(-67.12884432810795,-0.09237757770523422,-38.090065906376495,1.0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark14(-67.33861303556282,-0.04847092136464087,-5.0961094031157,0.06038654131689633 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark14(-67.38966055805578,-0.9859520867766587,-77.84645597952817,1.0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark14(-67.40455303662662,71.76116818019801,82.96285815645595,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark14(-67.43268189521488,-1.5567682880924125,-1.5707963267948983,6.765776736700715 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark14(-67.46280548801948,-1.5707963267948963,-32.6336932936155,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark14(-67.46967591937735,-0.11838927901701699,-10.530831518624325,0.9225165544206353 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark14(-67.71231037154304,-0.7401178118497773,-70.0023286317677,0.8202578595498644 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark14(-67.71833023074515,-1.002609915431436,0.0,-1.0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark14(-6.77506309611551,-0.7116119488003969,-1.5707963267948966,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark14(-67.75424262692032,-1.4345377826649193,2.500144541570279,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark14(-6.77873478542358,-1.5413934235532323,-17.263289088266458,-1.0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark14(-67.90417439532683,-1.1985359294287818,-1.5707963267948983,-1.0693177571483223 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark14(-67.95228230352431,-0.05918501416200596,0.0,-1.0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark14(-68.04674205526727,-0.6235515654188499,-14.718609333105285,1.0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark14(-68.15592212534449,-1.18263623722396,-57.03969042342277,-40.49685803468947 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark14(-68.162998357269,-0.6214909253738319,-38.10048363047276,33.43385224864008 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark14(-68.18606162440274,-1.5707963267948957,-98.20902850163132,-1.0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark14(-6.8266926379746025,-0.7006303479187319,-89.32663975635482,0.008238555846557971 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark14(-68.34294877151048,-1.5707963267948912,0.0,-0.23974131694376688 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark14(-68.42340258783238,-1.5707963267948963,-97.83905872361926,31.211429193644655 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark14(-68.48214490783022,-1.5707963267948961,-90.75606661190976,-80.35594949787259 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark14(-68.48332480358621,-0.09478566466122013,-19.748204777787134,-0.04731676212936455 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark14(-68.48873089921659,-0.28189607411636053,-11.868277138907303,-0.04050590030619692 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark14(-68.59073293400921,-0.3569668181136593,-64.40213904330506,0.6660077932496229 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark14(-68.59192329810918,-0.4347911341178307,-15.818397279389202,-0.07798529154772282 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark14(-68.59334906775206,-1.5707963267948912,-82.61811330449436,-0.43821911958372084 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark14(-68.73556513023237,-1.570796326794896,-11.498839526832805,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark14(-68.75126658453274,-0.36227699226789306,-68.1716487728973,0.7387681590909789 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark14(-68.8735932127429,-1.4466076921362414,-1.5707963267948966,-0.8388290638175735 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark14(-68.95103923325232,-1.5707963267948963,-4.367690545059884,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark14(-68.97500946546906,-0.7162784718252817,-61.79283696616963,-0.719229997123091 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark14(-69.01979676496677,-1.0305644766480047,-48.03000947701369,-1.0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark14(-69.07942956957852,-1.5707963267948957,-4.338506633222753,0.9999999999999393 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark14(-69.13604310780833,-2.7755575615628914E-17,0.0,1.0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark14(-69.16414165252971,-9.350437394825174E-17,-1.5707963267948966,-0.021202255174791296 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark14(-6.9167140706004915,-0.08588762236423747,-73.25934019109438,90.72531309691595 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark14(-69.20668698670553,-0.322223096419771,-34.13702422369753,-0.39740466023271204 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark14(-69.25667884360915,-1.0572856185755946,-73.35021841391,-65.61638609899526 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark14(-69.25829659661426,-1.235901777439116,-36.72173986034625,-0.056271445550132596 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark14(-6.941753671821125,-1.0315245370895965,-67.35300423846456,-16.622132934938723 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark14(-69.42782332507791,-1.190006074220124,0.0,-73.7471194790557 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark14(-69.44897959439629,-0.5662718233425288,-36.757585673803646,-1.1638761582671275 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark14(-69.46972723858735,-1.4877107732421968,-100.0,-0.2294533697310847 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark14(-69.6163178657965,-0.6251228201374667,-0.05232480805514303,-1.0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark14(-69.69131123580041,-0.9961996877405785,-78.69700621328597,-1.0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark14(-6.976607691127713,-1.5707963267948963,0.3565282301944206,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark14(-69.9589050295989,-1.5707963267948912,-59.72422235388237,-1.0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark14(-70.02926692063573,-0.6040133665200287,-100.0,0.9787710242394296 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark14(-70.03567985035771,-1.5572747413457562,-23.081192963658317,-29.190057914514576 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark14(-70.05292718350523,-1.0347600248286188,-1.8133294656183299,0.0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark14(-70.39659255662689,-1.1894695550726448,-14.20974586726815,-1790.3032587391467 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark14(-70.5400622831302,-7.772174505430855E-17,0.0,-0.6927510665152325 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark14(-70.65623266230563,-0.2912655806364697,-0.532223268765132,0.0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark14(-7.072433840466559,-0.09533157084417887,-37.7796700513203,-3.8481254696029197 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark14(-70.77479603166852,-1.4259407839240963,-75.17735753897006,-1.0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark14(-70.79214647919511,-1.080943998367136,-78.16904317499903,-85.29507004930443 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark14(-70.81159395009998,-1.0838292187068674,-61.40058597432223,-1.0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark14(-70.93324387174818,-0.06416036473857734,0.6832615031972592,-1994.7993493975323 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark14(-70.93665596523134,-1.2406545883234414,-9.612218448327614,0.06255272734762703 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark14(-70.94767974202534,-0.7514731371503216,-100.0,-0.5524047075335297 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark14(-71.0136653096246,-0.08645572337515248,-6.362689205691893,0.8834668677974472 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark14(-71.02391178856772,-0.8248756401072477,-22.701297052323955,2180.139022755965 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark14(-71.09442421476568,-1.570796326794893,0.04240976516862866,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark14(-71.11698886710184,-0.7966673267567587,-1.5707963267948966,66.44537244113708 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark14(-7.126525246951984,-0.4454509445882526,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark14(-71.29282858831233,-0.06523863826985891,-44.209278509438064,37.649899262185684 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark14(-71.38862453748787,-0.20105930130997954,-81.60416211098489,100.0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark14(-71.4432832147418,-1.5707963267948948,-23.884075526921897,-53.953157773710835 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark14(-71.53911197058812,-1.5707963267948957,-0.8495537378744542,-1.0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark14(-71.54424266870672,-0.6682200159085498,-130.12643531739792,-55.68560524074184 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark14(-71.56163561576464,-0.012962239216758709,-94.13818621199711,1.0000000000000004 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark14(-7.162790950718092,-0.23570144093481848,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark14(-71.73268356102727,-1.191066458462649,-1.5707963267948966,79.8066269251449 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark14(-71.79467089034601,-0.7324230789208537,-0.16605354233929326,-1.0000000000000009 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark14(-71.86748158733259,-3.8052975230437165E-5,-1.68342894597448E-5,-0.30496270952813465 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark14(-71.9767856669379,-1.5707963267948912,-74.96216877884254,-1.0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark14(-72.06384415634912,-0.9556635242750326,-5.612617917347616,-39.699805707051915 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark14(-72.11243203274697,-0.006410905634641081,-45.688519743472675,-0.9999999999999964 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark14(-72.19401752187129,-0.7438363929274716,-12.200463663214492,-92.78941273244938 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark14(-72.22475685277148,-1.541674773596652,-54.98284786341668,1.0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark14(-72.22515681547182,-0.42943004517616146,-99.46044749931085,11.594192493119621 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark14(-72.42772281614356,-1.630320093332419E-15,-63.33432537715829,-44.55805776078476 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark14(-72.58792535907801,-0.6986303764051622,-122.8077819936667,83.99002557101275 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark14(-72.66548969018349,-3.552713678800501E-15,-57.63672618502807,-91.50327800005171 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark14(-7.272051209774652,-1.5707963267948963,-1.570796326794001,0.05084701743274615 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark14(-72.80751075496293,-0.20382730557111195,-10.856015091650022,0.12249677615745572 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark14(-72.96006547962916,-0.9194330948893326,-21.472124298614442,-87.17880081793207 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark14(-73.02065346660814,-1.0664482160974533,-31.362587324430297,36.685798799108184 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark14(-73.048017073835,-0.6545348220694918,0.0,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark14(-73.10944323600735,-1.2289786496059,-89.6271088102865,1.0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark14(-73.11852005097273,-0.8424628353422285,-1.5707963267948912,1.0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark14(-73.2254472735272,-0.23667138304304278,-71.1278184389195,-1.0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark14(-73.2869380855815,-1.5707963267948948,-11.206380002405908,0.0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark14(-73.41820619301785,-1.0371571083347997,-7.049772348379319,-4.445964072700653E-9 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark14(-73.43686527015731,-4.487091047695619E-17,-30.13844956757459,-0.990659755846316 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark14(-73.45156461151137,-1.5689273260008338,-94.2666327111284,-0.8046737870455797 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark14(-73.51939199288988,-0.5762528235251629,-0.4034552908407223,-1.0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark14(-73.56355727344088,-1.5707963267948866,-40.9603568631809,-0.21055947937887376 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark14(-73.62943603677381,-0.8412446345840827,-1.5707963267948983,-0.897840447954867 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark14(-73.70703874045552,-0.9556324533456071,-19.235043887134125,0.0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark14(-73.8177982581681,-1.2552607005767227,-145.08162499497325,13.75521033604008 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark14(-73.8795544614197,-0.15706314667217414,-4.4363158870245485,-1.0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark14(-74.02804458656405,-8.850933980626347E-15,-76.98991468368149,1.0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark14(-74.11559938646712,-8.881784197001252E-16,7.483477921233423E-16,2238.8270043512853 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark14(-7.4436403798514466,-0.5931634225382594,0.0,86.37582793668547 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark14(-7.455204084920172,-1.1196624952237921,-31.53177872734551,-0.02415355133270282 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark14(-74.71137867419776,-1.1466041042132542,-3.20598890986118,-25.19616757440174 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark14(-7.474599407835836,-0.7404254386905557,-63.364971827273365,0.06262437260905722 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark14(-74.89948287821252,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark14(-74.90730345502375,-0.561909564405324,-13.571826342963513,1.0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark14(-74.941766063766,-1.0171232478956616,-1.5707963267948966,1.0000000942250498 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark14(-74.96112569604901,-0.7525866665588179,0,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark14(-74.98392016859418,-1.4163892351107332,-44.36855559649447,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark14(-75.03038760008316,-0.9672435598382592,-54.60618479174633,-44.67271762872207 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark14(-75.09464800179302,-0.8864833330296621,-24.42247496277901,-1.0000000000000004 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark14(-75.1007469774716,-0.2875986993284281,-100.0,2090.2334698195937 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark14(-75.11744498502522,-26.28301356195854,-6.6190895843576385,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark14(-75.20089535874632,-1.0147333862308077,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark14(-75.2593318088856,-1.546326726905349,-45.33368114625544,65.71572120086623 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark14(-75.29605796908776,-1.5707963267947882,-77.3336821094434,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark14(-75.3699775812566,-0.7718716854863118,0.0,-0.9704469174203718 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark14(-75.45653630756922,-1.254113049643192,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark14(-7.551448381990225,-0.21756195935517642,-48.24976160424885,-0.9677670214294338 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark14(-75.64457415961482,-0.23854514050335562,-30.576645835573302,-58.682761728747046 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark14(-75.71371887059712,-1.5707963267948963,-31.944568109584225,-0.09176185745312981 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark14(-75.81776487894341,-0.22455427627392788,-90.65983813794975,48.98480722119757 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark14(-75.92026059305826,-0.11064799290222649,-74.43300995038922,0.7258671799818773 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark14(-75.94665147153401,-0.4406468631614631,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark14(-76.01893365416593,-1.4842038479922526,-1.5707963267948966,0.9796626567314405 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark14(-7.611634292369099,-0.7397376717001535,-31.548877186762653,1.0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark14(-76.1464634369188,-1.5707963267948963,-36.948797744250996,0.0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark14(-76.29267882463944,-0.21058446535885866,-86.4686335835882,90.48967640304758 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark14(-76.48725242418125,-0.7555140161249059,-25.627247587894725,-0.02274190395203547 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark14(-76.56427817056894,-0.06850905663529348,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark14(-76.73528769257565,-0.5191916202863531,-202.75636492997376,-54.01574286393544 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark14(-76.75452496504033,-1.302568752378817,-1.3623192573554705,2130.5492558586507 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark14(-76.82825803541053,-1.032146483978425,-39.535951558281354,2.926047721682624E-98 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark14(-76.86168715499848,-0.8196614568477392,-53.854468626565264,0.9999999999999982 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark14(-76.9370763925338,-0.3466717240792416,-72.70639203329878,64.61018589038599 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark14(-76.99730015749452,-1.5707963267948912,-5.881542148019477,0.009232944190559707 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark14(-77.23815105784854,-1.5707963267948912,-4.617772125222274,6.596361553706913 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark14(-7.725469972912833,-0.1752876375314969,-4.632928274763927,0.0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark14(-77.26123530957258,-1.2300166512659438,-24.741447807698044,1.0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark14(-77.27182963062423,-0.07655164313006857,0,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark14(-77.32624413028941,-0.4696880740192798,-1.5707963267948966,0.7011351876729721 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark14(-77.43466017099968,-0.27572379745129183,-2581.6220108617863,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark14(-77.44323591092625,-2.220446049250313E-16,0.0,0.06255499513628389 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark14(-7.747128723791161,-0.013181418215201135,-32.69675357492201,-0.9989335860376557 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark14(-77.49404740422828,-1.7763568394002505E-15,-1.5707963267948948,-36.20878977667242 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark14(-77.51927409427147,-1.5707963267948912,-23.243216219716842,-0.02821542287219618 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark14(-77.56885417201775,-1.4844110709071647,-47.75307731203374,-1.0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark14(-7.769002370676196,-1.1616364506965031,-100.0,0.06255261718347548 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark14(-77.77280747411928,-0.5553831365741031,0.0,29.385137669514187 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark14(-77.81097958270524,-1.1237112488967702,-10.860048208147875,5.421010862427522E-20 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark14(-7.7958645630365515,-3.412715674666426E-15,-53.85596082684567,-1.0000000000000002 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark14(-77.98074002620825,-0.3920020737035572,-88.12156782655612,-0.7309746393469373 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark14(-78.0050457742436,-1.1547797666507194,-100.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark14(-78.0789107048903,-1.570796326794893,-37.07471219006065,1.0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark14(-7.812604119710688,-1.4680537066308923,-42.19246472773977,-0.06040510622486178 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark14(-78.18855288843444,-1.1464466091769148,-19.17360819484674,-0.8865284196988625 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark14(-7.825449658866071,-1.5669896824100107,0.0,1.0000000724560545 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark14(-78.32012173084388,-1.5707963267948948,-0.18483460419515918,1.0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark14(-78.44730401173126,-1.5707963267948948,-33.02359934430265,-71.89633882516897 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark14(-78.54278925349604,-3.552713678800501E-15,-53.80882356691154,-81.14462007627361 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark14(-78.79098634626368,-0.028847987031277222,-69.01658868971386,45.31461529823573 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark14(-78.79310250821473,-0.025828160677978745,-72.28290910344201,-1.0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark14(-78.89833384184183,-1.5707963267948948,-73.34701085654406,0.023586163278020336 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark14(-79.07826039038858,-1.5707963267948948,0.0,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark14(-79.30787280734852,-0.04424263035774301,-13.232569394389529,2021.4705408017355 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark14(-79.3243133335971,-0.9673476177884462,-41.28591362710694,83.68703001669297 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark14(-7.947140561581961,-0.08234698630219589,0.0,1.000000042584813 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark14(-79.55487363642808,-0.5116258840084713,-43.01838361131958,-89.65475482790612 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark14(-79.60711556950346,-1.5644252217484629,-24.744560320690447,-0.9661859716264056 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark14(-79.64504733471256,-0.2747732534315688,-14.149087466599397,45.33292375083781 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark14(-7.972290372931326,-0.7867268025508083,-1.837051897216753,-0.005066566341295542 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark14(-79.74227276063256,-1.4870594550813137,-1.570796326794836,-1905.2959688680626 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark14(-79.82721705030171,-0.12927119894925912,-1.570796326794883,-1.0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark14(-79.83423605375968,-1.5707963267948948,-1.5707963267948983,-0.015117442405415384 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark14(-79.9841493043837,-0.015971090567483293,-70.47047987379126,1.0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark14(-80.23017296779861,-0.462526439736275,-74.75103414371833,0.2231480024059484 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark14(-80.28408953870436,-0.7594119322165223,-25.312525151851872,78.59559364630886 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark14(-80.31610970240133,-0.11970280721335869,-12.893761994044553,34.87227390054089 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark14(-80.3889369468452,-0.07360722235721254,-1.528759021754959,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark14(-80.55829306179453,-1.539186771822077,-60.10565249812621,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark14(-80.67199345206835,-0.3695476204853442,-25.388796216747977,2065.315825561028 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark14(-80.69719171689457,-0.6897306646859365,0.0,-51.98850405133377 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark14(-8.082034972068115,-0.5428496604920966,-0.8344968158393216,-0.011946085794353967 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark14(-80.90045219960484,-1.5707963267948948,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark14(-8.09849887002149,-0.281030332225356,-107.49751439430298,1.0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark14(-81.04630092581306,-0.6082179849722726,-28.71156045372078,-2163.3614393314074 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark14(-81.15341536914994,-0.7569285152471807,-7.934262121289109,5.262515705694028 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark14(-81.18661643105823,-1.5707963267948917,-1.5707963267948966,-0.009399208670461975 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark14(-81.276602163113,-1.3676294954449566,-51.937953011084915,1.0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark14(-81.28178998103309,-1.068717495134051,-6.306014966391487,-1.0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark14(-8.149510299162356,-0.9313660929957609,-1.570796326794901,-1.0000000000000002 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark14(-81.49847839999737,-0.3538835328395812,-0.7936602948234645,-0.03897999634987287 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark14(-81.81434983012572,-1.4424313007650764,-83.86008535909899,0.9974199235764032 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark14(-81.81695786244298,-0.35002911135106984,-1.5707963267948983,0.3432637500397948 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark14(-8.184271724241327,-1.202739894904604,-26.946964685016088,59.876217470671406 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark14(-81.86481182565417,-1.2724359732425712,-99.05339046824268,0.9989264308521816 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark14(-81.92067279309941,-1.4847167429440409,-97.35794118261244,1.0438931232257012 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark14(-82.0050189422933,-0.17049171102072225,-3.2369359251473284,1.0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark14(-82.06052401930886,-1.3609047621858965,-11.724550624010233,-0.05179943672700027 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark14(-82.16154446303588,-0.17022457455468398,-31.13185194819738,67.90548163873075 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark14(-82.16263323272409,-0.43176753683324876,-88.39799091168247,2267.3992404215132 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark14(-82.31892452008962,-0.9288814344190874,-94.3293980953365,70.03068154285998 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark14(-82.34573941121353,-2.1401948972816178E-4,-32.67196452746184,53.27763630024907 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark14(-82.4822509863921,-1.392877380878219,-0.4190954342329437,2244.628839812615 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark14(-82.62456200802731,-0.5550712769184923,-82.82193812293606,94.49365592044833 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark14(-82.7764813066527,-1.5707963267948948,-24.729232368389376,21.28721681595968 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark14(-82.88382746197968,-1.3954179199728058,-1.7763568394002505E-15,1.0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark14(-82.97062052683377,-1.1484317156606607,-0.6382338629625341,1.0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark14(-83.09449738747813,-0.17709796767808106,-36.957746498985806,1.0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark14(83.10569032127864,-0.1887384474524385,0,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark14(-83.11111571682494,-0.9723256738414472,-100.0,-7.160560792693538 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark14(-83.1977523406736,-0.8564350423825783,-33.15656439249526,-0.8813991193475244 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark14(-83.33573691968571,-1.5579604673927676,0.0,-0.009619857180138688 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark14(-83.56936749256118,-0.6902362092026065,-5.803475309169556,-1.0000000000000009 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark14(-83.58702619957774,-0.8598144639764769,-67.1758684807661,-38.38439710357042 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark14(-83.61431641896193,-0.09744574361242013,-45.286702545706035,-1.0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark14(-83.82497449929274,-0.8330726701813589,-60.79835851846258,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark14(-8.390078977814653,-0.9761286479172788,-11.672367778198975,0.940979082896785 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark14(-8.400339850840226,-0.7854850719555557,-77.73401832834874,1.0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark14(-8.400881171503144,-0.05678888891579925,-35.51779831840054,60.26973009621847 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark14(-84.05772539396297,-0.9246685253882388,0.0,-1.0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark14(-8.406115589647921,-1.570796326794891,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark14(-8.41165189299705,-0.8105851233108857,-22.2987984567267,0.9999999999999947 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark14(-84.13325305281984,-0.6361599872125794,-1.5707963267948966,47.885689388345305 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark14(-84.27699523516253,-0.8740666528219995,-53.34074352461911,1.0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark14(-84.37223292583698,-2.220446049250313E-16,-14.663902990167315,1.0000005805561714 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark14(-84.37680229989047,-1.5545776187373586,-100.0,-0.2736466713609039 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark14(-84.57454071641696,-1.5116635455411231,-83.90912493254964,0.9638763500591141 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark14(-84.58534520727216,-0.5799129785103019,-99.91310441756467,-3.710669872859488 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark14(-84.72520438188307,-1.5707963267948963,-1.5707963267948966,0.9999999999999986 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark14(-8.479662156794127,-1.4218989724944215,-1.5689600280254796,-0.41274949040361747 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark14(-84.80236688294215,-1.7763568394002505E-15,-0.11779129122467047,-0.4106825440243864 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark14(-84.88150029469179,-0.422258414329668,-28.807695981780896,0.10810335992780562 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark14(-84.92084667334069,-0.012971284787357583,-18.528620440194427,0.0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark14(-84.93982482945344,-1.5707963267948957,-62.51544382917531,-66.2958350695459 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark14(-8.495579053312639,-0.7960973612850686,-1.341862662794128,-1.0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark14(-84.9784862194636,-1.3492913050128796,-11.804796618929625,0.0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark14(-85.00010159121754,-1.5707963267948961,-9.48220291081918,3.6931914471142943E-127 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark14(-85.0904809921932,-0.2365248669518678,-29.206720975051013,-26.461069881557833 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark14(-85.19341101094327,-0.7234619469286752,-65.9327291895841,0.5911333404342933 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark14(-8.522901804271442,-1.3255280902173254,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark14(-85.35650061007146,-0.8618151653062243,-0.01685546679961125,-100.0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark14(-8.542324362662114,-0.04676990680018939,-100.0,-34.929163768355195 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark14(-85.45206688489131,-0.18097724570349452,-100.0,-2.967364920549937E-67 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark14(-85.48334445830602,-1.5692653456076506,-1.5707963267948966,50.97338512164886 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark14(-85.53449192668853,-8.881784197001252E-16,-100.0,-29.443425171196868 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark14(-85.66002750787015,-0.004015324057058664,-1.5707963267949019,0.02218579998882103 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark14(-85.70333993128241,-2.2958925669509362,-7.179011314429517,0.0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark14(-85.80545396669572,-0.3872008027774737,-2.082264324655983,62.324524384450484 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark14(-85.87392587322167,-2.220446049250313E-16,-59.474728949734725,31.979819374156136 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark14(-85.89509569339116,-1.5707963267948912,-93.86759655167754,1.0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark14(-85.92466787450472,-1.3119538694019035,-77.013686482526,2.8063255149390662 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark14(-85.95503566712152,-1.2434586225432502,0,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark14(-85.96220532838065,-0.21230188528442456,-30.561264546234963,1.0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark14(-85.98451748526199,-0.13088561191147896,-88.45914820056706,-1.0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark14(-86.0392337212974,-1.5707963267948948,-39.65866103826187,1.0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark14(-86.20113417262539,-0.13610965530079033,-67.18770513890621,1731.1113742260902 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark14(-86.28346230330773,-0.041282792606964366,-1.5707963267948966,2071.601835476696 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark14(-86.65262746145393,-0.08159472426085243,-61.19648235352477,1.0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark14(-8.670949392570535,-0.23743186296464153,-99.01683001796846,81.95837693200508 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark14(-8.671563977246578,-1.4558622409622317,0.0,0.7134548999023628 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark14(-86.72067265134768,-0.752722074670968,-88.05035874897257,-0.8954693816066652 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark14(-87.03505647166602,-1.5707963267948877,-1.5707963267948983,13.166870155047711 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark14(-87.06873353603206,-0.6334422512873357,-34.18916272479147,-0.9938713259133152 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark14(-87.09265019738663,-1.3534116717853297,-9.960113139133554,0.0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark14(-87.11611751602857,-1.4414715370316427,-35.42948571825286,-1.0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark14(-87.16887431651372,-0.021129785329881547,-52.00777094622661,1.0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark14(-8.719073946328757,-1.5707963267948912,-44.252482591391185,-0.13789229672360515 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark14(-87.2046486346495,-1.5707963267948948,0.0,-0.041890350159231364 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark14(-87.21625864326556,-1.5371354616856006,-37.044242385416595,-0.2876092200566971 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark14(-87.37888844372536,-1.4582130563146638,-79.78111412495747,-0.05762265146674084 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark14(-87.4535843927442,-0.455088541104671,-32.90604278522624,1.232595164407831E-32 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark14(-87.51991077374122,-6.920163698091695E-5,-37.81774257342809,-0.9542639296314216 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark14(-87.60230118311436,-1.425078622279187,-72.51685085525072,0.25666286353548673 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark14(-87.64373223599797,-1.091829281792654,-12.206407579397743,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark14(-87.70140018215042,-0.015333953097135769,-63.56677598474465,1.0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark14(-87.79307451919529,-1.394424480268908,-68.85287315910045,-4.477235181457373E-4 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark14(-88.19157998634054,-0.9875338371819756,-0.34242230845859045,-1.0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark14(-88.5773456223311,-0.2581152216217935,-38.66991376925626,-1.0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark14(-88.69902054185619,-0.016329365759546532,-76.77985588909806,0.05717838913703494 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark14(-88.89094622512962,-0.014394063694666824,-1.381971954115521E-4,-0.017793875717042246 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark14(-89.18111095284982,-1.5707963267948957,-85.82733758305025,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark14(-89.24957804956641,-0.20612773868959347,-8.664674626000846,0.03698552886836857 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark14(-8.934431878236442,-0.1398492382453702,-1.5707963267948966,-85.3835648188066 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark14(-8.94027920381791,-1.376047211064306,-73.47812331718119,-85.61463294951592 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark14(-89.4426122133517,-1.5707963267948948,-32.645485586379635,1.0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark14(-89.45498615350876,-0.8746483729448613,-99.54099148917406,-90.13516222336358 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark14(-89.46600675047713,-1.5707963267948963,-74.91669945160002,-39.55465281642483 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark14(-89.67942555079847,-0.06928127598328679,-1.5707963267948966,34.236141104047434 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark14(-8.984932374561595,-1.179349100134181,-91.52463955338973,-0.16958562008265998 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark14(-89.92904640745209,-0.7805967185641449,-3.185071336575661,0.5908724070670709 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark14(-8.99605376275872,-1.0183425066508498,-66.2579320724076,-1.0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark14(-90.0107839782132,-1.158510909102032,68.40393542570422,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark14(-90.02745975222255,-1.2815448145482853,-24.865569390059775,0.05781948642291887 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark14(-90.05874907290969,-1.5619278984817775,-49.28419322331702,1.0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark14(-90.06177062050406,-5.552326622685333E-13,-1.5707963267948966,0.003344477814100232 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark14(-90.0688295261337,-0.7968810273897826,-33.92430304758902,-0.33444150414490537 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark14(-90.13316331586662,-0.6984955562642476,-41.2514656825544,-95.99098708891299 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark14(-90.1900364731685,-0.9761007378212594,1.4550300639341494,-30.11966581319185 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark14(90.21434171814903,-88.32661615324015,42.94714429506092,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark14(-90.2805816428448,-1.3995295650075286,-80.30371586567261,-1.0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark14(-90.3775714138222,-0.0018229344652189762,-51.99533416268175,0.0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark14(-90.39238987134472,-0.768157727022286,-0.6675020097889078,1.0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark14(-90.43598264170646,-1.1102230246251565E-16,-40.72214675361988,0.13087040230188318 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark14(-90.50286913538126,-0.2978500241188957,0.0,71.42142359814446 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark14(-90.53573193023622,-0.8660339021887019,-44.49345268815229,-1.9192258817182655 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark14(-90.60774328477963,-1.0116659500687155,-1.5707963267948966,46.681948944114254 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark14(-90.62236717483752,-0.05154891990401178,-38.87043163043847,1.0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark14(-9.06322148418564,-0.2941619800085542,-59.350166134941546,-11.327480865733655 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark14(-9.072833657566099,-0.0556236824332432,-67.58353738691181,0.5996151218798573 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark14(-90.77884616784897,-0.47591101886673365,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark14(-9.080384627957594,-0.9811729063001806,0.0,-48.9319232147519 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark14(-90.84572074391865,-0.8570517090360392,-1.567851085301945,-0.010137258508291336 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark14(-90.91398037458788,-1.4124729387369062,-6.103292711329295,-1.00000002936371 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark14(-90.9669952292552,-1.3449758170211037,-0.6016893733743616,48.5137570586467 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark14(-91.09707699686973,-1.5707963267948948,-23.507792641192495,-2294.3939364610374 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark14(-91.2499672178026,-0.26575245859610774,-88.24669909391233,-11.646853910455805 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark14(-91.31021034927461,-1.5707963267948948,-98.50532414856895,0.3256540574502565 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark14(-91.37867329933172,-1.5707963267948948,-93.30762100738167,94.45616884429057 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark14(-91.40462040314996,-0.4596765953992237,-8.999153736541984,1.3293219135748586 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark14(-9.148101232473962,-0.47705892762337365,-44.4181685539417,-23.225651326840577 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark14(9.176027121693394,-2.7755575615628914E-17,0,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark14(-91.81097184400008,-1.5707963267948963,-47.11788102877231,-0.5960709398014905 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark14(-91.82626342345267,-0.8749825180823835,2502.8995830364206,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark14(-91.82772917083743,-1.5707963267948948,-56.5689418876584,3.3087224502121107E-24 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark14(-92.0545989378571,-0.7394434117329842,-19.016871170137534,0.7411626346845708 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark14(-92.14092922432945,-0.08032331953448996,-1.372946188840176,0.04662861379883529 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark14(-92.17030767637421,-1.5707963267948948,-1.5707963267948966,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark14(-92.25480138353268,-0.7528950675621366,-37.742755742691955,58.19283610953684 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark14(-9.230414457992795,-1.3556044809777037,-57.11091942017487,1.0000000000000036 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark14(-92.37230139852608,-1.3924806143831003,-92.48460534814188,-2.6469779601696886E-23 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark14(-92.4375850974722,-1.4503924056910225,-100.0,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark14(-92.44287143260881,-0.899835418823587,0.0,0.005022703518940297 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark14(-92.46318017869557,-1.5707963267948963,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark14(-92.55847392453221,-0.4281559224135877,-92.4258508033313,-1.0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark14(-92.69997017780786,-1.5707963267948735,-76.987803974396,1.0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark14(-9.28038037775478,-0.3936821524311314,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark14(-92.86684242010213,-0.08173808311782779,-23.901280444711585,1.0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark14(-9.288706226002176,-1.5707963267948948,-97.88168556608736,-1.0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark14(-9.293884935024607,-0.037550244537726485,-12.114139127675784,-0.06184681311488355 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark14(-93.01677631366637,-0.10557971148588188,-72.53425014890759,0.4749657093744717 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark14(-93.12856407588906,-0.38365835445669916,-11.472063480715187,-0.6360637817899832 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark14(-93.2355653102383,-1.1614169270728338,-13.628241506696082,1.0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark14(-93.23997272567382,-0.10133328621055325,-18.357359260549288,38.22252909062138 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark14(-93.31494281898902,-0.4095370879021555,-28.856327899603855,0.002696611324423337 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark14(-93.60166277268762,-3.552713678800501E-15,-21.527816161943946,81.47809830708636 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark14(-93.63308630237577,-1.5707963267948912,-65.24802155262411,-0.018968126548761177 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark14(-93.67900167222467,-1.4756115018673224,-96.05793951551745,-0.23919673726010693 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark14(-93.6855770159187,-1.4007503569894966,-38.82487722626279,1.0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark14(-93.83141034423579,-1.4691137772179825,-1.5707963267948983,0.022847671438848985 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark14(-93.93417304508957,-0.7467419298788229,-35.09696617064657,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark14(-93.94737960091982,-1.5707963267948963,-49.70113876105899,0.9866083230727368 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark14(-93.98959723032924,-1.5707963267948954,-54.81123305392095,-1.0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark14(-93.99083114487279,-0.7631123681101177,-47.18600068982462,1.0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark14(-94.02849732638352,-0.2866436529133978,0,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark14(-9.406411761095976,-0.4368026205523359,-124.09263271568497,1.0000148326087757 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark14(-94.11864238009446,-0.5276158549785475,-38.86939852360976,0.0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark14(-94.22212593817527,-0.6200290378877663,-84.97185416152159,-0.31578365403107655 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark14(-94.2686180727174,-1.4576071580983978,-12.477254908166941,73.59899662674917 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark14(-94.40183411917668,-0.43730001275699504,-29.486832325994683,2217.987184446902 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark14(-94.45428615127058,-1.5707963267948948,-13.693700535282687,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark14(-94.47930116371121,-0.3588298943340824,-70.82375780472518,1.0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark14(-94.59101300162585,-1.5506054620210576,-136.63723929180503,1.000055136827905 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark14(-94.63235671536006,-1.8166172080317372E-15,-5.742217350948877,-0.5225168826134774 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark14(-94.74071086266112,-1.4737968848345444,-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark14(-94.81531541702984,-1.284109778614512,-21.871478374754602,-67.61449555193137 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark14(-94.82772937647489,-1.1045387908351862,-21.83910408312329,0.362089732269729 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark14(-9.483625490193418,-0.3653674296942021,-7.045955108993411,1.0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark14(-94.84509985988024,-0.30426032606630105,-93.06590923888636,5.040223807979981E-16 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark14(-94.96888680966961,-7.105427357601002E-15,-1.5707963267948966,-35.510095629540174 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark14(-94.97174685782171,-1.1102230246251565E-16,-96.05765769196151,1.0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark14(-95.02533912353948,-1.333132808765553,-65.58339954209873,-10.00386112630881 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark14(-95.2239757235639,-0.5319119908435865,-0.7105405711817099,-1.0000000000000016 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark14(-95.40547536202307,-1.327390412577765,-56.37714816353032,1.0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark14(-95.52787858286136,-0.4517384436703686,-4.781067503304961,-7.8727085492990625 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark14(-95.62781887487604,-0.3198385032961786,-90.19535973585637,1.0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark14(-95.76466500573756,-0.7145211888276526,-74.25497630979513,1.0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark14(-9.5809961713876,-0.2931914702010951,-18.665111347430354,0.3569768217609326 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark14(-95.83110348636085,-1.5707963267948912,-1.5707963267948966,0.9134302584895222 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark14(-96.07697169218076,-0.8226307934135174,-1.5707963267948966,-11.742191087683594 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark14(-96.15460538592704,-1.562926438076715,-53.544148815814765,0.36208952862240484 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark14(-9.619202491775127,-1.5707963267948948,-44.26021494625253,-34.01388126747628 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark14(-96.31286868193204,-1.5625898709827197,-0.15712971998801015,41.797005137033196 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark14(-96.35620800006542,-0.03550148380203266,-55.40341229422159,0.5842714760656816 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark14(-96.43060984852414,-1.3025627284216625,-50.57582194359329,0.8050767961742791 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark14(-9.647757827470912,-5.677177727605607E-17,1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark14(-96.50434786722693,-0.7506228515819656,-100.0,-78.56008013126531 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark14(-9.652716241405777,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark14(-96.59895587995825,-1.1117671358099126,-88.37496278297033,-100.0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark14(-96.71061781722877,-1.5707963267948912,-81.7883700027847,-1.0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark14(-9.672714749718292,-1.550176379921249,-88.19822823009176,0.18694237729433705 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark14(-96.90462816470148,-1.5707963267948912,-98.69889037691726,-0.9999999999999964 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark14(-97.17735205712542,-0.6842823309592614,-5.357078197007894,-1.0299899379421973 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark14(-9.723058583060052,-0.05255044145161872,-99.82000126585552,-0.937249432921218 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark14(-97.56682807537145,-0.2606345889033064,-44.28851758862294,-0.598874001354551 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark14(-97.61056774630299,-0.7458086133812388,-69.45872388426602,-15.098777165655424 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark14(-97.65648636605158,-1.0801967462575406,-12.104131131990734,31.616073044379398 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark14(-97.69577243904426,82.26081093492007,-17.662279596959806,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark14(-97.75467687309828,-1.4143308019754774,0.0,-1.0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark14(-97.7734753969643,-1.5707963267948912,-81.67101402196748,-3.849700789418391 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark14(-9.784162208639595,-1.5114970820166334,-32.65560011579357,38.3799942227944 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark14(-97.86146360711234,-1.5707963267842047,-87.82227201230175,0.8956992698502653 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark14(-97.92602744620982,-0.8552888129301124,-64.84921165200592,-0.415240661280341 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark14(-97.98178585380296,-0.8189778247850527,-1.6800485647246788,96.69145301565878 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark14(-98.00643504281948,-0.3963221143637235,-1.5707963267948963,49.515630873401584 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark14(-98.04806407982814,-0.02389323338935627,-39.97883283115841,-0.03582264170199208 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark14(-98.05075437740518,-1.0797069658891711,-29.861090480370493,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark14(-98.15467006912992,-1.5650579470211274,-47.117425565430786,-0.014910128660437422 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark14(-98.27219881622447,-0.16435769108427375,-48.03232704557915,8.492173684166785 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark14(-98.40301851176497,-1.5707963267948948,-19.547836892717935,1.0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark14(-98.46533814309369,-1.5707963267948934,-20.67979914982646,0.8382787345967486 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark14(-98.51765516835694,-1.5707963267947243,-11.100794087379114,-1.0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark14(-98.63158741937154,-1.0936542099464308,-66.22384088260665,-69.98706551091954 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark14(-98.64319626320056,-0.08284456796643036,0.0,1.7249065493091016 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark14(-98.66065281794786,-1.5707963267948948,-20.970780055562052,-100.0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark14(-98.70464134304906,-1.5707963267948912,0.0,0.9999999999999999 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark14(-98.7443028858097,-1.570031221600012,0.0,0.904093022774351 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark14(-98.80645248728061,-1.5707963267948912,-3.112703416080649,-17.883808594591358 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark14(-98.83970754579843,-1.244547479080211,-118.28221695613244,31.020585965310346 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark14(-98.8558298286221,-1.5322634781405513,-53.1330165702125,91.1640436318193 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark14(-98.8707573079127,-0.03351131142983968,-73.80305144275898,-0.04213670304238871 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark14(-98.90153991615743,-0.9493634713780104,-0.7489071744248137,0.06255538603754217 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark14(-98.91984241387549,-0.017202387100778403,-4.6055341400989125,18.103562656238413 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark14(-9.89901837536548,-0.28363557909111314,-55.83404677333708,17.07167867282439 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark14(-99.06386326422302,-0.2965335749026846,-33.402754177561015,0.052562618751403015 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark14(-99.09928530012931,-3.552713678800501E-15,-70.03774791897273,-33.65901146484549 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark14(-99.12130549589303,-0.01983821724720114,-88.26611632861372,1.0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark14(-99.12132318421095,-1.7763568394002505E-15,-32.759373854699724,-88.56606995328283 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark14(-99.13073138615282,-0.3305600571598374,0.0,8.802494435266617 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark14(-99.23970327333713,-0.010991931696627051,0.0,1.0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark14(-99.34029621395825,-0.4097865487339503,-33.018510472837335,0.0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark14(-9.935459074774812,-0.006170321955398678,-66.02140981209449,-0.03277426533400765 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark14(-9.945456932296384,-0.13708213783884549,-12.616507149362631,-0.9999999999999991 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark14(-99.52111431710236,-0.7478283033265527,-1.5707963267948966,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark14(-99.59873504474874,-0.49259591107816414,-0.9124154185930538,68.81394175421292 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark14(-99.70460668337974,-0.031381095728386266,0.0,-1.0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark14(-99.71004408432287,-0.6152329231132189,-2.585323083650181,1.0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark14(-99.71197218699942,-1.5707963267948528,-26.1912020121072,-0.9999999999999291 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark14(-99.84293115027394,-0.5476553821320564,-97.48202150066558,-0.8833132509737199 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark14(-99.92125213289971,-1.687904306284031E-15,-1.5707963267948966,3.2944368572595385E-83 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark14(-9.99285495921147,-1.0350403611274739,-100.0,-1.0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark14(-99.94089730406324,-0.4975832972071895,-3.152597563364189,0.029423911277633052 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark14(-99.97335222735185,-0.012253205118436776,-30.59546632533291,1.0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark14(-99.9766285691897,-0.1601838670104385,-46.38237130970062,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark14(-99.98184940964448,-1.1338088379687465,0.0,0.9379657680148328 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark14(-99.98391414666968,-1.5707963267948963,-1.9830902704123211E-16,0.02949566784566493 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark14(-99.99092183381003,-1.0177622130245194,-62.79915142588362,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark14(-99.99276251094003,-0.21403047579523693,-1.5707963267948966,1.0335994568138105 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark14(-99.99697244762538,-1.3645582288372047,0.0,0.02664908127115771 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark14(-99.99761635691839,-7.105427357601002E-15,-44.474043890186756,-0.011870123590006023 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark14(-99.99945581167837,-0.3560200751108337,0.0,1.0 ) ;
  }
}
