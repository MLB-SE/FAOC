import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-0.003127359116922395,502.2756479405226 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(0.0037956953021748598,-29.66001254404489 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(0.009053973930538639,-27.338031557984195 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-0.009622126449876632,163.24835625468017 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(0.010794163817896585,-145.52274296509532 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(0.0,-11.496923322752735 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark20(-0.013163631633447852,2.8421709430404007E-14 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark20(-0.01570796326794877,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark20(0.015707963267948963,-100.00000000000001 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark20(0.015707963267948967,-90.63234375160317 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark20(-0.015707963267948967,99.99999999999999 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark20(0.015707963267948967,-99.99999999999999 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark20(-0.01595536183969065,98.44943302303395 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark20(0.017166196661327682,-91.50520396481387 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark20(-0.01748888752448977,89.81682365989852 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark20(0.018346233707570825,-46.25606935447538 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark20(-0.019689511058206932,79.77833081538913 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark20(-0.021387902508626322,73.44321520828663 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark20(-0.022890030783358415,68.62361242299194 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark20(0.023431547713630766,-67.0376684456538 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark20(-0.02399455184284377,65.46470786714784 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark20(0.029098005284900808,-53.982955581150975 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark20(-0.02948009231092119,53.28329064332609 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark20(-0.029691355327119584,52.904163837888454 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark20(0.03147741806466975,49.90232437724281 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark20(0.03791612657595511,82.85637108253741 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark20(0.038751811225013554,-40.53478475300213 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark20(0.05223933874887114,-30.069223011151507 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark20(-0.05414294998781736,87.0360588304308 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark20(0.06129552554976092,-25.626606717315454 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark20(0.07194280541557418,-21.8339598757828 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark20(0.08142607662001433,-19.291072246121075 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark20(-0.09444679143352833,16.63154780541617 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark20(-0.09868713363368453,15.916931305609856 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark20(-0.10039044729934024,-62.58748193884061 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark20(-0.10133303887295853,15.50132458540115 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark20(0.10770259701334367,29.16914485544457 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark20(-0.14969151851870827,4.936453653184973 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark20(0.15541979747255905,-10.106796896786825 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark20(-0.19153021164102885,-16.402595844658983 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark20(0.2069827750470808,-11.001098049987133 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark20(-0.20703684588699606,7.587037560338025 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark20(0.21295752444900984,-7.376101552922613 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark20(0.2365487181681712,-6.640477018683989 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark20(0.24953847232287157,-6.294806216343597 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark20(0.24989553024393288,-6.2872144526973015 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark20(-0.28474558938488054,5.516490457984607 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark20(-0.28533675360738703,0.15938662099836837 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark20(0.28535731155670435,-2.5267860524806722 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark20(-0.2853962999431697,0.014118449653859532 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark20(-0.34378729993778556,4.569093526954477 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark20(0.36604434841252587,8.582546533539896 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark20(0.42452942435409113,-3.7000882310704384 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark20(0.45453105329527954,-3.455861410143195 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark20(-0.49501745565612487,3.173214012651073 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark20(-0.5249929373119357,2.9920332544618127 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark20(0.5403576154483728,-2.906956952002048 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark20(-0.6237525611270064,2.5183004041807155 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark20(-0.6590580358264118,1.9612795877095677 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark20(0.6590580358264118,-2.3446689841258577 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark20(-0.6590580358264118,2.3520098986330913 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark20(-0.6840656561982298,0.12342976417536078 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark20(-0.6866078410084953,25.332953379770174 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark20(-0.6959334047115662,1.1596456493207423 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,0.7566738300493441 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.1850998430770936 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.29704071383369 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.8545165403338615E-12 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.999999999999087 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.999999999999929 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.9999999999999716 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.999999999999993 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.999999999999993 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.9999999999999973 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.9999999999999991 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,2.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-2.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-2.8421709430404007E-14 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,5.9969806898152456E-12 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974484,-0.2665061178807253 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974484,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974484,-1.999999999999886 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974484,1.9999999999999998 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974484,-1.9999999999999998 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974485,-1.1923237576465209 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974485,1.9036549905282536 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974485,-1.9999999999999993 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974485,-2.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974487,1.999999999999999 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974488,-2.0000000000000098 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974488,-3.5202618317689387E-15 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark20(-0.8024113945658976,1.9575947418401967 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark20(-0.818942092358597,1.9180798513737634 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark20(0.8294889278870556,7.65617442133674 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark20(0.8755878119253424,-1.79399062595526 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark20(-0.9268079742136308,68.17253619478691 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark20(-0.9506846683404433,0.478926493731405 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark20(0.9851646779093386,-8.526512829121202E-14 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark20(-100.0,0.01570796326742041 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark20(100.0,-100.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark20(100.0,-5.399130029790431 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark20(1.008197510595025,-56.08887858812703 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark20(-10.122416158538565,0.1551799789885029 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark20(10.657620726257491,-0.147387148327077 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark20(109.17030642674177,-0.014388494254608438 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark20(-10.991845601647896,0.14290560327370347 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark20(110.71080100408405,-0.013918317581217622 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark20(11.173576675490011,-0.14058133509215034 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark20(-1118.7662777258015,2.220446049250313E-16 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark20(-11.744450389548462,4.477997575673783 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark20(11.745302310155466,-40.159884085680254 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark20(11.806151805222116,-0.13304896910609768 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark20(-11.823699511839799,0.04657904982389513 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark20(11.89802631797576,-0.0014466687893473535 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark20(-11.905972450961695,0.1319334756790922 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark20(-11.90731257853276,0.13191862701469895 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark20(-11.939004344971094,0.1315684525616696 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark20(-12.016912947810734,0.28657323193244366 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark20(121.73671523848255,-0.0044314266823774345 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark20(1.2515967285013268E-15,-2336.6187247613248 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark20(1.2634920662350609E-175,-3.674239545257732E-130 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark20(1.2676782433002671,-1.2391127915120586 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark20(129.4643568330262,-0.005003999407988357 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark20(-13.23839551600443,0.11865458505873296 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark20(-1330.0971873149754,1371.6496251873716 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark20(13.303341828973231,-0.11807531874238344 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark20(13.359106988925305,-77.15094011016717 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark20(1.3586470361228997,-82.08647026563631 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark20(-1.3E-322,54.111816586649105 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark20(1.4467345851051192,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark20(-14.468762106362902,-28.483261745144304 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark20(-1.4518189109742536,1.081950589650883 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark20(1461.637573578887,-1210.861833454767 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark20(1.4772765788457177E-126,-3.506894958413445E-192 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark20(-1.479512566786628,1.061698536435232 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark20(-15.529093394878245,0.01642286745614019 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark20(158.65533073595756,-0.007846044558089005 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark20(-1.6010845173199835,0.9810827035066296 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark20(-16.168751915580344,71.28301986435912 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark20(16.367021303775378,-0.027512570919929005 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark20(-16.367021303775378,0.04706401618245425 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark20(1.6808450505891877,-0.9345277402246381 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark20(1.6875087726550504,-0.9308374286691715 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark20(-1.7073675640050967,0.920010640889865 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark20(-17.07420647505147,0.09199820378710477 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark20(17.100061859645322,-26.008627599967937 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark20(172.00222457605977,-0.009132418668807896 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark20(17.280648683602905,-30.046918153165933 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark20(1.7450394827966635,-47.70791677723909 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark20(-17.544410507137755,0.08953257940218823 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark20(17.584910051232868,-33.625520993779176 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark20(-1.7763568394002505E-15,5.551115123125783E-17 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark20(-17.820387611566503,40.886383370313894 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark20(18.440748287655182,69.47205257771958 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark20(18.59330846723624,-3.410605131648481E-13 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark20(-18.770885341852157,93.8918674621222 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark20(-1.8964253622885539,0.8282932500434939 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark20(19.065092737882402,-0.08103040332969846 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark20(190.66593143430958,-0.009900642221748608 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark20(-19.335367437348012,47.63482016329533 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark20(19.473453403371053,-0.08066347012300668 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark20(-19.48804837500958,0.08060305970962185 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark20(-19.78981775804,10.159867679835575 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark20(-19.82206243607135,56.18459730360462 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark20(-1.984611772517004,-1.5829759236011367 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark20(19.934859858163676,-0.07879645695886986 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark20(1.9967644264936426,1.5744646990741424 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark20(20.045321877452622,47.08214321764632 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark20(20.19418504040592,-0.07778458618914003 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark20(20.332916015468456,-1.8538231272693777E-29 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark20(-2.040035599742282,0.045673932226820035 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark20(2.0569482974647855,-5.329070518200751E-15 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark20(21.08170245384646,-30.698094143787625 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark20(21.16018804688653,-0.07423357123832375 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark20(-2.1276331160316317,123.2933349011455 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark20(-21.33209053930214,0.07351419526617464 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark20(2.1675512534567636,-0.7246870514779407 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark20(-21.78044064004019,0.07211958439018973 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark20(-22.0421275475085,0.019225245657565893 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark20(22.07174170425759,-0.07116775594070555 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark20(2.2124192846893678,-0.709990342999312 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark20(-22.17648185695975,0.07083162861118686 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark20(2.220446049250313E-16,-8.758115402030107E-47 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark20(2.220446049250313E-16,-9.128214368331143 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark20(22.21199321180147,-0.07071838676595255 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark20(-22.26486353130028,0.0705504583303036 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark20(22.37576490870528,-74.60392260778879 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark20(22.650206610954964,-0.06935019859974115 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark20(22.702171646877602,-0.0691914567129146 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark20(22.707785892760143,-2.2026824808563106E-13 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark20(-22.708696271333736,0.06917157673986715 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark20(22.729284140264234,-0.0691089220892918 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark20(-22.732113357225458,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark20(23.07116932782422,-0.06808481635564478 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark20(23.13700422239215,-1.2261174181865186 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark20(23.39629219861511,-0.06713868648331706 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark20(2.356194488829848,-0.6666666670527336 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark20(2.3561944901908634,-5.401398350673681E-9 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark20(-2.3561944901923204,1.287218300024529E-4 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark20(-2.3966700518509825,0.6554078337073341 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark20(-24.189492708135447,20.67699817373014 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark20(-24.195982274320542,0.06491971720695489 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark20(2.4327159231292717,-0.021882288509566708 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark20(-24.58701192537991,-52.405882781251755 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark20(2.4811944120341245,-0.6330840415053389 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark20(2.4811944901923444,-0.03849321972741926 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark20(2.4825346177633816,-0.2571866669221379 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark20(-2.4825346177633816,0.6327389417071076 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark20(2.4825346177633816,-0.6327389417071215 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark20(2.4825346177633816,-0.6327389417071221 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark20(2.4825346177633816,-1.1178480128327535E-16 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark20(-2.4825346177633816,2.1316282923295247E-14 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark20(-2.49388040685374E-35,1.8928834978668395E-270 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark20(-2.501851451619684,0.6278535545257782 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark20(2.539614110897332,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark20(2.5568828788989255,-0.6143403515890924 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark20(25.714593471671847,43.514738940298656 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark20(-25.7497561569066,0.061002376768520605 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark20(-25.76528493117884,12.833835147633806 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark20(-2.6061944901923453,6.559197629485425E-13 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark20(2.606194490192349,-4.492445304649095E-11 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark20(-2.6061944901925997,0.602716463478568 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark20(2.606194490323941,-0.6027164636215117 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark20(2.6293509053403303,-0.5974084035738776 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark20(2.696703890754453,-0.5824875071305797 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark20(27.31310214476845,-0.057510725748732526 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark20(27.715311166460793,-0.0566761209123916 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark20(28.124007296266,-0.05585250744133674 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark20(-2.8195008217547013,19.556138461460222 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark20(28.539102430365347,-0.05504014467965135 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark20(-28.86538886352045,18.937459124808598 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark20(28.900240724752948,-86.47460689800334 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark20(28.93339191813455,-0.054290085698883106 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark20(29.572733995032678,-0.0531163715555909 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark20(3.003335410485292,36.190420108872075 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark20(-3.0279406462066225,0.4113652987983869 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark20(3.0494386291646265,-7.602807272633072E-12 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark20(3.1086244689504383E-15,-91.86140332120883 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark20(3.1223232335253743,-84.01531934669934 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark20(-31.593589453384308,0.04971883074927508 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark20(31.82223926535201,-76.73033467332957 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark20(-3.199559161846153,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark20(-32.20711084538617,64.88580153527838 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark20(32.34918805490494,-0.04855751940756129 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark20(-3.257541556359584,0.4822030048176309 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark20(-32.618854378112516,0.048156085084599454 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark20(-3.265423538011987,33.91198973914746 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark20(33.18794116570146,-34.192598565600306 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark20(-33.772121025323464,0.04651162790803361 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark20(34.11481676092862,-70.02521896083486 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark20(34.52681603115374,-82.61885853840809 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark20(34.72296367022925,-44.69511259501059 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark20(35.20811989893636,-31.444284557434884 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark20(35.21824636335742,-79.28576470612983 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark20(-3.5420389097759797,0.44347235216968395 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark20(3.5525333693470884,-57.975500421752415 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark20(-3.552713678800501E-15,100.0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark20(36.4804142238136,-49.90494160575874 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark20(-3.648627372236348,0.43051705930476203 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark20(36.80477942230672,-0.04267913981419902 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark20(-3.6867283887685858,0.42606781979932146 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark20(-36.913713679621985,0.006816926885930287 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark20(37.62601959342419,-0.0417476082713097 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark20(-37.63299593413727,0.04173986917077599 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark20(37.89636774295792,71.63998704150558 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark20(-38.39893952884457,0.04090728405702304 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark20(3.860767166443296,-0.4068611908140478 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark20(3.944304526105059E-31,-0.11976102775052766 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark20(3.9914168351516963,-0.3935435439769591 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark20(40.18030633326986,-0.03909368718511375 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark20(-40.36812424695014,78.44618628911799 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark20(40.36988098726542,-67.40813168120718 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark20(40.60034967610517,-48.554985646961086 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark20(-41.00989640893451,41.18029428172753 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark20(-4.130781766137062,0.3802661132262722 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark20(41.570011607604414,-33.063420668995306 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark20(-4.176551186778589,21.813736472933073 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark20(41.78073334465009,-74.26473267641751 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark20(4.187496432172551,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark20(-42.0944314268072,0.037316012440399504 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark20(-42.69069230893343,43.64752611202033 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark20(42.73602850443911,-0.03675578620113784 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark20(42.86634775009591,-0.03664404385352335 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark20(-43.10402035038241,22.41910339099921 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark20(-43.645875189543325,58.41107383725698 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark20(43.89847221985892,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark20(-44.14004370631219,88.54078032544234 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark20(4.440892098500626E-16,-15.743556462902703 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark20(44.56460317207447,-0.445391989400548 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark20(-45.95505758194538,0.0341811415205804 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark20(-46.38808458070577,0.03386206481671026 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark20(46.46483176802049,-0.03380613395174283 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark20(4.6881863658514344,-0.33505415617359313 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark20(-46.900838175100425,-51.85939610469315 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark20(4.85277505417892,-0.3236903234247836 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark20(49.0810109453397,-99.16756177034097 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark20(-4.930380657631324E-32,17.483169139020973 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark20(-49.5940608737655,0.03167307333015401 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark20(-4.97828248540399,0.3155297698353543 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark20(50.07765545386994,-0.03136720983730612 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark20(50.40835708082551,-0.0311614267506517 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark20(50.622623574333176,-8.389280980976935 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark20(50.80966751733577,-49.06258785127672 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark20(51.05088062083415,-0.030769230769228544 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark20(-5.141681988963924,0.3055024270591602 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark20(-5.164960215498155,0.2220942138216917 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark20(-51.76294778685768,20.679436185411745 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark20(51.87499478122696,-0.023951678684133604 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark20(-5.202689489874226,69.44161397023143 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark20(-52.68734701984559,0.029806326552879625 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark20(-53.590698181449305,78.41149669074366 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark20(53.68059735710179,-51.841789842562406 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark20(-53.7276774823617,0.029236259604010884 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark20(5.477797347667959,-1.2434497875801753E-14 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark20(-5.483181686963434,0.01627299274805377 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark20(55.17802210397943,-75.34537250871686 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark20(55.357761936795384,-0.028375358248556637 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark20(-55.41277972453842,55.6647550423132 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark20(5.551115123125783E-17,-16.272525524948136 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark20(-5.62278564229982,0.01627696631506741 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark20(-56.54432512839287,48.560155373792526 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark20(56.668802339450004,-93.24634764090403 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark20(-56.848011083255834,5.329070518200751E-15 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark20(5.690263281101545,-95.83448502390236 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark20(-57.10734324721179,41.86554858414789 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark20(-57.33415361237381,0.02739721837379472 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark20(57.47883489115827,-0.9874935776734475 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark20(-58.07983574179318,0.027045467789857752 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark20(-58.10883705143299,2.348751759552343 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark20(58.249098004334314,-0.026966878125357585 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark20(-5.8465465080224766,5.826450433232822E-13 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark20(5.865620467216431,-4.263256414560601E-14 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark20(-58.830838955061445,2.776822851556742 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark20(-58.86679600115961,-75.17459970375671 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark20(-59.078389309158716,0.02658834042639313 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark20(-59.911556325154066,90.87374212170437 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark20(602.1003492123186,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark20(-60.770520172263375,63.172508838239615 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark20(-61.422381351947664,0.002795096759481419 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark20(-61.646645807595384,0.02548064547903369 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark20(-62.0464549083984,1.4199967354799484E-6 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark20(62.45190303281146,-0.02515209706210797 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark20(62.736921383397366,-66.52551237012693 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark20(-6.320570662765547,3.552713678800501E-15 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark20(-63.21460269957385,4.528046643709684E-19 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark20(-6.39517062737212,0.245622270041036 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark20(-65.21821733917541,84.58583823847232 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark20(66.15379066543099,-3.300501562015242 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark20(6.672160269992773,-0.23542544891485317 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark20(-67.27026519436465,0.023350529721509083 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark20(-67.55932441203242,0.022422020500904694 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark20(-6.762626923549089E-4,29.083657567780676 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark20(-67.7143846356177,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark20(67.7824690364426,-27.85524357031533 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark20(-6.7885294087695645,0.2313897800554136 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark20(-68.28586664501366,6.536993168992922E-13 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark20(-68.31320846675939,0.022994035297861704 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark20(-68.32964021557797,0.022988505747126447 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark20(-68.85241835424827,21.65597427226244 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark20(-69.646911036699,182.67790291255855 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark20(69.70600806858474,-48.75207703165558 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark20(6.9950753047446455,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark20(7.105427357601002E-15,-0.44444502391363017 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark20(-7.105427357601002E-15,1.4848261265468636 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark20(-71.46848900101034,0.021981591970481995 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark20(-71.59757299673883,0.02190784638306273 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark20(-72.30486677787184,87.15920717289526 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark20(73.58887481940411,-74.43199539299816 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark20(-73.63799026855813,3.1554436208840472E-30 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark20(7.382092090407271,-0.037104756401459285 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark20(74.61282335678129,-0.021052632190095677 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark20(74.61282552239207,-0.021052631650308885 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark20(-74.67050529412985,0.021036369321560944 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark20(74.73916565032863,-0.021016566191375673 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark20(7.506684983059476E-7,-100.0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark20(-75.20909684946744,90.79023573860461 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark20(75.6670193750466,-0.02075932605471324 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark20(7.581518070377541,-0.20718757275436722 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark20(-75.8502072475716,7.105427357601002E-15 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark20(76.0816884571503,-18.00347001679113 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark20(-76.13562803164629,0.020631554075338343 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark20(-76.6534446821827,-8.526047068763035 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark20(-766.5846016511414,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark20(-76.68660516711654,0.02048332069690391 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark20(-76.82269454661301,4.418070052249831 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark20(-77.0301510582585,7.177972513822875 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark20(77.11850068690714,-6.264745602636836 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark20(7.733056613367026,-60.59711996766968 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark20(-77.75441817608584,0.0015741862590554496 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark20(77.80985977851412,-44.917467234451095 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark20(78.70156635627671,-99.69862112693029 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark20(-79.19887437557124,0.019833568837682954 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark20(-79.55565730456102,4.0678571622265736E-13 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark20(7.96666019399845,-0.19717124724087387 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark20(-80.05319258022672,99.50509996465235 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark20(80.60364224154486,-4.666720364908954 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark20(-80.78426825738892,77.84525056089927 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark20(80.90953107034153,-63.426292696931135 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark20(8.121375385081038,-16.40292895467161 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark20(8.125432141786689,-0.19331849671314794 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark20(82.37213694851154,-0.01906951045566241 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark20(-83.02452035902381,55.679834547062285 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark20(83.09188822272762,-64.19062212274254 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark20(-83.13875106612805,92.94443136296272 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark20(-83.30279348096946,13.042545339594213 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark20(-83.76757298328332,0.01875184239978357 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark20(-84.03762568599647,0.018680844301935555 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark20(84.22338104559367,-142.56334729094053 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark20(-84.61681482532315,48.96750625538914 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark20(-85.48205968275083,0.018375742613416027 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark20(856.7423552737046,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark20(86.21222894415664,-0.0182187617071288 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark20(-8.639379794151738,0.18181864446458568 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark20(-8.639379797371511,1.14413254269896E-5 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark20(-86.47541521205571,92.97927839012601 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark20(-86.50285710613765,27.818179768930122 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark20(8.661706722044002,-0.18134951657936274 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark20(86.98856816539704,-55.36430406344959 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark20(-8.700024461566542,0.180550794280417 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark20(87.7922972168569,-58.89778314794625 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark20(88.56815331454992,-99.30080175082306 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark20(88.74896949554434,-0.017699319053769504 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark20(-8.881784197001252E-16,100.0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark20(88.88849540396899,-76.6655740349173 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark20(8.898700835312155,-0.1765197365172233 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark20(89.10471738833715,-0.01762865505704969 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark20(-89.59051092426192,2.156567098485576 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark20(9.062765274305491,-0.17332417636903563 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark20(91.5698191828752,-6.655311923664684 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark20(-9.208164937347323,0.17058733607430468 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark20(-93.31947408053426,0.016832460129804275 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark20(93.43146482893108,-0.01681228405945423 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark20(93.46238144379842,-0.01680672268916517 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark20(93.46239667058256,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark20(93.54308160896494,-0.016792223430923996 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark20(-93.5941400167565,73.07715894354101 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark20(93.78060874798518,-95.54595173834623 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark20(93.81859737272538,65.04180225465376 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark20(-94.09197939953845,41.27466611827805 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark20(94.39017178142853,71.75631056248318 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark20(-95.01094667314942,10.43282895852417 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark20(-95.0835398694243,43.82524177501071 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark20(95.62410511379913,-0.016426781980605654 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark20(96.05156101870793,-1.283240180782741E-11 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark20(-9.609719159145925,-94.86290480409647 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark20(96.5350389423343,-0.016271773896866737 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark20(-96.78842114591201,77.0236695537258 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark20(-9.69085783049357,0.16209053463276746 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark20(-9.823107779312207E-12,30.24337740144357 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark20(-98.80045614681985,69.79584198698163 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark20(-99.53939474273392,0.015780649770422317 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark20(99.93967349763199,-33.61072073045483 ) ;
  }
}
