import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(-0.1477537114722196,-52.337921724771455 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(0.39097073209809396,0.1477284012519616 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(-0.6889179838235527,0.47460798843550894 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999900666241,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999961869187,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999985260045,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999999999988,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999999999998,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999999999999,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark83(1.0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark83(1.0000000000000002,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark83(1.000000069987822,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark83(1.0000401872947693,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark83(10.677554441832143,-37.95152186579755 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark83(11.944211990821714,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark83(3.7309489646545075,13.920046786056819 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark83(-37.50827379178887,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark83(-3.8866964793849754,15.106409522966683 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark83(-4.05671384477234,16.456927218367582 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark83(4.695496012220242,22.04768280077619 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark83(5.520400493515632,30.4757695540362 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark83(-55.28544813753709,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark83(5.673130691320901,32.18441184080757 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark83(6.508178754800974,42.35710029886212 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark83(-6.660984963806589,44.36872068237734 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark83(68.15602791404137,92.70815325213897 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark83(7.572130168643495,57.337155290880965 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark83(7.919328014402312,62.715756199697275 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark83(-7.945572290582366,63.1321190248703 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark83(-7.986377695956958,63.782228702478776 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark83(8.157408049300036,66.54458605364191 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark83(-85.67415956891028,-9.229237659735645 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark83(8.657080198742204,74.94503756745436 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark83(8.73125728407047,76.23485375857635 ) ;
  }
}
