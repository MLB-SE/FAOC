import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.006195004553227412,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.015350642602211865,1318.8011741734447,-1101.2008021746142 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.027895422078551828,-8.023469188441316,22.148396741430517 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.03771340203225372,0.6343014147429876,-8.526512829121202E-14 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.03775593672237204,-100.0,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.037858751300487936,-0.21809268353466607,7.202425598771711 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.039078177675835324,-44.144701536567375,60.54936365855909 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.046876040840185595,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.04851527207355874,7.105427357601002E-15,0.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.04999017888157198,43.113452031176266,-23.465593659039122 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.05727908602166528,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.06137626187504536,48.050318949172784,-91.24907915731637 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.06194938791581402,2.999393627791262E-241,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.3181361982776495,-1327.1132020838365,1072.649280363791 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.4251165711587288,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.5569036038985129,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.6099957606699746,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark58(-0.00717257791245166,64.03316258796255,-0.0493748922431549,0.11465720958079058,-13.027121312261801 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.1102230246251565E-16,-30.25965107066084,100.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.1102230246251565E-16,79.06782847760013,-73.8771888768786 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2436.781342097942,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark58(0.026021329038414365,-87.06928818513235,-0.05690443830603535,-1.6896281737745626,0.5519183331391811 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2637.8218776729805,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2.7755575615628914E-17,54.881384832371815,95.05103504479791 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-34.75315184640331,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-40.26484079883155,-5.551115123125783E-17,-3.541438743221594,3.458776402768364 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-4.440892098500626E-16,86.88085032468226,-18.9819004231595 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark58(0.0,46.001227492166876,-0.5563493367921877,-67.44811910428001,0.022106674802466354 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark58(0,0,47.4288869868864,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-5.551115123125783E-17,-1.0575015017598015,1.0365265319448699E-30 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-64.91158365675213,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-6.938893903907228E-18,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-71.9173474731887,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark58(0,0,80.80638634071585,-28.258892229988675,15.531480681334358 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-86.37254123818813,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-87.6743521173216,-43.40041396010741,65.79100435365802 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.00622216224088612,0.4096073561313224,-1.9804036829262195 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.04563869802655657,-82.00247494537447,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-0.08739014491651187,2.5232925680957394,-2.52329256809574 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-1.1102230246251565E-16,-0.3078178023124569,0.3078178023124569 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-1.1102230246251565E-16,-1.0505017817092455,0.8432742094147514 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-5.551115123125783E-17,1.7763568394002505E-15,-1.1076160993334216 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark58(0,11.578384001107537,-0.04952065661552956,1.4210854715202004E-14,-63.55382131234069 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark58(0,-11.735578915522336,-0.00742080452345828,0.03744905977749439,-34.60967815563371 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark58(0,-13.098835392504427,-52.13012886865496,72.23267988888833,-69.39919558157143 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark58(0,-15.560301157174584,-1.3877787807814457E-17,-67.44801837098106,0.023288991503873646 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark58(0,-33.90054006920052,-0.0393900568233795,-6.502796485894792,6.5027964729254055 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark58(0,35.52128201832659,-0.009632528613379333,0.01611903432107765,-97.1155093159546 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark58(0,-3.9415503053099545,-5.551115123125783E-17,-11.124180814636741,0.05394324260720407 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark58(0,-40.869523054421485,-0.24235873125964938,-1954.4463939965212,8.881784197001252E-16 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark58(0,-41.83072060978271,-0.0011327450814488937,1.0188278223258176,-1.541768189259912 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark58(0,-43.371763827284894,-0.014945721779740554,-3.458749594704684,-18.461602653628972 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark58(0,51.58562777797318,-0.05940582629998428,-33.20266832738124,0.04730934005986187 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark58(0,52.087250078943065,-0.005947687525539924,-16.503329547190788,0.004612683709682486 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark58(0,-56.76003949715964,-0.008434042398098002,5.958798011640654,-5.9587980116406545 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark58(0,59.2595115306377,-0.0601587404750272,-86.81800628648202,0.01387330976113628 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark58(0,60.030815756641964,-0.028722696945543066,0.007556043659999399,-10.94214892752223 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark58(0,60.801758950966736,-0.03478055574750334,-2.3659631318314136,-0.7810464751520303 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark58(0,-61.732033554836256,-0.8770385592184666,2.220446049250313E-16,-2163.4920260522204 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark58(0,-68.3618701292873,-0.050788418419437875,-7.471643224062419,8.881784197001252E-16 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark58(0,-70.60547597764332,-0.03313930618115182,11.845373554970394,-0.13260842467359568 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark58(0,72.11868931862786,-1.1102230246251565E-16,-79.37659777947349,0.0010526352595854275 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark58(0,-73.64791050540606,-0.01621425328050108,0.04514867531519684,-34.79163709297468 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark58(0,73.85725770662057,-2.7755575615628914E-17,0.9109448899047458,-1.7211908150053898 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark58(0,-8.431233050976665,-1.9087312349419555E-15,6.4477209699157406E-15,-33.88180015863774 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark58(0,86.52833951118258,-6.938893903907228E-18,11.678022181620399,-11.678017973859731 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark58(0,88.66973255124068,-1.1102230246251565E-16,-1.1630885732983955,1.0344231303232938 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark58(0.8896751114348689,-14.601541195552782,-0.016537979792764515,-88.56562911261693,2.1316282072803006E-14 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark58(0,-90.33865279914544,62.00979253903955,33.4560359339101,15.017339837957678 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark58(0,90.63358323474766,-1.1102230246251565E-16,4.363218853338236E-13,-39.21496402574838 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark58(0,-92.38216041654191,-2.0425708855109637E-4,12.112710237137803,-13.6835065639327 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark58(0,-97.8909371613524,-0.04459531325643473,13.473017997895555,-13.47301799789555 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark58(100.0,100.0,-0.28146835632248396,4.555341965465948,-5.006932204368522 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark58(100.0,100.0,-1.734723475976807E-18,0.09513737443315598,-6.469623686098111 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-17.091480673630723,-2.7755575615628914E-17,-4.558603220749988,3.71860031672561 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark58(100.0,-23.71079575570908,-1.1633588222712008E-22,0.14507531994094167,-10.686301038015685 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark58(100.0,30.590330588757126,-0.019388372173125414,-4.625545637027222,0.003155830822321126 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-38.443531419549714,-0.02142078671068065,0.02147900730078456,-18.909090446140283 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark58(100.0,3.9730181282767987,-0.04344780338459239,-72.5738678780493,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,40.43177861356233,-0.3223530835408323,0.5701550136071939,-5.211747667196987 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark58(100.0,52.08904556857055,-0.007769260201793554,-4.558890613862769,0.3222780164882222 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-56.767777894549525,-0.027688407434932505,0.009236895719858751,-0.009236895719866745 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark58(100.0,-85.88561600368683,-0.03524016575627783,-88.21949549566123,0.017805546472119085 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark58(100.0,-87.07111364301474,-5.551115123125783E-17,0.20237446312721374,-0.9162882222617124 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark58(100.0,-97.41911018264625,-0.047498718622022304,0.3224210023985805,-4.725690287410408 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark58(13.393082710079993,61.67657707935893,-3.684120307186274E-34,1.1102230246251565E-16,-18.943221042509645 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark58(1.3877787807814457E-17,55.06610250399241,-0.03645956630095501,3.2460922300902293E-4,-18.897176759628998 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark58(16.54212896736447,-100.0,-0.023032353195654845,0.05095582139099908,-29.32063686664341 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark58(1.7652855465252195,21.647968231874806,-0.028277097670648264,5.551115123125783E-17,-22.500596790985306 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark58(18.000822715271987,58.670501037404144,-0.016367590628656527,0.09624880769749655,-16.3201638627509 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark58(1.866369641242223,14.122784592680695,-0.006901625409230256,0.2977219063745594,-4.858486113992352 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark58(2.1873730493053545,57.48987937614003,-0.02754264899929819,0.06042132869368971,-25.997381400832158 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark58(-24.89065671661129,70.71187123631093,-0.028492376780146024,-1.886481314455145,0.8326593615100687 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark58(2.5620136036299144,88.63013141610062,-0.009232079785373937,0.06413901957025822,-22.14331511054366 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark58(2.5737787947340145E-85,60.19083739628542,-0.048870240543660966,0.15034696928642377,-4.727671174048298 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark58(28.083129721296217,74.55867974696562,-19.115574988225916,25.644375926006163,-24.562030666346615 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark58(28.265231098628018,30.153515339894753,-0.014093466277911902,0.31557837121984655,-4.496649888148545 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark58(29.7622626796088,100.0,-0.00589929563635655,-4.3354661920124755,2.220446049250313E-16 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark58(29.913470563814442,35.6142227668186,-0.023575881163893586,-60.2509392726005,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark58(3.0218059056330304,-0.17121499260305484,-0.021471478544899836,-32.8515261703519,0.0478150183540782 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark58(-33.346248142392824,-12.604514167358179,-0.06076448121406333,-28.573731880855952,0.054973439708353555 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark58(35.32837371789321,100.0,-0.03342746987035728,-0.7853529759420042,0.7853529759419802 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark58(3.5408132457308983,59.7335275692921,-0.04583712820696151,-25.78631202889605,8.881784197001252E-16 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark58(-36.355137875814485,23.347644469904147,-0.045339486397201555,0.616036219471269,-0.8333751907707492 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark58(40.029152759385454,-0.05578796237674766,-0.05726232813543786,3.8497006106250736E-11,-19.383943769351657 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark58(40.60993440330707,-49.59320530579244,-0.13822618919047633,2.9055937919749653,-4.387836595502638 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark58(4.421081568409395,99.83552076831849,-0.057275334824285734,-9.16765617403674,-0.29139038256756533 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark58(4.503811509695004,-0.1274468629201948,-0.02894097078055577,-1.4707963966231716,1.067990328505914 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark58(45.60398098044806,44.68033870303853,-0.0172568330399944,1.4210854715202004E-14,-4.172834157599951 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark58(46.02446755138902,-5.450592142430493,-0.015093595568446846,0.028728891282172916,-4.173885486197376 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark58(4.814556919242388E-4,-22.075529012797485,-6.211990693895587E-16,-15.718577000557428,7.550705964829619E-6 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark58(48.8424754296673,-100.0,-0.062139841764557446,0.043339129615381125,-19.739245877359195 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark58(4.943828375892245,-7.105427357601002E-15,-0.004754188831836759,-32.754997022990864,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark58(51.21232614243465,36.661902012003736,-0.0066553092339069345,-25.209689734319028,6.938893903907228E-18 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark58(-53.08079743644051,-57.20267383844892,-0.03792643536008178,0.013200733597147962,-16.93701824242138 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark58(5.351449234194086,45.497062205719345,-0.04194168495738859,-16.66657157515813,0.008518566649485138 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark58(53.9545804218949,35.637346282394695,-0.04851005723477685,-16.86254365907363,0.09315298798052218 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark58(56.878039631196856,100.0,-5.551115123125783E-17,-10.804586634094521,0.11307228698301808 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark58(57.39182876437305,-19.226460656927433,-0.0047731742180814885,0.005298563602982309,-22.09804265593353 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark58(5.80440914759955,73.65544785789868,-1.1102230246251565E-16,-2.0830025031397383,-1.0675273139413932 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark58(60.28039285504888,-81.7458603815217,-0.058627888964294606,0.0265577623305578,-23.496056418624597 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark58(61.21955832572499,93.32009426821212,-0.03651438444442754,0.02046011802308867,-9.793621030530156 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark58(61.725189264120786,30.131299887389346,-0.15336620653876684,0.010196832249138782,-22.661980489352107 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark58(61.95037537151566,-15.259325759884732,-58.094327005053906,-94.97634160784838,77.47987309629417 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark58(62.27591140340684,22.47127528722545,-0.02962536896190954,-4.2778438382576045,0.009152031770185864 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark58(71.55528231571935,-100.0,-5.551115123125783E-17,8.881784197001252E-16,-22.726434463080622 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark58(7.656510661867639E-4,-63.63742075517669,-0.02840941133826408,-0.8924068091397288,0.8924068091397281 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark58(77.78991780110157,32.79746770543784,-2.7755575615628914E-17,0.6812333114605051,-1.9337548968013591 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark58(-86.7982889145032,-99.63782888673121,-0.010378921628493104,0.3369571218549966,-4.661322231139611 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark58(9.160302527805015,-100.0,-0.015434761303870587,-2.162939771462857,0.7262321159005378 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark58(95.48767971042426,-99.47787911160589,-5.472931247145322E-18,-0.9359637756604062,0.00277280463939902 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark58(97.26233547001439,98.31060705298694,-0.002305452872011551,-12.854922245967025,0.12219415230517651 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark58(98.5518903104935,-4.780716865070098,-0.06004939471333966,-3.2446293888446434,5.182437626801537E-12 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark58(99.65305049022928,-0.041284054652123814,-1.1102230246251565E-16,0.09361519727549547,-16.779287685227835 ) ;
  }
}
