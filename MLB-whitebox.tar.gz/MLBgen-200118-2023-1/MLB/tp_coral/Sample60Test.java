import org.junit.Test;

public class Sample60Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.004461858032601242,-1.0105192407736603E-206,2.4074124304840448E-35 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.00674399728800032,-74.87353039409165,100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.007599564501155287,-14.207187245627779,20.775170991574146 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.013656234716788784,16.07807884850045,-35.33217595480786 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.014044360130792636,-55.99635797917311,-99.68302724249736 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.015876420498571835,100.0,-100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.025822259059068542,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.026120909468242387,0.004695735270381807,-3.545581229271517E-15 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.038310838114490056,1237.2421912997138,-1246.6536942020525 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.038508078852575706,-17.08387172789334,7.105427357601002E-15 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.040346569586672265,5.35838522138242,-21.57193345681898 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.04551443391309817,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.04731280757917852,-9.177049814621634,0.1711657186705224 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.048488916580511354,0.5340342746711071,-13.476910428441808 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-0.06507944320910619,-0.0018782926577179948,0.11496364557029981,-13.66341784833497 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.12633346928972689,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-0.2681479844677801,-1.1013853102030362E-32,-10.282534396201498,0.15276353730216205 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.2860251666514504,1410.1153771674374,-1054.336849963928 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-0.4174892083839302,-1.4522542145445504E-11,0.11962455488707321,-10.160695325075618 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.46982641857964524,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-100.0,-0.013108911786039706,-0.48748159055742346,-2.6561017276643097 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-100.0,-0.03160987780838015,-31.55598040115586,0.042302212549773933 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-100.0,-0.03353856946708755,0.34684706750120137,-4.4622307165632344 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-100.0,-0.04802393998054211,0.11888346293909446,-13.212908574169113 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-10.029333079922182,-0.055659403857944545,-7.575419485215633,7.105427357601002E-15 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1064.12125414976,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-1.0776114800878558,-0.06097966421750356,-60.747167150014356,0.025857935447685776 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,56.72487808301835,-37.31044704824165 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-15.82884194565814,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark60(0.016818560499458266,-31.46100758751067,-0.06114251233111542,-16.183613097118293,0.0892309798455343 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-17.30406049675561,-1.879515905675405E-4,0.08110591164054841,-19.367223605296648 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2.220446049250313E-16,-48.83874170216212,100.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-23.133396364481086,-0.01107669525391354,-35.51188510746846,0.04423297501783541 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-23.56812103704671,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-24.889604756879162,-0.01438362880593684,2.7755575615628914E-17,-66.67751933606597 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2638.2298760355384,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark60(0,0,26.387962388949475,-62.096010200019,-2.6551832539048803 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2.9438844150439394,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-3.142857539396884E-5,-0.18589594993526196,-38.22465506085646,2.221380238637537E-16 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-34.11629592833134,-2.7755575615628914E-17,0.019665711294818696,-72.40524961964442 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-3.562791207398448,-5.608558024112129E-4,-0.2388371794930517,-2.9053871638595417 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-3.6009686889727225E-32,-0.03399957906639682,-47.48461266890193,0.020511094128323096 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-3.7389707339745115,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-39.932515258709856,-0.0382328370427612,-97.83802794069558,3.552713678800501E-15 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-40.06991455484028,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-4.0617984411088965,-0.02235726489369999,-69.92409822427716,0.018154325180760586 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-4.3350888399021093E-16,0.0,7.047162046065076E-15 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark60(0.0,43.35581577109801,-0.002037993232054984,0.14107756696787488,-3.4306402658703408 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-4.440892098500626E-16,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark60(0,0,4.876109678001811,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-49.28327871768909,-8.881784197001252E-16,-54.69474892467867,0.028677534899486545 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark60(0,0,49.96614297719708,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-5.2451161218970285E-5,-0.1126816297646553,-2.143251608509175,-1.0150837768011371 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-53.431897624058564,-0.007866174906834,-7.755895962353783,2.220446049250313E-16 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-57.59016687201711,-0.05967530813224782,-76.8681700449585,0.020434938491135313 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-57.89798381859332,-0.05492438834508912,-35.6624854710852,2.0498085927572355E-5 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-63.458974928502556,-1.1102230246251565E-16,0.0015668138753893613,-6.58528736532147 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark60(0.0,66.5199986522346,-0.05932306769740642,0.38325074537933285,-4.098612581275368 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark60(0.0,72.30699325897666,-0.058808830439558146,-4.071200215523537,0.3355334534569662 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-7.912420458115946,-0.010227155671902927,-6.803959373184503,0.23086503617080023 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-82.68504290927544,-0.018602845027569093,3.5078052803091454E-5,-70.51984046487114 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-85.6595715941459,-0.05131292015483882,-2.00344129662793,-1.138375816631549 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-88.03676947649339,-2.31796060992004E-18,-44.97758074487735,0.02558969353316797 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark60(0,0,92.76070460662234,58.96505228682588,-23.34627868546167 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-98.95312388596632,-0.06151386325714125,-83.0737441620229,0.00554983468352538 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-99.82264932949226,-0.006657267014913386,0.3346581926208613,-4.014149069990208 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-0.011823545304758112,0.507401905106081,-0.8047434980146759 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-0.014547838644019526,-2.055614410508295,0.48481808371339596 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-0.024881294459382745,-6.681118392461875,5.181118392461875 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-0.0576984178448147,-1.4979695440610694,-0.07282678273382723 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark60(0,100.00627473151755,-1.695827983033594E-13,-0.20214380342198623,-62.55891294157898 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-1.3877787807814457E-17,-6.370081848089683,0.05681360244736108 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-5.551115123125783E-17,-0.15112201694253002,0.15112201694237576 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark60(0,101.51275213724811,-0.05310639271826259,3.469446951953614E-18,-69.38883980221675 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark60(0,-11.101736846097463,-5.551115123125783E-17,0.010297331676979878,-51.57702744490017 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark60(0,12.28292330241083,-5.006661477751316E-10,2.1865759955491583E-14,-68.71531608036247 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark60(0,12.376070136324188,-1.1102230246251565E-16,26.061604080758087,-0.06027243457184728 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark60(0,14.130667250509259,-0.005335959925274025,-3.8732918309015645,0.405545565728584 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark60(0,158.20495019120534,-0.9403043101877407,-14.046514399040872,12.646188558863173 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark60(0,18.726280342023802,-0.01748993774997773,3.2992376834674054E-13,-54.69025962034253 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark60(0,-199.26787300740037,-0.023238247403389343,-1972.181223734384,5.551115123125783E-17 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark60(0,-2.3131554976930886,-1.1102230246251565E-16,-31.987942645219302,0.003749557304982518 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark60(0,-26.27253957435894,-1.1102230246251565E-16,1.3877787807814457E-17,-1656.9440675847657 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark60(0,-27.269645437173324,-5.551115123125783E-17,0.04728789422757712,-31.296386993214792 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark60(0,-27.99887596514916,-0.007471813325101356,-5.160865407521758,3.590069080726861 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark60(0,-31.29035474831859,-0.036123856061737014,-0.8333822137435193,0.8333822137435194 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark60(0,33.95926039970806,-0.03182913357825479,0.01597622823458111,-0.015976228234581114 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark60(0,-34.3479749429251,-0.03559981906385763,0.3408969423305381,-4.607799172757142 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark60(0,35.74636132314642,-1.1102230246251565E-16,8.881784197001252E-16,-6.900380473019698 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark60(0,-39.49290055972526,-1.7763568394002505E-15,-0.08034921164079734,19.549617161362626 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark60(0,-52.25167948428516,-0.004397407111177826,0.08621317559784936,-13.009807407414115 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark60(0,-56.417232690968234,-0.018770387740619274,0.9866653255132408,-1.5895896470282957 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark60(0,5.9067767560199655,0.44037874853887615,-34.2769334190492,-7.055534943352072 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark60(0,65.6739602313395,-0.024378327607225858,-15.932197095131281,-15.48372944076665 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark60(0,6.9874693881584236,-0.049482863765315896,-62.21872100431736,0.02524636156834248 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark60(0,-69.93246262276864,-0.014359483111585636,0.16758932048233355,-9.372890362429033 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark60(0,-74.20238599240798,-0.005352280656120589,0.22616360734989627,-6.945398268098543 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark60(0,-81.76524948268808,-0.010004426079432319,0.11783825375313534,-3.191590906742927 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark60(0,82.23440023418155,-74.74402248331309,-87.32965484052411,86.12963873881202 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark60(0,-84.79049857272925,-7.105427357601002E-15,-3.0857752989255576,1.5857756360363306 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark60(0,91.09389173864488,-9.307340188065459E-16,10.392501601230316,-10.392501601230316 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark60(0,94.88809573622562,-0.002009508926034371,-6.5043454497773885,5.00401756966899 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark60(0,-95.76903533170443,-0.013477660865783891,1.7763568394002505E-15,-2.5883480033356414 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark60(0,98.64235614230036,-0.05668563571808725,-3.970219002038675,0.39564475561380164 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,100.0,-0.05202832027540222,0.004117743243730727,-70.24186934458119 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,100.0,-1.7763568394002505E-15,0.09797499272099941,-12.749239880660086 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,16.53236806050261,-0.03434675992158742,-4.352941424958475,0.3561409858710599 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,22.78796138169351,-0.05358283197677846,0.05879006952438451,-13.779336309538536 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark60(100.0,-27.355952905983475,-0.04583534572625139,0.34299974736424915,-4.41495427031656 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,-77.26861074208506,-4.440892098500626E-16,0.0012419067936493735,-26.455271953993375 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark60(-1.1102230246251565E-16,-34.26638361039638,-0.001267690767369441,0.006275824397514453,-63.17613188990776 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark60(13.488982390612886,82.23155037194485,-0.0229727091369996,0.018270980511110774,-13.877144256474107 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark60(-15.90908736674602,91.17306987011504,-1.143794985148685E-22,0.3252942539180303,-4.226010082986744 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark60(20.78829219216358,98.59971728159562,-16.9685449538556,89.79828034762994,84.44211516312043 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark60(2.12844491694225E-18,-92.27750212320456,-2.7755575615628914E-17,-19.33725689523851,0.06728199595257285 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark60(-2.1382117680737565E-50,57.396043348313086,-2.6648451606535125E-22,0.21571562068999506,-7.28179221222133 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark60(-22.3576863382727,-3.838272804480986,-0.03834566742695289,-53.42280330736376,3.552713678800501E-15 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark60(-25.13293275414741,81.66830827533822,-0.0501829112310494,0.19917164085124028,-7.886646512934346 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark60(-2.5849394142282115E-26,-24.74257964769182,-0.06061157512942095,0.19704881036502386,-7.971610302468042 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark60(-36.271625486708174,-65.23338119758719,-0.05866917524120648,-16.267637733545335,0.08071975153097144 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark60(-36.34216420477251,-1.0081376847743022,-0.031166998141837376,0.05873363032609727,-25.41366790470296 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark60(4.239532109737369,79.90189363990456,-0.00508205459728422,0.03838452117641744,-10.071876206362571 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark60(-4.46573638251273E-20,-4.373918220464794,-0.04341822870133434,0.05940683703482432,-26.441339165626587 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark60(51.61459482115313,-71.71866550535569,-99.98620431757821,17.275333522802597,10.145953676205949 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark60(-51.90667207474304,57.27614492218723,-0.17923167160135695,3.890632037875217E-14,-20.111605073380318 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark60(57.987709918047614,29.041160286171248,67.6959354713687,-11.608144774156642,-37.750492270790104 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark60(-6.4615818717523785,-81.8110272751735,-0.03972946894845031,0.0435298368914096,-36.08550913511191 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark60(-66.19466235122195,-23.984886566486153,-0.05672803995442661,0.012701107249967147,-7.168523271020825 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark60(6.938893903907228E-18,-93.46489831516594,-0.027294442596401347,7.378481023168071E-6,-3.6103629972139513 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark60(-77.88905717298675,76.3438144765228,87.6534938430157,-58.224447631990685,95.1466805546423 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark60(-78.33719487563219,-60.22433209566125,-0.04938117119571056,-69.30187387895211,0.022665631932720552 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark60(-81.2611542286714,100.0,-0.04482484114724558,0.3250465244672128,-4.462824854803781 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark60(-87.22824468232206,90.21863451129767,-2.7755575615628914E-17,-4.358891750528049,0.2723082618814703 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark60(-91.71262848934099,-0.022225444016826728,-0.004651191534250826,-0.40124468408522646,-2.8716777471885524 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark60(-92.11006683405138,100.0,-0.012638532202803343,-2.5256024072638823,-0.741332599213715 ) ;
  }
}
