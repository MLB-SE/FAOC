import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(0.0023157416229113714,0.04318271045898423 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(0.019579521665022526,0.005107377073414909 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(-0.057774503191333065,-0.0017308673286004356 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(-0.20784188090759415,-4.8113498377233554E-4 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(0.3321080479977517,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(-1.000000000000001E-6,-100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark82(-1.0154028560320545E-6,-98.4830793078281 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark82(1.082051276617662,9.241706207545519E-5 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark82(-1.0E-6,-100.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark82(11.09460009255831,9.013393828144819E-6 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark82(-1.1408917450533664,-8.765073499179573E-5 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark82(-1.3329359500993254E-7,-750.223573746576 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark82(1.3344327981310035E-7,749.382015621046 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark82(1.3405163976823977E-7,745.9999999877909 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark82(1.3751246397584305E-7,726.8897011965804 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark82(1.412224902554526E-7,709.1827603916581 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark82(146.73137501238284,6.815175009922982E-7 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark82(-148.1239633971023,-6.751102097633736E-7 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark82(-15.194090866050331,-6.581505962444112E-6 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark82(1.5271488019508189E-6,65.48150374885368 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark82(1.7113328638629355E-5,5.843398564454216 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark82(-17.48457640263706,67.12313428653701 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark82(18.001737181334185,5.5550194402176345E-6 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark82(-1.83528353708261,-5.4487493610366755E-5 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark82(-19.037400949111174,-5.252817875050788E-6 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark82(19.353394305336963,5.16705225095393E-6 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark82(-1.968358300130646E-6,-50.80375863772908 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark82(2.05481414461417E-6,48.66620188599923 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark82(-2.0627800148636616E-5,-4.847826684350025 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark82(20.75954276954745,4.8170617778100495E-6 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark82(-2.1155092042320223,-4.726994323633882E-5 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark82(-2.1175823681357508E-22,100.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark82(2.135217688431908,4.6833632252943465E-5 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark82(22.120501382756537,4.520693191789604E-6 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark82(2.3358375340620796E-6,42.8111966443563 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark82(2.7731083797277734E-5,3.606061730480434 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark82(-2.7755575615628914E-17,8.881784197001252E-16 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark82(-30.61855882271354,0.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark82(-3.171490006480881,-3.1530920733047196E-5 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark82(-36.045404652995416,-2.774278745451395E-6 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark82(-3.795527273665698,-2.634680053383481E-5 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark82(3.944304526105059E-31,-6.158405799864186 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark82(4.0363136545396656E-7,247.75081561743704 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark82(-4.321534241569225E-6,-23.13992989877849 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark82(-4.765847952077538E-7,-209.82624919120173 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark82(49.951778285056754,0.0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark82(50.973460680438876,64.61118153976071 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark82(51.55955848029606,1.9395045831593904E-6 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark82(5.176794314115976E-7,193.16973773128134 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark82(-5.280784487749168,0.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark82(5.42593374579658E-7,184.300075682769 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark82(56.397497296464586,1.7731283264987852E-6 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark82(56.67770348847441,1.7643622420293603E-6 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark82(-5.869090783810748,-1.7038414242260348E-5 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark82(58.77466776260468,1.7014132754900047E-6 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark82(-61.90812519178924,-1.6152968562721526E-6 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark82(-61.98906097755937,-1.613187849969222E-6 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark82(6.489567797451912E-5,1.540934668087825 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark82(68.1627252447243,0.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark82(68.77726981125365,1.453968735229405E-6 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark82(709.0989129584347,1.4102404921517577E-7 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark82(710.0034703093544,1.4084506435275988E-7 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark82(-7.105427357601002E-15,5.364822044384709E-7 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark82(-711.8424418811012,-1.4048052506075134E-7 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark82(745.9999855979403,1.3404825995586003E-7 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark82(7.535722034534473,1.3270128534694234E-5 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark82(774.8595051477513,1.2905565374600254E-7 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark82(77.49685682679966,1.2903749144754784E-6 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark82(7.938935290629949E-7,125.96147510088217 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark82(-8.0032990126617,-1.2494847446475887E-5 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark82(-8.04372734108938E-6,-12.432047452575237 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark82(8.167013203134204,1.2244378393024225E-5 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark82(9.860761315262648E-32,-1.3239529741910614 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark82(-9.860761315262648E-32,18.841773188232786 ) ;
  }
}
