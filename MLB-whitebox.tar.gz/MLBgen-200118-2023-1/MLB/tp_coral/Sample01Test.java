import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(0.0011263824696605973,-0.09945158584761202 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(-0.0012816619012534258,-1.5707963267948966 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(-0.0018494416962198112,-42.26630403040601 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark01(-0.011985458563877976,-0.1561199384425243 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark01(0.01583549096678801,0.17733203612841897 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark01(0.01985810926847275,-0.19961796741836324 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark01(0.02306864999179936,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark01(0.034217974794086836,-2466.596525458748 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark01(0.040866106332819285,14.42930003440933 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark01(0.04091165758378856,-1.5707963267948966 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark01(0.052727390867607984,-95.58093373186564 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark01(-0.05974434362332737,-18.013451782610687 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark01(-0.06002836847511084,-50.341622714687986 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark01(-0.06605419743630636,-1.173812502685595 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark01(0.06667654858992123,92.32923824900308 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark01(-0.07512505561395244,-9.42477796076938 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark01(-0.07699240629156456,-172.05225861969126 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark01(0.0824317475534726,53.0589653162921 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark01(0.09635861991968409,88.40684588343264 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark01(0.09833689601791439,0.025449097535202032 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark01(-0.09865266344415592,77.94997493667931 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark01(0.10143103321847775,-4.889003787624304 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark01(-0.10385472352652125,1.5707963267948966 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark01(0.10906023601580905,26.992013344006068 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark01(-0.1241730832686299,1.5707963267948961 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark01(-0.125167979049571,1.377530185780682 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark01(-0.13250751389426552,45.53159253810141 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark01(-0.13438259480986336,5.554198311073147 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark01(-0.13809056263529423,2457.7965631404822 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark01(-0.14820260755212367,4.930380657631324E-32 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark01(-0.1513352406834401,5.650048202423733 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark01(0.153967560221614,-82.82638731810208 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark01(0.15689072188408204,-80.52888136769249 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark01(0.17167848451343995,-59.190047110931495 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark01(0.17946677247419585,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark01(0.18711854061971112,13.186210503363606 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark01(-0.19462169838823837,-63.399738731659646 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark01(-0.19972679257811077,28.437279682155218 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark01(0.20501036990422672,30.23817767384692 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark01(-0.20924847268716174,73.44475200933591 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark01(-0.2092801726191138,0.5707297021116188 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark01(-0.20968298253183915,-44.116711671999134 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark01(-0.23040088592303806,44.17846192978876 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark01(0.23941494504545469,-55.84560527724496 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark01(-0.26305848802617804,0.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark01(0.2655972595356589,-43.24088313113104 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark01(0.26631884338455336,2.437760641956757 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark01(0.29225174787405317,1.9008369955019447E-14 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark01(-0.3080508204001595,-37.389416723328225 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark01(-0.324767562076245,-14.15689847820898 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark01(0.32812279797406996,0.0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark01(0.3365369278271656,0.83688421816016 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark01(0.43039875581849046,-16.00012956045714 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark01(-0.43770464698893763,-88.402499796774 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark01(-0.44360421171995923,-1.0933197880577556 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark01(0.44898574335712915,90.5712380523693 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark01(0.4594629747216885,-11.966832180004758 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark01(0.4598389271690283,1.5707963267948966 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark01(0.4809044975633414,64.39818941167091 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark01(0.5080410744286095,92.25142365279345 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark01(-0.5085721641104949,-98.64175426789814 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark01(0.5151998850065778,185.4100814110816 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark01(0.5348929474466072,11.50795206536182 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark01(-0.5411279056452654,-10.824550957573804 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark01(-0.5514457118476492,1.5707963267948966 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark01(-0.5634894216793143,1.5707963267948968 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark01(0.5912443224391339,5.030172501714341E-6 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark01(-0.5957697344995889,0.0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark01(-0.6088977094930856,-39.009352382435104 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark01(-0.6096369051508805,1.5707963267948974 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark01(0.6530090735298246,100.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark01(-0.6575627035920796,0.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark01(0.6707818690498448,5.927219400265272 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark01(0.6715615322625725,45.118211285218166 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark01(-0.6763457695193367,0.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark01(0.7070278883206481,-101.74373849550645 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark01(0.7145312136612333,-44.62081683682559 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark01(0.7181554004269871,0.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark01(-0.7510557634948185,60.32562303149055 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark01(0.7539584252301381,-25.89686262214086 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark01(0.7712530736615975,95.59084867560557 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark01(-0.7804832028599407,-51.08579299738003 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark01(0.7829082462623393,0.04072276199004194 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark01(0.8049411181596509,1.5707963267948966 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark01(0.8071941291707416,44.559573163207325 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark01(0.8212400169669021,4.983714567177312 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark01(0.8234951047646801,0.4600276548223122 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark01(-0.8389226693223579,-1.5707963267948966 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark01(-0.8457703217776356,-57.458866254915655 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark01(0.8487988083936138,56.04510483732082 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark01(0.8533630195719865,-100.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark01(0.8709340964489185,-58.25743458571946 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark01(0.8839047999113985,0.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark01(-0.8891776039999684,32.58028509994827 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark01(-0.8931281882954725,-14.963004305529033 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark01(0.8939419538851149,135.34081040580992 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark01(0.8954793477975329,-27.691311494739224 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark01(0.9111272087667288,4.407832243181097 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark01(-0.9116062563769844,10.741527437627013 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark01(0.9484985648372799,-10.57059568183063 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark01(0.9488049439270956,2535.1005964704736 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark01(0.9500627105474306,86.58576289761108 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark01(0.9603226668768201,97.40533770760308 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark01(0.9699190306452898,31.8276331542002 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark01(-0.9701891521864056,-1.5707963267948966 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark01(-0.9792527359719029,-3.5516634497966493 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark01(0.9896836488098485,78.10833694205564 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark01(-0.9918212960295538,-6.475742138740064 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark01(0.9969831609811592,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,0.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark01(-100.00000000000001,-112.04280303406053 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,0.290680061984535 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,0.33713308940972603 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-100.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,100.0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,10.99557429110188 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963267948943 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-1.5707963267948963 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963267948966 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963267948972 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963267948974 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963267948983 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963267949054 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,19.353588266530103 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-21.18005343428468 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-2616.3962333647105 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-2633.147581132606 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,42.70159085441156 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-98.47033905444374 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-99.81069130706231 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark01(-1.0014968692338029,0.4836423841974791 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark01(-100.54712923925433,108.3928061367228 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark01(1.005889228814354,-3.4616958361188015 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark01(-100.75405973351296,-45.15725530255549 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark01(-10.081431541708781,24.19673519524485 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark01(-10.099086761127523,96.13091209661972 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark01(-101.22209249812755,16.97895679953163 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark01(-1.012865722787085,67.44795946246131 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark01(-10.16199017502943,0.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark01(101.74752618725364,-4.774517359359846 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark01(101.9021888522899,15.652748142826354 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark01(-10.266393214205847,-17.535862472066796 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark01(103.02427380888719,1.5707963267949054 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark01(10.334687319358096,37.20225152582793 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark01(1.0357652125774024,-93.3855085296685 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark01(-1.0362819577689915,-1.5707963267948966 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark01(1.0391005349881623E-9,1.5707963267948966 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark01(10.406442496981164,-9.565974440878094 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark01(10.421027170527928,51.04602210633661 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark01(-104.9790700063443,2609.595156994846 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark01(-10.50998842874361,-36.24417280733308 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark01(-105.24075905357557,-1.5707963267948983 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark01(1.0532699505003695,-57.98813254435326 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark01(-10.573417804697636,-0.5393448527538426 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark01(-1.0587911840678754E-22,-73.82742727320125 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark01(-10.63582930385469,62.51583204105552 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark01(-10.678064871251593,136.21630315060838 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark01(-106.8367913449076,-37.69911220591247 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark01(-10.709641937043017,-74.82610716297116 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark01(107.5048855293156,8.535768470705023 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark01(107.52232456587986,11.352666994499518 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark01(-1.0782738620541565,0.0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark01(-1.0811689220276588,44.100279544015535 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark01(108.38493671791372,-70.68589574489388 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark01(-1.0842021724855044E-19,-12.564788579924251 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark01(-1.0842021724855044E-19,1.5707963267948977 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark01(-1.0842021724855044E-19,42.411500823461104 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark01(-10.843295399313746,-43.89876523524323 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark01(-10.86176955914434,-14.429865142586777 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark01(108.72904504836117,92.73563671801607 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark01(1.0878431968650055,-1.570796326794897 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark01(-10.933243335600281,46.623989693462406 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark01(1.0947074254387914,0.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark01(-10.983771654755927,0.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark01(-10.993071898104338,-1.5707963267948977 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark01(-10.994014031159965,-1.5707963267948966 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark01(-1.1025011305310102,-88.79000468232827 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark01(110.302232202882,-45.455515784851286 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark01(-110.33408218242545,-13.505349263151814 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark01(1.1095931713829064,-1.5707963267948966 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark01(-1.1102230246251565E-16,-81.61706775423718 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark01(-111.06221187004306,-88.39832576166714 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark01(-111.52653898157898,-51.836282305808645 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark01(-111.52915215908546,10.995574242895827 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark01(-111.52953895088493,-86.39379797199243 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark01(-111.57308318128634,5.852208938477642 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark01(-111.62022510631303,-14.52338795761355 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark01(-111.81336992227492,8.701496017815316 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark01(-111.81537410024413,-23.879801603157674 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark01(-111.87253452862782,4.837397949407594 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark01(-112.93044105964634,-33.195366203079345 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark01(11.30850991608392,-24.737944971970308 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark01(-113.10514827213949,-113.09733552922997 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark01(-113.10514885388454,-76.96902764261154 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark01(-113.10769464193416,69.11504158726233 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark01(-113.17263209826804,32.67942806145574 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark01(-11.414898332592003,1.5707963267948968 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark01(-114.35563788449716,-37.6071290331607 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark01(-1.1457028381174066,73.84199828442195 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark01(-11.466694244810725,-52.15445997700547 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark01(114.68340456414555,-43.848994068935895 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark01(-1.1496815336672626,9.837500564274777 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark01(116.10370058182185,-19.37483481633284 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark01(-116.66512459593962,157.40144586232253 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark01(-1.1688602683132672,0.0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark01(-1.1720569735207431,1.5707963267948966 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark01(1.1766518745348764,1.5707963267948966 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark01(-117.87598811818805,1.5707963267948961 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark01(-117.92772623441724,12.896595468237678 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark01(-118.22676589762827,-88.09367620350623 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark01(1.1877668646748751,-1.5707963267948968 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark01(-118.82479605970178,-12.454874917430246 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark01(-118.96389099081703,-124.7203620576144 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark01(-119.31967587887067,-0.3505255931526162 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark01(-119.38114953699557,-6.224346324550486 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark01(119.81524194763296,2.6765557488812237 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark01(120.10065982042305,17.549689123545846 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark01(1.2011458681182603,19.05061241657618 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark01(1.201857747870875,0.0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark01(-12.080034271265667,-1.5707963267948968 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark01(12.262100665391046,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark01(123.20730096197545,2528.86732578859 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark01(-1.232595164407831E-32,73.82742735936013 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark01(1.2410830533779724,-66.24093721064553 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark01(-1.2423123670946916,89.9058489929543 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark01(-12.445966127586331,89.1093890795031 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark01(-12.456280854090835,-27.48234904487478 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark01(-12.538287017173388,0.23754115113579316 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark01(-12.54310649397948,95.90035688545541 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark01(-125.6637078616282,-18.79035703481613 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark01(12.597620614723079,-87.96459531571723 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark01(-12.605330950944104,-33.40477224713128 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark01(-1.2665448765632625,1.5707963267948968 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark01(-1.2683071899728032E-15,0.0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark01(-126.84881426069605,-21.16667967172387 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark01(12.691370614359537,-131.67741260752615 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark01(12.734533273827367,-1.5707963267948983 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark01(128.03155158438423,8.10135349401948E-13 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark01(12.824871861461355,73.36540833857146 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark01(12.8553271910625,-0.4348254285236541 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark01(12.87288313820956,-0.024300011676388004 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark01(-128.80491748200973,-67.54424205159128 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark01(12.892297421507948,10.635101510200997 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark01(12.905486077205609,68.1228266723063 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark01(-12.911960705722052,1.5707963267948968 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark01(-12.92870174688376,-90.63993573344446 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark01(-12.935153373692325,0.325558343337093 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark01(-1.2959731884327805,-42.819379501297476 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark01(12.9644276202426,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark01(1.297330371365291,-0.9937391188666034 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark01(-12.974622342754305,-2516.5999207760115 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark01(12.997458353929368,-2.434954182809193 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark01(-130.37389547736748,7.853982682734825 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark01(13.055039627738028,80.66986065425012 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark01(-13.059486824553417,-44.60512090190083 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark01(13.09012472825098,92.86284368113921 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark01(1.31283704475503,-107.21502232693351 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark01(-1.3131563027977187,1.5707963267948968 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark01(13.237801628854205,-11.38309376356372 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark01(-13.242070131423972,-2517.1740506406063 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark01(1.3243635309240476,0.0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark01(-1.3280469828048997,-136.57189452105305 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark01(132.99833278742096,-33.81671878979115 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark01(13.310297401353587,7.419994090596816 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark01(13.349620107511925,5.879450417534308 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark01(133.51704202187585,-4.712388866655119 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark01(-133.81724811723902,-53.49633990943552 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark01(-1.3395527566581544,98.29179928041367 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark01(-134.56864266049627,-76.43974062501991 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark01(1.3460470727999168,-3.148262382934547 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark01(13.479222786949393,0.0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark01(-135.05735065673244,-0.007110995267321503 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark01(-13.516868746717819,47.02770981486768 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark01(-1.3549946194824,-0.07282058396180119 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark01(1.357732928156679,41.995175530044776 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark01(136.06403590900686,-20.274708253569344 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark01(1.361303544855228,-1.5489318392471236 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark01(-1.3641811298333688,-61.98304559490695 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark01(1.36489555277884,-57.36443904037047 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark01(-13.673657133091382,-0.0441442145053923 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark01(-13.740167014964655,1.5707963267948983 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark01(13.754698848805285,0.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark01(-13.794826620079522,2513.2579024957954 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark01(13.804617432834647,1.5707963267948966 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark01(13.811287914046247,149.17311729992656 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark01(1.3813666334639323,1.5707963267948968 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark01(-13.816935352342355,-56.22579473030603 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark01(-1.385472035594518E-14,111.52472761266843 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark01(1.3875630506423497,1.5707963267948972 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark01(1.3876041396879173,-45.53807109833171 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark01(1.3877787807814457E-17,0.0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark01(-1.3877787807814457E-17,62.83067427768665 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark01(-13.904309896004364,72.25359567477548 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark01(1.390674523777406,0.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark01(1.3941941410943968,-0.5856254043853188 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark01(-1.3954664517851179,91.67315501018602 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark01(-139.8646856941559,-2531.5578964803503 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark01(1.4004061021857122,-1.5707963267948966 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark01(-14.112306268199077,-85.93478012185416 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark01(141.14488463862583,-86.39486057629168 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark01(14.115748267353084,-88.25214660587311 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark01(14.134537100515164,1.5707963267948966 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark01(14.136176765257687,-1.5707963267948983 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark01(14.13649658266876,4.712385699305033 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark01(-141.37140210125492,10.99557399740814 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark01(14.137166941154069,-136.26913856672277 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark01(14.137166941154069,1.5707963267948966 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark01(14.137166941154069,-36.12831200988121 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark01(-14.150398159607704,-1.5707963267948966 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark01(-14.15394368166924,-44.35885080417199 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark01(-1.4154136395558568,87.9159567612528 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark01(14.170135070157881,20.438357701873187 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark01(-14.171829439507073,-2550.6984758261756 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark01(-14.223964719425638,-76.82160904040339 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark01(-142.54827261926783,-95.74180745747937 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark01(-14.294120165930266,-15.79431033688039 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark01(-142.9424657619466,-80.11060688349575 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark01(-1.430149578294225E-6,-62.82983186169365 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark01(-144.5408191968536,5.383559507133763E-26 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark01(-14.463408274486817,-1.570796326794897 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark01(-1.4481172460442755,-36.12831551628262 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark01(14.4888685391456,-13.574523899939322 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark01(-1.452420385344429,67.17543845753266 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark01(-14.534754790433269,0.24891305492177737 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark01(14.565546394495442,-1.5707963267948966 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark01(145.67656108891794,-121.96305903263905 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark01(-145.99200823179365,-0.5408418675821213 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark01(146.08405858342067,-89.53545217439226 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark01(146.0851065423836,1.5707963267948966 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark01(-146.24937919111005,-0.40796435296667866 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark01(146.31357068674663,-17.28078092070988 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark01(146.50559967528636,0.23770278097754272 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark01(-1.4670433001752075,50.302917767774 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark01(-1.4686542450465803,23.098234195833708 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark01(1.468830830603337,40.511377509292146 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark01(1.4719773874175963,50.19402558614147 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark01(147.64846324008545,-0.08475279228627686 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark01(-147.77006498765584,-135.5072597183084 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark01(-1.480744935219406,31.519904983619078 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark01(-14.84697305281621,136.30032760148745 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark01(14.981598980118946,-88.49196436412493 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark01(14.990638237474709,1.2210827433312947 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark01(15.042702524502515,-17.671515256144986 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark01(-150.80376358330608,76.96914208396291 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark01(-1.5101229637489166,-1.5707963267948983 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark01(1.5124073966663718,0.0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark01(-15.128123635481092,18.376324782541005 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark01(-15.161179562951121,0.08021023100528818 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark01(-1.521907694918843,-1.570796326794897 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark01(15.275419335608266,-1.5707963267948966 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark01(15.311752546199557,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark01(-1.531364757955539E-6,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark01(-15.355954327635814,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark01(-15.368249879403123,-0.1648688852083834 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark01(15.377249696146889,32.45967044592736 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark01(15.398752662143906,15.81555081619788 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark01(-154.02456000459014,-70.074230800674 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark01(154.44702988085498,1.5707963267948963 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark01(-155.1339789913652,88.44680800144752 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark01(-155.5114661933303,1.5707963267949054 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark01(15.554397497922917,88.53249892773513 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark01(-1.5565792532645872,-80.11078678103901 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark01(15.613623096241795,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark01(-15.626914364589723,-6.281341447104836 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark01(-15.63104975118949,-23.82460591166094 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark01(-15.638020619815563,0.0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark01(-156.42511434062382,5.114348909479408 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark01(-15.64351599245633,0.0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark01(1.568166486155948,-1.5707963267948966 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664861559967,1.5707963267948966 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664861566371,1.5707963267948983 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark01(1.5685487712168602,-1.5707963267948966 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark01(15.694175341437571,-58.45140134371511 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark01(-15.695428310491998,1.5707963267948957 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark01(1.5697581923902195,-1.5707963267948983 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark01(1.569822153899967,-23.56194191042282 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark01(-156.99873966628877,70.68876861919284 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark01(1.570416195525303,-0.5707960392742827 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark01(1.5706352173004348,14.13717044645083 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark01(15.707742116851858,-0.021263077148743058 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark01(1.570774652915657,-1.5708001416568478 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark01(1.57079548489559,70.6858382279818 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark01(1.570795791839434,-45.55504660205201 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark01(-15.707961457062213,-0.001825739088507041 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963127249274,36.12831199404348 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963240271605,4.71238545814527 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark01(1.570796324552545,136.65862889393782 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963261422546,21.509689559284354 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326766418,-92.67697975865941 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267882088,0.009029663991345055 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267924683,-91.10324721509788 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267934169,1.5707963267948963 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326794433,-0.6520317977724585 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267947598,-41.80948632452271 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267947846,-31.5708853408601 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948273,226.38088271681374 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948364,0.0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326794844,1.57079632679488 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794869,0.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948764,-1.5707963267948966 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948841,79.73142461265732 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794886,-2540.9171910090454 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948895,-21.442542174858588 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948912,-0.007086140844518085 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948912,12.11285471730389 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948912,-1.5707963267948983 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,1.5707963267948992 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,-31.810056273123244 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948912,-66.09038365162165 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,77.47939806057508 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948912,80.17606741123001 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948928,9.860761315262648E-32 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794893,-100.0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326794894,14.42920585007436 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948943,0.1274868412927376 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948946,0.0026298406378780217 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-0.03877535839549668 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,100.0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,100.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-16.478785139831913 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-1.9953816979270123 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,2.5141707908791526E-16 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-2586.64762465577 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,58.63727151322803 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-64.79011292630916 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-69.31315582586026 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-73.82742383712065 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,77.60200583853381 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,78.94657509113799 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-80.14476454924034 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-85.26137076719908 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,-100.0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,1.5707963267948999 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,3.1415926535897936 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,-46.64325618196251 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948957,-68.80035614737537 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948961,-0.11153668120868872 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948961,1.5707963267948966 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948961,-1.5707963267948968 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948961,69.75905688787552 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948961,98.0780528110941 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,-100.0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,-100.0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,1.5707963267948972 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948963,2448.8298337144456 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,29.84513015588378 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794896,-32.986844933162914 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,-73.82742713181824 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark01(-15.707963267948964,-1.5707963267948966 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.0032192808145422094 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.004074859006730164 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.010149349489339958 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.011988759298050988 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.018478833246703026 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.050024548375676554 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.05973530043214086 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.31022669254457524 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.3740287013606093 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.4988558212722381 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.5517917483677232 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-10.762645086436457 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,11.296135523539757 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-11.662503203157996 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-11.828051196816116 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.196129438602239 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-136.4979496604671 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-14.137166944496567 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,14.42920367326333 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-14.429214160451572 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,148.3341148031438 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-15.140325829768585 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-15.249685184634927 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-15.362173964022347 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5406118623286116 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948957 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.570796326794896 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.570796326794897 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948972 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.6113270284149166 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.6760940315924557 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,174.35977632551922 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-177.50009079453355 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-19.640857178165163 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-23.561944901923443 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,23.561944901923443 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,23.56194490192345 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-24.23164173770048 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-25.13274122871743 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-25.13274122872064 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,2518.161888986505 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2525.542336565157 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2625.726411124519 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,2633.5988108179304 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,27.052510415719873 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,29.345805133774746 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-29.845130209098745 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-3.1871437582275437 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,33.79276871732423 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,34.03239968441904 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-34.67974829762648 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,3.469446951953614E-18 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,34.85596741153484 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,3.552713678800501E-15 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-36.684871035963205 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,37.69911184307265 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-38.05118073562021 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,38.99246378787062 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,39.51167856672532 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-39.5356802144159 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,42.513929481993955 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,43.98229715095354 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,4.404657897880259 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,44.141734702248584 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,44.609893705853615 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-47.45238095056514 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-47.91200210313537 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-50.26548245743264 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-51.20436729799454 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,52.48117400604061 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,52.78709721637222 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,5.583457232001228 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,56.54866776461862 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,58.15071409141118 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,58.24320624573849 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-59.69373561502111 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,61.26105674455607 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-6.283185307036656 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,62.8318530715729 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,6.283185307180618 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-63.03152890802561 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,63.657186948123325 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-6.429265680501385 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,67.54424205215862 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-67.54424205217481 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-67.54424205218054 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,67.54424205218054 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,68.71036323550763 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,70.92895924750486 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-72.25663103256524 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-72.55066750664875 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,72.7489020861083 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,74.64903795368575 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,75.03954162787306 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-7.861794191332085 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,80.10594753914572 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,8.07965109438075 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,82.89509591371194 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-84.29529811179125 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,86.45294958197913 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,8.673617379884035E-19 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,87.96459430051421 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-87.96459430051516 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,88.08959430051422 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-92.67698333190486 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-94.24777960769583 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-95.24778067007715 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-95.48908248801682 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-95.5316102360668 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,95.59807017737553 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,9.56396499352268 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,98.96016858807849 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948968,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948968,100.53096491486774 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948972,-1.5707963267948966 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794897,-27.150729130653488 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948974,38.236026083560816 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948977,120.95229387842267 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,0.024979460900083822 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-100.53096491487116 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-14.441417559669524 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-1.5707963267948983 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-1.5707963267949054 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,1.5707963267949125 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,23.561944548539294 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,245.04422697934444 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,2598.6482725817227 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,34.1118618522226 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-42.41149730819545 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-42.56771013456044 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-4.410361521145873 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,55.93596236214901 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-65.21389227640518 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-77.04910007064794 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-9.660610172172834 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949019,-0.6631305050901801 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,0.0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,1.5707963267952358 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,-40.261400554990004 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,45.55309538437531 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,4.712385872311228 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,-84.71423940662763 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949,-100.0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949117,-4.712388980384683 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949197,-80.45605105827084 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949268,-67.54423920187166 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949598,-95.81857974918597 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949745,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963268402054,-105.24295765548683 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963750032723,-73.82742383712184 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark01(15.70796517527796,-0.001772854685833668 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark01(15.707965175297598,0.0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark01(-15.710923384878356,-19.333252871214192 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark01(1.5711254360379785,-0.45516942403988125 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark01(15.723588267948967,-1.5707963267948966 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark01(15.723588267951227,3.469446951953614E-18 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark01(-15.723588268088186,0.0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark01(1.5724307466701615,36.12831336973937 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674330965,1.5707963267948983 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674331207,-1.5707963267948983 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674337242,-1.5707963267948966 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674338161,1.5707963267948966 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674341712,-1.5707963267948957 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark01(157.87049634146996,2579.9722567662766 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark01(-15.810724909762751,-205.89557806673247 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark01(1.5840677751871084,-0.10184682666439315 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark01(158.47582135747382,75.97914230636844 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark01(15.858316698870272,0.0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark01(158.65042888510393,-92.67696045271761 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark01(-15.968227631964112,-18.21576412121658 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark01(-15.986581450043618,75.72231434898947 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark01(16.019669992932613,-0.5707963248510143 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark01(-160.20727262770853,-2.2377633323590104E-27 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark01(16.0377068615256,95.25731779870075 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark01(-160.737804143241,10.995574287564276 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark01(-160.79586079029932,-0.2766038258171849 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark01(-16.081624335192274,1.317684991123814 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark01(-16.165611417481657,-38.95632856533615 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark01(-16.19876424362345,16.714266322159286 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark01(-16.231172554537807,73.01502608060072 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark01(-163.1570553210224,13.069529486594277 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark01(164.22117081273834,90.76628390545702 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark01(-16.553061932882642,-30.0126740516005 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark01(1.6653698652345946E-8,80.57114277134212 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark01(-166.76964031548195,0.19154874098225366 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark01(-16.709046428494062,-1.4121879038629632 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark01(1.6726886023136274,-16.865379864444535 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark01(-16.76580671293408,29.18483519970585 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark01(-168.22248010632006,-56.24923856517194 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark01(1.6838641390450206,-7.847597783166337 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark01(-16.86789089348402,-0.04489779361263763 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark01(-169.1505611550184,-2565.0757207102424 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark01(-170.19347892720097,-58.55887611885298 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark01(170.40995890834967,-4.221728783534161E-15 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark01(170.60583298395102,-5.921940327315255 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark01(-17.091298360704116,71.84207541908651 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark01(1.7205457079069015,-0.4999926341372643 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark01(-17.273507212290244,-63.135802462781264 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark01(-17.278729862448827,67.54423919739394 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark01(-17.278759418818456,45.555046608707826 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark01(-1.734723475976807E-18,100.53077095971206 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark01(-1.734723475976807E-18,-1.5707963267948966 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark01(-1.734723475976807E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark01(-17.41494087216439,4.8395512477037395 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark01(-174.45201756978517,23.56194490024163 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark01(-17.53706708688874,0.5587657248034105 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark01(-175.41049303935182,-14.450191718102907 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark01(1.7544545756285999,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark01(-175.556183945039,-0.019596353167748493 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark01(176.06439690786593,-44.52297818435513 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark01(1.7658004292630463,1.5707963267948966 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark01(-1.772327455263408,36.62836310244134 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark01(1.7763568394002505E-15,0.0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark01(-1.7763568394002505E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark01(-17.989999392377825,35.41357191700226 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark01(-180.13611940798447,-10.520143667840909 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark01(-180.195657041517,173.6346622545388 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark01(-180.72318996122254,-59.01241504503916 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark01(-181.00732477543195,75.2503669922566 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark01(-181.80844614857972,29.845130555907048 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark01(1.818961115284813E-6,-2.7665708253336305 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark01(-1.8203241525409375,4.280167633920502 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark01(182.2125165830402,0.0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark01(182.2629810077586,0.3194311376999891 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark01(-18.29917998442937,-80.31301930591474 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark01(183.66381112614326,152.36724571372716 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark01(-18.380074392358537,0.0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark01(-185.35204463060182,7.074059984032229E-8 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark01(-18.547227628401572,-22.34126026390655 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark01(-18.63605295665181,-21.082626152886405 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark01(-18.689196087364266,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark01(18.849555924634306,-0.0015927672849705642 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark01(-18.849559443778247,6.938893903907228E-18 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark01(-18.85000099485274,-0.0011835052030210807 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark01(-18.850767440632012,94.24844902613101 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark01(-18.857368421794263,-1.5707963267948966 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark01(18.882577034399784,-1.5707963267948966 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark01(18.946935784306966,100.0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark01(18.980232712621586,6.440233355684204 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark01(19.035501629924866,71.45644448009554 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark01(19.046642517216693,89.63814265337896 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark01(19.053774698814564,0.0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark01(-19.082896683975328,18.173617939297596 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark01(-1.9116343613438478E-10,-0.5707963266037331 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark01(-19.19147883878182,-53.09850704216684 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark01(-19.20234528667548,56.082768228147856 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark01(1.9209620066499498,0.8898957910054583 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark01(-19.233637612063802,-42.55177382130037 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark01(-19.253635924151354,76.66662376884818 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark01(19.30174821001082,-55.444024471974714 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark01(19.324340611139945,97.6883620467492 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark01(-19.397134623132622,-61.95922279553855 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark01(19.44046937576346,98.98958486024051 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark01(-19.441973224102398,49.94630486167459 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark01(19.471640735888393,77.9159800698709 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark01(19.49500023353093,149.85368788875712 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark01(19.49533281296216,-10.203887257887345 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark01(-19.540410525879732,-1.5707963267948968 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark01(-195.6802583443634,-88.22996820481336 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark01(19.595516444186195,6.712571582095421 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark01(-1.9610734836247412E-6,18.851298618647867 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark01(19.616346238050326,-105.25332955489137 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark01(-19.618644589561114,27.155379612617914 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark01(19.636063253974257,-1.2743646833195548 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark01(196.36377486360084,4.712487098079595 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark01(19.68863069059377,1.5707963267948966 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark01(19.693996676507822,-16.4412594510964 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark01(1.9721522630525295E-31,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark01(-19.72569991528215,-72.84907293973222 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark01(-19.77604747993418,7.335780671116215 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark01(-19.82426044513265,-45.91376532651079 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark01(-19.858389474732565,1.5707963267948974 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark01(19.88993325313448,-1.5707963267948966 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark01(-19.92271970516309,-7.443049433356201 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark01(-19.948088232374673,111.74776595011883 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark01(-19.96975470850846,-75.50731817150387 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark01(-20.006037905920408,0.0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark01(-20.039120809185775,0.38038128976657515 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark01(-20.089509283177346,93.83611499617015 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark01(20.20040199898658,-28.1690670132743 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark01(20.236663187615008,-18.8721668220278 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark01(2.027135866091996,38.40535459716955 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark01(-20.32748567165514,28.407373377384346 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark01(20.32881297609137,-11.651468960650647 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark01(-20.357186718616248,1.5707963267948966 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark01(20.417722407695504,1.5707963267948983 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark01(20.418681267817867,-39.26990952312513 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark01(20.419970244510196,-1.5707963267948966 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark01(20.420411580874784,67.54423853458951 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark01(20.42073673161251,23.561941463052342 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark01(-20.429419880108135,-62.14553176491984 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark01(20.431674560947727,1.5707963267948968 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark01(-20.43965800971883,71.25181803110735 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark01(20.454248423452135,72.34404072595801 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark01(20.471205846827203,-1.5707963267948966 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark01(-20.478550888532226,-4.5941951643506425 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark01(-20.48407348045795,-44.53936318876837 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark01(20.494718259409986,-56.61602837479827 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark01(20.5216928608601,0.3552748978110244 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark01(20.52853699364914,-2.1284227860041254 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark01(20.53829245920848,-107.09380398520386 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark01(-20.544388742023372,1.5707963267948912 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark01(-20.574440802508626,0.570256747877192 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark01(20.59865574511899,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark01(20.63497868297813,-91.10087337499121 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark01(-20.66236286882102,30.644974419075254 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark01(-20.700747477628596,7.848221347968421 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark01(20.70578970279375,53.66721438431078 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark01(-20.70733735725627,-1.571038519481435 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark01(20.751222860284372,68.02248321991583 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark01(20.767563461768717,-2518.863654753714 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark01(-20.826975361579898,-0.1855231112913392 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark01(20.844147402661356,0.0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark01(-20.844703632453736,-1.5707963267948966 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark01(-20.86088775089148,51.16540923407007 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark01(20.869135065804784,0.023071892048675324 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark01(20.895643183292226,-1.570796326794897 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark01(20.901596501958025,60.49412344255671 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark01(-20.90347684875347,-15.535045506165886 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark01(20.939416761383626,89.08715130167408 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark01(-20.941084340920753,-44.27161440087405 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark01(-20.94575175633915,0.4017607388447639 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark01(20.993626635145503,53.350190266526795 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark01(21.065209045579564,35.93065962579175 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark01(-21.107016656808693,-14.431807977957135 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark01(21.172048433586745,49.41060489643286 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark01(21.255212121649933,10.180578938631271 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark01(21.266905335346777,-42.6459571430738 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark01(-2.1321286354704796,-0.42705819706484577 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark01(-21.4216177285532,-52.47010757073709 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark01(-21.42190050833254,-1.5707963267948983 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark01(-21.437804226815103,-0.32615452271929257 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark01(21.44553348815728,20.922336318618992 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark01(2.1523540728995325,31.44664758778366 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark01(-21.524172447299648,0.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark01(21.531825916510527,-140.19456297531715 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark01(21.554842758875452,-29.41917774073542 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark01(21.587879017375954,1.5707963267948966 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark01(21.602110282236755,1.5707963267948966 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark01(-216.02832968861938,0.04303427512875208 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark01(-21.627849868301624,-11.138973132283915 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark01(-21.63368046623046,1.5707963267948966 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark01(-21.63526210324629,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark01(-21.66282565131968,4.440892098500626E-16 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark01(21.665289953049395,0.0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark01(-21.67934882121623,-1.5707963267948966 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark01(-2.1684043449710089E-19,-23.56194490191844 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark01(21.68848817499638,2601.100057847444 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark01(21.70819605342439,11.800541649522287 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark01(21.712138758865763,-61.56786700750213 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark01(21.746196627206075,-96.6843894847294 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark01(-21.776583238040686,-0.11618142754128766 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark01(-21.803347803031834,12.046709162233753 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark01(-21.82486572282549,-86.51224559280138 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark01(-21.82835614286995,0.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark01(21.853028749885052,-100.0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark01(-21.87709708639875,23.51875914882899 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark01(-21.904146510229268,-6.1753832206606205 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark01(-21.987218149934254,1.5707963267948966 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark01(21.991137130214312,0.0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark01(-21.991143443619226,-9.380655996480552E-5 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114505781717,-50.26556012720716 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark01(-21.991145059049366,-88.08961603694748 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114511696383,56.54833356673899 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark01(-21.991145146166115,106.81374219240915 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114523368576,-2.1175954069033884E-22 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark01(-21.991146612446148,6.284367833781291 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark01(-21.991147303539034,6.204493488860964 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark01(-21.991147484768717,-62.82967199350311 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark01(-21.991148119083675,100.5334160144276 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark01(-21.991148575128488,-1.5707963267948966 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark01(-21.991148575128545,1.5707963267948966 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark01(-219.9450614094319,2.140875533937343E-12 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark01(-21.995637858469138,50.36029186268162 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark01(-22.004482568474018,0.0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark01(22.025122376191476,24.142771553709537 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark01(-22.06990556074959,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,-0.5629631352585968 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,-100.0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark01(2.220446049250313E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,-18.85072897795624 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark01(2.220446049250313E-16,2639.021027268407 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark01(2.220446049250313E-16,-3.073346734847339 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,31.41329669525915 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,-43.9849218523575 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,6.123235005394038E-17 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark01(-2.220446049250313E-16,-67.54424205218051 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark01(2.220446049250313E-16,93.21835088471336 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark01(-2.2278215958135803,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark01(-22.312260588743097,162.63888556745758 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark01(22.33249421376306,0.0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark01(22.380765590767574,-1.5707963267948966 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark01(2.256692474779731,0.0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark01(-22.584988907805982,-1.5707963267948966 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark01(-22.72098631107407,-1.5707963267948966 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark01(22.837372225587288,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark01(22.87377378925501,70.61974245260163 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark01(2.294314110686388,1.5707963267948968 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark01(2.299265552725369,-44.49881801840113 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark01(-23.054583272987834,55.042207502827495 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark01(-23.15778920979203,74.68809794059723 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark01(-23.254626137055638,4.837388980384691 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark01(-2.3289956141964865,-49.11317803865456 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark01(-23.302942569160024,1.5707963267948983 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark01(-23.39783846928496,0.0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark01(-23.55931506128458,-1.5707963267948966 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark01(-23.559648974934106,-89.53539145779224 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark01(-23.560081393798416,17.278759538617024 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark01(-23.708074984992408,-94.74835181365624 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark01(-23.7456668602487,1.617057822092481 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark01(2.3835323411282303,-73.31758314215978 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark01(-24.30499394363371,14.560476663555601 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark01(24.34600600001025,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark01(-24.355636158208412,0.42300330403541864 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark01(-24.603612463068867,0.4807365140627279 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark01(-24.606464310753957,1.5707963267948966 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark01(-2.465190328815662E-32,73.82742735936013 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark01(-2.465190328815662E-32,-83.2522091348268 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark01(-2.465190328815662E-32,89.53563476793411 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark01(-2.4759949782405027E-16,75.39559384551626 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark01(-24.856099469359208,48.98148779521719 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark01(24.869579994167708,-14.918804197366981 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark01(-25.08483570991501,-1.5707963267949019 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark01(-25.132741290342913,-6.2228657488320955 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark01(-25.132744723966184,-2.0903765537634507E-4 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark01(-25.132744750957833,0.0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark01(-25.132985369343352,-1.5707963267948966 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark01(-25.195241228718352,1.5707963267948966 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark01(25.21193471986311,-2617.9367529663195 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark01(25.231314918156954,-47.98700652918907 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark01(25.25850964126414,88.47085707423442 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark01(25.262752441140236,-10.596671264614077 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark01(25.269242251441263,0.0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark01(-2.5274441610657033E-15,-0.0025208080278662226 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark01(25.317190893777628,155.58895163771768 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark01(25.37768743842682,104.61855443933244 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark01(-25.38478553488784,-66.35239094953926 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark01(-25.394745957268185,-53.63717913377026 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark01(2.5437972535260163,-42.863959841013966 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark01(25.456702853317765,16.226698553813776 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark01(25.47419364539553,-70.0629569304599 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark01(-25.477590742550916,1.5707963267948966 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark01(25.561705299018683,-63.984991868410624 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark01(2.5632422917038866,0.36866939221863576 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark01(-25.659371749595607,-0.5707941316894131 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark01(-25.660340070311534,80.11061266802808 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark01(25.67978304064016,45.05262457948845 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark01(25.69727535209954,-6.712388980384691 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark01(-25.777471355337525,25.60237216706669 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark01(25.862888313306613,-39.20833561138484 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark01(-25.92105918243996,-29.845130209103036 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark01(25.938423546920248,1.5667752230915537 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark01(-25.956318484326758,18.76586980292238 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark01(-25.97823268287341,-126.28115435443601 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark01(26.06321414095561,23.08731059970674 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark01(26.09900378360821,1.5707963267948966 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark01(26.132741228718345,1.5707963267948966 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark01(26.13318925861779,-0.02694429129358695 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark01(-26.152302441156543,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark01(26.19969348349413,1.5707963267948966 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark01(-26.20920472467807,9.177873548128616 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark01(26.294525801911934,94.16418199305008 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark01(2.6297035245562235,1.5707963267948968 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark01(-26.30445722906198,0.0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark01(-26.34968534733167,-51.39588219010629 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark01(-2.6400928753871113,19.546806083707494 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark01(26.44546914230031,-4.370701573736312 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark01(-264.4607350099023,-0.4754907153697089 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark01(-2645.135355701768,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark01(-2.6481973169440662,49.88474519339766 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark01(26.501926339322225,-9.571785052119907 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark01(-26.525494310175933,-40.86084067828752 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark01(26.551926238971575,1.5707963267948968 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark01(26.55250914450881,38.82128694831878 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark01(26.565599778093446,-0.262069451724811 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark01(26.568500028931854,1.5707963267948983 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark01(-2.660403009632922,-1.5707963267948966 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark01(26.685391581615598,-4.712633121009691 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark01(26.70123995661163,-10.995573460961609 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark01(26.702461967168986,-78.79931686043065 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark01(26.703537555508557,-212.05745466554916 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark01(-26.704657958493684,0.0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark01(26.705564777942232,-80.11061202788022 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark01(26.70616739615208,1.5707963267948966 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark01(26.70616739615215,-1.5707963267948966 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark01(26.709255315114703,88.56549077103415 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark01(26.71687974219377,-1.5707963267948966 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark01(26.71787655313093,45.44841879810535 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark01(-26.79683221729998,-1.5707963267948963 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark01(-26.811809055131306,11.388937878584173 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark01(26.813584116746654,-72.6154837547144 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark01(26.85904680205647,2624.949623652609 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark01(26.867736507626777,-100.0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark01(-26.884790357316096,-86.39398736028176 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark01(26.934455835311127,-32.658872876362935 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark01(-26.93988514013262,70.68583470577035 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark01(27.02938850365628,19.55686959985603 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark01(-27.034798217763374,0.0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark01(27.04456239798558,0.0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark01(-27.051499769351423,-89.90165710709235 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark01(-27.076727014715345,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark01(-27.07728088615187,-16.696754211454973 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark01(-2.7089417389784387,45.09509778007066 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark01(-27.097881463337785,-28.672960234289043 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark01(2.710505431213761E-20,0.0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark01(-27.1426722684088,-1.5707963267948968 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark01(27.151545938250706,-61.147351447608536 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark01(27.153289922200273,-2596.340518823829 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark01(-27.16167866103426,-66.30498526826057 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark01(-2724.7531968177086,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark01(2726.229113875195,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark01(2727.1366206753455,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark01(-27.27299550919031,-43.864748881151286 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark01(-27.27970250315603,-1.5707963267948966 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark01(-27.279760803572046,-0.49374603266129213 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark01(27.43326277233653,-53.738803487983965 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark01(2.757484250678843,1.5707963267948966 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark01(-27.638296293265114,0.0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark01(27.728206081410434,61.57814776684353 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark01(27.737092918675067,-32.47665965322744 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark01(-2.7755575615628914E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark01(-2.7755575615628914E-17,-2575.2216150905047 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark01(27.76505604192303,74.83345181837443 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark01(27.79313628998304,18.174632291474396 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark01(278.0309495738179,-67.54423852994769 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark01(27.816812087776583,3.9268095331168746E-16 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark01(-27.82807767245421,44.526939930373295 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark01(-2.783782757814804,-17.278760509080254 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark01(27.885809866697894,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark01(27.916952143058147,20.79868753341016 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark01(-27.925688696812088,-17.134946065300397 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark01(27.946068802155978,1.5707963267948968 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark01(27.995478733117224,-50.65337234194545 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark01(-27.9995548995265,-8.739309961548772 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark01(-28.009384574388235,63.36549471046382 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark01(-28.060521310061247,-46.968202283314696 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark01(-28.061282188880227,1.5707963267948983 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark01(-28.06897715091024,1.5707963267948966 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark01(-28.07213287589363,-1.5707963267948966 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark01(-28.11130735449822,1.5707963267948983 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark01(28.121400988727814,2.9821044920494975E-4 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark01(-28.1340999594786,0.03892238702196336 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark01(28.152050762665993,-95.66380485742845 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark01(28.17589339581167,-50.22813299611728 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark01(28.185951536523532,100.0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark01(28.223935578186797,0.0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark01(-28.228586187093015,-2558.9026417584337 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark01(28.238665512109765,-74.63618717282857 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark01(-28.249171868044982,9.651954936691295 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark01(-28.25676279077811,100.0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark01(-28.259665512426167,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark01(28.26941963502488,31.51512311991998 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark01(-28.274330360068653,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark01(-28.274330556044042,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433090683502,56.54968923275905 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark01(-28.274332184767964,-81.67952297015721 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433250835359,-0.0020485003941329715 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333381086404,-83.2522205789186 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433378073208,-67.54423885607815 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333876620577,23.561944901204566 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433388230811,45.555203774657 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark01(28.274333882308134,0.0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333882308134,-1.5707963267948966 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark01(-28.274334120727534,0.0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433515123451,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark01(-28.288642919741275,-0.16937421892024146 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark01(-28.329366550269498,0.0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark01(28.339558533423116,-34.191474783965845 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark01(-28.419350130337477,44.52659428025022 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark01(-28.450520819196903,0.0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark01(-28.455395412303403,1.5707963267948966 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark01(-28.523191849010672,-4.078691686750479E-6 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark01(-28.556801669835345,1.5707963267948966 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark01(-28.921843157391194,-79.63083332495866 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark01(29.037192552081052,33.374769738871066 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark01(29.05422937861738,-33.86939823384658 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark01(2.9093409907969905E-29,-1.5707963267948966 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark01(-29.197790055379997,-77.68540041404093 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark01(2.923302219984336,-1.5707963267948968 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark01(-29.312660181326194,158.45920286794882 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark01(-293.7413306730006,1.5707963267948966 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark01(-29.487452198034294,198.24339616226888 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark01(-29.507169850193783,0.013869801448708257 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark01(-29.510223503577613,-31.934526310109568 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark01(-29.58477999791765,80.2341799625375 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark01(-29.77503849215242,-48.694697331861065 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark01(-29.84427372363934,-73.82742616260471 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark01(-29.84512854877248,-86.39379445152208 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark01(-29.846420702784734,64.40265205650043 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark01(-29.84732684208257,-10.995573489216206 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark01(2.9906278350722933E-10,0.30801818119854085 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark01(-29.91106195193592,1.5707963267948966 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark01(2.9956895484810544,-0.545989361696465 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark01(-30.000658184705742,-1.5707963267948974 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark01(-30.017237085827666,-94.63582143252543 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark01(-30.61922925486127,-4.712390595035928 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark01(-30.741268918117186,0.0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark01(-30.83940872238435,-44.26851614707377 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark01(-30.88092223889788,15.728420891395132 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark01(-3.093332413154471,-54.78154449167419 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark01(3.125733563398393,0.4199153534303296 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415891313503064,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415891313511324,12.566370580793912 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415891314723594,-31.41593107492726 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark01(-3.141589417495906,-43.98156481575305 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark01(-3.141592622897082,0.0011336525509525177 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415926286963534,207.34249469231543 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415926492161166,10.995574249154867 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark01(-3.141592653589791,1.5707963267948966 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415926535897927,1.5707963267957994 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415926547685875,-0.0026302847508697675 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark01(-31.415927616951123,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark01(3.1415932898151495,-106.81177202828577 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark01(-31.416048749244073,-163.36048325124705 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark01(-31.42762379183368,-36.49151342692338 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark01(3.143545792263751,0.009321991647215231 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark01(31.439737313576714,0.3828416349837401 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark01(-31.447236433633293,5.212388980384595 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark01(31.50128409755078,-0.23577355184326126 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark01(-31.510967094094227,-3.534942343962939 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark01(-31.57283293588107,1.5707963267948966 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark01(-31.68169011268442,1.5707963267948966 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark01(-31.712992278798538,85.95494828733675 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark01(-31.72229458211003,-1.5707963267948966 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark01(-3.172842666882206,-68.90006933517726 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark01(-317.2998718936631,6.203981847041347 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark01(31.73607420302864,-45.533727053947885 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark01(31.769585085459738,-11.843061768060139 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark01(-31.77243030737526,-18.776108314529367 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark01(31.79638064817695,100.0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark01(31.88029326695956,32.551268476362225 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark01(32.09273189003406,-37.85032108149656 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark01(32.12177441246962,-76.9526240293845 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark01(-32.153613269311805,3.2530844769897143 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark01(32.1642501119629,-19.680476898657844 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark01(32.169141451135914,-98.65139183229694 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark01(32.230728344646565,3.336662792058292E-16 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark01(-32.24441193938759,-14.435554396356451 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark01(-32.264637352135,58.692269973776376 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark01(-32.32869241955083,0.3686230903526462 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark01(-32.46524373069292,1.570796326794813 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark01(32.484463497994795,-13.697188458047739 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark01(32.520408489976795,-4.837388980384691 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark01(3.25234542358695,95.2779240540867 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark01(-32.626023168619284,9.494107596574928E-16 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark01(-32.63443735624399,-1.5707963267948966 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark01(32.65326981680949,1.5707963268213263 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark01(32.67623278351279,-74.61502510717388 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark01(-32.67818198596433,0.34691073473896755 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark01(32.69311339904027,27.314524784613397 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark01(32.81455573716826,-18.49403665437414 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark01(-32.859258049987886,-31.140822635121793 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark01(-32.86539496207851,1.5707963267948948 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark01(32.890839264857476,1.56620476285084 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark01(3.2973291567546175E-9,0.1204718053941427 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark01(3.297999240228311,67.7214455325774 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark01(32.98409302205389,-1.5707963267948966 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark01(32.98409302205461,-1.5707963267948983 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark01(32.98444712970298,7.8539825111077315 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark01(33.13697601860531,-1.3547956901211924 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark01(33.28385975749072,-1.5707963267948966 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark01(-33.31300433431117,46.53199982267685 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark01(-33.32516766756645,65.81856525466702 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark01(33.33426960257745,3.532293428111103 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark01(-33.394883125174644,-67.56418962089708 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark01(3.343819852470034,-5.4349449406692685 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark01(-33.43938821447854,-76.49927448764129 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark01(33.57173023554574,-88.35166502156738 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark01(-3.365192601285085E-6,62.83238947227644 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark01(33.778048540418496,35.80960509566836 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark01(-33.9275108424599,-24.80180699991162 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark01(3.422927874979546,-0.7630840635802522 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark01(-3.4352215014054367E-6,-37.69950515341234 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark01(3.4380780054644227,-2585.2744594710134 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark01(-34.47847591733288,14.654211618309489 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark01(-34.55751566724824,0.0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark01(-34.55751918626333,-0.0028744122154001424 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark01(-34.55751918948034,1.5707963267948966 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark01(34.5575213962078,-50.26388472074781 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark01(34.55752165024962,-31.417359269590442 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark01(-34.57802086947119,0.0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark01(-34.61998984253988,-41.2360422738981 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark01(34.62612549739972,-46.74433633481476 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark01(-34.63751294796606,-100.66893784671184 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark01(-34.65203618522217,-75.07195720019057 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark01(-3.469446951953614E-18,-1.5707963267948977 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark01(-3.469446951953614E-18,1.734723475976807E-18 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark01(-3.469446951953614E-18,-43.981195196267144 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark01(3.4696772911437535,-1.5707963267948983 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark01(34.80879540270995,0.42724072176857064 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark01(34.85969778105467,40.36699489677659 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark01(-34.91311507015109,-48.2243503512648 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark01(34.984512906527584,-0.3535139517942554 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark01(-35.03451319945867,-90.44602121928767 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark01(-35.04205762546975,73.43917624785239 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark01(-35.05142339339697,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark01(35.08754204136898,-16.05826293379903 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark01(-3.5222394875832145E-6,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark01(-3.522239487636917E-6,-81.68140899333463 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark01(-3.5222394876410105E-6,0.0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark01(-3.522239487664297E-6,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark01(-35.247957576692585,-93.5115879391713 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark01(-35.267675355641586,-1.5707963267681158 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark01(35.28528185236871,0.36280295420634673 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark01(35.3334019719272,-92.6769832808989 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark01(35.34712279633976,-43.86532175045743 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark01(35.371905211809434,-1.5707963267948968 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark01(-35.418888494400925,113.39406552357948 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark01(-35.42248412465324,-1.5707963267948983 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark01(-35.43246848002168,5.212388980384691 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark01(35.435331941524495,-1.5707963267948966 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark01(35.44658404835028,-33.19530849778799 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark01(35.447205163826084,-6.445497436866383 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark01(-35.49090022036935,1.5707963267949054 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark01(35.52009962944757,-0.42812113337292335 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark01(35.52406100148789,45.547380637099295 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark01(-35.59315169015551,-1.5707963267948966 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark01(-3.5623342142128784,0.9378008384113947 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark01(3.5625979461271697,-32.611588779938046 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark01(35.62763492879003,-2.5687096681284736 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark01(35.66563379320394,76.09239667568849 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark01(-35.66621985671461,-1.5707963267948972 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark01(35.67108034991236,1.5707963267948966 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark01(-35.68080929418704,14.996695563754287 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark01(35.698681753741596,0.0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark01(35.78667460473943,-99.17995797071302 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark01(-35.80566525915677,-96.02438101798828 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark01(-35.92464716933534,-1.5708115856899816 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark01(3.59611038601804,1.5707963267948966 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark01(-35.990958704291785,0.0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark01(36.01395500710595,-6.445087570261705 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark01(36.02179267655259,2645.8014278342375 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark01(-36.05415623184366,-4.715135452665348 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark01(36.05962156056013,-1.5707963267948966 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark01(-36.061737036824226,1.5707963267948912 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark01(-36.125685675644405,1.5707963267948983 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark01(-36.12702707485972,17.27875693413776 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark01(-36.12726169925435,-67.54424195819752 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark01(-36.128307714523764,-67.54423853149177 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark01(-36.12831518779661,127.23645566590137 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark01(-36.12831551464883,10.995570765978092 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark01(-36.14277492130738,2712.490146891514 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark01(-36.330381013846534,24.8563763052329 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark01(-36.50051309221196,-13.036062237926657 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark01(3.6505427138369413,90.91389248140752 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark01(-36.56804946972296,-58.02418504427082 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark01(-36.66155129431104,0.0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark01(-3.6690599377153976,72.37803309670608 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark01(-36.946233895131506,-98.51314316269786 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark01(-3.69953498732427,-0.4024694490310594 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark01(-37.03909786889996,95.42133878183732 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark01(3.7078597337828647,-14.429567185064847 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark01(-3.733430201607718E-20,43.98349745906337 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark01(-3.736308507044177,-0.4999999992940925 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark01(-37.49806728964362,0.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark01(-37.49812020611365,55.49977625677475 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark01(-37.673664203796896,0.22607159233470506 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark01(-37.699111843077524,1.5707963267948966 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark01(-37.72977914479855,10.840599563084542 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark01(-37.746623868966076,1.5707963267948963 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark01(3.778205997354735E-16,-0.13154332043488043 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark01(37.786171763718755,57.89771997834626 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark01(3.7808671102652625,-88.41104918451444 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark01(37.87644021512085,0.0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark01(37.87722909583087,86.91383787326035 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark01(38.0164318161531,38.8522342258716 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark01(38.01652049481717,13.378583073165071 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark01(-38.1239971611499,73.29310071155078 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark01(-38.13986203514534,1.1137575639864017 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark01(-38.15692043175586,-9.727757170606342 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark01(38.16590504802454,-48.93367136899081 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark01(38.23469605233403,0.15898563699142937 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark01(38.235023644591365,46.14356980870218 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark01(38.25863308792941,123.52957434781935 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark01(-38.36406502791094,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark01(3.839621798876962,0.046540412396261055 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark01(-38.496092083179214,-85.94270269362111 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark01(38.49896740617737,1.5707963267948974 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark01(38.57024142080266,-24.588085730288995 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark01(38.592589945899306,-26.491783931655164 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark01(-38.71816505798229,36.87522014427924 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark01(-38.746783123433644,-100.0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark01(-38.74764042022429,-38.794367993712555 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark01(38.785592806872806,-10.64974351040604 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark01(38.86013306061734,0.0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark01(38.87733733550904,2.384754211904024 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark01(38.95302437254134,57.87715754075025 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark01(38.96066514590629,44.607972280869916 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark01(-38.98819180257684,-49.836100449293916 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark01(-39.01093725999927,-52.34255031786945 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark01(-39.07842666423888,-0.20571875204532947 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark01(39.111346420002455,1.5707963267948966 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark01(-39.19705165974114,-2626.1860540254756 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark01(-39.20274755451205,1.5707963267948966 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark01(-39.20807230864591,49.969699101494044 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark01(39.25120634330022,-81.98334185464138 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark01(39.26805974524508,-10.995572728726453 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark01(39.269665121203516,1.5707963267948966 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark01(-39.373876540283995,-2.6824089423619313 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark01(-39.435878758118314,1.5707963267948968 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark01(-39.523171549692975,1.5707963267948966 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark01(-39.66512022691093,-39.926169644081824 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark01(39.674602986036234,64.4719319363569 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark01(39.701334011723134,-74.13616629337034 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark01(-39.71387037498049,-2622.7738120369863 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark01(-39.87369319972629,2605.2387002382943 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark01(3.993779327244468,0.0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark01(-39.971969729139964,1.5707963267948968 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark01(40.07055121180818,0.0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark01(-40.20924416686624,-96.97935791868055 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark01(-40.266709859801246,0.33497733456156953 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark01(-4.030369858229861,0.0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark01(40.374542738873174,-2.702348571270676 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark01(40.40492050463445,13.841820421180657 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark01(-40.44010391438364,41.94163241624946 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark01(40.46875086274187,-2711.334781950427 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark01(-40.49438582581999,10.475858268493667 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark01(-40.55839945617616,82.60795045347949 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark01(40.61483945505455,12.324365647687676 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark01(-40.61526991715216,94.01355499912901 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark01(-40.811649976290724,88.31170714996347 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark01(40.84066856404034,94.25663884406829 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark01(-40.840704484542094,-205.77356120876317 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark01(-40.84070449666708,-67.54424132387562 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark01(40.84070773566162,0.0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark01(40.8407080189068,-81.68140899333463 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark01(40.84472965155993,1.5707963267948966 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark01(40.87196553876244,-0.0016912593901400128 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark01(-40.88360891762326,-100.0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark01(-40.89962171184558,43.05161947733267 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark01(40.90098804384904,-0.12841130782226806 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark01(-40.9283668217906,-66.40091776861195 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark01(-40.92842917318511,1.5707963267948966 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark01(-40.93810622954865,61.97959900065764 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark01(-40.997734648743055,0.0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark01(-41.14883726343792,14.896602728360818 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark01(-41.18142225360735,12.858467140538764 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark01(-41.18422956301649,-11.376712350199611 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark01(-41.192640120542954,0.3531874792714036 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark01(-41.21858736246067,-56.793048979442794 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark01(-41.25805923261413,-25.77918290373773 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark01(-41.332380117354376,-15.103155693782682 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark01(-41.335721674511156,-14.471546800659326 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark01(-41.37372975428992,2574.909040560197 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark01(-4.141592653589794,-100.0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark01(-4.1415926535960645,-7.485039847856712 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark01(41.45717155667117,-73.82709657212123 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark01(-41.496836590011775,0.0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark01(-4.151113292388825,1.5707963267948966 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark01(-4.152949225644632,1.5707963267948966 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark01(41.567287583831785,-69.06962417826159 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark01(41.572275025590024,-8.178772387945788E-6 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark01(-41.605537455092275,-1.5707963267948966 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark01(41.60937019927715,100.0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark01(-41.66763704698944,0.0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark01(41.70926560158683,-0.03707593858059915 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark01(-41.81968944944712,95.620994763991 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark01(-4.184889559453967,4.71238914604469 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark01(-41.8603764035399,-7.853981633974483 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark01(-41.95433277477278,-17.204305157065892 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark01(-42.0244231318241,-1.5707963267948957 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark01(-4.204178898398709,66.67606960693351 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark01(-42.09472655346043,1.4915064401567497 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark01(42.14437974738112,-74.74689349025994 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark01(-42.179481291227326,106.88618558779675 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark01(-42.18031296391829,0.0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark01(-42.368051625985025,-4.946781130444 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark01(-42.4018009169751,-41.21872108135412 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark01(-42.40899908870724,-86.39379764192412 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark01(-42.411002288135094,1.5707963267948966 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark01(-42.506016937002656,-1.5707963267948966 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark01(42.512753810173564,-56.181945505372525 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark01(-42.53650082346221,1.5707963267948966 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark01(-42.56008638064867,96.22094134939532 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark01(-42.57064325691505,10.5203804965914 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark01(-42.581679344249935,55.95964721755354 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark01(-42.61844958979884,0.30567675500847186 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark01(-42.61864698600079,7.1045073061295945 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark01(-42.63467672891906,1.5707963267948966 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark01(-42.68631349087147,0.16484650244369448 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark01(-42.71158015449716,-54.891280497965546 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark01(-42.82455269503578,44.60624555829622 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark01(-42.82882695086474,-1.4848667091647376 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark01(-42.829664285726345,-68.6998320316772 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark01(-42.86882966570064,1.467849820565022 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark01(-42.87340657828468,1.5707963267948966 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark01(-42.90147237318764,-98.3339356599439 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark01(-42.95386542670416,67.68824867863056 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark01(-42.95504640704671,98.32870416932724 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark01(-43.0756986733445,1.5707963267948966 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark01(-43.12202296121921,-1.3263918219693487 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark01(-43.17300779551292,32.79555494850021 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark01(-4.325273163468623,-0.22509746373147854 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark01(-4.3368086899420177E-19,14.137167062725409 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark01(-43.54718447328531,-100.0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark01(43.982297150258,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark01(-43.98230065526213,-81.68124631946537 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark01(43.98278543150711,0.0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark01(-43.98326907773529,36.12828415446916 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark01(43.98351963276585,-21.531947902791103 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark01(43.99841754234751,-92.31262722882863 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark01(44.016066637913426,0.028037503209026378 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark01(44.03095960113984,0.0015164541805410081 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark01(44.052489709655106,52.29221326136886 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark01(44.05345632369571,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark01(-44.09483313236784,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark01(-44.09634092835888,1.5707963267948963 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark01(-44.104941234305464,-30.30082128159981 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark01(-4.412051763071474,-10.553703649412487 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark01(44.121748274503354,-69.64860139312117 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark01(44.137312863566095,0.0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark01(44.17304388170285,0.2586949077531272 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark01(-4.42504536984043,-65.29059562167558 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark01(44.25395491871976,-95.81857593448869 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark01(44.30462124178436,-45.084737277832254 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark01(-44.30865659819079,1.5707963267948966 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark01(44.365469261948725,-187.60134996834887 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark01(-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark01(-4.440892098500626E-16,0.0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark01(4.440892098500626E-16,95.9575632437766 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark01(44.41510655963253,-1.5707963267948966 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark01(-44.47195961044279,-16.81646565660737 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark01(44.61070530321292,-1.5707963267948968 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark01(-4.4653361757790835,0.736711132101874 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark01(-44.71885719433884,51.29446830984671 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark01(-44.96875361334686,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark01(44.97631287937278,36.64013838562602 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark01(44.99022591823004,-102.11885534444697 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark01(-45.03086087610769,-11.010687265288542 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark01(45.062616438861525,47.25665067708874 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark01(45.065635999698884,-9.542766734093476 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark01(-4.513845246633068,2406.7503079054877 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark01(45.179312213601264,-93.10288362294841 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark01(-45.21295494495597,-53.10277620525261 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark01(-45.22955832179909,-42.37080746411335 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark01(45.25256094598785,-74.21551404662992 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark01(-45.34041834110201,1.5707963267948912 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark01(-45.37980659025437,14.429203678060674 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark01(45.41441513803167,44.37119722874474 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark01(45.46687692834992,99.80696212001334 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark01(-45.512088502755425,-45.553093477052 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark01(-45.54690436142241,79.65262693037081 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark01(45.55309347526563,-54.977867915588824 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark01(45.55309347705002,105.24329072866759 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark01(45.55840887445685,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark01(-4.569485469341096,-1.5707963267948966 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark01(-45.69716408423259,-21.858528693873367 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark01(45.70912115143767,0.114842119701561 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark01(45.72773355467091,-0.4462778174943455 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark01(-45.75082555855383,-17.88946429052818 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark01(-45.776874153212354,0.0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark01(45.78709424007255,-35.02866827237557 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark01(45.83201636699985,35.04795301629241 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark01(-45.858405498591125,1.5707963267949054 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark01(45.94078420769631,23.407564084253522 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark01(-45.96870549161463,53.11124660788457 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark01(-4.60095121237126,34.836306780273134 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark01(46.12311200732955,-52.646888861769646 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark01(46.14377333534841,0.0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark01(46.268615103899265,75.2840682837323 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark01(-4.632810710485147,-23.56194490192292 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark01(-4.632989489882775,-58.56305557997064 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark01(-4.633892647014861,-73.8274273592539 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark01(46.49329138453969,0.0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark01(-4.652726288511366,-1.5708001449699238 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark01(-4.653451227766853,-58.15071410095058 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark01(46.54626811995422,188.1009272458299 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark01(46.640751371541455,81.07459686476551 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark01(46.6849548379935,254.6765933152674 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark01(46.716779643793735,1.5707963267948963 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark01(46.760706128273846,17.278759598221953 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark01(-4.692335144465872,0.0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark01(-4.698293068116641,75.88272085642967 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark01(47.083323461040045,0.2857717107233607 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark01(-4.710173070042452,-34.96284676959604 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark01(-4.711810441214927,17.27875625407604 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark01(-47.123886285622326,-31.415994263976017 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark01(-47.123887026517615,18.849434400166455 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark01(-47.12388780821126,0.0017230283741722428 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark01(47.12389225248798,-1.4344268251506576E-4 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark01(-4.71492798507424,73.8274271224019 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark01(-47.17640482291347,0.0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark01(-47.195113885212336,77.61241396600943 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark01(47.20005787450852,-98.92660330034613 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark01(47.212282225687886,-88.14185613069344 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark01(-47.24585048185975,93.74936470036955 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark01(47.285322451595135,1.5707963267948966 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark01(47.476051909308126,-122.56164767115988 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark01(47.47678654929649,-81.32718312761007 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark01(47.47774974083348,39.26806618309965 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark01(47.48301583693444,0.0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark01(-4.756851852009277,-38.08896258886227 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark01(47.57826648451422,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark01(47.58415586921889,-38.43527117477314 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark01(-47.598860515741166,-100.0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark01(-47.63989603449521,-1.570796326794996 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark01(-47.7542090585352,82.5499399637387 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark01(-47.924097295394155,-2624.396627460112 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark01(-47.94664702834814,1.5707963267948968 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark01(-47.95843899881742,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark01(-48.22739840061115,1.5707963267948966 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark01(48.55273500086595,-0.020806241940497357 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark01(-48.61916381295232,66.15309030112599 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark01(48.655633443424534,-1.570796326794897 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark01(-48.65579756770854,29.112218301841835 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark01(-48.69465179468201,32.98673829570261 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark01(-48.694802322142245,1.5708001415146482 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark01(-48.69731597128037,-1.5707963267948974 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark01(-48.70370287668058,45.55309370630368 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark01(-48.70373252099216,0.43677036719331236 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark01(-48.71574014362696,1.5707963267948966 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark01(-48.72411310682727,-13.40129692691896 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark01(-48.73098104464396,-94.15758166014581 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark01(-48.743071588525,-87.15510364009451 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark01(-48.76428697920838,78.71781950898978 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark01(-48.76714574629193,-42.297182854712936 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark01(-48.76763913071089,152.8416736763561 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark01(-48.80529561997214,73.99365518357195 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark01(-48.83314686167692,83.03707380894303 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark01(-48.84267895055663,98.26720954541025 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark01(-48.88519052537778,1.5707963267948983 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark01(4.888732704623339E-4,-12.53221697939027 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark01(-4.890874847755271,23.867306057705065 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark01(-49.0182232566287,-158.30043277443744 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark01(-49.09551108711172,75.373523754362 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark01(-4.920001065734915,-44.55250410505798 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark01(49.22986752867553,93.48546093029907 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark01(4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark01(-4.931481091407349,-66.1203741886911 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark01(-49.62270359419416,-155.53074819183882 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark01(-49.715197072384164,-0.43975696601465525 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark01(-49.77468609211033,61.26105674500097 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark01(-49.778073167528206,-72.77935052453034 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark01(-49.80066382262255,-1.5707963267948983 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark01(-49.80496970488004,-93.09790845521945 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark01(-49.910263604307666,-29.581057894868508 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark01(-49.92185705758753,36.371370749076355 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark01(-49.94404055970038,27.24478468236556 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark01(-49.946125559419016,-79.55554936421935 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark01(-49.95008475216099,1.5707963267948968 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark01(-50.07435823025194,-89.51553511101879 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark01(-50.0798408079763,-46.42280861945345 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark01(-50.10597436967716,-37.12775391458693 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark01(-50.107350622182906,0.830586636742396 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark01(-50.11542839958983,45.17385209025512 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark01(-50.12376095341762,-25.596148869368932 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark01(-5.012878545006539E-10,0.0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark01(-50.13306093322237,35.58420945126262 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark01(-50.17398325449853,49.8346737195708 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark01(-50.19170133301439,35.74468135596675 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark01(-50.20488793661975,-43.994671657846354 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark01(-50.22790152567364,-44.32470164802481 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark01(-50.238329493887115,45.84382874749232 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark01(-50.244048556347714,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark01(-50.26548269615172,4.7123782527691525 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark01(-50.2654829375839,43.98473945516288 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark01(-50.265541102589616,-43.98230583744596 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark01(-50.2656045277492,87.96457940613631 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark01(50.29311250411004,-1.9026298598324843E-10 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark01(50.307329210701354,-100.8212403219111 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark01(50.43688701465254,0.004873871299566623 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark01(50.54935849098536,43.21518981826126 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark01(-50.58483794215118,73.90907111193803 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark01(50.591556267535736,1.5707963267948963 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark01(-50.640229542175895,1.5707963267948968 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark01(50.77721839429859,-0.5888833791299767 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark01(-50.8508453454632,-10.803586325147442 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark01(-50.881128377044945,63.105073625601506 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark01(-50.94626128430442,-0.217676486662846 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark01(-50.9537741045007,-1.5707963267948966 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark01(-5.097758017902988,-0.1912220980825149 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark01(51.040688700773586,-48.28333087845512 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark01(51.073416263334295,1.5707963342527034 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark01(-51.08530934928139,10.660601327687562 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark01(51.109002650961,-1.5707963267943263 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark01(51.11553518861629,-1.5707963267948966 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark01(51.11857897871033,1.5707963267948966 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark01(51.202425963440874,-25.17258901052162 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark01(51.207127112085175,89.53539062730911 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark01(-5.122201297312769,23.644844074418558 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark01(51.24379035349847,-0.05147943333578315 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark01(51.291973116122904,1.5707963267948806 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark01(-51.33745783087223,96.73983911016467 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark01(51.353092663226015,0.0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark01(-51.36768441665407,43.99781071697452 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark01(-51.36780149128896,-226.23707438065404 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark01(-5.141592653589794,-0.00924480512698421 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark01(-51.43349648821709,46.77920084712413 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark01(51.45216687369515,-0.14262997315314863 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark01(-51.45270664370381,-1.5707963267947207 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark01(-51.46532345556585,1.5707963267948966 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark01(-51.53525546397016,-16.814940539327594 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark01(-51.54192489271008,2613.7912729777518 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark01(51.57817092763807,40.217793021150115 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark01(-5.167273072529386,-2.5443637062924895E-5 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark01(51.796615425792936,2625.363466162529 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark01(51.833915351566844,67.54424138060142 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark01(51.83559085582766,73.82742416813373 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark01(-51.932477728646376,86.52296240108709 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark01(51.98047208889824,10.698940991434078 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark01(52.224369547145464,1.5707963267948966 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark01(-52.2689302405926,-157.60165849008777 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark01(-52.30227492819686,-14.852515268908164 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark01(5.243339694694839,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark01(52.81017599958389,15.110733119297564 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark01(52.85853195487849,0.005029570798287092 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark01(-52.876376010120985,-62.95954776355653 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark01(52.88082482597997,-2605.0077360967966 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark01(-52.960504498257485,0.01940519637283617 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark01(-52.978670711210164,-0.29606600791904536 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark01(53.002953195429356,44.901079539150395 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark01(-53.004783396715325,12.054028002309053 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark01(-53.03850268954402,-33.06308696426457 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark01(53.06930282063296,-1.570796326794897 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark01(53.083067974661155,35.56231455484112 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark01(-5.313157914921611,2.4726308601617433 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark01(-53.17686152530279,0.0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark01(53.24164458126404,-10.298021958571951 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark01(53.33883210697698,-57.20753724260956 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark01(-53.407052636652935,5.212386642402378 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark01(-53.40707172939038,-62.83134679417942 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark01(-53.40707449602805,6.221936084244605 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark01(-53.40707510525819,-1.5707963267948966 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark01(53.40707514160865,-64.41827439933284 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark01(-53.432407710563886,-1.5707963267948966 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark01(-53.51381113218404,93.51914331202588 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark01(-53.55383764741636,-6.435063288559534 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark01(53.57132755449837,65.54389358135504 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark01(53.61528333780461,-4.619456415088607 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark01(53.63197383812054,14.429581551348114 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark01(-53.69663947572669,1.5707963267949054 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark01(-5.377496921035785,70.5471862681677 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark01(-53.86733944639819,-45.37111550698957 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark01(-54.0232991941322,42.798612352846334 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark01(54.06233180678976,55.71413991596259 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark01(-54.15591306357585,-1.5707963267948966 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark01(-54.19895478841515,25.434124520798918 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark01(-54.24299203371703,-1.5707963267948968 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark01(54.41801766868116,0.0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark01(54.46354605311947,64.32658461286206 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark01(54.465228030964994,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark01(-54.475483055529025,-90.40214479861373 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark01(-54.47602617547516,-1.5707963267948966 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark01(-54.489793088442596,168.55165737980533 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark01(-54.58167433929437,24.1158195677706 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark01(54.73067354736741,1.5707963267904983 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark01(54.75098122718363,0.0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark01(54.795246436190894,-90.79148807576871 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark01(-54.9554867070839,6.123233996603049E-17 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark01(-54.975241597182475,-1.5707963267948966 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark01(-54.97787431462718,-1.5708001414972594 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark01(-54.977876080851,-32.98673812148189 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark01(-54.97792555956577,133.51774962739435 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark01(-54.97794101417256,-4.712385462278274 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark01(-54.978347367059904,10.995570939581976 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark01(-54.978548222270206,17.278756318150087 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark01(-54.98050127845961,1.5707963267948983 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark01(-55.07511953982396,136.56859661971333 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark01(-55.08951152278451,-1.5707963267948963 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark01(-55.114025848738926,62.07730049033324 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark01(-55.148228682539305,-139.33556611516215 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark01(-55.14978378666303,1.5707963267948912 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark01(-55.17714111687686,-92.2664240755124 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark01(-55.17821333438272,-10.545476668876475 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark01(-55.19835016238619,-1.5707963267948974 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark01(-55.20376171028339,-0.857598787573 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark01(-55.21821649025396,-2626.3971735069454 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark01(-55.27751456079769,-61.49829839309208 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark01(-55.297292101921684,-33.76951512109731 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark01(-55.30563479892745,-1.4507323379748045 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark01(-55.35980055378634,45.080485374453346 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark01(-55.418526395028906,-61.35673004242923 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark01(-55.44199692512961,-0.15905188634367307 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark01(-55.464605487214875,0.6856773317852516 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark01(-55.504229629812635,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark01(-55.51079534993432,2197.294303491778 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark01(-5.551115123125783E-17,-25.130111388079502 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark01(-5.551115123125783E-17,-3.692336305704617 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark01(-55.542284294773786,2061.8650270970666 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark01(-55.54293411423862,95.27069361578447 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark01(-5.56604000259882,51.320440698169335 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark01(-55.821673856859604,-135.1579806681261 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark01(-55.85556853154321,-84.93677758855733 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark01(-55.85979598577022,11.062424206865984 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark01(-56.01769223625425,-1.5707963267948968 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark01(-56.019587601575836,51.037053907379175 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark01(-56.02716121037598,11.88995808073918 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark01(-56.113095415183494,18.05807705365217 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark01(-56.11349375194525,-3.1415926535897927 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark01(-56.131438217266314,-77.76724489882798 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark01(-56.1667245399556,-227.2728729719784 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark01(-56.16680911331141,-122.88574270389998 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark01(-56.17939981767479,32.229200442468766 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark01(-56.18069312801526,72.58162180557616 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark01(-56.216180300173434,-20.092037500788244 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark01(-56.30010350114302,20.213888538231117 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark01(-56.30664844313847,36.496480718248144 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark01(-56.32685020998311,-57.22480309338663 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark01(-56.36861664159321,-105.24377410050066 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark01(-56.36989083873445,58.119464091411174 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark01(-56.39159734212858,1.5707963267948974 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark01(-56.39759075821304,-88.52035942807602 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark01(-56.4487043858862,-1.5707895472481233 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark01(-56.45213369404753,-85.63345117144337 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark01(-56.454900603433074,17.28982507102006 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark01(-56.463282568125436,-0.3134524088711702 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark01(-56.4687570369714,88.357554423357 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark01(-56.49582666115638,61.18790401124664 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark01(-56.5301800574312,-0.19530264889583437 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark01(-56.548667829312244,69.11764373033417 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark01(-56.54866839070203,0.0023824106037885046 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark01(-56.54867007841548,-0.001530323776011647 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark01(-56.54867056460677,-4.807740970413986E-4 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark01(-56.54868879397736,-6.283185618577035 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark01(-56.55257401461628,86.39379691810883 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark01(-56.55257703912783,-43.982297150852474 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark01(56.559056579827676,-95.03875094447065 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark01(56.57132058949463,-0.21324930373833195 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark01(-56.714138478030655,10.922585646023524 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark01(56.75110485051181,-1.5707963267948966 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark01(56.75727848600934,0.0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark01(56.83891032942546,0.07318734546666437 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark01(56.882497245165176,0.0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark01(-56.90408647555216,21.370681171449462 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark01(56.91746536078398,4.301283048244969 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark01(-56.95699891374202,2.4008223699784565 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark01(-57.005591489974684,92.89680841217003 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark01(57.10549067157595,-75.11510867927164 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark01(57.16948578157329,-1.570796326794897 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark01(-57.333880050235805,62.712981154554456 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark01(57.48170481844665,-61.45891323494447 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark01(57.580176349754595,44.42390995409347 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark01(57.63113984523971,-27.122608993944098 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark01(57.69041977542443,-6.511733903723396 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark01(-57.78093046279493,5.218739564555037 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark01(-57.8511930467823,1.5707963267948974 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark01(57.895553871375434,-32.29363634119997 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark01(57.949403442381964,0.0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark01(57.979026875897816,4.743638980385067 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark01(-58.07886346270366,96.71753630433213 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark01(58.08594135772467,82.39276235737522 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark01(58.11688762090194,-1.5707963267948983 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark01(58.11946409100072,202.6501285941875 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark01(58.25073855197354,-9.78533243976985 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark01(-58.39951601940301,0.0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark01(-58.50951339788031,0.49999916756260593 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark01(58.5186739582902,0.0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark01(58.56092024815072,89.6793759317994 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark01(-5.858964118527311,44.039770538892014 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark01(58.66352284844095,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark01(-58.844515760546884,5.127470858400402 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark01(58.87142246179695,83.2735310990576 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark01(-58.90955104566142,19.103597345484175 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark01(59.5293601644625,0.0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark01(-59.633150199281374,-55.69562023128562 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark01(-59.68799934756018,-61.26105674500096 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark01(-59.690256896006765,-50.26548245741936 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark01(59.69026041820605,0.0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark01(-59.71808900586629,-0.23645546129458447 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark01(-59.74344405809103,64.0255655663577 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark01(-59.88898235247187,101.83290542176108 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark01(60.059817792008005,5.296500589525493 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark01(-60.076815992551744,7.182050717144939 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark01(-60.0797552812004,26.619348659218748 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark01(-60.13554431970098,-18.83082998718932 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark01(-6.0258755266782345,-9.354107205124663 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark01(-60.29741902842763,0.5597466241955759 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark01(-60.313497365461146,-96.61678351328196 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark01(6.035468646827425,-36.369244854860085 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark01(-60.453556880010126,-2621.727589350684 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark01(-60.52274338152031,1.307364815082872 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark01(-60.53966922857399,-24.393663982976804 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark01(60.60509243808926,-85.40123487156698 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark01(-60.68158073336336,-71.64946162160352 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark01(-60.6841485282155,-1.5707963267948948 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark01(-60.68963700949844,86.55333991664035 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark01(60.70574699880356,-0.20760757094786186 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark01(60.70802835543878,1.5707963267948966 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark01(-60.70908492636728,0.0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark01(-60.748448459903706,1.570796326783679 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark01(-60.788116642376046,0.3472570452851927 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark01(60.83924229899617,-49.92360767443389 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark01(-60.91354169821201,99.13276759056237 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark01(-61.01543788814576,-58.33830376926835 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark01(-61.06530857554132,-38.39061221594819 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark01(-61.15969523632987,5.000156447205706 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark01(-61.25733132930441,-0.03405408886977395 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark01(-61.260422220952854,23.561943751113063 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark01(-61.27269390983865,-21.7907865778282 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark01(-61.4586849657113,81.93773947733712 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark01(-61.50722840369257,0.6935027954786379 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark01(-61.620337084294086,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark01(-61.632528243153864,-75.96147314502251 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark01(-61.81132660312725,101.76275273440196 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark01(-62.730758280582236,29.6532222323994 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark01(-62.790976274810276,-99.27516132728698 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark01(-62.81591919034195,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark01(-6.283185336983058,12.56898920271403 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark01(-62.83185499847776,-6.281423253313619 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark01(-62.83185508776674,6.281473955368883 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark01(-6.283185784016745,-1.5707963267948966 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark01(-6.2831859170661355,1.5707963267948966 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark01(6.283200593587654,6.289285542074352 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark01(-6.283200881167953,100.53015155232656 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark01(6.283210695071859,0.0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark01(62.83333411111198,25.078265616419223 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark01(6.283389207842196,-138.20973188742133 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark01(62.83886005428098,-100.0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark01(6.286089579095119,-44.36143435033555 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark01(62.87158690866555,-0.19930064046643048 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark01(62.87164496902076,16.016373373764186 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark01(-6.287376224632849,-6.0189030958238945E-5 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark01(6.2885968865341475,44.08639424433415 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark01(-62.89435307180213,-6.123233995736353E-17 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark01(-62.89435308215867,-73.82742735935955 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark01(-62.89435393610301,6.283185290013146 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark01(62.92335049825162,0.0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark01(-6.299607704634184,-0.9289374345792534 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark01(63.086132476456086,-134.70260582081318 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark01(63.12932016409595,6.429223317730497 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark01(6.314435307181073,62.65010718739422 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark01(-63.14988649220727,56.91002180227187 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark01(63.19353414040208,77.62941730897981 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark01(-63.19462942326888,32.49402607584226 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark01(-6.325696822172935,-6.4326074611733555 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark01(6.328284188433613,-44.28371654819365 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark01(6.328477613980667,43.35068568265145 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark01(-63.37266848603926,72.67600926759575 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark01(63.40310035462733,30.49185639194999 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark01(63.40730013281458,32.911218509557216 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark01(6.345705791182104,44.26685922199258 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark01(63.50233785114703,-135.55779058460024 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark01(-63.534117511424455,175.26096012624308 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark01(-63.54828921876418,78.26824567109844 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark01(63.64003422355966,22.56549669607415 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark01(63.669311199134086,1.2232065706091868 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark01(63.67926751555799,-100.0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark01(6.376784632235438,0.0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark01(63.77543763588861,97.20368086209851 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark01(63.86096078057733,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark01(-63.89177231856835,2637.707066084743 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark01(-64.0105837269326,0.0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark01(-64.01440120411097,0.0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark01(64.19047791725221,-84.21166741995938 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark01(64.19190818345612,0.0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark01(64.38019197053134,-33.94839953475174 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark01(64.40047357647487,1.5707963267955252 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark01(64.40074000703248,23.561943249298047 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark01(64.40186577529315,-86.39379477775795 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark01(64.46834723558163,2622.328137793625 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark01(64.6332437331896,52.37413155173161 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark01(64.76966005194024,-53.15686666559769 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark01(6.4917369596248236,-5.6280357870894315 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark01(-64.92732000527319,75.39081087025741 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark01(-64.93066818354606,90.02367128346705 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark01(64.94350618804503,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark01(64.96010532578869,29.484050380974736 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark01(-65.01841871512622,15.982434421137658 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark01(-65.05375080072818,20.2410542119853 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark01(6.512647748564419,-1.5707963267948966 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark01(-65.12995715210673,0.7507925206671944 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark01(65.13219389906712,-1.1696777484752943 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark01(-65.21496329661345,0.43172311854189616 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark01(-6.5229880847775625,54.04412221595433 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark01(6.533185307179587,-100.0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark01(6.533185307179587,-49.87612524080196 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark01(6.533185307179589,-56.99296162269303 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark01(6.533187483670155,18.27483801347955 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark01(-6.534932828808593,0.05219279568846564 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark01(65.39467211731983,38.35625344910321 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark01(-65.44535362386034,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark01(-65.46258997524555,15.213023530823868 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark01(65.52350527563759,44.102674872234886 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark01(65.55461999144896,23.061198615861926 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark01(6.556466439936843,-5.530868588992613 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark01(-6.556500311553066,-0.17942921154611727 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark01(-65.63285468770086,0.0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark01(-6.566706378810011,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark01(65.78578014690865,0.5592233098473699 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark01(65.81065258511327,20.841854557789972 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark01(65.82816765634948,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark01(65.88262034893665,42.58381324831187 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark01(-65.93618987934116,1.5707963267948983 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark01(-65.97334296232754,88.08959430051783 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344512450857,0.00239286246156555 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344559215001,155.50883635269474 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344572538564,73.82737804109425 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark01(65.97344572544387,1.5707963267948966 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark01(65.97344763220815,0.0017731364931216382 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark01(65.9734495402378,2.2037823829512313E-4 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark01(-65.98099153648816,37.82204833914314 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark01(-66.04881316412603,55.12741832122296 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark01(-66.07873426509647,-17.119815570562395 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark01(-66.09487861653292,-80.30083496313469 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark01(-66.12502342378846,-1.5707963267948735 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark01(6.615640275398121,9.36058440689149 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark01(6.621566614561452,-0.5706375464268901 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark01(-66.22337875806929,0.0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark01(66.25886185918793,0.0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark01(66.30688499882623,-0.06937610756971592 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark01(66.42345731884353,1.5707963267948974 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark01(66.45207352653222,42.93345770981733 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark01(66.58529880238703,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark01(66.60541309977248,10.652646667865298 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark01(-66.65231941493603,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark01(-66.65939812653251,1.5707963267948966 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark01(6.667396373706552,44.12575951009292 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark01(-66.67990021338053,-96.55512756598046 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark01(-66.7069212850852,-42.706310851806116 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark01(-66.73085123129073,14.42952142635837 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark01(-66.75565421540713,0.0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark01(66.91864385452257,-46.866658605985045 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark01(66.92972103544025,-35.271610097264286 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark01(-67.01037303768837,-90.3694624616403 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark01(67.32794713553281,66.92552508060584 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark01(6.748558877553793,-1.135787089527066 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark01(-67.54161272520278,1.570796328158047 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark01(-67.54163263067076,1.5707963267948983 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark01(-67.54424305825185,73.82742531846652 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark01(-67.5444666156316,45.553094788937585 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark01(-67.54552477264704,-73.82742469125958 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark01(-67.54687189281877,-1.5707963267948983 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark01(-67.61178001966238,-1.5707963267948966 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark01(-67.71464503360555,-4.731729748664324 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark01(-6.776263578034403E-21,-1.5707963267948977 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark01(-6.776263578034403E-21,-51.83652353304763 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark01(-67.77210755462559,-0.416616904784001 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark01(67.81340497862979,-67.23907819009005 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark01(-67.9069341507531,22.845760451279148 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark01(-68.00599712149749,1.5707963267948966 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark01(-68.01317978089241,71.10178067195244 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark01(-68.04051392260793,-12.449268770752184 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark01(-68.15731382326976,4.67779968813776 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark01(-68.18648614210248,4.912977831963491 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark01(68.55378531757194,-32.10855362154905 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark01(-68.86109644162198,-20.306808145688237 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark01(6.899497734028344,17.714376770632615 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark01(69.11699150397546,0.0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark01(-69.11699150397547,61.2610567170477 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark01(-69.11699150397567,6.224006071225761 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark01(-69.11699152792505,32.99062911467361 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark01(-69.11699164640898,-4.7123889797598295 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark01(-69.11701785557987,73.82740328315421 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark01(-69.15651286046833,-32.50159324773791 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark01(-69.2308315059057,106.83569992652136 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark01(-69.24779421725893,-136.17462979879303 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark01(-69.29278973215224,0.0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark01(69.37307251245493,2.6076010309317894 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark01(69.40847575922879,0.0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark01(-69.43047380128262,-1.5707963267948966 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark01(-69.43047757140515,49.15623428465352 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark01(69.44010836026746,-62.464140785433386 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark01(69.44457820242108,19.677498791970226 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark01(69.4625639045076,0.0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark01(69.49045629887951,-36.22770185558851 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark01(-69.54823435722359,-12.033116300224776 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark01(69.56286695046619,-0.568795657920191 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark01(-69.57751111812955,-64.63733992830967 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark01(69.60341965099909,1.5707963267948966 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark01(69.6047214887527,22.694684519579795 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark01(6.960731102902301,-91.91527168173181 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark01(-69.65905169180905,-1.5707963267948968 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark01(69.71926790143701,68.63127193317314 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark01(69.74951436780381,1.5707963267948966 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark01(-69.76573113951545,-66.42533983283509 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark01(-69.76955089023593,0.0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark01(-69.78365497818967,-2626.122584974599 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark01(69.8726794628407,-1.5707963267948966 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark01(70.04216451996089,66.25791980186318 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark01(70.07514826066657,-1.5707963267948966 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark01(70.09231815506824,42.41173385254007 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark01(70.2556401640575,-86.39379834320818 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark01(-70.33598302108545,-0.5051877916323294 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark01(-70.43188012675259,27.71927667055612 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark01(7.045373702917801,47.36347402681411 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark01(-70.53825341357904,0.46496743437012694 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark01(-70.57695283587017,1.570796326794897 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark01(70.60416290516586,0.49129889824458195 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark01(-70.67093373569867,-45.0838768804561 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark01(70.68320486513144,-1.5707963267948966 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark01(70.6832048651321,-1.5707963267948983 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark01(70.68345054688147,-14.137167563030772 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark01(70.82299408517599,49.71852021983747 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark01(-70.86168615562454,-3.1421456344358063 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark01(-70.87435286083422,1.5707963267948966 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark01(70.87439385456082,29.427228805200627 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark01(70.92268225510608,42.62044735888526 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark01(-70.93116486359044,15.275058075142951 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark01(-70.94397423032507,0.0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark01(70.94668719567977,-71.76354103640803 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark01(-70.99496369367534,0.0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark01(7.105427357601002E-15,12.583493862841408 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark01(-7.105427357601002E-15,4.9099075227418325 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark01(-7.105427357601002E-15,84.47393984225647 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark01(-71.06702688530636,-37.707773129085226 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark01(71.11455477640054,92.76760860402746 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark01(71.14922897450907,-22.455208630162588 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark01(71.36077509608249,-63.65247895061585 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark01(71.41449702034694,-77.23497404628851 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark01(-71.4964281651749,-75.39822368615503 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark01(-71.56670207784671,92.11162523698576 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark01(-71.56918918345727,71.57687226623696 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark01(71.59282412468289,-17.536745831243337 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark01(-71.60841834347478,2710.14913014651 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark01(7.163500336907505,-55.29768793077652 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark01(71.70506851506639,12.416005047797626 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark01(7.1811859728249345,-69.20300709480307 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark01(71.84904676322782,0.0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark01(-72.09433760179226,1.5707963267948966 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark01(-72.25646861207792,-6.203908512131394 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark01(-72.25662751032579,-1.140793354381979E-9 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark01(-72.25662756436587,-18.849860603705803 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark01(-72.25662809401123,62.83290926159954 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark01(72.25663103256518,0.0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark01(72.25711931381525,94.24790852259657 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark01(-7.226723860028599,1.5707963267948966 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark01(-72.26868509981699,-0.15880652322597089 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark01(-72.37419453136428,2601.779642448989 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark01(-72.38163103256525,0.0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark01(72.41495424726084,0.0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark01(72.42532941302538,0.8390227026803032 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark01(-72.47999031158413,43.303762516422324 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark01(-7.251352950947563,-86.79493247419228 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark01(7.254890599081948E-11,-96.49183956580622 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark01(-72.58701028588715,95.07680015609274 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark01(-72.62974212179971,54.83749228706934 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark01(-7.273714976880797,5.040307165249485 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark01(-72.86667808791032,-2641.3240004781746 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark01(-7.287472258593141,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark01(72.9628779232969,-14.915788771127978 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark01(-73.00396489720127,100.0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark01(-73.03181187705046,-20.11549738328986 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark01(-73.074633339704,-1.5707963267948983 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark01(73.0782296800677,-81.41389125901453 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark01(-73.08114991384112,30.291995672025905 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark01(-7.310545281743845,0.0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark01(73.14675989993657,1.5707963267948966 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark01(-73.17641321113462,7.040327714776684 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark01(-73.19040261994377,22.898900323513132 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark01(-73.34302366344889,79.96336241896503 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark01(-73.41788058761963,64.4859099280262 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark01(-73.50640505559404,-43.05766749147828 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark01(-73.56583446978317,68.29516652458537 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark01(-73.62081628512875,71.80743827230634 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark01(-73.66844072328956,45.39252933129923 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark01(73.81959997098355,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark01(-73.82479751872188,-1.5707963267948983 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark01(-73.87188302619406,81.65462332389308 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark01(-74.00888520112491,-0.03377085158761872 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark01(74.17118600198091,-64.58779765442489 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark01(-74.2432633790576,-87.81289210803811 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark01(7.433419885805719,3.699361203689021E-5 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark01(-74.45033669639302,-0.2881933534497291 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark01(-74.6725390686582,-0.19884788606176163 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark01(-74.68927811747506,-52.49193935357559 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark01(7.474492132808393,1.4995902067986449 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark01(-74.81443242911656,62.534302382766356 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark01(-74.8349194428566,-158.16664623178866 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark01(-7.490670018373464,-27.1300852859037 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark01(-7.52558887482319E-17,1.5707963267948977 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark01(-75.3906849779425,-0.4281129383443717 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark01(-75.39822368612884,0.0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark01(-75.39822849319943,3.469446951953614E-18 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark01(-75.39920235835453,0.019492789885399004 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark01(-75.40212994295919,1.5707963267948966 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark01(-75.46780260084672,-1.5707963267948966 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark01(75.47208524561475,33.051974049139304 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark01(75.51641336653067,-14.429205172651052 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark01(75.52778610226402,0.3565811261373417 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark01(-7.562692914645003,1.950664229831385E-4 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark01(-7.563552716228401,91.54188267588742 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark01(-75.64260408498913,37.69650315483105 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark01(-75.78880984969685,-83.56246902579994 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark01(-75.87943740526508,35.5987607739103 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark01(-75.88795802465262,15.5241898016464 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark01(-75.91649587631949,-1.5707963267948966 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark01(76.02883190499702,-1.5707963267947918 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark01(76.03293304015531,38.85735108993242 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark01(-76.04815372403499,1.5707963267948593 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark01(-76.05957055318598,0.0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark01(76.14550584778722,1.5707963267948966 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark01(76.14570433317238,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark01(-76.18168020042499,-54.97878018437959 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark01(-76.21213733110608,0.0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark01(-76.21835767555937,-1.5707963267948966 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark01(-7.624687330942294,-1.5707963267948948 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark01(7.628051052448598,-1.5707963267948968 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark01(-76.31846143877593,88.50853341010546 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark01(76.32102648365776,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark01(76.32740685900937,-41.41802175787994 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark01(-76.33459800718659,-38.15481695508887 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark01(76.36035496400729,-43.1401116232786 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark01(-76.39092553648868,59.812719046751475 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark01(76.45129472342185,-70.55440387707677 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark01(76.48591879305502,-51.55160071474044 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark01(-76.57143120315162,37.66663616271714 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark01(76.573769487054,-2519.1676856668696 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark01(76.63401006170588,-1.5707963267948966 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark01(76.66971753396464,-45.301903178627214 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark01(-76.68894540039301,-1.5707963267948968 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark01(76.77892765256377,20.144411629548785 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark01(76.81200859155436,-1647.610441051776 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark01(-76.85006023851307,-14.429363228141746 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark01(76.88670550342242,2560.8405288125573 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark01(76.96502302050577,32.55379809885568 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark01(76.9679866440946,4.712387433390554 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark01(76.96902001158172,95.81857974918728 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark01(76.96928619737601,-1.5707963267948966 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark01(76.99428590567246,86.58505105727437 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark01(76.99678530408569,0.8620555076734326 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark01(77.00663122338315,4.452546338910853 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark01(77.02666612289353,1.5707963267948948 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark01(-77.05119397736837,0.0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark01(-77.09849189637852,167.88582022284248 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark01(-77.14856140748033,69.87529831334837 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark01(77.15728241054902,-88.20106733703055 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark01(-77.19260359261781,0.008358882064220257 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark01(77.20460836818133,-22.316788395718618 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark01(77.22362184417729,114.6702073841233 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark01(7.722407793920841,25.65679956824342 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark01(77.2536902776717,73.69872490891001 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark01(-77.2561719728943,0.0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark01(-77.27629290789714,-48.730735470053155 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark01(-77.29161524811745,46.743632138614366 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark01(-77.30567490206084,0.0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark01(-77.32173562925523,-1.5707963267948966 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark01(-77.34654535956298,-6.4298586683776735 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark01(7.735023801071179,0.0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark01(-77.3656614372066,-12.590938849599326 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark01(-77.36611540548222,-1.5707963267948966 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark01(-77.38099863040148,16.075472779313763 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark01(-77.40393958421537,-0.279668776449299 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark01(7.741826343946599,-0.3420652974400237 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark01(-77.43144171503818,84.02018342581664 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark01(-77.49139957524059,24.277819124634906 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark01(77.52786007523525,31.615339737503437 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark01(-7.755640582973996,-5.1092858394874 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark01(7.774448834604504,-23.561944901387168 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark01(77.74860791278635,-45.31826954327573 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark01(7.77530859945891,-10.995573702560764 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark01(7.775460593221986,4.712388980384082 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark01(7.775809559059353,-45.55309428497097 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark01(7.776178594543986,-1.5707963448131192 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark01(7.793205340842978,-1.5707963267948968 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark01(7.793445228611266,-61.26105652371284 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark01(7.793641497126843,48.69468612950166 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark01(7.794250962542579,-1.570796326794898 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark01(7.794326019804601,-4.712388980384669 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark01(7.794384875328114,73.82742717127094 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark01(7.795040488792339,-1.5707963267949017 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark01(77.96750941367402,-20.20704118753416 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark01(-77.98037421866653,-34.305816407573644 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark01(78.00039876241237,-1.5707963267948966 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark01(78.00906550650998,-1.3371400383299488 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark01(78.01518791485712,31.511048257896377 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark01(78.02047491717448,0.2431488354063297 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark01(-78.05135224056775,-27.557472529107773 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark01(78.08992371621034,48.951870476528825 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark01(78.09289137624066,18.84955592153876 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark01(78.09611418371318,-35.16502134419286 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark01(78.13145106353795,-77.38229493060604 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark01(78.17421448258746,-136.0906535016967 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark01(78.19692314595122,42.42317334758299 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark01(78.22231776157558,1.5707963267948966 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark01(-78.22940476829163,-32.67246615234727 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark01(78.24203163280694,-68.3289193454454 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark01(78.24761464979966,-20.61553004296468 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark01(78.2491213403681,-88.43550566718407 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark01(-78.27366423889644,-12.839142673489043 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark01(78.29348666355419,-7.179487990847541 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark01(78.29389991419293,-1.5707963267948983 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark01(-78.29792081579791,0.0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark01(78.32125522551175,0.0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark01(78.33062276364697,-78.29402339001274 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark01(-78.34324779396306,1.5707963267948966 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark01(78.36028196767225,0.6068849750889598 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark01(-78.36549914540845,-129.3950368795422 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark01(-7.84402443269245,1.570796326794989 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark01(-78.47926100872239,31.94748314994171 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark01(7.853132193571548,1.5707963267948966 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark01(-78.53942087086743,-17.278759594743857 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark01(-78.5398133180429,-12.565395836612419 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981416851393,-37.70073131262393 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981455844507,0.0018416630543273476 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981573374467,-6.204658242092527 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981622149942,-39.269908170423086 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark01(7.853981633974483,0.0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark01(7.853981633974484,-1.5707963267948966 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark01(7.853981633974485,100.0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark01(7.853981633974485,-1.5707963267948966 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark01(7.853981634352327,-124.09282387977785 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark01(78.53981721979075,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark01(7.862514663847769E-33,0.564975733179773 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark01(78.67495468535469,-18.47713174899323 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark01(78.71132376752209,0.0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark01(78.71283785467435,-1.5707963267948966 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark01(-78.73429367174049,0.0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark01(78.83861314345822,-67.54424205218058 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark01(-78.84584263371178,-0.12695223935981892 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark01(-78.8732499699226,-92.10328776643564 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark01(-78.92394531285618,22.77664127455415 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark01(-78.95742080011905,-81.53604872426068 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark01(-78.98579584606634,-9.096808101484552 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark01(-78.9902121393608,-0.264955123488507 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark01(-79.00920567674991,1.5707963267948968 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark01(-79.15849733473159,-13.703678807223035 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark01(7.940734155699204,-1.5707963267948966 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark01(-79.42676329557938,14.442535968455076 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark01(-79.44154765472632,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark01(-79.61731564187062,35.58351126793903 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark01(7.9715658834398795,-17.9284421193112 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark01(-79.7396115681928,33.11818118551284 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark01(-79.7494855164988,-80.33727307925639 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark01(-79.78798301311146,-1.5707963267948966 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark01(-79.79853943945216,0.0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark01(-79.82538485518137,55.65913808280277 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark01(-79.89485056979399,0.0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark01(80.038822201101,37.436065381154975 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark01(-80.10844517206053,-4.7123878601599225 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark01(-80.11152849618048,-1.5707963267948966 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark01(-80.1118220272238,17.27875683344213 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark01(-80.11324250717865,1.5707963267948966 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark01(8.013963417564792,80.12321786443516 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark01(-80.25546265829104,66.12856638996999 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark01(-80.31066976718466,4.747111913541889 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark01(-80.70732374363004,87.94368164036797 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark01(-80.73973910739869,-1.5707963267948966 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark01(8.101102543540534,0.0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark01(8.110521241720242,0.48816420819817125 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark01(8.113125595914408,-73.3183686018536 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark01(-8.121384803437832E-11,100.53472892143554 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark01(8.12576882841326,1.5707963267948966 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark01(-8.132550025740258,72.69735630005334 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark01(-8.147056892160185,-30.78894268084599 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark01(-81.56388739240646,-74.90910795964523 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark01(8.158353030011455,0.0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark01(-81.68121164041966,0.020365410333986866 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark01(-81.68141060174621,-81.68334111602177 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark01(-81.6814121898451,0.0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark01(-81.68143951091275,-1.5707963267948977 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark01(-81.72896758857678,-98.223901492378 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark01(-81.73618896808964,2579.205553331328 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark01(81.75453008784294,-144.12864955018972 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark01(-81.82032472327887,0.48940713476707176 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark01(-8.184240306160262,24.398978590202685 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark01(8.185871789152102,0.0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark01(81.88950297986761,-16.682824494368177 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark01(8.190420778339771,-1.5707963267949019 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark01(-81.93014676264427,-80.11061266653972 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark01(82.0828983931288,69.29609629600955 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark01(-82.14021789264604,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark01(-82.15016724036057,-42.797155295118 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark01(8.218916446687771,1.570796326794877 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark01(-8.222733463717635,6.432046166423491 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark01(-82.3384610777874,94.7249877638775 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark01(-82.35998326980524,136.38407783772823 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark01(82.37123257864971,-15.525699109328599 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark01(82.39009116291581,-22.07479753766725 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark01(-82.39320740457347,38.7778360610977 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark01(-82.43513638614863,-36.43060127828362 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark01(-8.254168501362443,59.781322165150584 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark01(-82.59570575168105,-59.04071249741083 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark01(82.64403347394372,2628.3956627423318 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark01(82.6934028652961,1.5707963267948983 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark01(82.73840456481801,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark01(82.8595169692899,-48.45706822000781 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark01(82.92311504326607,96.65473455024733 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark01(82.94938334404983,76.93520297701912 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark01(-83.07354576005909,-34.17185026524528 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark01(8.319762472733927,47.06933095930342 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark01(83.2509042808609,80.11061150595164 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark01(83.25220532013098,205.77300133608182 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark01(83.25220532013192,-130.37595872292056 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark01(83.25220532019792,127.23474807243387 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark01(83.27070844779206,-54.28034807631732 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark01(8.334982893396765,4.837388980384691 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark01(83.39397682051843,43.4124304605162 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark01(83.44044917755828,0.0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark01(83.44100131056487,23.03810325640079 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark01(83.50220531997998,149.25690153589642 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark01(-83.55840273955391,31.86005167478362 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark01(-83.76515682596755,1.5707963267948966 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark01(-83.8863372787342,63.06310189002794 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark01(8.389465566494245,85.93703969334283 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark01(83.95121772219917,4.440892098500626E-16 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark01(-8.397571591503493,-44.10052261348146 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark01(84.10056402020965,-0.3799551013259342 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark01(-8.41516116398519,45.321728742270196 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark01(84.20430050299609,0.48988471727617944 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark01(84.34330470103666,5.281032645507867 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark01(84.34773440475988,-1.5707963267948966 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark01(-84.39795172180015,2625.5504946669507 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark01(-84.40765620642443,-1.0908021987812333 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark01(84.48944764984572,-75.39822368615503 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark01(84.51737632525905,83.26832477377363 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark01(84.54167894503246,68.51871014375573 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark01(-84.57048806186805,2430.9506951789886 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark01(84.58432587199664,8.374384862892779 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark01(-84.63149633013703,205.8527234669172 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark01(-84.65211955672581,-76.94136130165704 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark01(84.66457399393872,0.0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark01(-84.72040092111453,82.99659972713147 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark01(-84.77871346612169,14.16863487645908 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark01(-84.78547636098075,-38.18056391227573 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark01(84.81506337402286,23.343864833607768 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark01(-84.8229035128797,54.97787143782137 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark01(-84.82299812468493,0.0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark01(-84.82299935447725,18.848187996104127 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark01(-84.82299985699117,-6.22312890689888 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark01(-84.82300163084177,-124.092909815414 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark01(-84.82300163817419,-87.96335571274237 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark01(84.82300166339779,-48.694673499502336 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark01(84.82300234803989,-31.418140419880423 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark01(-84.83908502787858,-1.5707963267948966 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark01(-84.91839188234557,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark01(85.03073267173025,99.15514803675453 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark01(-85.05467953140224,1.5707963267948968 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark01(-85.17606929127388,117.91806287538212 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark01(-85.39619425967288,-76.77150175125651 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark01(-85.62648250509392,0.0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark01(-85.8387985543728,-1.4798045153278472 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark01(-86.03698183545886,0.0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark01(-86.08500000412455,-72.90635263206342 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark01(-86.10670751234315,100.0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark01(-86.30382451734211,1.570796326794895 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark01(-86.34418578168712,-22.68273239438095 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark01(-86.3609335830932,73.59156162286915 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark01(-86.39179337219203,1.5707963267948966 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark01(-86.3937949486978,-98.96016528741471 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark01(-86.39379796590657,10.995570765324981 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark01(-86.39379797371878,-89.53545168240952 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark01(86.43053336735454,-21.734304617287975 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark01(-86.5071089031647,-10.711625619568608 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark01(-8.662130198533504,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark01(-8.673617379884035E-19,-1.5707963267948966 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark01(-86.83295197897489,0.0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark01(86.92997645921952,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark01(-86.9910518348945,57.94547061995706 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark01(-87.07636720784589,66.98981919846449 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark01(-87.11182728027782,-58.614620995669085 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark01(8.723793901193941,77.6072570491381 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark01(-87.35841464975466,52.63784866827342 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark01(-87.56021272109228,40.868198299329634 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark01(-8.778159937500387,-79.04871845657703 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark01(-87.96459758674521,56.5480048594446 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark01(-87.96460955986012,-29.84513020898824 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark01(-87.96557086301422,8.673617379884035E-19 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark01(-88.05192351104864,-1.5707963267948966 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark01(88.06097839277862,66.20428196966225 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark01(-88.17861344635757,3.8261225478470458 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark01(88.1995229668266,32.672368561044436 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark01(-88.20650697173622,76.12278987613212 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark01(-88.25767314321523,-31.701047493625552 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark01(88.38303069482578,-2.8449170435676905 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark01(8.855952104565166,26.224896572474318 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark01(88.61190596138674,-38.861710287949656 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark01(88.63379397860021,0.6786371304570716 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark01(88.68605945772306,23.56664022549304 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark01(-8.868764132261498,-1.5707963267948966 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark01(-8.881784197001252E-16,-41.19604994543875 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark01(8.881784197001252E-16,-52.40028347930677 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark01(8.881784197001252E-16,-55.9028337611581 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark01(-8.881784197001252E-16,70.55640123039959 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark01(-8.881784197001252E-16,81.8361624657272 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark01(8.881784197001252E-16,-85.1407587063938 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark01(88.8916280786182,-24.007105950610743 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark01(-88.89524671724058,-70.16857813513735 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark01(88.96740364339192,21.380399525183222 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark01(-88.99433554056984,-34.58380720791823 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark01(-89.03467011354849,-38.67612410282606 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark01(89.1447437992095,0.0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark01(89.14903676640355,136.6519741538387 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark01(89.19244189914232,-62.19766540678407 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark01(-89.24415496887167,-21.340430265567846 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark01(8.927016800241134,-54.25242311138532 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark01(89.37537264326404,1.5707963267948966 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark01(89.50778662649967,-1.5707963267948912 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark01(89.53539062730975,-76.96902353518942 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark01(89.53539062745088,-168.0750853959119 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark01(89.53542430184201,-4.712388980364863 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark01(89.53543501529194,7.85401215175695 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark01(89.5356694571923,-67.54423857567302 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark01(89.53626088606858,1.5707963267949054 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark01(-89.53775252041798,6.4294204745719705 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark01(89.54103079928456,-84.54203368662797 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark01(89.543853745114,0.4985516855774919 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark01(-89.58208148536808,59.8750318890859 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark01(-89.59158110548866,1.5707963267948966 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark01(89.6173581609909,83.10012792718572 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark01(89.78178955891266,92.86461086675044 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark01(89.81352027091597,-1.5707963267948966 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark01(-8.988201018992317,0.0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark01(-89.90934097586009,9.717605464700824 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark01(89.94636519458935,1.5707963267949054 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark01(-89.97975701374024,0.0977344061260162 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark01(90.02993167382593,-11.451706386473031 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark01(90.05087497638326,-4.962388980384691 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark01(90.11439266870644,-3.8712828072721805 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark01(-90.25010093740482,92.67698405807303 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark01(-90.2561321616978,100.0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark01(90.5994578666083,32.872836126931446 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark01(90.61110605838752,-73.54682627815326 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark01(-90.63036619448314,-72.99804775867784 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark01(-90.6327884149976,52.79449926465129 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark01(-90.67361258063373,-0.07042362719030948 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark01(90.68489727442119,19.91133153572124 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark01(-90.71853583950436,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark01(90.72583365640811,0.0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark01(-90.75948804657199,1.5707963267948972 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark01(-90.81571964748359,0.0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark01(-90.82947179829075,-2.919057676560172 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark01(90.83067314135276,61.870792539763784 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark01(90.87751960287949,0.05580959492757837 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark01(90.88897795916395,69.78395341762577 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark01(90.917403104181,8.2700163998506 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark01(-90.98487140992506,7.342808840895176 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark01(90.995191299097,1.5707963267522518 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark01(-91.0290253115144,-92.17621372399196 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark01(-91.03528008806465,0.0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark01(91.04336955784393,-75.05621391639205 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark01(91.06734957100596,0.5168187144714033 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark01(91.10014529675227,-62.94184674461523 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark01(-91.106183434647,-5.3938786004375394E-5 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618362866715,56.54806447740789 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618379228623,0.0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618430138074,14.137167060433809 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618641914456,10.99557428756315 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618679630096,0.002097852477878386 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618689200477,6.223805904806525 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618690176044,31.417774737747145 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618695410399,1.5707963267948966 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618695410399,-48.69465880329492 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark01(-91.10667533381792,0.0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark01(-91.10671961481873,6.25045905836033 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark01(-91.25996533519576,-17.580800450796943 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark01(-91.33309235470648,-43.298273937034104 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark01(-91.43539919478374,-0.6840282929238496 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark01(9.166174778446031,1.5707963267948966 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark01(-91.68449179705968,-32.899246383179594 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark01(-91.7363221215191,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark01(9.184150983070007,24.423390388185577 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark01(9.188167629500475,-92.67698368375659 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark01(-92.37287656557369,69.6206842081287 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark01(9.239466406966248,-16.432297578201705 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark01(-92.47515683156185,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark01(-92.52186199858966,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark01(-92.52370689242197,131.73371910470013 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark01(-9.25436855449368,68.24502196421483 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark01(-92.6006635706954,-26.701098188551953 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark01(-92.67435344026003,1.5707963267948966 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark01(-92.67770781448998,-17.278756352776348 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark01(-92.67835174493865,42.411498271115995 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark01(-92.6796131215378,-1.5707963267948966 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark01(-93.08750765435781,2599.1828949681512 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark01(-93.21129150215619,-1.570796326794893 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark01(9.348909854801946,-89.4598705076177 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark01(-9.4039548065783E-38,-17.278759594694456 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark01(-94.23590841073555,77.65280186471807 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark01(-9.42477443860096,12.56636788370714 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark01(-9.424777167353017,-5.2123889750561005 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark01(-9.424777649663891,-81.6789100095921 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark01(-9.42477795908438,80.1106126663437 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark01(-94.24777960769377,0.0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark01(-94.24778723714094,-137.98192286459152 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark01(-94.24792553634516,-76.96920797125226 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark01(-94.27482470055043,-25.459676531207528 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark01(-94.2790296076938,-18.84932813330194 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark01(-94.27902977487801,-86.393797789877 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark01(-94.2813875334991,77.16435514728158 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark01(-94.3026933657323,61.629259460956916 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark01(94.3488581036524,-14.4292213097156 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark01(-94.38947066882788,73.82750433044836 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark01(-94.38997463929336,53.587925383144615 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark01(-94.43868517991424,0.0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark01(-94.44450038464407,0.0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark01(94.4669896814994,0.0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark01(-94.49802094368367,-100.0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark01(94.5577669227871,-11.143681845039339 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark01(-94.57871415609249,-82.78821198816345 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark01(-94.71544765153837,0.0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark01(94.88887478778688,-100.0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark01(-94.89913959241201,-1.5707963267948966 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark01(94.99332721914456,76.9243946949672 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark01(-95.01792944084839,15.769229203707496 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark01(95.02165356351165,0.0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark01(9.5028598018136,-13.225799925688463 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark01(-95.05737531155167,-55.420095640718664 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark01(-95.16504746724503,1.5707963267948966 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark01(-95.1721581861382,-34.91754884870491 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark01(95.18269317084687,67.4063675373744 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark01(95.2184851028643,1.4542219363959716 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark01(-9.524256468043063,-97.0164239918441 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark01(-95.34718217566311,55.92994268329096 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark01(-95.3734891547824,1.5707963267948966 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark01(-95.4341529617985,89.65430282153892 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark01(95.49299963078893,0.0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark01(-95.53146974627442,-48.068497573999025 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark01(-95.54147717608049,-1.5707963267948966 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark01(95.56640951656863,-1.5707963267948966 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark01(-95.62494989874219,-1.5707963267949054 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark01(9.564518761317068,1.0347948915962304 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark01(95.6611282455516,60.540989001653514 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark01(95.68452081810288,1.2345081135407984E-15 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark01(-95.72585887588392,-2.720540660269037 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark01(-9.57281305478694,46.78407710196947 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark01(95.80305672622495,-2579.793025328658 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark01(-9.581191894406487,48.72863082422231 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark01(95.81649316383626,-1.5707963267948966 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark01(95.81844132036042,48.694682620775666 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark01(-95.83285902946805,-75.98234408048708 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark01(95.99085267649883,-74.75548535271128 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark01(96.00488368309664,2.0707963267952865 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark01(-96.17350148939236,-78.41569108566406 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark01(96.1779268074985,-36.5246074136727 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark01(96.44543808304647,0.0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark01(-96.5261925888234,127.98973184185058 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark01(-96.53469726567407,69.9034289886327 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark01(-9.678080920726881,0.0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark01(96.78741560671907,95.55580184171856 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark01(96.90427731657473,-1.313846921449966 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark01(96.90528524761126,1.1433302400939311 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark01(-96.90608925944979,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark01(96.94971623342329,1.5707963267948966 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark01(97.03471016316774,-1.5707963267948963 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark01(-97.05125510389976,41.3957583423572 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark01(-97.15397663863156,64.22821342188726 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark01(-97.25654166307916,-1.5707924805562439 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark01(-97.38936578515406,-108.38497715589901 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark01(-97.38937225090879,-6.224216048502272 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark01(-97.38937225178951,163.3679582651846 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark01(97.38937232089188,-10.994432584022015 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark01(97.3971847612836,-1.5707963267948966 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark01(-97.43559759752047,-2632.706971010949 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark01(-97.62466848829641,-42.15740155621551 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark01(-97.67553945590224,96.62480973384339 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark01(-97.70172891386834,-60.14598819236405 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark01(-97.73058335576054,-43.120722613239025 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark01(-97.7440802778108,1.5707963267948966 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark01(-97.75426060411509,74.33060289006309 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark01(-97.80013170854065,-88.99272070213911 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark01(97.81734145740128,-92.73243441540018 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark01(-97.88455802127413,-0.4289694786942662 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark01(-98.06031064479724,-45.16515729719669 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark01(-9.81208457425599,-52.132927581610424 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark01(-98.14368631266623,25.78565121603242 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark01(98.1787252348577,-100.0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark01(98.20707807562485,0.0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark01(98.29004895153291,-2384.2763736049096 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark01(-98.38473425150646,-111.6882875318574 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark01(-98.39582471845716,1.5707963267948966 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark01(-98.43260045132438,1.9001707056881258 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark01(98.4819877883831,32.98672286269283 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark01(98.48647275587876,-1.5707963267948966 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark01(-98.4897059149207,-1.5707963267948948 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark01(98.55487563729278,0.32127166608945856 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark01(-9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark01(-98.65877995838073,-23.00599443469538 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark01(-98.7484067084981,6.417544406612824 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark01(-9.875352713568699,-38.427918022087624 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark01(98.8278135028711,-18.32104578686298 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark01(98.88914829383975,0.0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark01(-98.90683504038336,-113.3394560421548 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark01(-98.94752689522142,4.712465662332889 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark01(-98.95753874743963,1.5707963267948966 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark01(-98.95769710615006,-1.5707967345501084 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark01(-98.96016594018295,-61.26105323521252 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark01(-98.96016858807322,193.2058633734354 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark01(-98.9606538056109,1.5707963267948966 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark01(-99.0563500145364,75.05011881740259 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark01(-99.12258951715214,1.4218543298858546 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark01(-99.19247559289659,0.0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark01(-99.25991549094826,3.8126642761595235 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark01(-99.41044410607088,-0.006850751645423641 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark01(-99.42596561336221,-1.5707963267948966 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark01(9.94304115275861,-3.6792062851527874 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark01(99.47232790540329,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark01(-99.49289523041483,3.564137281926122 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark01(-9.953747885760649,-55.43358049384508 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark01(-99.71238041705121,-107.32953789437866 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark01(-9.972363482185003,-67.17127484412752 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark01(-99.93818129910323,-38.81282998506237 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark01(-99.99993350451983,14.429307668558195 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark01(-99.99999999999946,-1.5707963267948966 ) ;
  }
}
