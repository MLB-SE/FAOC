import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-646.0985373155311,74.13316895752091 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-646.8279152842447,55.47599773386182 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-647.2443967409796,42.1166540150451 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-647.4146198935146,38.20755637236303 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-648.2495884298337,32.56694288431132 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-648.253731835496,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-648.544376868211,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-651.6379852073042,0.352403520703648 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-651.9251581007427,100.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-652.2632284278247,84.45321921554559 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-652.5427759520526,13.521607702416926 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-652.6766460226378,100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-655.2884119689336,98.18891435135157 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-657.186223011047,100.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-657.3202672045322,100.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-660.2220886725381,67.0470070554276 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-660.5204164622775,100.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-662.8744084669798,100.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-662.9881607276149,100.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-666.4765127503639,100.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-666.857175559358,100.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-669.4157737757334,100.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-670.2297630029843,100.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-670.445508324075,100.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-671.0498042354734,100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-673.2302256755189,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-674.4181459524343,100.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-676.630460682363,100.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-679.1098300668101,100.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-680.3210667848037,100.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-682.4732785453413,7.105427357601002E-15 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-721.6568114272915,16.987521824887068 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark45(-100.343305697739,-682.8754852131443,2.8035477192194236 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark45(-100.62961064050896,-673.993401727733,4.663882686619971 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark45(-101.29954791327187,-653.2168521900118,62.47187622208497 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark45(-102.29743539613519,-652.8001710710685,91.5923250618963 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark45(-105.32019126081687,-646.3674770816426,63.94054381745315 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark45(-108.36299668375882,-641.1916385722018,24.588437666254663 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark45(-109.6635887928787,-640.4150562271234,67.59228881162105 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark45(-111.59101007397057,-665.0382226051138,72.64213613538544 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark45(-112.21121910606067,-664.9234729381188,94.3425410611899 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark45(-113.78911764304407,-644.6992231574114,30.626027404137574 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark45(-113.83612618636039,-639.2128150943113,29.174121070198566 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark45(-115.49353932939601,-643.3686701456103,18.05606666516077 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark45(-116.58643384887381,-637.0522321948453,45.41736004256103 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark45(-118.50401890720448,-635.1647957187031,49.20979097605772 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark45(-119.31192473872231,-658.4876727476936,82.2920084483141 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark45(11.976164328724053,-80.58688517924348,1.6129426517910588 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark45(-120.62234865965387,-650.8070196419856,100.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark45(-120.97962995124053,-693.517646012278,84.10068919388641 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark45(-121.98610515088541,-627.9939359972778,15.332564839548862 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark45(-122.23330360457052,-632.6427384771372,27.966647024210673 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark45(-123.05792328486312,-676.7262280528544,55.25310517664022 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark45(-123.57171042089645,-635.8430511591096,45.861702940708824 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark45(-125.10226874458883,-666.6069952157192,45.08687825751781 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark45(-125.28040972628622,-627.1478881816864,9.004008440783778 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark45(-125.4480493954258,-643.0066723931735,99.07907281213983 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark45(-126.84878660620075,-625.7995795204537,29.7820210654383 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark45(-126.85166955432655,-624.7751047823652,61.78663591150661 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark45(-127.13279384948319,-630.8924923320612,73.95053754513276 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark45(-127.25158448260032,-625.2158940461741,92.67431115195254 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark45(-127.5065969967615,-618.9852126826098,51.539135539653046 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark45(-129.13290031886385,-623.2465670779121,64.92319377050407 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark45(-129.7569338007526,-674.3056678881953,19.957960748443654 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark45(-130.55935955741614,-635.9541230615905,17.758246143739285 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark45(-132.465180224115,-617.7972310001459,32.614969893446755 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark45(-133.5218422259115,-631.9612073928711,74.58461938854418 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark45(-133.62696947445733,-642.4462102331709,6.591647924604089 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark45(-134.26778843160753,-637.9053745447322,100.0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark45(-135.18547055939052,-614.6569473048805,48.923373231632155 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark45(-135.4908677035714,-644.4574685797317,93.55361346239548 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark45(-136.2678141844571,-612.9776610759579,55.20716047234481 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark45(-136.4734152776554,-639.0905610964429,65.68913988377037 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark45(-136.48074052405568,-642.9648780946459,98.02836701079237 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark45(-137.10479645573963,-644.643847798914,70.53686411512336 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark45(-137.10623634086278,-663.6543069883884,67.74749732029244 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark45(-137.99078705773618,-646.2502102545567,93.50333542247733 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark45(-138.61674080751538,-641.4546850179626,97.36839439323091 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark45(-138.75294056706664,-660.1126247650624,100.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark45(-138.8154911531007,-630.3736833686926,62.80420766097268 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark45(-139.202325503103,-651.6551631892216,13.718331751191215 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark45(-139.22809812347765,-625.7705968598414,100.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark45(-139.28590757587256,-615.2452560836506,100.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark45(-139.55403659753964,-618.1513801141119,68.51685747123022 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark45(-139.6977330282006,-645.931089288759,68.87577911212571 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark45(-140.03333494474776,-608.2695008658378,71.67734515413545 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark45(-140.35332704824066,-662.4565013462008,100.0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark45(-140.7016584452441,-607.3413132219146,61.36820232627912 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark45(-141.88300946961328,-662.1159491334832,100.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark45(-141.93266241751968,-605.8577067273293,46.472702272581756 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark45(-142.22806567454813,-607.0964714129364,71.63991844959583 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark45(-142.27420319156374,-605.1106353612516,21.959501928262043 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark45(-142.92075970165715,-606.8936684641277,38.01481113804195 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark45(-143.04259935390695,-606.999574012017,100.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark45(-144.56333056981848,-603.8165265027275,89.14818383231852 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark45(-144.76668179673757,-613.8383837173417,15.300242446816867 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark45(-146.1394027631641,-630.4095386381572,72.60568206757773 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark45(-146.49973126009132,-655.8682743315643,10.898048992273559 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark45(-146.5646178424692,-610.2579704584995,100.0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark45(-146.63379956579337,-674.4425431164905,71.29411506034003 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark45(-147.17258908107917,-642.4118587203184,6.735902199702522 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark45(-147.48293086873468,-600.3846400335393,12.47138258219833 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark45(-147.52864040323254,-599.2469566765842,92.93829647764389 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark45(-147.55715161093852,-648.1329159591969,82.136302790342 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark45(-147.6083161831395,-631.2436655480709,56.21225358799907 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark45(-148.35028368816117,-607.778498857189,86.78194379448553 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark45(-148.35241386115786,-607.4855377257334,56.4061415035076 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark45(-149.0507843643923,-610.0101980729794,32.18992894034355 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark45(-149.3787387111492,-619.1981373582787,80.20428611090492 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark45(-149.41926292070667,-606.07037564719,71.4104669324891 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark45(-149.46855148668223,-614.312032669914,69.3764870454107 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark45(-149.55717120892405,-616.760317292619,1.8838807230718118 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark45(-149.58285586445183,-604.3016576391279,32.13750058734115 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark45(-150.59316779742764,-657.3334025064003,57.43629788631378 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark45(-151.69859662549163,-632.8323550737064,76.13498717886208 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark45(-151.84929926705135,-611.9025943729105,99.82943334016736 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark45(-152.0055010748544,-640.0949049198472,100.0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark45(-152.18201743801956,-608.0081830166802,44.25609593641943 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark45(-152.2296899912035,-596.9720080193647,100.0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark45(-152.33344445953958,-615.340023103757,100.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark45(-152.3689415668178,-608.9643502252129,65.29648110301315 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark45(-152.42318723695178,-617.8748807549465,63.78118280943647 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark45(-152.94131473704522,-593.0586852629548,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark45(-153.41319742295582,-605.6541388432481,80.23510507271146 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark45(-153.50856773473296,-647.7385506279121,13.90969262785274 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark45(-153.79149163110458,-603.7085017270385,92.96020578249431 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark45(-153.79288973409854,-596.4547802442809,57.3834994016818 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark45(-153.9894907090469,-668.0400946684875,100.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark45(-154.9166664989551,-605.5155154735202,0.3117473997234157 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark45(-154.92755657883816,-639.7231209096266,73.00859453642022 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark45(-154.97200130905026,-618.9975542699225,17.992062904518377 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark45(-155.04272959214578,-626.996051383906,18.67024425045271 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark45(-155.09068205716832,-606.5859643138355,92.26456647914534 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark45(-155.0994752728418,-592.1883367509836,66.35521861753801 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark45(-155.4633808297047,-592.3633003369312,61.8849864029838 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark45(-155.5277302077788,-639.6827319316558,100.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark45(-155.53821123948424,-633.3975421241187,94.4220177181527 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark45(-155.73474842480408,-595.78194570699,74.78136743097426 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark45(-156.74782498565477,-593.7882571383251,37.140087495803186 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark45(-157.03607631826372,-666.9552934658134,45.563453667193244 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark45(-157.22020440465053,-591.0338105229075,78.91533652714168 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark45(-157.51106276232252,-625.3120436845829,60.97661964351681 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark45(-157.67140129489684,-594.7856035740158,100.0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark45(-157.84675353104382,-625.4870552052588,54.55660027974233 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark45(-158.331245687172,-623.7896476253756,94.25451537349292 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark45(-158.62223362375073,-594.3743863093755,34.27400811181235 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark45(-158.73820438668884,-610.4407858499052,39.31286113437048 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark45(-158.78603388201094,-592.9040635205882,33.272466050921196 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark45(-159.26161491311655,-610.2233073511139,18.61940398340782 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark45(-159.9795848877911,-654.7335557451959,98.01541068564487 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark45(-159.9839650034359,-588.1048750557011,59.21085454124599 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark45(-159.99990582068304,-598.8247868627578,56.207323573494705 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark45(-160.11260937853393,-620.1277476164594,36.14189882484243 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark45(-160.17765463890163,-589.9811263758517,46.072520024387444 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark45(-160.2315760160893,-615.1617066810876,51.17225677282741 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark45(-161.4333205930228,-600.2981967008363,68.01279764865131 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark45(-161.8327175609084,-630.8411596911452,95.88652482663383 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark45(-162.05113428143142,-598.5559324038777,97.02196247512305 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark45(-162.19415267128497,-628.429790765241,96.02578316041803 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark45(-162.5785041098244,-593.2797992304168,100.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark45(-162.7169847031169,-611.7294032615316,100.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark45(-162.89195623819995,-590.515995602232,60.43368780808339 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark45(-163.06689889499197,-586.2074488073121,81.99785733989424 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark45(-164.16221721924887,-611.9022941621809,72.20303394923164 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark45(-164.58371866532036,-610.8845563232932,99.40998435608194 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark45(-164.99557971377817,-588.129344627916,61.53921727491786 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark45(-165.03793674895638,-592.5080467962698,8.857784842263712 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark45(-165.0982914042215,-588.0695191461846,100.0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark45(-165.18295887158345,-604.0433873221701,63.18039606577301 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark45(-165.23784723856096,-605.5977528211444,89.50066395112597 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark45(-165.49404722930566,-663.9327462640708,45.906354627302875 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark45(-165.858659507213,-591.253135468727,3.393789838408324 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark45(-166.46829552653256,-656.5558512499633,100.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark45(-16.694513413058615,-773.7322271190823,32.15577427796444 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark45(-167.37831084438702,-623.0133217370804,79.30584055242997 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark45(-167.83156968333518,-591.9601637387743,80.82045007919493 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark45(-167.83514862776758,-603.7369109535427,77.56256529699755 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark45(-167.93421191025539,-590.1732493413622,31.901424736525485 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark45(-168.02511169084244,-621.9755667772605,72.27492916707354 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark45(-168.0295209049093,-583.8079379273576,10.208319888001952 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark45(-168.03119681094074,-605.975264072991,60.777351762316954 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark45(-168.12196535381278,-585.4177055002831,55.55883703816878 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark45(-168.79507245272796,-585.3988730604652,78.4427649512418 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark45(-168.97367169657022,-608.1737229735802,5.17901994449106 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark45(-169.08751289542082,-577.9695010223008,13.665962118961023 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark45(-169.3372910203676,-653.8959573016984,5.429453577301331 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark45(-169.769216138366,-581.5627628053049,100.0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark45(-169.9713278758863,-582.9490186368547,81.91005105001096 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark45(-170.32363767177273,-613.3765043324191,28.10673067338294 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark45(-170.79027150090624,-581.5832519639868,60.155725028511455 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark45(-170.89632271722928,-640.8533559160239,58.769915697567654 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark45(-171.3348722480761,-587.7512900960428,3.224968463449912 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark45(-171.9720383322865,-597.1677153207758,96.80724147877643 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark45(-172.3575746635371,-573.6992421218382,100.0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark45(-173.49864648027585,-575.4978630945548,77.7264812313415 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark45(-174.0255150111672,-650.2618047135797,82.05770524153252 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark45(-174.46152109176805,-584.0024233621729,56.345826610862616 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark45(-174.53016706352025,-575.9200516889466,5.647755874019239 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark45(-175.03785775788091,-580.6914272538195,67.00445795149332 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark45(-175.14244035662892,-599.3833911443504,26.027240635924656 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark45(-175.36540477262915,-621.0042007935408,51.199384975863666 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark45(-175.39126321317895,-597.3895856726629,98.09505335656985 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark45(-175.52170440268006,-609.3629021506966,100.0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark45(-175.68452134641268,-579.9328569458851,37.45100852035998 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark45(-176.1717659484705,-584.5222931277211,69.6687016524991 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark45(-176.26591086500525,-570.1057017010402,74.35696314430265 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark45(-176.42552774343926,-571.6395058163729,56.75455240274826 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark45(-176.57316550131853,-573.391906355842,72.08528706813951 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark45(-176.71872809767305,-631.4917944064916,45.62602370719665 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark45(-177.1953717716471,-573.5668353945669,45.51225125341921 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark45(-177.35851968564367,-572.0394180577903,4.353510453889811 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark45(-177.97113218759947,-623.9301633843958,60.96173512300123 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark45(-178.0142033671858,-573.2347652149477,6.673762429982034 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark45(-178.7702886021859,-597.995999749799,52.54217434376355 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark45(-178.77102306168058,-575.6577715054831,13.6169568032537 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark45(-179.18334259048697,-586.7996029758891,62.42761895619563 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark45(-179.3988888726526,-578.2046131199675,96.90876807573292 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark45(-179.9362834828897,-569.1480344525991,98.95211540351082 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark45(-179.9670378209552,-652.9799505462605,100.0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark45(-180.04520848395572,-629.6125225772403,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark45(-180.12393534840706,-591.9662756968357,18.480379831191286 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark45(-180.29584130292375,-575.515674939551,37.53339873830882 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark45(-180.30218211522762,-577.4851599174101,16.76155191868341 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark45(-180.75040868908187,-581.4997612457686,5.158754127942718 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark45(-180.8028960447138,-607.3358482256305,73.8966382682012 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark45(-181.07299344557313,-597.6208447808375,3.4651658878559033 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark45(-181.52971126082937,-568.6481356418732,56.97747876893985 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark45(-181.58926039472757,-603.9552787498058,14.982600214371772 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark45(-181.87372160198288,-564.4048822578836,7.105427357601002E-15 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark45(-182.3733746473584,-568.9230810935654,91.00506182710828 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark45(-182.43080396116355,-639.8328778184007,100.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark45(-182.81355495490308,-578.77349901664,100.0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark45(-182.82482482409094,-569.6735223962079,7.251889723092788 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark45(-182.9708013864369,-568.3391035718477,44.20062133885497 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark45(-183.0221759193334,-563.283092092503,90.32831114383185 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark45(-183.0643732387175,-570.4970267001837,22.972282380517115 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark45(-183.3214237401627,-569.9664204804042,9.959684016824994 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark45(-183.49728652896135,-569.5064538824466,64.88719298157304 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark45(-183.65836605310108,-565.4364567762153,61.00173623546428 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark45(-183.9089019682758,-582.7835342914856,71.41998076924438 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark45(-184.00449724643818,-622.6145335050937,0.425040462199334 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark45(-184.38973213777052,-606.4538436162276,22.79278889618155 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark45(-184.46499532624156,-593.560830377364,21.65398038623256 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark45(-184.65471834245477,-614.540580194617,100.0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark45(-185.22533626577274,-568.5913620932862,53.67096814544999 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark45(-185.75519615157864,-621.8263234354577,100.0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark45(-185.91995887656458,-577.9898195350455,100.0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark45(-185.92065468052087,-567.2140293380155,31.0545004474763 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark45(-186.16532359694554,-576.5830903892172,77.97418794858976 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark45(-186.21913118968274,-583.8495921259325,89.89768337117425 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark45(-186.25826178015905,-601.4539029471617,100.0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark45(-186.3970068090531,-560.6477523329825,50.76785103114807 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark45(-186.6163375673263,-585.1071411632913,19.14717688130611 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark45(-186.68485305512587,-561.3317057757127,88.29198711231979 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark45(-186.76805423056456,-593.1466447474124,82.92546459052997 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark45(-186.9030761985292,-651.7471796441686,97.04073854800538 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark45(-187.45070505846883,-598.5199056454506,57.13396899552413 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark45(-187.5932089509244,-565.2913497573524,78.42777799282342 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark45(-188.00390237843436,-575.156076090155,100.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark45(-188.61143577675685,-596.9415829080906,73.93055920526947 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark45(-188.66530185096983,-567.5404453157224,19.3578512675477 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark45(-188.69297946184653,-590.1017601044894,25.564659759271663 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark45(-188.89135996224846,-598.0310748397445,99.35826041876891 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark45(-189.54531403233855,-561.9966232310454,1.494732886853555 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark45(-190.323694737198,-563.2055125011798,68.08326599246644 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark45(-190.4833826817714,-625.7016630583173,68.535103272838 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark45(-190.60773412527809,-556.6665090889625,100.0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark45(-190.690158289169,-559.3188237495449,47.37261969200483 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark45(-190.78042108900522,-569.8430070535202,12.077415805829943 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark45(-190.79711873318453,-567.2222974413734,34.45061522167822 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark45(-190.82527721588028,-583.6143868403486,59.77146000558838 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark45(-191.22189148720457,-618.6933221451741,85.06858615864499 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark45(-191.26571002957257,-554.9050504158104,72.43202887184478 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark45(-191.26833809997677,-571.1803225559959,21.88417063613099 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark45(-191.32048958029276,-580.8387519725703,39.10632129667968 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark45(-191.36240448655306,-600.0202432954615,92.9419211307862 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark45(-191.78130178009667,-655.6329176073805,68.11514959082547 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark45(-191.80790209906652,-589.2088436976088,6.573731448468386 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark45(-191.9480164921132,-576.2216873134663,69.50402221702862 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark45(-192.33607204120682,-583.7004218803171,20.731511450782293 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark45(-193.0730019467134,-564.4619116792433,30.927641293989723 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark45(-193.3860844425436,-661.8009729540184,81.57235995708928 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark45(-193.4358630781581,-586.1412195440257,100.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark45(-193.653285313367,-620.0124618661911,5.980600564232203 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark45(-193.9238210996506,-568.9547085740651,1.511396645725128 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark45(-194.3117225823334,-633.5277335348798,89.01315451401862 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark45(-194.5213600466248,-552.1051967005737,44.691517274393846 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark45(-194.5897191572223,-554.6741878840209,100.0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark45(-194.7706188396127,-568.8217068351356,100.0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark45(-194.8723990876081,-556.402481344092,80.43338076727105 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark45(-194.87901541350988,-599.7252235399177,47.08252855957059 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark45(-195.1124956768142,-613.4148368980714,23.735531478195593 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark45(-195.529734134115,-553.7739276020201,95.59927118239835 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark45(-195.75797813014233,-557.0834871947967,100.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark45(-195.76099304753362,-575.941492591842,64.6603776162182 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark45(-195.8624122600349,-616.7820115769315,92.76793225390804 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark45(-195.91575376001805,-634.1800221570733,27.51930393054556 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark45(-196.4762533664814,-587.9230613101107,75.8761903678762 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark45(-196.55922565113565,-577.6861937466747,51.233229130945716 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark45(-196.60806332748183,-580.7480214250262,100.0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark45(-196.70625561343545,-568.2416628476273,9.343062365657275 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark45(-197.24208674783452,-554.8696857610032,100.0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark45(-197.27678721539823,-559.5113805060774,100.0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark45(-197.76838507199597,-576.0640786662206,11.407657056067706 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark45(-197.87385894472618,-556.6988788174014,73.04553710105685 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark45(-197.99979807431043,-560.3365492593617,32.738703463776574 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark45(-198.06040110674087,-563.5251544943798,34.42807245365775 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark45(-198.18137804987668,-564.6715696477694,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark45(-198.51283291152274,-580.1253756958101,94.80956953337659 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark45(-198.8035655100426,-547.4271261955747,4.8849607686176455 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark45(-198.92028560333046,-580.6035841078846,100.0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark45(-198.94848638252964,-566.817721638861,21.59489879169965 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark45(-199.11869494001294,-600.5411754555553,85.00987999339543 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark45(-199.43417762191893,-563.3414248875828,71.73575005956579 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark45(-199.7984669014232,-572.6886584918454,74.77519240548366 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark45(-199.89763145922774,-646.1331295946591,57.94517730994045 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark45(-199.92747904122996,-561.3355688822357,100.0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark45(-200.3840291786506,-598.4059363353799,100.0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark45(-200.59086083673867,-609.4542354897474,99.70339301978035 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark45(-200.89945229923455,-545.9113209383873,76.73132491536526 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark45(-200.92297200523336,-569.0172477130704,93.70547058228277 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark45(-201.71135164014913,-554.066538137334,88.69554194517264 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark45(-202.03545589201414,-616.6288143412654,39.969063017008324 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark45(-202.08501498517737,-554.3053448124267,84.36457230774278 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark45(-202.42020284142862,-570.9339098362719,100.0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark45(-202.88901446304516,-564.0824813462148,68.59193156203403 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark45(-203.03933401773955,-549.0256776003462,6.06324918243584 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark45(-203.0451884207333,-572.6468175418086,64.57970417851067 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark45(-203.69832558595266,-616.1870202406169,100.0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark45(-204.62943717276104,-548.9695283706146,12.505890276757796 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark45(-204.63471649699918,-545.5397193007914,51.61313732653704 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark45(-204.68321228006045,-541.3690335988125,33.7410377084382 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark45(-204.75031683626034,-561.3931089326377,75.29415055694597 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark45(-204.82947578036791,-553.5045442897064,1.4011976499050434 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark45(-205.38806635603595,-552.419298343033,3.7665612749991624 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark45(-205.4208658971281,-591.0128635892872,30.76751459935926 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark45(-206.1539986609184,-549.6508028056651,99.93639950827014 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark45(-206.28711812556787,-573.3429002817713,64.52357764632484 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark45(-206.35585907762052,-557.4053345737352,24.198235410615126 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark45(-206.45212358391086,-541.701262576345,4.986306459948835 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark45(-206.91793836824786,-540.2145753377441,40.36782167572309 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark45(-206.92864347500478,-561.3697150981436,65.24748963831453 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark45(-207.71148100138814,-569.6815828064257,100.0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark45(-207.88294048571086,-573.9640154307315,100.0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark45(-207.9282548079001,-569.7522925657848,97.6006142167686 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark45(-208.20192935462052,-576.7932048590986,91.62722455139911 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark45(-208.4750875315705,-581.8600041125059,81.26867251830697 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark45(-208.64629113217376,-539.9453370888169,19.726772331494885 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark45(-208.64847269612198,-537.6602816796203,45.02410127971319 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark45(-208.67044938484278,-542.8475966109895,46.63234897750951 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark45(-208.8356132797702,-586.370970153082,28.679063558663017 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark45(-209.93531179508707,-556.4365059634702,58.02061378475443 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark45(-210.1337015027442,-539.4854869438234,46.58562252527804 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark45(-210.86677741605257,-554.9249561309301,78.74599261752832 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark45(-211.0142378703667,-590.2912456597662,100.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark45(-211.23426179205063,-549.3932557383104,9.847745792208912 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark45(-212.42963842714676,-612.7743740841929,100.0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark45(-212.50574020729624,-534.9869948704605,42.80992053869522 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark45(-212.55582501782635,-571.872399949074,61.29073055610033 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark45(-212.7749003340429,-598.4697927458227,58.780068885024065 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark45(-212.88553214613054,-599.8135494091317,51.23953757541369 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark45(-212.9161328806058,-551.7978948434405,28.50308339781128 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark45(-213.1574807128906,-557.0002053109702,48.25920474924018 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark45(-213.201564724999,-591.3457409338567,30.656437644148326 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark45(-213.59648242711205,-542.7656874925877,74.18432951011528 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark45(-213.7996056507113,-538.6286732074843,63.4926871397052 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark45(-213.85126898400867,-561.3283193923534,46.579130408946554 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark45(-214.03266413924007,-541.6871641362856,86.65955011466068 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark45(-214.34832359572934,-549.4327036415114,70.34240582167112 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark45(-214.46290107381824,-545.2740266734745,36.45346041310077 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark45(-214.5504012295625,-613.663877010843,4.592426327031916 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark45(-215.2180570326685,-533.9806793331788,52.43920436406373 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark45(-215.62298350067385,-531.0364686941818,79.92631146743443 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark45(-215.6346272445299,-567.6973062047005,100.0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark45(-216.258523720404,-531.8835363469635,76.40333931031806 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark45(-216.76461540258154,-537.9411305085137,8.193428482208759 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark45(-216.8233288716845,-533.8632120059127,100.0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark45(-216.8502369425788,-529.7261978880471,11.373249344641607 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark45(-216.8954856136909,-572.3147716094282,32.48233440662517 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark45(-216.93355121029043,-533.3276311758138,58.11256483021464 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark45(-217.89588326674362,-529.7138808728804,38.01522860761355 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark45(-218.0168386933849,-528.0081973991173,5.12953756774867 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark45(-218.09811629810548,-539.0518574785586,92.46288371225603 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark45(-218.11035788269248,-551.6024605073295,14.59331763969169 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark45(-218.4552814826323,-564.1059814136913,88.79878421077535 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark45(-218.6727998028977,-555.4541454345458,100.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark45(-219.09512939734722,-560.3190512669868,64.44020339808458 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark45(-220.0606474712563,-563.921616752866,100.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark45(-220.1278309250195,-564.0754720862637,70.00388477514358 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark45(-220.1407440470282,-536.4011919286269,24.960073295294237 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark45(-220.16388262168758,-548.1465158398476,76.46655167884191 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark45(-220.46818280601565,-603.455550744741,7.983269917714381 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark45(-220.70928847100643,-555.5718732755336,8.354276633836122 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark45(-220.82826639990714,-561.6112828095374,100.0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark45(-220.86515533498593,-568.1396099959372,24.805605612839727 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark45(-220.87238353055855,-527.6387544472645,74.86939345056763 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark45(-221.10949941813809,-533.4450040111112,83.4254294364913 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark45(-221.15374140251197,-555.9730599091699,10.943180980394573 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark45(-221.2783522307335,-608.5611430674807,72.13255627231769 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark45(-221.53264944166378,-581.052270059568,26.357938957598066 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark45(-221.561073681645,-525.4392938195734,96.7060721551291 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark45(-22.176466092183162,-730.1581300136921,61.93753972281439 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark45(-222.05282516414218,-528.0763570409277,80.116718823062 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark45(-222.34944378485721,-577.7765616943185,56.72600578081985 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark45(-222.3510752118081,-529.330103839993,95.29096466233696 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark45(-222.58271782957323,-562.8799166245925,5.836136415266967 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark45(-222.63671632835116,-544.4009957471709,24.593927371043918 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark45(-222.74152293658184,-539.0394829453307,26.22855939244421 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark45(-223.23282403055097,-537.222984691431,96.74473836412531 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark45(-223.78909522937127,-548.1887275558264,100.0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark45(-224.40463468704164,-539.8835329647055,80.16042441812428 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark45(-225.05537676811866,-525.7058727834917,59.351160406422196 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark45(-225.11304815409704,-544.7853816835146,91.11789564065549 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark45(-225.1649797030587,-538.2763144976759,79.27579646649514 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark45(-225.51253966165729,-540.2830212013879,41.70317941872429 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark45(-225.82789501114507,-577.3088119813286,58.06322014607272 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark45(-225.95275139954228,-536.6478324744082,100.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark45(-226.1468062574552,-555.8316873699425,34.3873997400041 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark45(-226.39523894859235,-528.6705869728509,71.70542828750845 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark45(-226.43396872100354,-567.2563039979399,49.94633244091324 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark45(-226.4653684668633,-536.4477780877376,27.318511112298125 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark45(-226.64937920774983,-522.5402407314868,69.05056477079108 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark45(-226.9369584589976,-548.3761960229122,47.8872034261513 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark45(-226.946138503521,-520.7910498713836,98.88834698412458 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark45(-227.27716650978448,-577.9459548633142,100.0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark45(-227.3024808475525,-518.8886025372057,87.64385278476774 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark45(-227.38950052792023,-558.8668349300002,48.210509312990865 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark45(-227.75109941324018,-533.1835194057317,100.0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark45(-228.12637950557678,-536.1271467284689,54.69309125660389 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark45(-228.2487187825897,-550.5605071379426,12.94421145001104 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark45(-228.49030812040166,-584.4379722439826,52.64270043388029 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark45(-228.52026631361457,-536.1944878514086,98.50927324476395 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark45(-229.23374397773392,-524.6476348288696,89.24748487290739 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark45(-229.38935404190843,-558.59579464873,100.0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark45(-229.66311169336961,-550.0127392205122,100.0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark45(-229.9408490619334,-539.5472914367639,88.33254015494796 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark45(-230.03142635500075,-540.5155550082176,81.9167289188317 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark45(-230.56011373978873,-556.2993261796707,21.424370038917885 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark45(-231.14315489814356,-523.2690068223806,100.0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark45(-231.15135306031945,-570.6330054401902,75.54658877910487 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark45(-231.24318109503824,-600.5038875215175,41.16575491529139 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark45(-231.38443115198766,-556.0366760938344,100.0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark45(-231.61599131772397,-555.4769664723549,43.96471412536468 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark45(-231.6424064101082,-521.623609512794,86.4446074044582 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark45(-231.6824123019157,-554.4552947652719,29.179831576975687 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark45(-231.94787892126874,-553.2812208887368,56.14378097918731 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark45(-232.11776056644783,-544.1848330098466,95.67575051719335 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark45(-232.62972648253975,-537.2157484991715,50.86468420689229 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark45(-233.06558407160014,-557.0262688460374,100.0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark45(-233.14240640855294,-548.6152976973475,9.901032616726809 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark45(-233.1591345896735,-549.2756441176676,38.867787143565465 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark45(-233.23327750767405,-557.8327787977024,84.67684611355787 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark45(-233.34433898077015,-576.6303014098777,7.105427357601002E-15 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark45(-233.6030434127673,-561.4038481132974,100.0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark45(-233.8582766663935,-516.6700482699856,10.247839497832118 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark45(-234.0719490499411,-514.2633420518617,93.04176461778647 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark45(-234.2613986616075,-518.0405250936279,48.17051335181013 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark45(-234.70280978722252,-538.0955815260868,100.0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark45(-234.86344671530276,-535.6582055709799,100.0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark45(-234.94799116187664,-528.0103952349945,18.95564421421328 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark45(-235.13543793198488,-514.8039638525929,14.980896307386232 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark45(-235.43487368355702,-527.4802667008291,35.53399271598789 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark45(-235.54773681612852,-522.0086186099928,41.66838530728671 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark45(-235.6220801650268,-528.5648286505112,63.87729318935541 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark45(-235.74700761446536,-564.0198705216867,100.0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark45(-235.79826003261903,-514.0546098316689,45.469400056187226 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark45(-235.98784209833667,-551.3037466601183,67.23802971930672 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark45(-236.3462776225854,-514.6223092008819,31.874278874376046 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark45(-236.46008818712215,-525.1648385204185,10.849034838920574 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark45(-236.7169115111586,-543.8767051820377,79.93930339197232 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark45(-236.77892590217192,-563.5235476090702,87.20516378860214 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark45(-236.92621085798194,-529.8791432368259,25.848036494711835 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark45(-236.94155109250863,-513.0487673850035,86.84605042115737 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark45(-237.09767233880422,-551.1170884585083,92.71083584837197 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark45(-237.13352085071577,-526.9108692215068,74.1171712576643 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark45(-237.40377436344488,-572.0919436879744,71.78113552600502 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark45(-237.4060681205565,-619.950206750782,100.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark45(-237.43617038676086,-538.4467246268331,57.05175468410074 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark45(-237.53417179627237,-555.0988489530426,4.471928770580374 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark45(-237.6288744795852,-536.826355780019,97.78054114540993 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark45(-237.70632114051836,-548.0152677064374,7.865268985777448 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark45(-237.9513445794381,-528.449195400863,70.82537553657164 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark45(-238.04356540833174,-544.2290325867534,90.83348833927613 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark45(-238.20272249982284,-546.3770297476608,60.099031683557314 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark45(-238.36851339412758,-574.4560221818589,20.21257547510129 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark45(-238.65726855296072,-509.0111046260308,100.0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark45(-238.77588209036801,-519.7922178979474,22.80957258857481 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark45(-238.97878261484036,-521.6082654032679,25.436403756952714 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark45(-239.19810591823472,-521.6230588098251,60.09439403351752 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark45(-239.52829492443323,-538.3051929966786,52.29763542146584 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark45(-239.77612190255553,-518.4603482375982,89.89200914523002 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark45(-239.8756285926577,-517.0788956011888,73.16118282144316 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark45(-240.04793730809473,-536.0262325456916,67.50727765499204 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark45(-240.0667340320597,-512.7556615062008,96.2639570329176 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark45(-240.22900050347695,-579.2619980598298,48.770333264227986 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark45(-240.5643858572257,-509.3094683633523,15.595660700827494 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark45(-240.65920359653333,-517.5770726279189,61.51486426462333 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark45(-240.7097713747383,-510.29168922664695,100.0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark45(-240.72203887608487,-533.7662972423117,77.00609731659958 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark45(-241.0261274974625,-555.7379185117916,93.22428913148221 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark45(-241.48334974427323,-526.744938969062,19.47457735462463 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark45(-241.58373148045882,-511.2638986066331,93.14844641086529 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark45(-242.0116266445664,-594.4963518627554,100.0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark45(-242.0652059203508,-504.0059760556686,42.80778593221905 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark45(-242.4339873331285,-546.9148882346557,46.96348451576432 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark45(-243.2711883860319,-512.6322719298634,66.42478202932895 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark45(-243.3824140372651,-511.20561989774734,100.0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark45(-243.70327432329208,-528.0880954216007,3.37847979832857 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark45(-243.70758061258405,-534.5338312624457,26.13500480072082 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark45(-243.74037969526756,-509.72971936800445,50.692520938420074 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark45(-243.9125284114142,-535.3306492903195,84.29648542349202 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark45(-244.26865389825082,-514.9773772624644,6.3457557805740095 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark45(-244.3209532799406,-556.2030831901002,100.0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark45(-244.4559430158251,-568.3620471648884,100.0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark45(-244.6684874288844,-518.3711447166974,77.26977449387812 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark45(-244.7983790568129,-524.7595197997953,46.23156239777043 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark45(-244.9503055817374,-503.2012623984,41.88953816604908 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark45(-245.1180064557331,-544.6536841803827,54.595509794709784 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark45(-245.19418733749808,-505.42825946768386,14.931138746428374 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark45(-245.34347863101857,-544.9961695935189,38.15478447999777 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark45(-245.5257916486633,-518.3940724254516,98.71740246530584 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark45(-245.68677090737427,-516.970863864776,46.023319908174926 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark45(-245.72905092153252,-502.6123001597483,60.83020231890151 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark45(-245.96678599379769,-549.7465960929676,2.140425792482972 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark45(-246.06303035024854,-541.8231381101916,21.09281505955036 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark45(-246.18273540416345,-555.2715702141485,77.3792718694296 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark45(-246.3902849719791,-523.1278500436385,0.6002051574243552 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark45(-246.77867011536432,-514.4715161223191,72.81182466072013 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark45(-246.92958236130772,-549.1872458363006,17.652183049216646 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark45(-247.2848981921091,-531.3977134034669,67.75748017601802 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark45(-247.39287618757473,-509.91315467303923,65.81379859416609 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark45(-247.46430827239448,-507.53670412632437,100.0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark45(-247.5326003120928,-505.6172226158176,93.84242733128804 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark45(-247.69458651121138,-515.370455593138,93.43630458536094 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark45(-247.8493036190743,-520.6505359423127,76.66367057674529 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark45(-247.93539996911466,-513.3092815866306,54.339585685798966 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark45(-247.98015013515874,-509.85860313402117,34.970889732310695 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark45(-248.32508458747833,-532.1982758442387,24.1956716657415 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark45(-248.35688897930646,-547.3996224122444,93.21676346977392 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark45(-248.4524623742985,-518.8150579995438,17.96771001270372 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark45(-248.64582603682737,-567.0455222695514,11.687929579987209 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark45(-248.89797323170578,-500.7876214540995,0.35081242051997563 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark45(-248.91554630009728,-500.2994295442275,37.13011750456471 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark45(-249.00794271911434,-519.3996078237835,73.73413275986255 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark45(-250.140700244143,-503.949608361098,21.420180116385026 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark45(-250.19916849857887,-532.9094779240476,76.10425748088565 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark45(-250.49074666443605,-500.9943483957641,66.96738780279199 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark45(-250.51518184238265,-544.3959221652841,64.77264245129257 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark45(-250.56315337008718,-589.7309663770667,46.27457056207436 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark45(-250.92401960295436,-506.88336624275325,82.68337613903643 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark45(-251.16733824090954,-519.0295879423,57.40949962980993 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark45(-251.32964064864672,-507.36791765315724,6.753108547005098 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark45(-251.66901604185216,-505.6877716226537,71.49053207025841 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark45(-251.7580097928535,-503.35443146413314,100.0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark45(-251.89899533195097,-500.6048961378278,2.6161961570835928 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark45(-251.90430210752922,-557.0388111072552,21.552642701243656 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark45(-252.02795407653647,-504.4017234338489,25.298111053377625 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark45(-252.12879989860312,-507.42258409921834,11.719476099250457 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark45(-252.19441216677407,-525.7949944898654,84.07453648562299 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark45(-252.2974692361156,-495.8889373384389,5.404420903217286 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark45(-252.45427033981832,-511.82754769422303,24.10413784529139 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark45(-252.52248006962208,-512.2349249376164,23.94381225533988 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark45(-252.6804188645931,-504.3200127140275,48.825194724288 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark45(-252.90461877343688,-501.92711187575924,78.05679029295877 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark45(-252.9916714536037,-542.2078732444807,24.566129957984884 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark45(-253.22731420111214,-501.522656185998,16.571086089766112 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark45(-253.3532203139947,-511.99233369963866,100.0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark45(-253.39239442465802,-516.8315138873407,95.4504624794609 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark45(-254.33008373323725,-495.479013503318,50.73137141941467 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark45(-254.3940592878538,-492.12856708929195,52.116764195137364 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark45(-254.54040999433914,-496.1317027025005,49.00632902750982 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark45(-254.666812148623,-547.184882113049,59.77993833293826 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark45(-254.67280171989938,-506.7668918925393,94.14416145801479 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark45(-255.03090526582707,-535.305050908067,24.055358888124175 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark45(-255.14299780018746,-625.7581008979174,81.70671047441485 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark45(-255.24824347430868,-499.02204008269337,100.0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark45(-255.3732429713495,-509.7203030327769,88.81014507157124 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark45(-255.55523724407007,-490.97191810094034,97.34122303043125 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark45(-255.59244164462737,-490.57190612826287,100.0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark45(-255.7021267294719,-524.9582608587771,13.682567117126851 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark45(-255.7784179845702,-508.61727957177095,12.51957639648866 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark45(-255.82753532381366,-519.0928825801701,23.752963718347473 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark45(-255.92040509670187,-496.95276865232506,43.94170498584634 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark45(-256.0149769677008,-500.7948659088524,81.9283647092976 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark45(-256.15653019855415,-514.6062871601939,77.08479935712441 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark45(-256.17190232737784,-494.43836867536555,56.665864960553904 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark45(-256.20436753621425,-501.2473338944639,100.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark45(-256.20852303735956,-552.6668983831187,12.876057721547014 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark45(-256.29923115719356,-574.1620232250532,79.43430652447498 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark45(-256.4312981696459,-501.88625206301583,10.761083278873528 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark45(-256.43145331284677,-490.91219352915846,100.0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark45(-256.4563325365922,-538.2288633864925,64.04916677549494 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark45(-256.71689584537376,-516.0325235598164,5.300181007849062 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark45(-257.25522570303485,-509.08014090056344,39.450228518757825 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark45(-257.42035601922015,-522.379875716568,71.22439955400577 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark45(-257.45641219373533,-495.6754960780224,8.477575273600024 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark45(-257.879166442807,-604.3551953062655,64.12912378326268 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark45(-257.947178387374,-496.55637601127444,99.28880085683474 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark45(-258.17018351095396,-526.3522325286431,14.484813579944529 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark45(-258.1839919127421,-525.9781104604176,51.12167009226968 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark45(-258.2067231349296,-516.3879054503305,96.5183241121974 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark45(-258.4500160545674,-514.181874055138,89.35704435592874 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark45(-258.54235543698366,-521.1045949991816,88.84112486081321 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark45(-258.6582224481013,-502.31810782124245,38.89454711697789 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark45(-258.7654078776486,-512.0057759461233,31.40871870470511 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark45(-258.80184617795686,-518.2240245380478,100.0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark45(-258.8684157727729,-570.1895270441939,100.0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark45(-258.99379008637567,-521.9025199551926,13.797015922540922 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark45(-259.0077713987214,-497.31178798142406,85.9499191404594 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark45(-259.29875365300614,-511.30500328842027,45.08175944547419 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark45(-259.37086137861223,-495.0334476977215,70.42123465451922 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark45(-259.39932360964167,-498.18274534350127,26.386748266193052 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark45(-259.54233429818026,-527.8351840291573,82.83928439135352 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark45(-259.6234134019776,-486.7635121947486,3.0019793437797944 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark45(-259.78365804792264,-505.24839389641244,89.43300084066118 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark45(-260.12232007637516,-501.60329683966813,74.53764463399574 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark45(-260.18010662974274,-512.5552775147097,21.738040221381162 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark45(-260.2047210232598,-489.7717908696489,100.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark45(-260.2660177001862,-488.4233207185203,54.85354497798224 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark45(-260.30184801644816,-487.04254914827186,80.14159427297702 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark45(-260.3494764778174,-496.59517024849526,73.58389432966445 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark45(-260.646088233108,-522.5785173791895,55.54145333790623 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark45(-260.6585081353486,-497.4347858591583,67.01370053013167 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark45(-260.9533621540351,-506.9368089541234,97.47799498216102 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark45(-261.0233832586874,-487.686168563522,2.1709423508931422 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark45(-261.1103998154207,-520.0759409869229,13.465876297348231 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark45(2.6130131153871306E-11,-833.2694844247915,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark45(-261.65155812578854,-497.99748974259006,94.02432956657242 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark45(-261.7863059766868,-502.15351995482126,80.40699696569462 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark45(-262.1118133047695,-490.3302510958656,97.90108783245057 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark45(-262.2220221743545,-509.74734656860176,32.42926276159352 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark45(-262.3989883220612,-494.952147105497,100.0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark45(-262.49075616691505,-496.9421713184085,100.0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark45(-262.55306800992355,-499.23522965821587,100.0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark45(-262.64698426551547,-493.6305057210477,22.660681704762254 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark45(-262.70366102378944,-529.7976847933451,48.69737874325105 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark45(-263.06533466769014,-494.92460621293844,72.45127562644248 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark45(-263.2266628575923,-502.6437111077945,21.166406040107816 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark45(-263.38737564989475,-516.506701205434,53.99169226533735 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark45(-263.4376028966489,-510.3433400323008,75.80753356898018 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark45(-263.51935430173125,-486.48959884877763,40.58332190879342 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark45(-263.61680359605975,-531.7123516864694,84.2060343925366 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark45(-263.72493154792204,-498.343784738777,43.761264563315876 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark45(-263.96169105675114,-495.203758609266,75.86646984956229 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark45(-264.0490511111803,-483.8338725553295,50.76403157650577 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark45(-264.1246538277453,-482.1416617994401,0.589972640521236 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark45(-264.2336451279159,-493.1063854960529,51.36067501927877 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark45(-264.27353203929965,-548.8757029739604,31.322957498763316 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark45(-264.8949964150287,-507.8536013399081,73.30862682528942 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark45(-264.9681796426786,-511.1154839106456,91.90455633162622 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark45(-265.05541255077486,-518.4866267814143,52.149304642312245 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark45(-265.0982131602132,-490.30420765026906,56.665643709577125 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark45(-265.79097588382376,-507.5757916135177,66.2416348818179 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark45(-265.8987021651504,-522.9801349186414,4.586781328029986 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark45(-266.01988602012943,-510.0993953822226,84.6540354824983 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark45(-266.2546099662765,-549.444580368999,100.0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark45(-266.3871067778457,-496.9931054862701,2.9834799151379485 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark45(-266.5690621640122,-510.71600334576266,77.49487947840413 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark45(-266.5859589563047,-512.8963091158394,100.0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark45(-266.7338851271366,-525.8768383495636,100.0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark45(-266.7529066206504,-516.1405385689333,64.30760634835738 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark45(-266.9284982082317,-530.7424494049776,95.29977701574785 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark45(-266.9400052812309,-491.3848988046987,100.0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark45(-267.16296989199697,-525.8525972868465,58.73361225931928 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark45(-267.1985572848482,-565.6669883951123,2.7227257260004336 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark45(-267.43635702331954,-493.5935971258358,38.94425651445465 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark45(-267.4467545897565,-535.7082988019123,81.21224446761397 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark45(-267.466641586748,-542.0641413395579,18.557699259656687 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark45(-267.5100311603732,-502.7589819681062,70.66769931081598 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark45(-267.5576433113791,-483.72365918229923,19.441674441517947 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark45(-268.35202031973427,-511.2621419493178,87.08813534141112 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark45(-268.67458747020214,-491.53153631674434,58.72541379376989 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark45(-268.73782102247037,-507.88720599547304,85.24998107727936 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark45(-268.9010474912446,-540.3106961342967,62.44691643776878 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark45(-268.92662421173054,-510.61665614184335,52.11002358432782 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark45(-268.9961262960593,-491.0487988295289,100.0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark45(-269.08809922106235,-572.4214514700085,100.0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark45(-269.12074676338005,-478.78683299883124,100.0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark45(-269.5436225264685,-483.2293137246601,79.67456729893027 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark45(-269.5668662510386,-482.9428428430778,52.4679658384554 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark45(-269.86870544642085,-491.94970293979725,100.0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark45(-269.9571292580672,-565.6649976318836,78.38355145218 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark45(-269.9869970121202,-496.5089058133763,4.085033329466128 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark45(-27.01106965401074,-720.825402328369,24.722054759008415 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark45(-270.4413287375228,-493.19781123396416,31.86500314308921 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark45(-270.524263793685,-481.58029975611294,1.9275900970066715 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark45(-270.60254739835227,-495.49448426853064,100.0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark45(-270.70794223781775,-515.8208465560868,100.0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark45(-270.8174057325505,-481.3926022714065,97.51889516588616 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark45(-271.00109297582395,-534.9563125623893,67.32089472770036 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark45(-271.09805745667927,-488.94339783329224,58.15462078920771 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark45(-271.10420960273785,-477.37746645482184,89.96014585463371 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark45(-271.4812893605125,-488.12967975694636,80.52832687753857 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark45(-271.6195877339093,-475.817797042805,5.193847576842714 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark45(-271.9604649952451,-514.1292765424688,92.03057844448134 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark45(-272.22920480778333,-555.262645227721,17.634302826735905 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark45(-272.28321702355356,-501.17080824160485,68.82702465476956 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark45(-272.3696105467674,-495.64862514816804,9.77526373995454 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark45(-272.5362321462816,-480.57582798910573,100.0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark45(-272.70134291489643,-516.8264732139967,39.73898787020852 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark45(-272.7954316274976,-549.0568654725479,73.77124259116829 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark45(-273.1460526611201,-490.7125689765922,100.0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark45(-273.18677205573823,-478.2972999792019,74.72139798837935 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark45(-273.6522148407646,-482.8293973993167,98.6563174121948 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark45(-273.73104445771196,-488.0297958357304,97.3751245072786 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark45(-273.80258317041034,-481.7227443543921,64.28125427053467 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark45(-273.8642629661528,-526.9612107228584,32.30702633631492 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark45(-273.86559411888885,-491.7039439172915,30.23061710557772 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark45(-273.99508519879055,-524.9342241761952,61.129231211573284 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark45(-274.06391218846954,-501.2454972105797,100.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark45(-274.50330736000063,-479.7204703956783,76.16177629558166 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark45(-274.5547724974638,-486.3887616485413,2.1055054162751645 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark45(-274.57649874280395,-471.45750213055015,93.82824273875158 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark45(-274.9635738598584,-516.0273578735613,88.1589284202854 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark45(-275.0465347885866,-475.9573994030392,100.0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark45(-275.27757843636635,-483.80777994260245,54.20144516902556 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark45(-275.36070577202105,-519.405983521014,89.90762047660033 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark45(-275.4353658353989,-488.527251374727,46.97582221463995 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark45(-275.5452414040167,-482.19774445155826,89.99843613795386 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark45(-275.8672632980757,-497.57624024548,100.0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark45(-276.0673888208279,-503.68023897540513,93.87523257792935 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark45(-276.27331797704596,-492.49861882667227,37.94757115079045 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark45(-276.91445283447234,-559.3421423020326,64.29419766125824 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark45(-277.3902492649132,-509.2739497442812,16.920531154795114 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark45(-277.7554272208981,-479.460555825604,76.34048931075682 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark45(-278.0942066673173,-496.46470341034507,89.97572694767652 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark45(-278.18248646166154,-532.7533869966543,60.40915345208086 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark45(-278.2937658282542,-522.522072863227,41.69287596022734 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark45(-278.3201761800583,-475.0944061054172,63.344858020963244 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark45(-278.4826382453659,-521.9063488382019,55.62173929417159 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark45(-278.4926627795857,-493.30894892188644,90.07454049028746 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark45(-278.5291660689809,-506.06531292503024,27.244802107835994 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark45(-278.57447673503094,-530.5911784163491,100.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark45(-278.61973352938105,-475.47874161774854,65.52783946388249 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark45(-278.66648993765284,-516.063858191509,4.029526810323489 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark45(-278.8720011316356,-510.03764387311236,43.03612547138576 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark45(-279.01194580705425,-531.0725713730322,92.07045131877751 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark45(-279.3823985468504,-494.2616628259385,53.07698011715101 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark45(-279.46974210432035,-475.410065450062,7.200885737093898 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark45(-279.4714041520007,-533.5716714003819,22.835850281153384 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark45(-279.60692856353313,-488.2815727535809,39.62771031127727 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark45(-279.81082752788365,-518.971953117247,92.7158182362655 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark45(-279.8736422902307,-468.0987644089142,52.027762090111906 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark45(-280.16009567683426,-498.94913222450185,92.01400732399799 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark45(-280.27216951221004,-508.01508079633004,5.095321121975999 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark45(-280.36956960857333,-499.44633913925355,99.8115599575471 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark45(-280.51047083553124,-487.7416259781518,-59.678846482081816 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark45(-280.6226667272266,-489.28288303076494,79.08567634701618 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark45(-280.7057172190719,-500.58710694011273,8.92559100118551 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark45(-280.71068475259415,-477.00283257110243,29.183266661196228 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark45(-281.09806235556744,-486.7684726907469,71.98907783901345 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark45(-281.1330972812079,-467.7193990173623,7.188934663865837 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark45(-281.22353020803854,-540.9270520250352,79.55646061277551 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark45(-281.90814358031315,-480.72418398353,98.2561579116001 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark45(-282.0054474859055,-494.25068445319994,100.0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark45(-282.0933308791559,-469.9111926148677,42.246182411188414 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark45(-282.1269149848516,-473.85573115062243,95.00819749079744 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark45(-282.1739932389266,-468.4638344145588,70.48337624713034 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark45(-282.25159340516643,-533.5554138159431,95.68650502785195 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark45(-282.4152681831575,-477.42445090898093,14.433338312571323 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark45(-282.63683825345186,-500.5116711685255,58.815648847726266 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark45(-282.76338949340544,-517.3097785048545,86.03749800991031 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark45(-282.84060289182645,-492.4866847248134,79.64067523111191 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark45(-283.0427487708762,-478.73405856375035,17.02037302289652 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark45(-283.27797058927024,-478.3896700536422,13.584553521755183 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark45(-283.3696166514567,-483.91169714103467,100.0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark45(-283.43624484196727,-498.98128999241516,83.67910923841916 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark45(-283.52960464799486,-512.3226840731229,69.04317889509488 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark45(-283.5684515613488,-464.4049728381786,100.0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark45(-283.8328118376725,-478.6238290073846,77.85403159647117 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark45(-284.0927631368335,-505.978548590504,30.703606272923423 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark45(-284.4452641616453,-516.6438122602984,73.6261357125625 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark45(-284.7712312285615,-462.04708252662556,32.129025484995424 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark45(-284.82794530076035,-474.88119319292736,92.81506143013024 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark45(-284.8514799846023,-471.82497919841853,8.881784197001252E-16 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark45(-284.89296025256647,-487.5177435933874,33.68446359588174 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark45(-284.97180739527687,-470.08980217625407,0.26535575568486536 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark45(-285.01238031554277,-486.0305184067211,40.50322749305377 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark45(-285.0459469125044,-482.16439628811827,46.51507344357785 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark45(-285.110701827892,-497.5679974640904,50.435711029166896 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark45(-285.13331598175193,-490.21445439499934,22.312110110810863 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark45(-285.1529810677319,-487.5402516324093,46.16738532232347 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark45(-285.1629630089544,-461.086685993228,2.4851585075178946 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark45(-285.36687073202756,-463.09298717639126,23.094721046335636 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark45(-285.6254044814838,-483.9271292749847,68.93344349339716 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark45(-285.6363796940522,-554.308366272585,88.22087589342755 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark45(-285.7504311340697,-477.2682174975107,100.0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark45(-285.8916482101392,-506.42072218757556,7.947515154485037 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark45(-285.99073577433444,-473.66573755567384,52.01157979643577 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark45(-286.00996637229815,-460.133439478652,87.99828616738756 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark45(-286.10057317377886,-518.6248146061924,100.0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark45(-286.118361740736,-502.7993117961454,100.0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark45(-286.1358083649718,-464.84477841059885,2.439847462284675 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark45(-286.33375365551353,-503.9630690998243,43.22880459376867 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark45(-286.3618680165094,-473.2217441497662,18.040854863471353 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark45(-286.380654604241,-466.6040653921795,59.65366555802595 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark45(-286.3926878871853,-497.6678995299746,10.981459358334575 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark45(-286.8788519532633,-474.60227239201333,38.39955977163106 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark45(-287.2198594985442,-462.02321278578756,100.0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark45(-287.26227583701274,-478.93101110120716,83.1107318160671 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark45(-287.2905736770002,-472.2346296933443,46.88752026026327 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark45(-287.4957938086787,-548.1596052516027,71.37147762771491 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark45(-287.5343322820248,-464.5294074293404,24.24494729046522 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark45(-287.66182566225797,-476.7827512082247,100.0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark45(-287.80222241898593,-465.3979105481027,36.497359988899404 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark45(-287.8324606368972,-473.5546260467506,99.27045565369406 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark45(-287.9311707443743,-480.0208352720499,76.65695960326707 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark45(-287.9770241325379,-496.20728233313463,61.467418162048006 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark45(-288.0244796735643,-458.8031272628163,92.61984202546617 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark45(-288.1181724137138,-474.2090435144987,12.837206023253046 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark45(-288.3123419590418,-502.449645183842,52.51390705359242 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark45(-288.39714286739775,-481.9686898626294,30.920118857778135 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark45(-288.6893136438792,-457.4123140485898,100.0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark45(-289.00378992478795,-464.43075552022646,54.100809492407166 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark45(-289.12355498513205,-458.7751842480945,5.105089477973252 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark45(-289.1695219797025,-486.7817924575681,41.214622689919025 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark45(-289.2263645241877,-462.78801862573107,38.268820997042354 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark45(-289.41025446522394,-472.2080451978925,49.88060423097116 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark45(-289.52579304774173,-457.640802220598,14.120504400585588 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark45(-289.54136083032574,-497.17092109920554,67.2608793285535 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark45(-289.8474838341569,-513.9592619091001,19.448759947126916 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark45(-289.8483194816877,-459.52750045848853,5.930781169228936 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark45(-289.9645515765032,-464.13612457400586,100.0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark45(-290.1056584419342,-495.4516385484507,68.78293579267654 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark45(-290.15262874098386,-459.03078135286097,100.0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark45(-290.99715460782613,-499.2174381289269,100.0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark45(-291.28126814775374,-461.40417447244585,53.97605746426157 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark45(-291.39912669776567,-489.6766499640683,79.48897978156882 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark45(-291.53478864858425,-488.27401533329555,85.9446833712561 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark45(-291.9398360226927,-524.3519309636913,65.40823459625966 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark45(-291.98353541934273,-483.0741953524863,79.9621956072975 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark45(-292.2150870555939,-456.18624564869197,81.24687295951287 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark45(-292.4094820684328,-468.100872514426,55.6497659408449 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark45(-292.46631160483304,-469.7518121594452,100.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark45(-292.5686168375953,-489.55220092544334,81.55753013935589 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark45(-292.61663780249154,-492.3459039735812,31.90545555132701 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark45(-292.75192009935165,-473.60387655518457,65.64857902209695 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark45(-292.83882776042054,-578.4583258429095,91.21758931712435 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark45(-292.88492424366734,-467.2326439666696,92.24302817759394 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark45(-292.94728965778216,-479.9838533033998,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark45(-293.16232104353685,-478.57702853127716,3.308256480432675 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark45(-293.26623358314134,-456.8716356612414,96.20664017024546 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark45(-293.50934809855033,-526.4237552313335,49.772462282877456 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark45(-293.5495373259585,-474.5828286555745,44.49707674593909 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark45(-293.578973743078,-458.8041799815302,41.92825008728008 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark45(-293.75679994576524,-484.13236534913335,0.6985829560083072 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark45(-293.9139944287266,-453.9340806488651,100.0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark45(-293.98821403708934,-453.3342288429007,57.45408941380876 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark45(-294.2222702190642,-530.1226691854876,59.78371960845291 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark45(-294.40950337594484,-470.33103114819,100.0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark45(-294.4843801058462,-451.93758517577294,92.66033292944249 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark45(-294.57311476305705,-475.6347361987428,53.322304442447106 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark45(-294.5886210832227,-464.16030583432746,42.88457697203603 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark45(-294.683775559202,-474.84357513563816,52.22786251841811 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark45(-295.023464293772,-473.55576651059556,100.0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark45(-295.09104449393305,-498.4654118017741,64.4965326332239 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark45(-295.3058704620956,-470.84641531100374,67.53137521085719 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark45(-295.46128849853227,-485.3487371101749,62.44068596450825 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark45(-295.5685703056043,-478.61327915898136,22.59465575597733 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark45(-295.5811591617989,-478.4683384965632,100.0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark45(-295.5828666839397,-454.1832615265568,69.90349972727952 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark45(-295.78796681095935,-459.92528873980166,100.0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark45(-295.99206559120915,-450.9276466613328,100.0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark45(-296.1789765659971,-486.0015169980573,100.0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark45(-296.4468034007751,-450.580587661369,100.0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark45(-296.55789940978264,-474.1820868879305,11.732396877844891 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark45(-296.6407086414085,-477.68357409285284,72.78567538683654 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark45(-296.80161685639905,-452.2162265097302,40.556151344219614 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark45(-296.858414177506,-488.6091741210432,73.04573792574607 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark45(-297.04767382760326,-463.46198435542317,100.0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark45(-297.10226994815537,-458.6197977490916,50.13306717087241 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark45(-297.14651350552094,-459.0492408583141,45.573571533562216 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark45(-297.21239379880615,-538.9132335220326,100.0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark45(-297.28578152751004,-464.0752074859794,85.03904181891178 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark45(-297.54287615315667,-451.57548378495085,72.39364142072375 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark45(-297.7803272679513,-451.2282326821,100.0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark45(-297.7986380908942,-529.4824294870655,74.74885910723475 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark45(-297.83955419497727,-451.553794634254,56.395066469953605 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark45(-297.84900206182834,-458.2472629387501,73.9762622606832 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark45(-297.9566171619632,-469.7167886237986,95.05881206704078 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark45(-298.0019456632793,-458.94157300697566,90.68088355422367 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark45(-298.08430897723224,-489.97981634794655,16.765653115634066 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark45(-298.22399509224715,-466.6995985490873,81.19575425396755 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark45(-298.32340484438316,-460.79158814135053,100.0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark45(-298.6306487321812,-484.9348762090565,58.59347429012411 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark45(-298.7709506497865,-521.6629981119306,100.0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark45(-298.82337576090094,-471.04712040127447,14.109830657781716 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark45(-298.8251072835261,-463.17408907276837,63.7897850864984 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark45(-298.84649325242674,-537.8528412885352,75.78310329175878 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark45(-299.0634890854922,-473.2801863150557,100.0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark45(-299.2443771734955,-477.2673872584409,53.495530284692876 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark45(-299.4560462404324,-455.43179126647783,33.93195700635161 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark45(-299.4843912025199,-477.21310999829535,90.0602857968075 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark45(-299.7065615881718,-517.6047833191416,42.53304127475619 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark45(-299.70762181737194,-448.0036706859088,71.16918142472173 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark45(-299.8020101508431,-448.0588278279065,12.35250661837732 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark45(-300.0104102938823,-460.3199494269097,6.431039644814177 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark45(-300.07152375550015,-448.5320209022776,100.0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark45(-300.16001190906167,-454.35522946261585,100.0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark45(-300.2492037617038,-477.64304685670254,8.227233793702979 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark45(-300.36565944167245,-452.8901160715046,100.0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark45(-300.6075011043711,-466.16079261631234,55.31598333169427 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark45(-300.74593913266455,-447.5091821242318,48.88528443391405 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark45(-300.7558588968543,-451.0474162929964,70.37862008095883 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark45(-300.8001312091169,-497.0638192027174,45.50616623084605 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark45(-301.02455690190965,-445.63981734527033,100.0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark45(-301.3266548436531,-472.3870012768779,91.84585254540471 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark45(-301.9398302600303,-456.6319799626519,86.84236970203554 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark45(-302.12490634473266,-472.06768814906115,8.959134081154193 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark45(-302.4046746529166,-588.8640329765396,46.910004081960466 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark45(-302.42713483149186,-465.45834696125405,68.11719298440937 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark45(-302.45583709309756,-459.6168640683972,25.088111423397848 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark45(-302.5466556491662,-458.28700338373443,68.26492741711371 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark45(-302.84034033866726,-472.40530395504305,51.5775053780272 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark45(-302.84777836328163,-466.973357389669,9.503053459654836 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark45(-302.8981167315247,-462.47301490889595,29.747059243522244 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark45(-303.0636878718378,-451.31337342136754,90.4371463714115 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark45(-303.1531504102026,-462.3357103287193,100.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark45(-303.3087377901844,-453.8831006931131,8.881784197001252E-16 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark45(-303.6829330982621,-486.83208801546135,26.620630650532775 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark45(-303.70901324316685,-456.9081492491072,40.89404557676829 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark45(-303.7252943304326,-446.70261725797053,74.96701140771185 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark45(-303.92873989274096,-462.5974827716227,86.22450600719054 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark45(-303.9732778497751,-447.28223575836466,100.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark45(-303.97786572199084,-444.63634999082353,49.59101286637738 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark45(-304.1531433035946,-453.53176377516047,39.579750494412565 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark45(-304.2700699570369,-443.6133518361969,96.48400443727178 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark45(-304.30147825285104,-453.1557630746484,64.9975914653833 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark45(-304.4161479840022,-449.8369059263642,6.044454269323623 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark45(-304.65999019851836,-463.0089093568433,23.593572495895003 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark45(-305.17323255797805,-470.083867072482,100.0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark45(-305.23559271635577,-452.3945103157727,51.97693559721603 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark45(-305.5520042098775,-451.26511906799567,73.01592506845799 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark45(-305.89430410275327,-472.0246481635702,60.68071397591618 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark45(-305.92175421782986,-579.6121453852896,98.35348465593992 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark45(-305.98097356168597,-458.0975592419094,74.87813091935811 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark45(-306.00795300900654,-492.9909294324103,60.68625020895831 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark45(-306.0164168530605,-444.3515449503899,91.30707814714617 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark45(-306.1882489835674,-452.9206851976202,81.04718575028458 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark45(-306.28052132992326,-509.8386336565425,6.324349885502471 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark45(-306.57992618532705,-455.39519350565223,100.0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark45(-306.7700307664734,-490.90088453510174,63.95366321151167 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark45(-306.91149327280766,-447.4790118212268,100.0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark45(-306.95947398623224,-473.0823444584828,77.55334058388098 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark45(-306.99662838116365,-443.0875550795013,16.7834378083205 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark45(-307.5153885195527,-447.06373180996354,13.52563188590193 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark45(-307.56456871638704,-439.5915164256785,68.87784171071175 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark45(-307.57244693507613,-473.5694930639706,19.206875588709323 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark45(-307.6784984867644,-461.9481678079407,100.0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark45(-307.6953626633752,-491.1650360114256,21.702017855106902 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark45(-308.0168580475597,-473.8234647623506,57.5934205380745 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark45(-308.04477578358774,-442.2555459961567,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark45(-308.2458131049149,-451.9505143330664,55.66214978014267 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark45(-308.39740764819993,-446.6074885657475,6.607653000653244 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark45(-308.4095926556413,-449.87215680613275,36.222585641405146 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark45(-308.43547200584277,-550.3443435410319,73.25391088064657 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark45(-308.54475212198736,-561.3513171588568,11.120024648305616 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark45(-308.64992211128646,-444.5020242313462,62.35232683873414 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark45(-308.9361556143836,-456.4626757901324,-54.26266675029696 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark45(-308.98027303787757,-485.3305919189782,15.139865460877097 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark45(-309.04364251269425,-463.0692056858434,100.0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark45(-309.1317685025229,-482.92097938675204,23.548823595585205 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark45(-309.1505997192484,-438.3601782393812,25.150421161613878 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark45(-309.1601153413009,-472.2529128986666,15.614520034508203 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark45(-309.2002111246006,-445.2203506266803,93.50557141716598 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark45(-309.3879036857349,-447.07568557009836,100.0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark45(-309.68179707469375,-436.88709668817086,32.86947200565103 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark45(-309.74965570292756,-506.7385195818926,73.87944874317887 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark45(-309.80498822528483,-452.8296039350295,96.5462788780944 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark45(-309.85261521853204,-440.29331297657615,10.17366161640021 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark45(-309.9274181608632,-444.6534547397336,48.61463082259195 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark45(-310.17466964697314,-451.7323591720534,90.95515720578675 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark45(-310.2135107247294,-540.3672451446902,98.70604183004409 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark45(-310.2262367078457,-440.2931012288053,14.218884598464982 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark45(-310.3189306047294,-462.0336929669075,72.81662177717786 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark45(-310.3531626221293,-455.1256262298481,80.73845308555659 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark45(-310.4843453767866,-450.59831430580226,3.080379736998708 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark45(-310.7866767420442,-495.6827205436952,81.8463241233913 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark45(-310.86719276445746,-461.71792211815637,26.23412556864477 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark45(-310.8965371444109,-437.20859377568763,25.906346740550788 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark45(-310.92875889492893,-440.7705218214251,70.03464652606112 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark45(-310.9820174630101,-464.63628683246253,100.0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark45(-311.20323061195097,-436.6222532979358,5.471454629520849 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark45(-311.5902299367104,-487.5901277673584,86.40680211480262 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark45(-311.84159607332185,-481.9708296350223,40.864873009946734 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark45(-311.98370513973407,-458.02522804259434,27.658884041744344 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark45(-311.9920918379294,-448.1798175656849,94.90669909767405 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark45(-312.47190121502007,-469.3266770879368,6.729738184848671 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark45(-312.52579465237665,-475.9567384067585,0.4087865743849477 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark45(-312.7422066514739,-438.10858719919315,100.0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark45(-312.8077696232557,-441.51817129158115,88.88168528330473 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark45(-312.8355963153514,-504.55752047024805,28.808729376686557 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark45(-312.88415408801023,-455.5489360261055,24.051287133883648 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark45(-312.9759772824696,-470.64095636285305,72.91008231543552 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark45(-313.0152534357974,-463.3964948837214,42.565288194390774 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark45(-313.05593554983085,-445.4991589306969,26.305735696825906 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark45(-313.11173467315876,-434.6205135609985,47.22485418448679 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark45(-313.732356621923,-458.30923185397006,77.95284840263062 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark45(-314.01170676158546,-433.7782072608366,32.151538887807305 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark45(-314.1083836881189,-479.49395865269736,88.63204242586369 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark45(-314.52561657880347,-445.216426430512,22.241898333294458 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark45(-314.53194134327583,-454.62807372098507,94.85523747471194 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark45(-314.5402647011536,-433.7329950277027,6.33398144237583 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark45(-314.7499897075055,-525.3797940533677,100.0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark45(-314.77976853708947,-436.0719095585775,58.025771473845396 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark45(-314.8513777861981,-454.3516146413065,20.3235050737143 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark45(-314.9342217407387,-437.9170485104326,63.14249702556526 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark45(-315.28251514264963,-472.6325776180494,6.248615330112784 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark45(-315.2987846578391,-435.17130865827465,53.095958466194986 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark45(-315.32910957226426,-475.3487494585132,96.23261687023285 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark45(-315.4114424525915,-499.77121092335744,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark45(-315.4154639020987,-439.8761083369521,49.587373431914756 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark45(-315.41858756769335,-442.8822115120429,60.9464328351342 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark45(-315.44771129211057,-435.1963771432426,12.17219743232665 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark45(-315.56325467694995,-455.17137345487566,37.68893754134709 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark45(-315.81708753184137,-438.972314400816,43.35765192670223 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark45(-315.8383326572218,-467.71504930469325,79.75681938928358 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark45(-315.8942097473876,-445.40254223918953,68.53444618752803 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark45(-315.94405455253633,-528.4040285547818,97.9111757611073 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark45(-316.0079633406597,-469.3751447179556,11.086362466755986 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark45(-316.03646676581087,-522.065389986263,5.557538910319863 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark45(-316.07940362345596,-471.80262014186803,28.6390086759304 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark45(-316.0904963899699,-462.5234899495344,85.45263794636199 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark45(-316.10410908756086,-462.7731622211658,55.20669546188419 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark45(-316.4000401811132,-470.8250213168784,64.6465661983652 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark45(-316.5641455317344,-441.347521952548,18.400345852347726 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark45(-316.6568168885991,-450.8781171077835,99.35787169250995 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark45(-316.6687778825889,-467.0350783433921,23.417977376603716 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark45(-316.8339482971865,-461.48585416473054,100.0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark45(-316.9549053389853,-492.2897782545599,20.184406568969777 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark45(-317.2178419166606,-481.2183809371916,16.961543626708092 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark45(-317.2273947290638,-546.5585098565834,96.46901128726947 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark45(-317.38911327531423,-462.65582858109974,25.61741044695279 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark45(-317.5592354020621,-438.31894459986313,69.55756191618525 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark45(-317.65238668261236,-484.1209393368738,42.31286439565602 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark45(-317.65532876609143,-431.289433450821,100.0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark45(-317.6603230742863,-432.3241839338624,2.564991082903603 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark45(-317.74999668210523,-446.4771117851581,21.896692198440675 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark45(-317.76991395918816,-453.73612831736193,9.24153090191146 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark45(-317.79376343988486,-459.0659489459102,9.266841206632677 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark45(-317.8968811758452,-491.2877151265895,22.122297993569077 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark45(-317.9878343470142,-428.1978119526329,50.20417332101334 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark45(-318.008051106872,-433.52842859988976,45.92607623304701 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark45(-318.0451459181672,-429.93119462058496,93.79475750144238 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark45(-318.0681295485195,-428.9994518785563,15.584408960219221 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark45(-318.44941081552895,-429.2752138782748,22.558638876993385 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark45(-318.5625808756606,-461.28403858719525,79.01150103516923 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark45(-318.6226459463825,-453.96287791879195,91.45208303998359 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark45(-318.80638208540057,-442.118094393486,69.61906252689025 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark45(-318.99952309119635,-440.6907833826249,74.29331400465648 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark45(-319.11968791675287,-435.5343494665172,62.041237833752575 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark45(-319.1378534778511,-432.6436299546276,29.472474393089996 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark45(-319.14105905731424,-426.91917239301904,93.69249500706042 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark45(-319.1572360548711,-431.2668862407981,8.318557749162522 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark45(-319.23748903836866,-448.8077464208215,100.0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark45(-319.2572189576994,-516.9098746856189,46.30002111469494 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark45(-319.2740385733076,-429.20202514017245,29.00333976888831 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark45(-319.7894116211635,-435.45332511742265,89.0812252811678 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark45(-319.79292994603065,-443.1725838328577,100.0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark45(-319.79917556128476,-464.91878185156617,80.54350622724473 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark45(-319.83960953487264,-465.66903818470905,70.97190245574603 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark45(-320.0133790645863,-455.40060415513045,62.220116153503824 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark45(-320.16211630064157,-429.97020934658826,39.63531017927221 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark45(-320.1797822702436,-437.7354955839813,78.9418689014951 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark45(-320.18544789408463,-430.94752593192527,43.986916039366406 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark45(-320.27130574624766,-442.76280106926214,100.0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark45(-320.39063585667145,-425.64279792578316,33.53405505579343 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark45(-320.44218855407394,-452.3872232602206,43.534503385908124 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark45(-320.8568554194246,-432.78178077101813,86.5480644943282 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark45(-320.89086607386974,-493.00799688893557,79.07763929225956 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark45(-321.0251014540789,-436.1400053258737,100.0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark45(-321.0597175728167,-439.3303091451184,52.043273666117926 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark45(-321.1404415863667,-489.3105548725042,100.0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark45(-321.31697417573366,-442.71691615220294,23.76459983750709 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark45(-321.35929866944264,-446.7914248845096,34.0065525606436 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark45(-321.44551501875185,-428.13182937558037,62.70838358717978 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark45(-321.66421696738433,-454.8240227277018,26.81158419742367 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark45(-321.68091564583943,-481.6892118245494,33.927110913207144 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark45(-321.7898847164575,-477.9980712486251,63.03536618916971 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark45(-321.9478662715424,-455.64196231761724,82.14536479051117 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark45(-321.97517518252073,-493.30402873165497,66.98163656106513 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark45(-322.2186864431532,-428.57359458617003,47.283417907858365 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark45(-322.30787759343235,-446.4882652700507,33.45633413318632 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark45(-322.6725582429215,-436.49147736463567,23.461487925034447 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark45(-322.7796274232801,-443.04325771232675,61.54786387082416 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark45(-322.86571265959003,-460.5256925818039,50.50909136271693 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark45(-322.8714573058494,-456.8915693689717,74.95229606882492 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark45(-323.0530570806266,-465.7771947465279,100.0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark45(-323.27917059111405,-433.2935374608858,70.39373521294186 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark45(-323.2907528299789,-426.9543767258017,40.347917346939624 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark45(-323.3571492960086,-433.8518403055859,100.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark45(-323.54471869316717,-444.7633627521688,65.22751499161046 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark45(-323.56198481651796,-440.41891197801243,66.350464813824 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark45(-323.70107671587596,-430.4446082770536,33.81819369989191 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark45(-323.7116725629123,-422.6811462631717,14.851405848209211 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark45(-323.81670781499884,-439.97099891437483,16.30832687055026 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark45(-323.8722775270953,-428.50463752798066,68.57354665916927 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark45(-324.02338198934365,-510.5213129608883,63.204684308460855 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark45(-324.19657169282624,-435.1833103439005,15.072249566451546 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark45(-324.1973581261371,-475.90697481084004,45.912184425597246 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark45(-324.2374517351179,-426.3270190989133,76.92046379399508 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark45(-324.32466015942765,-475.42444988402366,76.04226982173847 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark45(-324.57724195314904,-422.21659378112173,53.575127551764865 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark45(-324.58460181307106,-452.4179494071723,73.06648747555766 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark45(-324.62861930821975,-468.0184137468473,21.548078774273648 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark45(-324.9779477852348,-440.1942134047326,14.058106268557651 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark45(-325.3983314813961,-472.5935625293006,82.2304186270988 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark45(-325.40402736020434,-476.31346173235477,20.30973568088082 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark45(-325.55438319662164,-434.57045828413317,42.89383756542543 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark45(-325.60456141315757,-427.89024125587866,39.339661092148674 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark45(-325.67142402139837,-438.8150613610083,60.37911165360873 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark45(-325.8499510464413,-429.8959671342339,88.58569473404833 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark45(-325.91677534899486,-424.52377801078063,34.44353803208904 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark45(-326.12065863367377,-449.7639877035558,9.137127336452181 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark45(-326.42857370266967,-433.9186016652304,4.701028797437786 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark45(-326.43886522760306,-456.1240392607582,22.122839842055967 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark45(-326.49532842277785,-430.77894232859484,20.943258938016612 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark45(-326.59099906400314,-457.9474610761605,9.153261563832245 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark45(-326.6135839627539,-477.1696539862972,45.32858632144249 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark45(-326.7123978500763,-420.04740131047487,36.21776520986461 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark45(-326.74679725541597,-439.4211988240415,44.174055834053235 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark45(-327.0080490465004,-432.21009268287037,46.82542652545462 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark45(-327.04759661941637,-427.0584268784782,84.39466706629223 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark45(-327.2831198278539,-422.02782949286217,100.0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark45(-327.5411587389732,-522.4145776929956,29.01311957050342 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark45(-327.5559212456639,-464.663709571276,27.160088383814113 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark45(-327.6804601027387,-442.3804058274261,60.653769405463436 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark45(-327.7740176779557,-450.2500009248087,2.1723894531550485 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark45(-327.87129428907394,-429.65104921370386,30.237560290585577 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark45(-327.9122965816628,-441.46480242953,18.980706350234435 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark45(-328.06451373608104,-444.6538503341012,1.117502441582559 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark45(-328.2540151343432,-455.07643647664406,86.88015335920653 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark45(-328.31717002021554,-425.8611065830539,4.515646068265738 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark45(-328.4535463693796,-426.86463917720306,26.903173839441138 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark45(-328.7430464456729,-518.0652061212463,11.293341066131873 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark45(-328.85625313692185,-439.8750173696967,94.71800179934749 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark45(-328.86292753642886,-445.9486899161015,74.3178056545886 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark45(-328.87529447794986,-461.7537686937144,82.19519547967658 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark45(-329.0257944284047,-423.5352061500141,4.298713683259251 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark45(-329.0950728478168,-452.3271260902836,54.71273455638686 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark45(-329.16023289448805,-441.0523690125395,9.609793269483617 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark45(-329.3545454942137,-493.7071988692902,51.687911515779774 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark45(-329.3886598912223,-429.5873006434504,21.21684416186534 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark45(-329.61118011357036,-439.7047201599136,1.4071673689000068 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark45(-329.70981426071495,-430.6494896162912,44.5914723765265 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark45(-329.77865185730354,-454.5097316070136,100.0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark45(-330.0870399519668,-459.2974997638387,2.9349989835419734 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark45(-330.1009853670486,-432.0138171820277,66.78562412766544 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark45(-330.1076779794964,-421.7304585198706,48.561897051692284 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark45(-330.1218443226626,-466.8248768357854,37.75514597752593 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark45(33.027943939761684,-52.29594764522278,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark45(-330.290008261076,-442.95401410895124,28.583454849565584 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark45(-330.38454042116905,-467.2941064713732,11.68342902365525 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark45(-330.43762334232,-444.2710988484699,100.0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark45(-330.5859738142117,-425.0566922812785,32.303883367614645 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark45(-330.5903330331565,-424.8607682151569,51.87933190043549 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark45(-330.81017502788256,-481.1703944028645,50.040323288114934 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark45(-331.6643619369027,-431.2785456371309,34.48154999417264 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark45(-331.6660141854243,-447.6030922637661,23.392548516604236 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark45(-331.74275155509855,-422.162770480219,2.0893353760019977 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark45(-331.7569538965958,-416.529805649706,60.093045244730746 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark45(-331.803062694656,-469.01167768126146,86.23311691003761 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark45(-331.9681739212233,-415.80858851566376,3.67374116663251 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark45(-332.09180523061434,-437.1226385969263,1.611448547436285 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark45(-332.48406827511815,-424.7249707120327,35.614986275335156 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark45(-332.5444818049985,-469.23190032706293,2.921289398365417 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark45(-332.58440672012273,-429.84195817027256,85.65433137674657 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark45(-332.5968127908009,-416.8326607056276,27.480513301536874 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark45(-332.68413070929114,-467.58561307923253,49.53766868458487 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark45(-332.73530977707657,-438.1444551044042,94.68962311255095 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark45(-332.7983475783234,-416.5218467473579,73.82457846516058 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark45(-332.8115967399233,-439.496186869354,69.3753840192702 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark45(-332.8564089156347,-442.9785347082721,48.42179172924824 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark45(-333.1508594580537,-415.85331143380716,50.10054811265846 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark45(-333.15257591866464,-437.76771198465275,77.0596271677004 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark45(-333.2438372955916,-446.6270712909045,34.3219602582698 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark45(-333.3503100122779,-438.6651699906208,62.43984392557516 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark45(-333.4443471727275,-486.5059368639939,29.637298173642705 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark45(-333.82218171709945,-441.14244605364684,100.0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark45(-333.8232694079157,-468.6025138811613,50.70375298223419 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark45(-333.8586354595861,-445.5534105877957,84.94352944053549 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark45(-334.00620690908494,-455.85624112736616,100.0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark45(-334.15641880386215,-415.52288426993346,82.21640807235534 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark45(-334.17760365229213,-422.48888742765735,75.93283337785795 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark45(-334.2121149225562,-423.15932794920724,3.807832672806427 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark45(-334.2319443570849,-436.47360282207103,81.16140597683051 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark45(-334.36039160411843,-420.26081652772683,41.626542521005035 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark45(-334.3768704994679,-414.8933193903626,42.66715788862422 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark45(-334.48457896623495,-424.6435126368842,100.0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark45(-334.54527687832217,-418.02032419199367,61.5793048599285 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark45(-334.70042246604754,-448.77413036176483,100.0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark45(-334.79151014147726,-415.7405025907564,86.15327711901682 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark45(-334.98823977639853,-413.56922653812086,83.27819706617916 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark45(-335.02308717723525,-456.79382468169115,11.12029967102422 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark45(-335.1932379017925,-421.0489370996724,100.0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark45(-335.30272547449096,-415.3882847487509,10.330085878723153 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark45(-335.51686614456895,-429.9077738147653,100.0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark45(-335.5382735326593,-412.6453585936421,64.40895749342889 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark45(-335.64657697759276,-415.9070577324692,100.0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark45(-335.7158570192683,-416.478097223622,82.15496597545388 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark45(-335.73520966588165,-438.4665326233216,16.925682271413393 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark45(-335.90962104815395,-462.7568543764625,85.69323744876826 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark45(-336.0142210651009,-411.86498165274185,83.80167523048033 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark45(-336.1046021255611,-412.98859394213093,100.0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark45(-336.16224675692536,-488.1689041482121,2.7205069125960932 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark45(-336.2504594247189,-426.44288119529506,45.74211389980576 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark45(-336.5432918668252,-423.9891507644839,100.0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark45(-336.84894424462,-460.2516871297033,19.97534683142817 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark45(-337.1145901527459,-432.323931121153,31.749706400838164 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark45(-337.1152478445089,-464.5169420089666,31.572027658989413 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark45(-337.18394857078476,-436.5984330973122,9.590851497119075 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark45(-337.3795028268677,-448.469628476151,-3.19268128100299 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark45(-337.615629097821,-424.41794534002906,98.90693149458735 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark45(-337.66942391924715,-427.67380050731936,13.774348824244441 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark45(-337.6943260365026,-429.7064444078116,61.196261994931604 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark45(-337.7975423504609,-423.2691284150082,4.5235584084108496 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark45(-337.7998859591129,-411.2275483741477,2.431224004860823 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark45(-337.8130809349403,-422.5699723398819,59.49267078349155 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark45(-337.94822490446785,-411.21187017236804,70.59527547648821 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark45(-337.96183593075574,-482.0578185462915,38.660077556617296 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark45(-338.2553310518757,-462.5243785558404,30.150345324830226 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark45(-338.2937119454271,-410.0131505520909,21.80096674980976 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark45(-338.3311796144138,-426.565044027576,59.1416018515626 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark45(-338.3595940238001,-465.31606490586597,100.0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark45(-338.68298001941344,-414.5808672741927,67.36735557863486 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark45(-338.8715648541091,-425.4748942530872,17.109726451959872 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark45(-338.95322748409046,-421.7481838382917,77.25621557519926 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark45(-339.0182651210465,-443.11570783481415,24.51471123611384 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark45(-339.0769025072756,-493.99489537044235,33.72177287446141 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark45(-339.2258196941331,-444.57336094441433,23.93333874822477 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark45(-339.46201133362075,-409.30973848859094,56.62033035090025 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark45(-339.66303815258874,-476.81082527104513,6.770735933228252 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark45(-339.8717287777029,-475.29218088854526,100.0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark45(-340.0520613678668,-428.5723174223234,100.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark45(-340.1110053698896,-434.13228010831386,12.177178995081078 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark45(-340.22607133282855,-440.2207471718281,19.28296442211294 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark45(-340.24030939517763,-419.80812119453503,72.43190088508771 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark45(-340.29164689630716,-456.33098768289267,10.903489643814751 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark45(-340.32835537274025,-414.4194947973293,45.64792825945426 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark45(-340.41947353420557,-406.3436937955115,94.82755007230239 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark45(-340.6686791892688,-425.3966653722188,18.434661960900556 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark45(-340.80825695668744,-407.49013437248703,100.0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark45(-340.89372932821817,-433.3905473561714,37.83386721915471 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark45(-341.0659608333492,-416.5315438743188,76.02126826271959 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark45(-341.21498354086486,-427.7253960981135,58.1719923389482 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark45(-341.43410461002213,-442.8048154424444,72.62482948679647 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark45(-341.510923878506,-449.53850853793506,94.18138266590702 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark45(-341.7174893127336,-407.8862459206973,81.49710594616829 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark45(-341.762490323569,-409.2211485093358,45.13637685984969 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark45(-341.9653737184174,-409.25461392964996,25.258579087173374 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark45(-341.9918390240475,-454.49478322012015,49.82960510826449 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark45(-341.9993102241109,-457.3993807398319,100.0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark45(-342.14875322774964,-437.84648447202574,0.15401291403630069 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark45(-342.2974752436889,-467.1991317530363,66.14653407021868 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark45(-342.38175118379525,-419.2508305241277,0.31055619953843916 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark45(-342.4385535254939,-432.3962677213866,86.21342286899417 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark45(-342.550284714003,-433.46264099335247,86.58673062733314 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark45(-342.6825596306719,-477.18844626652947,21.161368735636273 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark45(-342.8016074498726,-441.7277065140588,56.9128026817057 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark45(-342.91077044838204,-438.21968709805503,100.0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark45(-342.9707233464482,-466.87210241436503,100.0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark45(-343.36588278246916,-465.414378425655,57.62517198575881 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark45(-343.47303146041475,-405.6301998359954,47.377536858584676 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark45(-343.5530737275334,-411.617695713184,39.859497327540595 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark45(-343.58244259326995,-492.11352274290437,0.6896074331522897 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark45(-343.647107328306,-403.6736034381848,57.542809203977384 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark45(-343.7708003002317,-448.20772266084526,100.0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark45(-344.00343185517573,-438.0442475312306,100.0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark45(-344.18370626183395,-502.9571154228727,38.21680029692715 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark45(-344.35055483762306,-404.24856031570977,100.0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark45(-344.3819263187546,-483.02047666064755,77.2274834944661 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark45(-344.4071620698292,-407.01377247478484,52.95692261270716 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark45(-344.5927994334782,-485.42795415357375,72.3742978867339 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark45(-344.60561039531007,-424.84959902773187,73.78343435002884 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark45(-344.7308186693884,-431.7334512421174,100.0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark45(-344.90426642866805,-439.4471065493945,61.045022160820565 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark45(-344.9817716441886,-417.1333609637381,19.260037886849332 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark45(-345.04858806671785,-453.9046658650276,8.428000770532634 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark45(-345.10354057052393,-435.2055166167963,75.87549674859036 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark45(-345.1068117472606,-429.2634073828979,-88.5989727023728 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark45(-345.30840574115473,-453.18357069062495,100.0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark45(-345.4923261821109,-414.4666050870803,100.0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark45(-345.54791553220906,-429.7459936646454,12.831723665861233 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark45(-345.6673459507201,-415.5255942157025,27.145949938959006 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark45(-345.81808162536834,-404.1884995345872,74.55160650773885 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark45(-345.98511128660675,-445.66628023831163,70.36150035977766 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark45(-346.0419579673866,-449.9590416113361,5.553601770900201 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark45(-346.1549928312439,-428.37973848829773,100.0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark45(-346.222404648627,-428.6382049321271,100.0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark45(-346.2896869629506,-411.075205294432,70.45512542661305 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark45(-346.39181901816477,-410.9053875010366,53.27679149382985 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark45(-346.58967208980994,-451.82487506072255,72.4511932952098 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark45(-346.7808008880197,-426.09967750120245,22.31761723514836 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark45(-346.80960502729334,-440.69319389019086,5.3035977991594025 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark45(-346.8096954234247,-417.186537873312,61.83134897317274 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark45(-347.0947401385613,-402.5838076186725,15.291204088401571 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark45(-347.1790327217566,-412.89675101805125,100.0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark45(-347.1817518668416,-425.0474016335095,96.19970275556526 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark45(-347.2013735961383,-413.38458851777233,42.73844229659491 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark45(-347.39490115761373,-445.60542218900764,100.0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark45(-347.57446275225993,-410.9313633124252,82.4853339732897 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark45(-347.7970399461716,-410.5558048967136,31.594886448601557 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark45(-347.8660048517719,-422.6170289955354,78.42082843448102 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark45(-347.90577966051916,-408.20254012912994,1.3112000925659544 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark45(-347.9225737041431,-409.47427598219025,100.0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark45(-348.0807483921528,-415.8480767805496,0.11431594240680454 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark45(-348.0966972885127,-414.14733742395225,76.50675564743904 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark45(-348.2084544508254,-398.67438489133303,85.08715972514182 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark45(-348.39534763165466,-408.08712276835524,42.62630414084043 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark45(-348.6990528901342,-404.0228853674592,10.522590698842976 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark45(-348.74176096296765,-410.41903559774545,14.407869842224514 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark45(-348.74458892411826,-449.3935503310758,100.0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark45(-348.7551261708905,-411.685884550003,74.13960152202145 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark45(-348.94571937368136,-399.87886291012194,1.2338894481589193 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark45(-349.1965277382135,-402.1003431876881,7.414311588209372 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark45(-349.5043447458716,-465.87521368994766,2.4639520824699446 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark45(-349.5700817168558,-402.60938107577124,66.18882136746043 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark45(-349.617579914658,-433.4067888443846,97.69595407804218 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark45(-349.8407384339789,-444.9485722533205,49.41167160877063 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark45(-349.9102794412921,-420.75011364660384,26.005889191972706 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark45(-349.9104649740576,-416.18410869583175,63.189223086553056 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark45(-349.9334543159337,-406.5177258513568,65.06971211291585 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark45(-349.95552237614555,-478.02373129095224,3.806697121943259 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark45(-350.0388322457052,-444.2641018044867,9.378651478490482 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark45(-350.1000160049734,-405.77758986929916,29.522988971383057 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark45(-350.12716080759986,-487.84475553533525,49.7420021305673 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark45(-350.2756242608598,-400.26406052020377,40.436881268244974 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark45(-350.2939996850181,-455.67565995574523,12.668983587799858 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark45(-350.297604167493,-422.95403180168944,98.61456944281238 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark45(-350.3612735370355,-491.7325157123689,64.31495674553628 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark45(-350.62153159025144,-431.44710988044636,100.0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark45(-350.6863528577091,-402.19085057169553,74.65920494626386 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark45(-350.7474895577585,-399.70570276710765,91.89090859288896 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark45(-350.88823421377424,-411.3957615106391,67.1149179476636 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark45(-350.90749774839514,-415.95703177908615,0.6166963182874525 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark45(-350.9767623445008,-408.38468724459057,22.987433946177944 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark45(-350.9846217079343,-422.73288168096536,0.9934482335637256 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark45(-351.0048084720535,-435.5864002417578,16.22793040743764 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark45(-351.0317002205794,-425.3341552606955,65.68627026516762 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark45(-351.05641634225987,-443.82862656022496,98.4985123320792 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark45(-351.0795542349148,-429.4100871852657,54.41420933908901 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark45(-35.108750906157525,-720.9078551026432,81.04719501955046 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark45(-351.09042213678987,-436.2944667568612,100.0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark45(-351.34702528175177,-436.7712694276324,100.0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark45(-351.4491030216332,-432.23630205972904,46.00262225036798 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark45(-351.4593596095051,-417.87739304161823,100.0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark45(-351.66382286954035,-460.95706598669364,51.934566491869376 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark45(-351.7137014015465,-437.6338457342342,14.259578546972662 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark45(-351.724884505912,-408.05305931401216,34.04163098932847 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark45(-351.86177388947317,-500.426938455783,100.0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark45(-351.86974724787194,-433.56819001508904,33.197399111657546 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark45(-351.94080508379346,-411.120387535497,59.516720271406 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark45(-352.0935282806529,-394.6025699108744,89.34388384184462 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark45(-352.22650325021414,-407.47280221576017,97.23031184113177 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark45(-352.25938603020035,-403.33888673031186,68.0013628924714 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark45(-352.3826007158127,-457.08808685280593,7.10385911632973 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark45(-352.5789000920246,-436.42793405040095,46.50931368330916 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark45(-352.6942729079479,-411.5265893696065,64.27916752043413 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark45(-352.79159302948136,-407.5513866995168,50.60413393932302 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark45(-352.8149547338639,-452.5419394030208,50.04991287386014 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark45(-352.9268444231888,-421.8399965218701,100.0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark45(-353.279154339493,-430.99246305236176,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark45(-353.35621443669805,-458.5118652627556,66.36169946930771 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark45(-353.4042193303637,-416.9038110294509,100.0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark45(-353.41426050964503,-401.7968107834588,13.573692148115285 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark45(-353.5733631831623,-476.8217676873594,100.0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark45(-353.5756913537647,-434.63502979997133,20.365571903817113 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark45(-353.9565643441238,-395.2755099709218,23.955399431326413 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark45(-354.1464321071492,-413.4609150492733,62.45270935601974 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark45(-354.1721283687254,-409.6523892896287,4.421966857808428 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark45(-354.2904498706972,-394.8464458242593,100.0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark45(-354.4960454917223,-457.39945306083416,56.0927523506401 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark45(-354.52889226166525,-440.4402348839304,95.91497079516219 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark45(-354.5882177271511,-447.2659902715357,65.07068089588947 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark45(-354.75526676988403,-402.3920240662617,62.38874084911578 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark45(-355.0579305736352,-440.2683530426794,35.13243542727247 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark45(-355.2203434797443,-413.89084836664324,11.298074264071971 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark45(-355.3319568464794,-416.8120602267665,100.0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark45(-355.36750299567245,-390.849438614151,77.28464534782651 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark45(-355.4165046296125,-444.12092459107294,24.322459443383536 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark45(-355.4385503824275,-475.02149622400293,23.49379527918056 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark45(-355.44769944246553,-393.18451062241263,100.0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark45(-355.6419341144222,-463.22220292677855,17.566658752918784 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark45(-355.6457167157608,-394.4362542254669,93.64285327910474 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark45(-355.8805409716212,-399.40646889298836,1.8952784448613897 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark45(-356.0103265851635,-436.4845996966569,85.49733428637057 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark45(-356.41656696851,-395.84884841121794,84.93798713627217 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark45(-356.45770524623725,-419.6068389500493,76.57547097809228 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark45(-356.54282930507475,-395.0740999821871,64.4689149923006 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark45(-356.7693606295007,-419.9273089171335,76.16085705636709 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark45(-356.8755404163289,-428.7820011861163,92.4994075102723 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark45(-356.88973885356614,-440.2520581333759,100.0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark45(-356.90910874009097,-413.6490529257005,46.360067427499445 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark45(-356.9380769684753,-389.7547144353806,42.8719109767016 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark45(-357.36030906233634,-417.1964169747587,100.0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark45(-357.4359862992298,-433.9860100613419,8.394502878129842 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark45(-357.6526010757549,-402.3780503066305,70.53954643924197 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark45(-357.70505876434646,-459.4230452385111,96.63550916694817 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark45(-357.76919380001226,-408.59888625722346,93.65974466932278 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark45(-357.8800892643869,-445.7285573265116,85.63955782982129 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark45(-357.95189884915493,-452.76663840766065,82.79950761380971 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark45(-357.9768783871707,-414.8882646439292,60.238848336081475 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark45(-358.0818862041441,-413.27455463943966,64.53601737442962 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark45(-358.2510548002721,-396.25171881800253,86.34794351688237 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark45(-358.3028805997391,-440.7950562916622,31.16656494262321 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark45(-358.4738757011321,-417.66037382928505,22.13405745625097 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark45(-358.5673552794187,-454.46862129105494,18.323100905528463 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark45(-358.6693297283158,-397.0982578864874,100.0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark45(-358.8171455396598,-482.2487254507996,31.695749920546774 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark45(-358.8502281188118,-427.55455436767113,75.03027803681914 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark45(-359.02368239598474,-427.90659079554194,85.92267032244689 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark45(-359.21029783628364,-414.21748652463145,25.6835299664901 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark45(-359.4540377592409,-389.5138765444557,100.0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark45(-359.6537376246952,-396.1672902188126,14.084371110362355 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark45(-359.82766563373747,-402.84254249450277,37.14219351136822 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark45(-359.89815420487616,-423.08469135874174,39.94460564446521 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark45(-360.01272521502483,-393.9747670453658,68.11656212699404 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark45(-360.0416764044197,-400.1757647525803,38.79739748873553 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark45(-360.2038667533997,-389.96633586325777,26.645661470920643 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark45(-360.26605798526276,-462.2591925599,94.72556065939875 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark45(-360.31436103833613,-438.34057048788867,14.319462250708991 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark45(-360.5281370542215,-389.1306876952853,2.8669404281687747 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark45(-360.7469087324152,-387.2415205024947,32.19626115813497 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark45(-360.8978709081627,-506.1017927892502,75.46673871178743 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark45(-361.0561021373953,-427.78712559233537,10.044713159496482 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark45(-361.09398165562726,-445.2672191647949,20.422774985949772 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark45(-361.1444990830645,-440.2774878145838,51.65038852096836 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark45(-361.18926139449763,-406.1432471583624,4.800599981721575 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark45(-361.6238554089989,-469.2097746711391,9.242574013811947 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark45(-361.67469943640475,-404.65437510122183,67.1760623868609 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark45(-361.73118204110324,-393.9259278551975,9.05064652361089 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark45(-361.74102960726583,-406.69548422651064,69.3705047011446 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark45(-361.83785150059464,-412.0216420855297,100.0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark45(-361.87194401448113,-424.24525730990075,100.0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark45(-361.88653965080374,-394.7969649111087,87.40717059029498 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark45(-361.97108620849,-407.5970548959502,55.137122110669594 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark45(-362.061313394988,-399.99829902524505,100.0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark45(-362.24799079611194,-410.8891088410726,97.74943504036182 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark45(-362.3155233801547,-442.529097378437,8.809623078712676 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark45(-362.3482222896891,-388.966000899055,14.062158603829289 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark45(-362.4245605060924,-441.1992461202933,10.837465238930804 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark45(-362.46251956647546,-444.0000731075955,83.75970288720066 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark45(-362.52392220593526,-395.11169030904955,20.978303160907586 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark45(-362.52594334831076,-433.88466948331705,9.662379471044218 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark45(-362.58269762514254,-403.2946009126786,62.35268624900672 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark45(-362.60389908930523,-393.0178535143329,34.696815398381176 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark45(-362.94979415985665,-425.23869248146866,96.03953729024394 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark45(-363.07789582852126,-431.34357085121496,32.67541696701076 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark45(-363.1766256014325,-454.6403320450081,97.20975380126796 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark45(-363.2501736032909,-392.80343257922385,94.64002521921077 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark45(-363.3584036692355,-382.93010506305586,100.0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark45(-363.36049440638544,-388.3550438037813,100.0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark45(-363.36160631724783,-395.65256792828717,20.092554504971744 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark45(-363.43439937251827,-383.53301201766885,9.366759617684224 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark45(-363.453845227647,-391.7684026610977,100.0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark45(-363.4623907043395,-427.03483174627297,14.191700092817854 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark45(-363.5201512482564,-391.84660669554967,38.03976704652237 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark45(-363.5596427188844,-447.27910957762276,78.3135457407841 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark45(-363.5974430585406,-419.39299900216906,21.676496425999332 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark45(-363.73417071557526,-415.11061652609163,7.778989478081513 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark45(-363.74295274294946,-429.24480976237953,74.59044893865678 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark45(-363.8040907502816,-416.06724859831166,38.64603460636505 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark45(-363.9712797204975,-388.3318916731559,45.8714427480908 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark45(-364.0860704847369,-397.1969123404075,53.5744323089657 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark45(-364.2845835051687,-403.692897309726,34.66046342977123 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark45(-364.34227704716926,-382.23847669687206,100.0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark45(-364.51124739612453,-448.7483954187911,33.158028852659555 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark45(-364.5320729759535,-400.88868347023487,100.0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark45(-364.7043437243226,-429.5824619909097,95.91194829086987 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark45(-364.7564714230112,-414.9903468556079,68.96279493368476 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark45(-364.9310386028043,-454.36091145411973,70.66375548753399 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark45(-365.0348809011904,-414.3843043506596,26.81486162655007 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark45(-365.0464202190415,-444.15162935839965,95.72291844240073 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark45(-365.05675518675935,-413.6445008308249,92.4200266638932 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark45(-365.05751869080325,-415.0301724684899,96.19686175456405 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark45(-365.0776849395418,-413.90262713063225,89.57989066944111 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark45(-365.09485438685186,-405.6976112094774,100.0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark45(-365.10121504155217,-436.43755228955524,47.97512179376173 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark45(-365.2662904530753,-404.515701912598,12.218114865618475 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark45(-365.4487897977641,-441.8255197402797,73.0026020319576 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark45(-365.56566273842236,-388.59536013584903,17.264215220671034 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark45(-365.69268425288095,-415.9285332043273,100.0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark45(-365.70822190801755,-448.15582413125526,0.0011272214292838909 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark45(-365.7929394071958,-418.1168086104601,39.74750759590694 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark45(-365.89179362855526,-390.8073216865,82.75951994654793 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark45(-366.00986965484503,-383.2542279949912,67.35472992603005 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark45(-366.0295695429806,-384.6886042554201,100.0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark45(-366.1191184926937,-392.28205377613233,24.819277962028536 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark45(-366.17150782809404,-382.10454652098514,93.26049345096183 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark45(-366.4280480914716,-411.1432237768855,55.16794750270333 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark45(-366.53792961275866,-402.41072619584276,43.2584779893117 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark45(-366.54079614435517,-386.7026913155335,39.216858725284354 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark45(-366.5888260477529,-432.57761297952055,90.27503328863 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark45(-366.76882970511065,-382.6688407983699,22.671969081836068 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark45(-366.8019268008492,-417.3340914406258,46.031222628517156 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark45(-366.9609405376856,-474.2393607556272,17.564667015427958 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark45(-366.9664625198021,-392.0657418774184,68.2694503646398 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark45(-367.0542050394476,-387.50279254488794,100.0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark45(-367.09808957384746,-380.23005078626164,3.9207488257835053 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark45(-367.3504778178091,-386.4272993037815,7.65937229089802 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark45(-367.4124337841873,-385.45774893241105,75.8065288218088 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark45(-367.8332719825086,-385.3457535040069,35.898465601395 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark45(-367.9491901147081,-393.0179755541895,17.272929211938333 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark45(-367.9755360043643,-396.4195026683857,10.322323540172349 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark45(-368.07199545983667,-384.1395064624426,11.328670261335304 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark45(-368.13523328534563,-382.0562301197254,34.49393044126319 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark45(-368.2543018559473,-419.2710147863346,13.583269255253256 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark45(-368.31312729058175,-454.13839875487076,73.3611538080128 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark45(-368.36015926550334,-385.5329966212771,26.436248067910114 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark45(-368.41028844689504,-403.90960490903166,25.92939263185417 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark45(-368.4311942094584,-379.1176065952527,28.75480032960732 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark45(-368.451845983136,-389.20831991792403,25.694017535022667 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark45(-368.4537355056379,-440.0042182746109,30.926633225462325 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark45(-368.5104112044535,-380.8582986536557,30.143282158258074 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark45(-368.85093941536394,-420.4676190548648,87.08021464584237 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark45(-369.1418286995253,-386.7885259010383,100.0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark45(-369.22084524042714,-377.56709439141645,100.0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark45(-369.43493332633966,-455.85200618370953,100.0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark45(-369.48584348205907,-420.20756295898695,18.58396480559928 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark45(-369.67832646911876,-394.00382986338224,74.11025692515119 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark45(-370.0068046627437,-446.85112783097907,85.9229813259829 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark45(-370.0553558300512,-403.7253898618347,100.0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark45(-370.06487671702325,-402.85518318463585,49.94494623520154 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark45(-370.07938830536887,-404.87809616576175,63.77623343636111 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark45(-370.1057935483602,-382.15100996708804,89.54626333088166 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark45(-370.2025515068472,-383.77601996724775,100.0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark45(-370.737589720387,-381.35316651186656,26.25974904177933 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark45(-370.80330088062925,-378.89061554405237,29.88297980501953 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark45(-370.8108908019689,-395.49321331203464,89.75609458930606 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark45(-370.8608147575758,-417.91209575574186,20.52476595389581 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark45(-370.91260599944576,-397.92300432672425,11.406757780075495 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark45(-370.9458433085916,-398.9433784124379,38.34372401439995 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark45(-370.9560098984571,-422.7624846574169,4.644399741298727 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark45(-371.0097347458126,-461.59592680037315,52.41960791004024 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark45(-371.1318380086975,-387.644832828928,100.0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark45(-371.3999225120325,-383.1653668393735,95.85768025803625 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark45(-371.4099887753656,-375.053516791673,24.545074708045107 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark45(-371.44985973575854,-433.3640812103846,100.0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark45(-371.8625254104641,-405.25511049574914,100.0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark45(-371.9496270061216,-407.3006650026208,83.34415014410425 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark45(-372.02342658140776,-379.20932183509274,11.10658098258368 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark45(-372.07265229122436,-394.3539121521309,100.0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark45(-372.11938593659625,-410.74978186246625,80.54420447988778 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark45(-372.19871238958507,-450.425848527817,16.42511373282916 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark45(-372.31127213402647,-415.3126692358887,9.96551181986544 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark45(-372.3824874846723,-400.2115723914372,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark45(-372.39768450558944,-399.61530832692193,100.0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark45(-372.53387579528965,-404.3864310269983,39.98452938579223 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark45(-372.7776699833852,-424.7917643652552,91.16532739540312 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark45(-372.8475382978118,-391.8502959637593,71.57307875491682 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark45(-373.0580608207499,-404.9923100609342,97.15739331580534 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark45(-373.0961810883713,-381.0158571494821,99.4752573276721 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark45(-373.10029637936856,-427.54283971494857,23.213746487634367 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark45(-373.14870604723154,-374.2394319350872,88.9999010859475 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark45(-373.20357446201376,-402.0073393548936,53.66037820982555 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark45(-373.5734947514075,-410.09462643595106,83.00122570093242 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark45(-373.62221221450505,-391.0323328648326,15.900964469394083 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark45(-373.6687270675968,-380.7190523730511,100.0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark45(-373.7352604354146,-405.76176511905044,54.63804401245639 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark45(-374.0175206103584,-405.5221645884095,64.92758691652614 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark45(-374.0395826769115,-456.19619398535093,25.531954165988097 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark45(-374.13271533205915,-410.8142801435275,48.44139532878009 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark45(-374.3194784674711,-485.7869072653134,8.576983055967432 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark45(-374.3504642463469,-387.82137840615155,100.0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark45(-374.4937841804796,-382.4857425491943,100.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark45(-374.5014448473111,-383.23096060549955,59.13244799109535 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark45(-374.7226511080477,-395.5025218487151,33.58708350326694 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark45(-375.02264417009684,-371.6973171736887,100.0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark45(-375.0620602434265,-409.2322177566268,54.36885481427953 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark45(-375.1657725222952,-381.9865841844176,100.0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark45(-375.18453792974407,-437.8790474035169,100.0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark45(-375.5697284786705,-409.44928428075576,19.198978222590952 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark45(-375.66942790454686,-390.9693618649978,42.724565768695754 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark45(-375.7435800719636,-373.5765205863294,76.09691156066134 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark45(-375.78528307058303,-378.14697347454745,96.2012092243013 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark45(-375.8366174408579,-394.889843959734,85.59740198237333 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark45(-375.85177419834724,-389.7324732490182,15.169051223737199 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark45(-375.9343191147309,-389.7171570469567,75.40506793926158 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark45(-376.30636842905074,-422.5793944022324,22.704065355453665 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark45(-376.40668963153297,-408.29978902166715,35.445032150310965 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark45(-376.4219597404948,-411.2982084562687,46.841241048456624 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark45(-376.5418262062079,-381.7319396563999,94.92224161795 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark45(-376.5424188449378,-416.40093095709796,32.922382931591585 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark45(-376.5782796176055,-389.8887129645112,83.87881631975495 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark45(-376.6018732745793,-397.1276646337423,66.01641393575585 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark45(-376.60931273664437,-408.359613380546,17.051069058949125 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark45(-376.77501618683664,-442.6550235708523,55.49918533091261 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark45(-376.79382904412154,-376.9294074103036,100.0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark45(-376.83032388360925,-410.9188254085869,99.49538340327211 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark45(-376.90122766591304,-380.92723259455016,33.48401265342048 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark45(-377.0154034119775,-392.77520334476446,73.00148188558907 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark45(-377.05808945989764,-375.6420628437459,100.0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark45(-377.1886140141018,-380.56506031919065,8.390489595037167 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark45(-377.198891695529,-398.58863907871904,100.0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark45(-377.4750667489016,-373.13278587220447,34.93189495795136 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark45(-377.6136529644833,-410.3680669719707,2.4290240775273872 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark45(-377.8332460587148,-387.11388867378037,10.951293209146499 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark45(-377.8506863641927,-374.3547600484798,99.69483115305567 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark45(-377.87947862652607,-398.8097235037327,77.13067946584599 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark45(-377.96059265032295,-372.8365606519719,100.0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark45(-378.04203834230026,-384.3063851488445,100.0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark45(-378.12298769284934,-383.3997657932772,36.005898966533266 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark45(-378.1894154680898,-397.440388190895,24.915168026556785 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark45(-378.21256259317835,-377.09852499849035,43.41009423830934 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark45(-378.3329931726319,-425.1489564296262,36.20336919943776 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark45(-378.40411884864045,-387.64620970847346,81.11889110166885 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark45(-378.53689422805786,-372.1308760933599,94.10252855189862 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark45(-378.6162866640181,-382.92424860813094,2.4757210156905103 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark45(-378.64046351643316,-388.6196835571346,15.514497796754512 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark45(-378.742183593931,-417.5444008659684,5.492404554215938 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark45(-378.7633784507455,-435.46092392061917,75.62912692836443 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark45(-378.78835669256716,-372.924761229913,74.74262161068864 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark45(-378.7924764254535,-393.2240173398086,100.0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark45(-379.02498329669714,-372.3681538409976,50.606675329126205 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark45(-379.08723919163094,-380.0772375164845,3.6499995936639937 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark45(-379.1435179729543,-409.162075900116,7.445730239747704 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark45(-379.16371582136287,-380.6294652231792,0.9056398171749578 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark45(-379.3782447014102,-384.8344868820125,51.95782680091682 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark45(-379.65035965892923,-368.8786560969181,64.97447661937721 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark45(-379.7115211043039,-400.82590562632225,47.2672546334972 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark45(-379.93821016509725,-369.22317121395986,8.866633344041347 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark45(-379.9997628108697,-422.365882662823,100.0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark45(-380.4030763735559,-378.4214623810022,69.94958037206723 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark45(-380.42209091843915,-379.43312335583926,92.60194135828738 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark45(-380.458817778106,-428.46570342740284,86.21837888677683 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark45(-380.54573089247134,-369.6430747463669,63.65603011581422 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark45(-380.60086855407957,-404.8775365490077,21.16605287682158 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark45(-380.7451629442408,-400.1135070908322,100.0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark45(-380.8411422314705,-380.5052577244098,42.379877444647406 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark45(-380.9926028704126,-406.9869916426859,34.86434574788714 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark45(-381.09398014035554,-369.28682769821387,65.4046944012187 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark45(-381.1760112612694,-390.836840939491,97.45861910055052 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark45(-381.25006447135155,-384.9306713414141,70.35164042900558 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark45(-381.35894489123444,-373.5450218887831,80.36734586233717 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark45(-381.46213049738486,-377.83157048552516,37.27069078259527 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark45(-381.80110128816057,-412.1043582571771,8.081306689821199 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark45(-381.81620009792357,-367.3442835950859,42.6764188960469 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark45(-382.03814934248055,-411.9834397733414,70.71320217479177 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark45(-382.0543681028727,-375.6532231245661,33.44422389388669 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark45(-382.1948475783082,-376.8154159230297,100.0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark45(-382.46327863995526,-411.23248373962684,31.874214336097822 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark45(-382.51268967725844,-394.31367976302744,4.389857747371352 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark45(-382.5258362093328,-418.4520509025738,20.489934144370253 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark45(-382.5883714295943,-419.0334688113428,73.32382295160897 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark45(-382.75391850757245,-381.4063435990804,54.80085974217826 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark45(-382.94462807253956,-447.898613846183,92.56092529796996 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark45(-383.05781987875565,-470.4033850371101,68.39526551583884 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark45(-383.1655000254934,-423.28253533893616,100.0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark45(-383.16562312736306,-408.4545658564478,82.38487660194892 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark45(-383.3141822325991,-389.3170514433307,15.797045950282126 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark45(-383.34556236928233,-374.2532052011795,73.72685940756362 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark45(-383.35677707818826,-387.2574844050851,21.368714746334526 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark45(-383.3855362818735,-416.50891632154685,2.3159734383010715 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark45(-383.57713691170835,-421.69011406609906,29.662490624437766 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark45(-383.62569437556914,-380.43676346537904,2.2017301636321633 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark45(-383.6485760841006,-366.48636902645484,83.90032889018724 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark45(-383.6777069495736,-363.3999323727513,38.32361663746872 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark45(-383.7044386833071,-366.18846643792983,26.666489172990367 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark45(-383.885467058332,-374.698109893146,91.68660625870189 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark45(-383.9163283676902,-368.8391788772667,0.6309014882570239 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark45(-384.0418310827367,-429.2782030434831,89.79767918441925 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark45(-384.0980159498435,-372.3625605400502,38.08873735816408 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark45(-384.15768977271085,-414.6285909422986,38.871519164846035 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark45(-384.3107177347674,-366.4254296178676,100.0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark45(-384.3264730502896,-361.7187391780913,19.790992884563842 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark45(-384.4955873325933,-415.07244425989074,13.701834766181648 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark45(-384.54610183704165,-366.92994106247585,100.0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark45(-384.59287625112523,-415.00903697110056,81.93756881973857 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark45(-384.8128482748134,-440.89882394583657,25.642007311985566 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark45(-384.9193227402413,-390.0930030779545,38.71571367721444 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark45(-385.0702397200853,-401.1573918730554,27.473573267927193 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark45(-385.1821497657129,-375.0437423844134,100.0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark45(-385.27323036951975,-396.0293529052069,97.18086707441981 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark45(-385.3820321717972,-382.5196268402729,41.16154571414006 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark45(-385.4775227149427,-439.08638364772867,33.04908983028875 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark45(-385.5920502617914,-360.978095633391,71.35660160037355 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark45(-385.6607254548689,-360.6301338122892,36.5272846602997 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark45(-386.23897720387265,-359.86060635572807,90.35448448500753 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark45(-386.2501175047674,-365.15599634617956,53.69537437250704 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark45(-386.2590463673871,-392.62353055879925,67.58707627724684 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark45(-386.35506316946135,-371.15353459589517,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark45(-386.35737057225475,-364.94527825339094,7.519833075216383 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark45(-386.45197525031637,-373.1951209920633,30.182497621788002 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark45(-386.63200879325626,-414.7732278381897,80.6243197494152 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark45(-386.6944361727293,-389.86495410147637,100.0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark45(-386.72088600526644,-368.19875174552055,100.0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark45(-386.86579560949355,-359.27233807227753,49.822520337209454 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark45(-386.94150960998707,-363.52828607865,13.982861472769798 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark45(-387.0415205692891,-393.3442604735013,26.31748767168058 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark45(-387.5510467812825,-366.3621054460944,59.312364321848065 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark45(-387.735856333259,-358.7076979268828,3.9726763435996224 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark45(-387.96959262711016,-377.2299956364146,53.529772222417726 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark45(-388.00732160016895,-382.19544273900345,35.1047541530491 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark45(-388.1804338800746,-424.0029382221802,66.16244881557907 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark45(-388.271410014954,-417.8100677975645,44.331340165658226 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark45(-388.7454864886061,-412.5357955602145,14.176457685055084 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark45(-388.7849605073274,-374.23046564978074,27.107706253006313 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark45(-388.86165979296015,-359.0358150807309,85.52573289477166 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark45(-388.9469262429957,-446.8336310930624,21.610970687328802 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark45(-389.03518461288866,-371.57491835539787,94.77802440040736 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark45(-389.151109310735,-408.83698231122486,49.738478502932594 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark45(-389.1817308603444,-373.56449768460703,67.71325735064329 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark45(-389.1952311006553,-374.32651460851173,92.65246290721421 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark45(-389.2044939245851,-426.67225194027475,7.300179501571691 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark45(-389.3290760009994,-370.4227747550438,12.293159430250483 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark45(-389.3671367521876,-371.04529679747804,12.551776337551559 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark45(-389.6193973898729,-378.7138532574481,64.36886396572282 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark45(-389.66130892352857,-358.12565619644045,4.2174784527451195 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark45(-389.7208017255243,-358.5590100607078,100.0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark45(-389.7957356652836,-406.6854076658919,16.940482322484158 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark45(-390.00404997078675,-365.6918361708854,96.15982760748466 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark45(-390.0519913149502,-370.74871087033375,100.0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark45(-390.05999774907207,-364.60730577148604,85.79276453161381 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark45(-390.1354245976465,-399.21102383029415,20.916504453021375 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark45(-390.1610116109187,-360.52963206614476,66.11097663192916 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark45(-390.17852355223,-376.7517836285918,100.0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark45(-390.1911238173001,-386.59164954791703,94.07951975017241 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark45(-390.204438996342,-368.7777520012265,56.598253807071245 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark45(-390.21434320109097,-384.41627982030155,26.192418971128802 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark45(-390.29464821821256,-398.403731250541,52.43665324055732 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark45(-390.29722210861075,-371.9771067706004,39.63386493859906 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark45(-390.4845537953152,-379.1090781328902,72.12907582391398 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark45(-390.55104396346894,-359.53866047665787,50.685873133058976 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark45(-390.5663678888602,-376.0060106706866,11.872778826324804 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark45(-390.7033388564416,-355.776569823862,60.663748205723635 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark45(-390.8767397081258,-371.42755579640635,96.00844223646416 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark45(-390.99974331583167,-356.07386743291204,91.7099876392297 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark45(-391.2965907914688,-372.469596717928,1.2845327476139943 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark45(-391.31654753086065,-382.7669750493427,71.98891220237968 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark45(-391.3961615891089,-398.50232019308834,7.860942105373653 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark45(-391.63001031910676,-360.45112634327904,5.605741459809039 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark45(-391.7100876654261,-397.27968116632417,68.76250836848706 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark45(-392.00808578892486,-369.5848795471209,81.73218520193177 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark45(-392.1470222586538,-381.98244858440626,18.69245431827879 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark45(-392.1710871848431,-386.4733256713135,8.841019033866957 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark45(-392.24671835291474,-385.2828647451245,49.01487170720455 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark45(-392.5456469265525,-399.5734527493713,28.732553737507573 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark45(-392.5696605051659,-359.311891869045,84.97579063939861 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark45(-392.58212949069105,-394.57846394927833,100.0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark45(-392.5875117332343,-384.62696502036715,56.93524412354145 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark45(-392.61311253011115,-386.978522291892,33.02989194172213 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark45(-392.7092801210815,-371.49860040862563,15.492585839192131 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark45(-392.7614270031038,-385.5523272657497,100.0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark45(-393.01874153468776,-353.9012006269197,80.61806416499942 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark45(-393.1300452374222,-364.39475831212815,43.82996952063348 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark45(-393.2922114952706,-405.0484298715685,100.0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark45(-393.36164522225414,-355.1289730332883,75.83245425757346 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark45(-393.5344028774872,-366.4400043414739,53.149904906684526 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark45(-393.59787435090385,-386.0814069088215,39.89529103258553 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark45(-393.6008845669312,-374.28983881576045,100.0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark45(-393.7754703027798,-375.28869026741063,12.9509437986014 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark45(-393.8236424245025,-400.0212629952245,77.95174930047602 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark45(-394.08020123669104,-354.5241839845273,22.074707047985925 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark45(-394.10854256567694,-406.73838979614965,18.047638287417826 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark45(-394.1254226778563,-386.3892976535944,29.35884617109454 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark45(-394.20983702024,-354.2964488634181,62.17822400762222 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark45(-394.33821478952643,-357.83504733761083,100.0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark45(-394.33907933292096,-393.4495782200471,77.56437510345745 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark45(-394.40769330827123,-473.61620679670455,63.194667652478984 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark45(-394.47230492499796,-404.41329973635254,69.83427099560812 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark45(-394.5164760183444,-401.8573973255599,64.85077400976971 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark45(-394.52187679325647,-390.2401285555513,79.45030797573312 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark45(-394.5681527389247,-408.35828937035205,69.06073941550042 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark45(-394.62906665736193,-372.14394380573805,31.27765068208467 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark45(-394.7289369589002,-389.0702786810049,73.33143999089819 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark45(-395.0370000587466,-361.7912708376081,4.554378027768905 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark45(-395.24986110034297,-411.1223264457042,100.0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark45(-395.3278123982218,-364.6497341774721,82.53717069944616 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark45(-395.35554563477405,-356.786303266744,48.53297170296025 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark45(-395.8761716133998,-406.97203328376395,67.8086666755894 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark45(-395.89767621031444,-373.33999608875536,77.27077618243919 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark45(-396.13813771099694,-365.63891360906626,66.05832953691504 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark45(-396.1541111415362,-367.2286833945795,4.077838447753493 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark45(-396.34264136992505,-360.34467034128534,94.13715676316315 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark45(-396.4170180234716,-415.98300325267945,66.72399717806101 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark45(-396.5812718134725,-352.9002954326792,16.60074758876445 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark45(-396.81908397677216,-354.52032606615796,42.71424524055428 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark45(-396.91116439403135,-357.69871678497316,25.253143845674714 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark45(-396.93142126216253,-370.17293083771875,15.211581372521962 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark45(-396.9962202321697,-362.9410607263798,100.0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark45(-397.067388558126,-363.9060504044903,58.80131576492987 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark45(-397.1432516960926,-388.23679531126766,100.0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark45(-397.18093402675146,-427.6593398407543,50.08366058888086 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark45(-397.2329240213734,-441.3045098198815,17.406676406894533 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark45(-397.3475868176738,-358.21569624630524,81.90758037417456 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark45(-397.35954343066265,-407.0454292299754,20.88113948080634 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark45(-397.4327256269756,-349.46293728685015,78.06723692029635 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark45(-397.49502194877823,-394.66309850664675,11.968887461426661 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark45(-397.64346374592367,-410.79196514321285,77.04028071686255 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark45(-397.6987596229858,-416.40723132939934,70.61034638171739 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark45(-397.76483809633334,-351.8647897321269,81.95902335310362 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark45(-397.87384458786585,-357.5393243947604,80.2302010210916 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark45(-397.97136467096783,-439.6031031932573,62.725009863165134 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark45(-397.99213610749365,-391.54146860761796,6.612160888727601 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark45(-397.995790832412,-395.6616584004729,17.92810988415677 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark45(-398.04967243882066,-373.06613645532093,53.61563041486639 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark45(-398.11610578207484,-380.78871042033774,20.163053378280637 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark45(-398.25080607430976,-414.13665548290487,100.0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark45(-398.3875771825716,-379.34062307521424,8.110546047590688 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark45(-398.6385602565765,-410.1483108922789,9.805381275691346 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark45(-398.71361967530277,-361.36407229338954,78.03849265819741 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark45(-399.01759493889784,-401.8266114765827,2.8525978315419707 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark45(-399.0393137491823,-354.5247310797964,90.01252197078372 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark45(-399.17588694591905,-357.7806881028144,39.42777071614279 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark45(-399.18547753060153,-383.5605626050723,98.2756062637418 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark45(-399.19643280434343,-401.8008207733295,99.22997883953732 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark45(-399.2885680860026,-375.0720811073917,9.564144249306136E-7 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark45(-399.3250270003489,-364.61115682484836,79.05867052975236 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark45(-399.43131678614156,-361.66628331573656,12.11572843800188 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark45(-399.4699302554335,-349.39022096775994,81.39752532040195 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark45(-399.6960110932885,-398.79377740690177,2.5761070079902737 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark45(-399.7204667111674,-377.8337545682944,94.09614662630392 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark45(-399.7369545133903,-406.3694423055955,34.70082472361844 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark45(-39.990559946029535,-708.0259123755519,2.8827636829904577 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark45(-399.95228834095053,-398.93202563303316,83.95814996881484 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark45(-399.964041083824,-413.81919480885085,100.0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark45(-400.12767743112266,-410.75010817192924,96.94366393751147 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark45(-400.26795533094236,-363.8322061414861,85.74905439107188 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark45(-400.5578583867821,-368.5807316843293,30.19126534798076 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark45(-400.5629385840067,-367.21006681407925,28.784265728440175 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark45(-400.5698973936173,-348.07380190490005,31.95707944601 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark45(-400.5973031962729,-380.6538663789171,14.192558710444843 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark45(-400.6172275742436,-416.02515153386594,25.71742869488493 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark45(-400.90272711156433,-359.9525991168819,8.314444405533976 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark45(-401.09789454461367,-406.0163902706221,68.06530821549981 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark45(-401.1207391601075,-359.66229680896174,94.15969153805628 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark45(-401.15122045244465,-354.04336491666953,7.406068357985291 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark45(-401.4035621958187,-407.9159748157849,100.0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark45(-401.4245503376064,-383.8555242868535,28.328437027827192 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark45(-401.4718563316799,-362.55011412344857,22.062083560851818 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark45(-401.8092374854958,-364.7271004772005,60.95198297710388 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark45(-401.87297303555266,-349.8901018319583,15.513427504031824 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark45(-401.9745543475312,-350.0925104259929,72.39461485262214 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark45(-401.99133383941347,-352.32437748123044,100.0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark45(-402.02306703587897,-344.5903662770855,77.10477835230816 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark45(-402.028484084775,-353.88187684380557,68.29809005159677 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark45(-402.1066323509599,-350.5924224814629,11.146285650237154 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark45(-402.15054364631396,-351.81373443065945,6.5019086881532075 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark45(-402.3138744958835,-375.2617001046777,67.62014896561973 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark45(-402.3169768709881,-351.462728414648,83.01395488063636 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark45(-402.44944691261446,-368.1795915945442,100.0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark45(-402.44979056640096,-369.6728128266218,86.84840511343074 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark45(-402.6851562079775,-369.2795482114288,31.939319992743833 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark45(-402.6989345486257,-349.7048027604165,100.0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark45(-402.7318481653853,-379.85799429233623,70.82898143245612 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark45(-402.82409620179203,-352.04536998687297,4.455734842144494 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark45(-402.9345058421957,-387.06404306801676,28.953794824967503 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark45(-403.087737565849,-361.22917047356947,27.917928292099873 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark45(-403.32375630369955,-354.6252633730335,37.31398217270575 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark45(-403.3432966905161,-351.704185299987,50.98101416581156 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark45(-403.3545112538933,-343.77104257858576,78.17553060450844 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark45(-403.4102377529028,-350.38900882425077,47.561281033156234 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark45(-403.4732332893554,-372.0385731895808,28.5625270716977 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark45(-403.4778225064196,-350.458534184916,20.474594750862877 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark45(-403.64863663290265,-411.06655046213353,13.004075021519483 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark45(-403.74610516684606,-343.4516761190003,12.570554126308181 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark45(-404.3257687983121,-426.8737496249261,6.799938721446324 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark45(-404.35879689679757,-341.72271113039665,42.2949435652057 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark45(-404.3728264509276,-348.6710886398931,43.07949536372283 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark45(-404.37897241218644,-404.6525159313965,52.67960211731986 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark45(-404.63251928880345,-357.1300956659122,100.0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark45(-404.8987789066519,-343.91309961412776,20.100382009314615 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark45(-404.9101106945703,-343.3993448927656,67.87909105750288 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark45(-404.9768225830957,-364.63640040815926,35.40176710901537 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark45(-405.1189695772975,-346.16578760532724,90.23932984941149 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark45(-405.171328322554,-364.9778267805368,85.2667628148684 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark45(-405.47173145079427,-342.96653299321406,15.524424206603385 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark45(-405.691970906164,-350.7789167237903,62.29627364985754 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark45(-405.69977462231134,-341.5970778306366,87.94089760493821 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark45(-405.7984819492832,-356.6945546896409,63.6113347457659 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark45(-405.8628076080824,-348.06705705879125,18.86206865854912 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark45(-405.90214289972914,-363.38151618528974,100.0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark45(-405.9263735733591,-347.7428417873192,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark45(-405.92935722362324,-365.70871333577236,61.57556567347888 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark45(-405.99663307414795,-348.60200460136207,14.446947118978983 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark45(-406.2773207401524,-349.47605581268465,64.07186717999772 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark45(-406.27808446125596,-343.77821538987246,76.88443529764123 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark45(-406.3433021931761,-388.99309699198733,24.70792433151287 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark45(-406.4115577161445,-380.6468519648539,81.41546600412491 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark45(-406.64328820112456,-399.80663570066105,32.751470655433565 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark45(-406.76260500177654,-430.4884287626845,55.56543605378758 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark45(-406.9060576331447,-462.6702356893226,15.698560705758695 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark45(-407.03170662022114,-376.95405061151365,100.0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark45(-407.04044278817435,-385.2445960969424,10.335204307102131 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark45(-407.1716244815964,-349.37089929736345,58.31681936644256 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark45(-407.18488804103515,-395.2642859712285,29.780529703219514 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark45(-407.2734136766355,-370.3571671737407,42.41768519321215 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark45(-407.41710562111314,-353.84225977532236,100.0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark45(-407.42370265392543,-340.5625491403616,20.00287667180018 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark45(-407.61530035219965,-372.3509397994015,100.0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark45(-407.621419154792,-341.0503397256901,48.63527202486139 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark45(-407.8801850246099,-400.58890144341626,88.79089588164038 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark45(-407.9047440339555,-338.4186079812403,91.8528616912439 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark45(-407.9486929094228,-351.3608441116741,0.9129493136900777 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark45(-408.0827625154482,-379.5909741960139,52.65498053263977 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark45(-408.0885070782233,-347.96298252659545,12.548218173071305 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark45(-408.24757480945414,-340.04982427746324,12.471097145636207 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark45(-408.4752658946851,-344.4926789072171,71.81286914859518 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark45(-408.730479015023,-397.51844238219667,88.88649902594878 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark45(-408.7921416861182,-376.51063649364255,75.28136006216481 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark45(-408.9889792672635,-352.7635709920777,45.96608489666036 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark45(-409.00394297637513,-340.6219097877337,30.221671897098332 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark45(-409.01966353271155,-363.0257986249342,100.0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark45(-409.24526052197143,-353.04528947178954,82.53858960284882 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark45(-409.2857315856486,-366.0327594496565,37.97267756466712 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark45(-409.55018937866,-384.89949606406145,100.0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark45(-409.59991278955994,-358.9569153034507,11.335912946123642 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark45(-409.66094965936793,-342.94047367247725,43.239420214321655 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark45(-409.736363685531,-358.22697616201714,96.99798110927708 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark45(-409.7644505208329,-341.3929204520933,56.72496123349714 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark45(-409.78058679038134,-409.1352024622988,9.299455946413659 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark45(-409.9953193372722,-359.2626839677254,84.55027980994169 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark45(-410.10237603702654,-376.555660878018,41.78228733771411 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark45(-410.1236320280027,-405.79169972669496,7.878334251663958 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark45(-410.12715085572574,-349.9837987136333,3.8387748208504178 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark45(-410.17512129832386,-375.6102192766067,4.890374883199229 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark45(-410.31744831060735,-390.25861901130617,7.99553418567929 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark45(-410.37475371067734,-336.43616214712546,100.0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark45(-410.5298232464224,-335.68814515122244,60.01333969271815 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark45(-410.96347616710005,-339.43408824553444,88.87189365711546 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark45(-410.9956841419082,-349.9661303480894,33.557516548928504 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark45(-411.01541958309997,-422.14493045051955,1.5798565945375458 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark45(-411.0249156201736,-370.97289161902154,32.18860856623559 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark45(-411.09881387571136,-401.91176944863236,7.65318020252856 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark45(-411.20609989527367,-353.3914456221603,40.14761861494762 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark45(-411.2110119144925,-401.31028231809313,68.16518772947418 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark45(-411.37517431032103,-343.6881001646923,60.223718732397884 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark45(-411.5170101022208,-366.6473718798281,95.88359441860209 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark45(-411.62281001064736,-389.1494394104446,97.16124030490718 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark45(-411.70053909593514,-366.0105717334454,60.01273366481553 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark45(-411.77028413710303,-371.4839193591698,100.0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark45(-411.7880799787674,-360.6394185925705,24.550116891361924 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark45(-411.8563865450229,-352.64923720594686,2.769260082580246 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark45(-411.87549601853533,-377.50840506118533,22.592043004213664 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark45(-412.115630487237,-342.14954155282607,27.328675970768984 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark45(-412.3037107140325,-372.26749926125643,70.58309991267583 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark45(-412.3101325616018,-356.4475303777468,51.795959786981996 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark45(-412.4031379173461,-372.41552984463476,0.18375423816047842 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark45(-412.6807371956522,-338.0715002137241,100.0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark45(-412.71595961754053,-337.5963914966604,100.0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark45(-412.72971071570856,-343.6294387202011,100.0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark45(-412.7954545416802,-357.1141777908118,35.729797982929625 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark45(-412.89518140711795,-352.8213542673835,2.135573722795179 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark45(-412.94073209124366,-360.83894994504936,100.0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark45(-412.95912202282284,-412.9374292472554,55.91810398132918 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark45(-412.9636708993068,-403.9167548103203,100.0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark45(-413.13346237327414,-374.82910274571356,67.497393423994 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark45(-413.2728856921964,-350.79795824405426,73.89435395577334 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark45(-413.3069995625409,-403.1251369334987,100.0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark45(-413.3651750153401,-482.7436290007626,24.15831019798034 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark45(-413.3780135603418,-345.66554747306867,13.85658591465824 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark45(-413.60048605367876,-358.9049125470476,100.0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark45(-413.610955848559,-348.3136736085486,34.502537971667664 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark45(-413.6271058571186,-354.6614487290217,54.664157054424294 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark45(-413.74121994786987,-343.12599990533454,100.0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark45(-413.7867283531364,-385.45948003044236,62.30673860498689 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark45(-413.8622559200011,-360.0544161233964,12.639176065720221 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark45(-413.9361053592621,-367.4153395711157,99.29921245463473 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark45(-414.06797893037566,-360.0987302167613,36.406106959576675 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark45(-414.1951636845346,-338.92014912118236,81.57462357157277 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark45(-414.27913210099604,-403.5593641413203,64.63267621218941 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark45(-414.41731869487023,-349.1577446262178,32.382001774275494 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark45(-414.48322800962126,-334.51248574125265,36.46890475902501 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark45(-414.52340333052115,-366.44930382742126,56.1686918713018 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark45(-414.6435790682871,-334.619355496143,12.044644388066558 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark45(-414.8341126963522,-331.75141764979384,100.0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark45(-415.2937489121177,-369.3459955905284,100.0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark45(-415.51177953502366,-380.50695150711886,35.262915546969026 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark45(-415.7746731558161,-330.6166386792628,97.42892408328751 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark45(-415.8099673364631,-339.757310969359,85.8778383597712 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark45(-415.8173013253767,-332.1019269151949,99.72227606676535 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark45(-416.0528897436989,-348.95888321721594,51.4905685267812 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark45(-416.0623249502953,-342.40712027273077,1.2000858399653538 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark45(-416.10236343759817,-332.1986755045444,100.0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark45(-416.2023186356123,-402.96169963947426,24.348814804431413 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark45(-416.23655383161923,-389.1304843598644,61.59825600795904 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark45(-416.38488579748736,-386.1314979377771,69.32925174505183 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark45(-416.42761227515194,-354.5341208350442,98.40342675490206 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark45(-416.55905795849065,-365.9313088730657,100.0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark45(-416.6928724869977,-377.2299169148236,1.3516447664870412 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark45(-416.80205528697974,-418.2611257121484,53.34036975686331 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark45(-416.8122102206,-346.02785056810046,90.57154784864838 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark45(-416.84411226535576,-403.1699601049065,84.34386895666094 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark45(-416.8829472751314,-331.114529804893,100.0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark45(-417.3433786536276,-341.43237224546124,100.0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark45(-417.3563124610172,-403.0554949284846,51.890402128289935 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark45(-417.3602535435511,-346.42418845824574,63.93171050263368 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark45(-417.36679478692747,-338.2043107069503,100.0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark45(-417.5133851760092,-364.6333233564645,42.961896283405025 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark45(-417.53336725703934,-333.83700518224174,60.516784114063256 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark45(-418.03861845494293,-375.90782517923026,52.61726304070922 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark45(-418.3106145232008,-381.96232153703545,100.0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark45(-418.3313822954686,-353.4225744980647,60.457003618449306 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark45(-418.7055329302303,-342.9607529131199,54.568579715359334 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark45(-418.8298264742972,-329.74383563010747,53.14464367983419 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark45(-418.88018190389613,-344.44780178582545,44.766869906674515 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark45(-418.96219657812225,-330.58669442964134,34.094052204999144 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark45(-418.9836460161807,-370.332030105513,3.7839917404044883 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark45(-419.1037401617931,-367.5541509771424,14.552731654940686 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark45(-419.32433231717926,-406.5537607774951,100.0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark45(-419.3319017168223,-398.6329927646264,10.471426534855624 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark45(-419.4133750722533,-348.53600610779154,71.53174590379689 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark45(-419.6007828948269,-328.83908827163566,58.001697709119156 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark45(-419.7880846375159,-361.64762103198746,39.469423922442104 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark45(-419.7930343489132,-383.07991355859195,21.938252551575488 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark45(-419.835019284117,-327.87171611897264,80.28940249619697 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark45(-419.8721854568143,-327.76555934476573,72.03864963615564 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark45(-419.9650918916213,-347.14545741598977,80.51260913396331 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark45(-420.10072640749667,-331.4376970254041,100.0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark45(-420.15745958765467,-337.6974471222346,7.0389598959016695 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark45(-420.15770387788876,-350.8638353152492,50.61435114739629 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark45(-420.5951491657153,-357.1121889011738,100.0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark45(-420.6651034953568,-332.12177996949157,81.01166155704013 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark45(-420.7911095792201,-330.8653062744446,76.46246856760553 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark45(-420.8124826733976,-417.39137271345857,66.74896098591935 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark45(-421.18188926851553,-344.4817075078485,70.37864921462455 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark45(-421.2192432061375,-354.74904550567703,72.46307939814348 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark45(-421.25675308496034,-350.59719637322996,18.205257615369646 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark45(-421.3636358990099,-341.0988034938329,61.93447984112163 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark45(-421.3931217472509,-375.76496535770127,33.29418282751783 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark45(-421.59400825822246,-367.4230108009171,54.65046556531743 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark45(-421.63419111844007,-348.67521170922925,100.0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark45(-421.9403079385228,-416.3865914633929,30.364140081730994 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark45(-422.26881260846517,-332.61611752025556,52.381979299937285 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark45(-422.27021954429193,-361.4322628403458,47.52465527032652 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark45(-422.3022240922454,-361.7972532182367,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark45(-422.5654700580095,-359.68351662802775,54.80019837121574 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark45(-422.5985595220334,-386.25973315938484,14.236171531612712 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark45(-422.6076016849115,-349.8513347587026,80.67317978343925 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark45(-422.6195953085654,-328.78027054221246,69.55026090788911 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark45(-422.6629937087433,-381.4244153326572,49.36134566152319 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark45(-422.6952441345829,-323.73401491982406,77.57710711741245 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark45(-422.88450056731136,-342.4272172967422,77.27928089783157 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark45(-422.9212913309549,-331.68305570085613,6.742919703249967 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark45(-423.36634437011907,-330.12704901733406,87.35145957408562 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark45(-423.4569771651017,-324.9049452038498,0.5691599069968589 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark45(-423.52633637413044,-376.87029172174095,74.819388907303 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark45(-423.5353169141136,-324.1794851618329,66.85896417408807 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark45(-423.5769154438679,-325.9091022615721,66.81626102647806 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark45(-423.58473670857893,-348.51331054963913,26.62488032373882 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark45(-423.58973262882574,-357.9479142814198,10.288826980015102 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark45(-423.62232804258645,-351.8747270667313,38.71375459219274 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark45(-423.69041239696065,-365.28201199120986,40.393077820562546 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark45(-423.7415273259885,-369.91054931577935,100.0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark45(-423.74994693147846,-340.7913882555452,52.823562679124336 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark45(-423.7844991739301,-336.0513267683206,24.731329824132246 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark45(-423.7878659380882,-333.1946769552315,12.923275483884993 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark45(-423.9158477407812,-333.077650366605,87.00350272750748 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark45(-423.91800151560363,-364.86902554583696,52.70330161278741 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark45(-423.97496613740725,-324.5724140591389,37.80235171810409 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark45(-424.1132081593272,-323.59151013767087,41.532203739901234 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark45(-424.1481641564584,-325.8059674599081,93.72354291629347 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark45(-424.289833171408,-324.23467932277873,65.73271570657052 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark45(-424.305729173297,-349.47175971945785,100.0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark45(-424.31576454482956,-364.25287979091854,36.04023409298529 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark45(-424.6246644958166,-389.67126476193863,61.571550512699616 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark45(-424.63545797613335,-335.83019289612344,100.0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark45(-424.6634979953229,-333.192206068584,50.107021476906084 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark45(-424.7864760790173,-357.82135333583824,53.95428323938745 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark45(-424.9810808287744,-345.6593590659542,33.27925875554473 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark45(-425.03867775777206,-430.5020095292274,90.23692903996354 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark45(-425.1350249013929,-354.0367750565001,19.308104732383228 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark45(-425.1587782655847,-373.7658900071853,4.700547310979758 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark45(-425.4611862815329,-322.44811738436135,80.79466828229792 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark45(-425.4759490359122,-325.86352215419896,66.74760256485101 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark45(-425.5427917979259,-323.7784225890767,3.552713678800501E-15 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark45(-425.6304872669739,-345.4003341178941,92.64047416691378 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark45(-425.80209566888607,-394.1571571799723,100.0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark45(-425.9194657782214,-329.80166503772875,92.79610009801252 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark45(-425.96476688837197,-341.81752805014776,47.44434127060023 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark45(-426.16936316909687,-366.3262749863346,100.0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark45(-426.21978681372315,-342.41542905834933,55.983658842828504 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark45(-426.3185438009813,-353.57453395958606,15.35610730895651 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark45(-426.4409268154798,-332.91192587835377,61.08529889704778 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark45(-426.4619547384991,-370.33367540398433,49.48213188300761 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark45(-426.4680484133526,-409.34693027170385,100.0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark45(-426.4838792600909,-319.90034293544574,10.91561512529313 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark45(-426.4892791083019,-331.69290884009627,33.12000754911139 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark45(-426.49436619154704,-354.0154946559703,22.725329865121992 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark45(-426.72554032260433,-336.84046011061315,75.9008442375644 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark45(-426.78973737462667,-321.58664241977056,57.92010506839378 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark45(-426.79184566213087,-389.5102566232924,100.0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark45(-427.0832817347426,-348.1820094884094,24.34221206297154 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark45(-427.2209062346947,-328.2254465846194,13.458096078811593 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark45(-427.27164926737584,-319.0185829305878,34.04669763936582 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark45(-427.4201763140593,-334.1617547607817,100.0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark45(-427.61292408298914,-369.6463976678743,50.81458310595741 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark45(-427.89806721548246,-322.71347344475356,79.4860796773568 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark45(-427.9082360765095,-354.7502870628497,65.4610234946932 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark45(-428.2975153919308,-363.37616461915366,57.430363925510136 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark45(-428.3032368458874,-363.0710200075401,4.236147338163576 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark45(-428.3150628189596,-351.0696737898159,5.552790867362162 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark45(-428.51925505398384,-319.2710954197434,8.22483511407441 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark45(-428.6146667957515,-358.6392973321541,100.0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark45(-428.64386842159263,-342.6052276824108,0.031555717627426816 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark45(-428.9116189520609,-378.5007502593592,51.05767425948363 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark45(-428.91294334547547,-341.806222289889,21.217311870090327 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark45(-428.96029546717585,-328.086999299949,4.349372542367917 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark45(-429.05204114212086,-354.5015310273127,37.75410384893439 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark45(-429.09004856127933,-371.0811214244955,91.75742817627318 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark45(-429.1723141304529,-329.6026794760883,30.02248428923008 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark45(-429.2395707318975,-350.5965455639988,100.0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark45(-429.3874215154808,-359.30309648363004,90.53274340308067 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark45(-429.46813233856494,-342.68086253185203,65.69522839440017 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark45(-429.4752376410764,-329.4098301017723,24.628164783701024 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark45(-429.5613026690995,-371.4845053031196,91.96174945160178 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark45(-429.756187783369,-321.4210477514679,62.31499310045163 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark45(-429.7852537672939,-329.4646658417729,53.41065188654696 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark45(-429.79471387485876,-370.84425707839534,98.08766153374941 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark45(-429.84103507110194,-321.8881884466124,23.15524593489171 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark45(-429.8961277330931,-317.6706026934978,18.450617003130404 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark45(-430.0172491350367,-326.23271868228454,13.879805785331413 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark45(-430.07971614132606,-317.3186963287266,42.86763468632287 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark45(-430.10056681518057,-316.79755482036916,30.857894251669364 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark45(-430.18179280096916,-337.45281084954325,93.00441301491983 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark45(-430.3134853393443,-342.0422574055146,44.65059954858168 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark45(-430.4831447333542,-347.76487256356734,52.65680388413563 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark45(-430.98670633166705,-316.6792861776695,15.110989077894232 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark45(-431.2899105301013,-330.0495282361078,100.0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark45(-431.42682362000465,-316.00318424677096,70.27262901205248 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark45(-431.48899591055766,-366.6762113807526,4.332764905439234 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark45(-431.5194513465272,-357.92188900186807,100.0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark45(-431.5887710357271,-326.3266691386034,49.22453312937489 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark45(-431.7817487252207,-341.11557768798536,100.0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark45(-431.8420286054168,-315.0909926584209,100.0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark45(-432.070335176849,-317.29581336001365,100.0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark45(-432.1077548219725,-386.0832910994466,37.69797965772659 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark45(-432.551418898357,-319.02565974698365,5.265412377669861 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark45(-432.6497038266849,-318.000195892151,77.49162445717633 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark45(-432.96061617334186,-324.31995073987133,7.06170093644532 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark45(-433.18447019981164,-344.4946356663869,90.48079164228142 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark45(-433.23975588058784,-314.8029182514777,51.71327748881603 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark45(-433.24962912246536,-318.777114599625,59.210352067441306 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark45(-433.26651529848493,-315.2002255120074,43.36678746691794 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark45(-433.36816493582353,-324.30613169299176,76.64199689776652 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark45(-433.4390365963005,-380.8736138300841,8.883417184683722 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark45(-433.48720882663525,-326.5153656749857,36.65087776706304 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark45(-43.351108408419115,-730.8441496233906,59.1935511992543 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark45(-433.53812432460734,-388.965260375598,82.45517309163512 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark45(-433.5496001383973,-355.2818823311061,100.0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark45(-433.64488445046885,-328.1328898551086,49.52263204472294 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark45(-433.70931099242466,-325.1448369967668,41.64441261277679 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark45(-433.81291244238315,-328.6909477541369,92.36370883025265 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark45(-433.951751357677,-346.4120483569059,56.93104767176587 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark45(-434.0007731484492,-387.8349845793769,64.31419183677374 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark45(-434.0429098332861,-313.58683553981996,67.36036859105562 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark45(-434.049157281567,-406.3202888962465,93.22639826704238 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark45(-434.217968336155,-334.45272981910625,0.21889878026793497 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark45(-434.38537119890793,-346.6473131830594,100.0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark45(-434.4676660515252,-350.3804862894748,94.37057399444251 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark45(-434.75533279969653,-313.75275900387567,99.39952012724996 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark45(-434.9402388385298,-362.0748991681192,100.0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark45(-435.1697628905775,-312.03297141570465,28.77464918196239 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark45(-435.23050494482897,-320.3827991034247,48.34177620640659 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark45(-435.27069536239424,-384.7503838378398,28.51693197046714 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark45(-435.2754308634718,-319.9568626046876,10.400864628456148 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark45(-435.47778483533307,-312.537255039438,82.56025372301193 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark45(-435.5507199839606,-332.7199088110316,91.44527036019338 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark45(-435.65915681519243,-328.571534739242,49.22617278112352 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark45(-435.74462914975993,-311.0019018787195,66.91863933468142 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark45(-435.79596122775735,-349.77883833366144,32.544875254789275 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark45(-435.8771721886287,-313.7546378570227,79.58617808049127 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark45(-436.1684834160258,-313.59981952394577,84.29313931189998 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark45(-436.3518950776678,-363.0210140205742,100.0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark45(-436.36534469126036,-312.6174786903307,12.63291176057632 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark45(-436.4709642515113,-323.2710943592556,4.7865437218075755 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark45(-436.4904562988792,-349.4518900866881,14.820356945618613 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark45(-436.57541715478305,-337.02138866617804,77.60408448780757 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark45(-436.7861054391231,-374.68932095165053,74.88154340348225 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark45(-436.78989811467557,-317.5768167109559,100.0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark45(-436.91592110663015,-331.37421294642775,2.8670767142645843 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark45(-437.1743451885137,-341.91136774569486,19.426947513502782 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark45(-437.26320190207446,-324.8687595095448,28.525119800055904 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark45(-437.3183067701614,-350.3396506573586,100.0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark45(-437.49090088797004,-344.45326463230924,6.767566098465313 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark45(-437.5148684229058,-351.1239984794203,70.02480506787637 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark45(-437.5731163369172,-320.00194935640786,100.0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark45(-437.6510186309696,-344.95744862067994,99.13262154954333 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark45(-437.78920148758573,-309.3771462504294,96.89040837505678 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark45(-437.95847199688546,-428.02805703435075,25.805138304106595 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark45(-437.98520075089203,-314.1817906678386,100.0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark45(-438.153962938007,-347.15318969098246,72.75571480053969 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark45(-438.43776841629483,-314.6449292180995,21.7772102506852 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark45(-438.63766917282834,-316.6845651047004,100.0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark45(-438.7582885160319,-339.353804687818,92.53328452970828 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark45(-438.83287946226716,-311.67525275843684,100.0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark45(-438.93050814636064,-320.33919233129507,100.0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark45(-438.9314545350164,-311.54560149735954,3.2489146150462886 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark45(-439.0511295485339,-323.2492085443662,85.50148499664496 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark45(-439.26020019799495,-316.5276941196332,71.17034482795327 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark45(-439.2829767839499,-313.8228796989076,49.49863872872214 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark45(-439.33562565724026,-311.98461828065615,93.11430289977449 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark45(-439.4548100900159,-309.4318014292455,9.92709774960072 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark45(-439.74001136650463,-343.1739391503037,40.854921324180935 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark45(-439.96483645681303,-308.81506219776725,23.363662356518915 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark45(-440.02948710828247,-367.5975268649083,45.24296104920177 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark45(-440.09459075476184,-319.09973708768183,40.22048069154641 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark45(-440.1503909131226,-305.86927211470214,54.22982959039163 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark45(-440.2168755327599,-362.803040340923,21.177839312283076 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark45(-440.3352438511668,-331.4339545171228,100.0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark45(-440.5706333160874,-315.06578006947075,27.38143694893411 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark45(-440.6133678058139,-362.93902000775046,100.0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark45(-440.7185517219048,-313.15702911109014,68.21706511718361 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark45(-440.7922364952436,-353.7533932931231,29.811113232949168 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark45(-440.9122885326863,-309.2078900245333,94.87691821654332 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark45(-440.92919665758996,-326.0349582642798,12.992500803691925 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark45(-440.97430146606945,-309.4160415777025,23.05724300887158 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark45(-440.986427737027,-394.31580357865965,94.40083927892707 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark45(-441.21649878031513,-334.85943088240424,99.40538738261549 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark45(-441.22514798204014,-305.66837278388635,36.525076316249454 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark45(-441.24244721210465,-309.07976083626386,100.0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark45(-441.2442600802501,-336.7617836217878,66.44238490163781 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark45(-441.32504727101093,-323.81261641959435,66.2655205233714 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark45(-441.5227940294198,-373.04758813653405,41.56484293269881 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark45(-441.61701690784975,-307.11872305430785,12.944976172500361 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark45(-441.63651025242876,-311.90878318148253,9.141146616484434 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark45(-441.66425882663566,-343.76585502363196,54.996099447085044 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark45(-441.67690236628704,-325.5041273484229,97.73556154249079 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark45(-441.7188797371097,-314.86500982371007,9.01757469168551 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark45(-441.77969639259226,-342.24860182787734,77.75869772088254 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark45(-441.80946693084985,-381.7852865011657,56.853821150044126 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark45(-441.8953247769237,-321.79340594045976,22.639191608367582 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark45(-442.1117846286921,-377.1339138655528,74.25657459563696 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark45(-442.11686304473267,-338.90835532277686,60.06301573615863 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark45(-442.2213981658653,-377.3057789711601,14.25268056918432 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark45(-442.29667904943733,-311.7726430779613,40.83399335094984 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark45(-442.3471764123868,-319.04810231419697,93.4215013414379 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark45(-442.4884171145709,-351.07517324397395,99.36443182447229 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark45(-442.57206681582545,-332.76949581052014,61.53446192568575 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark45(-442.64570092193986,-305.4821799249097,94.38252095944699 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark45(-442.9203025301148,-331.8154274055507,100.0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark45(-443.0127735358729,-309.31942442508716,34.546404659568225 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark45(-443.03287146537957,-356.99324075891394,14.88496871144622 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark45(-443.0367530460845,-303.081366762998,35.05129200871758 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark45(-443.0901145924085,-305.0581785854941,77.5304840953817 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark45(-443.09465005278366,-348.47098603704814,100.0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark45(-443.3193680995823,-334.77784843643013,97.63535477008423 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark45(-443.4338395286792,-354.7528433120609,100.0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark45(-443.6882906543177,-378.8896961336998,96.1151618486609 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark45(-443.690070804627,-315.0901684239032,-3.207679311109544E-6 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark45(-443.7428132941808,-420.30790958281807,13.900668365089118 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark45(-443.9113887857417,-377.0099809380243,53.05068193633818 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark45(-443.9519505356827,-306.8149528319461,44.54781277567204 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark45(-444.1202277341154,-343.7634550533582,54.64080634982952 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark45(-444.22856255527273,-305.24060867966364,100.0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark45(-444.2363456429305,-318.1320098565498,25.302242088514973 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark45(-444.2876599822892,-309.07677635326314,99.82579575546276 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark45(-444.4581133375599,-336.32340674864406,56.76807136970277 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark45(-444.5449486067662,-313.4287550139697,73.17998425005149 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark45(-444.58881703444,-314.14264868436146,36.003864858019256 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark45(-445.0156641617427,-318.11891275943753,23.705689388019294 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark45(-445.38229825281604,-317.96145705176497,91.65939928994874 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark45(-445.55414161471873,-309.06557681542836,63.16699481862588 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark45(-445.55526960377546,-322.8680152580407,15.854027007246117 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark45(-445.66761199333956,-313.0801866183847,100.0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark45(-445.7550342246001,-312.6699283547306,27.282390221218634 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark45(-445.76446651722375,-315.75580100212676,96.55303255462886 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark45(-446.0121249304056,-329.72639550510314,62.60130889276462 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark45(-446.0483656922661,-317.56360460250454,39.34231067292205 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark45(-446.2185002178546,-341.99601007681247,100.0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark45(-446.2267208243978,-354.3901792723587,100.0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark45(-446.23571215625304,-338.05614826748683,1.1341641310454593E-5 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark45(-446.2591379485811,-321.4238959607313,79.48697948684696 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark45(-446.3129888827446,-336.1959974610197,100.0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark45(-446.51965463421806,-353.42761390232624,96.61781506070182 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark45(-446.64072208465853,-349.6799799921324,88.10785110049099 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark45(-446.65278373227363,-352.90888820074446,100.0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark45(-446.73938081828203,-318.7047109494295,100.0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark45(-446.95360352740005,-361.653226260206,76.04864817184233 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark45(-446.97112079502205,-326.686666459878,100.0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark45(-447.1189377571492,-318.67481446439274,69.57825568499618 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark45(-447.20496079593124,-325.46869528454897,79.42651502336605 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark45(-447.9055337525532,-307.58702269675064,45.67850049164297 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark45(-448.26079042481217,-332.00741136444844,87.4164004884891 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark45(-448.5450331865403,-307.0923743653993,5.931094533454285 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark45(-448.60369030762166,-313.9312776498172,63.57370691661495 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark45(-448.63156736403783,-299.2000071881353,0.2905043358714181 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark45(-448.7587462684642,-301.1680415909707,100.0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark45(-448.9086695830577,-351.32205084472054,18.51046276235526 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark45(-448.9828427828735,-310.4562636780346,100.0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark45(-449.0107572133505,-332.88444148982694,49.085063624478835 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark45(-449.0274279264778,-297.5485269018833,60.84033699429739 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark45(-449.0595235386657,-328.2540405822729,28.425554200439738 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark45(-449.38533280697425,-337.3323699162135,86.30731807681602 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark45(-449.51418245822396,-361.2451131325892,4.771465982672282 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark45(-449.7240891382369,-335.8125475833688,100.0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark45(-450.20258433031194,-300.027650291719,31.78305534496427 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark45(-450.3380176449414,-364.6101535707529,62.842620639862815 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark45(-450.4962526411256,-335.60008064388273,100.0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark45(-450.5451483821515,-409.07147177740427,100.0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark45(-450.59516414644247,-302.2729744209326,83.3296047996991 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark45(-450.90959399577554,-326.7044311096955,97.65516907396236 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark45(-451.02339698761364,-306.32405135677794,2.2799825543758914 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark45(-451.12473486474613,-316.1642817169883,31.178543350468658 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark45(-451.13310559694287,-325.0488652202277,100.0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark45(-451.6781324846258,-301.79290633008577,45.78928138566977 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark45(-451.82185055773436,-316.52654911099916,84.53647382417833 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark45(-452.0820004654165,-322.1589743476244,3.3099637613265003 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark45(-452.0824624468683,-308.95718943076014,6.347486977242923 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark45(-452.12409056939845,-366.53437597135746,100.0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark45(-452.24594442817465,-323.67880136586945,73.8238296218951 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark45(-452.2691055451146,-323.16015618903293,16.935017666276366 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark45(-452.27427816152573,-309.4949255113823,100.0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark45(-452.2795786631066,-348.9167276189924,70.42224059392748 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark45(-452.3908205699657,-379.04768998760454,30.988840159877157 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark45(-452.73829072981863,-352.45836540291793,20.11139816198984 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark45(-452.76106545265,-332.0423130460637,36.700479329123965 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark45(-452.79104497239024,-340.8177779861272,50.44441858032823 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark45(-452.94562484803225,-300.866802156915,55.8904566382692 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark45(-453.0086761096076,-353.50108345063444,100.0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark45(-453.04548835424373,-308.7296734253898,34.54843111711165 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark45(-453.3188461703401,-311.5526566474741,10.549671132976897 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark45(-453.4217711826678,-293.9861680982832,56.70835171819422 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark45(-453.4599845839643,-316.2632679215371,91.85414433200046 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark45(-453.7210302526858,-314.4788175622174,5.383126107693433E-8 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark45(-453.89450320155026,-338.36625595588737,64.97598584860302 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark45(-454.0400987026491,-335.64036716009934,6.988223355774451 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark45(-454.1256281523153,-308.7796205277558,83.15794027840383 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark45(-454.17222057849995,-326.9906398290041,51.846460821114164 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark45(-454.22881345939635,-357.0391331868635,20.54689801247669 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark45(-454.3546187585907,-350.6172042301765,87.1606414934702 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark45(-454.4101042425535,-293.0286535369796,5.112716645688067 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark45(-454.62572397477726,-298.215194050316,44.421111718943195 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark45(-454.712445040105,-318.8200618696954,14.479402048855604 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark45(-454.7412744384733,-298.61820345167513,96.61470117745512 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark45(-455.03092559102646,-313.07318723643584,58.6747192473633 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark45(-455.08441970954635,-305.9279077049815,95.30440804002939 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark45(-455.1142531777079,-308.50244169373684,54.82556513653077 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark45(-455.17919954677217,-330.2412507269417,15.39569160132912 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark45(-455.27660096085185,-298.9439186610571,15.62658322524129 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark45(-455.31542408839914,-370.40305066893353,95.35473186090832 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark45(-455.39561882201724,-351.37082899962496,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark45(-455.41367141028644,-314.0180552029886,100.0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark45(-455.63360341297346,-339.09787697134203,42.476379201709136 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark45(-455.7543808989131,-307.5707993446601,48.942342858139 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark45(-455.775346845526,-290.85598951221505,100.0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark45(-455.8739870351876,-290.5180967302962,100.0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark45(-456.09291754599076,-328.6051785850745,100.0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark45(-456.27566634233136,-374.6818743047617,24.720474537250283 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark45(-456.73452474858885,-397.14689067923337,88.35858549191761 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark45(-456.79522780400106,-322.2357583378098,100.0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark45(-456.80944605319456,-339.45246155278386,85.34544819489116 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark45(-456.8100245235746,-307.430804949447,88.5956046283591 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark45(-456.9166669252852,-329.29572338921554,5.910936972071994 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark45(-457.12033394397685,-364.9791275997378,100.0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark45(-457.1938573634975,-308.2245015109386,11.162525073381275 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark45(-457.23707682957945,-304.8662113705171,60.320266450885185 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark45(-457.3211334462646,-310.0791428331101,7.533792864133119 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark45(-457.3460415207653,-297.2482541392618,16.38437043250896 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark45(-457.4467325612508,-321.14717672009306,6.951568904677984 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark45(-457.7184123611581,-370.42880642342743,60.36234303256137 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark45(-458.0119922514378,-298.11251201835205,100.0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark45(-458.0499843088336,-294.0701333082999,20.344050783851955 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark45(-458.1248275159742,-317.505487513686,95.69782741531267 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark45(-458.1503804967073,-293.48242695714936,71.80083006573449 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark45(-458.1536285378479,-299.2523456503635,77.58597423663406 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark45(-458.7103246498622,-340.21412496529626,100.0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark45(-458.71993531599867,-295.2482012098107,53.05966543292669 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark45(-458.94701807721816,-318.0148930628859,41.778564429436585 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark45(-459.08297221440614,-293.9809259109178,52.692150527175045 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark45(-459.08916543640714,-365.015557298601,76.01965431343399 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark45(-459.0918535532423,-294.12660108001444,11.289732075603638 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark45(-459.24918078527014,-356.28618235969014,100.0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark45(-459.2627198727524,-322.180462736949,17.02730773546422 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark45(-459.3314235313916,-302.6147603823109,49.07191107940783 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark45(-459.36687537387604,-302.51779513970666,5.404230748855227 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark45(-459.3672664578605,-298.87420958616013,47.186886361798685 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark45(-459.5278284536938,-310.13249343680263,38.54280791420959 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark45(-459.58742196690315,-330.9481556080545,64.74130731055082 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark45(-459.58995477984394,-294.3814606285864,17.730518052623438 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark45(-459.62267545748585,-361.5654734807426,27.784804437751703 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark45(-459.8343302185038,-287.7414178081559,49.75785735889099 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark45(-459.9902642302434,-301.08876721621436,71.2100030377791 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark45(-460.0899048684783,-321.7996773668126,16.708054444500448 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark45(-460.52304786884343,-330.7810322716466,53.0666591511889 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark45(-460.71516096523055,-301.6873725663089,59.0618406371633 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark45(-460.7324149188196,-294.67727209548286,40.0913037337601 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark45(-460.8728079067134,-318.6347255256949,35.65212434329456 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark45(-460.9963127763358,-317.60731114378723,65.44803083279857 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark45(-46.12123678881708,-704.1362849857701,32.180682811923816 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark45(-461.47758052186174,-291.9387128467822,14.273164647857996 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark45(-461.5162234363573,-348.72627695052984,20.432747755923742 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark45(-461.551955246149,-289.29457072946326,54.2978211019649 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark45(-461.65107992266144,-356.9460298803612,100.0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark45(-461.85693815835236,-285.77493826423944,6.200172711358505 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark45(-462.0930617522927,-333.17059652598846,100.0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark45(-462.1663706746389,-325.7529172323925,100.0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark45(-462.43065158476185,-288.12058291443833,60.008154638843024 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark45(-462.6341680491011,-288.4116778670488,26.992128102436055 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark45(-462.8037093724776,-289.281201293603,100.0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark45(-462.97700654761036,-295.8580164858632,21.543974985596307 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark45(-463.163140954432,-317.5936411415376,62.27372560791821 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark45(-463.18574496007017,-355.5051940235033,6.9613235934626436E-6 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark45(-463.64539358283105,-300.424678023312,39.877128146663324 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark45(-464.00660511131605,-294.4891947720449,11.087477584048159 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark45(-464.2279552183972,-303.1580501276258,45.912946744708904 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark45(-464.2506693384429,-285.31804565035293,41.374552706534416 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark45(-464.2683731098456,-309.40520663086215,3.6410260355334003 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark45(-464.336195172661,-338.08056176236806,100.0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark45(-464.3785452698829,-282.2704921152302,55.65487190797336 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark45(-464.3803169638359,-295.4731540480252,66.05124778249876 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark45(-464.63315526113655,-308.1988580174758,15.971187286760653 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark45(-464.97037934518397,-393.3188171035222,18.119539165139457 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark45(-465.0600323469805,-296.0475290621889,95.72749891454575 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark45(-465.07472280355324,-314.4614665945029,12.350337454218717 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark45(-465.24467911978263,-310.62510631482246,29.409354205203158 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark45(-465.4656516059943,-281.8183881977136,31.965909821544585 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark45(-465.5018933464679,-294.1117485357043,64.21216582078429 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark45(-465.52500114634165,-290.3436362253724,29.22784754056122 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark45(-465.64644455965987,-315.4667599730668,37.081099001347006 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark45(-465.68995715356436,-284.06419397920746,69.04902025346132 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark45(-465.7150912467753,-311.69930993710034,58.080353734798734 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark45(-466.10347601177045,-287.06062492274407,52.03194410692737 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark45(-466.2768675365698,-290.29224998337907,45.38448703193404 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark45(-466.373804167481,-280.7891238102219,84.05487816289781 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark45(-466.5535670224927,-335.34846449355763,34.61686602363723 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark45(-466.68645157296646,-287.7414299155115,42.49055645828281 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark45(-466.7507400880018,-289.2139907843515,56.80129736723782 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark45(-467.3788756709734,-333.78240406855605,96.12782678411295 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark45(-467.5990317145427,-313.32726742449466,91.44610291077723 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark45(-467.84557243793427,-344.35010398088394,16.425629824048357 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark45(-467.9800225233039,-306.14118308175193,94.75463472270133 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark45(-467.99021710053194,-288.2018573028185,85.8108047100958 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark45(-468.2170633628596,-287.5435421652341,45.48943998034383 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark45(-468.41122241337615,-291.4758084560712,91.45819109620385 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark45(-468.54251342967694,-280.03834328410846,21.29339568375977 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark45(-468.63165566558143,-285.9778636471181,100.0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark45(-468.644153825433,-300.5229559730594,35.80287075489065 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark45(-468.69884827295465,-344.80962036456356,5.416615520974773 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark45(-468.73653137847464,-296.57829010713994,36.36435896251146 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark45(-468.7465076224274,-288.62168603347305,100.0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark45(-469.1210779804361,-286.99558619818725,92.75108504049098 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark45(-469.2254431915474,-355.23420001970527,28.801715575493603 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark45(-469.2608755879117,-302.0050438218313,18.69004534323051 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark45(-469.5449023117951,-317.9633425590452,17.969246085830463 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark45(-469.56468352887975,-295.312517490793,0.8400449954269789 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark45(-469.62116610933754,-290.51716489377645,53.033016592726796 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark45(-469.6243170864415,-278.62872532441554,2.3327429365376133 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark45(-469.71575999583666,-277.05858687943726,21.313261215299732 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark45(-469.96565347447034,-317.9358324153478,24.564584630781127 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark45(-470.15388378168194,-336.6762200997241,95.53569642067262 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark45(-470.3232962653215,-286.63638791908306,46.085694645556686 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark45(-470.62841574236586,-347.1983419558763,1.3323674672251542 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark45(-471.0043667045421,-309.9845868654075,0.18301076399640692 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark45(-471.0637007219562,-295.8038749569099,76.81485129066897 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark45(-471.1589980140905,-285.26051360358485,43.34871111744374 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark45(-471.1922881711446,-309.2531876767573,100.0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark45(-471.24787490719507,-285.8535126345556,52.038944310483835 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark45(-471.253059343081,-336.3298841942065,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark45(-471.284219717873,-324.1312451754486,100.0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark45(-471.33243604273775,-336.2995776061384,92.05235197918878 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark45(-471.72461943883604,-276.81870892523926,100.0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark45(-471.8624155302874,-282.20515112815474,100.0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark45(-472.15031283661625,-335.7493155830791,50.264163146793436 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark45(-472.3086414741722,-307.7239387509883,10.27196981342098 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark45(-472.600478241871,-308.46464633588045,49.297204330227714 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark45(-472.73283400179434,-303.02445719308946,77.5550441695872 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark45(-473.3471465283996,-288.5554374853973,62.73094185898387 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark45(-473.40709474400535,-287.0840852740489,33.525748239218274 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark45(-473.6839770885534,-337.55269020339057,95.859889958477 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark45(-473.69259418860645,-285.0042845090609,68.47754855871578 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark45(-473.694570426747,-277.23135326939325,89.18101011021088 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark45(-473.71301744179596,-294.9664679733364,63.817772181675394 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark45(-473.8627593419133,-300.0506171200407,12.358036834582968 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark45(-473.92587508295395,-275.71845031069984,100.0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark45(-474.0202084656328,-285.41844316058643,18.510681541751268 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark45(-474.0612366379208,-302.34207572133687,100.0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark45(-474.340835821284,-282.3939565099042,0.1402596899994819 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark45(-474.45466101225634,-284.03934551054743,13.833010786572217 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark45(-474.6986645302273,-279.70652236155763,36.32118584910339 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark45(-474.8405032943356,-298.4718818630661,30.539372530484144 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark45(-474.8670146674989,-300.7067867451729,47.922755187863345 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark45(-474.9549270587343,-276.0102152067176,98.48599850745364 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark45(-475.0590566161919,-291.3010110960391,56.52085542385731 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark45(-475.2404569818955,-303.9701984284919,8.51606632381285 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark45(-475.30481027788784,-294.189339202624,52.206831812460365 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark45(-475.56760629635835,-295.28338442697765,87.81287486941793 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark45(-475.56963898421856,-310.4233163921761,12.967592186880509 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark45(-475.6494190356222,-325.4902470683434,25.46856642250826 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark45(-475.6767014032359,-311.1649785821168,100.0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark45(-475.8767499577234,-272.15578276354535,7.015827374967504 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark45(-476.13500858188013,-269.90324874977523,17.099538813480805 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark45(-476.35384940298,-279.4286724900716,78.88959797689103 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark45(-476.5310592931203,-301.3748182775115,57.68187295420165 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark45(-476.6786980866914,-300.51339189798324,23.250753524181917 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark45(-476.8304850566258,-317.35281835661965,56.55343055697148 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark45(-477.41252032114477,-299.1479752293555,66.81079629119839 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark45(-477.4975591118394,-289.5273369464063,42.44406290914819 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark45(-477.675317588132,-291.00105398892794,71.17565783036048 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark45(-477.76686054623684,-269.49315598157136,40.27523378006367 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark45(-477.94445668969433,-299.4490406677853,100.0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark45(-478.25839967919126,-318.95056199772637,100.0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark45(-478.4384842819759,-417.089982865219,39.5140170466946 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark45(-478.4672217028419,-295.1604756085981,85.55587087912758 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark45(-478.4690680819405,-285.28978189875966,19.893222901986874 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark45(-478.4794313552159,-324.12669236118234,95.85063441668035 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark45(-478.6057660306206,-331.2377899346765,16.857831629318582 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark45(-478.75357316298573,-302.7212220781812,36.860127716842186 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark45(-478.8173720930272,-333.2277919260219,76.07435257763578 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark45(-478.85518624520734,-315.6774471574396,79.14466953338132 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark45(-479.23576454834324,-344.3236294149563,5.151487242750605 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark45(-479.60134163382105,-328.1802100424843,35.035737054536675 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark45(-479.62870567202407,-298.6759894861384,17.75677221852719 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark45(-480.1643581156138,-349.8041065541108,62.07218004824293 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark45(-480.423729973228,-336.1591981817895,53.305177817086275 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark45(-480.64215211716396,-288.87294437226416,86.08680146168705 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark45(-480.7475842039241,-306.1742463600758,79.73212664827963 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark45(-480.7604905817458,-298.9427295957875,65.90650036281431 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark45(-480.8386974925591,-321.11887709244604,100.0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark45(-480.8817908027575,-273.2741199338437,100.0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark45(-481.04371903386755,-280.63382424015265,47.30676385585198 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark45(-481.1292283519813,-271.79700432837456,71.93916926984818 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark45(-481.12964113910675,-287.5961660351403,5.721312232209684 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark45(-481.57226557602564,-358.0836567840068,98.12490262620565 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark45(-481.60440781014296,-279.5923815478843,23.98089585342018 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark45(-481.6572406274691,-283.2680970910875,12.326196097140226 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark45(-481.77551677322657,-336.7098192083027,61.26890011898291 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark45(-481.9274245119446,-314.4750462548428,55.30224604711205 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark45(-482.18455598875414,-302.18642248216815,45.81850076819234 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark45(-482.38309007949067,-277.42944516152346,100.0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark45(-482.41076670592867,-306.1846089722789,47.672273796559836 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark45(-482.69081352134646,-263.96489339149963,20.252855056724158 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark45(-482.7760611488101,-314.71004430576016,6.603352488345436 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark45(-482.8292254733248,-368.63875949938125,47.56916336436916 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark45(-482.9110836705785,-316.69335441207687,17.290197709780443 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark45(-483.075638218388,-332.44198073138057,51.68431665167529 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark45(-483.19266523152646,-279.09140290334204,52.70826582773748 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark45(-483.22495410655046,-270.14866242882135,25.215278203200683 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark45(-483.4224792323956,-313.66551197106463,29.526434302458114 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark45(-483.85346921462315,-277.4719679174996,16.180475650023567 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark45(-483.9334167834158,-331.44480080733257,20.508228804818714 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark45(-484.0821274962585,-273.04905966527457,15.07863373290293 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark45(-484.2336828083098,-262.45652699377433,5.7234890441732205 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark45(-484.28616042380906,-293.54702064538407,93.5001449336489 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark45(-484.4110985185478,-286.18218980643485,100.0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark45(-484.5048908817979,-262.874446510007,100.0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark45(-484.5187642283809,-292.6334129655125,46.13420009366456 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark45(-484.55477555626544,-263.0175181678901,100.0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark45(-484.97946952745815,-295.4687755543423,83.83602804155376 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark45(-485.09289056531225,-295.2386907901444,72.68088834828805 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark45(-485.1281877289772,-283.03651141667666,76.7064065507451 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark45(-485.7215496557639,-290.91986725170796,0.21247717269767463 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark45(-485.7298804173352,-354.13341752852176,6.46218943774268 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark45(-485.8458985470717,-337.206502876772,52.725949053594434 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark45(-485.85812872748386,-343.18401838975944,70.70957484424571 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark45(-485.98418023322625,-260.31284159473967,74.68777354213874 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark45(-486.11620231230455,-281.95013578862984,50.16169981900393 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark45(-486.18182608033567,-343.54278407876035,23.256896652076335 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark45(-486.74654625831266,-261.97177420721596,28.744232792454852 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark45(-486.7849862683139,-305.0250202514098,27.161837176210454 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark45(-486.80292596745625,-269.78055233703583,56.55758926406601 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark45(-486.8711896625225,-274.435206928529,6.265403095697977 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark45(-487.12251064254696,-345.22534614246155,71.73123807693742 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark45(-487.37721672469576,-294.064997803387,91.23808222085904 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark45(-487.43243619219123,-263.9482972825992,100.0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark45(-487.8269829997428,-281.7496330947312,44.20264112146771 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark45(-487.8738272468895,-285.10822735217266,19.302043289268497 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark45(-487.96943188039626,-268.32917147462825,38.91165832063223 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark45(-488.24597676151484,-269.37596734298205,73.14851580063356 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark45(-488.4887337023654,-273.2369524480639,90.84136389353586 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark45(-488.5181509991302,-265.7509574416035,46.92142428123054 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark45(-488.66269616677226,-266.1959946800472,100.0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark45(-489.09337249008536,-260.25772971379587,24.507882344742086 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark45(-489.5681845002031,-269.4812910314542,92.29151168433347 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark45(-489.6648876732349,-285.77113667694135,95.26603637247985 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark45(-489.93251144587725,-321.0972551889004,28.251490604061104 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark45(-489.93456143019404,-269.6130523663173,24.332339275481957 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark45(-489.9454853928277,-283.1516796319757,91.47157376250851 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark45(-490.07527038651267,-259.1245714736546,64.64023202772717 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark45(-490.0775286699546,-290.9987013530239,25.340145231394516 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark45(-490.10274544438323,-265.3351375887286,13.89966102020712 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark45(-490.304662294983,-315.59303183273755,97.43376756173691 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark45(-490.41831222138353,-286.06700021189056,21.676163212386655 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark45(-490.8465850061032,-264.87225423024483,47.704294103980175 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark45(-490.8882546979788,-274.6857043439527,72.89342534262386 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark45(-490.9061140793555,-274.33157374709305,92.33522253614436 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark45(-491.0435946068748,-283.8232160855066,97.89671314402167 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark45(-491.10013777398933,-264.23854339471785,90.54879513935481 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark45(-491.21279290191956,-364.0787670211099,28.966950306039053 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark45(-491.3090258584647,-290.223170316171,24.233723889580546 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark45(-491.4944174813241,-327.19796658286106,37.27557975543991 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark45(-491.52720838788247,-264.4941562369463,100.0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark45(-491.57007732926814,-292.48031372216013,54.425936435704756 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark45(-491.6065374036783,-259.1213881946498,8.441880024929944 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark45(-491.967271101448,-278.0796396324398,100.0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark45(-492.10298424293774,-256.33822554939616,11.173750210389514 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark45(-492.1203112809385,-296.8642533730518,85.69895049969003 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark45(-492.51835083851626,-312.10057551140557,56.37579292987428 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark45(-492.5253973937127,-284.5354945381466,12.77210433606541 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark45(-492.5287869225518,-296.1463401551452,52.75874067154379 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark45(-492.6852837594868,-275.9255677895875,100.0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark45(-492.97265703430526,-321.9107970965051,11.065132552658213 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark45(-493.3817595065606,-339.0845043348187,69.7910408165217 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark45(-493.9033617675191,-288.8077189639796,12.221345230094173 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark45(-493.91994625066644,-306.0748828912071,65.44279433282625 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark45(-494.0152976087767,-275.5358746784201,39.390349406974096 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark45(-494.0227304583856,-259.84993513962536,92.37734589977467 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark45(-494.0658848316821,-278.07968734839847,59.198746341252495 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark45(-494.2322032455772,-284.3841790098494,100.0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark45(-494.7790337776447,-351.2762294375374,11.226522132587036 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark45(-494.8246144545635,-267.2798539727636,2.9673458327489595 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark45(-494.9026069207088,-262.8362604946479,99.53381463537693 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark45(-494.9257399540773,-340.90495807039116,95.74492617016023 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark45(-495.3247876256523,-274.79332820675927,21.128342211526757 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark45(-495.3453791531308,-261.2483808043517,71.82327651553751 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark45(-495.4348399802811,-260.10763252550646,4.542231262157387 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark45(-495.67688120153286,-298.99208668960097,47.75507556552279 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark45(-495.6868007352273,-303.9420869705615,93.6112569648777 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark45(-496.0105300201453,-256.6526655103201,100.0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark45(-496.0443792483876,-270.58915234780176,100.0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark45(-496.0928486331915,-320.5001745268898,27.31993530848203 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark45(-496.12301616759737,-259.4960623216425,68.23982239809482 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark45(-496.2255149287405,-251.6439006444339,71.9330472482167 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark45(-496.45742966522255,-300.5353572284372,3.379082180197429 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark45(-496.46006660962513,-250.75499431870833,87.28898950884647 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark45(-496.5226568913871,-268.324932134991,50.66822203603192 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark45(-496.7505770136386,-269.87799300396586,81.58480352156673 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark45(-496.8623560407977,-347.9644140818742,88.32132488643933 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark45(-496.9760697042236,-273.236473273689,100.0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark45(-497.05769104787885,-277.76112726448986,53.72231890401312 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark45(-497.9838789763167,-283.5320657913845,6.645379843232121 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark45(-498.1072062477064,-250.11009128836358,100.0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark45(-498.17638719624955,-256.46893548455296,34.173152178984395 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark45(-498.37846869078186,-253.4665363002141,14.581568637288342 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark45(-498.393582102142,-310.02509613127353,66.23042663620518 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark45(-498.5991683235353,-253.65823818883925,35.567501278509354 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark45(-498.9238444283724,-325.6671561690387,46.89522485642027 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark45(-498.9525721346586,-316.48327740887123,100.0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark45(-499.5105215632416,-314.69989265669517,87.8015497532085 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark45(-499.6437925965964,-255.60052574310683,14.54649204459588 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark45(-499.6846527984627,-305.7328936699178,100.0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark45(-499.8054007188698,-272.78732221464116,60.5929937009509 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark45(-499.96970826676716,-286.7414580242526,89.64421369687891 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark45(-499.98069543532523,-294.8651545845436,73.58681332913918 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark45(-499.98645765958247,-314.57775951187875,18.054587338503225 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark45(-500.0434103702204,-309.4683881602103,77.67372353506133 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark45(-500.1193105743414,-252.1233160985937,98.60786579131374 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark45(-500.137850569417,-287.64370184061266,100.0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark45(-500.1501891591523,-295.5011101274279,60.51816107151177 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark45(-500.2059097631274,-250.52910344214445,70.71803031960832 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark45(-500.29436909940154,-298.79111313270664,24.091537048683918 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark45(-500.34077012391924,-397.2238719149316,49.626199288572536 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark45(-500.44846911976157,-279.1847577525256,73.78484191717556 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark45(-500.57179184075443,-289.5503019222346,83.57939967513386 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark45(-500.68949404009294,-255.6713977950847,50.29466521795679 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark45(-500.9059519814781,-251.17314036422866,43.61374641912229 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark45(-501.1043238526377,-252.43280849200136,89.74877846724829 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark45(-501.2319755080604,-262.3425971229339,91.34784693503263 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark45(-501.34519142164345,-262.8782986503513,100.0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark45(-501.4509093337638,-336.6960205266548,100.0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark45(-501.7393322625487,-265.09222599082034,100.0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark45(-501.7639104499268,-246.11925607222932,99.29088809500618 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark45(-502.3919604785724,-247.924876665852,74.80238386896653 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark45(-502.3925474429512,-259.1576923442209,100.0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark45(-502.4050257836429,-264.5621342994954,100.0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark45(-502.6816561761695,-254.27786883298674,100.0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark45(-502.80183640058317,-244.43159352637826,38.66650668920565 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark45(-502.9430301747535,-260.63886654212166,100.0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark45(-503.0370153867345,-338.6218100238898,6.405217662372493 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark45(-503.0883642086553,-266.5419693893022,75.81958243302623 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark45(-503.1913546055034,-266.9340476507057,4.948068221979284 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark45(-503.24563719149836,-252.49308973341147,54.69933615683544 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark45(-503.3034015595464,-265.27379653470496,32.597462973929055 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark45(-503.4609547213543,-275.84032729982505,39.90698711934121 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark45(-503.7429919009388,-243.50430016989864,80.9994086169927 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark45(-503.75503844722226,-291.2796307055123,39.329133081339336 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark45(-50.387010914716555,-699.1374682659077,46.50207141147632 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark45(-503.875508694023,-274.3050558391173,34.43573971391093 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark45(-504.1589960117411,-263.4351363651661,27.20692448477824 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark45(-504.3902800991908,-247.55023629430914,23.67220093722942 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark45(-504.3961273253506,-311.2944707735502,12.684603166109751 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark45(-504.48252783132665,-270.0394316823632,90.10136177760788 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark45(-504.54005878068995,-243.42069184729561,6.882115860333116 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark45(-504.8727940743369,-262.88873878995395,84.13311246078848 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark45(-504.9451375872207,-324.17960998691166,35.91609852491919 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark45(-504.97023986763526,-262.89809473514146,9.914102513867377 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark45(-505.24590016595505,-305.6697974920861,100.0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark45(-505.2629633206534,-277.3888905698252,53.20418991555252 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark45(-505.4552771797458,-275.7285550168077,47.57445773682534 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark45(-505.54619190436915,-266.4911904961892,56.926184075905894 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark45(-505.5952680839484,-345.10776890704545,31.893514460198503 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark45(-506.02384485314536,-275.05092803713524,88.56363442169669 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark45(-506.2979491250076,-297.76302681752196,6.190591509815732 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark45(-507.03641800891336,-273.80570994906446,28.872988405038967 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark45(-507.2400568528555,-291.9047933604151,10.758538008604873 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark45(-507.40939037026266,-268.8452734707677,92.07427495985212 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark45(-507.6310677450173,-249.50127946061605,6.2545219523236995 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark45(-507.6877613330585,-271.4785261923299,100.0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark45(-508.0788041263633,-265.8229171172813,0.9647108118581116 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark45(-508.2301072285072,-285.3728401175631,35.512079006999755 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark45(-508.31350129622183,-264.7820470730591,100.0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark45(-508.4698581976743,-315.2979960664898,21.716787593123897 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark45(-508.81901215238463,-291.8803659490908,2.0338673837957373 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark45(-509.01811538816594,-243.63508219776642,79.43743484698359 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark45(-509.1143962542169,-281.8645638624277,52.31630291737525 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark45(-509.25700671517956,-245.0347226792088,5.339088230419591 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark45(-509.3890745078453,-249.59133376276787,100.0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark45(-509.5764065998128,-236.65071281562442,85.43325627602283 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark45(-509.7340167055577,-249.14848392989447,44.18390562793749 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark45(-509.7613534221961,-270.65338109011884,54.178590153265816 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark45(-509.77080068859635,-276.50177538448713,64.6119364664317 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark45(-510.0104848661765,-262.62561848773356,14.093666046900537 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark45(-510.09789089305616,-251.82157990102002,84.21697457094032 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark45(-510.2839686102546,-262.01699399814294,100.0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark45(-511.2995364718105,-280.7820375784075,35.44501881675197 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark45(-511.29996584626144,-246.35342966488716,23.502021475198248 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark45(-511.3881690485874,-279.36084481922285,23.978462284757526 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark45(-511.45304908572723,-285.2757032302306,10.248799797590806 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark45(-511.85904287054905,-261.7349999591087,100.0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark45(-512.1703245893323,-236.9501700025374,42.62665038601264 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark45(-512.3433098451032,-253.14754138642198,46.84285357412924 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark45(-512.4814538654848,-280.41918204629604,45.61842775002003 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark45(-512.5082582612141,-296.20361682298847,53.66746394813947 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark45(-513.1930218145093,-239.77496826536182,77.82732402102127 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark45(-513.2929778486858,-254.6295544309629,19.79987321018821 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark45(-513.4262135446083,-246.43208206141009,79.20048079849946 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark45(-513.548831142714,-256.0303933554501,100.0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark45(-513.5713111207402,-254.4875564118252,65.09389642899924 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark45(-513.5979602830382,-304.3491417135002,19.86279969447193 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark45(-514.1141001753881,-278.14260378632014,86.50484891713836 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark45(-514.3153947417085,-344.1907980445879,91.90377494794711 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark45(-514.5840998849901,-276.5754460027727,30.088601013857016 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark45(-514.6067365322884,-251.40488294613772,-0.0017524226924798192 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark45(-514.78189530226,-290.7680587602368,53.211444995272245 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark45(-514.865634999872,-282.93580462735883,17.980309995842774 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark45(-515.3137589340208,-288.5668082770629,14.253551512616028 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark45(-515.4292204792237,-265.4893573226816,3.640439005437088 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark45(-515.5435539462678,-232.34887944151305,27.606192202247755 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark45(-515.6305908389838,-256.20276259920206,30.142785298319893 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark45(-515.7198103244118,-258.1247269870579,67.0442643190417 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark45(-516.1932993440842,-256.1776687436939,100.0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark45(-516.2323749665242,-285.0075054075992,21.044299838436473 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark45(-516.6807216955347,-287.9353693824098,56.35194302154705 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark45(-516.9663717083863,-318.35882381436943,67.56070376248843 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark45(-517.523039321928,-232.03252527839143,62.968591576747485 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark45(-517.5419880775286,-244.13508605155192,31.632899175540132 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark45(-517.6307457750181,-255.40730990553882,89.94629805277233 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark45(-517.7988547775158,-232.47638833108442,29.38060205003606 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark45(-517.8179816946481,-252.2643593414286,5.130234371451948 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark45(-517.8238926508054,-296.954836066265,44.98208003043388 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark45(-517.9331919762411,-245.42437035660166,15.027514915503446 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark45(-518.1272815555175,-257.9594820143784,92.44965547863967 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark45(-518.2903400427195,-273.60915440899316,10.483779538417409 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark45(-518.3428901569846,-228.34121043551087,46.17911349637501 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark45(-518.496374933858,-245.70900608133206,13.871977450847808 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark45(-518.6953282880804,-228.38929883813972,100.0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark45(-519.0960329966379,-253.30455885215068,32.230770581689114 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark45(-519.1591734075325,-239.35389370497347,32.81309997415846 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark45(-519.4847978741025,-250.53868509161032,98.99772019248303 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark45(-519.6647593844892,-240.50612748105,61.65292904192329 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark45(-520.258137800768,-259.71782149874707,79.29509735561336 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark45(-520.3711854466208,-227.70241557473406,94.56349573792994 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark45(-520.4640774538328,-268.1383179345622,70.66904951316272 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark45(-520.9742555355016,-260.48968686981925,51.54118212089932 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark45(-521.1718302589151,-296.75142928162313,5.551115123125783E-17 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark45(-521.2095311878436,-272.72497511290214,70.55108243546269 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark45(-521.2101145585106,-238.8833761249534,34.323093425932484 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark45(-521.4045911401975,-296.1113276752942,100.0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark45(-521.4649041823378,-254.0905438170217,37.1490861621985 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark45(-521.507735730077,-248.6227932214992,8.16830043939909 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark45(-521.9086773709539,-234.69373929581587,94.54808788983465 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark45(-521.9201275576295,-264.70913734239934,99.4388279731146 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark45(-521.9347225226445,-229.21137351763508,42.32072282173934 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark45(-522.2104986007864,-245.07507324017456,100.0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark45(-522.387073806222,-299.5042435087838,74.538926266972 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark45(-522.6996366352123,-239.00368667860008,55.660346439198264 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark45(-52.27778407446726,-702.1249295317252,9.454799945830942 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark45(-523.1216960117997,-228.37732949260456,9.219156191076422 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark45(-523.2605255328447,-225.72854942830006,77.70584813613766 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark45(-523.440265313052,-236.123042130011,29.281743179019827 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark45(-523.4876450235492,-247.75703730649968,25.740619086582868 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark45(-523.6443259462501,-296.249912128865,14.929952521878079 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark45(-523.6521296675397,-252.2215572797949,100.0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark45(-523.6606956431333,-313.9347556461778,79.89195615714755 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark45(-523.9462807258357,-239.9207358563344,5.913782993837984 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark45(-523.9618899272267,-223.35063035016998,50.38263820600561 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark45(-524.0689062516285,-228.5561744902031,20.465586809406418 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark45(-524.2630839454114,-241.5792341161299,86.75724285316369 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark45(-524.5052291617033,-280.643747109112,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark45(-524.8970064091844,-221.5882198412693,35.821487954789035 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark45(-524.9561978410562,-265.98702547002415,55.41710427350489 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark45(-524.9862831644338,-261.4963747396717,90.24146204245352 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark45(-525.1595427038175,-221.6806323051486,100.0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark45(-525.349800896059,-252.6552449537528,67.54565823437568 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark45(-525.4807268516524,-230.58678973630106,62.98167141501992 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark45(-525.511973446518,-255.50611945721326,94.75035311277446 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark45(-525.6113549228068,-235.96634796942192,100.0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark45(-525.6447029420575,-227.99982628001672,98.89019512423687 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark45(-525.7408170107794,-235.39816691672186,100.0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark45(-525.9457163874798,-239.42956355301175,49.15111196230737 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark45(-525.9487365632546,-257.96855217369733,30.478883474059586 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark45(-526.0433233663698,-225.8396477264395,80.77312592609188 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark45(-526.0535448731529,-249.78486401375042,100.0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark45(-526.1513873628909,-259.3890621930393,100.0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark45(-526.3701578402823,-230.9595554986284,98.67801376996437 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark45(-527.3943919652615,-223.60986957980327,15.784854921735246 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark45(-527.565264614697,-236.58688639029668,100.0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark45(-527.6601846904426,-258.27578616594536,11.233938577558362 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark45(-527.678675426182,-218.40979141776242,8.304386306237888 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark45(-527.8494980631815,-245.9963175668734,93.48839418455847 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark45(-527.961676619771,-248.6770917046682,6.399919687664294 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark45(-528.0758823406156,-243.47315627152634,6.475271101409149 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark45(-528.1639182913129,-241.69355655778588,75.92618441208347 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark45(-528.2051986578296,-243.21996963242992,74.86539658115242 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark45(-528.3047715646017,-226.7826257336692,100.0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark45(-528.3651080841611,-256.6143733998507,40.281189575216644 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark45(-528.4438148556543,-224.49172052065234,41.627604653968916 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark45(-528.4599297165488,-218.58245867969953,73.95703558409613 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark45(-528.5163272727264,-218.86711445475117,86.95953202336287 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark45(-528.5990563615379,-273.52524900868855,20.58916823898076 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark45(-528.8208897926747,-270.59853010028735,66.78832400982296 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark45(-529.0092012712626,-232.73500969775748,13.98046811645661 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark45(-529.0372627827218,-279.3841078480657,35.68288445968767 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark45(-529.0464625787391,-299.4980464471139,8.341069851488044 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark45(-529.4779142377872,-261.7560689120694,19.4275329568963 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark45(-529.5189534808142,-218.40755444031305,21.71542255688395 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark45(-530.2434181222081,-244.35177245019054,73.1300219641324 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark45(-530.424844604577,-242.40734048402814,28.457886161657598 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark45(-530.4870248966523,-228.70957642714012,72.96815810734725 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark45(-530.4892857599647,-227.97954295651033,44.5872932788144 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark45(-530.894796519895,-224.44719892619486,55.16410545869451 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark45(-531.1663157207029,-294.21961596889616,49.74835020111655 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark45(-531.7041890708887,-222.3715060972258,25.815304875165396 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark45(-532.0887753650456,-257.2191126058773,17.457986009486334 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark45(-532.1436304507668,-218.2819939419884,66.10315260154428 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark45(-532.5028905120213,-399.3954003289421,13.113313944715017 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark45(-532.5873329735055,-225.78771601992764,32.637885472770876 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark45(-532.6613996482215,-220.34168866543618,100.0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark45(-532.6938600711235,-250.12877177785128,97.56895019988525 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark45(-532.8369196040876,-222.2452062052559,30.68385881133588 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark45(-532.9838804523139,-277.37480164914774,80.19143090060354 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark45(-533.0422843194989,-240.4470834824594,89.17945726282676 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark45(-533.1076438424375,-214.14387632544046,46.1808034529119 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark45(-533.1809833232685,-241.68351071121268,86.01767028276456 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark45(-533.2472165912862,-245.09165673912926,4.685872460619407 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark45(-533.8119422255872,-215.5694607678056,22.462166553381266 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark45(-534.2027527990543,-234.83321321759237,29.401518060021886 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark45(-534.2227819081046,-263.58505026363486,29.660001963946883 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark45(-534.2475919401567,-247.78113809561378,100.0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark45(-534.3999700523672,-248.96652958413029,68.38305505618587 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark45(-534.4720584510325,-273.23068767982807,41.350556785571435 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark45(-534.6060529074734,-260.85785500393735,100.0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark45(-534.6182222746597,-259.241418165749,38.5724586324032 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark45(-534.6229285358012,-250.09075000091767,8.98466503200402 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark45(-534.7739190032273,-218.95784208615464,74.82349627338266 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark45(-534.7967316020239,-253.217937984998,67.81871151550521 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark45(-534.9011943849796,-230.99036302622167,62.39679040536177 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark45(-535.3952684918569,-235.07675620797608,100.0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark45(-535.4865975299114,-280.10101423909623,97.03984605472415 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark45(-535.5711168402207,-242.00398090888808,9.031918961470456 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark45(-535.670160964765,-236.5408724871189,78.87515383037112 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark45(-535.7844483488965,-242.33908907999776,75.67184869615463 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark45(-535.9887795960465,-210.36265917370287,79.65721782132917 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark45(-536.2980144387611,-211.008208673166,71.32059063205168 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark45(-536.6525563971944,-246.25251933906674,100.0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark45(-536.8435995548057,-235.38749827574622,47.61239875193678 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark45(-537.2521398554143,-225.96615504000124,68.27588913997178 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark45(-537.3577457078392,-217.4250938506284,1.4780292843167295 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark45(-537.5348857727188,-314.03479965619385,100.0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark45(-538.0167439326428,-253.14853286659792,100.0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark45(-538.198400211507,-211.05547069142216,58.955991100321086 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark45(-538.2717463285268,-287.6918856119718,28.76670260639807 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark45(-538.7364151951057,-264.4583548208309,32.37040669397331 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark45(-538.831731303862,-210.6193556732342,69.58060072883669 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark45(-538.8607924627464,-313.01340634446495,94.17908388764778 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark45(-538.9521044274928,-233.49182869186234,8.004156988340867 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark45(-539.1342607153774,-268.0788116515727,8.350025132801036 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark45(-539.1634772552446,-216.71083236544337,6.3944793834636044 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark45(-539.4112624404796,-220.1351616728424,97.82662423549772 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark45(-539.4494595901391,-208.74975380817548,84.21037898124351 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark45(-539.7270610725344,-285.4038846356538,81.12275080222139 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark45(-539.7575820114332,-230.11810592784144,13.751524110216181 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark45(-540.3419943263954,-229.4618206067533,65.2308286626843 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark45(-540.5300431762989,-209.65324122573443,38.06039140953243 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark45(-540.7281190108156,-225.6629891087471,20.032428175822204 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark45(-541.0206275542116,-229.2270985229925,67.66571218163085 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark45(-541.2760357518742,-205.04175888530148,1.9216323657047951 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark45(-541.2917568786377,-211.2026140750738,31.74979386796798 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark45(-541.3349782626801,-208.5526102361678,45.133570837469875 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark45(-541.5646237278193,-244.37010218346097,90.7204836581908 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark45(-541.6012844270647,-218.95881863671312,38.69159591424338 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark45(-541.6864068152738,-212.8923363621528,21.449002490017506 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark45(-541.7770559862062,-232.0258743752962,69.68966346718014 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark45(-542.2759253625703,-233.94508797881542,19.311726391069598 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark45(-542.4009126035136,-238.3017383246496,79.94543307590538 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark45(-542.603002959202,-228.70412854309072,84.16054231528526 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark45(-543.1030381023974,-227.11535602829545,26.788358384548758 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark45(-543.3083388591228,-236.87091021291516,97.62434288249051 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark45(-543.3677329309264,-263.5937747184863,66.16889291221486 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark45(-543.5085450308397,-240.66771110037266,100.0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark45(-543.9612280697389,-217.67711376683107,64.72829809672777 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark45(-544.2019608066034,-270.6616113832025,100.0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark45(-544.4300422985486,-273.7996692614246,100.0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark45(-544.9565996058604,-235.8165662603567,8.715175296548992 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark45(-544.960578124985,-238.45906454638273,100.0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark45(-545.072691132017,-269.8878903613009,82.45575062942015 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark45(-545.2100632184332,-201.71229562824124,73.9037575940861 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark45(-545.5744455841161,-211.4613422185226,66.97711022946294 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark45(-545.6937439690863,-200.53680856765902,25.524667035245415 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark45(-545.749800853748,-245.4000659862384,26.122037036467177 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark45(-545.9599351025614,-201.22377876605867,5.155234256047308 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark45(-545.9637872424731,-247.10082930608604,100.0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark45(-546.3087796575195,-242.72132643529744,69.7300240424762 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark45(-546.3611913656255,-243.29800181753598,64.85114312376521 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark45(-546.625726410441,-200.7539815920842,31.51313966800916 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark45(-546.787527704909,-243.15795098590164,100.0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark45(-546.9723453210026,-243.2828243132552,8.217601812107205 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark45(-547.2858675295536,-207.964557876997,32.85009956007954 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark45(-547.8175799546406,-256.7419661900932,55.35163482166797 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark45(-548.0225975918461,-200.37633472940763,140.58300275809145 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark45(-548.1205213088956,-217.04405602202112,49.53942607776344 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark45(-548.2243592109503,-226.4027823410879,8.990961826174313 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark45(-548.3598398477181,-250.32779998027326,57.95155466452971 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark45(-548.6892628472657,-222.14340998047862,28.199966109229763 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark45(-548.845286977618,-218.70211685996668,96.7551018337891 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark45(-548.9960198455648,-209.4235700993274,100.0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark45(-549.0577822433363,-220.7070409330895,76.8533649984553 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark45(-549.5485526680337,-212.11016743352664,82.32963035571089 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark45(-549.5842684418486,-304.01907361107567,32.57369084161596 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark45(-549.970604468958,-216.36111669963003,88.65641850404745 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark45(-550.0405435096352,-239.82990908550994,69.14020359813182 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark45(-550.6329934213811,-220.20889956823518,18.681166440807246 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark45(-550.7273556679766,-250.60083776616779,70.6341408703712 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark45(-550.8351220324082,-245.66494765796813,62.78037676302782 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark45(-551.6135954418274,-265.0883772394328,0.43441377200123554 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark45(-551.7926736552027,-213.68451663432876,100.0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark45(-551.8588637281983,-195.84392579090414,66.27893776814778 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark45(-552.2825002448673,-231.63304295183292,24.541775458433406 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark45(-552.4662326268586,-200.53551321499924,10.507732460667114 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark45(-552.46698947761,-194.3664374105632,87.7116614221903 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark45(-553.225455049698,-222.1418874324034,100.0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark45(-553.2674345564137,-252.36745859302917,95.2274831271805 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark45(-553.275512243636,-218.57146362383537,50.0226705496805 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark45(-553.4757953830887,-203.95132422999424,57.70526107728148 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark45(-553.5052144426326,-218.3548440877873,13.959321152761945 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark45(-554.3691573574409,-235.04787641211928,100.0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark45(-554.447234162109,-256.06300191689144,30.517077677480472 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark45(-554.4534933388219,-212.78444543815874,100.0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark45(-555.0724153341723,-199.58755560801242,29.2412669578527 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark45(-555.2770090191235,-243.25801956891928,93.81769501145249 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark45(-555.6221911292321,-240.64026193183915,26.176554950294985 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark45(-555.8990803730445,-190.13431738068235,23.760939854731177 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark45(-555.936281433546,-261.1913038765464,35.19500100654284 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark45(-556.0333824698322,-201.74347949561357,24.143314886575283 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark45(-556.0711326071374,-217.91156729911467,49.22643835205125 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark45(-556.2728746911221,-257.92711237432576,17.63114241795283 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark45(-556.3176427578185,-300.74013305433834,65.45677553157952 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark45(-556.4043701315547,-194.57363511470237,88.31092181902248 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark45(-556.9921008751911,-234.03464071788298,100.0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark45(-557.0181525880953,-247.19315323061778,96.51937949679467 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark45(-557.045652147219,-230.3130682692129,3.260283628156884 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark45(-557.2167960100791,-198.62747813877198,100.0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark45(-557.2360740846393,-205.40385932230006,98.38685053293483 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark45(-557.4268449550741,-194.5220972294984,10.564942838698713 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark45(-557.8656326899281,-197.97147489206742,100.0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark45(-558.0823730674492,-206.18902745471183,100.0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark45(-558.2474970199827,-248.797579273017,100.0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark45(-558.4196801956014,-193.15376560863777,100.0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark45(-558.9579077857259,-258.9885617316737,2.718881679301191 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark45(-559.115525097368,-235.60304109222227,22.985706524695132 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark45(-559.7179444122785,-188.66018114941755,61.29573501235407 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark45(-560.1984953479058,-261.2190485828321,42.21514404352835 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark45(-560.6118516526188,-187.29336221906573,100.0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark45(-561.2471639801983,-209.04039449095882,55.01504612711244 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark45(-561.4714297166504,-240.07353043837793,19.270297760043164 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark45(-562.0071781500001,-184.651397820265,79.80524696960941 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark45(-562.0562475245896,-194.7181437186758,32.93753647287798 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark45(-562.136337612549,-286.04460331306484,88.48667116558971 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark45(-562.1384776314595,-212.783659755441,93.83981057857162 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark45(-562.2253306204691,-186.83616863756825,38.07778245894079 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark45(-562.2407928507565,-373.9376338538775,43.16352110616833 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark45(-562.7152275440639,-224.6642456862005,57.01076515190323 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark45(-562.8325656913446,-204.39891345730783,40.97552815818821 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark45(-562.8562523734118,-199.69426367942725,100.0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark45(-563.0292325278383,-196.33038689443433,23.308236575709444 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark45(-563.7842818118875,-185.30348669696272,81.93606752570389 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark45(-563.8498456040976,-222.95195983433587,100.0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark45(-564.2375792253097,-185.76175644107028,100.0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark45(-564.4126398516851,-198.83211336788935,57.73636931439523 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark45(-564.6031707451993,-241.65788444405683,24.120532801612967 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark45(-564.8879232704155,-198.45080310350633,100.0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark45(-565.3165325712908,-190.66925373139054,89.86286971814843 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark45(-565.4153475142238,-185.39066109199132,65.21875438856803 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark45(-565.4583492405553,-193.07026190748635,30.78997661541078 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark45(-565.7708073628639,-257.0667282218052,100.0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark45(-565.9601667654464,-195.81022942843947,100.0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark45(-566.0546238074016,-193.38217754160664,44.73678763893773 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark45(-566.1120233684818,-191.03609950826313,48.90366360872943 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark45(-566.3745009836234,-238.06736926958968,64.44875407302192 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark45(-566.5138407332428,-199.0651282473376,100.0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark45(-566.5615886272551,-197.52985087753834,87.56050190336063 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark45(-566.5774242007398,-221.7004542808331,38.37999685294557 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark45(-566.750950076708,-213.40319830935118,75.87686533624736 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark45(-566.7803120652509,-183.43709018606705,43.47577117863989 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark45(-566.8034309837458,-185.96816402472834,31.87810264186757 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark45(-567.1228172279385,-226.71922138581726,93.75811711974109 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark45(-567.2521671955315,-190.26076404828848,100.0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark45(-567.472021810476,-205.01655451002352,51.1263444743755 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark45(-567.7184346951097,-263.4120623442416,59.85827499463056 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark45(-567.755846324045,-200.08603794954917,73.15369487287737 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark45(-567.9119256119209,-179.98965592583886,27.514663374821666 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark45(-568.3873918198157,-211.35231258193375,54.30927195701963 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark45(-569.2624947778697,-199.8923081145987,100.0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark45(-569.3569480916364,-194.12741543283136,100.0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark45(-569.5396875997747,-184.907484371474,33.85287946219316 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark45(-570.2256595735031,-268.6816019502793,80.03341815429327 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark45(-570.394900900291,-222.51836572558128,0.5301793380629647 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark45(-570.5020624948656,-199.63034162561877,38.98644472187732 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark45(-570.5866138669775,-184.25843170851093,17.22225660811077 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark45(-570.6339761688901,-203.40126675422715,99.62154830503465 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark45(-570.8417674751662,-258.35101952071824,25.651266017864344 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark45(-570.9906832537612,-186.80412713480985,90.58647787558138 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark45(-571.5026694294565,-227.68630669903098,2.5363472799314337 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark45(-571.5964982650042,-181.69377399183264,96.54273411952136 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark45(-571.6878521051902,-174.77982292117247,72.80235579914205 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark45(-571.9260389042777,-174.20734017694247,100.0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark45(-571.9605013531452,-186.87867576132123,28.46600675117901 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark45(-572.0515503395013,-192.13889088154997,100.0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark45(-572.3690276140258,-264.334503559103,100.0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark45(-573.2200650147042,-196.26374289282415,1.286793400626678 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark45(-573.3936617537099,-187.5806293980949,2.7829962605225376 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark45(-573.4936759140874,-178.20772507156173,0.3710471838068159 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark45(-573.7732997149808,-243.44530303549945,63.04171593672035 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark45(-574.0759343369641,-173.1733764178459,37.60049051874168 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark45(-574.1453447092975,-199.82476351148063,100.0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark45(-574.498874005709,-171.97523105956785,0.4727047266331823 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark45(-574.5929911912489,-254.16498213999853,34.68171611131882 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark45(-575.12123439069,-259.0199130352491,87.85387177894387 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark45(-575.290911283226,-225.1504385775317,87.40685180608531 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark45(-575.3964770929871,-275.10538669648764,26.07824702747456 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark45(-575.5235090619883,-213.01684422584879,19.03591237151801 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark45(-575.6605654400976,-183.8855188614452,74.10570287088666 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark45(-575.8041653806184,-263.7921287851709,100.0 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark45(-576.0519972112264,-180.34198592248842,37.919985172403926 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark45(-576.090659482747,-204.0756174179151,79.92224100908783 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark45(-576.2573392402779,-192.83697013890503,100.0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark45(-576.4301571567748,-185.24527984027208,81.17768632881047 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark45(-576.5195483258032,-201.05273157796347,24.134460418472997 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark45(-577.3686597084817,-169.32001476453306,88.94300905024434 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark45(-577.5563108601397,-186.97001957014308,37.37041428874676 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark45(-577.9191922387904,-187.61035251700287,100.0 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark45(-577.9378586479021,-234.870285189514,55.69635319152556 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark45(-577.9649025989015,-197.49819595151342,66.52498833173163 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark45(-577.9686152269608,-178.45499155354386,1.2232870478463553 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark45(-577.9697213185807,-239.96386356372406,83.87028445654857 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark45(-578.1134319611372,-249.74794191121737,100.0 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark45(-578.2411296691636,-229.24100194549743,44.14142042223088 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark45(-578.41745356551,-213.46285172368832,61.011262542184824 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark45(-579.0955179767604,-259.65750955692926,76.41522206089883 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark45(-579.2262470014455,-188.2850599336271,84.21461550796765 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark45(-579.5866093883963,-168.43060248229327,11.783875576149725 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark45(-579.819989883986,-201.80195667293765,13.374551265434206 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark45(-579.8621751344682,-213.1022504002523,4.18992555241941 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark45(-579.8923434139014,-194.31556541976937,100.0 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark45(-580.1822364150529,-214.59330964412513,22.795953488653865 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark45(-580.2900004415213,-188.40865262057147,61.519927824506425 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark45(-580.783821260895,-183.61540306901628,40.013045528930206 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark45(-581.0780816341831,-261.3475324784142,73.24058857369309 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark45(-581.2401082934441,-176.4539394575819,44.146005583771625 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark45(-581.3131227229338,-191.20142331816794,76.56911412441244 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark45(-581.5880773919098,-226.4340313293001,30.90569858699618 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark45(-582.0946355153447,-184.3177594771996,53.23901263775491 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark45(-582.4098962110621,-177.99153547353046,83.81652617924621 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark45(-582.6838558257356,-182.81912599846814,55.49355687523584 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark45(-582.6949367112662,-199.76531412636052,77.69800583967702 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark45(-582.8738538521216,-253.45876134665252,61.20148368968546 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark45(-582.9529343681207,-177.71669165667635,36.81941170656319 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark45(-583.2709270605907,-212.19295673166934,59.470463271771536 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark45(-584.0377291483265,-171.2120213533882,79.65775368171052 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark45(-584.4343123018696,-181.16201154563828,62.957921363367916 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark45(-584.616624843057,-188.98991825266143,14.450743444751254 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark45(-584.9807507756847,-234.40475542845985,3.1207086622391955 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark45(-585.2445007603338,-168.60733947138098,21.960660361095833 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark45(-585.7531721190167,-175.8888910297655,84.89141255454635 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark45(-585.8096068312141,-177.94272181504618,35.52914076304941 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark45(-586.0153145103322,-164.28749261550087,0 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark45(-586.1117345633153,-165.10112686521308,27.133390892947688 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark45(-586.9136276490964,-186.05208207909854,100.0 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark45(-587.1112728839232,-192.79430058238398,78.00448862288826 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark45(-587.2485944500172,-205.4118333873273,44.59940191625253 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark45(-587.5317798440814,-195.77687752491582,62.97614379820152 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark45(-587.5637959127774,-250.6223029406186,27.57108583211169 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark45(-587.5642871389541,-165.3766472747751,20.23579838067475 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark45(-587.6733674459989,-253.70081796917884,63.226775506668616 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark45(-587.8513737023776,-185.76816181259346,26.661331182492788 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark45(-588.1187361056801,-230.62607025679603,2.940275141847664 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark45(-588.4687310638933,-199.66786857425433,17.66785842140297 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark45(-588.4916944269152,-161.75404076774788,56.8455364701517 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark45(-588.8464021444096,-178.96933267481705,64.29909833681234 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark45(-588.8490876510367,-161.7061401877612,100.0 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark45(-589.0742287625076,-184.19590060636872,3.552713678800501E-15 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark45(-589.1659688784096,-189.96844696459704,36.973179228276706 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark45(-589.4869749830846,-166.04542639200338,43.55138573212136 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark45(-589.877007852566,-166.47563592698145,50.34523702479737 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark45(-590.6886455327945,-162.65636274242385,3.122260079672003 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark45(-590.8346506540398,-157.1120611391802,100.0 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark45(-591.2187999889545,-234.99325465832166,81.51113373542404 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark45(-591.3431679808267,-181.4531684841598,7.967130990986519 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark45(-591.4251684808379,-161.357608274027,79.52067255624888 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark45(-591.7796588601122,-175.181502366815,37.417085928989906 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark45(-592.3070931191294,-168.258855271009,100.0 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark45(-592.5406862504234,-207.78895232067615,97.70980564315036 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark45(-593.027724196872,-187.62666376243706,29.870213309501537 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark45(-593.5164083297595,-177.33066743222565,48.128307208308996 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark45(-594.1035213121049,-267.7053363790683,37.58751601993495 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark45(-594.2306667252957,-157.1927682926346,37.39545758852901 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark45(-594.3842689887999,-246.7296673367585,100.0 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark45(-594.5836653917202,-179.5805394495742,16.077071989032007 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark45(-594.7223086135343,-176.8664578221463,8.52357657032097 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark45(-594.8717753377008,-178.1003590632629,97.44169293700259 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark45(-595.2203877184568,-153.0314923042921,7.969140605851138 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark45(-595.2465441865319,-224.298836955186,86.89421840639505 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark45(-595.2800170310082,-176.38424431177276,18.482993265667645 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark45(-595.4895070288845,-173.03301558955928,18.352974569327245 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark45(-595.6253967650892,-170.2109375505724,88.69947136009421 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark45(-595.7293455372842,-184.28081938744361,11.910271654362163 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark45(-596.347690069063,-164.79093662961705,76.81558941003374 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark45(-596.417637543953,-152.65541458471537,89.25491912678777 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark45(-596.6861272948577,-164.00783018791498,100.0 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark45(-597.0335452468813,-177.9508636530295,17.390344342473114 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark45(-597.5787611099962,-204.05639832525503,99.05641336596463 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark45(-597.9055566387993,-187.61917425563058,58.94906596599671 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark45(-597.9861469696983,-150.65104799819534,89.424881655154 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark45(-598.3747518446291,-177.45651962653642,88.50204960245375 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark45(-598.9250980070982,-190.16341015572044,16.911227520199247 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark45(-599.9193110363603,-156.96364460166313,79.65127275842184 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark45(-600.3884496365448,-152.55024192410642,90.85219791456905 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark45(-600.8351757168087,-160.54315192107674,100.0 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark45(-600.8439888316735,-164.68989252414312,33.95700674607275 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark45(-600.8724294669264,-196.70120287285982,37.49302830137103 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark45(-601.1799813311279,-155.78638879131017,71.71539497681539 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark45(-601.950110708732,-190.09082670930079,35.50096908470101 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark45(-601.9575086059522,-185.5967483537033,81.85154378071027 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark45(-602.0511308016856,-146.65437514962886,92.48868474453283 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark45(-60.22305233462624,-707.3249387499411,96.1836086909137 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark45(-602.5125164795098,-184.3751229301367,27.273351219549568 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark45(-602.6504090937972,-202.8020114803263,67.99168800485069 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark45(-602.9258542418872,-232.710711528698,7.155530996004984 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark45(-603.1153011295845,-211.24917252399734,100.0 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark45(-603.1975874009547,-171.47462265925563,3.4126421471348323 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark45(-603.5533040804369,-161.35893564951462,83.2599991560482 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark45(-604.1391223251899,-147.52058286529083,54.797290306976976 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark45(-604.568405709864,-147.92333306008734,100.0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark45(-604.6340432072748,-182.48086959907056,47.43700143742751 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark45(-604.7555053089378,-159.40470526291213,100.0 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark45(-604.9066439489732,-147.29251232982278,64.63365400858208 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark45(-605.0552909021161,-215.01824114527312,38.62021168146359 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark45(-605.8625302246147,-171.13337642586154,100.0 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark45(-606.318486944517,-146.37869543408712,33.895663161934095 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark45(-606.6092628797844,-151.39006735857822,100.0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark45(-607.0731260393655,-141.1208513435467,89.27329642258778 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark45(-607.2749688069632,-199.3091367946675,6.020474330284856 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark45(-607.375682006003,-152.60799020250641,18.87906619122211 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark45(-608.3147929583283,-154.19079190677795,100.0 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark45(-609.0168896287199,-188.0573699458506,1.1655142792423447 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark45(-609.6667392303978,-179.18263560007617,51.897229366876275 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark45(-609.9706832778538,-140.08314325071194,45.83315943590529 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark45(-609.9790997238865,-188.14236224545482,33.46245404906401 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark45(-610.5019936924128,-148.75200572567934,91.25388358366482 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark45(-611.3036288256449,-172.05689842998547,96.32339973714448 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark45(-611.4671904021468,-135.6514707664377,6.728150090218946 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark45(-611.5522204458712,-158.1026487670889,100.0 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark45(61.17023431778412,-30.445479027087472,-92.18155419987153 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark45(-611.8938597097049,-147.90655411659415,68.8650196328783 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark45(-611.966941788328,-181.00757372752054,73.75339487161975 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark45(-612.0368580581604,-134.3629183650532,16.30733600988637 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark45(-612.4240641114475,-150.19540344952242,60.883898168486525 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark45(-612.6869701319498,-147.94993569794914,86.35786477910469 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark45(-612.883246065952,-203.94361999972526,9.727238309882267 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark45(-613.1963513095708,-155.457342875927,63.75919380641571 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark45(-613.5666430038078,-168.23590791461046,84.14899006905515 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark45(-613.6083142328993,-143.62268032940264,40.88762760444314 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark45(-613.9838255989429,-168.5422296995557,100.0 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark45(-614.4269742223865,-207.45581570078974,12.136009470569391 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark45(-616.0140037584482,-154.01044556089303,91.32195983637351 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark45(-616.3361877106591,-138.54577886700616,69.48933193050217 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark45(-616.7488278652488,-130.31722375100512,88.76811658035805 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark45(-616.7492905205505,-184.97123757321862,46.195170538918546 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark45(-616.7602169090303,-133.26771448611072,37.66203037763748 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark45(-618.0495704421388,-187.67820422905857,100.0 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark45(-618.4214986927124,-168.54896726148885,90.30905239052021 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark45(-619.0671489896741,-173.01861054081735,27.296654852320756 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark45(-619.1588199889902,-178.76327187253855,18.268599980126893 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark45(-619.2025060880841,-179.7965359027208,100.0 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark45(-621.0160376981537,-135.2404710516476,88.46355329016225 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark45(-621.0243543452965,-154.30970436563237,77.22651638764921 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark45(-622.0273292545207,-184.45544630533743,55.05077019649147 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark45(-622.4506659648273,-186.82459042437253,48.19824446883746 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark45(-622.4548771100781,-130.42057599155953,24.265904972052027 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark45(-623.0630756173642,-150.86435132078375,100.0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark45(-623.4660381336438,-196.23781871030292,100.0 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark45(-623.4851007250453,-149.15590858666502,94.88876601127254 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark45(-623.6887118220423,-136.58958176396575,100.0 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark45(-624.0607580731107,-181.6203330323664,44.283611016428694 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark45(-625.050394110815,-139.82814616868842,25.73940092019025 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark45(-625.2331440401192,-167.24413946908982,100.0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark45(-625.6148165839672,-175.1391246743451,28.671513770537388 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark45(-625.8058026194542,-138.09534660883665,12.81170125235569 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark45(-625.8216536973295,-134.02725529969302,10.893298478490848 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark45(-625.9248588189378,-140.6520270426387,68.7088511529744 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark45(-626.5794550688519,-188.58509153801862,100.0 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark45(-626.6528508279166,-210.09865661848283,56.22650798208329 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark45(-626.938855710768,-135.66145208246746,45.87379925841773 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark45(-627.0844593449949,-183.67185441853408,59.046085615912546 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark45(-627.3175897209748,-132.61251218175852,67.29797557066638 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark45(-628.2288524879051,-183.84875304632675,40.6138445322369 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark45(-628.3974197208806,-118.34851486631939,28.380051433453133 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark45(-628.4478160919075,-138.92313595419657,27.639433217973348 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark45(-628.5063256831281,-190.28507063023545,100.0 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark45(-628.9664818235203,-181.86004623772138,66.53413139157288 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark45(-629.0489647490839,-154.63443632979744,48.83898365321829 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark45(-629.0690253816422,-126.30398418482557,16.013288301209144 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark45(-629.1051288597755,-167.55184377948575,97.98294126311933 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark45(-629.4139448949475,-175.69700962589098,100.0 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark45(-629.6572953637267,-180.95775883410494,42.10361842376932 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark45(-629.9425559024858,-161.1447832859269,100.0 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark45(-630.3749920081528,-159.95007439845023,2.2256213525556916 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark45(-630.7097496621595,-266.64499100546317,88.57965384742147 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark45(-631.0376592860406,-144.80548832978374,83.98849065732384 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark45(-632.2284233304123,-134.0067760324272,21.848973644950604 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark45(-632.539840330868,-155.42221510274487,64.9783579608636 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark45(-632.5582387081614,-161.5825298188923,7.462569779728142 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark45(-632.6894908558654,-148.5009459381556,99.04229148882948 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark45(-632.9209888826787,-139.95735383768329,0.8561295464306795 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark45(-633.4127495091388,-135.61316546225393,16.594576669426203 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark45(-633.8805315820113,-184.07217090594798,39.10082463831452 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark45(-634.3639347937317,-135.96075963754078,67.44267092030731 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark45(-636.0151715949994,-111.0033733678542,91.38768537085241 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark45(-636.0336971260788,-188.7620823149621,27.662907017997924 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark45(-636.3940581864006,-110.66661370151934,52.998393463724426 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark45(-636.5377522811241,-112.42003340896747,60.5004386381392 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark45(-636.5919977515083,-169.1402050805308,42.14449530168889 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark45(-636.7620075968614,-122.98541377027328,31.208251509111705 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark45(-637.538326038906,-112.7706466893884,44.653013240094396 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark45(-637.9230341140924,-123.5398713348541,8.926692706005895 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark45(-638.1566814626076,-121.31560130456342,3.22669310113848 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark45(-638.3957484348825,-131.98782413411817,53.1518700302872 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark45(-638.6582330010332,-174.70621583624185,75.2776913906971 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark45(-639.2949758190653,-120.67179933816777,40.7108216188891 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark45(6.39766764733487,50.35991586603237,0 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark45(-641.1315705843563,-133.03540677782615,56.60613558092612 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark45(-641.3531320047764,-112.98208468158825,24.067444113083653 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark45(-641.682456230348,-184.16246369307214,52.528209523401046 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark45(-641.8276134173137,-177.77466537712257,19.669085815532767 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark45(-641.977330457312,-136.9263899144844,100.0 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark45(-642.8862218247785,-138.66770865305494,4.775226053214894 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark45(-643.9357415646112,-153.41857130544363,83.68266679318774 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark45(-644.1161640068885,-123.0813704752018,20.6336938233689 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark45(-644.2966602197505,-105.71756885914206,20.491535385925346 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark45(-645.2321958332728,-171.88525772915872,79.2913278032656 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark45(-645.7722087675493,-214.43973431807865,85.43123724705072 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark45(-646.2208502396591,-100.0,100.0 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark45(-646.4007090132989,-100.0,54.962045498005665 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark45(-646.4446821030568,-129.50509004199043,20.89435649470377 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark45(-646.5268861871774,-100.0,22.916953198699236 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark45(-646.701542953374,-100.54713389777207,43.083603767276145 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark45(-646.9673145756408,-177.4173406335072,8.004254904185075 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark45(-647.1213920941782,-106.2264248517406,64.74017085162524 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark45(-647.6410437278753,-100.0,67.99674215593805 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark45(-647.8006381353515,-100.0,98.69854385897631 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark45(-648.6060361343184,-101.86591829756284,40.34233215017886 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark45(-648.8105133956907,-136.1033097948842,33.14033224765305 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark45(-649.1577785187139,-100.0,100.0 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark45(-649.2557488967062,-100.0,91.99587182932942 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark45(-650.3299835725187,-100.0,26.172604151707233 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark45(-651.9589813462201,-150.2676318659413,63.448530726987514 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark45(-652.2227020300668,-99.28354609927679,72.0481741634309 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark45(-653.4734921799877,-100.0,100.0 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark45(-654.878951439404,-123.7791013688964,100.0 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark45(-655.0582024007261,-100.0,78.99259634212282 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark45(-655.1990971999599,-151.1777331547729,26.60388607537223 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark45(-656.1062259696786,-115.43170695335297,5.257828119195346 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark45(-656.6518371437513,-100.0,81.59736904129835 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark45(-656.8799384148865,-100.0,100.0 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark45(-657.278053899739,-100.0,8.23203449308285 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark45(-658.2633031371781,-99.66509724064221,12.639487124174508 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark45(-658.7002213564818,-100.0,82.96831972245334 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark45(-658.9953610088719,-108.43989062878931,70.4657834997399 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark45(-659.3422230915402,-98.66439280509461,8.028389910954758 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark45(-660.3804442459223,-98.36112055322675,50.11722650799945 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark45(-660.5879173107371,-137.8189273753442,32.801882454508785 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark45(-660.8748905503279,-100.0,100.0 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark45(-661.0918398394682,-87.33565615659911,12.196262256787035 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark45(-661.4231276673067,-121.7408235894017,100.0 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark45(-661.4863706114245,-100.0,100.0 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark45(-661.7236956444888,-151.68985102750293,34.79106607632707 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark45(-661.7338846361597,-131.43659936805201,52.714495303515946 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark45(-662.264910026725,-113.92799288075844,34.62434194076823 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark45(-662.4575693148713,-98.3926779346041,69.81964500281356 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark45(-662.6936854483757,-94.63335110423641,23.636495404980323 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark45(-662.9896136007256,-171.45288126730298,27.119690889666884 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark45(-663.0535922565953,-100.0,100.0 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark45(-663.2328976653486,-87.85668932521926,80.02143058943909 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark45(-663.4357710653081,-116.58197541815505,7.105427357601002E-15 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark45(-663.527797989138,-100.0,100.0 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark45(-66.40185587626158,-702.7349029923741,10.55540469031122 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark45(-664.245362381465,-149.5172058509678,3.6033410537042556 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark45(-664.9345573756103,-89.61053677153559,40.04213361556154 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark45(-665.1470676884933,-100.0,100.0 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark45(-665.3071072875813,-100.0,100.0 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark45(-665.7196237420903,-100.0,77.17504082091517 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark45(-666.2397974790813,-94.44509978183916,19.93761453122322 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark45(-666.9810001624271,-145.96746583476056,57.36379226789879 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark45(-667.8071932068093,-100.0,22.902436328979263 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark45(-668.1650027574107,-100.0,100.0 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark45(-668.2176481146731,-154.24773468490585,38.412187479527205 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark45(-669.6254226950832,-91.78668126483213,58.496426603836056 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark45(-670.5472411980761,-100.0,57.850171196952715 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark45(-670.7201161270084,-96.4241544910169,9.274355753795604 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark45(-670.8392805872812,-104.81904470381122,31.686389153556632 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark45(-670.8771801622493,-79.96511182529375,62.28942554451589 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark45(-671.1969715993475,-97.80105628569964,77.90277723355445 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark45(-671.3578633850774,-100.0,9.909097790497468 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark45(-671.6103866245095,-100.0,100.0 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark45(-671.6668048573118,-81.7400141518062,10.362634359727167 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark45(-673.4841052513366,-80.40063793829684,39.45662707197971 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark45(-673.7410052766609,-102.68042436924136,80.4595792882586 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark45(-675.0542988426621,-91.26414934234299,22.298432565045317 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark45(-675.7862886161859,-92.404869966597,72.79353622844954 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark45(-678.7791890012749,-155.12432075460796,98.8987600907306 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark45(-679.7571150027926,-100.0,100.0 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark45(-680.0399150306891,-100.0,12.454784747043977 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark45(-682.3429813212634,-108.44445195282402,35.140364653853396 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark45(-682.497798433395,-74.95482585973747,59.195869420353944 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark45(-684.0655961764459,-74.02934382398662,75.62183803059746 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark45(-684.5734962492072,-83.99153196543696,100.0 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark45(-688.2212499517141,-140.09968005077695,45.827746894245394 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark45(-688.7108170612265,-79.18675808279343,79.38201942999177 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark45(-689.7557063473885,-88.61817049145998,35.90388101741161 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark45(-690.4703093747063,-177.29571137327335,96.06030323136662 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark45(-692.9462242042591,-68.92201213919421,61.16270784828072 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark45(-693.3346889816294,-100.0,21.447014939048614 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark45(-69.52028155836592,-692.4745981467894,64.46506645371983 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark45(-703.7341509550862,-67.72500033845182,30.322269601012863 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark45(-703.9053300527297,-162.0142742469119,54.02405319600879 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark45(-705.0116143492703,-58.330294212704125,88.12221019609655 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark45(-707.7033966712937,-111.04622513144889,31.746960027123066 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark45(-717.4573477413668,-82.74800871886758,89.33363998499289 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark45(-724.3439462682047,-42.639624807310184,59.00449068641336 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark45(-726.8375637332165,-106.47152984048154,48.70896190499582 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark45(-73.06734832361991,-708.0674943595923,89.39017442366543 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark45(-74.34923443432824,-677.915603731819,51.311749509363295 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark45(-746.9956842781494,-0.17547869968448992,53.29945757829665 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark45(74.74299461621705,-74.74299461621705,0 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark45(-75.6898071539211,-680.9491955490246,44.423567985396204 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark45(-77.17266535486098,-676.0771702724796,40.87213059762428 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark45(-77.44710227122647,-89.95708380026765,0 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark45(-77.8328836194538,-683.3342930862204,8.775508894703023 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark45(-79.09821273629754,-667.9734604586129,14.692201736906668 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark45(8.178640588088058,-762.0511790895239,0 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark45(-82.26139023991952,-692.8263307938815,0 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark45(-83.73584097228002,-677.1292754618078,21.80240932534548 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark45(-83.94422438780802,-697.6707590258595,18.173666379976595 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark45(-84.81467392262914,-671.5291407166891,76.67369373852412 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark45(-85.20861932473018,-663.9217710445774,6.577391613780776 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark45(-85.88951461432862,-703.6219891938604,83.47732188908918 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark45(-86.3943820194755,-660.0628662180218,99.97777660418225 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark45(-88.15712205062766,-662.2686093979005,22.433229217330066 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark45(-89.17285323275017,-718.5286601306994,59.72387622764353 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark45(-90.11687636109858,-664.346411081465,18.578764758823766 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark45(-93.10978987392811,-683.788715622795,78.78697328758108 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark45(-93.8181031211326,-712.4596027715424,35.493067637686806 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark45(-94.40891458408711,-658.0184082567029,19.106711076059298 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark45(-97.1035418583111,-675.0156618227279,78.42094723407683 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark45(-97.99206720461828,-649.0750099739109,4.399653589300328 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark45(-98.55603632026173,-651.0029902622554,98.41158244762022 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark45(-99.0375103748685,-668.8797795630729,29.022134751153402 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark45(-99.62576699078708,-667.2674625838944,100.0 ) ;
  }
}
