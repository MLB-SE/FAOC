import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(0.002012540723402739 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(0.09817508177502787 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark33(-0.1999608137336275 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark33(-0.3777703252000507 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark33(-0.3953163619603617 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark33(-0.4102020637247277 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark33(0.4310506407681629 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark33(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark33(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark33(-11.190587481021595 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark33(1.1274507759694075 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark33(-1.2154326714572542E-63 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark33(-12.566370614359172 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark33(-12.686949722536653 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark33(-15.291160713877545 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark33(1.570680465841445 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark33(1.5707963264767175 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark33(-1.570796326794893 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark33(-1.570796326794894 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark33(-1.570796326794895 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948957 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948961 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948963 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948966 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark33(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark33(-2646.503115785148 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark33(-2738.8738574253425 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark33(-28.275424011906637 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark33(-28.911433034862938 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark33(-29.21313859846235 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark33(-3.0814879110195774E-33 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark33(-3.1415926535897953 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark33(-3.141592653589796 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark33(-3.141592668491046 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark33(-31.926658929997572 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark33(-33.33464318135874 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark33(-343.88538442691635 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark33(-34.55751918995346 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark33(-35.59571032990985 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark33(-3.699676774001375 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark33(-3.702740222435324 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark33(-3.7036656700641544 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark33(-39.66453467724249 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark33(-41.4122540272222 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark33(-44.88396176134979 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark33(-48.390974295422275 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark33(-48.47348676330726 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark33(-5.015233455245792 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark33(5.488538582199396 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark33(-54.969950370967126 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark33(-550.778714378208 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark33(-59.690261439444 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark33(-60.83636552690965 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark33(-62.83185307179586 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark33(6.429211676637778 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark33(-66.6401072231721 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark33(-6.938893903907228E-18 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark33(-70.58410459884104 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark33(-72.41679579724223 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark33(-72.4419505296707 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark33(-76.49529031407965 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark33(-78.53981633974485 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark33(-7.921129274295822 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark33(80.40092022730539 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark33(-83.73384610562537 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark33(9.011352239729604 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark33(9.13560225977308 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark33(-95.70561886733344 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark33(-98.02154409063463 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark33(-98.61214371368283 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark33(-98.92465243537933 ) ;
  }
}
