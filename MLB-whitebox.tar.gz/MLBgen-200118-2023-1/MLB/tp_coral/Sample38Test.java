import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(0,18.90140385726508 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(0,47.46105427086914 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(-0.5247094801259031,-9.836214727221858 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark38(0,81.33657221065121 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,-100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,-2.2250738585072014E-308 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark38(-1.04E-322,-100.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark38(1.0502895886008296E-16,-51.57051671842428 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark38(-11.457855547527089,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark38(-1.1791094667462924E-12,1.5777218104420236E-30 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark38(-12.0035837056056,-191.89606912260467 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark38(-12.129649946280097,-18.6287369268304 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark38(-14.141624836214703,-63.028803713749085 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark38(-14.671339761690987,-2.2998087994840404 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark38(1.5777218104420236E-30,-79.45949836212952 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark38(-1.58E-322,-43.5037511890364 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark38(-1.6646600256603534,-62.25034846157376 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark38(-1.7763568394002505E-14,-27.492338059458234 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark38(-1.7763568394002505E-15,-87.99406719805556 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark38(-1.7910951422351025E-306,-100.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark38(-18.39001939215352,-51.166910864133655 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark38(-1.9755454881104765E-306,-88.78561403960998 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark38(-20.307347487456056,93.49515717744643 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark38(-20.36001817165436,-95.04380897587777 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark38(-2.075968839076844E-306,-93.29887325491325 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark38(-2.1895288505075267E-47,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark38(-2197.6053442371426,-0.007971669712532992 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark38(-2.2250738585072064E-306,-100.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark38(-2.25532261831628E-306,-100.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark38(-2.5835820670062275,-45.70578777360972 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark38(-26.73006990249772,2.465190328815662E-32 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark38(-27.39690323948807,-87.74835406521893 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark38(-32.4992681320571,-46.481035325177686 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark38(-32.63540387645989,-6.45283854221131 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark38(-33.51388624698977,-16.339843332391425 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark38(-34.056982090174955,-69.91526385054077 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark38(-35.348929399535066,-93.57029348170813 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark38(-36.90296456529023,-87.91806297061 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark38(-39.26446558411427,-55.99077219302533 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark38(-3.9460819314391244,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark38(-4.011740026528831E-307,-37.24441249143777 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark38(-40.182846617114656,-40.18284661711462 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark38(-42.27907168664229,-8.6701041416638 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark38(-43.44585418716977,-55.82213205358444 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark38(-43.57518349095211,51.844042140317356 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark38(-4.37314257905025E-307,-19.653920980331797 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark38(-44.17755660188454,-32.96179185287269 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark38(-4.440892098500626E-16,-78.00481312938402 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark38(-4.51104216776316,-89.2112764291607 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark38(-4.55584882673223,0.0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark38(-46.91621408871016,-90.06191980986725 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark38(-47.7048313931363,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark38(-50.247260790925765,-50.247260790925786 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark38(-50.855747230564404,56.4407218153396 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark38(-51.36100406870063,-51.36100406870063 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark38(-51.917703344806874,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark38(-53.1860597416413,-17.08267211963181 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark38(-54.608281004727104,-52.26579107170958 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark38(-55.43626704992262,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark38(55.629236575357254,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark38(-57.54730294438026,-96.28117324543481 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark38(-5.916316306194483,-94.58157419392282 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark38(-60.21401716691233,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark38(61.399929961553624,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark38(-62.12179057194265,-65.3386248430063 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark38(-62.334227582019494,-85.82055417641028 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark38(-62.987966888181155,-3.357752835514958 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark38(-64.87807269308541,-64.87807269308561 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark38(-65.77252828089732,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark38(-66.99196079840686,-28.178768695279047 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark38(-67.1240031967075,-67.70526686640225 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark38(-67.79067737907813,-19.25479140508584 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark38(-6.902152141549493,-7.641641231894255 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark38(-69.38683991264591,-2.8480945388892178E-306 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark38(73.804963776568,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark38(-73.90797979515432,-10.54657739742322 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark38(75.27161550811721,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark38(-75.38739503400149,-78.88696626604994 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark38(-76.18721498304254,-76.18721498304254 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark38(-76.31504740127492,-77.21730784258736 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark38(-76.7406199767615,-76.7406199767615 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark38(7.888609052210118E-31,-58.9162938889227 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark38(-79.04619967940427,-21.323017314535562 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark38(-79.0750225561836,-65.9552189212198 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark38(-79.66366102026971,-88.79649244404386 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark38(-80.02988823042247,-35.00793337821855 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark38(-83.44819908997347,-83.44819908997351 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark38(-86.309501028906,-87.32992992865351 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark38(-8.673617379884035E-19,-100.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark38(-87.80392854201365,-87.80392854201368 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark38(-88.02168048281574,-5.9011225823901015 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark38(-89.71500776018304,-99.03134413299802 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark38(-90.999723014853,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark38(-91.28812594203548,-28.55507591244543 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark38(-9.219312740268508,-147.38514082644087 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark38(-92.66785341085554,-81.92786420882157 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark38(-9.272582701669307E-13,-60.90479437421943 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark38(-93.18696922516536,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark38(98.650789473147,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark38(-99.24064534694895,-99.24064534694897 ) ;
  }
}
