import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-10.994340103311885,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-1.43E-322,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-17.648938146545404,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-1.865174681370263E-14,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-19.205432395483157,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-20.83184578557062,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-2.2761049594727193E-159,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-22.81894085396665,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-2627.7466705805327,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-2643.0733579499833,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-27.923903596530806,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-38.85785147197301,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-39.13837468636427,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-42.39303993393244,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,4.440892098500626E-16,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-50.16354194717183,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-5.123971036834301E-13,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-53.50309865192584,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-5.551115123125783E-17,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-5.6843418860808015E-14,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-61.44741085693841,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,62.725528635801396,0,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-64.70631756943683,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-67.90758106396254,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-69.62393060091401,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-70.17527195960042,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-7.748665426346662,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-79.04361525446515,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-79.96614633445662,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-84.36937502539658,0,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,88.95786304786026,0,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-89.99999999999991,0,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-89.99999999999999,0,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.9473880759221913,-4.263256414560601E-14,0,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-96.75067949737391,0,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-100.0,-32.68410002430273,0,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-100.0,-32.70244742943423,0,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-100.0,-3.508354649267439E-15,0,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,1.0488653907413834,-58.3367515998281,0,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-1.1681284420464602,-32.70387344840946,0,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,1.4210854715202004E-14,-32.700550745435905,0,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,17.344806858168205,-5.555082800799635E-14,0,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,19.295133801771442,-6.873128815570183,0,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-21.38200835699176,-49.731911451318545,0,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,21.636741983259764,-30.519655800251755,0,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-21.89806249724147,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-2.7099656892543464,-16.86413559556283,0,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-33.814899182398065,-3.5083546492674388E-15,0,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-37.1810046377393,-63.86336338218284,0,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,41.33465752348537,-32.69168488573868,0,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-41.798054339149736,-28.937321691974788,0,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-4.226941927526929E-37,0,0,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-42.90427705823363,-1.0658141036401503E-13,0,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-43.11417454171651,-1.145315923136934,0,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-43.91474900508665,-25.455899799931174,0,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,44.412722529076035,0,0,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-44.79553499248457,-3.5083546492674388E-15,0,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-51.265252549948585,-0.8978754286764143,0,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-52.22063281979255,-3.693646643083294E-15,0,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,53.47035726713443,-19.065192841206624,0,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,55.6966425941456,-3.1920879383409613,0,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,60.154462512767,-5.704877261270141,0,0,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,6.222812084572785E-5,0,0,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,62.72093662323032,-32.6639602604861,0,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-62.90398889466551,0,0,0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-64.68371197381842,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,6.643254062317577E-18,0,0,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-69.97703892173372,-29.652373790202716,0,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,70.74998184013981,-74.98843727647738,0,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-73.95473692324622,-11.875159315903488,0,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,77.85706695879696,-6.217248937900877E-15,0,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-81.13522098581483,-0.32522376388086727,0,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,82.35624458142875,-32.69925430884011,0,0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,84.04912388948662,-1.2773780630713816,0,0,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,8.424662449240799,0,0,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-8.572195032646977E-10,0,0,0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-8.88318879082908E-9,0,0,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,93.64803102239097,-22.85970576084391,0,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-9.51455436127637E-38,0,0,0,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,96.32109320913158,-32.70080246474272,0,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,99.29322114689668,-4.212919140880928,0,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,99.96085429987977,-13.07828707790135,0,0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark78(100.0,3.914395746321421,3.9143957463214214,-6.348743749899382,-21.059794507389938,0,0,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark78(-10.577275967069795,-38.88164797571952,-67.97088697496194,-76.15153095790566,17.818698436396247,0,0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark78(14.032626715042193,-12.735340438191924,77.26465956180807,68.91687639941202,-12.062751073496212,0,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark78(-1.6398832213263618E-17,-19.21647308521024,-19.216473085210232,-100.0,-1.4423059192553223,0,0,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark78(16.695850167077722,-2061.977985523762,816.5171171572847,66.32527841526849,-7.083006368074436,0,0,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark78(-20.46817493677331,-9.651158627870075,-9.651158627870068,-28.73086927143018,-4.2115510695480936,0,0,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark78(29.958178363303325,0,0,-57.29036682099614,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark78(32.20284757597908,20.81845417528168,20.818454175281683,45.10132164630531,-4.564422684942009,0,0,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark78(-3.320784391938194E-24,0,0,-12.585039371807827,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark78(-35.053157968224596,0,0,6.993096334282313,-0.870758906654487,0,0,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark78(-35.12525156755724,-25.412251861225617,-25.412251861225588,35.48977305127032,-11.258796252993662,0,0,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark78(39.772403442729235,-15.002725377255778,1.1442593347593402,-49.681131283899035,-2.0733654864011726,0,0,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark78(4.641796927490458E-28,0,0,-100.0,-6.27891354802523,0,0,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark78(-46.86639016620677,92.26231102766573,57.456830734259654,56.606648596806025,-23.946565436608708,0,0,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark78(-52.786735124679865,49.99118971122056,79.43573664745708,-57.76802604409217,-21.39442782704421,0,0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark78(-54.893609424510004,-72.7686547582969,80.98959207864678,-85.94143907615998,-4.263256414560601E-14,0,0,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark78(-5.542190628881205E-9,0,0,-100.0,-1.7763568394002505E-14,0,0,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark78(-56.2705093239803,-19.203846128993106,100.0,-20.756139248877403,-4.326868922695793,0,0,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark78(-5.804124371635752E-23,0,0,-99.39222930367558,-19.053451022974315,0,0,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark78(60.22112261416723,-1202.7438321936017,1428.2685081648935,-51.02148213722249,-0.01902564463109968,0,0,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark78(-64.64931930002436,34.32862113467962,78.48706760583241,-35.30013406595633,-11.40030309212068,0,0,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark78(-67.31162911742157,-64.4206640821317,65.98905841683066,-75.6837920270761,-1.5389053981604661,0,0,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark78(-6.915312591345414E-9,0,0,34.74229207765606,-0.3071670494700845,0,0,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark78(-72.08158636078983,0,0,57.10699394160903,-19.474989005300202,0,0,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark78(72.70312359294854,80.30262248954517,87.39559280169291,71.63734351228719,-4.538730757202714,0,0,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark78(-7.764045359899939,-12.546280227848627,92.99496986371102,64.64009065420865,-30.69851874874763,0,0,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark78(-82.29774919970492,-55.13464262254748,-68.7337827790177,42.53803891642036,58.306083580890004,0,0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark78(-85.45994199742522,-59.746136181746536,-54.27149804590628,34.2018634965292,-32.28100135182217,0,0,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark78(-8.681498365224385,0,0,49.14264186508984,-15.65398385817403,0,0,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark78(89.54415111580025,-74.6501212731799,36.49509662941591,-68.96561327605667,-10.983901991159172,0,0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark78(-9.716151053420401E-5,0,0,-94.25677067514664,-3.6071295029227457,0,0,0 ) ;
  }
}
