import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(-0.004219255761603764,-0.008438511523207487,65.3604894506461,0.004219255761603743 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-0.004942521005331046,-6.310887241767978E-29,0.7829653856654124,-19.54657437839856 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(-0.005091931928673493,0.0025459659643366495,-60.41938955402806,-73.16003329896698 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-0.005375724106897658,2.094656530110074E-24,0.783114157108824,-0.5077472296058473 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-0.006760520684221,0.0033802603421104974,0.7887784237395588,-99.89134190650347 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(-0.00726309200467784,1.5386991542512671,-128.9476992768873,47.13530202185435 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-0.00767825568978301,-0.014243592097659252,-6.3205146175695965,-0.778288201112586 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark23(-0.0087438895942703,-0.017487779188500217,-99.7411948066788,0.7941420529916984 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark23(-0.01014392346255077,-0.020287647733962473,-45.50381323686507,0.6230298991115027 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark23(-0.011883257896910134,-0.007583201957548708,0.005941628948455067,0.0037916009787743736 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark23(-0.013558333343270479,-2.112051842563334E-16,-0.77428654509826,-40.65610162776721 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark23(-0.013688858896140441,-0.02737771779228071,65.802285843458,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark23(-0.01508218355619484,-0.026675216339955954,-82.74897393145054,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark23(-0.01858374426217088,1.0716430744091703,0.6981621316029305,-169.39612463633057 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark23(-0.019429949776357147,0.009714974888177295,0.009714974888178574,-0.004857487444088648 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark23(-0.020483894874645716,-6.165290952701369E-65,0.7804723938778094,21.740265483360396 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark23(-0.0214207384051468,-0.006487318900579395,-101.41364540230688,1456.4171948610297 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark23(-0.0224569280192235,-0.04491385603844699,-0.08087839344113866,0.44425390742365123 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark23(-0.022672461576487987,-0.04534492315297596,0.29844581943882625,24.18559191338445 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark23(-0.02285498044560768,0.011427485921261086,-51.119834220517674,-6.9373927818972705 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark23(-0.023862315278960957,8.881784197001252E-15,-0.7734670057579678,100.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark23(-0.024378391731923084,-0.03257653585979934,0.01774163802347007,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark23(-0.02447826433010636,-0.048956528660212495,0.4525972944118537,14.64357044099205 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark23(-0.026410646892885303,0.01320532344644243,-57.800138267527885,-100.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark23(-0.0270242977674795,-0.04321108535823396,34.50819033417582,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark23(-0.027043430939131346,0.013421084369340575,0.013521715469565673,0.778687621212778 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark23(-0.027934263128133855,0.0,-10.192873428604614,-34.125008984973995 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark23(-0.02812005638606825,-0.056240112772136475,-44.703677104365084,41.47277419003046 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark23(-0.028132649103863483,-0.051865073198344484,0.014066324551931741,0.8113306999966206 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark23(-0.031641170753881065,-0.0632823415077621,-37.91035264501834,-490.75908280153226 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark23(-0.03565576932560921,-0.07131153865121798,-75.8417581623927,5.484284642756862 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark23(-0.03744270698820057,0.011806365370594873,0.01872135349409998,-0.005903182685297466 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark23(-0.0382553834251729,0.019127691712586437,-0.7659345795460151,61.61436269025302 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark23(-0.040905701795595384,-0.08181140359119066,0.49996937344541426,-25.383304674039874 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark23(-0.04198442429636811,0.02098575018429246,0.029592843468980272,-0.010492875092146232 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark23(-0.042198724639027935,-0.0840043785809168,-64.38229008709254,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark23(-0.04363156859791265,-0.08422677535604392,0.021815784298956226,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark23(-0.04388271015470477,0.01683503439887704,-100.0,-0.00417178176136432 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark23(-0.04397854027676651,-0.025762527224609477,-0.7634088932590615,-68.41976525836995 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark23(-0.0445913537006388,-0.08918270740127754,0.0222956768503193,-13.095478921722789 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark23(-0.045312330445936855,-0.09062466089186139,-18.58733228981469,47.39863111778212 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark23(-0.04538684697755474,-0.0907736939551094,-100.0,19.767622078252646 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark23(-0.04651514076977635,1.0824013045761018,-0.780229278551225,100.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark23(-0.04762565217184234,0.023725440680006083,0.02381282608592117,2.3416226779638807 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark23(-0.04885493842200452,0.02442746917697864,0.024427469211002372,17.212579772041263 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark23(-0.052214998326803264,0.0012884445967449344,-35.283989532659916,16.595795240518623 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark23(-0.05273016150638539,-0.07355082318510124,-54.15078044124888,-0.5257744588783771 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark23(-0.0535146539736683,-0.1061278830869625,-0.7586408364106141,-0.732334221853967 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark23(-0.05477772208193343,-0.10955544416386154,-29.02383977008644,36.18680807239376 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark23(-0.0553985851109447,-0.11067367169969099,-0.757698870841976,0.8407349992472938 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark23(-0.05590125132931438,-3.710198814843579E-12,0.08103138863427592,-25.208545800979508 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark23(-0.05592683033316852,-0.1118536594258954,0.02796341516658426,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark23(-0.05617911886312976,-0.11235823772625879,0.813487722829013,10.92808611625816 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark23(-0.056355770904987376,0.02775661266658128,-106.06239688526337,78.09293871965286 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark23(-0.05673088214930186,-0.11346176429860319,-10.955875219726916,0.19863525445216826 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark23(-0.05676413520756439,-0.11352827041511601,0.028382067603782195,-66.54451810293045 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark23(-0.06236339953450191,-0.12472679886284652,-8.6083010470553,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark23(-0.0645173092768305,0.03225865463841524,0.743808413414226,27.17900972295494 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark23(-0.06719043778309347,0.033595152765215935,0.7369071816579641,-57.5012162660443 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark23(-0.06904397435460123,-0.07538143678664799,-0.7508761762201477,-0.7477077183882086 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark23(-0.06908787775353668,-0.138171957020274,-12.674823396432352,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark23(-0.07110862895679404,-0.14221725791358797,-0.5884374039179671,0.07110862895679393 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark23(-0.07204965544507809,-0.024995971832217388,-176.64872788729693,0.012497985916108706 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark23(-0.07364243570291329,-0.14728487140582036,-27.59693900378829,61.54377875380109 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark23(-0.07633788999071855,0.02287350023166917,-0.5370600458327011,-0.011436750115834587 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark23(-0.0763686179724261,0.0381843086782459,0.47259915074335723,36.852633530612735 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark23(-0.07641073295949255,0.03820536647974626,0.29743436720311117,-8.937870412480478 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark23(-0.08085635134003055,0.040428175670015255,-0.744969987727433,0.7651840755624406 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark23(-0.08512336094782624,-0.024152565649358203,0.8279598438713613,-0.7733218805727692 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark23(-0.0852273882811522,-0.17045477656230434,0.698722641056512,-57.006928429102935 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark23(-0.08546568306492763,-0.1709313661298552,22.321434401376443,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark23(-0.08719364712928268,-0.058604747888641784,-48.21038894092495,47.19396274333803 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark23(-0.08756226143080982,-0.012924296620762554,0.025979363561039994,-0.778936015087067 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark23(-0.0878344308666617,0.043917215433330714,0.7904650890762213,-78.23388753563466 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark23(-0.08783890434414876,0.04377146008422805,-63.48174483389972,-0.021885730042114082 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark23(-0.08803249729859369,0.04401477464389102,-44.997174552211646,-0.022007387321945543 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark23(-0.09051330883368182,0.045093005413130924,-21.888552121602086,0.7628516606871734 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark23(-0.09139519019954567,-0.1827903803990913,-0.34857108547861815,0.8767933535969937 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark23(-0.09305462680601446,-0.1861092536120289,-45.43955725636508,-0.6923435365914339 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark23(-0.09344024083800395,-0.18688048167600774,0.046720120419001976,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark23(-0.0939855579608322,-0.17581321217132045,0.0469927789804161,-0.42082021454550866 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark23(-0.09444104277857382,1.369174303691622,0.04722052138928691,65.29794632742203 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark23(-0.09489331690692691,-0.006444165300514615,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark23(-0.09538181000741874,-0.015528691370973818,6.938893903907228E-18,-0.551982349156898 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark23(-0.09692644149987706,-0.1938528829997539,-21.856600592936616,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark23(-0.09833522973093939,-0.19667045946152453,-167.25627517183926,-0.41057535320007166 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark23(-0.10145231700256113,0.047477835481669395,-0.7346720048961677,82.70199678698638 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark23(-0.1018480180296566,-0.20369603605931313,-100.0,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark23(-0.10205789677045451,-0.204115793540909,2257.0573635256146,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark23(-0.10313291883002229,0.04485036719498048,0.051566459415011145,0.762972979799958 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark23(-0.10380224498635342,0.04583723198029421,0.837299285890625,-0.8083167793875954 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark23(-0.10503461985954485,1.2533389269125004,-13.450681304471859,0.1587286999411982 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark23(0.10505624098176986,-0.35289152742632446,-79.18098182090338,67.72090574818658 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark23(-0.10508936598773007,0.01802229699354936,-50.94261733785603,-8.077935669463161E-28 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark23(-0.10551719985628613,-0.08814230674067086,0.8381567633255912,-53.94512816679827 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark23(-0.1065825478746799,-0.21315813348679435,-0.7321047348538099,0.03025609491486734 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark23(-0.11007762437710326,0.04180908146410822,0.05503881218855164,-6.743470976931252 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark23(-0.11019895235474997,-0.10825804949631215,0.055099476177375095,-2062.5632584894365 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark23(-0.11262885115438533,-0.19924887036082736,-0.7290837378202556,24.970974197455213 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark23(-0.11363130192993154,-0.22726260385986297,-0.7285825124324825,-86.50253425690515 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark23(-0.11640603209342017,-0.14777622144017347,-38.417866823267524,98.70022690277712 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark23(-0.11691565059944042,-0.23383130119888068,-100.0,53.70824096226612 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark23(-0.11708948990329082,-0.11489023986907906,0.05854474495164541,-0.7279530434629088 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark23(-0.11735854259041023,0.011514170385783533,-63.308507042010774,0.11735854259041023 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark23(-0.11803806666214522,-0.236076133324286,0.05901903333107261,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark23(-0.11902656565212386,0.04871430577994541,-0.7258848805713863,52.23865735582956 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark23(-0.1206771575569978,-0.24135431496801948,0.8457367421389982,-1848.3541487050045 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark23(-0.12290961553220525,-0.012148694603429142,-92.1484124153481,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark23(-0.12338600417875556,-0.24677200835751106,0.06169300208937778,-18.303881675217404 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark23(-0.12482584492768228,-0.17655104369964558,-0.7229763296511136,-2105.428972509274 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark23(0.12624545442809582,-0.06312272721404799,-0.8492790564817351,0.8169595270044723 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark23(-0.12922213458382673,-0.2549776150799023,0.06461106729191336,-27.355702395235124 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark23(-0.13230229028034762,0.05893795264698687,-0.522252652208195,3.1512255253807187E-4 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark23(-0.13426348125401755,-0.15893748525176443,-1.2282730903757937,-73.05028375556171 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark23(-0.13491269651045856,-0.2698253930209168,0.8528545116526776,0.1349126965104584 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark23(-0.13752012913636263,-0.27504025827272516,-0.17995953378733343,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark23(-0.13795557908390735,0.06897778954195366,0.30189506230314217,-0.8198870581684251 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark23(-0.13925356900598462,-0.278507138011969,0.06962678450299226,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark23(-0.14461527673690555,-0.324341808055717,-104.38125388628455,74.93292519427544 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark23(-0.14477307113245744,0.07238653550139106,0.07238653556622872,-0.8215914311481438 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark23(-0.1456468480000639,0.07282342398120989,0.07282342400003194,77.71800643455792 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark23(-0.14662850761951784,0.07331425380975748,0.8587124172072071,-100.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark23(-0.14666557810315164,0.07333278905157575,0.07333278905157582,-40.802488024935016 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark23(-0.14867564530069083,-0.2973512904889938,0.07433782262236334,0.9340738086417941 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark23(-0.14940659335132178,0.07470329667566088,-0.7106948667217875,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark23(-0.15026658118041122,0.07513329059020557,34.35281574583553,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark23(-0.15133308027396403,1.190228703419297,0.07566654013698201,62.23673872006285 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark23(-0.15174246639455982,-0.3034849317003828,0.07587123319727995,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark23(-0.15351447230082457,-6.938893903907228E-18,0.7078198202382529,115.4237004532236 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark23(-0.15591765952118308,-0.30295031340960193,-67.36343297387523,0.15147515677193404 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark23(-0.15602184694437143,-0.30907131106180596,-0.7073872399252625,0.9399338189283513 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark23(-0.15724768390297794,-0.13486755034210454,0.7793683744508548,-82.07891721568467 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark23(-0.1575874698074016,1.2556048642654782,0.4168863400247079,-29.687512533093837 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark23(-0.15773751946357392,-0.1810201864085329,-0.6866069175896549,9.52596780848313 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark23(0.158831267119483,1.8458608055436445,-0.8648137969571484,34.420075385298915 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark23(-0.15898986618988875,-0.3179797323797757,0,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark23(-0.15941791476943906,-0.318835829538878,-0.6481108494811485,0.9448160781668875 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark23(-0.15983132927719623,-0.2811721054145874,0.8653138280360464,-100.0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark23(-0.1602801034397289,-0.2613745843582903,0.08014005171986446,0.1306872921791452 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark23(-0.16226433232667697,-0.3243243935867641,0.8664102053782287,43.27614894003911 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark23(-0.16677775804446793,0.07417294289125591,0.7764490461517515,32.91085911320717 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark23(-0.1670131711089667,-0.1805345626533893,0.08350658555448831,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark23(-0.16747640048971324,0.5025848106784409,-94.46726694426935,-1.0366905687366403 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark23(-0.1678218380539052,-0.33564142638268435,0.08391033069578278,-21.520108713001964 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark23(-0.1696825979735811,-0.08845179195957102,0.8702394623842389,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark23(-0.17077979892761974,-0.3395167251494207,0.8707880628612581,0.16943473484570915 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark23(0.17079818611443887,-0.48724779318015277,-7.652942622629055,-13.12753019984697 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark23(-0.17144913605904333,0.08572456802952155,0.08572456802952166,0.7425358793826875 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark23(-0.17247829184171523,-0.34469508039696994,-0.6991590174765907,-35.78610712029402 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark23(-0.17410894084873152,-0.012178949734677952,0,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark23(-0.17587899733856943,-0.3098031458112493,0.08793949866928472,0.9402997363030728 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark23(-0.17594180818633173,-0.3518836163726634,0.08797090409316587,-53.29645174465419 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark23(-0.17594981641626842,0.08119242577729241,-0.697423255189314,-0.040596212888644345 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark23(-0.1767861036418967,3.156029736134713E-11,-0.609313459421965,-8.912728201796655E-7 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark23(-0.17986441441227177,0.08993220720613587,-64.31080439198591,-0.044966103603067936 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark23(-0.1804470386498439,-0.36089407729968775,-0.2971475755528346,4.293556179283777 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark23(-0.18311133836936114,-0.34941329417619205,0.10637402124987339,-0.6106915163093523 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark23(-0.18351806197393672,0.0917590309869683,0.09175903098696836,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark23(-0.18389380843803949,-0.09858233825824911,-35.13511059769936,-82.83917165463649 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark23(-0.18660154820385857,-0.36999063806237764,0.1174853553779002,-0.6004028443662599 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark23(-0.18825225828710826,0.09412612914355412,0.07743306717865484,2175.2749959643893 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark23(-0.18974034645330135,-0.35731413677106316,0.880268336624099,-0.6067410950119168 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark23(-0.19010534762657852,-0.3491281025272488,-0.6903454895841591,-77.38450009227758 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark23(-0.19056986318019878,-0.37651175612179766,-0.6901132318073488,0.18825587806090027 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark23(-0.19171599255313876,-0.0663149091891476,-14.876442374614129,0.22787293587423618 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark23(-0.19217818401874384,-0.22219941925826348,0.6154526126636807,-35.885697060725306 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark23(-0.19254493433523645,-0.3850898686704731,-50.81897143015603,-60.233590000511 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark23(-0.1925577545247794,-0.38511550904955527,0.09627887726238882,88.25789143761861 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark23(-0.1964388745689522,4.05939462495598,-37.73188352190614,-38.20623252327712 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark23(-0.19658203821926543,1.1771466547620708,-44.171016553359266,69.31189114557634 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark23(-0.19674358969526987,-0.3929884348954202,0.10346199151263703,0.9818923808451584 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark23(-0.19750088767573604,0.0987336654807156,0.09875044383786802,-0.8343412677691078 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark23(-0.19861841892596432,-0.39707382759315824,-0.6860889539344661,0.1997014031824514 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark23(-0.19871947995613523,0.0993597399780676,0.09935973997806762,-0.0496798699890338 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark23(-0.2003671108446239,4.3790577010150533E-47,-0.5821995136882564,-0.019184895281417664 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark23(-0.20163498165990545,-0.6613605976186149,-45.45131533648717,0.33068029880930716 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark23(-0.20487116232327032,0.08877053774604397,-16.281091287102967,0.0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark23(-0.20489160955486044,0.07592918234308688,-100.0,100.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark23(-0.20498237273882436,-0.4099647454776486,0.10249118636941223,46.36420811705949 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark23(-0.2072197345816903,-0.4144394691611184,0.8890080306882933,100.0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark23(-0.20788804125702143,0.10394402062851049,-73.51788911698549,-97.08933355576907 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark23(-0.20821172850252717,0.10410586425126356,0.10410586425126359,-0.8374510955230798 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark23(-0.2091564810515237,-0.3676932696156948,-72.92609586078382,23.73821381693379 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark23(-0.21158183682316095,0.10579091811885469,0.1057909184115805,-0.052895459059211454 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark23(-0.21196634902188438,-0.32639121818860245,-0.679414988886506,-0.6055086825338288 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark23(-0.2122041555995826,-0.42440831119916506,42.92920081777718,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark23(-0.2139922193903916,0.10699610969519568,0.1069961096951958,-99.2513680359017 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark23(-0.21445442887879285,-0.07289196468711104,-29.060136871707744,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark23(-0.21649149097807086,-0.4187032890938029,0.8936439088864837,100.0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark23(-0.21766037884751427,-0.4353207576950255,-0.6765679739736912,57.67318975023113 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark23(-0.21780589349535306,0.0334224574738613,0.8943011101451248,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark23(-0.2212381243592798,-0.4424762487184388,-0.6747791012178084,-73.71797125339698 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark23(-0.22274663915239667,-0.4454932783047867,-68.50256940500644,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark23(-0.22300181124676174,0.09930572702560658,0.09930572702560568,87.28350742979552 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark23(-0.22322276164066984,0.1116113808203349,0.12949376540287716,-80.28202544923874 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark23(-0.22502234003306887,-0.19603982058070077,0.11251117001653443,0.0980199102903504 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark23(-0.22595140652195278,0.11297570326097628,0.02455525001381853,-1223.1202862604896 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark23(-0.2273398428600983,-0.4546796857201755,0.2974749268826085,-0.048969176172692794 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark23(-0.22799992825674023,0.1139999641283701,-0.4787914687171316,0.7283981813332632 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark23(-0.2285264743000328,-0.45705258844937124,-0.14689467423154146,0.22852629422468568 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark23(-0.22900751646166403,0.11409007811087868,0.8999019216282803,-0.8385091334309286 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark23(-0.22952780230374234,0.11476390115187107,0.11476390115187117,-0.05738195057593559 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark23(-0.22969846963025442,-0.4593969392605086,-2185.1978864207526,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark23(-0.22984173009464007,0.11492066476128276,0.21966114735117453,-0.0438557736680754 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark23(-0.22987813573739363,-0.45975627138298836,0.11493906786869681,-83.12426900333446 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark23(-0.2305645577207823,-0.18590980644151034,-9.944402147928578,-0.7639962976996912 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark23(-0.230779894422881,-2.7755575615628914E-17,-8.537693922840042,50.45663688472622 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark23(-0.23197857423137824,0.11598906645152338,-39.89915553983797,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark23(-0.23281629278605603,-0.30277056319860185,-47.6341358110055,-16.621462837648846 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark23(-0.233709606050897,0.11685480302544848,0.11685480302544854,-1708.782496499011 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark23(-0.2338196677740443,-0.11943083815431922,0.5472880189437401,0.059715419077159604 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark23(-0.23531139042388438,-0.006096942235535752,0.11765569521194222,2.3588448067465717 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark23(-0.23558747112993927,0.1177937355649695,0.1177937355649693,0.7265012956149636 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark23(-0.2358669995426932,0.1179334997713466,-75.46866238088549,-61.307133843767154 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark23(-0.23593714700841,-0.4718742940168198,0.117968573504205,58.84208104088116 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark23(-0.23605368856095035,-0.466695515695553,0.11802684428047518,49.62155402228461 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark23(-0.23754336379831278,-0.1241876251757191,0,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark23(-0.23890426058981462,-0.4778085211796288,100.0,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark23(-0.2402873093282708,0.11101685763142884,0.12014365466413542,0.7285748136292116 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark23(-0.24184612193539995,-0.4836922438707998,-16.041090465556252,73.10061897131985 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark23(-0.24520746687219452,-0.490414933744389,-0.4344664380986349,-21.316967516427596 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark23(-0.245524114898298,0.011010049987709658,0.45732287643001285,151.49473405176317 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark23(-0.24562180171585654,-0.4912436034317128,0.12281090085792827,-35.959893436347826 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark23(-0.24586825058027836,0.12293412529013903,-45.57965947866981,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark23(-0.2461802409777626,-0.49236048195552473,0.2930376814419242,15.722139130413678 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark23(-0.24698323520175208,0.03206123164444827,-0.6619065457965722,-0.016030615822224134 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark23(-0.24790363451239017,-0.4958072690247768,-0.661446346141247,2118.478635155385 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark23(-0.24869239190290454,-0.4971761749397445,-0.661051967445996,28.422797027222305 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark23(-0.24881951119750437,1.061955051854623,0.14771714791704083,100.0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark23(-0.2489572457884956,-0.4979144915769911,-50.94207558417304,62.27428090267826 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark23(-0.24920655913907686,-0.4984131182781533,-91.83247546361939,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark23(-0.24938684868112482,-0.4987736973622495,0.12469342434056241,-34.308084546147924 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark23(-0.24972253197732563,-0.49944506395465116,-0.07658582771659495,14.748644362820803 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark23(-0.25015467804258296,-0.5003093560851658,-0.6603208243761568,-83.91772638822088 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark23(-0.2510933908132196,0.005198652328744766,-0.224171801099387,72.93666427554952 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark23(-0.25128388133762236,-0.19699091682329073,-0.6597562227286373,67.57513472477902 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark23(0.25191382139691726,2.071850478870426,-0.1259569106984585,-100.0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark23(0.252085508425112,0.5041710298876432,-0.126042754212556,58.38950574917761 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark23(-0.2522535389532994,-0.022900793970906493,0.1261267694766497,-17.267309644456844 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark23(-0.2534673601114461,-0.5069347202228692,0.8837690747463677,-1.317328966683462 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark23(0.25395460233884776,0.508148356992142,-0.9118181777023792,9.95007457383001 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark23(-0.2540731518925955,-2.7755575615628914E-17,0.6541026575328562,93.43042653604975 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark23(0.25473330504973135,-0.25457739323223305,-68.45477999714159,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark23(-0.2550399835195819,-0.5100799670391637,0.8020084428465849,0.25503998351958185 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark23(0.25520824462476915,-0.8613206234728568,-142.8677287803068,63.98876286021854 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark23(-0.2554482085057832,0.12772410425289138,0.1277241042528916,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark23(-0.2557051239561267,0.12785256197679862,-0.6575456014208295,1651.5405774167768 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark23(-0.2564390233019703,-0.4490522678069339,0.9086465383715839,17.055074009639426 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark23(-0.2573072895570619,0.05568951726982933,0.6611698952179565,-50.74482878507739 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark23(-0.2575552264373466,-0.5140829268029374,-0.656620550178775,0.2571675477657518 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark23(-0.2576241981009668,0.0,0.1288120990504834,49.478790145958776 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark23(-0.2579751059033315,-0.11787692113910918,-157.4495977160451,-62.25452031306399 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark23(-0.260394684606244,0.050437226496522825,0.9155955057005702,-58.785604410973114 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark23(-0.26057580649977385,-0.5211516129995473,-44.40971242447477,-67.71854545850579 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark23(-0.2611167350633792,0.13055836753168956,-0.42533867358164645,-44.043854437343825 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark23(-0.2626698038357358,-0.30560547915976033,-0.6540632614795803,0.15280273957988014 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark23(-0.26328994573271025,-0.11626455010536318,0.13164497286635513,-21.38109325454995 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark23(-0.26381846566593126,-0.5276307186174553,0.43250317593690113,64.2907286654107 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark23(-0.26671932485831934,-0.510353765099892,-1.0003612639230255,3.512972538298719 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark23(-0.2677353927159066,0.13386769635795326,0.13386769635795331,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark23(-0.26819301425917375,-0.001244112731830671,-0.6513016562678614,-26.386987903169604 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark23(-0.2693792852007607,-0.4781991504731618,0.13468964260038035,55.74730862419375 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark23(-0.26976889787307134,-0.3477746104300822,0.13488444893653573,-5.467040805371929 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark23(-0.2699468463649809,-0.4105889648800549,-89.1539466495064,-890.4338734196715 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark23(-0.27086821951977946,0.13543410975988968,3.5788843614049117,-13.959757026313213 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark23(-0.27184842814216476,-0.12223975699121069,0.13592421407108238,-100.0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark23(-0.272329488092359,-0.2724353973420335,0.1361647440461795,0.5571072701150899 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark23(-0.27278908228706455,-0.545578164574129,-0.3467316755677852,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark23(-0.2742879815104236,-0.539611653816549,-3.0044839332368163,-0.515592336507364 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark23(-0.27526329204695466,-0.550526584093909,-65.88891065843927,1238.0854819016793 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark23(-0.27805009027095373,0.13902504513547675,-48.22651540100531,51.688632835152376 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark23(-0.2786982316258498,-0.5101779386062267,-0.5948412256799059,0.25508896930311337 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark23(-0.2789034447292319,-0.5578068894584637,-91.521239464789,0.2421799544001066 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark23(-0.27898677087923146,1.7560228144807897E-24,0.8189723498997962,45.44160571642125 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark23(-0.2796791903158303,-0.41126010536374813,-0.6455585682395332,20.741564413572682 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark23(-0.2808660588285959,-0.5579953220985506,0.1404330294142978,-100.0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark23(-0.28106901029556713,-0.5621380098273985,0.14053450514778357,-100.0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark23(-0.281150667718304,-0.4085170049319182,-72.61491956748888,-79.77986767536218 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark23(-0.282402583436556,-0.5648051668731102,0.3070767198356774,-29.092222621045522 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark23(0.28268351159145055,0.565367023182902,-0.14134175579572528,-106.29585326474015 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark23(-0.2840692991722581,0.008550475325579242,0.6647922417552218,-4.2473244179186445 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark23(-0.2852655302947838,-0.04504769825767496,-100.0,0.8079220125262857 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark23(-0.28582282206032,0.14291141103015992,0.9283095744276083,-0.31756777907928896 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark23(-0.2863602687120408,-0.5727205374240811,-0.6422180290414278,-72.56213531683196 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark23(-0.28678646479314657,-0.5735729262855589,0.14339323239657328,50.35668154477662 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark23(-0.28823847626211174,0.12060830150428714,0.9295174015285042,-0.8457023141495918 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark23(-0.28940524838511794,-0.5537927102342532,-0.4970814041722331,100.0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark23(-0.2900237245490771,-0.5088669399289948,0.14501186227453855,100.0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark23(-0.29278800305708236,0.0,-0.5108002264518031,-84.77201819937399 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark23(-0.2941457576058132,-0.5848208555255623,0.5397749175139168,2132.1482263964544 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark23(-0.2948812470238793,-0.5897624939543107,-39.08726044537755,36.991044940926685 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark23(-0.29499162411147123,-0.6379023513417112,0.9448737512328761,-7.785031930608561 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark23(-0.2961430562669976,-4.024850088026098E-18,0.6754744185608587,74.23878139715498 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark23(-0.29640886226614616,-0.5611593244822084,-0.6371937322643753,-87.86377788212293 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark23(-0.2965123989091978,-0.36811004717601425,-7.125606538799419,-0.6013431398094411 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark23(-0.29736524048076407,0.06879459355343409,-0.6367155431570662,1958.173771266764 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark23(-0.29827453896720374,-0.5577087676911608,-0.6362608939138464,38.70927840920468 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark23(-0.29886337342882463,0.030882197498959485,-25.8767184347777,-100.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark23(-0.29940637397697506,0.1497031869884875,0.7479723666503286,67.3506109475569 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark23(-0.3018327446774868,3.0814879110195774E-33,-44.49026197886098,0.06918403355884016 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark23(-0.303257986985217,-0.15216899947424228,-0.6337691699048398,-53.2076899408489 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark23(-0.30419651741328635,-0.42675683005970644,0.1521802865221278,0.21338470900879358 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark23(-0.3044962698901682,-0.25891088728261247,-0.6331500284523641,0.9148536070387546 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark23(-0.3049088112477576,-0.5891397279322182,-0.6139569041593931,100.0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark23(-0.30540323577384515,-0.6108064715476902,-16.68585799083435,-0.3592710151293228 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark23(-0.30594844436909074,-0.20377277027759674,-0.6324239412129029,-79.93772093567873 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark23(-0.30690505614883545,-0.4010849585035474,0.7908317681413343,99.90992581348017 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark23(-0.3069738282719079,0.0,0.7177394468417693,-85.0572555170472 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark23(-0.30745073760572184,-0.6149014752114432,-13.274274767512551,-1445.2417104773924 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark23(-0.3084726485609476,0.15327921971207664,0.15423632428047387,-0.07663960985603835 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark23(-0.30852083335926395,-0.3839782188350565,-0.6311338889328052,0.9760723524955424 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653589744,-0.390014785978423,-0.6283185307179611,72.92678649113749 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653589793,-0.5651698456391847,-89.20976547321129,0.28258492281959224 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653591001,-0.6052033151518738,-0.4246258093638333,-1964.7452599219528 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653592633,-0.6283185307175807,-0.41990904949223173,-100.0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark23(-0.31623523504414686,-0.6324704700882935,0.9435157809195217,-0.46916292835330164 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark23(-0.3164818368785127,-0.6271572449581917,-19.382678212423663,23.356169715247454 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark23(-0.31651158446455097,0.14223852364561804,-25.69104710271821,-0.07111926182281536 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark23(-0.3165175574100182,-0.4416993074800278,-13.405252852321428,0.22084965374001383 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark23(-0.31849764732967345,-0.2517365459554233,-0.6261493397326116,-0.6595298904197366 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark23(-0.31857326676547926,-0.14427105972651277,-66.04319308267607,-74.24073583965861 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark23(-0.3191357461185391,-0.5413728156985113,0.05691467532391049,48.17798002369128 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark23(-0.3191535030783484,-0.6244154002803304,-28.23828146426194,1.0973717398229381 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark23(-0.3202072255334986,-0.42365093065265597,-0.625294550630699,-4.5073326833829315 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark23(-0.32074950446124295,-0.6250234111668265,0.3086600143175593,0.31251170558341324 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark23(-0.3210508046481484,-0.624872761073374,-0.6248727610733741,0.312436380536687 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark23(-0.3211388771744559,-0.6422444527633551,-53.274787342662364,-13.034294828141961 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark23(-0.3219514407836732,-0.594738485592861,-40.988866576649265,0.2973740002830896 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark23(-0.32359321964697924,-0.60580813604139,0.8952635937969309,100.0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark23(-0.3238793874736055,-0.6234584696562845,-0.6234584696606456,-42.19290471594385 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark23(-0.3248593396338877,-3.374896899216353E-22,0.16242966981694384,21.319127769152516 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark23(-0.3260294723663473,-0.6205374832053879,-0.23461105046978892,100.0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark23(-0.32612434092946074,-0.6223351230788137,0.9484603338621787,0.09801249464916034 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark23(-0.32761344122912395,-0.576845819334164,-49.43935146354763,45.077174770265835 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark23(-0.33200651393488056,-0.5930102082441251,0.16600325696744028,12.14015053821835 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark23(-0.332481013603376,-0.5800158072395813,-0.6191576565957603,100.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark23(-0.3330953317308644,-0.618227119348135,-0.618850497532016,32.500880935531306 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark23(-0.33605341371926484,-0.528886716490704,-91.6626814248654,0.26407932857711436 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark23(-0.340516837427178,-0.5110349100268828,0.170258418713589,94.16261904583564 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark23(-0.3406456157327836,0.07115612173885394,0.19823950250281624,50.231887481419975 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark23(-0.3406713421293688,-0.34054783391404353,-7.317995236880229,89.69903297015786 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark23(-0.3414416222648914,-0.614677352264987,-0.6146773522650025,-0.47805948726495484 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark23(-0.3421425919338559,0.1126584039468359,-91.08697559675791,-67.41281128582007 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark23(-0.3423960436680855,-0.589259090486893,-0.6142001415634055,0.2946295452440919 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark23(-0.34292792501851227,0.1714639625092561,-0.2854786834212262,75.3556071320763 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark23(-0.3433443821123976,-0.5847844129957538,-0.6137259723412495,61.52028210133014 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark23(-0.34474365949654834,-0.6894271375907395,-46.34352754943347,16.052676806804733 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark23(-0.3472347281056186,-0.6117807993446388,-0.6117807993446389,56.832525662933726 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark23(-0.34939509166366817,-0.48022538572888607,-9.606345736884649,92.8259024097822 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark23(-0.350022846653425,-0.6103867400707357,0.42743982728670415,-61.40713072341043 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark23(-0.3521623571746004,2.7755575615628914E-17,-41.125958846803755,-0.9130714511780706 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark23(-0.35350206896914205,-0.658005364561883,-0.2266981981416052,48.22840376308052 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark23(-0.3535688151282182,-0.6086137558333391,0.8633446064063489,150.35683346904193 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark23(-0.3543360410042009,0.0,0.8062236421479012,80.06853431509879 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark23(-0.3545628986506807,-0.5464417428174454,-0.3944550361490788,-100.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark23(-0.355057718334345,-0.6638222671837225,-0.6078693042302757,-61.42946541852944 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark23(-0.35584531131146685,2.657550793109868E-4,0.8044921709328046,36.09130491245038 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark23(-0.3565848320273203,-0.6064841016333986,-39.91381034960024,0.3032420508166993 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark23(-0.3586543109073626,-0.5976528345552552,-41.966757399599366,44.3709328681541 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark23(-0.3609959699126377,-0.5788708821406515,0.8295361348518135,89.20649412924739 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark23(-0.3611280656452359,0.1805640328226179,0,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark23(-0.36155929328175673,-0.42464430865979697,-0.4381069940738548,-25.18425940198429 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark23(-0.36228905766697994,-0.5446270612392328,-74.5815731448574,68.57988606087216 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark23(-0.36236776882837374,-0.41435515568555414,-0.5056588648735022,-78.82893306527028 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark23(-0.3643995719384887,-0.3342691292415667,-36.85592048708477,0.37118022571594267 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark23(-0.36484365629118615,-3.0598373064482974E-30,0.907983173077547,57.76329375476513 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark23(-0.3652291880875321,0.17936680719935794,0.8494358061907996,-87.03764744303821 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark23(-0.36716569882804606,-0.6018153139834225,0.840829939112058,5.595590002561745 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark23(-0.36767541981981444,-0.07511079714047075,0.18383770990990722,36.83157638306152 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark23(-0.36812501094600636,-0.6013356579244451,0,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark23(-0.368558297737358,-0.27008842036130065,0.9696773122661273,-64.0228522057179 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark23(-0.36917525702897636,-0.600810534882957,0.9699857919119365,-0.48499289595596984 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark23(-0.3698037978501283,0.18490189892506403,0.9703000623225124,-56.201696231276905 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark23(-0.36995551888835876,0.10150101784284526,-72.51361000393975,0.7346476544760256 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark23(-0.37058197471772036,-0.7406030324080501,0.8254662152951964,14.546860705082722 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark23(-0.370863018864396,-0.5999666539650494,-0.5915275707657651,0.9941470290017562 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark23(-0.37395800806867363,-0.27514875982367704,-100.0,40.234565263810396 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark23(0.3741488522213,-0.2543515586191707,99.24292083427372,0.12717577930958535 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark23(-0.37632559616354455,0.18816279808177222,-15.693955078307244,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark23(-0.37661357171093324,-0.11512678960685069,0.18830678585546662,-50.305104284705074 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark23(-0.3766846119996764,0.18834230599982785,0.9737404693972865,-0.09417115299991753 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark23(0.3771802844515406,0.7550477918009374,92.99739150733053,-0.3822771969733729 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark23(-0.3794647031199308,-3.3373115072944606E-16,0.8777586362701706,32.75477572579851 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark23(-0.3799757354118871,-0.5942754457239796,-94.79794342149916,-100.0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark23(-0.3803027639231451,-0.23036105571558746,-50.59281138728371,-67.05342541461894 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark23(-0.3805795088830486,2.2761049594727193E-159,0.6117136146631754,68.06204496889887 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark23(-0.38105532415726767,-3.8134840283467153E-35,0.19052766207863384,8.639382724949082 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark23(-0.3816181188490088,-0.5895836616648825,-62.974158845302846,100.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark23(-0.3823484900758847,0.07387255316263508,-35.16937242233992,-53.217817913222966 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark23(0.382845241658864,-0.19142262082943207,-0.19142262082943204,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark23(0.3829657811514827,2.3338450416581007,-31.309927240332037,87.57627432311355 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark23(-0.3842318167260531,0.8018397778459175,-75.84370630190352,82.06645273778578 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark23(-0.38476644179711905,-0.7404313586488409,-5.57399814256604,76.22957737244106 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark23(-0.38488300922515456,-0.5794551946078189,-0.5566756897392863,-5.665351449127671 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark23(-0.38493141145018256,-0.22900830177610762,-0.5929324576723569,52.11101773471753 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark23(-0.3852989763373955,-0.5122674375986694,-0.5927486752287505,81.88563883903953 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark23(-0.3861087347543119,-0.5923437960189389,-0.5923437960202923,100.0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark23(-0.38851073366201255,0.15316693807905013,0.9796535302284546,-0.8619816324369733 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark23(-0.3912173819539602,-0.47128740056982665,-57.59956673278115,0.23564370028491333 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark23(-0.3914329394385813,-0.32994615904795155,-0.16283592221961044,0.16497275438535228 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark23(-0.3923233963300751,0.19483047826533273,0.1961616981650376,99.50464341150577 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark23(-0.39298544399127955,-0.2946255573152799,0.981890885393088,-85.25439871188766 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark23(-0.3932356345227578,-0.4495279724251454,0.30221863584880576,-32.96708626282583 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark23(-0.39464444708944124,-0.7892888941788821,-94.4462187932314,-0.39075371630800715 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark23(-0.39516332934543885,0.10249756120333342,-0.3531691650724597,61.31547168059369 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark23(0.39524405767275284,2.361284442140402,-0.19762202883637642,-0.3952440576727527 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark23(-0.3953256720702716,-0.10326048883550287,-81.78855047830845,-0.7337679189796968 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark23(-0.39621155523031903,-0.3159062003630378,0.41184519164684197,0.9433512635789683 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark23(-0.39633864607858776,0.06204770383109803,0.9835674864367421,5.3725414453643126 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark23(-0.39636058279071856,0.09275735816676767,0.9835784547928075,10.995603546907862 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark23(-0.3970999665015566,0.0,0.1985499832507783,58.903817062570866 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark23(-0.39973666862613677,-0.7994733372522727,-0.8039571675300462,-70.28615486499602 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark23(-0.400382086168384,-0.585207120313255,-40.96836597037392,1.0780017235540758 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark23(0.40096205419537945,2.372720435185654,-0.20048102709768972,-16.112201101995833 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark23(-0.40108221149330214,0.11017481489859693,0.9582505022894355,-0.8215155855307701 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark23(-0.4021875781512652,0.11097511560042855,0.20109378907563263,3.8715062497903245 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark23(-0.40457735843448983,-0.4756490612452309,-15.580288951019325,-99.57110445979059 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark23(-0.4051931696405643,-0.575681375756906,0.20259658482028214,-83.93216500739848 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark23(-0.40543105569783244,0.18768320776231628,0.21502711265229427,143.67164105051117 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark23(-0.40557601365643503,0.2024325273882581,-0.3365020385366716,-0.10121626369412906 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark23(-0.4056945596873472,-0.5567446049405859,-21.604962797763452,1.0637704658677412 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark23(-0.40770329540735356,-0.5682164457341019,0.21051044110681827,26.123913195298346 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark23(-0.407920363261171,-0.5680056452232219,-0.5814379817668628,63.89852370784173 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark23(-0.40831747854193173,-0.5039784423266274,-168.65688828308157,1.037387384560762 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark23(-0.4098823929420996,-0.8154063606714235,-70.23165007187244,88.3722070486816 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark23(-0.4108843752473264,-0.0489388330273004,-94.40720153424977,-0.7630183749356121 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark23(-0.41228170772136297,-0.15919732155198218,-40.5419582976257,16.549617599172862 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark23(-0.4122832586377566,0.7439070018691102,0.4145585568646525,-13.438272175738424 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark23(-0.41274612657409,0.12107456301541239,-0.32852197591192295,-0.06053728150770621 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark23(-0.4155120333733432,0.7397722600482097,-100.0,-0.23798087627619643 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark23(-0.4173312877272295,-0.23688172212569464,-59.79524801037407,65.27719647873391 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark23(-0.4224472246083793,0.18867988508476685,-65.80885666201567,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark23(-0.4235662059509615,-0.5736150604219673,0.9971812663729288,-1.171323746846108 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark23(-0.4239565161340999,-0.5734199053303982,-0.0857015906814344,-23.612028138440177 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark23(-0.4261146906110613,-7.775131163978657E-32,-31.92591778663341,0.37683314002409807 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark23(-0.42904746402666105,-0.5263491495865433,0.21452373201333053,100.0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark23(-0.4292047465754424,-0.47517957700630187,-0.5707957901097271,66.36600648256386 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark23(-0.43067059484315573,-0.4418542713666986,-12.847180115645074,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark23(0.43389230723939465,2.438580941273683,-1.0023443170171462,6.656936384094025 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark23(-0.43604587953055685,0.09998793889602445,-75.25672087547967,-1326.6607035547017 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark23(-0.4361310078059131,-0.39992412598458243,0.21806550390295654,-31.53638052877528 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark23(-0.4364666202069267,-0.5671646996189134,0.21823288943565328,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark23(-0.43889426209563837,-0.33041482328418104,0.3184057245028266,0.1652074116420863 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark23(-0.44023037573501866,-2.7755575615628914E-17,0.22225598763168186,99.73993782499738 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark23(-0.44074012867526596,-0.17008069576540344,-0.5650280990598153,0.87043851128015 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark23(-0.44110329156506317,0.2205516457825315,-44.37065644717829,-100.0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark23(-0.4435141642381366,-0.2997244625352934,0.2463325171088369,-0.6355359321298016 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark23(-0.44354311837589777,0.11233503588378635,0.22177155918800584,-0.8415656813393414 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark23(-0.44355277213513467,0.2217763860675673,0.22177638606756733,-0.8962863564313172 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark23(-0.44425243690316585,-0.5001710479357546,-0.5632719449458653,-2068.006322152174 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark23(0.4442963835328834,2.0885444161869993,-0.22214819176644168,-38.993032361418024 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark23(-0.4449674076596745,-0.5628660860495439,0.7141916357958155,131.82269920503978 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark23(-0.44510023356765016,-0.12514240986574907,0.49360200684568883,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark23(-0.4454643300245271,0.20681894633777564,1.0081303284097116,-0.08799260538219307 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark23(-0.44757264247573486,0.20736746602132514,0.22378632123786743,-79.40362512937722 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark23(-0.4496397554307361,0.2248198777153676,-19.281796303983676,-0.5500938359822869 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark23(-0.45018407161260104,-0.48303601006665997,0.019342100349962435,-78.92402864595111 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark23(-0.4507880097460843,0.0,-57.064244100129336,-78.08845510488185 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark23(-0.4521707926603983,-0.5391877679084001,-125.89608917790926,-66.70618575778707 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark23(-0.4524575503265657,0.009672944082940381,-3.569331283264686,0.18702013406390594 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark23(-0.4539952896935302,-0.5584005185493676,0.5933163889621242,1653.2153164048689 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark23(-0.45706421137988223,6.938893903907228E-18,-2.927597130977806,0.1828212932244525 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark23(-0.45848133298586585,0.12016889161434507,-100.0,-0.06008444580717254 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark23(-0.4598486541163335,0.2299243270581634,-0.5554738363392815,-0.11496290885129398 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark23(-0.4609457156444066,-0.8053459146593793,0.24098249040689446,-41.83824529678699 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark23(-0.4626009705625362,-0.43768189596364104,-99.84126609779513,0.21884094798182055 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark23(-0.4636319019326226,0.23181595089002874,-100.0,41.59322793730056 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark23(-0.4650763322031082,0.2325381661015197,0.2325381661015541,-4.011529605093589 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark23(-0.4654766586486543,0.23273282645966664,-16.03154778512068,-22.089120161303352 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark23(-0.4698773257298223,0.16718564987276352,0.23493866286481932,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark23(-0.47006114515443254,-0.5503675908202317,0.92615318608432,67.57639690739734 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark23(-0.47087864467540463,0.2354393223377022,-0.5257074329828983,-52.721981995514746 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark23(-0.47135549337057125,-0.24089629266329013,-0.08084957796832966,21.19961410328007 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark23(-0.4713897504907414,-0.25289131951161004,0.2356948752453707,54.06048663908917 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark23(-0.47193895872740166,0.07052794330566342,0.23596947936370083,-83.4717027522463 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark23(-0.47428284383191754,0.23714142191595866,-21.441275600376805,46.38666364075389 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark23(-0.47527363703461134,0.23763681851730567,0,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark23(-0.4757258852500108,-0.357083592071301,-48.114405567474684,0.6350941454883634 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark23(-0.4770524456291172,0.2385262228145585,0.23852622281455862,-100.0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark23(-0.47721273120931806,-0.5048863931162545,-0.22819519292588672,-5.5271478752604446E-76 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark23(-0.47743242829140514,0.22128624923340004,-5.632695644737912,38.39502075213007 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark23(-0.4777464780645348,-0.11710731972312398,-0.5465249243651809,-33.19666301025396 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark23(-0.4791370046944003,0.17309800841066228,-30.79814254399539,0.6975342553683942 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark23(-0.4795410837450516,-0.5456276215249223,1.0171906624069036,-73.32642661587856 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark23(-0.4807181303758126,0.24001780977198112,-44.684083653230616,24.198655805508963 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark23(-0.4815196205492453,-0.515824348522969,49.31622318490102,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark23(-0.48376375686513173,0.16189409248628028,-100.0,0.704451117154308 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark23(-0.4842342265327444,-0.25605690683335725,-72.90653897555606,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark23(-0.4843532250246766,0.2421766079126968,0.24217661333429466,-0.1210883039563484 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark23(-0.48438595642370247,0.14642298603133705,-0.543205185185597,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark23(-0.4845110735355479,-0.869245236455066,0.1050916227402281,19.28494848406528 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark23(-0.4846442450569584,4.3091907955093935,-0.5430760408691242,56.751292817188556 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark23(-0.4848291367705799,0.041195348907865165,0.5404638783555082,83.76468104080739 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark23(-0.48502734612027587,-0.4932319717579361,-0.49323197175793343,33.52717503648841 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark23(-0.4859578520861363,-0.10409138596136336,0.004624879479842581,-60.081030854014784 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark23(-0.4866649421581555,0.24333247107907768,52.88177199639027,-0.12166623553953884 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark23(-0.4867594097756421,0.024030875311309298,0.4927860346376637,-16.440127133395624 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark23(-0.487194760747481,0.24359720012526317,0.9241101639468636,10.578877454563132 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark23(-0.4876662924624691,6.38378239159465E-16,-0.004635827431966988,-0.7756301341022351 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark23(-0.4915622468318735,-0.42592684067702435,0.24578112341593675,-0.5595619230627953 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark23(-0.4916613528959949,-0.5286394225844209,-0.022352022735456962,-0.5210784268995949 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark23(-0.49189798124704076,-0.4688860284228934,-6.570552592686825,1880.8579944029357 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark23(-0.4931001560718613,0.19897807794016684,-0.44244360118376447,-88.6554588180682 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark23(-0.49629443574106485,-0.2465490465866153,0.8683494518920724,-0.4751372281187969 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark23(-0.496774509503157,0.24725714331445187,0.2483872547515785,-0.12362857165722595 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark23(-0.4974003259149031,-0.536698000439994,0.24870016295745154,-134.57868590158193 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark23(0.49879753380356406,2.5683913944020245,-100.0,100.0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark23(-0.500109645603108,0.5643139236929089,0.41567470680122576,75.14755660170567 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark23(-0.500269526048505,0.2501347630242522,0.2501347630242525,-1.0712769528552533 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark23(-0.5002882622431588,-0.5352540322758688,0.6517030621339122,17.97765952065249 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark23(-0.5012862077100094,0.25064310385500455,100.0,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark23(-0.5018413939367532,-0.3983939909642026,0.2509206969683766,6.258153763927777 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark23(-0.5028158171222865,0.0,-79.00769572597156,0.3926927020049546 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark23(-0.5043097853032036,-0.2280929371617827,-99.85860907016969,43.74910961238595 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark23(-0.5054524704277004,0.027308190724234516,-50.62029496660004,51.87768214307882 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark23(-0.5054856071902485,-0.5326553598023231,0.25274280359512424,-71.27109693350367 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark23(-0.5055188991030928,0.18993646477158768,-0.5326387138459019,-99.79397554758603 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark23(-0.5059351152962435,-0.10284064453024122,0.20892994032672774,53.52098847440032 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark23(-0.5066489147117433,-1.2446030555722283E-60,0.5159229075800964,93.25000350706516 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark23(0.5069493622554465,2.5844959572925386,-0.41007138470059273,-141.88043565282183 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark23(-0.5071230674758711,0.25356153373793516,0.25356153373793555,39.928553031239936 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark23(-0.5102058629377586,-0.31415926535894556,0.4712388980393114,-100.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark23(-0.5104186839313968,0.08685746914948947,0.24432851398928174,-81.19187998213219 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark23(-0.5112548627627569,0.18756194971076523,0.25562743138137844,-23.397734200760734 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark23(-0.5116925551737541,-0.10330135227847714,1.0412444409843253,-40.296614354675235 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark23(-0.5118430322715214,0.08279347645031068,-100.0,-0.04139673822515533 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark23(-0.5157105305915182,-0.24506289602586329,-63.61557725038844,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark23(-0.5174051546186755,0.029490217673699082,0.2587025773093379,0.7706530545605987 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark23(-0.5192506726160268,0.2596253363080133,94.02098435524384,-0.12981266815400663 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark23(-0.5196149813844688,0.2598074906922343,13.294781224089832,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark23(-0.5199809677250284,-0.2961338926522577,0.2599904838625142,0.14806694632612882 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark23(-0.5199939997484829,-0.2801998278187469,0.4601424167582041,-54.18149427795613 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark23(-0.5200349516166143,0.07041207739857458,3.4204772011612605,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark23(-0.5210712662451058,-0.3617663352719003,-16.73948577553386,-69.79455291244098 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark23(-0.5212734248131882,-0.37966083129523237,0.7730705747828621,50.412697001119 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark23(-0.5215769112846348,-0.49578280414857007,-17.908211715321734,57.88274240569442 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark23(-0.5219398257396296,0.18387143574809195,0.4750701653348705,-72.93329252556308 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark23(-0.5230151053384894,-0.5238906107282034,-15.137114498359324,100.0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark23(-0.5239807518477423,0.2615614361882695,0.26199037592387114,2.2249548422487604 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark23(-0.5255400936395729,-0.19052052798356067,0.5948776354138875,0.7193494327241947 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark23(-0.5271814952873997,-1.1540745101289263,2.4101317275433267,-69.62261993810026 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark23(-0.5289717283999493,-0.3206899933982013,-18.03472794688992,81.87352234417943 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark23(-0.529532694519441,0.019828323176755536,0.6862001813561862,-3.626553852377258 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark23(-0.530168231176475,0.2510834898003621,-16.150194228469545,-0.12554174490018102 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark23(-0.531265969879075,0.017345702323372292,-0.41044334965570783,-69.42083341666397 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark23(-0.5331362731262157,-0.5182292475116931,1.0519662999605561,-33.54778973429651 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark23(-0.5334413816598929,-1.0663336423563505,-122.7339436664668,-100.0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark23(-0.5336232695009028,-0.3950465911489369,-75.08939198146956,1884.120900427862 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark23(-0.5345972318582808,-0.3696348800665361,0.2176210880953885,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark23(-0.5354897633749474,-0.5176532817099745,-0.5109622862537014,33.391807366897005 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark23(-0.5381427813128282,-0.433427546516331,0.2690713906564141,-0.7377043330080795 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark23(-0.538477349390023,-0.08922967122538492,-0.26365920952311495,1555.3000822981494 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark23(-0.5392088067184508,0.2290273999112253,0.2696044033592254,-2166.2741014718863 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark23(-0.5392825784435329,-0.16924782536443028,-83.93240767806108,158.5673409482306 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark23(0.5394468113446635,1.1884536322352803,-77.23716242080269,9.616031233371121 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark23(-0.539702268644783,-0.05558837625871336,0.030909886399841498,-157.59261404819992 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark23(-0.5404925554385397,0.2702460470954024,-37.26038864047388,-0.13512302354770123 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark23(-0.5417340794661453,-0.48528861522327027,-0.39279549158209415,1.0280424710090834 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark23(-0.5427977946445517,-0.4622347668849091,-0.5139992660751724,0.23111738344245447 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark23(-0.5430281226905781,-0.3697487250734075,0.27151406134528905,66.82827894758593 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark23(-0.5430402252043631,-0.513872240713969,-37.546588109726656,-0.20234058358061424 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark23(-0.5432339458555795,0.17323591533425603,-73.55130773631106,34.16089198258264 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark23(-0.5444634728407513,-0.31415926535895466,-100.0,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark23(-0.5455705212280898,-0.510991664949074,0.5362864367522475,-98.39408144798297 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark23(-0.5473964389947661,-0.31415926535898375,-100.0,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark23(-0.5478806872700772,-1.063251374373162,0.2771927651146565,-100.0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark23(-0.5489313800052553,-0.5109324733948204,0.27446569000262766,-68.88245852647319 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark23(-0.5497697332129408,-0.20785298927708773,1.0601674288059248,0.8740101134938356 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark23(-0.5497949740322781,-0.34917685171264556,0.27489748701613903,-25.075325590125118 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark23(-0.5514195937332989,-0.3542762314507145,-0.10950296485115302,-0.016079446535911434 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark23(-0.5522639198838326,0.27613195994191475,-2122.4540826816137,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark23(-0.5522798930668888,-0.2984976147992425,-23.05678409261717,-0.6361493559978271 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark23(-0.5534330423322444,-0.34900085456039787,1.0621146845635705,-100.0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark23(-0.5539546060849944,-0.4511106793272828,0.7075307603899257,-0.5598428237338069 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark23(-0.554983003468187,0.1601408357154564,-0.5079066616633547,0.7040128252202971 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark23(-0.5553444484658757,-0.14201600399152814,0.25595103856791196,-49.195804461790715 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark23(-0.5557584798260489,-2.5135404550232773E-4,1.3232691278413418E-18,-56.97466125979079 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark23(-0.5563955183976721,0.3513250411182679,-142.02750387659006,83.46530391263842 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark23(-0.5610536546947831,-0.504871336050055,2479.8253712775363,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark23(-0.5625060284215625,-0.4791659236266216,0.28125301421078125,49.403032296924735 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark23(-0.5628424948471226,-0.3447903180916267,0.2814212474235613,90.23067926670254 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark23(-0.5637920226870168,-0.3141592653589793,0.2818960113435084,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark23(-0.5652458768612248,-0.5017643213177552,-43.26869868982006,82.67462708538665 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark23(-0.5656037381364973,-0.3492197736386897,0.2828018690682486,876.3273448002171 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark23(-0.5666842024415404,0.4179940659796926,0.2833421012207701,90.1128332807165 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark23(-0.5678086372073641,0.23209388031392383,-0.5014938447937662,100.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark23(-0.5680860678210615,0.20111901614388383,-90.05035408020477,89.33988706408888 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark23(-0.5687479407615803,-0.35059113629928645,0.28437397038079015,-57.75845933331218 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark23(-0.569794218090229,0.25728615244302017,0.28489710904511445,42.35324188897113 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark23(-0.5701907555927432,-2.220446049250313E-16,0.3474298850416707,17.583913507025954 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark23(-0.5710004146650628,0.32697043619579597,0.2855002073325314,0.6223226133201194 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark23(-0.5722374553980166,-0.44539169518559685,-0.2960504449468391,39.431054381783596 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark23(-0.5731335270457252,0.2446553551440206,-0.4988313998745857,21.417116713801793 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark23(-0.5752295705997673,-1.0641132604886638,1.0730129486973319,0.5320566302443318 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark23(-0.5761853716122703,-0.36092838551674195,0.42061527682745986,-4.128495044117724 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark23(-0.5797439910091337,-0.21023864011836801,0.2898719955045668,0.10511932005918379 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark23(-0.5799146721899728,-0.49544082730246175,-43.963651837793556,26.453787810283398 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark23(-0.5805477209995124,0.26480444039648715,-153.69776332735216,-26.64790844128953 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark23(0.5807452490763225,2.732286824947541,-26.312550652268012,-92.0789495366485 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark23(-0.5838778951540591,-0.014000904875006813,0.29193894757702954,-0.7783977109599451 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark23(-0.5853587934343745,-0.16348019303082606,-0.49271876668026104,0.08174009601211302 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark23(-0.5859567717846961,0.2929765599847459,0.29297838589234804,-17.44185688068724 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark23(-0.5864666996642628,-0.07116728625310564,-0.39819976611141883,-21.612003349934625 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark23(-0.5869160272901723,-0.21549332707660118,0.29345801364508617,0.8931448269357489 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark23(-0.5875777476177511,-0.29995108413043425,-62.135041591655096,2.2378253993555997 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark23(-0.589341753112998,-0.05031733123712945,-36.80500523792013,22.843616899735814 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark23(-0.5900077888721784,-0.490394268960975,0.977085354329596,-42.25691853466237 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark23(-0.5908699657990171,0.288964924729399,-0.38147611845372686,100.0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark23(-0.5914147969187163,-0.4896907649380893,-63.41256706083153,46.71454622776247 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark23(-0.5948405475459599,-0.12419163479167228,-0.4879778896244683,0.06209581739583614 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark23(-0.5959422537292565,-0.07127028467890462,1.062818468632928,-2.023784381336977 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark23(-0.5967736886097461,-0.45176071315628435,-0.48701131909257533,-0.5595178068193061 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark23(-0.5972748231979003,-0.761094470632897,-0.41166746718184044,-37.96016643473007 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark23(-0.5999808467874376,-1.1745581104600757,-0.09519540467237878,46.13201628665513 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark23(-0.6023389900528076,-0.3629599589887479,1.0865676584238522,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark23(0.6044244943651915,-1.087610410580044,-1.087819626705091,-41.87596555369605 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark23(-0.6044979944887156,0.07234812863515747,-85.60778109236642,-0.036174064317578726 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark23(-0.605593299978253,-0.48260151340818774,-21.715234939287413,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark23(-0.60604241928159,0.13284635541049183,0.25532216021704734,-29.03716638582168 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark23(-0.6063778681889788,0.2791350806030886,-0.156333685491054,-0.13948182074488993 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark23(-0.606665494838594,0.3490841327184752,-50.414427948165866,94.07579794526433 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark23(0.6085458506312212,2.7869953499879068,-44.95576706023766,-40.91340469182491 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark23(-0.6089427615427123,0.20692813842777796,1.0898695441688044,-0.10346406940737586 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark23(-0.609729638298667,-1.2132231608443296,-0.4805333442481148,1.3935240219595282 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark23(-0.6097528036988495,0.11349600721767672,-23.183469610333766,-53.92324915558316 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark23(-0.6101878218429099,-0.3351641870305852,-135.56876331287145,0.952980256912741 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark23(-0.610529864262296,0.3049288532594432,-38.902971035046676,-0.9378625900271699 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark23(-0.6114852778340939,0.34610331569157876,-19.329106330670783,90.93316893101786 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark23(-0.6133235052777843,0.2690682650045087,-0.4787364107585561,65.37115564921426 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark23(-0.6140576832496505,0.2982161424820549,-114.09994125491566,-0.9345062346384756 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark23(-0.6144627794197224,0.018706560007282817,-60.02292062562375,-31.195349180754945 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark23(-0.6164620955447451,-0.47716711562507563,-17.16296830101635,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark23(-0.6166229836826154,0.30831149184130746,-0.4770866715561406,-29.223726653180364 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark23(-0.6171470371181116,-0.4768246448383924,1.093971681956504,-54.1059867712119 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark23(-0.6176403929254354,-0.4535994584524631,0.5995012914866992,99.96843466881872 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark23(-0.6189422628796873,-0.18289339262472026,-100.0,97.5557607535163 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark23(-0.6211570859958085,-0.19011650388815715,0.31057854299790427,-54.6757996471652 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark23(-0.6217659401910325,0.22771371385083283,0.31088297009551624,0.6715413064720318 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark23(-0.6229085492890977,0.305478265908409,64.94534302283644,-0.1527391329542045 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark23(-0.6233113149441732,-0.47111150193005397,0.6770753924922305,-32.56972449595866 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark23(-0.6248700457687316,-0.2015043609138709,-25.21795810915873,0.0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark23(-0.6271107327701351,-0.2929616006737429,-65.26351868222478,0.9318789637343197 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark23(-0.627157458259197,0.3045254961803286,100.0,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307179557,0.31415926535586136,1.0936782867615915,100.0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307179573,0.25203702881792267,0.31415926535897865,93.29244056529973 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307179585,0.31415926535897915,-12.971448285434263,-0.15707963267948966 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307179586,-0.08275531670467207,-28.552609631726114,-75.14651320729722 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark23(-0.628318530717961,0.2457148688772799,-2243.199758253419,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307179624,0.3141592653585756,1.0995574287564294,-31.5078459168366 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark23(-0.6284345180411254,-1.2422203158343927,-0.4711809043768856,78.65805282573787 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark23(-0.6290131846494414,-0.4708915710727274,0.3145065923247207,58.12156615227046 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark23(-0.6290371164115525,0.10865726895675186,-22.58937590762759,-0.8021033011296395 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark23(-0.6293137661880915,-1.1206429455016367,-0.47074128030340245,60.30412621526641 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark23(-0.6302976885805013,0.06028010478312399,1.1005470076876989,-0.44628291368285433 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark23(-0.6308617295618817,0.30902868820930907,-0.46996729861650743,-0.9308691142832254 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark23(-0.6313819260851853,0.2961195684271807,-2164.8074898848295,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark23(-0.6324595944991437,0.2877937865885605,0.9548927111815179,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark23(-0.6328962530043797,0.3050038207861363,-0.46895003689525844,63.46336696390977 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark23(-0.6333360712940067,-0.3132400081433506,0.8789662668755827,55.24759555905706 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark23(-0.6336452091660245,-0.36210749454979374,-47.91847550615458,-75.00118929207267 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark23(-0.6359625543013563,0.2953910970938311,1.0658771068281028,0.6377026148505327 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark23(-0.6376761406387922,0.28491038268684254,1.0751390662200473,16.255993656177044 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark23(-0.6389841626732768,0.06825204378184715,-0.46184450095738416,0.7512721415065247 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark23(-0.6423485645828058,-0.31006991495553793,0.6074274464977827,72.61946237343503 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark23(-0.6424971175453414,0.28580209170421345,-72.8199419106341,-29.173104446621537 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark23(-0.6431000040738541,-0.2560441080861662,0.3215500020369273,41.72914629093293 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark23(-0.6462668102721509,-0.4590521257388358,0.32313340513607547,100.0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark23(-0.6477336986299045,0.27532892953508714,0.32386684931495224,0.5939762245352906 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark23(-0.6490683972437484,-0.43592873440166185,0.8970982453850118,9.796652937872608 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark23(-0.6510791796615438,-0.3815343897209571,-21.682358094329313,-35.70332619928458 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark23(-0.6511365680819396,-0.05477316445424158,1.110966447438418,-55.900446989980985 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark23(-0.6512675559072231,0.26826121498045025,0.32563377795361154,-0.13413060749022518 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark23(-0.6529075312571265,1.6716483071766118E-17,-0.3439082354616949,-191.33027491726133 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark23(-0.6546424273649132,0.24410490395354573,-0.005452100619089479,-31.514472739887182 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark23(-0.6552462590512276,0.20247510198458288,0.3276231295256138,-36.266465067714215 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark23(-0.6569288550610516,2.911043502291999E-8,0.41360802758956633,78.05392281446792 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark23(-0.6579662782468592,0.25486377030117785,-46.94308614301557,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark23(-0.6587305069141309,-1.3033490826568084,-0.4560329099403828,-0.13372362206904476 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark23(-0.659969240461485,0.0,0.9442560589231115,79.91579969536502 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark23(-0.6620448727901258,0.24670658121464503,0.33102243639506285,-92.77076277917433 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark23(-0.6628137317826841,-0.07233686131720748,-0.45399129750610623,0.821566594056052 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark23(-0.6634490722547884,-0.4422314132008265,-60.398293539471084,0.22111570660041324 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark23(-0.6636464597241392,-8.326672684688674E-17,0.7738974132775268,-32.216829044303054 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark23(-0.6651416028958705,0.19979555630396031,-12.847066043397124,0.6855003852454681 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark23(-0.6659623097807608,-0.14410555664359748,0.8315158465808026,40.86233433949307 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark23(-0.6662719397433452,-0.4458211662339184,-25.14936752573208,0.2229105831329257 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark23(-0.6685941102088869,0.19720359088090253,-53.06500921270302,84.09656764139088 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark23(-0.6689264949315488,-0.11550925875616447,-0.45093491593167384,0.057754629378082234 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark23(-0.6691558153388987,-0.30468087234565994,-0.4508202557279988,0.15234043617282997 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark23(-0.6707135013645403,-0.35725243567385456,-4.054264437733023,-27.17978571590581 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark23(-0.6732145274354513,0.08024504256019649,0.4581904957569581,1.4579141393145392 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark23(-0.6739774122143629,-0.4484094572902467,1.1223868695046297,-27.948975549334975 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark23(-0.6746655084289159,-0.09046126510083097,-19.78788456668528,86.22295438343343 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark23(-0.6748025832363731,0.14487460638897323,-0.3850925189086616,-27.97673496665926 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark23(-0.6748824059534968,0.22103151488790274,-22.830670999206994,96.76545382484237 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark23(-0.6756626548164187,-1.2364628919085128,1.0782941249746882,-0.1671667174431919 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark23(-0.6757733236764955,0.1409078312475606,0.3378866618382478,29.160848409573223 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark23(-0.6796092201384923,0.21157676463209482,-0.4455935533282021,156.0122050751662 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark23(-0.6799101491308799,0.21097602853313666,1.0068726717363772,22.79097806591406 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark23(-0.6830129588247221,0.13004243941938276,-0.13601505798030364,-47.88273655160275 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark23(-0.6831406299118203,-0.27285807891812197,0.3415703149559104,-100.0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark23(-0.683235337366322,-0.44378049471428715,-0.44378049471428727,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark23(-0.687255259481142,0.0,0.43253236775835885,56.101972476732044 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark23(0.68741457620561,-0.5083239961873385,-1.853523578422983,-2.4247598768988627 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark23(-0.6875348570462421,0.053126686447898114,-0.4416307348743272,21.420571835183832 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark23(-0.6877521357043177,-0.4415012959741473,0.3438760678521588,-0.5646475154103746 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark23(-0.6878076714880682,-0.06626609210292278,0.9813387154929124,-100.0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark23(-0.6881120959150779,0.19457213496474024,-95.06970885963592,-0.8826842308798184 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark23(-0.6885250613812985,0.1907544757271349,-100.0,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark23(-0.6902454748207045,-0.39163899335608915,-25.383624867109212,-99.79082565390843 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark23(-0.6908055795844993,-0.13042419890055199,-0.4399953736051987,-0.7201860639471723 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark23(-0.6940585896160268,0.1817587891034046,-18.978163643614934,-0.4277109803817282 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark23(-0.6946745535960728,0.13757381334536445,1.1327354401954846,0.7166112567247661 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark23(-0.695860820273838,-0.21986410056185068,-0.014761076197166738,-0.168333355639777 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark23(-0.6959491988649403,-0.34479564516318545,0.6353317438137354,-23.070690704186532 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark23(-0.6968996830771259,0.17699696064064419,-0.43694832185888544,93.24727873714542 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark23(-0.6976030980569233,-0.22323481141148033,0.34880154902846167,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark23(-0.6979161575223998,0.1199529492410818,0.21713797701895565,91.96043890585557 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark23(-0.7007033127167959,0.06150570344282197,0.9453092320801556,69.24338299921179 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark23(-0.7011340450907307,-0.43086983960594827,-0.40347180427600393,-72.16964079845704 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark23(-0.7020753562787707,0.1663411776342043,-100.96198153500504,0.7022275745803461 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark23(-0.7021465463818919,0.06201886843629776,-0.43432489020650233,-80.89019201036254 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark23(-0.7027003768473781,0.1548624139211722,1.1346348429168434,-55.90451563865444 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark23(-0.7029319198133976,0.05935777593063585,-3.976148022984935,-0.1990132172165343 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark23(-0.7098695240831295,-0.43046340135588324,0.35493476204156477,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark23(-0.711614611990314,0.09672363128078046,-68.82539138810682,-98.91438613532277 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark23(-0.7146117260931026,-0.04300916241052215,0.3573058630465513,0.15571644426947756 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark23(-0.7147999088552877,-0.23506796510271044,0.8749846451109289,69.41627635923362 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark23(-0.7175610744108168,0.12183514219305933,-0.42661762619203986,-16.24327148303631 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark23(-0.7185067279130871,-0.41009731137391725,0.3592533639565434,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark23(-0.7205889607572975,-0.3706288809151582,-0.4251036830187995,55.510065215426344 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark23(-0.7207605915428899,0.07171226907818273,-19.30276003978741,0.479852820980531 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark23(-0.7231554023899764,-0.4238204622024597,-100.0,81.80875030112861 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark23(-0.7237524751388814,-0.42352192582267423,-50.55798886819437,0.7587706717753577 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark23(-0.7260950753283807,-0.4051447513665065,0.07569430574238811,-99.8026946948404 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark23(-0.7265713630473749,0.1176536007001463,0.23409350953395494,75.98917257825578 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark23(-0.7299628926271546,0.11087054154058706,-0.4204167170838709,75.35956301358593 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark23(-0.7305634707017236,-0.4201164280465781,-62.47180644209329,0.16880211351099922 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark23(-0.7307823405906567,0.1030000494019652,-0.42000699310211986,0.7338981386964657 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark23(-0.7308988181532552,0.07932554551753841,-106.73188953764564,108.29406844153979 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark23(-0.7315205729417682,-0.4196378769265278,-0.4196378769265642,98.64058034813947 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark23(-0.7317969652196219,-0.41949968077919614,1.1512966460072591,0.9951480037870464 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark23(-0.7331278249883715,0.09229053818698701,0.46054538552742263,77.40425664625423 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark23(-0.733641770259165,-1.4208450400905512,0.9782792961196923,123.21613125311353 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark23(-0.7350023021628215,-0.11666078300888216,0.42186427745094446,0.8437285549018894 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark23(-0.7351774007125222,-0.11530396498269546,1.1529868637537093,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark23(-0.7362024687887698,0.09839138921735668,-16.78794889076608,2094.776958673296 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark23(-0.7382358292555211,-0.23237443957535153,-53.780184920015046,0.6526618653191951 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark23(-0.73953875934135,0.0019951015409546396,-44.341786472466,0.46607684318453035 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark23(-0.7402885020299411,0.09021779524384876,0.12273124585876155,0.7402892657755239 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark23(-0.7448095573293312,-0.40180419708950227,1.1349122424735045,0.20090209854475316 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark23(-0.7466463367294552,-0.412074993950616,0.9627077799388571,97.89688991064573 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark23(0.7472212501203688,-0.7262821152254679,-7.445774113858903,100.0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark23(-0.7475136281160739,0.07576907056274855,0.33011544321164954,-0.8117032232308512 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark23(-0.7540055775738916,-0.03996381757056094,0.3770027887869458,81.32693921149854 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark23(-0.7550453688335388,0.06070558912781836,-0.40787547898067883,-80.10266045794957 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark23(-0.755997690648994,-0.3776042564497944,-22.028650389808945,-153.6425041436974 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark23(0.7568212453055024,3.084438817405901,-0.4362243300592552,-2.327617572100399 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark23(-0.7569786387352017,0.055033231112977206,-0.4069088440298474,-0.8129147789539368 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark23(-0.75887347761163,0.05304937156682453,-0.4059614245916333,26.25510150120721 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark23(-0.759127345658031,0.3793015817899861,-41.96736741299953,100.0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark23(-0.7597425387859307,0.051311249223034316,-88.32275439710686,0.6153071199780732 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark23(-0.7627426003269031,0.045311126140800934,1.1667694635608994,-1836.265443421276 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark23(-0.765912526607275,-0.15406636795345188,0.6138582241008719,0.07703318397672593 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark23(-0.7670392066575921,0.0367179134796646,0.3835196033287961,2.7407298777859967 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark23(-0.7683455472329845,0.034105232328927315,0,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark23(-0.7721712482840914,0.022466626721585645,-50.367877264025566,-1.316240237312838E-11 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark23(-0.7747464187385737,0.02130348931774878,-47.39565164538248,63.63328986188806 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark23(-0.7761758853222486,-0.3973102207363239,0.47658465871914013,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark23(-0.7766953434902479,-0.05526333955317422,-78.47915504541837,-24.841731749551244 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark23(-0.7796780133858016,-0.3709256944721219,-13.328308160851654,98.1540455429521 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark23(-0.7797955985964797,-0.10693839096284506,-3.552713678800501E-15,0.0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark23(-0.7831324672528629,-0.2676735411676632,-100.0,91.5476663300547 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark23(-0.7839374403517717,-0.1811334923099484,0.0,0.08204976785344653 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark23(0.7853698290502574,3.1367251824701086,-9.640038310849471,1.7047529409885538 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark23(-0.7853927128267266,0.0,0.3926963532745437,-0.3932819605270278 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark23(-0.7853974941805343,5.261326168011996E-10,6.415605341331466E-12,-0.07237496439904625 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark23(-0.7853981633974438,-0.036405181710836135,-90.93677884833517,0.09473871930675558 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark23(-0.7861429701367353,-0.09934822856850822,0.39307148506836764,18.58336362064426 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark23(-0.7861475037000631,-0.3923244115474166,-19.56574088259934,91.43770368768467 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark23(-0.787080081681191,-0.0036964782191929234,-0.32232764535806463,-72.83125738052743 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark23(-0.7871620948332393,-0.006082127187771246,-16.42321793822866,100.0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark23(-0.7902420477925722,-0.39027713950116194,0.3951210238962861,-67.75607102072722 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark23(-0.7903428794502845,-0.0733358672083475,-100.0,100.0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark23(-0.7915965817787314,-0.24156363794834812,0.0,-219.75673055055978 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark23(-0.7928214417221799,-0.3889874425363581,-10.224963544775486,-938.222137447518 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark23(-0.7950858776903703,-1.5895149754417865,0.397542938845185,40.072477870197694 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark23(-0.7979760860754956,-0.3071701610437206,0.3989880430381363,0.15358508052186126 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark23(-0.7992385929894064,-0.03661296698590692,1.1850174598868712,-85.44793737119758 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark23(-0.7993749748052328,-0.027953622817002997,-43.136717220296426,7.771402505463985 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark23(-0.7994955731117389,-0.04389158670615301,-0.3856503768415789,0.021945793353076507 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark23(-0.8007054629491748,-0.03061459910345432,-66.48036393206185,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark23(-0.8013219777030939,-0.3834512607805005,87.77637184019758,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark23(-0.8019914741680869,-0.3548347604075044,-100.0,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark23(-0.8038488064227796,-0.03690232890275643,0.02614732666491917,-0.08093468633950163 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark23(-0.8043141936619962,-0.0995756690677576,0.4021570968309981,0.049787834533878805 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark23(-0.8048070531978777,0.308176476344618,0.3886182819074128,-88.09154711776029 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark23(-0.80579098369015,-0.2984879211065272,-75.81250743758355,-1385.3379562395814 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark23(-0.8069874358958936,-0.14475950065647747,0.4034937179479468,22.17913653160283 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark23(-0.8089363535979189,-0.1389854701115531,-0.3809299865984888,-0.7159054283416717 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark23(-0.8103637239003186,-0.380216301447287,0.4051818619496193,-0.5952900126738048 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark23(-0.810373523696948,-0.04995072059900002,0.405186761848474,-1804.0973675562673 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark23(-0.8105218049563828,-0.050247283118273915,0.7063542059768622,-0.7602745218373056 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark23(0.8107696752157962,3.192335293484149,-110.86876254363463,-0.8107694833446262 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark23(-0.8149770618462061,-0.08456325310970607,1.1928866943205512,0.04228162655485301 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark23(-0.815221197168951,-0.12053180098040167,-29.415013238579387,23.33495028079099 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark23(-0.8161404677540969,-0.35969513812214443,-37.39976245185617,-75.21031135960082 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark23(-0.8164479289849709,-0.0621489155071335,0.0,-0.013129451331453212 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark23(-0.8168156832831475,-0.06283503977139902,0.40840784164157373,-3.961029156126152 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark23(-0.8177183060939115,-0.06478342045905051,0.869890747970075,0.03239171022952525 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark23(-0.8182061868083523,-0.376295069993272,-94.47230381427838,-35.81880334049059 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark23(-0.8193222477628428,-0.06784816873163883,-63.28967099689671,1.390974726779021 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark23(-0.8199271886005749,-0.28964268924225334,-36.599788105198556,0.930219508018575 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark23(-0.8209858498245725,-0.0711753783075622,0.7746271325117454,72.42710545573675 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark23(-0.821341204228035,-0.07220677656867915,-9.095900126419423,-54.008118361462174 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark23(-0.8213948729020147,-0.07339768216878548,6.776263578034403E-21,-12.528847153068336 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark23(-0.8214818772756942,-0.1820120679941276,-0.10407646704085494,92.76826147347279 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark23(-0.8225772459627569,-0.08369619405682702,-65.57848866877406,-12.960107771572106 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark23(-0.8233298514355765,-0.19146309123279145,0.509346501928178,-26.438525351875256 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark23(-0.8238145050606266,-0.30382436076456926,-0.2926528709061011,0.6255643541056548 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark23(-0.8244123809724636,-0.07802843515003109,-21.975383898154856,-100.0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark23(-0.82603637317863,-0.36408389224300347,0.9907764540337993,-6.238418473571727 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark23(-0.8268936021466237,-0.0829908777971304,-6.5835418450061445,13.475568988043133 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark23(-0.8283688199413757,-0.2568224258258289,0.41418440997068784,-5.970325329818624 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark23(-0.830006977161487,-0.0892176275280775,0.681944978871712,16.730164231835982 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark23(-0.8302680777293384,-0.08973982866378055,0.8449527881987731,0.044869914331889874 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark23(-0.8345652168297667,-0.1080327753128335,-99.99999999991219,0.05401638765641681 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark23(-0.8352883004876684,-0.16713359975324416,0.4176441502438342,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark23(-0.8362175048268404,-0.10163868286013877,-100.0,36.97010385974236 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark23(-0.8372460340774583,-0.21558548831196694,-0.36677514635871944,-57.79370154775884 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark23(-0.8380686981003083,-0.11170267169033873,0.5089161311541629,14.434068231113221 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark23(-0.8388213326278143,-0.10820220024273342,-0.36598749708354106,4.995657470914287 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark23(-0.8423591525086797,-0.1344170313996064,-0.3642185871431084,-100.0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark23(-0.8427995897234618,-1.6128821168926337,-0.36399836853571743,-80.8754213384676 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark23(-0.8430114842568224,-0.11522664171874908,0.4215057421284112,-75.49746968289476 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark23(-0.8432005357474051,-0.19235846942011914,0.4541017802862646,6.2534868831454515 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark23(-0.8447867734351086,-1.6875919568113475,-18.083907548814345,45.32607354433324 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark23(-0.8464944953765265,-0.12219266395815698,-69.44131986906794,-47.39217636040958 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark23(-0.8467213316212681,-0.14007392954614628,-60.070523696812394,-44.206807623961254 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark23(-0.8485716945910142,-0.12634706280541236,0.42987862813615213,-100.0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark23(0.8486344244647038,-0.48534742149796606,-0.42431721223233865,0.24266942411470424 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark23(-0.8498922199434353,-0.36045205342573045,0.4589429619719652,-0.9730478497125018 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark23(-0.8502932591824349,-0.3602515338060772,0.42514662959121746,0.18012576690303864 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark23(-0.8509134592613381,-0.3591740069888392,-40.90511665935793,-9.024572238209918 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark23(-0.8526040827383679,-0.13441183868183965,0.6509863243002085,99.16330791809557 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark23(-0.8537339819640822,-0.350661004857529,1.0047255372657933,-0.6100676609686837 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark23(-0.8539499081435911,-0.2962775885475306,-0.35842320932565275,-0.637259369123683 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark23(-0.8542104231259386,-0.35829295183447885,-0.33408221512888037,-5.253383949937611 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark23(-0.8592270184102757,-0.14765771002565503,1.0107091864313231,-31.569168544917936 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark23(-0.8627243854920732,-0.15465244418925028,0.4313621927460366,50.16976427708668 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark23(-0.8635413305124624,-0.15628633423004212,-0.3536274981412171,183.09675945637431 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark23(-0.8651336561610967,-0.1594709855272971,-7.079856053587968,-93.89526336221226 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark23(-0.8709177474664249,-0.17138217293746122,1.2203465828322413,-80.7840467040305 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark23(-0.8721138095764337,-0.17343129235797106,-33.404186630361,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark23(-0.872641074553422,-0.22004793622332192,-103.58240646510733,0.11002396811166093 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark23(-0.8737033203796153,-0.3485465032076358,-0.34854650320764063,-20.946692780039726 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark23(-0.8746322357485332,-0.34808204552318145,-69.78796957816215,-47.17621354208044 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark23(-0.8786976625654357,-0.1966680202265625,-0.34604933211473043,-70.86835440246256 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark23(-0.8805645198764029,-0.25580688508314364,-40.80417552927498,-97.18643336741762 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark23(-0.8821255623674371,-0.19345479793997877,1.226460944581167,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark23(-0.8833123180255376,-0.19625032963591482,-24.71434804328571,58.50740328810469 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark23(-0.8843516973348151,-0.1979070678747344,0.44217584866740756,1.6697498607322638 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark23(-0.8848151263697026,-0.19883392594450883,0.5282694201795337,-5.102676460036193 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark23(-0.8871243603428594,-0.3418359832260185,0.4107644474638138,1.658792231545391 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark23(-0.887706692144762,-0.204617057494628,0.443853346072381,98.11903531905553 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark23(-0.8897089828334507,-0.2086216388723035,-0.12268156578234975,98.82104407826597 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark23(-0.890464194803771,-0.2101320628126473,-0.340166065995561,15.805895921842833 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark23(-0.8911211238648963,-0.214531083825482,-59.68477097559877,0.8913487849907591 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark23(-0.8915565982850677,-0.3859016353220641,0.45623935513705516,-188.30719739660648 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark23(-0.893795687312857,-0.33580548043674313,0.4468978436564285,0.16790274021837157 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark23(-0.8947604971587486,-0.21872466752260156,-58.947023604017076,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark23(-0.8956742453226674,-0.22055216385043858,0.4478371226613337,-3.4334732763571716 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark23(-0.8959899531978603,-0.2211835796008247,1.135029700633129,-68.938080503749 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark23(-0.8972413224670885,-0.2720686004534762,-0.336777502163904,-73.56478835680898 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark23(-0.8987961277034957,-0.23501994323987552,-28.735665591589147,64.90054628863227 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark23(-0.9000915071474472,-0.22938668749999813,0.8427448352724465,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark23(-0.9002658315911504,-0.32989396269954996,0.45013291579557513,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark23(-0.9008645284638014,-0.23093273013270643,0.4504322642319007,-31.66710408209088 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark23(-0.9017159954951107,-0.32395476776437865,-0.334540165649893,-0.11911767602602845 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark23(-0.905862188577449,-0.28103826542716936,-44.304808564245235,0.1405191327135847 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark23(-0.9077211540760315,-0.3163423027001365,-68.8980852109984,-7.077189369918173 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark23(-0.9090560266863171,-0.2538883515738533,-191.7861004829331,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark23(-0.909102674161139,-0.24740902152738165,-0.33084682631687873,0.12370451076369081 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark23(-0.9107641158064855,-0.2959120223275316,-100.0,0.1479560111637658 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark23(-0.9108777299636325,-0.25132990151428436,-78.77577436848541,-100.0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark23(-0.9131150604620553,-0.2554337941292142,-31.06249123070822,0.9131150604620554 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark23(-0.9154145959812799,-0.2600328653038629,-0.32769086540680825,42.66177140227825 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark23(-0.9167696145883094,-0.3088521751292682,0.4583848072941547,0.9385093306426404 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark23(-0.9197644804319096,-0.2687326340689229,-57.50979172380641,79.01840219969552 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark23(0.9202930785847392,2.943167018114512,-0.4601465392923696,83.31395492570583 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark23(-0.9214316052812761,-0.3246823607568101,-0.32468236075681156,-0.06472044578740635 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark23(-0.9216692487269952,-0.2734392393690124,-36.46526712460722,49.530098600821844 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark23(-0.9250526526197727,-0.27930897844464997,-62.70436305819206,12.65099453259725 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark23(-0.926305236301028,-0.2818141458071597,0.05525843562006377,-13.963889099278232 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark23(-0.9275879410939999,-0.32157168780919726,-29.067291790230627,-0.08688999599922986 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark23(-0.9277579464966016,-0.28471970641482786,-0.3215191901491475,0.14235985320741396 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark23(-0.9283200920416528,-0.28584385728861944,-75.7224265095831,36.9033198079672 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark23(-0.9287773638690546,-0.31946930352254693,0.46438868193452737,-26.189229020210824 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark23(-0.9294858298331736,-0.3030419257558943,1.250141078314035,47.38669147654103 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark23(-0.9297465530474305,-0.3068569688628859,-0.3205112308755746,0.9388266478288912 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark23(-0.9300012141060026,-0.289206101417109,0,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark23(-0.9424777960768083,-0.31415926535904326,-54.200486066963215,-100.0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark23(-0.9536364935049968,-0.11215050154288264,0.36810124607282163,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark23(-0.9660315523329472,-0.2544140732284165,-210.58455563804102,99.99999999999633 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark23(0.9793555965315298,3.2652231963015548,-0.4896777982657649,-2.4180097615482254 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark23(-0.9943911495149731,-1.5713697429922717,-93.92287952937637,5.421010862427522E-20 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark23(-1.0162766972668988,-0.4617570677389013,-12.916857589112558,0.231508830349415 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark23(-1.0223529111893108,0.5079025107125549,0.5210477667016098,-1.03934941875373 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark23(-1.0473629523644363,-0.7999785396556388,0.5237499512975272,-0.3854088935696289 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark23(-1.04867397136283,-2.0733931256238205,0.4587499461159794,-129.34619130295815 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark23(10.492898715787707,22.53035252397511,-6.031847521291302,-11.265176261987556 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark23(-1.0619344610615875,0.1936006023967126,-99.9999999997412,-0.8821828428552135 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark23(-1.0634411793567882,0.4881319510038496,-100.0,-45.75328134333226 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark23(-1.0711469024875886,-1.0636212394236362,1.3209711211600421,-100.0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark23(-1.0830860110712612,-0.2438551578618171,-100.0,-2.244302959946074 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark23(-1.0966729425363815,-0.6225495582778664,0.5483364712681907,-20.281289687521312 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark23(-1.1049908515598552,-2.163558840106425,-0.23290273761752056,-57.81445075262693 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark23(1.1092822555939363,3.789358509959327,-12.88716375627972,21.667265647614734 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark23(-1.1127257217857094,-2.2254514435714188,0,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark23(11.160244471252023,-5.58012223562618,-6.36552039902346,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark23(-1.1216960146132078,-0.6725957024315193,-0.22455015609084442,87.336228359772 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark23(1.1253568394879974,-0.3529972313801415,-98.7924252116876,227.18101401192513 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark23(11.275221686421858,68.82965120668231,-94.95778535731463,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark23(-1.1324810748698805E-7,4.484155228993886E-44,0.7853982195361785,98.24028615958773 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark23(-11.32518632392516,5.66259316196258,5.850533989429951,-54.09858309618268 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark23(-1.1335812440498767,-2.2670284521570623,0.5667994089088815,1.91891238947597 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark23(-1.1385119876569056E-10,-1.199040866595169E-14,-0.7853981633405227,-23.226066197982888 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark23(11.465899437527824,-91.73480553560229,-21.87645765857124,-74.1391044763246 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark23(-1.1672334093974583,-2.3196379509897516,0.5836167046987292,-1.1926123234268944 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark23(-1.1711244815858626,-0.7896938495538282,0.5855622407929308,-233.88203796122855 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark23(11.889338104871662,25.34829710826771,-87.96471438790418,88.64437398000356 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark23(-1.1904368221682673,-0.8100773175416383,0.4085247358276025,6.534534163923172 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark23(1.1948603052804003,-27.549932949748396,-73.09073520892093,56.34829804543415 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark23(11.990240542482809,25.551277411760513,-100.0,-12.775638705880256 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark23(12.06785913425892,-2.8190829348191637,25.595659302511287,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark23(-1.2153431127911933,-2.4306861781255975,-6.174587137531219,-89.10549116869282 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark23(12.214901309519426,26.000598945832227,-100.0,-2.5317560451818295 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark23(-1.223729278913291,-2.430416612128216,0.5132939264247063,-1.126357682151563 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark23(1.2551368868390211,3.795267920492283,-0.10208997132118569,55.430352725648795 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark23(-1.268626894986991,-0.15108471590395212,-0.151084715903953,-2.8447228483727125 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark23(12.729944362589817,18.00142972907786,-6.236852233824721,57.82346991189077 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark23(12.7475877096169,27.065971746028694,-75.08410609366459,-12.747587709616898 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark23(-1.2777137427383423,-2.412890498221455,-1.9930250417046174,1.4324260037728513 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark23(-1.3105591691460596,-1.051174261009807,-100.0,-0.2596259400070032 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark23(1.3163659207053604,4.20352667639384,-95.74616301513392,100.0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark23(-1.3264101142955873,-2.6386141347943606,1.448603220545242,-89.00172414916706 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark23(-13.278776517485005,-24.986756708175115,5.853990095345054,10.74831854224038 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark23(1.3413936701440372,2.6827873402880753,-0.6706968350720186,-28.16993035010331 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark23(-1.347950790590287,0.255960180167629,2.2614819411626708,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark23(-1.3526596434768827,-2.6626505723175677,-0.10906834165900693,0.5459271227613356 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark23(-1.3716631537679336,-2.7433262822089652,-129.3985763053808,1.3716631411044826 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark23(1.3718391059192214,-0.6862152824880414,-2.2538989206436604,-57.749147881739034 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark23(13.746304035604313,29.06340439800352,-7.4263958663194725,-13.746304035604311 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark23(-1.3913634249927973,0.6952805900942204,1.38232487165322,-100.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark23(-14.058934916444386,13.699938027382473,5.682863651585947,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark23(-1.4208239669115068,-1.270851607028117,-90.40677216404545,100.0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark23(-1.4511148573061428,-2.61544427140618,1.5109555920505198,-59.953334916751125 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark23(1.4595161566763748,-0.7414183449083054,-142.84143696344907,1.1852609986052869 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark23(-1.4657584365652037,-2.6413723314342654,0.7328792182826018,-100.0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark23(-14.669248848354929,-29.33849766949502,6.594877971329195,14.66924883474751 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark23(-1.4904214759454575,-1.586429307352609,-20.978421630813212,47.034130593560015 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark23(-1.495806861651717,-2.934714412661511,0.7479034308258585,0.6819590429333071 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark23(-1.5085970238463626,0.7542882739326225,-8.784311144821125,-0.37714413696631127 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark23(-15.09534683224129,-29.307152187817927,0,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark23(-1.5100529548476034,-2.649910723004322,-51.95532022168511,28.81196377741583 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark23(1.5128089522872539,3.329267718728404,-1.541751395384712,46.23718480306578 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark23(-1.5285428558912664,-0.02112673545181023,-0.021126735451815648,-67.65395032276417 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark23(-1.5285947932308885,-2.171482201237607,1.5496955600128923,-11.481952067291749 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark23(-1.561929984866424,-0.004433112761776618,-100.0,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark23(1.5663201631772627,-1.568343366455008,-0.7763738035141239,-61.24544236540508 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark23(-15.75518207952093,-29.939567832246965,0,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark23(-1.5779493880595816,0.7840182525043274,0.5661304273645855,40.48600923989423 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark23(-15.995779611279644,7.22492881393551,0.7669093133961695,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark23(-16.102818636498114,24.179428443755626,-4.781181238357732,63.60266769215542 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark23(-16.140994074212244,8.918568334104299,8.85589520050357,40.58649804724456 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark23(-1.632822072374949,-3.2617133457728005,0.8164110361874745,-88.68993797256928 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark23(16.754035416278068,-1.1624133958954541,99.92828749544016,0.5812066979477271 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark23(1.6756368325923428,3.742205673330467,-1.6232164210197824,8.053652508687904 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark23(-16.79074579739614,-32.6471118979875,0,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark23(1.7104884142358538,3.7592833792226656,-2.0319780596850023,-1.0942435262138845 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark23(-1.7112626444953984,-2.494911120162606,0.8035229216501221,24.021117359671784 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark23(-17.260892354599527,15.845048014105593,9.415844340697213,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark23(-1.736157281561731,0.8500748822299401,-154.0509751986694,-0.42503744111497 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark23(1.7390464088899655,-1.579598340301433,-1.654921367842431,-86.41649168168199 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark23(-1.747905483370741,-3.2171257422971666,0.8739527416853701,1.0154082742162793 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark23(1.777281067741228,5.124947386785998,-89.26832226412374,-3.3478718567904475 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark23(1.8183792385451136,-0.9093443064695296,-12.940142331662145,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark23(-1.825238507637136,-3.6504597000052295,1.2311520545019854,99.99871287742985 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark23(-1.860834267829492E-4,-1.1319721899383413E-4,-32.985389591865925,-100.0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark23(1.8677412969619023,-1.0503252991447733,-93.32270173494676,0.5251626495723866 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark23(1.870262091896916,-1.1788931265388953,-124.62716953193161,0.5894465632694482 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark23(-1.8747724549491571,-3.7439678934308063,-55.71338959461626,-72.74174562937972 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark23(-1.8796917919108407,-2.701959460410524,0.9398458163697105,156.07430027867713 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark23(-1.8798736238327356,0.19403536711807431,-75.24531896027433,-0.09701768355900242 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark23(1.8962108672447509,5.360944789290681,-0.2809086742513246,-62.366226816916644 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark23(-19.14270030410075,16.828479694038506,9.653727851105657,-8.46474344781327 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark23(-1.9562618811734078,0.9116982712007665,0.21027993070168716,-41.10876479394502 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark23(-2.007840520681006,0.5821774562855865,-86.24475794314748,-10.869089156532127 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark23(-2.0291195205916366,-4.058223910808453,-6.196110382732968,2.8145101188016746 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark23(-20.37610753763732,-40.75221507527465,0,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark23(-20.793979905460084,9.611591789332595,9.58734951206545,99.99999999999999 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark23(-2.1372922235378646,0.8321853529179501,-33.88891155734403,157.2172124378813 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark23(-2.1625620925382942,1.080039537970265,0.29588288287169884,-99.99999999998731 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark23(-2.1705626123786383,-3.8174741954552838,-91.16026892881925,1.123338934330193 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark23(-21.883974626692744,-42.25160554067925,11.72738547674382,18.778770624693678 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark23(22.43918076398638,-4.004843085040655,-11.219478519622646,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark23(22.44307430333203,46.4569438207499,-93.36742573862928,-22.4430737469775 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark23(-2.252009897898476,-4.48314733268671,-16.008197899274123,2.24157366468128 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark23(-22.589711734582224,-20.384632272556274,4.623314380695561,-70.41269717012793 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark23(-22.68544623560676,18.632281891981982,-49.38678210833611,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark23(2.2807074585537164,6.125628047987828,-32.64932907621315,-11.655582284364561 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark23(-2.2809426040477803,-3.1846095136872288,0.35507313862644185,-29.09753051282986 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark23(-2.309166108489442,-4.611425649352252,-168.1322198455095,153.10142863137776 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark23(2.309610373392948,6.190017073580789,-0.5615181927279602,-2.3096103733929456 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark23(-2.322737045664305,-3.2343836511100923,1.16121835055861,-39.47389462807924 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark23(2.326298227268016,-1.9325773585056112,-33.35919752898342,1.7501587005568982 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark23(23.443572177681713,51.49281924334009,-22.744998338269752,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark23(-2.353163401608552,1.173152996160333,0.40586055878274063,47.041173362617116 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark23(23.593737555842836,-4.4410320864784865,100.0,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark23(-2.3763815175498144,-4.705502530832631,0.403545575672131,76.17935661797827 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark23(2.4135051668641188,5.726011578598082,-1.9921512445990823,7.340281032019613 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark23(-24.402126796322918,-61.2942764648444,-61.24425182078925,-65.83665673944053 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark23(-2.446578921150971,-4.86660864545826,0.4378912955546741,-65.8958711794859 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark23(2.4504047782142506,6.471605853564067,79.98953198159921,-3.2358029267820334 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark23(-2.468088887510818,-4.936044341127722,0.4486462803579608,3.2534203339613015 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark23(-2.4733470729829468,-4.8699661373727485,0.451275373094024,2.4344033172187474 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark23(24.80811511849677,51.00698260760981,-36.38496850879738,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark23(-2.5216119692579557,0.6948779568250097,-140.8976564095649,-60.918242109678324 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark23(-25.528195614338593,-51.05639122867718,0,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark23(-25.586308740358852,12.007756206781998,12.007756206781977,63.371298033212085 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark23(-2.591211948909304,1.0625850701973927,-9.415880287982095,100.0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark23(-2610.737309076065,55.29424746168635,0,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark23(-26.110052457119274,-52.2199457963143,3.0630611175061944,-64.21672804825747 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark23(2.620019435192262,-0.9931456867551974,-9.120615397503801,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark23(-2.6320842423319526,-3.727699227316448,-106.93496929990444,1.078474124345421 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark23(2.6374986419114683,6.416682631460175,-49.22561904120086,41.56008165495306 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark23(-2.6486527648731926,1.0928287511912083,-8.100495292928576,26.28855420355192 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark23(26.71074994834435,54.991101869061204,-72.55891981083958,-26.710152771133153 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark23(2.676168962688235,-2.114741340611754,-100.0,1.842768833703325 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark23(-2.681920396100284,-5.319685787608221,0.5602965905614588,93.76468281954519 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark23(27.175190024324465,51.435028901845186,11.872561221714847,4.00982467949602 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark23(-2.7212818733819972,0.7618661651954342,-100.0,-1.1663312459951654 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark23(-2725.7543162133557,38.28686458797398,0,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark23(-27.476999015647824,-54.488049855867864,14.52389767122136,-43.4416570700792 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark23(-2.790490882548919,-5.322187680068946,0.6098472778770114,-87.65973796387928 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark23(-28.160457770199244,96.0739277784622,-60.29089996794619,76.043198403069 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark23(-28.51408551983009,22.15457127430627,14.13633747256366,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark23(2.8581726091950843,5.785515727946384,-1.4760800678316441,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark23(2.884473899914211,7.339743685436877,-0.8165252482952033,100.0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark23(-3.01043541659063,1.2546379429132029,0.9781262753131087,-136.76362151938207 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark23(-3.0611444603314544,-4.6099038848543366,-11.353863806295902,-57.27048463305476 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark23(-3.0865143138023514,-6.172827424943318,-100.0,3.086362310993121 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark23(31.554696049714547,64.68018842622399,0,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark23(-3.1637910485884984,0.7966328520201489,-80.88531679678388,-30.77896160859649 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark23(32.181759440097466,-8.87627788340313,-10.672247670198558,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark23(3.2188438853587167,-0.20981278898459774,-27.527732738203518,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark23(-3.274788437733066,-5.694429521282638,1.614105345694732,36.330580156338954 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark23(33.085132747436006,12.947215134445543,0,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark23(33.45855966664212,95.43102133037272,0,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark23(3.3736676425155427,2.5814977309990015,-2.472249866645633,-2.0761470288969477 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark23(-34.47053348240287,-67.37027063801085,0,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark23(-35.0004753650274,-70.00094448063886,17.892935201858442,35.00047224031943 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark23(-3.581890534318981,-6.791862937005163,2.5763434477470692,-17.872319101635743 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark23(-36.1591040957117,-70.7474118646285,0,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark23(-3.6327734340126927,-6.792069687552856,-100.0,100.0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark23(36.36983783092646,74.3104719886478,0,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark23(36.37286303466368,34.14138249192652,0,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark23(3.659303587568685,8.88831533447807,-99.99943452126315,-49.99718427733404 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark23(3.6944040616278926,41.65122416519844,0,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark23(37.302725407263125,93.40623148716901,-29.666669303629376,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark23(-3.7358790559901576,-5.9036364386999995,1.8679419218206441,-164.8470499066905 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark23(-3.7495493827866386E-11,0.0,0.7853981633788257,96.54618106782365 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark23(-38.168967263855876,92.37606595615341,59.95475898336926,2.510425481183873 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark23(-38.20650496332738,-74.84221359985987,0,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark23(-38.26891279311009,6.665913906287585,-10.204247096351551,-75.6441892575583 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark23(38.616499268486564,-11.548375800296519,-19.30824963424328,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark23(3.9550453318738463,9.480365297733444,-1.2828148798226466,-66.00105483284827 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark23(-39.869357847563435,-78.16791936833198,0,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark23(-3.9906459075817793,-32.77665353607972,0,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark23(-4.014897694481876,-8.024080019158607,2.654612566392073,93.60968234109147 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark23(-4.063768444610184E-5,2.0318842223046585E-5,-23.127196578442774,-98.37514856347757 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark23(-40.95977885629036,80.60323165311814,-47.21489909891443,19.60577412448383 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark23(-4.1710619452412574E-4,-2.1796974541491042E-8,0.7261977276469397,-0.7853981524989609 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark23(-4.184484591464652,2.0252314967558527,1.3068441323348776,-32.91158837807902 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark23(42.810390178124095,-69.30112665873372,-63.306584919147355,-63.4235653794196 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark23(-4.2979825636068165,-8.588402816892767,-52.62323668975301,4.2942014084463835 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark23(-43.31772456400631,-28.685272712994703,0,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark23(-4.4652207271978765,5.484163510500327,2.2125946554482345,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark23(44.72406314283816,-61.62963435743129,6.851136661671504,23.502841057959273 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark23(4.492378231620844E-4,1.4034559414392191,-1.1102230246251565E-16,0.08462484037433171 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark23(-4.4936684365731,-7.416549841491998,3.032116414096194,4.4949874986306915 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark23(-45.42821688713876,-37.7729467343366,19.010402302605783,-56.507612570226385 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark23(4.574069597175495,10.556443206976827,-2.0686553820195765,-96.36591884524196 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark23(4.577449614845794,10.716332858105861,-181.12697485452856,23.357640454980995 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark23(-4.595971793107615,-8.941233363253174,3.0833422980978464,5.25488332882987 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark23(4.6042526684433773E-4,-2.6736406965289963E-4,-52.621907104321956,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark23(-4.6241208130703635,2.311959902719984,3.0973580661174296,-0.3705817879625437 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark23(-47.025952667300295,-3.643989406858637,41.4383714334744,-62.12519788509934 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark23(47.06739588196004,-99.71963414784088,47.975580927184836,12.667497506706326 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark23(47.5715148286732,-20.14947374254244,-81.91717083251532,53.841902609151475 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark23(4.785099023100981,11.14082517764183,-3.177947674947939,-5.570412519698753 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark23(48.034623954316885,75.92239523827968,71.50342496939714,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark23(48.441835469891835,96.88367093978368,0,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark23(-4.868882449608121,-9.731603080506401,2.4350419013759987,14.790577696936873 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark23(4.8800858795597115,11.32938846207027,-3.1859374232945252,-4.879296067637687 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark23(-48.99946469217462,-39.020919273867236,0,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark23(-4.93050771632417,-9.83702825486535,3.126364775106968,-39.85095317925196 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark23(-49.650413660424285,32.039835111103734,-78.06198105802329,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark23(-50.18703735957213,-42.79003087418856,37.74696761775431,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark23(5.025042941162564,11.620882209120023,11.579214165722307,-1.9279530401022742 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark23(5.110485077617325,-2.555242538808665,-12.25132372728174,-35.61207103297975 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark23(-5.1964004113768,-9.869502007591038,1.8049654477394845,50.46017715080051 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark23(-52.199440456589684,-104.1430651526194,0,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark23(-5.227981300965955,-8.893024044435256,-22.52730392245773,3.661248522777468 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark23(52.3819618619155,-72.67641453432225,-79.74929830371597,6.648276827550248 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark23(-5.264948023101209,-10.449477916450844,1.8470758505986602,2.875723244938993 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark23(5.286049339678567,-1.4260742349372,1860.4870386864154,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark23(53.05522238195064,-88.82307721239052,-85.83046665767424,-37.24471510801355 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark23(-5.329070518200751E-15,-9.325873406851315E-15,-2.639784051527722,2137.774243390818 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark23(-54.0302865666569,-107.20761123985552,0,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark23(-5.408538553223764,2.6595168255699653,1.9657034682848709,100.0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark23(5.486970135073354,12.342700409055693,-2.743485067536677,-34.44568402287562 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark23(-55.0413968115961,68.00439891781923,73.54206249144909,9.324320162670219 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark23(-5.510895224819369,3.5009275393545125,3.5408361121760255,-145.48393997338903 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark23(-55.391206536230726,34.92203916168333,27.681793669707787,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark23(5.552677307168411,11.10535461504759,-3.5617368169816537,-79.37710391433686 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark23(5.580599686557706,11.84327286315863,-97.91691803043908,-8.273302087518951 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark23(5.593641788565384,12.755326807769569,-2.796820894282692,-26.79796693445357 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark23(-5.8242191974113044,2.8669296746880053,2.1267147911725535,-46.9637331785137 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark23(-59.533401673900265,-21.056012181559396,0,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark23(-60.674450251920156,32.410315783004336,-98.70166431503806,61.17812679442497 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark23(-6.099165214260697,2.3416580284441046,1.478771982074619,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark23(-62.24339331597939,-74.83121043527765,-98.99628731941665,-49.772849464858005 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark23(-62.26911064936089,90.12478314556344,0,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark23(-63.16489664141709,9.174966718951083,14.102211579563729,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark23(-6.320864859713782,-12.487016041560807,2.375034266459443,-71.50383942774911 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark23(-63.230994455318054,69.79446587724695,0,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark23(6.378321900525982,14.327440099206369,-100.0,-6.378321886205736 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark23(6.38218216108228,-3.359969573894677,-35.41315452425005,-83.38627398180361 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark23(64.18062100531833,-16.822730193381602,-3.380647199108793,13.057948576659712 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark23(-6.545947164473527,-13.091894328947053,-36.90757374432622,6.545947164473526 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark23(-67.39056277297972,-28.50062401559596,0,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark23(68.61713986566397,55.96718703571608,-61.599384181264426,93.0582357967015 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark23(6.887131364481828,-4.225731469492943,-2.6583442107745476,1.327475203048068 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark23(-69.03306462848903,-80.86407526825818,-92.93392339008797,-86.97223986535177 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark23(70.4256652934711,91.19515087827168,10.199868424015051,41.381878424187505 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark23(-7.105427357601003E-15,-9.643289991677902E-21,3.552713678800502E-15,-0.7853981633974598 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark23(-71.16516600104833,62.21901092812368,-43.091553101594386,36.7191928515326 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark23(-73.76875973309156,-5.448205117518242,-29.297282258948727,-46.81489197324673 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark23(-7.484476373522639,2.1655433720714146,-59.889029656500036,75.09075496789728 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark23(7.5905831852155075,20.175061442494552,14.379744920537291,-83.39586430192605 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark23(76.25880176457184,-13.157092208994882,60.10002008900551,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark23(-78.33863052068759,24.946190867684834,0,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark23(8.038939536315208,17.64867539942531,-60.48447462827262,81.49645191771059 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark23(80.45989408738049,88.7016428158025,80.01531841616614,34.33711264235424 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark23(-81.16398445658675,-48.4498209536802,27.84118049928763,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark23(-8.290361280945225,3.359782779937713,3.359782477075164,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark23(8.516740797739017,-1.0195006880104214,-52.95267929138428,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark23(-8.538971305155755,-43.48130930108618,21.9380162833329,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark23(8.58139730908107,-22.55856744237221,5.501273977484104,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark23(87.34692349447982,95.24724805905745,-53.346267684677116,-29.144689716606592 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark23(-8.823200888270184,4.409175236233687,3.628326327909141,32.35292373760961 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark23(-88.42622461895901,46.572850501190345,67.71172568704117,-85.945276296576 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark23(-8.881784197001252E-16,-1.3322676295501878E-15,-34.95211060301722,100.0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark23(-8.920725327061223,3.6749689483611676,3.6749645001320554,-1.5435650459581272 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark23(8.993903531172988,20.0045990534695,-3.7115772206100726,11.266007607044372 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark23(91.13712830062963,1.7818299053770374,-6.789169053964201,71.27930780742687 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark23(-9.160713479070566,81.33189068872002,0,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark23(-91.8800928050559,-61.49194906759761,76.99480702894351,-14.474120457548437 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark23(94.01008979417645,80.26315844139933,-14.68342299053947,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark23(-94.1874153716912,51.390939063678104,-8.74526643320553,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark23(94.94785609422803,14.55463603210086,-37.51379349221744,-5.099315234709081 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark23(-95.72483655555867,55.45944924845606,67.48265305348411,-26.583638730266827 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark23(-9.639993965650751,-19.27437710443806,4.820004463023557,9.63718855221903 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark23(98.26919408434037,89.11334414281365,-81.4359129827519,67.20405821484277 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark23(98.53540255846343,-64.92615584332265,74.6099700589032,15.612948340568167 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark23(-9.987655769719867,-19.975305576183008,-32.930714331433485,-13.573118413555004 ) ;
  }
}
