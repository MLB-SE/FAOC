import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.29725081584597035,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(-1.0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-1.0000000000000009,-1.570796326791334,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark15(-1.0000000000000142,-7.323217533566477E-4,4.719054009797133,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0010915846832054632,3.76158192263132E-37,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0015775686601780664,0.0,-2.194726950453229E-5 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0018300025882434885,2.4308653429145085E-63,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0018531188164841903,0.0,-0.1801356686309871 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0023761035752481916,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.002602081386760093,-2.572847501202485,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.002614068644952813,0.0,-69.71425776678103 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0026167875871262103,0.0,-0.9700991665835766 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.002629840638802365,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.002629840638905479,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.00828986027524558,0.0,1.9259299443872359E-34 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.014971779166039152,0.0,0.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark15(-100.00050067190574,-0.020699829471883528,0.0,0.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,14.429213048713208,0.0,-0.9999266213251295 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-1.5707963267948961,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,3.3877295827908873,0.0,-100.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-5.904398494914307E-4,0.0,-72.35801815495753 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,6.751155878046942,0.0,65.00560461081452 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-8.304362703495738E-4,0.0,-0.03437054443977929 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark15(10.66808467525071,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark15(-11.016988432546214,-0.006089753064526588,0.0,-9.629649721936179E-35 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark15(-11.73960064975563,-0.12016699101150341,-927.8421313832679,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark15(-12.998199067753006,-1.2857169097384258,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark15(-13.032008894510097,-0.0026180824501459313,-100.0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark15(-13.18479849235211,-7.62332614868375E-14,59.03645913121835,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark15(-13.192168112983818,-0.0012700837754285746,0.0,2.385417527128351E-10 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark15(-13.420534472847251,-2.304092391371242,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark15(-14.794404255961638,-0.2437539671092953,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark15(-15.254806782090121,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark15(-15.29758862168029,-0.007110101614514974,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark15(-163.962135131297,-0.01577848461185527,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark15(-18.176447285483626,-1.30827891033094,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark15(-18.30412762777676,0.020162626098586465,0.0,-0.634338665799659 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark15(-18.751594755293528,-8.915820048603371E-12,0.0,-73.26872488270337 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark15(1.9084059726669267,0,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark15(-20.142590664272056,-0.002134928698631077,37.4335047695037,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark15(-21.209392354870843,-26.332714789333636,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark15(-22.73326557048717,-1.570796326794895,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark15(-2.2745955193190355,-0.3740032098403816,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark15(-2.3147946277859432,-79.74364439005335,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark15(-2.4240767936944843,7.001098359851462,-2.1684043449710089E-19,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark15(-25.52021929319651,-1.0310998386632263E-8,0.0,-0.9999999999999999 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark15(-27.321247778498716,-0.24433681272276148,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark15(-28.176923504503947,0.6578248614507486,-7.105427357601002E-15,-100.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark15(-28.251355602163567,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark15(-29.308634750699422,-1.3568418740629153E-5,70.70463303096454,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark15(-2.9841668815833042,-2.7333982821783074E-4,0.0,-0.48178159207536414 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark15(-30.07157157399429,-0.4490900992906416,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark15(-30.366686967091447,-0.21970349557784197,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark15(-30.43413330644404,18.429279938249607,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark15(-30.440459442787294,14.430448800973487,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark15(-30.50288914008746,-1.2205891964404471E-15,0.0,-0.40361090778468023 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark15(-33.67116856260761,14.429977050070327,1.0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark15(-34.44816039937061,-0.33671944576538826,0.0,-1.000000665091075 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark15(-36.72485992795744,-0.0012012024635263754,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark15(37.8094783849927,0,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark15(-37.94226090293928,-83.94287967305891,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark15(-38.01613404238611,-0.025924961105916973,8.881784197001252E-16,-0.9999999999999998 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark15(-38.523838674884615,-0.3823426818895249,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark15(-40.00875982498272,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark15(-41.53231676088569,-0.18896414327372213,0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark15(-42.29231689911088,0.10995918176782016,-1.9667159241491873E-4,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark15(-42.96865182362233,0,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark15(-43.43047341021289,-0.5002688305077116,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark15(-43.61855511779078,-0.8439436400226548,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark15(-44.60024244458841,-0.002582042393079457,11.27571882118592,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark15(-44.65900953798733,14.429208481441805,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark15(-44.9230756982802,-66.83442829743521,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark15(-47.08066338690422,-0.0018586296278731765,0.0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark15(-47.86279540510445,-0.11523076717807612,0,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark15(-48.87531085363487,-0.0026305006289138524,-1.2842060819956393E-18,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark15(-49.61947410131757,-0.020154778641227722,0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark15(-50.671130552640605,-0.3507734670203462,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark15(-50.99587476554278,-0.015856843986418047,34.10815629362028,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark15(-52.00878292783044,-0.04173182305383982,2205.6991941428764,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark15(-53.16942876180728,-18.977628489288634,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark15(-53.781978198360136,-2.583574626391985E-4,83.51546599142634,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark15(-54.94129804417659,-1.8839286539214907E-15,-2350.168405847995,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark15(-55.064288717178975,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark15(-55.857598345712,-35.97006223491728,0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark15(-56.17621896152238,6.4382890940265485,-48.7548411414241,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark15(-56.23874229180795,-0.0020154856595831555,0.0,64.32541277164111 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark15(-56.74370395967192,-2650.1563136305454,0,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark15(-5.709175907943262,-0.10592959415866318,1433.9600830916079,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark15(57.48669775807343,0,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark15(-58.58970539702835,-1.1102230246251565E-16,0.0,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark15(-60.72749067926116,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark15(-63.822745413581345,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark15(-67.42109576466797,-0.002629840638914266,0,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark15(-69.12196125541152,0.0,0,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark15(-7.255760925557467,-1.570796326794882,0,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark15(-7.3958349723404755,-0.016171363678330577,0.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark15(-75.51569719426104,0,0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark15(75.78873744916018,18.10264952908169,0,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark15(-75.81943133964722,-3.41191440670033E-9,0.0,0.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark15(-77.51137079820319,6.595657501103401,0.28963051301297493,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark15(-7.829000926450998,-0.0026298406388894787,0,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark15(-80.97278534156992,-0.0020663587725245477,100.0,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark15(8.207625204337205,0,0,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark15(-8.209711420971644,-0.1442883140461514,0,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark15(-82.80604721072243,-0.012115553710440112,1.0713894565425068,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark15(-82.8130171453813,-0.5044113212100854,0,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark15(-84.4139389005767,-6.301698936465456,0,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark15(-84.57370483202081,-0.00113109253298623,0.0,-1.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark15(-85.61598204751073,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark15(-85.72514428485513,-2583.516507900898,0,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark15(-86.6176805745469,0.2883117946151431,0.0,-326.59760879533405 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark15(-87.25871824510467,-0.008608514317022344,0.0,0.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark15(-87.57504062374528,-1.2124118418029184,0,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark15(-90.36578989167249,-0.0022185791361294355,0.0,-100.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark15(-90.53045201257684,-2.220446049250313E-16,0,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark15(-91.4518525011682,6.432133818215516,0,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark15(-97.20498296216233,-0.5707961643296976,0,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark15(-97.68320053464386,14.42939097892932,0.0,-1.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark15(-99.63053053343252,-0.01167523202934461,0,0 ) ;
  }
}
