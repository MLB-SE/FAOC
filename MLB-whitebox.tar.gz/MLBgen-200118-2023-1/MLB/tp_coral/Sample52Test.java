import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.00236265556267021,1.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.002528550481655012,69.4748172003444 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.00911369174989235,-1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.009120311227821025,-0.004475179059910193 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.021758440862881017,-1.0000005026020162 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.0329622111396084,-0.13303597123248456 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.04021022547711928,55.4225876899512 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.04321087931163605,-1.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.061790358643798456,1.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.06694632362736506,13.583563650224086 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.07707261595992528,-0.999999999999954 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.07759370381744124,-0.6725863388440159 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.08577682885218281,1.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.09436868855693724,3.7600828131067052 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.14774571406857184,-1.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.1515468687517723,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.15266901193981391,0.11338895515530178 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.1659471397322454,-0.4618736433928806 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.17821487150118953,-7.542299859627E-17 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.18415817421365066,31.588535792591628 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.19477300211982773,-21.328092744000685 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.20981492005194646,-37.60830443381944 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.21204183767506002,1.0000000000000002 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.23534322375414263,-1.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.2496566238548088,21.78283748631354 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.2733022428564662,1.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.2747692933682823,1.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.28119375459843354,96.07824992053557 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.28979049586905103,-78.58776262269166 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.3004696847722872,-1.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.30070207991677755,-93.74598276554838 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.3010177128039659,-1.000000000000007 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.30136148147605746,-1.0000000033423655 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.317423162383065,27.264091209733124 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.317877868556435,1.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.349350750950141,1.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.4893105792840851,-1.0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.4903981286137098,92.08546094471609 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5049187990814391,1.1619882601483469 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5125189627480456,69.66334702879882 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5139593691023662,-1.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.526037507694154,-31.060544262029897 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5740421371215069,1.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5837973219456605,50.12623307257951 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5857551142303933,1.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5914252540710994,-1.0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6063124693150811,-2192.1220821570687 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6080303057500711,0.019498814645405392 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6282051407434578,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6294081188485683,-0.3621254755153767 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6537543190341563,-59.86070040840419 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6598118951638876,-44.05343370544775 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.693396433851894,-38.09346185594098 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.754648258871434,0.9978631804846687 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.7584882799250119,-48.86903520958255 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.7745644539074397,2.2227587494850775E-162 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.7779986561203913,20.330026558611298 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.7798664770278748,0.007339475296999742 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.7993543479365319,-1.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.8115807211576794,-0.9999999999999982 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.8555395384189151,62.9265373945497 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.86831856658253,100.0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.8854800673552368,0.930665654471059 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.8919255955646399,-1.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.907341745404652,-84.99866066933743 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9132429686677833,1.0000000000707248 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9141033905039846,0.025135452840527664 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9643278641938108,-1.0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0099526119815538,1.0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0415246530758087E-7,-0.999999999972618 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0494224453674308,-42.073078774663706 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0589785671638334,-19.648712623757337 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.1390767996174205,47.52534090799527 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.1673179271373122,-91.3822563724667 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.1938283409343857,-0.06255252523161041 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.2079647087380292,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.223335988494721,0.9868258528982733 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.2237674933596198E-4,-0.029513244735825214 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.2279503725490886,0.9275749014598365 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.2555799911463326,-1.0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.2629334340181493,-0.06082848173725866 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.2747190027955893,0.03362682796627314 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.2881882424041409,1.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.2969416842402584,-1.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3148851121912668,-2333.3935331070934 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.349601740300426,-1.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3661393576073946,-1.0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3810626627607743,-75.86914850554345 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark52(0,-0.13956003993193455,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4038924923882672,0.688377209671919 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.410222429359492,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4287354006034516,-0.9999999999999947 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4388718786190857,8.470329472543003E-22 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.439930538934686,-2.5026038689788762E-147 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.447613194781831,0.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4572138240361678,-97.65998878888868 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4601503841620505,0.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4611214549495404,0.9999999999999999 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4715289653405499,-52.62116971791193 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4736122091912671,-0.75670062944982 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark52(-0.014818252049600114,-0.0024791552057343846,-1.4502862247992099 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4894711822639797,0.9415587092335369 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.494303431397095,-0.9999999999999991 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4959239614992557,6.935552230127243E-17 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4973696579412819,0.0625529762228339 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4989176531962123,1.0871832636107758E-16 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4990107692187753,1.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4994116651855653,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.499720122879882,-1.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999890448251,-0.6901680270930073 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.499998340019462,-0.9999999999999977 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999996508555,1510.73629375375 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999607008,0.485605917948672 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999993125,-1.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999997606,1.0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.499999999999995,5.551115123125783E-17 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999964,-9.847550128344082 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999982,-0.9390635417281428 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999991,-0.0882639585776106 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999991,2356.829422850105 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999996,0.8139966878844813 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.7763568394002505E-15,0.7256372165952436 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.7763568394002505E-15,0.999999999999965 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.830564887700981E-4,-3.06248888343303E-8 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark52(0,-0.2025907349612055,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-2.2473011739412907E-18,1.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-2.7755575615628914E-17,1.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-3.409915766259544E-254,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-3.552713678800501E-15,1.0378039029390458 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-4.440892098500626E-16,0.4935876389344165 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-4.440892098500626E-16,-29.151951541546016 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-4.910375685894975E-15,0.9999999999999908 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark52(0,-0.6316590236730324,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark52(0,-0.6583305464579041,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark52(0.06860150189637082,-1.494891727567667,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark52(0.07788556731470944,-1.2193708798345475,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark52(0.07843368746665647,-0.02884390500008749,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark52(0.08798573514171881,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-8.881784197001252E-16,-0.05580834497179521 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark52(0.09529167753628452,-0.4858621672735097,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.0178763728185038,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark52(0.10720912607502978,-1.4999999996944873,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.175979092949372,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark52(0,1.5531385713532503E-18,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark52(0.16094145084018763,-0.14171268409114934,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark52(0.17315241117952063,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark52(0.17880953592943527,-0.18290854598617917,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark52(0.18176904804790528,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark52(0,-18.834355243071755,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark52(0.20731678134056253,-1.0955292887019112,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark52(0,-2.0E-323,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark52(0,-2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark52(0.25694624707965785,-6.552372086129459E-9,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark52(0.2610195300592473,-0.6889515154013224,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark52(-0.2638279606633649,-1.4999999999999982,-0.02138806668186284 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark52(0.26488734140517023,-0.4194074864214805,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark52(0,-2649.465764678102,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark52(0,-2721.655428744187,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark52(0.2772729599162247,-6.74975470150125E-9,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark52(0.2781309679494974,-1.2083668177613576,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark52(-0.2846051884603915,-1.1102298820465817,-69.18005594772424 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark52(0.30609447744276963,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark52(0.32392205528198303,-0.14842288427581463,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark52(0.3364916038809924,-0.4487676720611491,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark52(0.3454963256433281,-0.07692504191993521,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark52(0.3528843209497552,-0.3455937082752456,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark52(0,3.721603633980621,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark52(0.3853924721748996,-0.16679783348050137,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark52(0.40535122648447963,-0.45322400161520315,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark52(0.4182217793515548,-1.3461061927288824,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark52(0.42012544622522663,-0.21215663960688658,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark52(0,-4.244273234705176,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark52(0.43450555338043273,-0.25654900211433485,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark52(0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark52(0.46627527950569103,-0.7920870991981559,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark52(0,-4.676340597720568,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark52(0.47360292153042893,-0.5532249627274552,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark52(0.485550070381251,-0.6182187269930779,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark52(0.5045352714450075,-0.5144173474200358,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark52(0.5076896275890643,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark52(-0.5108435703468023,-1.4999976172571863,-1.000000527698039 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark52(0.5257076382520864,-1.3559136270729892,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark52(0.559897639880802,-1.2726342060652058,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark52(0.5656581337701709,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark52(0,-58.200095640439976,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark52(0.598019570663498,-0.21594378005183046,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark52(0.6066609821403688,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark52(0,-62.10353368424653,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark52(0,-63.99692636151797,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark52(0.6551825981271626,-4.404678070090913E-9,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark52(0.6569909898142148,-7.254772784764705E-10,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark52(0.6805556645195878,-1.0149017361396313,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark52(0.6827949759311025,-1.478455773936233,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark52(0.6933496567020008,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark52(0.7036132279299068,-0.47683168434183654,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark52(0,-72.8629266757918,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark52(0.7321393135893075,-1.49999807467517,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark52(0,-73.62620195509575,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark52(0.7446594335799191,-1.246820623299321,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark52(0.7518733316368588,-0.6706207155346426,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark52(0,-76.3074810481374,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark52(0.7943149959480422,-0.5080632071448394,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark52(0.794454791960348,-0.0758283527984176,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark52(0.7980292850525075,-0.6632454246020956,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark52(0,82.02387330620914,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark52(0,-83.59591320733797,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark52(0.8382142637315053,-0.8251559883798871,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark52(0.8770423599880388,-1.0244108974425887,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark52(0.8815397503757083,-1.3578218941431395,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark52(0,88.24883635970059,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark52(0.8944353547720155,-0.7364825733010916,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark52(0.9289183258779663,-0.9161542469395854,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark52(0.9788258844502451,-1.4719132615273822,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark52(0.9931929161937063,-0.9360142618056362,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.010651245788249684,1.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.017602417143671313,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.021156482882935035,75.40572192053361 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.029838473010115774,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.03114248968586253,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.041013786619675585,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.05327365939941986,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.06035473808573448,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.07391998841236534,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.0814793092828414,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.08184785875310086,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.11965050002203448,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.13195421075662317,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.13615814742988075,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.14506766249824476,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.14981817825180932,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.15324983204359838,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.16474698020759052,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.17656510693395855,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.1988348765232284,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.21162464890062527,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2517087345393483,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.25537368934146326,0.3306184487073114 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2556520771804678,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.26741177843565034,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.27470798919862854,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.28514469073638715,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2893614205712651,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2974091855449217,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2985727005819825,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.319154836010785,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.32120202791397934,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.34083869099396136,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.3441227269006644,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.36486385019694567,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.36578669780723655,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.38258256188353057,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.3840854765139404,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.40270330144244293,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.4066740986877639,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.41960559410947473,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.44922831814181263,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.46056244725399154,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.4675300402395486,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.4782313118683692,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.517757393013575,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.5275940696159154,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.5598223146162921,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.5939654101553128,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.5985207576746274,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6198182759600868,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6244159924920912,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6248377545753798,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6273918945268417,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6376822035543773,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.6469650813455575,-0.05210095905271672 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.657088984235128,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6634097370195291,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.7234860910082709,0.037812868709133224 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7378862567462434,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7407871119328526,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7533688521750616,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7551032185668305,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7596273179581046,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7674679903836491,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7851995100425713,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.8082676479085851,0.04215406526734623 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.8487865076900127,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9160041460803232,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9190083995429488,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9428395170347895,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9471282386636141,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9575574736935486,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.974058701442678,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9761095672452598,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9967091613519012,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0132811662394555E-15,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0171202696588608,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0276419671963168,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0472418169490592,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0546912940209783,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.06805999882121,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0694667272776357,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0919599293045712,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1063925137651451,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1142299020441357,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.117868970701098,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.119695701882315E-6,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1213666998522096,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1472701242629024,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1559522992934426,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1662164489133071,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1721616098069576,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1723933325838192,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1858731017457956E-9,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.187464129501942,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1970697623497117,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1974252070296796,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.2823063531483214,-0.36208927214567166 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.2863062029371273,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.3060936470984306E-4,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.3226844363306793E-6,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.346406368737323,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.3710969049765875,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.3777045364673886,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4012823034260877E-15,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.417163702669296E-16,0.6724425418353308 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4193616512348113,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4332742194488246,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.4897233091391795,-1.0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4961023181477622,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.4995719387879456,92.41036849823156 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999995912705,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999998674634,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999886673,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.499999999999985,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.4999999999999982,-1.499696813895631E-241 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.4999999999999998,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.8251455195359812E-9,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.121803796185184E-8,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.2978838877335943E-9,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-2.5574209138099447E-7,81.40797260893727 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.997771800205747E-8,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-3.016496515252675E-8,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-3.949510809491555E-9,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-4.209453032558289E-5,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-4.266551670736657E-9,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-4.7304806948129794E-7,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-5.083245139040401E-10,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-5.0995902466235095E-8,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-5.262403681143532E-8,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-5.473839089747484E-10,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-5.569554595043441E-10,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-6.785020697093777E-5,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-7.078182911840254E-10,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-7.255437026032586E-10,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-8.94396693862104E-17,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark52(10.039111496125656,-1.4861782229112692,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark52(10.040378657608734,-0.5462410543099145,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark52(1.0075508699181057,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark52(10.07989454071543,-0.31938581486889994,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark52(10.094722286026297,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark52(10.100876255330633,-0.5895499069773606,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark52(10.101849994263455,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark52(10.104782425672132,-0.037876130549395315,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark52(10.119171850898056,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark52(10.170509237851611,-0.7554977238223874,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark52(10.17937273410385,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark52(10.207721778249422,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark52(10.232256902118657,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark52(10.2513547082349,-0.5124080740383903,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark52(10.2733244582097,-0.6104850914437892,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark52(10.420322631052414,-0.10131044487452012,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark52(10.421934648499587,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark52(10.467493395426473,-1.0846804635196816,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark52(10.476391559311196,-1.3437451517531005,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark52(10.480716698115316,-1.3098723255089226E-6,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark52(10.482296321300154,-1.4277194467195073,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark52(10.511752067218623,-1.1907311435475996,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark52(10.545530004765325,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark52(10.61720768312459,-0.2726570432075093,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark52(10.63500345297193,-0.8842843620593355,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark52(10.637495029172257,-1.1002270191562449,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark52(1.0640036107588742,-0.12068754254450331,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark52(10.662929992642677,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark52(10.70649568188351,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark52(10.727901599517104,-1.4999999996210405,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark52(10.735404200171915,-1.3805834507609782,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark52(-10.831746454082223,-2.6061798112078998E-11,0.26012817478127437 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark52(-1.0842021724855044E-19,-1.2536876309277987,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark52(10.84535228552663,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark52(10.845965160008724,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark52(10.857731264823512,-0.5398161820918778,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark52(10.858225174342891,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark52(10.876079527909416,-8.713520205437025E-5,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark52(1.0900324081075894,-0.002352400135665178,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark52(10.915893307768503,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark52(10.930025715411034,-1.129994272727446,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark52(10.989424891693096,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark52(11.046154984468833,-1.0480905436481385,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark52(11.118903394803127,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark52(11.1235164927958,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark52(11.135098773995807,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark52(11.149572410531412,-4.246364682038381E-9,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark52(11.151358922970857,-0.8976928431437612,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark52(11.154480619754262,-0.284313577823994,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark52(11.160429239512638,-1.4999999999999916,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark52(11.173754778654214,-1.1544107834147543,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark52(11.253164878757602,-0.6500319387189535,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark52(11.337937682099446,-0.22688953692962976,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark52(11.374475626248426,-0.462997207535783,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark52(11.387405645027584,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark52(1.1387515029416976E-16,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark52(1.1426400653587132,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark52(11.427005916429238,-0.09310657719485338,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark52(1.1451921531917297,-1.2073846459678492,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark52(11.478047001138897,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark52(11.483698205270883,-0.5792410938151704,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark52(11.513675919282084,-0.10577274608280043,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark52(1.1514886097950905,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark52(-11.520432517616772,-0.3829251128581796,-17.328065764438982 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark52(11.536816447636927,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark52(11.54239279265911,-0.040847509747227395,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark52(11.554560061124835,-0.41247045414555816,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark52(11.57266078820551,-0.7021273570116519,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark52(115.75166038569535,-0.6777943999271656,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark52(11.583426361442019,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark52(-11.584411352182514,75.74853837551484,-46.573660933821934 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark52(11.59586476653801,-1.4999999996760929,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark52(11.596012946693747,-0.5100081747461994,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark52(11.597962462307095,-0.14494385945852617,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark52(1.1650494248277425,-0.9131094209388748,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark52(11.721206397754074,-0.6241991046133142,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark52(11.748611215302262,-1.1958979706277433,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark52(11.776072365494144,-0.021111236408273726,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark52(11.776407629536001,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark52(11.829405158261963,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark52(1.1836039180366562,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark52(1.1860551001797432,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark52(11.864588470328256,-0.08903886013297399,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark52(11.873105294460364,-0.03701370582103758,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark52(11.95378701281031,-0.08956139485331338,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark52(11.983364337516974,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark52(12.013122530338341,-0.48172995033929056,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark52(1.201838463540426,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark52(12.055349072074335,-0.2438135311651699,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark52(12.082035960660356,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark52(12.149642416913892,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark52(12.15826262375117,-0.3975219069660363,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark52(12.168400788832958,-0.1116380983318454,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark52(12.236250353926351,-0.7679343864611823,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark52(12.260463157166669,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark52(12.270047474606834,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark52(12.31828435509253,-0.07146436102871756,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark52(12.323332665124274,-0.5272309889138427,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark52(12.340547004923977,-1.335547580040433,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark52(1.2368318753301537,-0.559826658198542,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark52(12.408969818075917,-1.134124037499563,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark52(12.410979176936706,-0.7897818208494272,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark52(12.415896454166216,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark52(12.44376402609592,-0.30021087302047533,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark52(12.443978832878202,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark52(12.464620863151453,-0.31611843870755507,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark52(12.484287499196725,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark52(12.55057360362212,-3.358393221028167E-8,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark52(12.58197009833918,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark52(12.600788602807238,-1.4999999920347038,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark52(12.61149443681353,-1.3074967290084167,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark52(12.663104841671611,-1.3374643897438139,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark52(12.668432918151822,-0.24492201992132223,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark52(12.67507913859609,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark52(12.705871773541716,-0.506090508481023,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark52(12.769236826155066,-0.6994703095481327,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark52(12.773863952984502,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark52(12.789971688326855,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark52(12.797020791944774,-5.164073852886398E-9,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark52(-12.818211681547595,-1.4999999999999982,70.93750290654 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark52(12.828001503161659,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark52(12.836328155464628,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark52(12.87163292184961,-0.05438676114136276,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark52(12.894912433838002,-1.219979991428815,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark52(12.909839349105127,-0.7792943612962233,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark52(12.933273156439526,-1.49999999991838,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark52(12.934811517840132,-0.419372834942247,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark52(1.295089764611463,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark52(12.957975519986007,-1.0093227359037726,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark52(13.013038774336778,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark52(13.014369879791317,-0.29069149468450206,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark52(1.3016397655106289,-1.279087012899268,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark52(1.3020255270175198,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark52(1.305084325839001,-9.770416937537013E-9,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark52(13.104925593739093,-0.25969931976751637,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark52(13.21472081492919,-0.14628028834289353,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark52(13.221140769909535,-1.4976934391374946E-5,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark52(13.223255542856833,-0.509412631418305,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark52(1.3239489571261913,-0.6104746514916854,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark52(13.243348900427023,-0.6065675385189024,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark52(1.3259206164443214,-0.5324219434797821,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark52(13.262129906926319,-0.35473803316431185,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark52(13.30211830433437,-7.70251073064106E-16,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark52(-13.311684690705642,-1.4278639417249015,1.0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark52(13.330963500526622,-1.0728267949003225,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark52(13.363549288552278,-0.8072645457973961,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark52(-13.388705867890693,-0.038060782923508896,1.0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark52(13.436898174372658,-0.06550993152589907,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark52(13.462463260694081,-0.05150910316629834,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark52(13.54386151369601,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark52(1.3552527156068805E-20,-0.03627573434838603,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark52(13.63485898774745,-0.2393309623977018,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark52(13.643813258480124,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark52(13.644145469240016,-1.4977014853283919,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark52(13.687551897961441,-0.8581896544357925,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark52(13.77417470231164,-0.6348241375145172,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark52(13.796274519336492,-0.9756133548651215,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark52(13.801273725754442,-1.2290188438182614,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark52(13.803716434498796,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark52(13.837588816607166,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark52(1.3868666194545831,-0.7130851479573153,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark52(-1.3877787807814457E-17,-1.4730789938021374,1.0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark52(-1.3877787807814457E-17,6.369043754681318E-17,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark52(13.904189774583358,-0.8556449146375467,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark52(-13.940865514812174,-0.7490399462697165,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark52(13.961922321283438,-0.9288437308097457,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark52(14.047800268765016,-0.6953917882328725,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark52(14.061531923196405,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark52(14.085658106879634,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark52(14.117530628486598,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark52(-14.133682424011742,-0.5632550191813203,6.434446986835036E-86 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark52(1.4182315719093381,-0.3455905059681337,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark52(14.185887250562823,-0.18883507624324636,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark52(14.187764995165836,-0.8205559091465204,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark52(1.4210854715202004E-14,-1.0758136853620055,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark52(14.22051544590937,-0.44640862672990167,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark52(14.227725064878882,-0.2699222780443642,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark52(14.282242783402467,-0.031473244329662975,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark52(14.329695985106945,-1.8917504891171616E-7,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark52(14.387826017118293,-0.8108224711503276,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark52(14.432040647950387,-0.2627758050589897,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark52(14.437967263930329,-1.4999999998389428,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark52(14.498949547785603,-1.4518568305556738,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark52(1.4591329536287816,-1.1171676565116901,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark52(14.606867305295836,-0.2267969935702545,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark52(14.62180109204644,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark52(1.463361261179502,-0.39923499318618383,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark52(14.687426344728564,-0.10156752510089184,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark52(-14.736669612792852,-0.026680533305151966,0.9093610099937678 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark52(1.4740544066956147,-0.34837073051160417,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark52(14.750890745244334,-0.07134145681513271,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark52(14.784380425099357,-1.1515157756445893,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark52(14.806108578977287,-0.8540322712935051,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark52(-14.824191479114443,-1.4999999999999982,1.0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark52(14.82972451540327,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark52(1.490326632501359,-1.497291603902259E-9,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark52(1.4949330182136773,-0.09196674593371768,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark52(14.96070054942922,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark52(1.4963281287286634,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark52(14.980746743539868,81.17050554598842,-63.13169120033058 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark52(14.999306090110682,-0.622444636572892,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark52(15.02189711992304,-0.9793196609188304,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark52(15.030851282833805,-0.13009541930729887,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark52(15.040272444880685,-0.9832322218873202,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark52(15.040764004843354,-1.3542811778250154,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark52(15.108037502001194,-2.6188075573647186E-9,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark52(15.127856820118453,-0.3461222601414742,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark52(15.137879722688,-1.4562885222972108,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark52(-15.156934564364844,-0.18273856206148587,-0.8163775723513873 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark52(15.208343670166443,-0.44574231421906774,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark52(15.212993475563664,-1.4964579204065707,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark52(15.217310888470976,-1.109835849285958,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark52(15.223169120678762,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark52(15.236423523389206,-0.2587617823295716,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark52(15.262934752728,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark52(1.5273298768988042,-1.2809480187651228,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark52(15.333676204948588,-1.3639783968155683,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark52(15.343164883600808,-0.1421111023708037,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark52(15.347592394845655,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark52(15.348175780505713,-0.48883383079366116,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark52(15.351185756432104,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark52(15.365052485759538,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark52(15.39033616678347,-0.0035367514592707927,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark52(15.408939130349793,-1.107060494417344,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark52(15.432125124512552,-1.4999999999999942,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark52(15.433060596190911,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark52(15.444842295654169,-1.1315131835932202,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark52(15.476879247063808,-0.5642869394876175,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark52(-15.500237844043724,-0.0012853924084202494,-79.59780181825886 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark52(15.519447379706156,-1.4999999998420368,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark52(15.564618051271339,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark52(15.585698789863912,-1.1276533309372927,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark52(15.601009046680673,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark52(15.63177469007331,-0.007772165603082881,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark52(15.633498582689114,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark52(15.717544770574838,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark52(15.719982390803409,-1.3396048494847974,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark52(15.777736723940805,-1.0313124304052366,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark52(15.782126994512293,-0.3099263842915896,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark52(1.5786839332921618,-0.03286800561720563,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark52(1.5788570645680338,-0.31612395249247727,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark52(15.801595925501275,-1.4598472656641528,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark52(1.5804757894050012,-1.4836359562679002,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark52(15.818881390561724,-1.3226881278015838,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark52(15.85230174011997,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark52(15.86818635482885,-0.6518246797233926,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark52(15.87564236654731,-1.476957614722096,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark52(15.892800658601487,-0.6971257730875906,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark52(15.913137916342095,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark52(15.92996286293112,-0.8747125785460406,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark52(15.931718746005654,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark52(15.934011097805858,-0.014297490832529647,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark52(15.950819898697887,-0.603973958111979,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark52(15.955623299539482,-1.4246652961734707,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark52(15.96889704515803,-0.025049485100162583,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark52(15.9996908077092,-69.63768314353081,-51.185144341944145 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark52(16.01713020096473,-1.0630440413973186,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark52(16.038722825540223,-0.2039350985571191,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark52(16.056711576901385,-0.5432306428949687,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark52(16.103422603627447,-0.8050535009432493,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark52(1.6167277207853346,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark52(16.178798986234675,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark52(16.241166440112337,-0.4641730737505583,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark52(16.24979820171289,-0.6486215386436008,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark52(16.260711491238983,-0.9359544174649541,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark52(16.31918970727741,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark52(16.33696011978236,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark52(16.38182270100124,-1.4209093759049964,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark52(16.388302159476567,-1.348764781797926,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark52(16.43854069972105,-7.67643139407384E-5,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark52(16.47474135176935,-0.022619028901844307,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark52(16.499151949329132,-1.2069023870406426,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark52(16.52077370137681,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark52(1.6536131071624178,-3.5661441315883314E-9,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark52(1.6560770408136323,-1.4552172225803699E-6,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark52(16.57566403474374,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark52(16.583263429825877,-1.0105720695473626,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark52(16.60121694366903,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark52(16.621543869116433,-0.009035658476942446,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark52(16.676058717691575,-1.4803251442522631,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark52(16.683374234729314,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark52(16.709348658429988,-0.747129704003811,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark52(16.71608765164943,-1.169624651573475,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark52(16.77269083867914,-0.3171374669207978,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark52(16.77699204319461,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark52(16.79549095953365,-0.5415232032022803,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark52(-1.6810581277136123,-59.721100311143594,-59.36159219912833 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark52(16.883750160037717,-1.4999527619256958,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark52(16.891561543500643,-0.7992100703045115,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark52(16.93079048061567,-0.5889146817705324,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark52(17.003042561374542,-0.8228515515145123,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark52(17.018824185769503,-1.499999999999993,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark52(17.024172923747354,-1.0567494910741273,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark52(17.043615561928434,-1.3187443026835965,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark52(17.046776836859536,-0.13829906982186202,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark52(17.08090608269538,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark52(17.088740196274358,-0.7735060873103459,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark52(17.0928512142076,-1.3427071643785493,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark52(17.12444751147173,-2.9057470363531657E-9,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark52(17.18955387667907,-0.7249220873336126,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark52(17.200071259761188,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark52(17.214227451411674,-1.3292983493119996,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark52(-17.270447103192318,-0.8670834293766583,71.18843278766131 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark52(17.272315272626088,-0.06988919107265075,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark52(17.285116340297876,-0.3124554037939724,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark52(17.292197551942508,-0.5597792015613612,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark52(17.297286085836937,-0.25308208912428665,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark52(17.30377287384961,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark52(17.306176622691577,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark52(17.319410540681023,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark52(17.338500590218544,-0.0012707181140732102,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark52(-1.736397636671711,-0.9824173053933813,-1.0000000000000018 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark52(-17.37088939539553,-1.4912163743139195,2347.669457157221 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark52(17.374587657483897,-2.2111691122157294E-6,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark52(17.42308357553972,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark52(17.43791616552917,-1.1153228859382913,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark52(17.44645416958228,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark52(17.454718233602094,-0.7705293439409502,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark52(17.461470649112087,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark52(17.508497741345415,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark52(17.52364516881007,-1.3153560075753261,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark52(17.530913126713088,-1.4922355123203772,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark52(17.611008981381403,-1.0871405914069072,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark52(17.70560167732094,-0.002656588219580449,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark52(17.724397379395995,-0.012231213813393538,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark52(17.725812237594855,-0.13247874624330103,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark52(17.759774330358415,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark52(1.7763568394002505E-15,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark52(1.7763568394002505E-15,-2.220446049250313E-16,55.505458278774 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark52(17.780700015126506,-0.028937923844606306,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark52(-1.7787291870034767,-1.4495328477964557,-0.909664612680259 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark52(17.7968958421513,-3.809645098581352E-8,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark52(17.82976640385081,-7.764742981409796E-7,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark52(17.83769831119932,-0.2139943523697525,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark52(1.7845191897086945,-1.429653160361454,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark52(17.855974102040207,-1.4874834453385866,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark52(1.786628986160025,-1.442235001423768,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark52(17.874543122412078,-1.4942273302010909,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark52(17.89409127981812,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark52(17.900577215681963,-0.896856591227845,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark52(17.909802259919626,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark52(17.915281639099945,-0.7912298839638083,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark52(17.987406489256202,-1.323778579580916,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark52(18.0023766297265,-1.2322778452370988,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark52(18.00843707383288,-0.24351597400062985,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark52(-18.01622146689731,-1.432153086278092,-1.0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark52(18.017357844023536,-0.014505813566245468,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark52(18.018328149169626,-1.0943426225231887,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark52(18.03864086549315,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark52(18.092446501661158,-0.9437432266373206,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark52(18.10442821601923,-0.4950186324925031,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark52(18.190249099752066,-1.2348749306377869,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark52(18.206738715800498,-0.9073311676946645,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark52(18.20743839202629,-0.554490823481093,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark52(18.22294016485891,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark52(18.246815069656492,-1.228472620495376,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark52(-18.30268208488461,-0.5411266832685344,-0.9999999999999929 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark52(18.310115706875145,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark52(18.330494737182335,-1.0220154579199425,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark52(18.361709481711003,-0.609128331246346,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark52(18.374745091731853,-1.2385522711367831,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark52(18.4031568475892,-1.0467340398361102,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark52(18.415956855345556,-1.0894730164354574,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark52(18.426676229968166,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark52(18.431925869199603,-1.2442268035677877,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark52(18.4465692755831,-0.2202869243596357,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark52(1.8484628867692505,-0.39675209007576256,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark52(18.50064771915187,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark52(1.8528243161443754,-0.047396079967577665,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark52(18.53474876594477,-1.4197427929919115,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark52(18.53732122597419,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark52(1.8604193879876227,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark52(18.612488465543663,-1.3177736578311943,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark52(18.61875200514241,-1.499999999902601,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark52(1.8643353865027947,-1.2216106510469018,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark52(18.661941961025846,-0.07722095361085568,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark52(1.8692440363725211,-0.19727556291440607,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark52(18.704419526991245,-0.44032982370515983,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark52(18.72937775964691,-0.8257037890474379,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark52(1.8731629251504849,-0.7927160145884853,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark52(1.87556895045727E-15,-0.38942616691982956,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark52(18.761302659702547,-7.261138594526634E-10,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark52(1.8779215540530174,-0.49721716014352657,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark52(18.886681445947147,-0.7561537234375066,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark52(18.889936367809028,-0.0288105514201347,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark52(18.895040734397153,-1.679276406611158E-16,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark52(18.927305642889166,-1.4340483409836446,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark52(18.93298520664159,-0.08451136176260698,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark52(18.953290271659455,-1.3529990050276848,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark52(18.954492127037696,-0.19453075062403435,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark52(18.99960966976713,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark52(19.00317406605657,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark52(19.127152315525038,-0.9872119361863838,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark52(19.163775142153128,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark52(1.9196207214106806,-0.32694277089723534,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark52(19.200603855107595,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark52(19.20801421698738,-0.10285591949740791,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark52(19.2262206129485,-1.4645187407729288,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark52(19.230264806281184,-1.3659285048819072,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark52(19.2538070995778,-0.39344804290757107,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark52(19.302275346863077,-0.01871166956624144,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark52(19.306359576850156,-0.5929935185541666,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark52(19.355954869020437,-1.3577806570823254,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark52(19.39572611924912,-0.7252717313102579,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark52(19.399205293562904,-0.005552077068147199,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark52(19.425359110948584,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark52(19.42929290136076,-0.08126664454582144,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark52(19.46356436510227,-0.6477734050705803,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark52(1.9502886659312155,-1.0672178259813219,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark52(19.545277905054064,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark52(19.55025084759214,-0.09769635518138092,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark52(19.57408959876659,-6.651336161836657E-9,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark52(19.60197161533261,-2.426048714331413E-8,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark52(19.655470706198148,-0.8288227410309439,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark52(-1.9659508762641327,-0.1104554859792088,-0.32242555474220613 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark52(19.65953935705012,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark52(-19.672746768234635,-1.484352994416869,1.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark52(19.677064051824914,-0.7716480056423114,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark52(19.691926775664136,-0.27911851313275804,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark52(19.712951047551748,-1.173946472929642,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark52(19.814981247540672,-0.3178193149544364,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark52(19.844928609641503,-0.965565596354967,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark52(19.86421168875321,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark52(19.885961829709302,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark52(19.88971236126195,-0.27756740199644936,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark52(19.944937177653063,-2.363148926670519E-5,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark52(19.958644311184273,-0.015122622163556077,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark52(19.977663467900072,-0.3302352596368311,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark52(19.991443459474418,-4.258835570266427E-9,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark52(20.004290824827315,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark52(20.023817402683775,-1.4323841623873756,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark52(20.031566026360622,-0.9572468709605744,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark52(20.064268184881367,-1.1978176699601544,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark52(20.07452448097417,-0.40842904398049806,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark52(20.10401316120523,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark52(20.169121356793653,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark52(20.20443245231362,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark52(2.0259478735151357,-1.0380301030253853,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark52(20.323315861580998,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark52(20.411561562088025,-7.415823674330027E-10,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark52(20.435038242605202,-0.28959892994757896,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark52(20.506946791118352,-0.13626715180451288,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark52(20.528996059121205,-0.586625679628006,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark52(20.549441168024217,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark52(20.57275341888892,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark52(20.587744824653164,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark52(20.592600058026335,-1.4999999995752011,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark52(20.598425744834614,-1.4029597760612436,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark52(20.628576434977703,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark52(20.629600082267928,-0.5271338356410311,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark52(2.0661297377629637,-1.3311801625430888,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark52(20.663679199599244,-1.0332126939159134,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark52(2.0677591446372396,-1.0715968241959786,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark52(20.679420759336736,-0.5553933268753242,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark52(20.701911548316684,-2.837791694871332E-9,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark52(20.734874312108392,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark52(20.76557459967627,-1.0569258011953195,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark52(20.7759784253614,-0.470464133118656,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark52(20.83583541141423,-0.7777468221147803,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark52(20.84544855181339,-1.4999999999322717,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark52(20.847822063595117,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark52(20.86743375539932,-0.8365442142385183,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark52(20.875115243631797,-0.21101509603973478,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark52(20.89548444152359,-0.9420974040496937,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark52(-2.089971865754239,-0.5603958749090407,1.0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark52(20.929951778675274,-1.4654877997392646,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark52(20.933684130538126,-1.260154670290846,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark52(20.935751705710803,-0.9405932234280273,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark52(20.95712152290002,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark52(21.00157074483799,-1.367145385074581,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark52(2.1008500878515264,-0.6250615876152654,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark52(21.00931837235147,-1.356357480467118,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark52(21.019515374039972,-1.0875507844388286,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark52(21.024413263436912,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark52(21.028897925395796,-0.7119058541008414,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark52(21.043295361485896,-1.4769701700012834,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark52(21.05479799272078,-0.16550113127643185,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark52(21.087105964524795,-0.4898123309651359,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark52(2.1123849200276785,-0.45500513920669405,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark52(21.202984874571968,-0.3512068401844508,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark52(21.25585571691044,-0.37927744062517377,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark52(21.26365539285264,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark52(21.2810108619897,-0.8725106040937707,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark52(21.287559481797114,-0.21409573361657408,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark52(21.32621764505656,-0.9627740043874526,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark52(21.330867820132614,-1.1139315658721789E-15,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark52(21.372074875966618,-0.12700536347294133,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark52(21.374425108802065,-0.12378071261124901,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark52(21.4430815139874,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark52(21.46349309148505,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark52(21.47627088947199,-0.03820090767844153,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark52(21.476951307890833,-0.8706509249255515,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark52(21.508490921141828,-1.294127503238401,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark52(21.55146049269196,-0.2487066971527856,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark52(21.613592405904058,-0.9504821777397865,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark52(2.163365013747633,-0.4313239198546095,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark52(2.1642452510678822,-0.21830238381509415,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark52(21.64915132478427,-0.05107852955031322,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark52(21.650777561225425,-0.2953118547808158,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark52(2.1676413605689993,-1.589319344718204E-7,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark52(21.682928563634402,-1.2681665217136242,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark52(-21.696249436170216,-3.894100308436356E-5,-44.22754279874434 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark52(21.70168808069877,-0.7319788511048865,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark52(21.73290957469615,-0.15811964748485785,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark52(21.781648814954764,-0.40854116825292675,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark52(21.786246069672906,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark52(21.828116143565715,-4.703284284889095E-6,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark52(21.860458135837675,-1.260425606640327,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark52(21.867501372263117,-0.03650483865804517,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark52(21.88530318265947,-1.2234974252170217,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark52(21.890061006098804,-0.45491119176463624,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark52(21.91154413639102,-2.4324796633250485E-9,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark52(21.91234326693902,-1.499999999969637,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark52(21.964763903114616,-0.3209901864100484,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark52(21.981280957527048,-0.33095989550058924,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark52(21.981827337147774,-1.0612463199005364,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark52(21.98645958482301,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark52(2.1992184940062884,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark52(22.015868313066115,-2.421837753853869E-9,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark52(2.2069437159368768,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark52(22.08596187337556,-1.4451372794514659,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark52(22.102047050372796,-5.320643044513526E-4,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark52(22.117908420098566,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark52(2.2135384122934667,-7.528037887523425E-6,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark52(22.15472432479301,-1.5595677758038412E-6,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark52(22.161848747127117,-0.21689718068997088,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark52(22.16350928047686,-0.8276999248320418,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark52(22.183152303210893,-1.1912939334193937,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark52(2.220446049250313E-16,-0.7862339013431177,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark52(22.217679869513688,-0.25154332352685516,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark52(22.259012986502455,-1.428658303520539,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark52(22.302599707693773,-0.13219855569852257,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark52(22.324199993706635,-1.6378105366604658E-6,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark52(22.324505516995586,-0.22797214413407385,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark52(22.37757724982987,-1.0923079303847807,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark52(22.400321314561396,-0.3695349571336404,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark52(2.2423981541785905,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark52(22.48778768330331,-1.2059103233949564,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark52(22.492635687176303,-0.2728589241043473,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark52(22.493237735720967,-0.9703884125856774,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark52(22.501480345036555,-1.0258707897292823,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark52(22.52368066336345,-0.8222312635916742,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark52(22.52730489688248,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark52(2.253079820399056,-1.0725332637016578,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark52(22.58803368578723,-0.38333121919618107,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark52(2.260174601930288,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark52(22.61174915357164,-9.29926604144442E-10,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark52(-22.701969612304637,-1.4999999999999991,-1.0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark52(22.714383692156773,-0.22797612056724903,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark52(-22.72406094964947,-1.3287332640351934,0.07683157504286575 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark52(2.281295147410546,-0.8908436225978709,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark52(22.842956024886263,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark52(22.852249073233054,-0.8581241580909502,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark52(22.85566069957075,-1.4999997291059444,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark52(22.901112001016728,-0.668462889835066,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark52(22.916979173173814,-0.7296690541772427,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark52(22.917616685695872,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark52(22.93113908417463,-0.8998465784319869,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark52(22.94432563220981,-1.403245470322935,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark52(22.9465065731642,-0.33299316042909766,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark52(23.016943023602533,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark52(23.018652651804118,-1.0302753762137273,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark52(23.031773131603444,-0.02050618993445192,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark52(2.3032975642100126,-0.8412092538917477,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark52(23.055417226115154,-0.6509979018200681,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark52(23.07808980924562,-5.778418054743047E-8,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark52(23.079640330989122,-0.4707937845843414,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark52(23.098051973647202,-1.0238769567496178,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark52(-23.111634970003948,-2.220446049250313E-16,-0.08419810250195707 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark52(2.311800714422546,-0.16854080017178696,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark52(23.125938079912533,-0.015201836341515576,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark52(2.3164047802727765,-0.33639929551819137,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark52(2.319198629411119,-1.1967696891977537,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark52(23.28747574727533,-0.5932710487336328,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark52(23.33153591597175,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark52(2.3360334318619005,-1.4840228590507578,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark52(23.363335943062665,-1.3047704667777316,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark52(23.367192638887165,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark52(23.432693232174604,-0.07948567143385443,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark52(23.448047627063936,-3.266046151144911E-6,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark52(23.462182230886825,-1.4810881169845693,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark52(23.48567368630158,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark52(23.498402446713612,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark52(23.509666568241386,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark52(23.544541349082316,-1.1975789115921813,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark52(23.719905236406476,-1.1931439103550758,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark52(23.772738022302462,-0.6942160186566912,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark52(23.783440331853164,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark52(23.852881086576982,-0.6306546878022912,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark52(-23.857008111303358,-1.4999999999999964,-2402.7058507624038 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark52(23.875532990979664,-0.6527080276399899,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark52(23.887336959676112,-0.29354315015708576,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark52(23.935728266675056,-0.13825356298544644,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark52(23.955475989428805,-1.2035369408893009,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark52(24.056842328487164,-0.9274702348560311,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark52(24.09227386588915,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark52(24.11517294135794,-0.45260778396253176,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark52(24.203485566270203,-0.9793347171491202,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark52(24.228145286120494,-1.153027993510027,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark52(24.22958105886694,-0.7196190124035111,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark52(24.232189625964978,-1.4797622057188036E-7,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark52(24.243418886758185,-0.527851505174624,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark52(24.248194737934295,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark52(24.24876213452889,-1.24820842240994,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark52(24.24980255097653,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark52(24.30643839039152,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark52(24.374455326633626,-0.928725113058404,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark52(24.375299971951023,-0.8582753379590715,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark52(24.42469665797504,-0.18706703907552774,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark52(24.439706217676868,-1.2153501625167338,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark52(24.443520244866107,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark52(24.445147766826068,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark52(24.509021681575845,-0.10090545432375242,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark52(2.45210869119264,-0.285938729284288,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark52(24.56594650861254,-0.5939636798582932,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark52(24.578771736914753,-0.7826453224117529,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark52(24.5919139984883,-0.36333635820208166,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark52(24.604473439657284,-1.4423820275490025,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark52(24.61344295139969,-0.5566510572692351,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark52(24.615287197706852,-1.4556822398213771,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark52(24.629402482242853,-0.507263572047439,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark52(24.633258688892283,-1.4999999898641445,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark52(24.63920783235083,-0.31794152256059705,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark52(24.650814373617493,-0.6063513356988315,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark52(24.67089445687491,-0.7229075901975903,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark52(24.714485521265914,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark52(24.73275972938007,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark52(24.781692250550464,-1.0307057692879198,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark52(24.783283494221536,-0.1564100011031897,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark52(24.81394570528251,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark52(24.814720738434957,-0.5900838703702078,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark52(24.82350930957442,-1.4355348555557157,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark52(2.4880224067093337,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark52(24.888658843055183,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark52(24.91261372919871,-0.15959138543064721,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark52(2.4942012698795635,-1.4999999807629374,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark52(24.962653632970415,-1.228050958625147,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark52(24.99248984486244,-0.24308316031556298,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark52(24.99933196403454,-1.154164744392986,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark52(25.042765296274748,-0.35766338615021054,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark52(25.051683508784436,-1.0997176699897813,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark52(25.111881573258543,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark52(25.12737778476577,-0.46739605735718737,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark52(25.174704680937438,-0.6616481619177086,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark52(25.205707205308578,-0.9707280839803332,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark52(25.227127492531814,-1.1583023508732002,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark52(2.5267092733270573,-0.7871720233126123,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark52(25.274419062596508,-0.5939190833018269,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark52(25.305767385832965,-0.4416117118477366,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark52(25.3274563076733,-1.0390028968205847,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark52(25.34752177856545,-0.08003281703249399,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark52(25.353125649385206,-0.7807348469132626,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark52(25.355472726947696,-1.3064093072120166,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark52(25.36086370384156,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark52(-25.38925878506427,-1.244523389190883,0.1970410543654566 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark52(25.39259430996436,-1.4999985802503246,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark52(-25.41177728751069,-1.1049395821269528,-1.0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark52(25.412089583161787,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark52(25.44043185122777,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark52(25.440441946985246,-0.7246791847172851,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark52(25.446436542842505,-1.454383895434404,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark52(25.452139474180726,-1.1462657480306664,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark52(25.506691316664817,-1.2890687150293898,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark52(2.555138413515749,-1.3907323562738136,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark52(25.57214859771109,-1.3690155273583997,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark52(25.601765798865443,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark52(25.602120874501047,-0.4607279143163941,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark52(2.563203349553177,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark52(25.66873334214538,-0.6422102383718648,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark52(25.678212407929962,-0.13365028719604943,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark52(25.7400471859592,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark52(25.7424394291953,-0.029940532040257928,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark52(25.746954546508796,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark52(25.760062121492183,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark52(25.796738325044743,-0.9460457345549032,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark52(25.818305737759566,-1.8623420085341874E-8,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark52(25.880290612852928,-0.20778428800276938,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark52(25.916632192142913,-0.19522281320152413,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark52(25.933105821205118,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark52(25.96855025323443,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark52(2.6024510102877514,-0.9689258232372024,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark52(26.052309951662643,-0.8980935513416033,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark52(26.096608849753498,-0.8314475215056036,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark52(26.103773595947686,-0.8872066572462884,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark52(26.132060363548362,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark52(26.133801634762534,-0.522379189198328,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark52(26.167984353181225,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark52(26.16987084808315,-1.4015722370353672,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark52(26.22065532015357,-0.9179483325240092,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark52(26.237577947740363,-0.21458146063391859,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark52(26.251493552430745,-0.023300457793347107,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark52(26.28081172632146,-1.596233295717062E-9,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark52(26.280872717698784,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark52(26.29788074395461,-0.0135035655004061,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark52(26.314249218715435,-0.8282537065318517,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark52(26.407529063612657,-0.43123280928043206,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark52(26.412461971893237,-1.2602531484722057,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark52(26.44642095644025,-1.2777541890056954,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark52(26.480001429586665,-0.6886886720736358,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark52(26.596369281426902,-0.13636883595861748,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark52(26.611447587575316,-3.913248874003014E-7,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark52(26.626598304638165,-0.9858000410696803,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark52(26.626650856382142,-4.427928513215427E-9,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark52(2.662765763991999,-0.9589032611332584,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark52(26.705684200357794,-1.0855831211716223,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark52(26.7323080637089,-0.2648738384346956,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark52(26.749046617361333,-1.4412331284274158,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark52(2.6757535468358924,-0.601317586565429,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark52(2.677312303150428,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark52(26.776895183204495,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark52(26.78769148703303,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark52(26.80967215810422,-1.05405557233198,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark52(26.812766888963296,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark52(26.865536928535242,-7.316590410375217E-8,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark52(26.884531223165084,-0.37487783326642576,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark52(26.91031737606741,-0.06669913181306628,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark52(26.931956195438932,-7.427324414597573E-6,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark52(26.93298732818113,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark52(26.94306281758307,-1.0042675268032593,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark52(26.94547737231747,-0.7657999544670986,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark52(26.967552043956317,-0.5328303101179745,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark52(2.6973936346427934,-0.8068902325445606,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark52(27.016723886528784,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark52(27.017205770280427,-0.06998653364559553,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark52(27.113939472212877,-9.407740172087118E-9,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark52(27.134951204134243,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark52(27.207999243025412,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark52(27.20874719618442,-1.3109393799034166,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark52(2.7220111532793894,-1.4999999983590735,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark52(27.23946912593012,-0.703763288306917,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark52(-2.7243642774829135,-1.0174729765140182,-1.0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark52(27.25239247363369,-1.4999999999999645,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark52(27.257928977205893,-0.052706552263210416,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark52(27.271599316328164,-0.7235335469561432,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark52(27.285942308616058,-0.4812210549959701,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark52(27.331619569430714,-0.77466445335304,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark52(27.42256587396814,-1.3312198659257977,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark52(2.745033797087558,-0.28761252143049904,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark52(27.468766559232407,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark52(27.483842517853034,-0.1175610652032516,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark52(27.519147661361167,-0.5469317239352757,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark52(27.536757051955533,-0.8817128784190915,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark52(27.553037153442858,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark52(27.578056774858105,-0.48760434429636657,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark52(27.612282281891115,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark52(27.63275187344042,-1.4473870223899254,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark52(27.71232192152849,-2.080378981073773E-5,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark52(27.72835583016723,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark52(27.743193830450608,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark52(27.766649352353383,-1.4999999999268696,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark52(2.7782883002099013,-1.4505444548731473E-17,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark52(27.785528480955477,-1.1507106633597353,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark52(27.808214034029504,-0.028551481732691286,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark52(2.783754814246806,-1.4999694357241558,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark52(27.848149987794073,-1.2967082240607533,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark52(2.789011578312568,-0.05231411657754492,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark52(27.908692081042034,-0.04483590504869284,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark52(27.911237038860985,-0.35257190857914533,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark52(27.9190317259676,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark52(27.93670431242647,-0.16188527366385452,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark52(27.94424987421931,-0.09653499969711277,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark52(27.96543947968867,-1.0207916461230022,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark52(27.965636551317502,-1.3797423404940585,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark52(27.97954851144143,-0.19310280307580022,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark52(27.99032645206023,-1.4297686125697426,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark52(28.037303855646414,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark52(28.090521295200013,-0.9862148734447357,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark52(28.105805572561763,-1.499999999999968,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark52(2.8168813890816864,-1.096186381801809,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark52(28.19702287680815,-0.3873537148245422,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark52(2.820104831424345,-0.43570700136228724,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark52(28.231186448478333,-0.6595454183223115,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark52(28.241241838714767,-0.9467119650431339,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark52(28.30915159491022,-0.0620704547878029,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark52(28.316665089825335,-0.0726720010650288,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark52(28.333957461747286,-6.14499874763217E-10,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark52(28.33613766139516,-0.5625522615936589,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark52(28.403430333560777,-0.9272896127263359,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark52(28.45230689937455,-1.2681124852527432,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark52(28.4914410880254,-0.3760522572494367,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark52(28.498751385036798,-0.39666131960896145,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark52(28.530318701516734,-1.3869548336198587,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark52(28.543951134730463,-1.40034125971016,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark52(28.548049847281483,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark52(28.55148991189128,-0.0109631518525872,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark52(28.555342407799497,-0.44424882272395383,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark52(28.577909535317104,-0.1371510130923903,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark52(28.643438720994702,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark52(28.660851247559236,-0.7674531799195563,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark52(28.668760634271962,-1.0257042750373495,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark52(28.670828200452434,-2.4346243490145733E-9,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark52(28.697692371156975,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark52(2.869830173198821,-0.9830933597159113,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark52(28.729471025294597,-0.6161374052197888,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark52(28.73390304063051,-0.6005574503430893,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark52(-28.759663698358594,-0.30576707046781715,1.0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark52(28.792511784977904,-0.9611583664199392,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark52(2.879419213210525,-1.4104712347308312,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark52(28.800945856757664,-0.5127061740414138,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark52(28.81680084777861,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark52(28.8255760092934,-1.3219052553819977,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark52(28.851226665709902,-0.10683662616635559,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark52(28.882952964166904,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark52(28.894143834031325,-1.7220069613204317E-6,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark52(28.976795421562734,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark52(28.97859014968025,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark52(29.0021716963858,-0.3989376563404045,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark52(-29.006724302779084,-0.33377104623670084,-2321.154442551469 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark52(29.028241964190357,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark52(29.05090104019092,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark52(29.095063348651138,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark52(29.174472523400055,-1.2166568133371172,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark52(29.185668012704202,-1.1002040247733946,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark52(29.191660023626753,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark52(29.24537361861082,-5.51821323350741E-16,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark52(29.25198645939841,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark52(2.9270441156550504,-1.1509091191562777,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark52(29.27607383023286,-0.008265328477265577,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark52(2.9320371301084975,-0.9496604317551913,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark52(29.35572874267208,-2.8715597972580186E-9,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark52(29.36153839908977,-0.8886804290694803,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark52(29.4125814928719,-3.5022330258130255E-5,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark52(29.467438245380585,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark52(29.476074668362514,-0.008023154099479513,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark52(29.491018726236277,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark52(29.509295689988335,-0.05245998310658173,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark52(29.51427729128551,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark52(29.52603408499718,-1.499999999922124,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark52(29.56495015799989,-0.39314692029878984,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark52(29.623783905362213,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark52(2.9625844008000345E-18,-0.031086020197377273,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark52(29.633075506714203,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark52(2.970897528847672,-0.49386146356214056,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark52(2.9732636698034014,-0.22521836650012972,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark52(29.766809031735846,-1.257225791716083,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark52(-29.78163521680311,-0.6434006708383038,71.84463598747374 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark52(2.979184315546334,-0.3831335913522764,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark52(2.981363788056669,-0.580383074409923,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark52(29.828830540216387,-0.6235227307521001,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark52(2.9835800226361435,-0.8393864722490276,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark52(29.86582359154579,-1.3091153476753747,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark52(29.871544474810207,-0.6500826623117035,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark52(29.886566308738626,-9.424440897779485E-10,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark52(29.916967047924743,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark52(29.950476023879673,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark52(29.96674925441137,-1.2881187931845717,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark52(29.98756726886113,-1.2576275919388427E-8,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark52(29.99071909836141,-0.26114239821744745,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark52(30.042401355532263,-0.6249160543178647,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark52(30.074348832445036,-1.1357941861521108,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark52(30.07955111297133,-1.3645231935173996,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark52(30.08171950502222,-0.11889643190235821,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark52(30.088438444244016,-0.27393603613812445,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark52(30.105813765543374,-0.2849388466038505,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark52(30.105856773356045,-0.23310494419988181,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark52(30.197337747547657,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark52(30.232279524054633,-1.1238758169106209,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark52(30.247456453855875,-0.24191939264608164,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark52(30.292858550659957,-0.10035335495484787,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark52(-30.455054674496225,-1.3240506000214762,1.0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark52(30.469581493565475,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark52(30.494649768964933,-0.1271015599683183,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark52(30.535179760679018,-1.3501615683937844,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark52(30.537778920914626,-1.4022560408778872,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark52(-30.58604959638383,-0.6557763725355468,0.0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark52(30.595501147935853,-0.24308978531544767,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark52(30.6024348059683,-1.3647104982522045,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark52(30.604270978504623,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark52(3.0622547142234637,-0.4120148152512993,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark52(30.62984290422534,-1.0227821705849536,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark52(30.64070582429417,-0.9953266685613472,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark52(30.640711075202244,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark52(30.736817579883166,-0.30024668547582056,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark52(30.768627079345123,-1.4624956011926673,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark52(30.770702016558943,-5.0657881161363066E-5,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark52(30.771708131272433,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark52(30.79320706445813,-1.4988004327198325,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark52(30.807696164378115,-0.38318372997656525,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark52(30.82740937998642,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark52(30.841170352168632,-0.1102379797310249,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark52(30.853024585224905,-0.9604993098320689,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark52(3.087127204283174,-1.2803735911037535,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark52(30.884732388376655,-1.2762884774489946E-15,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark52(30.88894187953329,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark52(-3.0928410664759554,-1.4042593470743265,-1.0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark52(30.959485224581837,-0.09160178485508556,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark52(31.003783307972856,-0.4908311942177246,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark52(31.00941398914414,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark52(31.024983498880214,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark52(31.06464332335713,-0.4150654124017009,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark52(31.07802481807829,-0.6976947699806004,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark52(31.090760389636067,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark52(3.1096316484653386,-0.052126079017644766,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark52(31.10178285485975,-1.4434328616846273,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark52(31.12313546864867,-6.566350140262254E-10,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark52(31.12555205691467,-0.5877218929795425,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark52(31.20209440343587,-1.7723580681455882E-8,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark52(31.207871573252362,-1.1828939663092553,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark52(31.241165863494984,-1.1710185843426353,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark52(31.248194290598832,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark52(31.290938740842194,-0.48101965740947605,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark52(31.35101206244771,-0.5414708716693184,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark52(31.36250133319904,-1.2913941986924744,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark52(31.382996799679425,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark52(31.384454573620417,-1.4616245765598075,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark52(31.396486349317705,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark52(31.505094967957888,-1.141798111536124,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark52(31.56091004599201,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark52(31.588151856659067,-0.6463944013652589,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark52(31.618934289106335,-1.383527326545199,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark52(31.631273524960704,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark52(31.660361549041774,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark52(31.68433863680741,-0.9897329679713849,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark52(31.69141117809994,-1.1989790958079203,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark52(31.697176037203306,-1.217426308195386,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark52(31.716637643798492,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark52(31.718253404145543,-0.5948779393053325,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark52(31.749327756622375,-1.4865566624965898,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark52(31.75631491142309,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark52(31.790707593874743,-0.7671275389799632,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark52(3.1801894209294375,-0.015354288025652973,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark52(31.85631936445678,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark52(31.860342586340497,-0.14950981889796233,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark52(31.880749224425017,-0.9748507843953576,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark52(31.89055763777972,-0.06440075510573351,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark52(31.89409273308074,-0.26906900637742037,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark52(-31.910457839472212,-0.5351318222349262,-1.0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark52(3.1911137828445817,-0.5118968114075363,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark52(31.93210824122922,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark52(31.933126262329978,-0.13465754519393958,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark52(31.945841158147743,-0.31947674998633213,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark52(31.955066011475886,-0.1763219729200346,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark52(32.042676617397916,-1.4986879185989892,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark52(32.06697926082169,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark52(32.09629116864406,-1.2594713004174167,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark52(32.10265454890652,-1.4999999952995182,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark52(32.11693803353568,-1.4326709174703751,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark52(32.1174388739783,-0.7343307587857781,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark52(32.14479423104919,-0.8195227333677337,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark52(3.214957434964944,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark52(32.15760426845418,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark52(32.192289861896455,-0.5172639259009122,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark52(32.23986702729766,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark52(32.28526326877298,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark52(32.308405528162595,-0.3252123175544632,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark52(32.31340259092076,-0.7681256917759962,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark52(32.32552048159582,-0.7532967332830083,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark52(32.33624050101298,-1.4209072285213984,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark52(32.34886497963946,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark52(32.380504921996064,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark52(32.389530266695274,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark52(32.40294826736419,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark52(32.42992964191717,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark52(32.44061592199232,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark52(32.4414065977638,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark52(32.445418880815964,-0.06419089092877073,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark52(32.50834618310245,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark52(3.2548958537665698,-0.33348254273531097,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark52(32.564944612767135,-0.19196597474296184,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark52(32.58887302856769,-0.3770754341262226,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark52(-32.605810116087845,-2.220446049250313E-16,26.77181214086723 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark52(32.693233307263654,-0.7855633946228977,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark52(32.739710734740754,-0.34661207118872994,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark52(32.748468940519075,-0.727932703390297,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark52(32.75304948827165,-0.5014128566974039,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark52(32.75578320672287,-0.8394158759653241,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark52(32.77244645808298,-0.6051245093569004,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark52(32.77778109072048,-1.1104289986008213,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark52(32.78109369016471,-0.8911872876412971,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark52(32.798354856245105,-0.16371281449626418,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark52(32.80126498951378,-0.4819219467015934,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark52(32.806102036616274,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark52(32.81478336576711,-0.79486260651462,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark52(32.843050825906374,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark52(32.8618542850314,-0.8740938223537622,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark52(32.87274951681829,-1.0113928157914867,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark52(32.8854696507276,-1.3566457533779754,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark52(32.885898497022964,-0.49901196774580114,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark52(32.892931874269095,-9.031938171926243E-10,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark52(32.89347242622918,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark52(32.89558948657219,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark52(3.289749993148625,-0.8474244438750141,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark52(32.91027340472451,-0.17349012731662383,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark52(32.913121903242484,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark52(32.9269217184752,-0.04992433077801506,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark52(32.94835033864311,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark52(32.991199657223945,-0.7335856636766431,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark52(33.05026974463169,-0.2779500653982163,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark52(3.307695376083487,-0.8473041866396755,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark52(33.1439045741356,-3.896438804621731E-7,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark52(33.167971834593715,-1.7533107845074238E-15,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark52(33.173599490887355,-0.7897212914263179,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark52(33.20376937438638,-0.9463003438026618,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark52(33.29076886875916,-1.233774228831224,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark52(33.33599686933698,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark52(33.336031507881366,-0.689569869350845,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark52(33.35538822036223,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark52(33.36508809610427,-0.11668173851304561,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark52(33.40270320982194,-0.3666071849019117,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark52(33.40971792304052,-0.7690893664477834,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark52(33.41449703106657,-1.5532694704869533E-6,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark52(33.443874052391635,-0.653789746576944,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark52(33.47869627360456,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark52(33.4847818623057,-1.4190952237673098,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark52(33.49361651114751,-0.4465112496260808,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark52(33.518794559867395,-0.29916507474853815,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark52(33.53494967272562,-0.4877717687449887,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark52(3.3574036244491907,-0.7301649757900011,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark52(33.57860457241123,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark52(33.60579464937903,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark52(33.671378450123406,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark52(3.370369313576587,-0.028075044963507878,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark52(33.711823717422064,-0.002408257941561461,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark52(33.756094106889236,-1.4999999999999813,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark52(33.79818187693448,-0.25066197824947856,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark52(33.80210189262953,-0.04444843689049627,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark52(33.82839272216949,-0.6204501893240191,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark52(33.86742331200466,-1.5057062798526137E-8,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark52(33.930772998914875,-0.4947798500571725,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark52(33.96675810560991,-0.7540172906499238,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark52(33.99215798048212,-1.072930676847193,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark52(34.06379631409436,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark52(34.121168644321344,-1.2802823851017997,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark52(34.16169029184431,-1.0477464408116153,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark52(34.22596508964875,-4.813837654359365E-7,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark52(34.25300546752182,-0.26974178408886595,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark52(34.27871916448345,-0.149561172811007,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark52(34.284399222054724,-1.3738683578150754,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark52(34.319276889464646,-0.4566505935040026,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark52(34.33651160139141,-1.4999999999999503,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark52(34.37496291835313,-0.14722021214637251,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark52(34.38683536079526,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark52(3.440012101022049,-0.31768310853223536,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark52(-3.4405093105779204E-17,-2.3268062634879E-9,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark52(34.41584563164208,-1.4430483723456922,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark52(34.4229531806344,-1.1476889841590767,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark52(34.42593185647565,-1.2016540700471323,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark52(-34.44021073813002,-1.4850915670202287,-0.9684352447425283 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark52(34.44093359147169,-1.034602578187311,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark52(34.47927365554519,-0.1192726122791804,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark52(34.48131653158676,-1.0043722626241918,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark52(34.50642008807622,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark52(34.53264087632016,-0.2484581990361363,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark52(34.53434764812755,-0.8343863298592802,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark52(34.54975638761488,-1.0999978725776782,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark52(34.61482004643918,-0.3434429559872997,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark52(-34.632590250088775,-0.18542060643579553,-0.01733842871901148 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark52(34.6442314413506,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark52(34.74107530004697,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark52(34.760431642467616,-0.9322648432971277,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark52(3.4782447722183916,-1.4999999999660687,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark52(34.79209721253757,-0.6753148244271038,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark52(34.8160333423977,-0.49607083871354174,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark52(34.82828072817776,-1.4241091951205471,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark52(34.83320081306999,-0.637074682988592,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark52(-34.84515984017962,-0.8236367987516076,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark52(34.91459638181209,-0.5955271891089999,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark52(34.96386670059947,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark52(34.96464483437441,-0.2550215271388083,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark52(35.025550402869555,-0.1892318631952259,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark52(35.02743805939602,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark52(35.04160114742567,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark52(35.060079380398975,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark52(35.09695249424351,-1.4054764940456248,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark52(35.11481646374105,-0.3161157319644161,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark52(3.5122640932841165,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark52(35.13259359261045,-0.22181570375654758,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark52(35.192915221033616,-0.6809505557924638,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark52(3.5204288040358023E-4,-1.0175076555184792,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark52(35.20848405740531,-0.220952302269116,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark52(35.23567321517328,-0.9556844559690507,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark52(35.24552157077429,-0.45929991558897143,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark52(35.26413895255615,-1.189107826047902,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark52(35.27110801243049,-0.3748030927496009,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark52(35.28165079141513,-0.9848244518275919,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark52(35.303962027737725,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark52(35.30830064565782,-1.408333511262641,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark52(-35.320452454017286,-0.23015258102453373,1.0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark52(35.35016396486746,-1.1244176248588875,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark52(35.35251561897036,-1.2224012289966595,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark52(35.37407143125674,-0.8037901185157388,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark52(35.46140628345387,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark52(35.47582971788837,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark52(35.50077712447427,-0.32634425137007783,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark52(-3.5507124059163577,-1.375475260251736,1.385614140534103E-18 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-0.4353453728621588,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-0.5582452527028677,-0.6433201656474574 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-0.863721423591513,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark52(-3.552713678800501E-15,-1.1800204412179687,65.46962251013312 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-1.2028241363050967,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark52(35.52860581610523,-0.443791355615738,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark52(35.537457052226856,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark52(35.54551559351783,-4.707347490708245E-10,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark52(35.57245966017891,-1.066544897132447,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark52(35.5839753100276,-2.0217729150737814E-8,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark52(3.563713060925175,-1.2172872702703863,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark52(35.6410987610536,-0.35225189319029937,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark52(35.693981840328746,-0.4623083173053737,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark52(35.7155688908756,-1.1018506861867472,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark52(35.738130364157485,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark52(35.75012174711762,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark52(35.751872938312005,-1.2143437132866524,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark52(35.76145572726092,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark52(35.869928126120584,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark52(35.87969922838811,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark52(35.88050311074457,-0.9574472105406733,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark52(35.884815053105626,-0.31001389498262055,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark52(35.89550178505714,-0.18254265200377162,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark52(35.93541288277966,-1.499999643125864,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark52(35.95704547349611,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark52(35.9719921762927,-0.7090566631632953,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark52(35.983147613953776,-0.46657903166749115,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark52(36.032630646080406,-0.5423005167161303,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark52(36.035600402152895,-0.37917204423181516,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark52(36.05205307040481,-1.351409670973382,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark52(36.06861261535522,-0.09192890205147153,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark52(36.0998920877457,-1.4056167504452688,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark52(36.101398841754396,-0.3362294512583459,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark52(36.12747678556967,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark52(36.14449871566218,-0.8906114463321142,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark52(36.170185733568985,-0.8200526895756677,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark52(36.25188052931233,-0.5594242057226531,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark52(36.25417108769895,-1.0155304418639162,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark52(36.275159910763364,-0.8545718096917359,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark52(36.28333927111466,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark52(36.2846480807591,-0.797145676099994,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark52(3.6286689248778288,-1.4033107222753927,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark52(36.29102835680703,-0.673393815548023,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark52(36.291433982402026,-1.499999999999968,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark52(36.29282268809126,-0.5880000577449973,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark52(36.318861508708025,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark52(36.32445916288259,-1.1915555295944955,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark52(36.40316536357608,-0.1085049182873254,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark52(36.41489667585982,-0.20456522845484315,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark52(36.49322209014807,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark52(36.60740669970926,-0.8451006955611149,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark52(3.661797940514532,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark52(36.666040449928545,-0.562323986937237,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark52(36.68592264891379,-0.2894443225095654,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark52(36.719257410503886,-5.281005136207526E-10,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark52(36.74487042369884,-0.6063580473975709,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark52(36.746009257633716,-0.20387168746472525,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark52(36.77865337511559,-0.7517397440433824,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark52(36.79609141450629,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark52(36.79968828336191,-0.09085466006420351,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark52(36.80680844591245,-0.2128984642364622,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark52(36.88152372424696,-4.5720282492493545E-6,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark52(36.89428076232634,-1.4999999994976176,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark52(36.91209668182853,-0.19839755236075973,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark52(36.91550733291577,-0.7189638241909398,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark52(36.99753384227611,-0.8883788630175404,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark52(37.00216440022763,-0.05253839587999043,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark52(37.00401151618702,-5.697569290027377E-7,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark52(3.7012060553190764,-0.41583567529639964,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark52(37.01848887654691,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark52(37.04941213357835,-1.1289333086041928,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark52(3.7052499658183606,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark52(37.05605112368218,-1.090383627787702,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark52(37.060842710971485,-0.33677632927910395,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark52(37.130890696219666,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark52(37.140193685036195,-0.8783305028431521,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark52(3.714186700230291,-0.004578584332197266,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark52(37.143035970813386,-0.8578850654319634,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark52(37.16572692324371,-0.5134518696521146,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark52(37.173938247505845,-0.45342429325466904,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark52(37.3391140174587,-1.3233202428635769,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark52(37.35794080506477,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark52(37.35968859472692,-0.913712515144331,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark52(37.37573442012644,-0.41050045779304156,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark52(37.378006892086205,-0.4063014871541868,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark52(37.39783635864314,-0.43616262677225137,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark52(-37.42036257375795,-1.4999579313439533,-0.2760400653604432 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark52(37.456486669956824,-5.444416347351949E-10,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark52(37.45805027688411,-0.4521881240306129,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark52(-37.5368451388534,-0.5937665145936482,-1.0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark52(37.59283234909003,-1.4999999999999662,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark52(37.617580190002485,-0.4472663065016338,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark52(37.653901848172715,-1.0393815183947092E-8,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark52(3.767346599062705,-0.7485827755189369,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark52(37.67909795218537,-0.863404838250645,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark52(37.70403056991705,-0.4727807046894359,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark52(37.72764067678423,-1.4033799638880424,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark52(37.73246347978602,-0.10165790962697319,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark52(37.74542863233711,-0.713156336806378,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark52(37.746312702819225,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark52(37.74724234394631,-1.2959420154759584,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark52(37.7954590985549,-1.2864763900146539,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark52(37.819341917626446,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark52(37.83950832348961,-0.3428841583490121,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark52(37.84843247199271,-1.1454553796824314,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark52(-37.87223556706005,-0.29386612804901,0.0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark52(37.89318076850637,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark52(37.92656563075532,-0.7965961191871624,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark52(37.95421154679122,-0.7324783759921409,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark52(37.966662847629856,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark52(3.798329638352655,-1.3104956308154352,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark52(37.98941476350791,-8.455755082270965E-10,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark52(37.99969422165276,-0.8025679194842752,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark52(38.08630828746366,-1.499999999861293,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark52(38.10560287251761,-0.636077080386922,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark52(38.10781400058619,-1.29576545045986,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark52(38.11733806627931,-0.8575977410371838,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark52(38.12862093544846,-8.254467401650339E-9,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark52(38.129199949345086,-0.03663985640363743,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark52(-38.13815911566953,-0.04400538712715331,1.0000001410260566 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark52(38.15548529405733,-0.9096196819257045,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark52(38.185675507281644,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark52(38.19876501038138,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark52(38.23577507423052,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark52(38.24519806104735,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark52(-38.26870181442852,-1.0987738833408116,-72.69703460780275 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark52(38.27719863516248,-0.37004522603015033,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark52(38.285756457143016,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark52(38.28936735314497,-0.38862054145658,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark52(38.29214269320232,-0.16293552130200695,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark52(38.35930076752601,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark52(38.37897464808407,-0.5992660718192505,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark52(3.8386444754179365,-0.8152295051542797,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark52(38.433310614773205,-0.6986980383603146,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark52(38.474341703676714,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark52(38.47708445322068,-1.0769988888337068E-7,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark52(38.4773590665973,-1.225838495575338,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark52(38.55146865485929,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark52(38.590260690289625,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark52(38.61470289438677,-1.3641820076240094,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark52(38.68891632732036,-1.398896615606785,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark52(38.70668286628748,-0.7076031386759022,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark52(38.728714811291525,-1.128780173114336,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark52(38.74292684606212,-0.6890788887957282,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark52(38.792212738680945,-1.3877705103172577,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark52(38.796074093227446,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark52(3.882157182016172,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark52(38.83205953927086,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark52(3.8856437961911183,-0.95213011073713,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark52(-3.892956395729886,-0.16308049537730596,-0.26176631856927446 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark52(38.94050779954687,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark52(38.942008417261746,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark52(38.9476466116964,-1.4143486758906292,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark52(-38.95045895882592,-80.1591818846902,82.77144210582654 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark52(38.98007512345458,-1.1966808517958585,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark52(39.054902419592025,-0.463746282163213,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark52(39.062832902129486,-1.934770465243344E-8,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark52(39.103644762728266,-0.7204063307014215,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark52(39.13436378261329,-0.9265618283956125,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark52(39.221205594096126,-0.8285853730301962,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark52(39.2264201230042,-0.08203722339565211,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark52(39.23633810837134,-0.9746944819078518,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark52(39.2412112566604,-3.3123672781556275E-8,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark52(39.24478975665778,-0.49474114183878726,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark52(39.250825487096535,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark52(39.316136805841154,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark52(39.36723972858323,-0.03729454959338341,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark52(39.46377298143599,-1.1050961255200278,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark52(39.46701386497551,-0.4056929570025359,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark52(39.519785390058615,-0.8317766842239269,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark52(39.59009660476693,-1.3603758833672757,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark52(39.60105158260605,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark52(39.63363409543993,-0.5262581558563468,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark52(39.67935551732705,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark52(39.685237270558304,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark52(39.68884767069966,-0.2619624174811275,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark52(39.72436963836756,-0.03662920581064544,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark52(39.725365046906916,-0.5215964307090104,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark52(3.9743623792790856,-0.39869310338791986,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark52(3.974910502974894,-1.3051404036985161,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark52(3.9750747836023663,-1.3391445318178987,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark52(39.802229065396034,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark52(39.81502109287749,-0.07517528176004262,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark52(39.834148174626044,-0.48478337945346267,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark52(39.85243131952735,-0.49925760573903627,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark52(39.857740775013866,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark52(39.870112620341274,-0.6959087602770726,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark52(39.92015844838619,-0.1220747334806731,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark52(39.93939553093551,-0.5846042953809771,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark52(39.940049569159385,-0.7753425409187997,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark52(39.950310481064975,-1.4394137795618462,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark52(40.04409680391022,-1.3154442147331509,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark52(40.08252603074453,-0.11004323813565975,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark52(40.091142274915555,-1.2267539280627735,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark52(40.1378374791563,-0.04994151728997487,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark52(40.14156234079488,-0.13274234923736333,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark52(40.15067632765904,-0.05501038123964275,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark52(40.158237853422484,-0.2978133737150096,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark52(4.01749245164666,-1.4083053165031085,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark52(40.18201358402008,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark52(40.18601302125896,-0.34333618299476143,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark52(40.19968366409415,-1.4422766554891666,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark52(40.23003106500508,-0.6085076719230447,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark52(40.231884665041164,-0.22896474000942701,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark52(40.2886603711239,-1.0219174706169971,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark52(40.29620273098763,-1.2235566246964154,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark52(40.31233395631005,-0.47441962303336604,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark52(40.31300820820945,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark52(40.32192885776249,-0.029877047244718333,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark52(40.33783175737739,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark52(40.368938738410776,-0.3167298867291515,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark52(40.39012300863109,-0.1238964776006295,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark52(40.41263889162573,-1.2816704343618062,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark52(40.41279899893732,-1.4999999999996803,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark52(4.0415946369472255,-0.12713814306792054,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark52(40.42500331087459,-0.03630017553442393,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark52(40.42821213845659,-0.5894090425071141,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark52(4.0495823326047,-0.3219068700887202,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark52(40.510364018024816,-1.4999999999088311,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark52(40.52265087425377,-0.8373103221993574,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark52(40.52288618754183,-1.499999986547778,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark52(40.5451753766246,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark52(4.0555805792097175,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark52(40.628281115147416,-0.8373068188052555,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark52(40.63506595226521,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark52(40.65640467575689,-0.03617620741049832,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark52(40.667036271083475,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark52(40.687021271241235,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark52(40.69745415077231,-0.5914235106367344,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark52(40.77866691001568,-0.7853904779684626,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark52(4.090590004731439,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark52(40.958861058848214,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark52(40.96201089315855,-1.403242648358172,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark52(40.96641911475706,-0.5079975845964952,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark52(41.04481833957638,-0.1697690918583703,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark52(41.048660342595156,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark52(41.04889425422141,-1.35277791004226,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark52(41.05230348875821,-1.443466655212071,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark52(41.060224495225384,-0.6115028332906576,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark52(41.06221382840587,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark52(41.08483814277194,-0.1702942138607958,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark52(41.11051569553634,-0.8256026481779557,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark52(41.11425128911185,-0.6585696219037502,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark52(41.147071008375036,-0.7081494164933257,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark52(41.15367486315834,-4.5189917326875596E-10,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark52(41.17450179112224,-0.13304957870256362,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark52(41.17938226528435,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark52(41.21408868905377,-0.2542436437477278,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark52(41.23539912357481,-0.2870693896752504,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark52(41.24148397228137,-0.7473922472831305,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark52(41.253079009635826,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark52(4.12635516603288,-0.08251909321202788,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark52(4.129378434568929,-1.032554572764576,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark52(41.32109919639326,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark52(41.35308377453927,-0.8016450081415769,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark52(41.428589832578524,-1.2793501106693705,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark52(4.143141039661964,-0.11865505281354982,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark52(4.145552643038069,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark52(41.4570452463793,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark52(41.46365458572089,-0.6831374461040634,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark52(41.52662319512014,-0.6223420183751163,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark52(41.591419410084654,-1.0324717846260265,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark52(41.604044898779705,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark52(41.61299679549674,-1.025094679960338,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark52(4.172452640415393,-0.7319361678854222,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark52(41.75337989015139,-1.2719301605670381,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark52(41.78383942281033,-0.815345313734353,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark52(41.78584939182859,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark52(41.80893886955268,-0.9642262781013164,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark52(41.855170803150806,-1.2625887246433551,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark52(41.88860765323298,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark52(41.90612318500706,-1.06764149363228,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark52(41.96654854024726,-0.11457394682724631,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark52(4.200515065524148,-7.67192718545373E-8,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark52(42.00618773825097,-0.6873066909500896,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark52(42.02954474633583,-0.571720991405761,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark52(42.03500740598078,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark52(42.05038437534116,-0.36683918403949317,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark52(42.055388063390374,-1.499999999894097,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark52(42.0728023127849,-0.3837913930706516,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark52(42.12393222040299,-0.8884437090864736,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark52(42.150633117474456,-0.9016934649821118,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark52(42.15845413369102,-0.32400365173021406,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark52(42.19731604111844,-0.4024302742888488,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark52(42.22272531737946,-0.539767039301438,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark52(42.241732278075375,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark52(42.254066134040364,-1.253313883680892,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark52(42.25650704687766,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark52(42.29305304816522,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark52(4.229938025752659,-1.3172816287887614,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark52(-42.304788062480654,-0.10208391962459118,-0.6053390557443639 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark52(-42.31585095364579,-1.4979887193965846,-1.0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark52(42.352353637387544,-0.722916156175882,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark52(42.36295944598073,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark52(42.371657515533144,-1.053755962345278,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark52(42.38816288038525,-0.6599613149333521,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark52(42.394884252127056,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark52(42.397426368697054,-6.899100234035785E-4,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark52(42.39836003909076,-0.05043474239201623,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark52(42.41953505222463,-0.7036422802469335,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark52(42.455013328715694,-0.6853609337268639,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark52(4.249154530131776,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark52(-4.250436403341503,-1.0040555641227702,-1.0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark52(42.54444663127737,-0.7357528184289919,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark52(-42.55259826862392,-3.442002701146372E-9,0.0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark52(42.555545561169524,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark52(42.5616448591726,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark52(42.58454705941193,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark52(42.603269580152045,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark52(42.6191324566752,-1.38023286247626,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark52(42.63959912249694,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark52(42.68632616922315,-0.44661067027720097,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark52(42.773100418633966,-1.1523272218863685,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark52(42.78189946731468,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark52(4.282542347159364,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark52(4.282930358390702,-3.713863988372415E-9,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark52(42.8467515114188,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark52(42.84919187496905,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark52(42.89414723795602,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark52(42.90649916020055,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark52(42.962914528887865,-0.4017097863918053,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark52(42.96676413816266,-0.39033350126058414,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark52(42.97856060989833,-0.238244392756779,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark52(43.00617907553266,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark52(43.04097235353862,-0.6003919420045918,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark52(43.096989813254936,-0.03395072962309194,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark52(43.108848449063885,-0.13060840428596743,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark52(43.126700727319246,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark52(43.15086772374946,-1.3901476059014795,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark52(43.15806048385533,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark52(4.317595164563514,-0.09682366562516065,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark52(43.222620188600004,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark52(43.27392975997827,-1.3028564990166842,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark52(43.27510399357055,-0.5864743490947086,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark52(43.28694331470919,-1.2971820049279357,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark52(43.29252613626294,-7.416462255902953E-10,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark52(43.29385179458023,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark52(43.30362645315786,-0.6180918308196827,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark52(43.31226905465311,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark52(43.36345888201387,-1.268618449066991,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark52(43.3682019695471,-0.18469372414028803,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark52(43.38231884172467,-1.4805776148168859,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark52(43.41309376695497,-1.064065248998574,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark52(43.41370770125012,-1.1869838090790066,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark52(43.416804605308045,-0.13173265139611506,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark52(43.42535322160863,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark52(43.45161476351322,-0.2800207605020455,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark52(43.49439006682533,-1.1678989396741124,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark52(43.57294814078415,-0.7887089331730791,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark52(43.5883105489738,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark52(43.59069710503519,-0.8884460899460089,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark52(43.623254871075204,-0.49670231552404165,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark52(43.71041738735099,-0.6385492021618404,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark52(43.7926474543103,-0.6143332089075955,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark52(4.381372678002293,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark52(43.84752307338039,-0.9386276924489492,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark52(43.90854146718493,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark52(43.93519344871322,-0.9033344564098584,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark52(43.94737568227328,-0.4372573323953756,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark52(43.994851687890815,-0.6422824281340986,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark52(43.995817158087675,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark52(44.034187848416224,-0.44587955051009676,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark52(44.04354000773692,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark52(4.407277597305107,-6.003227170659246E-9,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark52(44.11241480126161,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark52(44.13614160988894,-0.9680658187488183,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark52(44.184649647997475,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark52(44.23589608926608,-0.11887889022197018,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark52(44.244427481269355,-1.402079484926782,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark52(44.3481019695667,-1.2297778157988546,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark52(44.37436154568462,-0.811924911817163,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark52(44.379800985236706,-1.4626358697938885E-9,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark52(44.382844754870774,-0.05835904035920825,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark52(44.38352825074829,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark52(44.3870210864593,-0.14500371969257886,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark52(4.439641184306993,-0.8552872967491247,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark52(4.440892098500626E-16,-0.38398934838829635,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark52(4.440892098500626E-16,-0.7729692010622071,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark52(4.440892098500626E-16,-1.2674833284551246,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark52(4.444047682822912,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark52(44.46481947606179,-0.8140908172999547,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark52(44.48572084624624,-1.2385359644424232,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark52(4.453562761837077,-0.00686565897782998,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark52(44.550998215968505,-6.742380443324399E-9,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark52(-44.56185052068171,-0.049226301863342314,-0.01896191820462878 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark52(44.57195002762734,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark52(44.652639000410176,-1.3775462770344973,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark52(44.678021191306186,-0.35800164113869926,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark52(4.470794256897676,-0.1534864182471777,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark52(44.76039693262322,-0.12304163604478857,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark52(44.77737298720505,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark52(44.780802954313316,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark52(44.78540996660937,-1.4999930117948623,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark52(44.80007422104609,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark52(44.820062097221864,-0.2044080608743007,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark52(-44.85477051011083,-1.028398162505331,0.9639185027734221 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark52(44.856160406245856,-5.93755890736234E-10,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark52(44.85978906629114,-0.19322379989327026,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark52(44.87278675907098,-6.078339237065502E-4,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark52(44.8928274563462,-1.4427866803010687,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark52(44.91903749703249,-1.4065891848548526,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark52(44.95869618236833,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark52(44.98614776141463,-7.597926821677755E-9,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark52(45.02337090255054,-1.3317292917603807,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark52(45.02348617943636,-0.5508074572790038,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark52(45.07005449301309,-0.530876435182627,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark52(45.07096120423927,-0.13883946441752992,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark52(-45.07859310295938,-8.74966416083775E-9,25.304374760395422 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark52(45.117804869528044,-0.8993821060548974,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark52(-45.1522985840334,-0.006975110893600661,-1.0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark52(45.15696638574687,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark52(45.20605040375748,-0.7568170929599998,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark52(45.28920131661198,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark52(45.33352862584135,-0.8849404883959702,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark52(45.366180155868626,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark52(45.386472361886234,-0.7741263602698352,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark52(45.40704544122441,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark52(45.41632666897027,-0.6383770564461884,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark52(45.41947081439652,-3.4807718713118904E-8,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark52(45.42543840153506,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark52(45.44844016736823,-1.335133983473181,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark52(45.47554005923224,-0.380890278637561,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark52(45.48459882444567,-1.2362566511513122,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark52(45.51055565704684,-0.11378346238027448,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark52(45.54254162409136,-0.409900617242946,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark52(45.56974407192479,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark52(45.57388336188737,-0.09684719944322673,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark52(45.62277224747306,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark52(45.63232846628224,-1.2936206087665592,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark52(45.681528329115054,-1.39554323307795,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark52(4.569006730461297,-0.2619346142322456,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark52(45.71522441849103,-0.4074400680798562,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark52(45.72268146095425,-0.43806776969563543,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark52(45.72680917937325,-0.2923575111478627,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark52(45.73785409033283,-0.9240568322747151,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark52(45.77946931732868,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark52(45.78952144664612,-1.1183491429003003,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark52(45.80079369815459,-1.009432082473924,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark52(45.80108943982868,-1.7277112691424275E-8,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark52(45.80341517939749,-1.492540804120111,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark52(4.58313288324288,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark52(45.86772637443539,-0.09606001975886462,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark52(45.99493132646078,-1.4269736385334593,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark52(-4.604329531704445E-9,-0.11264937648389603,9.268386361820527E-9 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark52(46.12578083625567,-0.7390355819164547,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark52(46.13850853602355,-1.4999999999999933,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark52(46.17938515340634,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark52(46.214897953957696,-1.4862787557998784,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark52(46.232582371984535,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark52(46.233140991227515,-0.5428335095306052,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark52(46.2718642524942,-0.8392312335699026,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark52(4.628629116265337,-6.598962424252954E-8,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark52(4.628913010263483,-0.011242517649533212,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark52(4.635297484514254,-0.38302941748663905,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark52(46.39274577253772,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark52(46.42831993062623,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark52(46.43213735124425,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark52(46.529209625228816,-0.16918676557509915,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark52(4.655317243885975,-1.4999999999999822,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark52(46.624631601112355,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark52(46.6664323340282,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark52(-4.6674385980171,-8.371949562197394E-10,-1.0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark52(4.670081299695525,-0.3638715718105161,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark52(46.72681143039148,-0.3718327702920021,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark52(46.74040060094945,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark52(46.741178764650144,-5.583408527445738E-4,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark52(46.764102273604166,-1.3609211282568356,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark52(46.786295855684585,-0.5324753410937646,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark52(46.81804307586145,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark52(46.84622472163187,-1.0882724943894686,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark52(46.891744020539385,-1.9021551781705065E-6,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark52(46.90820172812418,-5.662297247427564E-7,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark52(46.92682636321726,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark52(47.014533612248755,-0.6592394774948502,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark52(47.0317443354738,-0.13754798828070136,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark52(47.04710508566643,-0.06628074332171874,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark52(47.06343421747596,-0.8929624047661235,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark52(47.07128994749741,-0.7406506381072742,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark52(47.08088676040965,-5.810245296522371E-10,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark52(4.708134660315849,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark52(4.709362666926026,-0.9038844166628325,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark52(47.11743700697727,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark52(47.148857572682054,-1.2973104162103122,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark52(47.161915296210466,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark52(47.17095341197822,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark52(47.17709798392056,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark52(47.17874408953579,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark52(47.1848673206909,-0.33004497690135626,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark52(47.18892870873963,-4.6652121483681246E-8,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark52(47.241700592907996,-1.339639103261891,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark52(47.26508748852061,-0.18644158814951406,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark52(47.312697188528915,-0.45530587625283747,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark52(4.73401125707862,-0.12766081048750977,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark52(47.38045063788189,-1.411358312217037,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark52(47.385682058587136,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark52(4.741966777990328,-1.3408898967124117,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark52(47.47479861459782,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark52(4.751750399284177,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark52(47.57492897672203,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark52(47.57539036495167,-1.4999999988622317,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark52(47.59260553381935,-0.6437839905615022,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark52(-47.619141991999655,81.48961626827293,-82.52645845150795 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark52(4.762134180050188,-0.09588622437081323,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark52(47.651677643894885,-1.3040741110714535,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark52(47.66157065683103,-1.049672954183038,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark52(47.666842106386525,-0.2838521729340018,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark52(47.682645933639975,-0.1347202071731306,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark52(47.686443707943056,-0.5720693224768345,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark52(47.70465540315604,-0.905900615547726,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark52(47.72713676088141,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark52(47.79215071638526,-0.9494902707442208,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark52(47.79837297311653,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark52(47.86526374939558,-1.4081030907905356,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark52(47.88674925629665,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark52(47.90897656918524,-0.692784443822219,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark52(47.91468002886794,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark52(-47.91573574427383,-1.4999999999999991,94.57581906367683 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark52(4.793783173851072E-7,-0.44236448584885524,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark52(48.070940812640316,-1.4999999999999574,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark52(48.14418327753944,-0.3777108051258722,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark52(48.15929843618332,-0.9254603845853808,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark52(48.16088167238299,-3.150439116499713E-8,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark52(48.19155405623317,-0.7953135939568625,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark52(48.19501336424824,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark52(48.1985355547219,-0.16647059063987513,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark52(48.24374014200209,-0.2396267167522148,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark52(48.28161134026854,-0.7406222901559687,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark52(48.3377604488452,-0.4122982893685341,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark52(48.359514461840554,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark52(48.40416360156255,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark52(48.4460940868876,-0.7751260353047864,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark52(48.476057700174266,-0.012290518463390576,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark52(-48.49358591054735,-1.4999999999999964,17.94991784352827 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark52(48.504164522867285,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark52(48.58619227783202,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark52(48.58962075801803,-4.928558755402862E-9,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark52(48.59078405319093,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark52(48.595137387485806,-1.1039573148742932,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark52(48.60458872012001,-0.0952711093477785,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark52(48.765517961369234,-3.961509962356501E-6,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark52(48.78734709497839,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark52(48.84177658447476,-1.4905792067730697,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark52(48.887596092115984,-0.2743596971066184,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark52(-4.890634491584704,-0.04522773906405297,1.0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark52(48.90969750351229,-1.2305139991501441,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark52(48.93042523601417,-0.3776686543842884,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark52(49.03351080559499,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark52(49.08613119391026,-0.10405149149310661,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark52(49.11713760636624,-1.0127580565555832,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark52(49.14585340904344,-0.9088975663018459,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark52(49.14949828262479,-0.9995220390337591,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark52(49.1782619185806,-1.2937479160880194,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark52(49.198945024955776,-0.25545789520296136,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark52(-49.214521686699726,-0.06251527664846357,-0.3127493480088104 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark52(49.2191887727694,-0.8202240573445074,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark52(49.29326399016962,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark52(49.30535375185937,-0.4677543411233609,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark52(49.35608417661305,-0.8010745607722534,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark52(49.41926565350728,-0.8489595977968918,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark52(49.4290278293085,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark52(49.43406946599886,-1.0293077506523929,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark52(49.480318785817985,-0.52809330238928,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark52(49.491840258515666,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark52(49.518437112210876,-0.9960762533909095,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark52(49.53937975357715,-1.2021268661818478,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark52(49.562214664519864,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark52(49.59143399560841,-0.2070415587297263,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark52(49.610485702433145,-0.9664919126889341,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark52(49.62732255973495,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark52(49.65208102472691,-2.1210049260292674E-9,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark52(49.6637518628406,-0.08497584395145918,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark52(49.66488401977355,-0.2490995071718456,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark52(49.66542671630091,-0.2540895399117744,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark52(49.69049585275549,-1.1591559228515496E-9,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark52(49.739884140607955,-7.183477209450638E-9,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark52(49.788999040348585,-1.0219388245809955,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark52(49.79799253068953,-0.547206373291738,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark52(49.7990061883134,-0.309524750480489,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark52(49.802127990895926,-3.979943172858731E-7,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark52(49.809452096641124,-0.2997686649727907,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark52(49.83424818727025,-0.9568469087360825,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark52(49.85599088527334,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark52(49.856111952471,-0.2909861716863712,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark52(49.89594709562999,-0.3919369491504341,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark52(49.94027841935782,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark52(49.974339513604605,-0.6898432189225958,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark52(49.99415986088032,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark52(50.10050266573697,-0.185436410673364,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark52(50.11662335471897,-0.5252029921508115,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark52(50.13756005832974,-0.8975082272482382,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark52(50.168796610067204,-0.8184157046835512,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark52(50.214294486674106,-1.3665062346798647,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark52(50.237774455095334,-1.1939870844722262,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark52(50.24873256874571,-0.9520164248111553,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark52(50.26879828905538,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark52(50.3082773201982,-0.12433759272096298,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark52(-50.34430484776391,-0.5466431443575068,-74.14506279032548 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark52(50.368344844201474,-2.333817623654781E-6,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark52(50.38132499300377,-1.2459143778292132,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark52(50.42441835185622,-0.9728608083533032,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark52(50.4912756018866,-0.2407634769094935,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark52(5.050695331449139,-0.04041752159827805,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark52(50.51801867592299,-5.083724273798205E-9,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark52(50.62788581185018,-1.0508294794056097,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark52(-50.7162348602932,-0.18395712989370072,0.007079762592741928 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark52(50.716822644656304,-0.7071706817247243,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark52(5.072460682880127,-1.0948563170864203,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark52(50.73745361080855,-0.36894009748014356,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark52(50.73944868889194,-0.44543568658440247,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark52(50.7948271545236,-0.0010889817943508906,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark52(50.80308356330349,-1.2425289991172548,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark52(50.81490168126686,-1.3204334131077156,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark52(50.82898871198485,-1.4999999999524745,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark52(50.833044608944036,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark52(50.84277938722968,-0.7821402137643545,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark52(50.876691075016964,-0.8704300912257672,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark52(50.92966139910524,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark52(51.01469540498569,-0.9371377097452667,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark52(51.03104817508316,-1.1027439153856653,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark52(51.1138724419466,-0.48379901227420197,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark52(51.11893546208763,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark52(51.160146330045194,-1.382323197165448,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark52(5.1184096582539285,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark52(5.118838985926047,-0.52287363639158,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark52(51.19069045575526,-1.1098652182715085,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark52(51.222973988744855,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark52(5.125097149110951,-0.6762530595493734,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark52(51.29680926236288,-0.0020831346954898063,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark52(51.307693442495435,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark52(51.31512750304316,-0.7263360917779997,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark52(51.33435974963987,-0.9761319426523509,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark52(51.37386291342416,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark52(51.385566369745526,-1.0580400992420445,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark52(51.41411286087583,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark52(-51.42237379834293,-0.026501556925477843,54.98207151470777 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark52(51.446348059196225,-1.4056896818121203,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark52(51.4720488136246,-9.042803746204497E-7,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark52(51.47299068647641,-0.5872480619904921,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark52(51.478789793868174,-0.2545442348666199,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark52(51.48853769380981,-1.5085138596112666E-4,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark52(51.49516532979445,-1.4999999994760729,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark52(51.49808234138325,-0.12348674495571504,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark52(51.51650480286506,-0.5757087046637244,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark52(51.51855277031626,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark52(5.154940014935221,-1.057397188863737,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark52(51.577928665334895,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark52(51.59106051190102,-0.4107481870172543,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark52(5.16470922873791,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark52(51.67241754481479,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark52(51.690220727149295,-0.24455504741133716,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark52(51.69170171229405,-1.1699680237749206,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark52(51.72064661674335,-0.7883417434516341,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark52(51.75971810378442,-0.9580567622054159,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark52(51.760727586916325,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark52(51.760936088205426,-0.5642077826047593,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark52(-51.78127589747288,-0.07802236379456845,1.0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark52(51.78249585412645,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark52(51.799920135195116,-2.672799792296963E-7,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark52(51.81254136230453,-0.48930395359613965,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark52(51.818261725374555,-1.328483760597905,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark52(51.85046072054256,-0.46342433378156905,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark52(51.85791046648886,-8.340935219337491E-10,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark52(51.8749428767361,-1.1070940373313825,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark52(51.91103261397859,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark52(-52.032121002577504,78.39328566657252,65.29874951968722 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark52(52.06872997070303,-0.3499377238953434,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark52(52.06944545489506,-1.3273627364988227,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark52(5.213526254244222,-1.3526789255016407,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark52(52.13973713604209,-1.362150846063766,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark52(-5.214042305380751,-0.24853204406749052,1.0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark52(52.2155274678441,-0.07155252302139692,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark52(52.22334366217552,-0.06843339358948697,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark52(52.25163936067963,-1.197748206968586,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark52(52.31578507896086,-0.3863903856196975,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark52(52.31704005156226,-0.886672135100973,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark52(52.37911887419642,-0.2848833740471548,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark52(52.44632940123489,-0.6377767733404084,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark52(52.468183082452505,-0.03132406462633787,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark52(52.47405124268815,-1.3451406290700305,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark52(52.487407151765126,-0.23778873589848032,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark52(52.50814976440755,-3.0247932872018115E-8,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark52(52.53315746122212,-0.7579024569073418,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark52(52.53769672770525,-0.6425528476207365,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark52(52.58901276201637,-2.013238856415927E-8,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark52(52.619537285058016,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark52(5.267614319994067,-0.5001799099030293,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark52(52.6876946010664,-0.0433193886183616,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark52(52.708037543353356,-0.9791975238357367,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark52(52.735930168790965,-1.4999999999512423,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark52(5.273999494449598,-0.04491587118560858,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark52(52.76139328853232,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark52(5.276263681066839,-1.237017604452148,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark52(52.76845860678662,-0.9909772253273719,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark52(52.78431298794995,-1.193511763317887,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark52(52.797822034150826,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark52(52.80615463044688,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark52(52.85802029615766,-0.6509651556916864,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark52(52.88864480761701,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark52(52.90378282215556,-1.1468318527932435,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark52(52.91550899100611,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark52(52.963475446618475,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark52(52.986093305682516,-0.7684974785924439,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark52(53.00891109139732,-7.71959492305189E-5,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark52(53.02373664185608,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark52(53.05184270572194,-0.8263552362988162,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark52(53.079514637972025,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark52(53.104099550721386,-0.2572781186032218,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark52(53.15921370585568,-0.42494220541463346,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark52(53.238524147284906,-1.0576968603202257,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark52(53.25175301893129,-1.8560898279032851E-9,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark52(5.325596715321694,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark52(53.26199506139962,-0.1539997667720191,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark52(53.30174761010389,-0.9284558681485704,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark52(-53.34891102520909,-1.4999999999999964,-62.361683592617176 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark52(53.391386339869015,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark52(53.41310320369996,-1.235060236094256,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark52(53.44686327157669,-0.8386689869016125,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark52(53.46826101279245,-0.46788096516604827,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark52(53.481268677150865,-1.4135294293165697,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark52(53.492595459837815,-0.009300874159777095,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark52(53.52331848251592,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark52(53.59773161426264,-0.910859308994246,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark52(53.60768414323681,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark52(53.62025049869894,-0.41567823362638023,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark52(5.3631450452416525,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark52(5.363214238141581,-0.3272117918583844,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark52(53.65415058021409,-0.26932227513178475,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark52(5.366487182066848,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark52(53.68132762302834,-2.6276501761379327E-4,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark52(53.687327471775866,-0.04388740040556521,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark52(53.689403599249715,-0.031496907868395096,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark52(53.75046238379463,-0.7245835730869119,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark52(53.75105493277118,-1.0902161284263001,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark52(53.91083239249852,-1.1415917607132258,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark52(53.91158612604619,-0.48979196750008214,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark52(53.9546598491178,-0.18499202323322758,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark52(53.96107658327503,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark52(54.02777002752185,-0.4270687537343955,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark52(5.404328129925972,-0.7631233842575629,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark52(54.056913045521696,-0.8540712182233943,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark52(54.100733382719724,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark52(54.177221934960016,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark52(54.218788171055905,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark52(54.25407693199503,-0.1991464901272657,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark52(54.27257274644205,-0.1301467928365838,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark52(54.28434374894897,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark52(54.302370738121,-0.8740181856136839,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark52(54.32023449660478,-1.4360736477997382,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark52(54.32636765301868,-1.4391330124634094,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark52(54.33017595268632,-0.259120182116821,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark52(54.35551332994777,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark52(54.36535355882673,-0.9422917042001728,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark52(54.394193795502986,-1.0130709956467785,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark52(54.41779788755317,-0.5883812173752925,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark52(54.42603463206106,-1.11200764003092,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark52(54.46137298256295,-0.18965642850607395,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark52(54.46207882821835,-0.06579650196556397,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark52(54.46688464890411,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark52(54.476845753409066,-0.4986604441795617,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark52(54.50173460657377,-0.57495054579405,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark52(54.52487103091232,-0.4890782030665015,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark52(54.53065268756557,-0.8408264240255372,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark52(5.453193506649896,-1.0167337375886376,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark52(54.558893453281655,-0.4511307480328668,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark52(54.560886837622206,-0.520253841277226,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark52(54.56238421877302,-0.18126685774668516,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark52(54.56801037967047,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark52(54.57413605196294,-0.48267858368097905,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark52(54.655232236967265,-0.2913495798254697,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark52(54.67005952966042,-0.014212119764519283,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark52(54.695199038609964,-0.5467772654590786,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark52(54.71275619637325,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark52(54.74465149437985,-0.16565152310736522,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark52(54.81282010864981,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark52(54.8468449493782,-3.1376219800825413E-7,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark52(54.86857484461858,-0.6048264372838617,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark52(54.88919709077349,-1.9236460034204097E-9,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark52(54.91635993649919,-0.9714125437131761,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark52(54.93832815195506,-0.07458719435947164,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark52(54.96581114928223,-1.0654896726124765,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark52(54.97043418936519,-1.2728527079339012,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark52(54.988864011838075,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark52(55.01016666269501,-0.11119892866713572,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark52(5.502887266583581,-7.028437040243097E-7,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark52(55.044059414505696,-0.07524569464090326,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark52(55.0545898495981,-1.4393096492545823,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark52(55.077550658943515,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark52(55.098591057779544,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark52(55.15695528103488,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark52(55.19487914662295,-0.40215541961314116,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark52(55.2064725828739,-0.0035424551042324286,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark52(55.22225294017505,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark52(55.22921231865618,-1.2750584393215103,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark52(5.5245620350535205,-0.8502536818056007,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark52(55.26014194019126,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark52(5.539821010353194,-0.5224481945412549,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark52(55.41463874948456,-4.2839025843172623E-10,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark52(55.434008449667594,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark52(55.4795261755383,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark52(55.48103699153387,-1.018307798453626,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark52(55.48898067661763,-0.002973580774237705,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark52(5.551115123125783E-17,-0.12805773287090289,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark52(55.52170444384917,-0.5496655002905424,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark52(55.5759151754512,-0.4742412905834854,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark52(55.57962202939329,-0.9646770476973316,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark52(55.58022334944178,-1.4062560242824578,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark52(55.60766251435257,-1.4999999999999867,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark52(55.643889773985194,-0.6111649484116969,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark52(55.682062510785485,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark52(55.68549325201833,-0.089796745869406,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark52(55.70863498574556,-0.7051235892325518,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark52(55.759398810031975,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark52(55.7786397104602,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark52(55.79034768465391,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark52(55.819099578931684,-43.56950359715732,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark52(55.8556137419301,-0.8194708633781562,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark52(55.86677708737272,-0.8642231358956645,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark52(55.88237732557381,-1.1135650955580085,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark52(55.90697445258107,-0.35256329647477413,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark52(55.91518432270257,-0.24116388847300074,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark52(55.95995030623714,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark52(55.961741052931586,-0.20779409421741235,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark52(55.96355127956284,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark52(56.04824878718156,-0.14449073518407474,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark52(56.069924668012476,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark52(5.609348202677083,-0.5686241308026285,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark52(56.09959724640967,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark52(56.115298365951446,-0.030208430238344075,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark52(56.11622698043402,-1.4054726175179784,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark52(56.164706780557964,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark52(56.171483464117344,-5.376177603170236E-9,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark52(56.18896833962776,-0.27102619270166883,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark52(56.192544493363954,-1.287862642753126,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark52(56.25660571940659,-0.9639718618754411,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark52(5.629262567039845,-0.49989153381410667,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark52(-56.34935039089827,-1.1602102344868452,1.0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark52(56.35779976024628,-0.4237142461409178,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark52(56.39483062059651,-0.21625342551684046,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark52(56.41969734441368,-0.21785971178297636,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark52(56.441479019858036,-0.9494230733340188,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark52(56.45315427773933,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark52(5.64542420381303,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark52(56.45693446684007,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark52(56.4574743579027,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark52(56.53727308237936,-0.0025369156530246073,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark52(5.653857428369105,-0.4509070510204667,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark52(56.60248441203362,-0.908442796700534,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark52(56.63598497002047,-1.2523158877770513,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark52(-56.69571674701083,-0.7253633281607006,-1.0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark52(5.6705330494630335,-0.9898795519999517,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark52(5.67371172644981,-0.5604213837111955,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark52(56.74378876349387,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark52(56.745721659386135,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark52(56.81612225039464,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark52(56.82360525965348,-1.102278116365156,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark52(56.827517064791074,-1.4102387422793217,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark52(56.84196289471777,-1.2019365066146435,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark52(56.86173029571272,-0.05683094047265591,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark52(56.97576461165724,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark52(56.97969255481192,-0.16811213909662115,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark52(56.98572079816287,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark52(57.07021181094973,-1.1356575945552732,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark52(57.09261164140807,-1.4663899887614391,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark52(57.11695057335076,-0.6662056747547096,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark52(5.71225905221483,-0.3639528734196471,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark52(57.139911550063644,-0.03213372863622088,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark52(57.16905378801803,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark52(57.278915024297845,-1.097464324503043,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark52(57.34336508941195,-1.0508752688318737,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark52(57.360811284084605,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark52(57.41369901947903,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark52(5.744156430112795,-1.4508858961200466,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark52(57.57056187725874,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark52(57.58126673671664,-1.9426557474224087E-9,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark52(5.768041121195822,-1.1240332504229888,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark52(57.70669487784994,-1.2420199248643229,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark52(57.76462849698726,-0.9674762546094187,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark52(57.783949698625264,-0.36407227382408447,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark52(57.785800994687264,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark52(57.816730893952425,-0.37151122373801915,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark52(57.86344631933822,-1.1903567987092802,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark52(57.90189791977244,-1.3657756800014056,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark52(5.792721032533123,-1.484915603622511,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark52(57.97143808812645,-0.4818400903993352,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark52(58.00714168024592,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark52(58.0778595143818,-0.8295221840083107,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark52(58.084458709818705,-1.363118132507685,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark52(58.11253937009323,-9.393923757560813E-8,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark52(58.12817121160933,-0.7521800404860528,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark52(58.13493529695548,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark52(58.148423176956186,-0.49375725146145466,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark52(58.160030386982555,-0.9671096284035814,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark52(5.81862655333299,-0.1739278351777589,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark52(58.21863905843381,-0.06390845726137082,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark52(58.236148081561716,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark52(58.23996294291695,-0.8969826572820696,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark52(58.241304925797465,-0.8377492788052194,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark52(58.249968931566144,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark52(58.25954243104766,-0.9965468078754567,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark52(58.337634254444055,-1.1818756947558722,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark52(-58.360352618314764,-0.263508450811323,-92.46874363964366 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark52(58.39203781977008,-0.5950090302854392,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark52(58.41427761073413,-0.8763399055803891,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark52(5.844347469678008,-2.0478417534195787E-9,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark52(58.46305247948621,-0.2451572527171345,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark52(58.46528523291555,-0.2813235349416541,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark52(58.48073740173331,-1.3448599136171435,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark52(5.849713780627624,-0.4496050362962194,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark52(58.52813589145228,-0.36546925089924476,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark52(58.569048021834675,-1.098871079284871,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark52(5.859463700781305,-0.2864790598186997,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark52(58.67014309674108,-0.011185942673132563,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark52(58.68628721400694,-0.5042658622473262,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark52(58.69964573826901,-0.4106125026083474,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark52(58.7288032367746,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark52(58.732749522695144,-0.20953011863093707,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark52(58.75124191800103,-1.0746720017952782,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark52(58.75400500778497,-0.477864533679516,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark52(58.773169228691785,-0.03162934582408987,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark52(58.778191533446076,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark52(-5.878557318148392,-1.3172671070804625,-44.08872820546485 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark52(58.79991818684044,-0.612306203471813,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark52(58.807696048961056,-0.9152951336141888,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark52(58.81499134181959,-0.549252027980133,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark52(58.90389905133205,-1.3942550234620736,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark52(58.913018819933086,-0.0014563207416671275,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark52(59.02108675226023,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark52(59.08141302537993,-0.03750641389410424,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark52(59.1016316706436,-0.11077868884263387,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark52(59.10409513209591,-0.17296592929106802,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark52(-59.112083155833815,-1.4554778058343003,80.82834212107386 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark52(59.11835594412483,-1.8578386214188556E-9,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark52(59.13554318721032,-1.2031651216126205,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark52(5.9152609308338736E-272,-0.008942681034362918,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark52(59.17996536477517,-0.9438162916229942,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark52(59.19975453721338,-1.143490394383249,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark52(59.21352717082701,-0.719605382121614,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark52(-59.21551937972323,-2.220446049250313E-16,-1.0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark52(59.233425883683,-0.9049797769798893,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark52(59.25711022350035,-0.2657414456288478,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark52(59.348605582774184,-0.04785296844549691,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark52(59.371781679114854,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark52(59.38139155440578,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark52(59.415960048062004,-1.4707173331491394,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark52(59.426354119713665,-0.10637607509952474,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark52(59.43720865482199,-0.5299949418083267,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark52(59.45377105275348,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark52(59.454885380968335,-0.9906051871298533,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark52(5.949452932757691,-1.4880750816876984,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark52(59.51796331504789,-0.15370390674074286,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark52(59.535035016977986,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark52(59.53809650995643,-0.2771135940726994,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark52(5.954204516060017,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark52(59.61258453924873,-0.20091960845936452,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark52(59.632392014017,-0.009232459046008223,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark52(59.66019189940985,-0.5005287100789673,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark52(59.66799713435613,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark52(59.68973936000833,-1.4196231790655394,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark52(59.71912679916163,-1.3919652093069812,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark52(59.72750166399925,-0.5365793779959374,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark52(59.733576716038215,-0.7936159390342334,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark52(59.78020274464832,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark52(-5.983363844557954,-2.0894044490717608E-7,2399.8443177170784 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark52(59.906775814847265,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark52(5.9937788610995995,-1.2476524883241638,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark52(59.94312922039373,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark52(5.999392469679194,-0.5346893342905048,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark52(60.05606445577285,-1.1259884987411017,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark52(6.005761735566637,-1.489126653701618,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark52(60.070478510776496,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark52(60.076086718076525,-5.005582263264926E-5,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark52(60.100038919623586,-0.6325866658237798,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark52(6.0119830311600175,-1.4999999999494802,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark52(60.138730870136385,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark52(60.16369706677517,-1.3823933494298046,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark52(60.17566675519532,-0.5745622071482916,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark52(60.22800657747001,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark52(60.29011814593405,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark52(60.36439047080643,-0.160425003951993,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark52(60.382270919929994,-1.3806121165786465,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark52(60.40399678199941,-0.08073757739011889,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark52(60.42799607857596,-0.021811204018114233,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark52(60.44500004600525,-1.4057234873627067,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark52(60.45984956431449,-1.0617468846070235,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark52(60.46473425432819,-0.5597441026092103,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark52(60.46829638543376,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark52(60.48141992685606,-0.8701258936493634,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark52(60.49145205460417,-0.044017371172898834,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark52(60.51692786601964,-1.1149407000377864,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark52(60.53170500199303,-0.8554006187630989,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark52(60.54992037844187,-0.8730040198840621,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark52(60.55846207482384,-1.499057512489714,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark52(60.56411258766277,-0.3040487799895284,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark52(60.62826069143104,-1.2727028348296394,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark52(60.62935601749041,-0.5873633442677858,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark52(60.631374123805074,-1.4229986931514271,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark52(60.71809504419977,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark52(60.73494990743524,-0.15156529574932742,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark52(60.762223876709264,-1.4344850939318956,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark52(6.080590642624145,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark52(60.828359687505525,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark52(60.918013483375574,-1.3368713429279975,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark52(60.93552332171574,-0.014999101897777756,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark52(60.96055301867426,-1.0403642477876964,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark52(60.963769297249996,-0.8021895261583043,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark52(60.980048182125955,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark52(60.99313837114664,-0.7765215943543899,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark52(61.090689296608154,-0.14232766985880566,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark52(61.101891705758945,-1.523893853728366E-9,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark52(61.13512082812264,-0.9442267845994934,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark52(61.14077237095884,-1.0025239100289571,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark52(61.16187293768145,-0.21161869933541824,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark52(6.1194941290887925,-0.44141979050820623,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark52(-61.28352718963609,-1.4332450462490782,-1.0000000000003721 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark52(6.130903127666095,-0.5713699187032546,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark52(61.332626747267085,-1.4393405578195484,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark52(61.33870155156583,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark52(61.35662346083734,-1.3526143729992697,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark52(61.36347578336256,-0.581050539613301,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark52(61.40073961529683,-0.5765060578593681,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark52(61.426567696615166,-1.3262695280551342,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark52(61.53466829043794,-1.332706493052191,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark52(6.163914866314928,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark52(61.64141286758522,-0.9066256242096723,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark52(61.667161371688394,-0.08899667321873217,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark52(61.690670118409,-0.9623968471437097,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark52(6.170384539962163,-1.4999999999627915,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark52(61.71606369197974,-1.4003014645957137,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark52(61.72269472546196,-0.7992248723056432,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark52(61.72783433512472,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark52(61.74501907947092,-0.3139045557151139,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark52(61.755272459804445,-0.5371384228937757,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark52(61.7888102704634,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark52(61.802520822573996,-0.11035490596092387,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark52(61.82541146520146,-0.9633814485652135,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark52(61.85047920194047,-0.009830081807606798,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark52(6.185737743879124,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark52(61.87804403596243,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark52(61.890863133709104,-0.7692466186687739,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark52(61.986853269026426,-0.5235173169911924,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark52(62.03155141307079,-1.4999999999999485,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark52(62.105603582108756,-0.8342938779820948,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark52(62.111480397849185,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark52(62.12020876854737,-0.4884950075086749,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark52(62.127601667183114,-0.9732164278210149,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark52(62.1408185622912,-0.17634733850498796,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark52(62.143986927831264,-0.7010845061262281,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark52(62.17347324028533,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark52(62.26820901256029,-0.6385777417506837,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark52(62.27594757697622,-0.7205737739716067,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark52(62.31663982731732,-1.448891904920496,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark52(62.328114897665614,-0.8248807116031429,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark52(62.378262604874124,-0.24454382611315673,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark52(62.39197714890321,-0.08825541227288972,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark52(62.39546311978032,-0.4262763605091192,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark52(62.43619990106687,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark52(62.438070594497674,-1.5806231741138407E-8,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark52(62.481115365577494,-1.4013009108875298,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark52(62.489162201139806,-0.27060127132579836,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark52(62.490704730474576,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark52(62.5064504938785,-0.7738055912806188,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark52(62.548775720365285,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark52(6.254964757105668,-0.9341862213380371,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark52(62.595026409596976,-1.1856436199245433,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark52(62.671805727331844,-0.9233118905079376,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark52(6.268648674000943,-0.306510561693245,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark52(6.2687962475428805,-0.5534611554741957,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark52(62.71332196414332,-1.1339141369677308E-6,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark52(62.88733282231106,-0.8163799087081869,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark52(62.8880647328389,-0.9624634992818102,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark52(62.91312682508982,-0.3285990905765992,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark52(62.93209001003929,-7.839626304767316E-7,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark52(62.94407071932611,-1.2022787296262507,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark52(-62.95862422466207,-1.127602885388869,0.06255252577148482 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark52(62.96139008965691,-0.9082350187114585,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark52(63.0011938407838,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark52(6.303713379865911,-0.1597845160697613,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark52(63.04774922344197,-1.1349006720070505,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark52(63.0695859801921,-1.2096863546136873,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark52(63.072499206771624,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark52(-63.088416199844005,-2.9768662665827094E-8,-0.9999999963113647 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark52(-63.128855068968306,-2.019912139765991E-5,1.0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark52(63.159467571721116,-0.09622647394237044,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark52(6.321220013742803,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark52(-63.22963436253208,-0.19201141624433368,-78.09651457718986 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark52(63.23695428752222,-1.3345120814636464,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark52(63.277080591464085,-1.0631978600198684,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark52(63.280387554020336,-1.3186671600353477,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark52(63.28352549332527,-0.09657434342761162,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark52(63.291874497669454,-1.494190699673344,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark52(63.34005519530871,-0.33627739912235066,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark52(63.3640614742892,-0.5049346268915116,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark52(63.3949821411849,-1.3144051402505852,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark52(63.39827878747576,-0.012826713607656082,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark52(63.53539398033925,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark52(63.63978743669304,-1.0886528196668586,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark52(63.6398481557103,-0.939280212527251,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark52(63.64329308166779,-0.0537126242145054,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark52(63.677962350374884,-0.7462432753183124,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark52(63.7361552004661,-0.20524306574987716,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark52(63.74435799448719,-0.5606451912331534,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark52(63.74693846016021,-0.917298916521248,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark52(63.81524066701296,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark52(63.846847250885496,-7.874708548553346E-7,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark52(6.388831450308646,-0.8368362734081116,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark52(63.91469082403171,-1.4231345973352894,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark52(64.00031768407393,-0.9622828552172865,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark52(64.00394775233124,-1.2651363982168427,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark52(64.01349762178629,-1.0438059866536662,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark52(64.02682913846121,-0.023267097215274646,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark52(64.0710650690269,-1.3048598347455682,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark52(64.07152848630965,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark52(64.07215322555493,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark52(64.11629129669967,-0.9942642294629849,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark52(64.11868001284647,-3.581445352832269E-7,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark52(64.13488316970324,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark52(64.18652857921117,-1.3060740674769238,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark52(64.20073590493357,-1.384912454536951,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark52(64.29840701496796,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark52(64.32099197692966,-0.05315710677222363,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark52(64.32810214871841,-0.16925790408954255,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark52(6.433153582254754,-9.350175422287661E-9,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark52(6.433914752491624,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark52(64.35188838944501,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark52(64.37849000417543,-0.5229145521310472,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark52(64.44624995012484,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark52(64.45300735896195,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark52(64.45863099018298,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark52(64.46866450173133,-0.20575878693527372,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark52(64.50624516444762,-0.5949644063646391,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark52(64.50778080413144,-1.023938272281321,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark52(64.5371156227818,-1.4889001506835439E-8,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark52(6.45376050389153,-1.1751072079239044,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark52(64.54723903316875,-0.07471929857579962,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark52(64.54846056047995,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark52(64.5556842809946,-1.4051261213245285,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark52(64.66060210137647,-1.3539330935341418,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark52(64.66817402379709,-0.7941820873618326,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark52(64.70887735485206,-0.6347376342826685,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark52(64.72468148386687,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark52(64.73138777889869,-0.3607247428201106,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark52(64.74146319745074,-0.9433005539505714,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark52(64.74282172826514,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark52(64.74501824593887,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark52(64.75566455819471,-1.704204536316792E-9,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark52(64.79171267432415,-1.4999985796714275,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark52(6.479524015769854,-0.09129319780677747,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark52(64.79732207910484,-0.8004465053626697,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark52(6.480603787902879,-0.6703452149619338,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark52(64.8094950791326,-1.237634362400044,0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark52(6.482276252267695,-1.0373535368716316,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark52(64.84497848122919,-1.1166622849184658,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark52(64.85301327763317,-0.5197673617370966,0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark52(6.485453127327997,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark52(64.85572944315837,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark52(64.87414518513899,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark52(-64.90094747422046,-1.4999999947735365,-61.20354153079157 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark52(64.91311885400972,-1.2726919555575193,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark52(64.93226118182619,-0.6804256469979002,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark52(64.93791029554146,-1.0140678404587464,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark52(6.4987822796786645,-0.7745019583528714,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark52(-64.99979042671494,-0.9666126461480076,-32.47570918258036 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark52(65.10185421835146,-0.4547043083558535,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark52(65.1209859465774,-0.5592788593297202,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark52(65.12833045909551,-0.447756553305657,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark52(6.515928979043098,-1.145290538921518,0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark52(65.218343715824,-0.8502517019792935,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark52(65.26669861271046,-0.47440341010184284,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark52(65.2749827212923,-0.033466363864523035,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark52(65.28186410847147,-1.4898872616751624,0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark52(-65.28809632478344,-1.4999999999145168,0.0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark52(-65.29423537827572,31.10893917085272,62.6087037773178 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark52(65.32085138892728,-0.763958720535129,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark52(65.39967781275263,-1.0724982428511671,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark52(65.45313978695357,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark52(65.46440575761153,-0.2653357816939632,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark52(65.46779448996028,-0.9240407457727997,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark52(65.55507479401791,-0.04408213284384699,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark52(6.559222681771756,-0.7329530191627867,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark52(-65.64643470844365,-0.791947288972807,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark52(6.567258882077402E-288,-0.04544326473000599,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark52(65.68766109626648,-0.7552772946627755,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark52(65.7190428856243,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark52(65.73907406883527,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark52(65.76627960247345,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark52(65.80979524021427,-0.5086405114056873,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark52(65.87431697570082,-0.34941133195822177,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark52(65.87806450818329,-1.0416759261584758,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark52(6.588924959465217,-0.4489429915179579,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark52(65.9029207662241,-0.6306526219049526,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark52(65.95917965323457,-0.39164534881615154,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark52(65.96753651622677,-1.0913233829948963,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark52(65.96888357727647,-1.2729388909370485,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark52(66.03959734991716,-0.866841721826491,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark52(66.0659758350356,-0.41101480390722145,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark52(66.1174497119764,-0.02472280736714083,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark52(6.6120706485806195,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark52(66.14239019004756,-0.2552785962890375,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark52(66.1831681204417,-0.625731804212265,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark52(66.19118245473535,-0.9020442660195465,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark52(66.21782054278233,-3.9228072041016565E-9,0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark52(66.23403930601995,-0.230002254862959,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark52(66.25209220350456,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark52(-66.29092315837077,-0.0011196117994122234,-1.0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark52(66.31171844694757,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark52(66.34082110209435,-1.1503612245087993,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark52(66.34129966133531,-3.1082960574206224E-8,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark52(66.36195351290135,-0.07469983777729583,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark52(66.4121873780176,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark52(66.42739840872954,-0.873106268201362,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark52(66.44511874516039,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark52(66.44898798961711,-0.48252028698233573,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark52(6.649596221354103,-0.9726031807693611,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark52(66.50307630784903,-0.8311017048322498,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark52(66.60035013789297,-0.25268942986500065,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark52(66.6828968015524,-0.34013539418990923,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark52(66.68590791779721,-0.5074238280070922,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark52(66.70181142263075,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark52(6.672567335133039,-0.39502990249348,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark52(66.75999763530274,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark52(66.7770224061247,-0.8669940005127756,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark52(66.79882401058,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark52(66.83450436302715,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark52(-66.84295797625069,-1.4950032326795444,-1.807877370056093E-15 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark52(66.85147357655137,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark52(66.87857182908496,8.11480072456267,-10.623749576670122 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark52(66.89343691277074,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark52(66.98219767142393,-1.4525472825593995,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark52(66.99263782105726,-0.9196455742466085,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark52(67.00122013127046,-44.420598890919784,51.59036495006586 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark52(67.0219569812667,-0.01651327903864007,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark52(67.06977614792885,-1.0603451218802888,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark52(-67.09380060729586,-1.4999999999999964,-7.828831062292281 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark52(67.1395942890083,-0.7506186379648554,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark52(67.15475591643724,-0.6133904564908348,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark52(67.19773260512326,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark52(67.20842286137201,-1.1641626445979514,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark52(6.722170599148768,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark52(67.22174120828382,-1.0293655038974363,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark52(67.22636559560823,-0.1645238318187996,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark52(67.23244811028698,-0.4923428124627094,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark52(67.25895452269745,-0.5031597445582907,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark52(67.27881947217713,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark52(67.29648449511686,-3.3322208376504496E-8,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark52(67.31840582540872,-1.2688780810454996,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark52(67.34957898822032,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark52(6.7520657317369555,-0.17974051901961663,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark52(67.5580118803984,-0.6181131857231894,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark52(67.58853263302194,-0.47497029669009283,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark52(67.61623535676665,-0.9188075901717858,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark52(67.66888342457338,-0.21902633092937762,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark52(67.72065833225557,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark52(67.73051868336215,-2.4546053614487388E-8,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark52(67.73498608200913,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark52(67.736314140952,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark52(67.92107520976879,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark52(67.93907182693586,-1.4735080832044813,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark52(67.9847867509302,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark52(67.99913516315286,-0.6434666149884567,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark52(68.02837872776689,-0.007226053139465227,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark52(6.803071889623867,-0.7567126302208322,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark52(68.07633882159502,-1.4647448457824561,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark52(6.808166341154726,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark52(6.808569525530771,-1.3658855939340662,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark52(68.0951231089046,-0.8442421171351842,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark52(6.80990256472613,-0.1694341033543978,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark52(68.14536644392385,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark52(68.19997100117746,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark52(68.22804512017859,-1.3542540982101914,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark52(68.23214596630504,-0.8043001331030208,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark52(68.27499666995467,-1.1991083980660786,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark52(68.27591800789804,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark52(68.32305642096937,-1.4998524103297373,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark52(68.38758142525482,-0.47291692807185814,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark52(68.38888039688553,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark52(68.40939037396694,-0.9464265055382157,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark52(68.42238074480557,-1.1873252788653872,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark52(-68.4901348824348,-1.3578662933730559,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark52(68.53830943710847,-0.7911595436521361,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark52(68.55657635647599,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark52(6.85804468055025,-1.1531743159317642,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark52(68.61771848206563,-0.9357405398964048,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark52(68.63314313519183,-1.4122842824011475,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark52(68.67531993706712,-2.4060212881056722E-8,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark52(68.70423961727491,-1.32121791696812,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark52(68.71638544001391,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark52(6.873523291975417,-0.32609507866315335,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark52(68.73545663122033,-0.22359961602424483,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark52(68.76197447451142,-1.0763757235624922,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark52(68.80706828775674,-1.1588099537273737,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark52(68.83716728457816,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark52(68.83902055282407,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark52(68.85180321571832,-0.2127357823765361,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark52(68.86688016960241,-0.17777575184572214,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark52(69.06172604271853,-1.0413373201065552,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark52(69.06688299638733,-0.29442654092738074,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark52(69.10824699459121,-0.27366849544296623,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark52(69.11140988948604,-0.01608201524392716,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark52(6.912462687889715,-0.21154585473554377,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark52(69.14215893821526,-1.2590645023069982,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark52(69.15451480349017,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark52(69.18189808592993,-0.40387739333997974,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark52(69.23898595401877,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark52(69.25872592779544,-0.2771363292965958,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark52(69.2940729275133,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark52(69.33174846396608,-7.041691377263795E-16,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark52(69.34764251166467,-0.09913400450045629,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark52(69.37418299658478,-1.1229627480185336,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark52(69.45849241672789,-1.4593434014646753,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark52(69.46260327084326,-0.3521047257969627,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark52(69.48553317050636,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark52(69.5804508818571,-1.1442632613421608,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark52(69.59747974829028,-0.735927677375491,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark52(69.60487050882858,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark52(69.61214085293898,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark52(69.64892910164116,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark52(69.69066358515013,-0.8940192154836666,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark52(-69.75254908462452,-1.3039923041974362,1.0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark52(69.76446870431559,-0.08785111558375952,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark52(69.76840815289259,-0.11760518661020924,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark52(69.81629302595438,-5.4072413902749615E-8,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark52(69.8288818383032,-1.499999999546496,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark52(69.85567847376609,-0.7699790678777154,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark52(69.8823741799954,-0.4190564936087302,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark52(6.9935285819400566,-1.499999928913889,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark52(69.94192232298309,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark52(69.94616431300452,-0.6412265699449987,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark52(6.996387745841485,-0.8350523917013304,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark52(69.97262556885872,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark52(70.00364530835418,-0.24348218943811162,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark52(70.00866486800089,-1.2034400624950639,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark52(7.003656403788117,-0.9200461125811515,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark52(70.06521984689701,-0.4696093221469706,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark52(70.08207033062922,-1.349863021690795,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark52(7.011029396122709,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark52(70.11098953423522,-0.6708788499855451,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark52(70.15493081026639,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark52(70.15788159086536,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark52(70.16168389805642,-1.1871295010642058,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark52(70.1623171018393,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark52(-70.19547136403499,-2.220446049250313E-16,-0.7767339123753194 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark52(7.019780059174536,-1.11133445207627,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark52(70.20972441167942,-0.735307889768638,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark52(7.021259030555754,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark52(70.28195210284183,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark52(70.30992294623087,-0.03906993957369842,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark52(70.34306597126931,-0.09039067534185041,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark52(70.37363362136999,-0.006495964609683268,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark52(-70.40402623320523,-0.39618047385660304,5.551115123125783E-17 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark52(70.42976305946965,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark52(70.48531365375345,-0.7554254347556016,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark52(70.54840079301894,-0.41436567787342726,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark52(70.5496184658694,-3.910032872012362E-8,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark52(70.6137442670651,-0.746078316241851,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark52(70.65622388435767,-0.3458863722325134,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark52(70.66973243482138,-1.483381816901781,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark52(70.70508744611891,-1.2479617399390293,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark52(70.73177360011084,-1.2425774519087334,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark52(70.75877310950476,-0.5378064854311516,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark52(70.76747248852844,-1.483600879386385,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark52(70.7786165316443,-0.4193577616758233,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark52(70.81217118621494,-0.2563440016838352,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark52(70.8387938469618,-1.1177665541125492,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark52(7.085618683537627,-0.32131451179542025,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark52(70.88523720597593,-0.2432975843490226,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark52(70.91480672665045,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark52(70.95465722816854,-0.024420562382428734,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark52(70.98585717993939,-0.7734759296385745,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark52(7.105427357601002E-15,-0.21883233352844256,0 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark52(7.105427357601002E-15,-0.4050440659710457,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark52(7.105427357601002E-15,-0.7423242152369265,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark52(7.105427357601002E-15,-1.456421619076412,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark52(71.0553743175374,-0.13914135330467864,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark52(71.08635513432384,-1.3408312231198014,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark52(71.0899218382224,-1.4999999999172968,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark52(7.109023324826898,-0.8588979297595367,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark52(7.115490839854715,-0.7971494600673719,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark52(71.17152500726837,-0.5608008760070078,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark52(71.20929960500334,-0.9602822599494187,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark52(71.23106937217688,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark52(-71.26765310697635,-0.10910378434942558,17.297137320705502 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark52(71.27757222976432,-0.6928780303577575,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark52(71.30033995637851,-1.3021934434607236,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark52(71.34010451737747,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark52(71.34099192654972,-0.5629929401040012,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark52(71.40370245969129,-0.7500903078774428,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark52(71.43217409682987,-90.5131082417761,-39.72510213391636 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark52(71.46392930853665,-1.465723370798651,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark52(71.51008290154545,-0.32456973867681427,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark52(7.154410304128618,-0.47356377203622113,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark52(71.56862376593469,-0.2290325793786603,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark52(71.57104450698886,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark52(-71.58144048132522,-0.6824433640841303,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark52(71.69716453578954,-1.3400728311637085,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark52(71.73351458458143,-0.8575422297179093,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark52(71.73700268240935,-0.47221361108989623,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark52(71.7466256458033,-1.2763115304548034,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark52(71.75754908554336,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark52(71.75929037168828,-1.0895531126445919,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark52(7.180137127575875,-1.3879395635640037,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark52(71.83035211131465,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark52(71.83867709748729,-6.659342160379116E-8,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark52(71.85162006604214,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark52(71.95841830243347,-0.03356736415956085,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark52(71.98076515792094,-1.3900187740664511,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark52(71.98798323409648,-0.04785115524743633,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark52(71.99860936862993,-0.2457242977981119,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark52(72.01418604644442,-1.0033124437180447,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark52(72.06932017877648,-0.45000365422505695,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark52(72.07527248281023,-0.3018932220297419,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark52(72.07594627073658,-0.9197182071426706,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark52(72.09242369549071,-0.38539507756336366,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark52(7.210409443200973,-0.8319437059287308,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark52(72.10714919265887,-0.9910950888516636,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark52(72.14700341861905,-0.15590575164924703,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark52(72.16016780869052,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark52(72.17795158696492,-0.1788129829233185,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark52(72.19956391207978,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark52(72.21831796332796,-0.7994623402485317,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark52(72.36015502600605,-0.5884252841989515,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark52(72.38215924299456,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark52(72.3891734268648,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark52(72.3998106409991,-1.318673290439167,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark52(72.41603972539048,-1.1923796631472428,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark52(72.43530517997209,-0.8227350192320344,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark52(72.43959038541284,-0.38434972183656546,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark52(72.44144476230196,-1.3865009427274586,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark52(72.48368574578652,-0.07579862818001004,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark52(72.49822527409884,-0.1033698115244448,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark52(7.253531389908552,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark52(72.53726283313296,-0.6493811423523977,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark52(72.56527645080976,-1.0917942284505036,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark52(72.59448150488714,-0.1855651141573329,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark52(72.64520996221157,-0.7593804263126316,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark52(7.266697545283137,-0.7251946849224322,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark52(72.67366637397164,-0.41826472661441016,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark52(72.69283995784716,-0.21182572012222334,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark52(72.72100948879459,-0.07749884778669133,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark52(72.73648329829642,-1.1811081942276362,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark52(72.74999448301217,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark52(72.79565260224476,-0.2354318764164418,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark52(-72.89917479320779,-8.904285379936264E-8,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark52(72.99027409102393,-0.9656179418464728,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark52(73.11026656595341,-5.033131503042086E-9,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark52(73.11962030876953,-0.8535207008606847,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark52(73.13416323700785,-3.721255896594631E-9,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark52(7.317047267913111,-0.9912037945422014,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark52(73.17280120609874,-1.0942932003724,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark52(73.20012689491824,-1.4814160749399718,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark52(73.21502810201531,-0.025529437097556062,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark52(73.22688539129084,-1.1603360521371554E-6,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark52(73.30533209478025,-0.9580543133558024,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark52(73.35936078663494,-1.1349895735899014,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark52(-7.335937102912487,-0.48462875215423196,0.023952749130804085 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark52(73.4272851700855,-1.326437830176915,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark52(73.48036943888516,-1.4145021399248798,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark52(73.49412357041015,-0.8467975073287448,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark52(7.349758585711982,-0.8659106231779204,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark52(73.50025895681372,-0.9068945644462333,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark52(73.53552268849928,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark52(-73.556091722389,-2.092734707003111E-8,41.74891728248909 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark52(73.56950179536506,-1.402443763067385,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark52(73.71048784277087,-0.5326337892596135,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark52(7.383668484003493,-1.4444703065973954,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark52(73.85119832329575,-0.16222252402707985,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark52(73.9098096814788,-1.2446744891968597,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark52(7.391435677039354,-1.323953949088983,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark52(73.91830091050446,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark52(-7.394076163542342E-273,-1.491885106325177,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark52(7.394076163542342E-273,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark52(73.94204686065385,-0.8619825736703959,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark52(73.98538282205338,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark52(73.98913194585052,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark52(73.99354481423006,-0.5271068342761585,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark52(74.0256021563151,-1.114538615753908,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark52(74.0687540488974,-1.1550818827846925,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark52(74.0943816755356,-0.9320082102855451,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark52(74.10548213752267,-0.9297443247427601,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark52(74.11845916122526,-7.193204370739552E-8,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark52(74.1661812426423,-0.7624391808755264,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark52(74.1691855966292,-0.5692970821255443,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark52(74.18487729110788,-1.067527287711445,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark52(74.31684280988006,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark52(74.3178021307679,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark52(-74.36418168642253,-1.4999999999999982,0.8162201382535905 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark52(74.3845497329605,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark52(74.39971890624479,-9.703480408939227E-9,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark52(74.45949434599027,-1.2551108074784183,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark52(74.46480954095858,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark52(74.47950580127663,-4.910639138483785E-10,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark52(74.52526178697082,-0.007053803571437811,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark52(7.468344392710733,-0.11719729238096566,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark52(74.69776113160367,-0.5574759081945899,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark52(74.7211258191175,-0.01657849827638813,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark52(74.81307848125755,-1.1746407104421053,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark52(7.4873294712278025,-1.1315106568111872,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark52(74.8845701108865,-1.3475625459123108,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark52(74.9329145919813,-0.1051888016227549,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark52(74.93810078283232,-3.948061492421528E-5,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark52(74.96952336527647,-0.08155140603683031,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark52(7.49740605842429,-1.4999999999349565,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark52(7.5003215955648415,-1.256682443004813,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark52(75.03928523529609,-0.7728678744355113,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark52(75.07397017189865,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark52(75.17920269071666,-1.1152423733409318,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark52(75.18854632980037,-0.997393005297301,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark52(75.24578865143141,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark52(75.24682529835214,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark52(75.25657805180603,-1.2846605884207922,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark52(75.25754298680641,-0.8991501842309901,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark52(7.527789312564195,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark52(75.313151697258,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark52(75.31713491738415,-0.8009099033570806,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark52(75.33763350251627,-0.6545439744076305,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark52(75.3578983250072,-0.6872373023986142,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark52(75.44794466510533,-0.42927186512187343,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark52(75.46677909209075,-1.0788000666678021,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark52(75.51953266990736,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark52(75.54418712795274,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark52(75.54878228339294,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark52(75.55371626825455,-0.6766047053719078,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark52(75.55886370405263,-0.47049171896948305,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark52(75.58510005645772,-1.2961373858864,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark52(75.62494656996773,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark52(7.564115276708506,-1.4590850232832802,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark52(75.68001271136009,-0.1934678926315292,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark52(75.69764819124768,-0.06995697114442301,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark52(75.75327958876566,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark52(75.77247406152134,-0.4811149315242318,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark52(7.578885821732406,-1.4999999997956777,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark52(75.87698240864097,-1.3369348579962335,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark52(75.88842325089345,-1.2717217648025478,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark52(75.88990064957149,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark52(-75.91403817026936,-1.499997149741037,-0.6728496902514536 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark52(7.594916144295212,-0.30071886792435976,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark52(75.94928995821812,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark52(75.96179057933372,-1.143351966802129,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark52(7.599775607144784,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark52(76.02862242998438,-1.1813885566355873,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark52(76.04375174498031,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark52(76.05366122657128,-0.9354852741146487,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark52(76.08475135413286,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark52(76.11113331811109,-0.7218755358606639,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark52(7.612288353831872,-0.9042829551931391,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark52(-76.15042997996252,-0.6745319501801248,1.0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark52(76.17253487164172,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark52(76.18264466831445,-1.4067097554027992,0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark52(76.20649722598992,-1.4999999999999396,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark52(7.621527898519941,-1.121976968777716,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark52(76.21821172048044,-0.018042586811147954,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark52(76.22407779784807,-0.025699085509129027,0 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark52(76.25466801046721,-0.8839924362968001,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark52(76.25776814860441,-0.6219823393914092,0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark52(76.2721278014213,-0.23843445703135469,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark52(-76.27769033666766,-1.2136676117716982,-37.226814886192685 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark52(76.43280651314838,-1.948215903295912E-16,0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark52(76.43952169186403,-0.3424772073348281,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark52(76.46168341569182,-1.0919031786658828,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark52(7.650813950377184,-1.4294240086169727,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark52(76.54537562884622,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark52(76.58228509439985,-1.1211598909696825,0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark52(76.59570840522849,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark52(76.60401809540984,-1.499999998037295,0 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark52(76.61498012680727,-1.3646326329872664,0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark52(76.62397353478718,-1.4190323336992066,0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark52(76.63626317510477,-0.9900152965124884,0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark52(76.67419558565882,-0.09502423430758711,0 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark52(76.68583050218248,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark52(76.74019911061538,-0.25665288492562777,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark52(76.76814771821009,-1.0510829683423895,0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark52(76.772008841936,-0.6699007904768368,0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark52(76.78333760862449,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark52(76.84071692894071,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark52(76.84357376213231,-0.5472945660648301,0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark52(76.85802591726019,-1.1840875026693232E-8,0 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark52(7.689944942510323,-0.3032499179283734,0 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark52(76.90881052234738,-1.3982952310797003,0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark52(76.94217412168362,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark52(76.94251832072283,-0.3882805736592543,0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark52(-76.97509419391645,-0.8965584268381355,-0.020162330042478815 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark52(76.98483939293214,-0.5167762621790208,0 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark52(77.02814234834787,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark52(7.704078168156393,-0.9639418859201214,0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark52(77.04744764922756,-0.6727040982332166,0 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark52(77.05382481636744,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark52(77.05880823887856,-0.18641892038844787,0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark52(77.0674525287377,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark52(77.0692439600245,-0.170906886920851,0 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark52(7.7136892032276165,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark52(77.14411496271035,-0.566820900302341,0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark52(77.14855391645168,-0.0755404260181578,0 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark52(77.20116247400847,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark52(77.24719017316714,-1.442501208369468,0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark52(7.7284133835387365,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark52(77.32746727239935,-1.116647968112796,0 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark52(77.34197532091187,-0.20227146354626016,0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark52(77.35154735429003,-1.4999999999998792,0 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark52(77.37508951929453,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark52(77.39640497848404,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark52(77.43115294280332,-0.8729236021468125,0 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark52(77.50480006200681,-0.6588371215074034,0 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark52(77.5064439882498,-0.25493076894964073,0 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark52(77.50770039284414,-6.44444664979894E-5,0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark52(77.57062217549421,-0.5964521038265298,0 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark52(77.58278090706554,-0.40950191010487913,0 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark52(7.7624060603918394,-0.24896704683103416,0 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark52(77.63291038449032,-0.8824141575915128,0 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark52(77.63644210112645,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark52(77.77461459618704,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark52(7.778096645707365,-0.2317937273580477,0 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark52(77.78115326604185,-1.203291893613283,0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark52(7.783276141689495,-0.2526755516073871,0 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark52(77.83855122649669,-0.5336515872049858,0 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark52(77.86222685731732,-1.3802607160665588,0 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark52(77.86853679701011,-0.9195847877751521,0 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark52(7.789348820962687,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark52(77.89387199721546,-1.4542474713781797,0 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark52(77.90076795263946,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark52(77.90087251747582,-0.5165840422597228,0 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark52(77.96905304462096,-0.3778679183827022,0 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark52(78.00548079331571,-0.32715504435268095,0 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark52(78.01292558348257,-1.0359677203544777,0 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark52(78.02348542655525,-1.4704118440698797,0 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark52(7.808063637299597,-0.17349112259607086,0 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark52(78.11596985278442,-0.4635938937116528,0 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark52(78.14028494858056,-0.9849329704898118,0 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark52(78.16137406838727,-0.9204766940376423,0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark52(78.16930488644124,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark52(78.20607007163056,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark52(78.2076313043666,-0.585270241097148,0 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark52(7.824472085214724,-1.0105699203875984,0 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark52(78.2644339477124,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark52(78.2879723916163,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark52(-78.33180673573239,-1.393225129358633,0.3665370243434828 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark52(78.36046914731372,-0.35207978157665065,0 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark52(78.37406727592764,-1.2978889932986086,0 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark52(78.38164248126168,-0.736881662185897,0 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark52(78.43044012571886,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark52(-78.44043189954608,-0.2644200508593604,0.9622307171328602 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark52(7.845760646440354,-0.9047477950665979,0 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark52(78.46543336247291,-0.28306335036182567,0 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark52(78.53893509662947,-0.2264093526761033,0 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark52(78.56355471485114,-0.508705365991897,0 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark52(78.58425541608065,-0.6040478465480188,0 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark52(7.859226614977331,-0.5868021538154666,0 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark52(7.860839624630202,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark52(78.6106425236627,-0.26693132997877456,0 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark52(78.6331026101289,-1.2608747992429983,0 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark52(78.64538401965305,-1.4223821612591419,0 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark52(78.66613455261728,-2.5787339269008942E-8,0 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark52(78.68455027686616,-0.007471261006226372,0 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark52(78.77893091577627,-0.7785001957105542,0 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark52(78.81228362200287,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark52(78.8568345331646,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark52(78.87220285860896,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark52(78.91855555988104,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark52(78.93539063948666,-0.6079051492585847,0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark52(7.895561997300348,-0.04402242946897239,0 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark52(78.96634964972696,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark52(78.99286573117688,-0.8425513012045475,0 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark52(-79.0070100854605,-0.025572893192107236,0.10327990714254848 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark52(79.0111317344027,-0.882289435456961,0 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark52(79.02250306238761,-1.2362947015850354,0 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark52(79.11956889861386,-1.0702207752259199,0 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark52(79.1481569927873,-0.8116219324902447,0 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark52(79.15277558169115,-1.286135833850139,0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark52(79.23870811750845,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark52(79.25248176112402,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark52(-79.31481363457678,-1.1318663777293132,80.71792641601806 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark52(79.32106430435188,-0.9673257839248661,0 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark52(79.33038662688955,-0.17802446140031236,0 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark52(-7.933069664418506,-1.4128090812265377,-59.356584525948065 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark52(7.9364277566690475,-0.3771519401728227,0 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark52(79.38652828065636,-0.8741707095780438,0 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark52(79.40218055977371,-0.44888867905413843,0 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark52(7.94170621780188,-0.061260469647102855,0 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark52(79.45852554431039,-0.01975318377124191,0 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark52(79.461627858032,-0.021148853839541355,0 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark52(79.47090654077506,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark52(7.9479231526121215,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark52(7.9491216643440055,-0.8151939585962822,0 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark52(79.51728239333221,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark52(79.59864626614362,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark52(7.9628573475188915,-1.264769298656887,0 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark52(79.66952779651666,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark52(79.68591265061639,-0.5848905703852503,0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark52(7.977661592234028,-0.8112434989173751,0 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark52(79.83305464537034,-0.03705517168695488,0 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark52(79.83795449300882,-1.4986575761004208,0 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark52(79.83879572090126,-0.6867400535507693,0 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark52(79.84680527135183,-0.4559554415959427,0 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark52(79.88294046001414,-0.8009416375899194,0 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark52(7.992887881887917,-0.7193718202676828,0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark52(79.98736310273222,-0.09222771035427169,0 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark52(80.0027186414043,-1.8236557780783063E-7,0 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark52(80.00723319407953,-0.3930796686217377,0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark52(-80.02729180999152,-1.2543579535047618,0.04664930074423738 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark52(80.03137751520481,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark52(80.04765967475652,-1.1374118243345208,0 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark52(80.06959485178052,-0.5455322731800578,0 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark52(80.07238171487211,-0.8326714149320322,0 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark52(80.08230187511003,-1.2999171231962485,0 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark52(80.0950548906456,-1.4999999999997904,0 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark52(80.10854708733518,-0.4889193982939437,0 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark52(80.1426155092328,-0.8414590961722861,0 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark52(80.14901274428843,-0.0663926257337959,0 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark52(80.18580435668713,-1.1590978944637305,0 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark52(80.24594170510032,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark52(80.27880872090768,-0.4998929468463107,0 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark52(80.28345292747233,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark52(80.3669340893431,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark52(80.40550940853285,-0.12771522006386427,0 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark52(80.41656026643571,-0.7867894654382086,0 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark52(80.4399275407996,-0.39104533987776896,0 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark52(80.44940327373303,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark52(80.53543745634184,-0.4404250408976793,0 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark52(80.5507244950051,-8.131586636240456E-10,0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark52(80.59442677030037,-0.2552016353137909,0 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark52(80.66935976367398,-0.7394845593865966,0 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark52(8.074160574636664,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark52(8.075972559713946,-1.4001097017582396,0 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark52(8.080709771182384,-0.07512298629304226,0 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark52(80.83301298674931,-0.44523442862044327,0 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark52(80.83886698318983,-1.3591132385455431,0 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark52(80.85897101946591,97.57903431270606,31.812527912064127 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark52(80.89485638407626,-0.7915422473309519,0 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark52(80.93809105421583,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark52(80.9554752373665,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark52(80.97913952820164,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark52(80.9814507538739,-0.6594424583717278,0 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark52(80.98792248635559,-0.9224383265905867,0 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark52(80.99908138749738,-2.2254220577155812E-8,0 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark52(8.099912919524257,-0.19532747837915898,0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark52(81.11516347766826,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark52(81.11614158064828,-0.8855638630982443,0 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark52(81.16160593526808,-0.014403813811678295,0 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark52(81.16507342193408,-0.17121710456085526,0 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark52(8.117547291306893,-0.5203214717168008,0 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark52(81.17636160020129,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark52(81.1782723997745,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark52(81.23440221459593,-1.2658662149064565E-9,0 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark52(8.124282645541015,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark52(81.26299867963574,-0.8768338010881633,0 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark52(81.29128978422892,-1.2609417118747261,0 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark52(81.29427251374204,-1.270173331622157,0 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark52(8.131570117920464,-0.7224035287702719,0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark52(81.31867747264866,-0.1277908647005288,0 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark52(8.132221601873368,-1.342305078933649,0 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark52(81.32388346292686,-0.3306167562131037,0 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark52(81.36422306496878,-1.4999999451509742,0 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark52(-81.39778215676336,-0.0010739828601216469,0.9879494482318496 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark52(8.142607590026568,-0.40798054791832705,0 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark52(8.143441388315637,-1.093109212560833,0 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark52(81.4729501124575,-1.0548908203983682,0 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark52(81.49008362704407,-0.6438227726395804,0 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark52(81.49077400727725,-0.6642292528262033,0 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark52(81.52216086267515,-0.5464352542277302,0 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark52(8.153668719990321,-1.0649250251543414,0 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark52(81.53916857698502,-1.3829580966402713,0 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark52(81.59312876960564,-1.2447855596262793,0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark52(81.59836426605546,-0.9083492329790097,0 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark52(81.61314947916387,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark52(81.64217633966571,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark52(8.170002793241764,-0.7037744203834251,0 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark52(81.70288925675779,-4.7601003731510555E-9,0 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark52(81.81077157089224,-0.6495291770024096,0 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark52(81.81438026727844,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark52(81.84572949331701,-0.323619927610423,0 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark52(81.88715533556231,-5.54187051170712E-16,0 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark52(81.99995569960981,-1.3552072498786267,0 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark52(82.01299296242098,-0.7134483008378867,0 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark52(8.20233812673396,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark52(82.04662894578328,-0.08733058602564192,0 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark52(-82.05120048980585,-0.3924424580630199,0.7999918036884479 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark52(82.05458061177572,-0.015208388608400014,0 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark52(82.07583823277608,-0.9029881804514215,0 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark52(8.209692312154075,-0.3533094841926756,0 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark52(82.11528047327369,-1.3427665455049773,0 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark52(8.217281761780647,-0.09164584540026577,0 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark52(82.18535142724235,-1.4999999998668074,0 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark52(82.19741704456197,-0.39859989688179587,0 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark52(82.21330672170265,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark52(82.26551900623119,-1.0428459478278047,0 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark52(82.29214389744816,-1.3030561389061974,0 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark52(82.34004865967825,-1.3352202347635154,0 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark52(82.34091029589479,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark52(82.43058322906208,-0.8687166695388271,0 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark52(82.45007595581089,-1.3805290365685843,0 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark52(82.47185816978231,-1.0561711296965992,0 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark52(8.249477336635593,-0.9984790018230913,0 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark52(82.56023662540107,-0.7874213468377604,0 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark52(82.59637239150624,-0.7131737534778511,0 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark52(82.63857394051763,-0.43464238676126676,0 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark52(8.264844957259413,-0.3056906358739804,0 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark52(82.65988784818865,-0.6333266001341418,0 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark52(82.66156579933087,-0.8156273587329963,0 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark52(82.7244614976237,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark52(82.73495646957517,-1.4530384019222424,0 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark52(8.27366266373997,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark52(82.74735702693847,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark52(82.77433929224824,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark52(82.77605946001232,-5.000972322057492E-4,0 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark52(82.80155656365727,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark52(82.8478727623262,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark52(82.8615880335067,-1.499999999999952,0 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark52(82.87838159451161,-0.896107220514951,0 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark52(82.93239125592464,-1.4063637082784433,0 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark52(82.95948708477054,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark52(83.01239394956636,-0.10075450724214363,0 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark52(83.04206398741289,-1.02560311515046,0 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark52(83.0443682228265,-1.3592524924421072,0 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark52(83.08616705431079,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark52(8.31373735957132,-0.5933674169926064,0 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark52(83.1808441653393,-0.28974753782973117,0 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark52(83.19444446628364,-1.117724111007501,0 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark52(83.2107364488572,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark52(83.2818489406981,-1.1580417235263987,0 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark52(83.32095538788597,-0.35063094971079933,0 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark52(83.37336474386748,-1.2309327943608679,0 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark52(83.38131128320744,-1.4999999999501816,0 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark52(83.42259440167433,-1.4174985894814711,0 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark52(83.42445925353957,-1.4499016229735417,0 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark52(83.44697431722429,-1.1745501403797114,0 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark52(-83.4497242436457,-1.4999999999999982,7.280224588522316 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark52(8.344986692671934,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark52(83.45681919676872,-1.3940367276676011,0 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark52(83.52463497687083,-0.3226053437419125,0 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark52(83.54963477650878,-0.9911781611608594,0 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark52(83.58454934430068,-0.8870750079445697,0 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark52(83.60407881153995,-0.9802051524900783,0 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark52(83.61256454882167,-0.38839862101921696,0 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark52(83.63083217895277,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark52(83.67523088395026,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark52(83.77126039911448,-0.7978901674265296,0 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark52(83.8726442944064,-1.7671604949966886E-8,0 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark52(83.9255601256485,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark52(83.93535246217132,-0.21123472867836313,0 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark52(84.0290953575132,-1.2193894038985604,0 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark52(84.0698857199423,-0.06756724997298996,0 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark52(84.07606939712092,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark52(84.13256226662952,-1.8656279035646913E-8,0 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark52(84.17028687523606,-0.15251655383145535,0 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark52(84.20211517615957,-0.36891027145837185,0 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark52(8.4209490598614,-0.7551383416294969,0 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark52(8.423978719966438,-0.6549434184868916,0 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark52(8.428383977671665,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark52(84.30605037991157,-0.1427235700881555,0 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark52(84.31156373614434,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark52(84.32020009940823,-0.9802569201812403,0 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark52(84.32855797026565,-1.4999999999999307,0 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark52(84.34703148508723,-0.6447389137432147,0 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark52(84.35867545547333,-0.11648856409550179,0 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark52(-84.37674009014178,-1.2702046725852336,1.0000000206358286 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark52(84.41858672126898,-0.9519736690761351,0 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark52(84.51798414134336,-0.8819899942215981,0 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark52(84.55145821956035,-1.2504710083112087,0 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark52(84.58933306760161,-0.9876441199662362,0 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark52(84.65264689616885,-0.7366047037190526,0 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark52(84.69510664653697,-1.1549068964228084,0 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark52(84.73026051837961,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark52(84.73986791391269,-0.877507153481929,0 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark52(84.7840846598777,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark52(84.82623121282231,-1.0054510404074755,0 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark52(84.92231421450266,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark52(84.92526916501164,-0.5117220615565063,0 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark52(84.92974718961122,-0.35452870107033174,0 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark52(84.99210987912141,-1.4170808432078132,0 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark52(85.00777706817367,-0.9808111705031463,0 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark52(85.03868897542618,-0.8722095669395618,0 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark52(85.03943119401208,-0.623626364169084,0 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark52(8.506154380421474,-0.8907844401089121,0 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark52(85.0639767353995,-0.9273073723660232,0 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark52(85.08936879480535,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark52(85.10516847083926,-0.19378270725229088,0 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark52(85.12238389846064,-1.316395661498035,0 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark52(8.512477758124916,-0.6083640981289378,0 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark52(-85.14487036041176,-46.24486056441146,0 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark52(85.14797544431678,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark52(85.16518502999531,-1.126512991847978,0 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark52(85.16632295350112,-0.9880037613669608,0 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark52(85.18063633719814,-0.6936673938760531,0 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark52(85.18335368483275,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark52(85.18985531757946,-1.277093590688383,0 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark52(85.21220988737434,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark52(85.29377531808895,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark52(85.32683518070928,-1.4928972959235036,0 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark52(85.32920256075306,-0.2515264771760375,0 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark52(85.39306008808606,-1.1841691212000702,0 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark52(8.539863862613231,-0.6042788714152048,0 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark52(8.540539704286218,-0.7865447981255951,0 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark52(85.43255588796686,-1.054652319294263,0 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark52(8.543565062905927,-1.3540594222236049,0 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark52(8.543633897133546,-1.4503639319251036,0 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark52(85.44227449230121,-0.6391573604991905,0 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark52(85.47355811350877,-1.1052063259371918,0 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark52(85.49205736811678,-0.04554243436257366,0 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark52(-85.54385401314542,-1.271068631119304,-1.0 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark52(85.55939032656835,-1.1492508978274207,0 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark52(85.61460079313156,-1.1291530407068753,0 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark52(-85.6236568373796,-0.8411231622069422,1.0 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark52(85.65917698160962,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark52(85.67331636044062,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark52(85.71572902651687,-0.03514339483319501,0 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark52(85.77180186956737,-0.09862637919250028,0 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark52(8.589442623829896,-8.964653260671936E-8,0 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark52(85.91375013220247,-0.2616871921939463,0 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark52(85.93386653932207,-0.23955695326722082,0 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark52(86.03311803787747,-1.2464758386936854,0 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark52(86.04528103025268,-0.9927359394859252,0 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark52(86.05392456385626,-2.642147936916528E-4,0 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark52(8.605826395370524,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark52(86.06764618017888,-0.4252652469366178,0 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark52(86.15438234752128,-0.8578833035724514,0 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark52(86.16749600256514,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark52(86.20182565126427,-8.107347473166924E-7,0 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark52(86.25608506678819,-1.4981837510701705,0 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark52(86.2780798979839,-0.10158110602898773,0 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark52(86.27829485387696,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark52(86.33875131302986,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark52(86.37388280291034,-1.4268265110631404,0 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark52(86.37529198922627,-1.3623398716449167,0 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark52(86.42507093330431,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark52(86.46152665195683,-0.6008874963292072,0 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark52(86.48695831018804,-0.3524168725840049,0 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark52(86.50057477442465,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark52(86.5192988770851,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark52(86.53970874689841,-4.914966111665878E-4,0 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark52(86.58074496919502,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark52(86.59570739843218,-1.2388180544668823,0 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark52(8.65976802854938,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark52(8.661307499792088,-0.47485683585261995,0 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark52(86.65687012995059,-0.26177362354321687,0 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark52(86.66474304744746,-1.199887948172136,0 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark52(86.66694195213921,-0.7865942640508661,0 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark52(86.7728157323003,-0.6595283560627614,0 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark52(86.80699671120578,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark52(86.81444376240458,-0.31265622581409175,0 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark52(86.86837567317647,-1.4800480697272453,0 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark52(86.87322869649847,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark52(8.69782547622853,-0.16462672724064786,0 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark52(86.98502850216742,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark52(87.04667736065029,-0.370017956479721,0 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark52(87.05066524850236,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark52(8.708879774931836,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark52(87.10416386808761,-0.6943841546952356,0 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark52(87.1803016554006,-0.8842000409397599,0 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark52(87.23325094943455,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark52(87.24045963510761,-0.9540171210487927,0 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark52(87.25553162658046,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark52(87.27778354983352,-1.163076600532107,0 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark52(87.28189237689432,-0.7756291070394665,0 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark52(87.33165432009937,-1.3379434068995502,0 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark52(87.41628332429431,-1.2728265283679034,0 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark52(-87.42017535468818,-0.2516416232201384,-0.9980775814155196 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark52(87.42349336883237,-1.107283482194439,0 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark52(87.45367748253352,-1.3572786364458416,0 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark52(87.46976906134083,-0.029189734457983674,0 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark52(87.55033620417942,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark52(8.755659629596764,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark52(87.57480937589617,-3.343475219824742E-4,0 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark52(87.60413152224416,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark52(87.70703640321568,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark52(87.70744419271799,-0.8234881161614398,0 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark52(87.7151341634605,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark52(87.72867360836466,-0.07189810958463738,0 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark52(87.77080198927064,-0.926163195763479,0 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark52(87.7727718205409,-0.05341253683933456,0 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark52(87.77278214183198,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark52(87.8050274920913,-0.6921663537045335,0 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark52(87.83511350366922,-0.15362671289623986,0 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark52(87.87712816417869,-0.6586361215584873,0 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark52(-8.787745802973873,-1.2577487453826958E-15,-1.0014076573694644 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark52(87.93727324743702,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark52(87.95352834379568,-1.3652760443583962,0 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark52(87.99180137651524,-0.2129271041556393,0 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark52(8.804221430555486,-0.29684091453425765,0 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark52(88.09639453190704,-1.2183610945005428,0 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark52(88.10761231690302,-8.754349239343964E-16,0 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark52(88.17074625437371,-0.7619919668801465,0 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark52(88.182640199214,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark52(8.819679483678925,-0.5004780681228738,0 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark52(88.23045977111252,-0.9509296712721091,0 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark52(8.823484322927191,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark52(88.25645895767798,-0.9181960235618902,0 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark52(88.2590424348737,-0.4291982235868952,0 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark52(8.8279263425474,-4.871439988293061E-7,0 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark52(88.32604098455587,-0.7631952335781653,0 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark52(88.33587047659003,-1.449751237005826,0 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark52(88.33605855897397,-0.2813653932564888,0 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark52(88.41559530203902,-0.021473620565633438,0 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark52(88.43280639159775,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark52(88.43887312734492,-0.24008976602295068,0 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark52(88.4418402053455,-0.23474009008445185,0 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark52(-8.8480993557437,-1.4999999999999996,53.41780267455377 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark52(88.49643451400306,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark52(88.49952234763273,-1.0991197634802974,0 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark52(88.5457041449142,-0.5072414537297047,0 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark52(88.58851457645693,-0.6826359373919191,0 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark52(88.63286462860466,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark52(88.63584345255029,-0.5542144454124494,0 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark52(8.864137766662054,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark52(88.66797069629237,-0.846062767796532,0 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark52(88.71912787190084,-0.18276307342976805,0 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark52(8.881784197001252E-16,-0.19830939175123796,0 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark52(8.881784197001252E-16,-0.20006951537019102,0 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark52(88.84305215072646,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark52(88.86476576553164,-0.585911572978767,0 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark52(88.87698827049505,-0.4020868562998743,0 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark52(88.89429155719517,-1.4984594019648902,0 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark52(88.9263294425021,-4.2941398785214956E-8,0 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark52(88.94184136979442,-0.1822775929466287,0 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark52(88.98153926926045,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark52(8.902971391504416,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark52(89.05938430589998,-0.4957905993406672,0 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark52(89.06123679665924,-0.14129468023463293,0 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark52(-89.12716337378934,-0.5159320221053321,9.60285138939477 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark52(89.19586534301715,-0.9764253781004544,0 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark52(89.20229507626144,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark52(89.28536246109368,-0.59093861892506,0 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark52(89.32168795355217,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark52(8.932992207718755,-0.6071371198217577,0 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark52(89.43078861557626,-0.6575370880055118,0 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark52(89.44248934275441,-0.4549073536775641,0 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark52(89.46418203209336,-0.24158345792324099,0 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark52(89.48481472665853,-0.8532027759109981,0 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark52(8.950661263275705,-1.2281342152708685,0 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark52(8.959345336862867,-0.37638479116451995,0 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark52(89.64548530848023,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark52(89.65445679599318,44.29621387253451,-4.017614174800514 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark52(8.966716621703986,-3.868141397350363E-5,0 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark52(89.68880632963817,-0.28429413323418373,0 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark52(89.72006512776403,-0.8956780763846178,0 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark52(89.75581663365463,-0.47919095097609077,0 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark52(89.77005971651154,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark52(89.77665241699074,-0.2583223470669793,0 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark52(89.78841810144888,-0.13872323812818377,0 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark52(89.78932997441268,-0.15310691383288683,0 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark52(89.8370938319319,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark52(89.885085094319,-0.5735549395663153,0 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark52(8.990197662368345,-0.848675348539022,0 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark52(89.94792697644135,-0.427354895258631,0 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark52(89.97817507108357,-0.004763892640762602,0 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark52(90.00648138854294,-0.9305535453583573,0 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark52(90.04851977373326,-0.9228945363972008,0 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark52(90.05154035359786,-1.0031436765824657,0 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark52(90.07576004614006,-1.0362753213061153,0 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark52(9.010144765375912,-0.5335660592499374,0 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark52(90.14765599724646,-5.6935124503429274E-8,0 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark52(90.1990387983718,-0.2827548444748419,0 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark52(90.21744840939554,-0.7831241895090022,0 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark52(9.023334109479185,-0.03337988821913118,0 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark52(90.29148137195884,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark52(90.3474066262134,-0.2096957866878003,0 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark52(90.35167964304478,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark52(90.37293648886674,-1.3231633921451955,0 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark52(90.38897037484313,-6.152171549461087E-9,0 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark52(90.43625990842202,-0.691633187040258,0 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark52(9.044605828486539,-0.04720361345005131,0 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark52(90.46887673869438,-0.3653650555999235,0 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark52(90.47885889770276,-0.6883914312169717,0 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark52(90.50492931795313,-0.25182060012411966,0 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark52(90.50544996916773,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark52(90.56072137366073,-0.12871580152797213,0 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark52(90.56878139548644,-0.6284693619454106,0 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark52(90.68240093975703,-0.7659823663304115,0 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark52(9.068752595674027,-1.3860498550948246,0 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark52(90.69831986707436,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark52(90.71835815420363,-0.15113021444654806,0 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark52(90.72367540399917,-1.181367387320872,0 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark52(90.7518747673816,-0.4725983786792713,0 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark52(90.75371834554647,-1.2603224226223517,0 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark52(-90.76823805773171,-0.6893862694865271,1.0000000000000004 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark52(90.80032028217889,-1.1204013790438836,0 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark52(90.80922577114322,-0.6173690827388115,0 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark52(90.81355836595559,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark52(9.083065892583173,-2.657892003524711E-16,0 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark52(90.83225798575373,-1.1309288926638423,0 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark52(90.84587135853181,-0.6376868701646492,0 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark52(90.86626246100849,-0.3771905837570735,0 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark52(90.87865783157031,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark52(90.8889535369693,-0.47136001553115525,0 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark52(90.94496984852009,-0.1609791918226294,0 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark52(90.95378147354678,-0.4160531648686796,0 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark52(9.099878038640526,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark52(91.00586365348943,-1.4999999999999862,0 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark52(91.01169803777852,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark52(91.06423195620306,-0.19551937592656543,0 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark52(9.119649414626167,-0.4551291618871989,0 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark52(91.24080496193028,-0.9360645159386678,0 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark52(91.28936412612208,-1.318881761712933,0 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark52(-91.29978105565549,-1.4999999999999964,49.85078133682023 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark52(91.33748474923945,-0.8084033410426628,0 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark52(-91.37828975808523,-1.2938185748743938,-0.4269987316794781 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark52(-91.45432853662037,-0.4748248238587538,0.26220601037322266 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark52(91.45566484136137,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark52(91.51693732533475,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark52(9.152976190623946,-0.8808972719626524,0 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark52(91.59393207121181,-0.42608427890486666,0 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark52(91.61359224111874,-0.7129289606631488,0 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark52(91.66719189616629,-1.4720013395696352,0 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark52(9.173355982351978,-89.1061143924241,46.797067853876456 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark52(-91.73577797560839,-1.985633281331804E-6,-0.0914255649558835 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark52(91.7549323262412,-1.2369704753368609,0 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark52(91.80472787897648,-0.6493286620230911,0 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark52(91.87093867958652,-0.4200169117116716,0 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark52(91.87159788122736,-1.499999999999984,0 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark52(91.88802281995507,-0.5510349514801618,0 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark52(91.90156838061901,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark52(9.19344827620722,-0.6097853303468384,0 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark52(91.93858394193848,-0.8923517458047829,0 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark52(9.19541788245408,-0.2467093302988813,0 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark52(92.01592789698748,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark52(92.02607502063,-1.0352379629441182E-8,0 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark52(9.205381843736404,-3.9361440085855213E-16,0 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark52(92.06823966677845,-1.0372362375878255,0 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark52(92.16865839982918,-0.6100182584142431,0 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark52(92.17320180236464,-0.8951516709906286,0 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark52(92.1945139514682,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark52(92.2354050382623,-1.2432071794109367E-9,0 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark52(-92.24957821495433,61.66328577466359,91.88182683211298 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark52(92.27674881207757,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark52(92.28873922581903,-0.8034503587840421,0 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark52(92.30735074529784,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark52(92.31470182917462,-0.8160300215513274,0 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark52(92.31536889388178,-0.4661783820416594,0 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark52(92.32946003976244,-0.2687420907508056,0 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark52(92.42202763625721,-1.4999999999999645,0 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark52(-92.4253443220416,-1.4999999999999742,67.35373788472154 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark52(92.43017906724864,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark52(92.44841056731917,-1.1139276070960582,0 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark52(92.46114608880472,-1.4515664441733662,0 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark52(92.53659877030049,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark52(9.253868199698417,-1.2293914004135926,0 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark52(92.54232357899039,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark52(92.64768278669953,-0.9783844481646149,0 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark52(92.72851435642619,-0.7707106719166745,0 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark52(92.73536555633945,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark52(9.274690901960113,-0.3068993112722751,0 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark52(9.279239477659202,-1.1062684108979253,0 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark52(92.79626843262514,-1.4588323361234785,0 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark52(92.8357333338922,-0.5508841189115747,0 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark52(9.28616160506202,-1.0721296175148325,0 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark52(92.88109612875385,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark52(92.98932802832563,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark52(93.00672761426009,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark52(93.06379932235129,-0.1092387013787306,0 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark52(93.07069596632985,-1.1775712807911796,0 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark52(93.10399360043525,-1.1597504101868559,0 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark52(93.10623608577475,-0.28638051597206915,0 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark52(93.12030614793022,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark52(93.16520199289303,-0.9946138520520407,0 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark52(93.19925295137722,-1.1100504161203144,0 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark52(9.322560535197667,-0.5532189642352421,0 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark52(93.23330450692313,-0.4376331229936028,0 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark52(93.24563802145936,-0.16024213695716227,0 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark52(9.325890906180035,-0.055789427520451795,0 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark52(9.327344912943047,-0.39258947746657213,0 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark52(93.28147708405089,-0.9102012327331295,0 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark52(93.32031300138382,-1.0773070852384798,0 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark52(93.32278534554794,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark52(9.336332063257561,-3.7620054795662186E-16,0 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark52(9.348820878048159,-0.46810631271121395,0 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark52(93.49387164204866,-0.11151825444832876,0 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark52(93.52619767362799,-1.4989602315261474,0 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark52(93.53817560160383,-1.42564836505999,0 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark52(93.55839278703121,-1.4570759667100575,0 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark52(93.57070179051726,-1.3048479387919407,0 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark52(93.62082998395425,-0.781815930715382,0 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark52(-93.63126750252822,-0.8961554194858223,-49.63729401199388 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark52(93.68820863310293,-1.4999999999999978,0 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark52(93.69650937615734,-0.8461010745719836,0 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark52(93.73194305631486,-0.8229410979062302,0 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark52(9.38733123589613,-6.518371313380512E-5,0 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark52(93.88664812618669,-1.090830040763862,0 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark52(93.91973868238074,-0.20806496717293754,0 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark52(93.9276825067883,-1.1184832805816494,0 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark52(93.96188656384302,-0.5947788944952546,0 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark52(94.0485096539168,-0.37633015973437445,0 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark52(94.10492316574437,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark52(94.12160587361558,-0.8143536826267752,0 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark52(94.14599769918473,-0.5934957747797398,0 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark52(9.416168898770437,-0.05225177075075932,0 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark52(94.23545087581813,-4.460062147450108E-10,0 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark52(94.25761493015949,-0.19978512753403194,0 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark52(-94.28297909128246,-0.22471342341155567,-0.06255253604481592 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark52(94.30319855738294,-0.06220844019692606,0 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark52(94.31651332513593,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark52(94.33612566108982,-0.5413957130672316,0 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark52(94.37397636325355,-0.9875157100346321,0 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark52(94.3764646362437,-1.4576890762137586,0 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark52(94.38937900691741,-1.436635295232044,0 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark52(94.40319458431975,-0.16600556026752944,0 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark52(-94.41414958010274,-1.4626090626534891,0.45708281129148176 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark52(94.42879255173571,-1.364242129823408,0 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark52(94.44485393191052,-0.04102434567367785,0 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark52(94.52320533096233,-0.005601240933675644,0 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark52(9.452410256814332,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark52(94.54961108351033,-0.5480287246725084,0 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark52(9.455687108342982,-0.2720816417573918,0 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark52(9.463330813509574,-1.4999999931926704,0 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark52(94.65198633521732,-0.7698404330410078,0 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark52(94.68532366145604,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark52(94.7045002459121,-1.0758758064930838,0 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark52(94.74278038387902,-0.6793746664136403,0 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark52(94.81985931365065,-0.7222073148403609,0 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark52(94.84384868446865,-0.3144971816522226,0 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark52(94.88902423734615,-1.4207056660312356,0 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark52(94.90189084712102,-0.8204271812872665,0 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark52(94.93801884042875,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark52(94.96207122898451,-0.1665379663329854,0 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark52(95.00650516895749,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark52(95.21457836843982,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark52(95.2658511700412,-1.076615365418272,0 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark52(95.30796644126815,-1.0303411807323908,0 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark52(95.34242321941437,-0.38595152431184143,0 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark52(95.41574669722462,-0.9704357739269476,0 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark52(95.43368511486256,-0.9679008448376436,0 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark52(95.5012095273662,-0.55816787330361,0 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark52(95.50292547470741,-0.913089492416173,0 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark52(95.51317269530617,-0.3296191057054023,0 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark52(95.51661754913262,-1.4588366770744923,0 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark52(95.52848345244706,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark52(-9.553957143047697,-63.593161667585754,-36.307811556337796 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark52(95.55847983641308,-1.2211355042469911,0 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark52(9.557032723215059,-0.827751755744931,0 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark52(95.57704253307813,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark52(95.62842530310624,-0.36050295377047803,0 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark52(95.63829412599324,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark52(95.65128612656869,-0.6536596085778603,0 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark52(95.65462345003088,-0.810353849973402,0 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark52(95.6764135864794,-1.0845512339846994,0 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark52(95.71220731782938,-0.627776863493338,0 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark52(95.73892154605318,-1.4278228989169293,0 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark52(95.80897607872494,-0.06363585016049211,0 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark52(95.86257882182505,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark52(95.94570559256834,-1.0194028517612157,0 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark52(95.97384392026265,-1.2272581781826084,0 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark52(-96.02764922624426,-1.4999999999717382,-1.0 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark52(96.0387066122172,-0.09869849482992654,0 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark52(9.605126686260917,-0.24584192544881578,0 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark52(96.08850842810844,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark52(9.61218303733652,-1.0800479721705658,0 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark52(9.617718585646234,-1.0896634842072264,0 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark52(96.17823972243639,-0.5512265547398414,0 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark52(-9.620857695540824,-7.346808616510608E-16,-68.52865180122873 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark52(96.26919444680973,-0.050282547468076144,0 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark52(9.629880466014441,-0.9113307130015467,0 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark52(96.34992607846162,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark52(96.35489131363647,-0.6833171960870672,0 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark52(96.48921624039465,-0.50996113438438,0 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark52(96.64793563496775,-1.0548828841729687,0 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark52(96.69271915402918,-0.6058011528417349,0 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark52(96.72832681695431,-0.2960141648188568,0 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark52(96.74877155551263,-0.8826578840915147,0 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark52(96.76473091161895,-1.1320205798695042,0 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark52(96.77410588793393,-0.74682361181506,0 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark52(96.7915740591846,-0.026922920992527577,0 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark52(9.680585933404831,-1.4469738506219263,0 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark52(96.81069261573525,-0.7906118209871147,0 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark52(-96.89464237597495,-0.001803237656578705,-0.06123971384574678 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark52(96.96604684007107,-1.120007102926688,0 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark52(97.0232328541628,-0.3544853074296303,0 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark52(97.026453448914,-0.9265998050172891,0 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark52(97.0405751556562,-1.4999999996463689,0 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark52(97.07102413150687,-0.2668521052591144,0 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark52(97.126066837373,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark52(97.19955362058195,-0.43225637028491737,0 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark52(97.24795678495451,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark52(97.2813419313822,-0.009459562035015523,0 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark52(97.28759631749298,-0.20621938920508853,0 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark52(97.30098114999788,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark52(97.3012677844892,-0.7440980872246217,0 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark52(97.30421199135532,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark52(97.31799236567306,-1.480481460728944,0 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark52(97.4050102302347,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark52(97.407609210772,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark52(97.43044470412396,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark52(97.43129835369285,-4.1455266148788465E-10,0 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark52(97.4470424315009,-1.158054313779619,0 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark52(97.45308498728645,-0.03340512482035833,0 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark52(9.749080537733974,-0.07022314225510229,0 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark52(97.51466249296809,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark52(9.752758127740606,-0.6621227523634143,0 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark52(-97.60516001099717,-0.6254953520670117,-0.0590558872721168 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark52(97.60566441648919,-0.3352283254402266,0 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark52(9.764594097798124,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark52(9.767042920794303,-0.5188482912000258,0 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark52(97.70525367327505,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark52(97.71675895372258,-0.8781519616996968,0 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark52(-97.71850720707162,49.43840239513179,53.09816102563815 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark52(97.73080275833493,-0.2047469299093052,0 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark52(97.73316477547034,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark52(97.76311841719928,-0.7345752555583225,0 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark52(97.76694275648345,-0.1964229001405876,0 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark52(97.77953721553118,-0.12874553426073865,0 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark52(97.86681662295044,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark52(97.87442116901391,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark52(9.787625012792784,-0.7477998213856454,0 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark52(97.88226787140707,-1.4911405992442197,0 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark52(9.788887864076278,-2.13735155341581E-8,0 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark52(97.92828268340317,-1.101737844002113E-6,0 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark52(97.93858588196156,-1.4448522291445585,0 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark52(97.96448111640761,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark52(97.96472074656992,-0.9643969960900307,0 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark52(98.04037536881717,-0.7988966161247735,0 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark52(98.04407052501097,-0.2503831574918578,0 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark52(98.04460659707354,-1.1595923611834582,0 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark52(98.04878836036333,-6.770221979098821E-10,0 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark52(98.06367402148437,-0.382533534579216,0 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark52(98.13524649320445,-0.6172448041412224,0 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark52(98.15977808942733,-0.3259062386808318,0 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark52(9.818381493225633,-1.384589153640217,0 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark52(9.818822471111988,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark52(-98.21771234329283,-1.3085923708120466,0.9454980171992851 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark52(98.22130712340254,-0.8895485562514125,0 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark52(98.274646550179,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark52(98.35083476539448,-1.071294509457933E-5,0 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark52(98.37071279513046,-1.3635810223996998,0 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark52(98.43698389195183,-0.4876479842938153,0 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark52(98.50710850975176,-0.18023372327875942,0 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark52(-98.59414362280278,-0.03616522154417012,-1.0 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark52(98.61958163517428,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark52(98.71482552466594,-0.9252536693621689,0 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark52(-98.74525158117429,-1.1802884318032336,-46.23804698146727 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark52(98.7671272718382,-1.3541335974788566,0 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark52(9.878513141810814,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark52(98.78994820136245,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark52(98.80104881498252,-0.47604255469801027,0 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark52(9.887030081673974,-0.5859900704418672,0 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark52(98.91072044837031,-0.869855189258999,0 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark52(98.92383302173417,-0.7071052877238144,0 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark52(98.93862925443563,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark52(98.9562816688622,-0.8768276690831343,0 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark52(99.06025503251873,-1.4886843895197337,0 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark52(99.0690583297951,-0.6221587297319502,0 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark52(99.07613870772386,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark52(99.09418147673964,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark52(99.2470595264852,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark52(99.29668325172892,-0.1387430478440444,0 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark52(99.3074295085454,-0.9073741521463572,0 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark52(99.30834260339313,-1.2915735266149446,0 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark52(99.31164531879938,-1.1001547148569557,0 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark52(99.31830216352111,-0.8602863653416764,0 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark52(99.35831976698336,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark52(99.3743792814478,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark52(99.38106395227808,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark52(99.4576285554981,-1.3128717319842027,0 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark52(99.46078347340148,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark52(99.57740738786575,-1.1679923292809136,0 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark52(99.58053425785906,-0.05430038978823859,0 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark52(99.6297085395617,-0.1831636634794931,0 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark52(99.63150509728248,-1.4999988068019756,0 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark52(99.66409968661559,-0.15031521793029123,0 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark52(99.66606750037855,-0.5480400376358254,0 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark52(99.69588137169566,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark52(99.71157323267803,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark52(99.74107334392889,-1.4216126381758158,0 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark52(99.7420559228841,-0.48009896673980157,0 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark52(99.76680933144746,-1.4102242719540605,0 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark52(99.78111742077195,-1.499999999999968,0 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark52(-99.81737475425204,-2.220446049250313E-16,-64.87688186919748 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark52(99.82010143222746,-12.404389618553083,-32.274128822597675 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark52(99.83861581978374,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark52(99.85025771943117,-1.0689415534765914,0 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark52(99.86910054760122,-0.8303614781450648,0 ) ;
  }
}
