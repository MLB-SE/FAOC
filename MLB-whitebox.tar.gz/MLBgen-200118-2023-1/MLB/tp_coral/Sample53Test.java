import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
//    0.8534599691639768;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.004323888110633898,1.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.010431423505626859,-1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.013023216157203574,-1.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.020313760531817188,-0.9999999993422609 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.02315927395930983,-40.49559144566508 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.02665461618539253,-1.0000000121110442 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.033354882864731754,1.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.04680349485586377,1.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.06986230120886187,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.0811350606596965,-70.86207250563862 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.08252731891883759,0.05068498342897658 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.08452668697652718,0.7110305441200285 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.09583281758304174,-16.67038905649588 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.1049514333617818,2.220446049250313E-16 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.11163693208497476,-1.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.12351597797554648,1.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.13180578347516692,-37.092168659035714 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.13483803443563502,0.19940943354193374 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.1353405343288756,1.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.13670927146738054,-0.9999999999999999 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.14264597609431637,-0.05691110438991158 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.14424143176413828,66.33380129170672 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark53(0.001479876922072147,-0.5683624950822538,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark53(0.0017769289601690323,-0.09656441410052707,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.1779760450407081,-52.96538545118483 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.17820457151770075,33.899314211301885 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.18875595338930573,-1.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.2118084605612947,-1.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.22179530915883613,-6.323538852298664 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.2577725037348726,37.559434215243755 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.25810258166921707,1.5208732530361279E-210 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.26646319097375226,-1.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.30396393312528347,0.7803713899602612 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.3088197997553692,1.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.32761692243646223,-71.65821392227053 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.3306711681975206,-54.94151130467179 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.3394384825224961,0.9999999999999998 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.34813902664405094,22.519639817479607 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.38562334129430664,-97.58589654437462 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.39777973543564116,0.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.41116986921505827,-70.66345540232845 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.416230422124002,2.6469779601696886E-23 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.42805903104140314,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.4331625504276033,1.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.4557501249709005,-1.4457869095856338E-11 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.468100141753348,45.20751033554879 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5011634476682203,63.411381793510856 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5473819501926819,0.3224412322911139 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5684152571171726,9.958065406652652 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5700454998175364,31.075760003213308 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.5724421667871107,0.0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6044151431964013,-0.9999986552281113 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6389514472323381,1.0000000047371922 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6685892306128417,-0.06255253695111508 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.6838573639251725,73.78979626592582 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.7022595595867454,-1.0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.719296980992052,52.18750295603957 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.7454860138912733,-0.9999999999999991 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.7558301700365264,-0.11424746906437755 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.7564308419070398,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.7564324008170189,-0.1475871803484281 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.7939566981956017,0.05688433117156905 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.8410082710720033,-12.326546730139356 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9448139226982941,-0.9999999999999978 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.09619721051504371,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9680972629020119,0.7007993959939597 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9817479740186421,1.0555064176554343 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9862096990077398,0.9875108866916367 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-0.9974319871976186,11.670487458160864 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0378298747834855,-72.66859632733593 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0466370596156298,2265.997472709057 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0526702164276571,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0570563053460686,-59.82390015582565 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.06291707957748,-1.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.0782256984446281,11.113980076101626 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1051767184573347,-0.0505350420627287 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1074314568463706,10.329288198691241 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1193373660706696,0.12690308708318754 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1386092831276475,-1.0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1650478636853996,1.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1753688734361447,-0.9687682365377617 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1872192974383773,92.79050050485867 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.188600124398895,-32.252790020879466 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.189069272554634,-0.6647585458938772 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.1961057483705133,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.214325501430349,37.568732910333416 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.2319335335415076,1.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.2405531340957214,-1.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.257063619446145,1.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.2910520348172225,-0.5081704365786663 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.3051437870309095,1.0000000000156197 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.3053819242983669,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.3211042962358381,-56.26619990848087 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.3905143201261378,2271.520864153677 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.3908273093013463,-1.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.3960664827077531,0.8984204295429057 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4188642574747763,0.6795279925146216 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4266709904327446,-1.0000000000000002 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark53(0.014549995438510294,-0.7620081726696655,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4574090576219638,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4576400136555243,0.5408592375458908 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.459111715349028,1.0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4859789454508658,1.734723475976807E-18 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4876261356811251,-0.22363623601944405 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4913901529174534,-2367.1651883677578 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4954394553767785,0.9999999999999991 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4956258403378617,-2093.274942484565 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4967879856643012,1.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.498014561438744,-0.9407069748120591 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4982035756934473,1.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.14986490441395528,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999930243213,1.0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.49999999884397,0.8671607831427055 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.499999999999993,-1.0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999964,-21.58129279414007 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark53(0.015655077566409777,-0.13474437452453775,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.714363919775917E-17,-81.659997958855 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.17532017196512484,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark53(0,0.19617688309136838,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.20425598236857212,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-2.21937379483271E-4,4.482886014227819E-12 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-2.220446049250313E-16,-1.0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-2.220446049250313E-16,-5.882440793569363E-17 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.270292914172895,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-2.7650244491179812E-9,-0.9999999999999895 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-2.8266953821862867E-4,-1.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark53(0.029544184097467605,-0.08338688617918558,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark53(0.0,3.364787583607073E-27,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-3.552713678800501E-15,15.62374879074791 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-3.7769350726556377E-4,24.584185107611574 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark53(0.03790579916419261,-1.3503450064923068E-9,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark53(0.03800403035931865,-0.3909533461324338,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.42884756539345403,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-4.534877353051571E-6,-0.57591192514221 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-4.614152432250745E-11,1.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark53(0.04852438505780594,-1.0776411470719092,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-5.070947981953307E-4,1.0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-6.162975822039155E-33,0.06255252527156405 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark53(0.06311754705974609,-0.5465751273462975,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark53(0.06547935706699093,-0.14212468267307354,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark53(0.06769590273307813,-0.08215746054868323,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-6.858551701248543E-4,-1.0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-7.105427357601002E-15,-100.0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.7160428177543938,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark53(0,-0.7986613469000474,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-8.317328074071291E-16,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark53(0.08458018539012535,-0.3564290523688233,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-8.704034445613431E-16,-7.01378991682689E-192 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-8.881784197001252E-16,0.3652352381691044 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-9.113902524445497E-305,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-9.347340420082207E-9,-1.00000000000179 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.019706482461146,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark53(0,-10.700859381497125,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark53(0.10722738330855464,-0.6497178069803731,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.0E-323,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark53(0.11658065915234772,-0.07575218234399017,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark53(0,-11.728835431473584,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark53(0,12.377335909390894,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark53(0.1275622245414496,-0.598366449820655,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark53(0.13664286682559634,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark53(0.15862884834529173,-0.09515098193746474,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark53(0,-16.99447113340449,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark53(0.18352149830381126,-1.0746640292850782,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark53(0.19161412005377168,-0.5388604299312427,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark53(0.19666923579860984,-0.8581375649455081,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark53(0,1.9721522630525295E-31,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark53(0.19866937326121956,-3.502619787768855E-5,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark53(0.20481806079885678,-0.7092468915454906,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark53(0.2285776380716964,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark53(0.23355395855648586,-0.05491099656753676,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark53(0,-2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark53(0.24663977296187856,-0.921322610003902,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark53(0.2479538432432946,-0.7954634915869434,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark53(0.25363700597749383,-0.8945519995157589,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark53(0.2608606943048708,-0.8322632983775122,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark53(0,-2637.801920735288,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark53(0,-26.38929271623354,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark53(0,-2740.3465231517357,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark53(0.29988651952481243,-0.0013524191370403622,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark53(0.30584257740311216,-1.3828759961875239,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark53(0.3300414673816192,-0.25596946378521057,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark53(0.3758042241706647,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark53(0.3769764593066327,-0.4902202028897298,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark53(0.38928526781389916,-0.1291247109096303,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark53(0.3897405442282462,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark53(0.4063336517909515,-0.0779917723918393,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark53(0.4174739418621982,-1.4056416504620903,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark53(0.4202323751654764,-0.04869531256611026,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark53(0.42378902674211566,-4.5466111527997585E-9,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark53(0.43864661792577675,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark53(0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark53(0.44993937127307504,-0.3266707593228233,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark53(0.46458782177698943,-1.4736528599271939,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark53(0.48269169021399705,-0.18196558087902082,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark53(0.4836483269438361,-0.4465975513681719,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark53(0.48722968413903633,-1.869437075616322E-8,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark53(0.5033731691098967,-1.118685976301874E-8,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark53(0.5175598659020562,-1.3644468230569515,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark53(0.540833248817082,-3.5991167682843395E-9,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark53(0.562753102226303,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark53(0,-57.42448587531606,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark53(0.5811710393805356,-0.19889368239878458,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark53(0.5854828989536855,-0.7461736365095382,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark53(0.6040544862623577,-1.3925912771038738E-9,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark53(0.6041621198463876,-0.8034582164645485,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark53(0,-6.162975822039155E-33,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark53(0.6268003930543116,-1.191122516676768,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark53(0.6334119838265777,-1.1429141886758982,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark53(0.6375871390250865,-0.7722720669240182,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark53(0.6478852657617074,-0.07232525374062959,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark53(0.6561037059974524,-0.5253566637590605,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark53(0.6688442806591307,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark53(0.6701953360850581,-1.4641571545024927,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark53(0.6730493061553323,-0.5898124360684478,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark53(0,-67.32984807212985,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark53(0.6795020551731871,-1.4736194914317071,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark53(0.6801210492359857,-0.03208486782207709,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark53(0.6854088887775611,-0.2782960528950116,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark53(0.7163672792489137,-1.2740749566652312,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark53(0.7190672006260925,-1.2807764660317944,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark53(0.7333411174138824,-1.1180758638202268E-8,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark53(0,-73.47141940254438,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark53(0.7840773663602472,-0.2717631422642208,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark53(0.8128841350993667,-0.04143561726269618,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark53(0.8196264080581273,-0.6212376501496482,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark53(0.8331784638840753,-0.07825395155388765,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark53(0.8365699591807293,-1.4999999988407102,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark53(0.843013229850694,-0.49457899477216927,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark53(0.8433333462287464,-0.8140199702050523,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark53(0.8527159134598179,-0.3138903683225891,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark53(0,85.32316503335556,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark53(-0.8736984104660337,-0.20984967716280067,-1.0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark53(0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark53(0.8882199497629557,-1.0854249496844846,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark53(0.8914726258718559,-0.21496496710431312,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark53(0.9077582662017292,-1.0521961350702336,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark53(0,-91.02456713749677,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark53(0.9273915366415366,-1.2914539715664697,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark53(0.9673597603520534,-0.5384258901185515,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark53(0,-98.94026443927861,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.0011517294582906923,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.0012268245925189125,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.0016585715159796936,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.006757702307079394,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.007256548111607142,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.011065044202612548,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.011584207792999512,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.017606242682326967,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.032283963530884356,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.03373123363076205,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.041793268236918174,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.04208856883383029,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.0591114461686628,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.06008630297821106,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.06960662961067898,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.08408098307230061,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.08428133753713254,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.08563202338382203,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.08571345419287506,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.09418429939633638,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.09957141348650067,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.10034966020711705,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.11988275186868491,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.12502836869651435,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.14403025797683755,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.153713638579161,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.1540004040695652,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.17077760189577695,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.17124516302288395,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.18623609024865706,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.18698426654229386,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.19517491821372435,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.1979750275194192,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.20801145907345203,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.21032907291502617,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.21326013917786213,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2136926876060583,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.21547270870664187,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.22014440555680312,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.22640476573555351,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2269246082279095,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.23273574340192857,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.23698787042592118,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2392620524831207,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.24560952342579678,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.25032224190098373,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2569341529048059,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2593329975190082,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2694820122972968,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2789689169199647,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.27997102657431094,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.2853475455336447,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.3095076750056661,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.3096075865429153,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.33911188435527695,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.34958427436493916,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.36597462984475737,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.36979357966039417,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.39789534923131586,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.4105790345897429,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.4289870294613114,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.4484374245469256,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.4873946831624212,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.4877030256344328,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.4948330799612819,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5116655843460415,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-0.5205374645963412,-0.9794072160264595 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5352049254272189,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-0.5473390368712694,1.0000000000007496 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.578686052326309,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5815685206743111,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5929359462747504,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.5989857292012077,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6023883388183728,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6121175614368312,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6385544073903269,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6706168588025898,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.676218063197872,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6791795504160697,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6916220077721922,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.6949147670745598,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-0.7084905976689354,-1.0000000000000002 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.7238525603689651,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.7541648988321388,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.8141867950099608,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.8228315317952046,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.8462573192104949,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.8702619360034237,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.894050579291103,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.902521958558888,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-0.9174432844942308,1.9306765773157792 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.9322488442784316,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.9329927468607221,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.9711465954701071,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-0.9934862710933212,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.0076016431146912,0.739890766264752 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.0098972160886088,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.013297344389474,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.042333445454907,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.0621513952044928,100.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.0879083773977434,-1.0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.0971160049841553,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1008183857134968E-17,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1040700367361573,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1170277375625655,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1239929366673853,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1368741079850926,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1404582282226103,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1464079279103965,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1633085989214154,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.1740905442234587E-5,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.183378771075243,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.2519174725014552,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.262715859032666E-7,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.2709930293552536,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.2755796299164364,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.277959784529156E-8,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.2846597594765945,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.2902115307803237,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.3145163715280395,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.3167466144525828,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.3244910987909404,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.3533310647518884,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.3711467248531273,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.3877787807814457E-17,0.06255300297691396 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.391390502345115,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4388813202156463,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4507890946614386,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.459473324782211,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4676466278071927,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4929937161689095,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4959484933527236,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.497271082723964,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.4999989630059707,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.499999988450969,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.499999990749113,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999971073579,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999255864,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999605895,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.499999999999992,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.499999999999993,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999933,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.499999999999999,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.8924766599197294E-6,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-2.3491083730349005E-8,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-3.111911316685853E-8,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-3.3252042867382635E-8,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-3.4963877329011497E-9,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-3.552713678800501E-15,100.0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark53(10.003936988698683,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-4.930380657631324E-32,0.9999999999999913 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-5.45974832737852E-7,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-6.065151450910757E-9,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-6.699638738713352E-9,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-7.54420324054092E-17,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-7.61687609688114E-9,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-8.469879587752706E-9,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-8.881784197001252E-16,1.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-9.625924913749036E-10,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark53(10.024120575472836,-0.10130311100647615,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark53(1.0040634281596823,-0.010239441377863326,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark53(10.093146197294775,-0.2898761091563469,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark53(10.098616029994437,-1.0898978271992338E-4,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark53(10.102184562686716,-0.745626410761858,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark53(10.103314666599076,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark53(10.118601667457135,-1.1537483653611313,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark53(10.140082109577033,-0.8984506796244744,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark53(10.174285311092495,-0.3440562485796099,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark53(10.185654183004303,-0.3703198524331679,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark53(10.1941565597849,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark53(10.264612478175819,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark53(10.268851610121509,-0.21343954990972236,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark53(10.286085355019964,-0.7917580640602182,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark53(10.291769477878244,-1.4999999850851158,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark53(10.298722409032024,-0.6594561993238985,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark53(10.300503340262708,-1.3730624301257564,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark53(10.350061631696477,-1.499999999999997,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark53(10.373548046877971,-0.5115779554699966,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark53(10.397557663549026,-0.11919515070587504,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark53(10.413054837269996,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark53(10.437691174139188,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark53(10.465097712706074,-3.4673930672306806E-8,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark53(10.468602568468377,-1.49955309942674,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark53(10.530634971327373,-0.03762155295666456,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark53(-10.595041317774442,-0.6919630746596604,-0.0517856211889986 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark53(10.650430809958934,-1.2317606235348417,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark53(1.0663865158950439,-0.018006564344747344,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark53(10.687934576115026,-0.8975547809280755,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark53(10.709377854383995,-1.4733192061275648,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark53(10.713836081356831,-1.3136763150122066,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark53(10.751437955464072,-3.066834025032334E-7,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark53(10.802704787295397,-0.9551038674083172,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark53(10.85760128038946,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark53(10.858461048354144,-1.4999999999995364,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark53(-1.0862548453388217,-0.7981863099986607,2.778448436856347E-163 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark53(10.890206184451046,-1.3523023306762827,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark53(1.0894036764643173,-0.871085259381484,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark53(10.935360425198425,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark53(1.0944888876767522,-1.1747205875945075,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark53(10.950600719351215,-0.7181451050592802,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark53(10.973080840579435,-1.657096341539987E-4,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark53(10.976376004809168,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark53(10.98787754482315,-1.3812740702255013,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark53(11.002343692397119,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark53(11.003347611225138,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark53(11.025673601177646,-1.4999999997965254,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark53(11.045406945317254,-1.2947496176368087,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark53(1.1090685000215181,-2.021669914608024E-8,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark53(1.1102230246251565E-16,-0.11614660543470451,95.32087941709715 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark53(1.1102230246251565E-16,-0.3084098301060008,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark53(11.115392088133476,-0.12231761877946506,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark53(11.136030599425254,-1.3400248388404208,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark53(11.17293174679564,-0.9786389311469701,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark53(11.21853691175383,-0.36783481377704863,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark53(11.21893815749803,-0.44402434875178187,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark53(11.234836880229366,-0.15398647376319996,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark53(11.242268191972265,-0.41014912994256286,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark53(11.254899350683601,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark53(11.25914153032268,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark53(11.345645469083008,-2.1304339897597995E-7,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark53(11.359268023733833,-1.1003559461318986,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark53(11.416061018106497,-1.3964971356701372,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark53(11.436441440664652,-0.6540834050729205,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark53(11.507479093885479,-0.8070042542687736,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark53(1.1516096155767688,-0.843364845592171,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark53(11.536807613167753,-1.234195845327422,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark53(11.546072208719082,-0.0026459291870191137,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark53(1.1646977461406918,-4.3294561544907816E-10,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark53(11.649678378735835,-0.23186474565013904,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark53(11.65157591201578,-1.4999999996328448,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark53(11.663448667037727,-0.9523679668082252,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark53(11.68814691491771,-0.16395780752000366,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark53(11.719126041991771,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark53(11.788930536865337,-42.81262437685187,30.347099583473693 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark53(-11.804569014243143,-1.4073747609981853,94.45493488299726 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark53(11.900433379282234,-0.7437907285983334,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark53(11.915410024644359,-0.3292936536095823,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark53(1.192255527673396,-0.6690018060499953,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark53(1.1933432416359686,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark53(11.934313122155487,-1.3468528089655933,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark53(1.1938525640158515,-0.1501116244074936,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark53(1.196118751856858,-0.8871997357418024,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark53(-11.993195494362315,-1.242449659732467,-0.9999999999999997 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark53(11.993410070456846,-0.500749593926577,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark53(12.008763612463618,-0.8726262662532669,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark53(12.022389267700248,-0.05008595956922246,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark53(12.02762022783321,-0.438477498221431,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark53(12.096552516389394,-1.280328759030585,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark53(12.110757992694872,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark53(12.111921093931159,-1.2462450771281366,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark53(12.144646631860994,-1.357002161894027,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark53(12.157556723818175,-0.09867298035279382,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark53(12.179719231707466,-1.429949164856552,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark53(12.212488262439704,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark53(12.244086153816564,-0.9868867699857634,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark53(1.2252069613741412,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark53(1.232715156717967,-1.1368205054191256,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark53(12.384236291360303,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark53(12.415144969635765,-1.499999991426038,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark53(12.472220366632712,-1.077420238932472,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark53(12.501019585960185,-0.3289818596777616,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark53(12.502164652324083,-0.7817771808987475,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark53(12.505691981306072,-0.7965109658626233,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark53(12.52532005693404,-0.04892259981829816,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark53(12.5813906849207,-0.15871743282740935,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark53(12.59293231481422,-0.5910086163528057,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark53(1.2650614785441974,-0.5860510075824408,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark53(12.653249955893699,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark53(12.695498671421854,-1.3213452386774144E-8,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark53(12.71116687244178,-0.8364813982846542,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark53(1.2748607963847123,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark53(12.782110647060623,-0.8758464241324482,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark53(12.799244751481911,-1.2877379673697207,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark53(12.799431939692482,-0.020977083799767038,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark53(12.809812187371008,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark53(1.284368478012592,-1.8150300216435076E-5,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark53(12.863518578233354,-0.6026599683201539,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark53(12.881391201791502,89.41638835422089,66.19295070107631 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark53(12.9004435501177,-0.729739237560409,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark53(1.290955446083757,-0.16651058198323654,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark53(12.913150472495303,-0.727140885556885,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark53(13.054244535846777,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark53(13.067993161797602,-0.5788748093671656,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark53(13.071733633898575,-1.2319544178016457,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark53(13.083890854006032,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark53(13.116422264687387,-1.298428094212241,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark53(13.119389132497508,-0.21657361112713147,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark53(13.158425139878585,-0.4903849884947603,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark53(13.163134887486308,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark53(13.339367121155618,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark53(13.354057906659264,-0.8298311318904723,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark53(13.442147331599983,-1.3886295061248233,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark53(13.48038273918229,-0.6555307105265376,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark53(13.50227771735938,-1.364538906308573E-9,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark53(13.547084192578467,-1.2741436656546767,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark53(13.59796388641088,-0.8316600294496084,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark53(13.68132766723846,-4.4713896846659335E-9,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark53(13.767647022711776,-1.4837033264138624,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark53(13.793455940527522,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark53(13.79854981226083,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark53(13.805927878404528,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark53(13.894068611638382,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark53(13.906883968533165,-0.13386832531915616,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark53(13.910259846948023,-1.2344455214041972,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark53(13.955824842041608,-1.360437376350645,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark53(13.974920033053923,-0.634097634407085,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark53(14.004932815147114,-0.8428681000823262,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark53(14.079207071944511,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark53(14.143689454786445,-0.13262844111248095,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark53(14.16587956275646,-0.5655817140829098,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark53(14.167783978095745,-0.6485824526810436,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark53(14.196331851086484,-0.5168875562426081,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark53(14.198138144047066,-1.4999999984957912,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark53(14.223247534858217,-1.1393602613027909,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark53(14.226274352289451,-0.5817709793220813,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark53(14.257228009582143,-1.7744890803418342E-9,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark53(14.270752958675411,-2.7684304164553715E-8,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark53(14.290361655619966,-4.033457305076228E-5,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark53(14.30125385282895,-1.2827088399887572,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark53(14.31250054335366,-1.311888757967811,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark53(14.320971489001224,-0.9501834822599022,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark53(14.336465907515432,-0.0015080230977986275,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark53(14.350687798406751,-0.1283301583370393,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark53(14.383818745367122,-0.9660275819393358,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark53(14.402993523304474,-0.6296056264576606,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark53(14.418560279910398,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark53(1.442971755450074,-0.36217426566117084,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark53(1.4433881034631355,-1.499999999452804,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark53(14.442888533991962,-0.5119313327943235,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark53(14.490720337184982,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark53(14.495067098377262,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark53(14.515118512167078,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark53(14.51955362248465,-1.4999999999999298,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark53(14.61439262606568,-0.07747677715958012,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark53(-14.617755406103415,-1.0557357442849535,-0.9915013214045222 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark53(14.657178829179522,-0.22408890148257843,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark53(14.661399932437405,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark53(14.705584043509276,-0.4993854745195989,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark53(14.762252212292239,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark53(14.764284168473353,-1.263219551011233,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark53(14.766782978449257,-0.93787337280442,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark53(14.780309134635331,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark53(14.792233662681886,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark53(14.845912114180464,-0.4916993222163808,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark53(14.849227040377386,-0.8847069616198731,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark53(14.865554125633615,-0.6844222715707957,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark53(14.868305126797793,-0.6626648225983183,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark53(14.88182655782421,-1.1799605739001915,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark53(14.88972417662957,-0.771864396659339,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark53(1.4893252592964643,-0.6527827820947742,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark53(14.916036016956626,-5.19248749564797E-16,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark53(14.922161140032898,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark53(14.9242914894519,-1.2563548291309425,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark53(-15.010072041229225,-6.94648238558267E-10,39.95998440919616 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark53(15.024668663275804,-1.0503992062000744,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark53(15.06840346103968,-1.1446586551146805,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark53(15.06980470455451,-0.966546837011478,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark53(15.077830209380494,-0.7699799866497007,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark53(15.126165192256614,-1.1626250232015325,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark53(15.135098117299805,-0.3718738185107724,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark53(-15.16696117995055,-3.283770093047364E-4,0.023808053262771176 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark53(15.209344651858814,-1.4999999999999467,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark53(15.22067715259032,-0.30218683785429784,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark53(15.229415186758672,-0.7958865032544544,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark53(15.238414287944526,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark53(-15.260593158206147,-0.7646325680698265,0.3584230965730161 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark53(15.292622266437801,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark53(15.294636360437579,-0.36777963860241947,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark53(15.302147905180803,-0.08939408022754947,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark53(15.31621299014732,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark53(15.388249541412065,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark53(15.39181159316614,-0.5376408357016011,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark53(15.405947831191927,-1.157669657390901,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark53(15.423087136898815,-0.854065938777552,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark53(15.428891888117505,-0.2326600035488955,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark53(15.429247997056649,-8.198097967994087E-9,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark53(15.434506806967189,-1.3620700015408099E-8,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark53(-15.46211932849842,-0.2682946002728426,1.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark53(1.5466503325961602,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark53(15.483933989669069,-1.2848341373845784,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark53(15.51664069726641,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark53(1.5554781099839943,-1.064285964157822,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark53(15.557302247422044,-0.33259766273074926,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark53(15.574097288424683,-5.132122517557618E-8,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark53(15.606317164585516,-0.4859359400564731,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark53(-15.632396027353735,-1.4999999999999982,90.14499248421649 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark53(1.5645669936595397,-1.0830716519155423,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark53(15.65240576780866,-0.9289020120257767,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark53(15.662290688771893,-1.4999999969133362,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark53(15.671591725465547,-0.7868834435319698,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark53(15.684114403721324,-0.2473788615840533,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark53(15.684987061640783,-1.4999999999991935,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark53(15.688140265367513,-1.473636115965689,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark53(15.70581159116604,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark53(15.72071853583917,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark53(15.75524449148212,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark53(15.764090472160234,-0.5393713723004083,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark53(15.773805500517495,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark53(15.81064421844653,-0.5735415889595998,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark53(15.820431319364337,-0.46182871384199964,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark53(15.827858912682675,-9.841903028398049E-9,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark53(15.82908749753041,-1.2640189391376575,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark53(15.836370614920533,-7.905397836687641E-8,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark53(15.851871364848089,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark53(15.881352413657382,-1.194890810496613,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark53(15.886519328588818,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark53(15.896262083840057,-0.31590907793125744,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark53(15.898786441029927,-1.2159159968318738,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark53(15.921309018003413,-1.2048979583736417,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark53(15.926351090557878,-0.5940539942835712,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark53(15.933378789913762,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark53(15.940063740166948,-0.21654004766437074,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark53(15.957564116853334,-1.3558947799031387,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark53(16.020683655491645,-1.000901430755194,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark53(16.039543311362667,-0.18198208312800546,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark53(16.06959649257632,-1.2119154157490877,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark53(16.07707957025151,-0.8789537463371473,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark53(16.14467384102842,-0.6370354581621466,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark53(16.175452026388044,-0.381648683326838,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark53(1.6189352796768968,-0.01938799768059818,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark53(16.21346813070222,-1.381624006470176,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark53(16.246616110185702,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark53(16.256931212086094,-0.7415930272476303,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark53(16.257596842477312,-1.1638758974770926,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark53(16.29309647656263,-1.3576305092397547,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark53(16.29859243266713,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark53(16.30878541210577,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark53(16.315616649975254,-1.499999999999977,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark53(16.33614020020329,-0.41254030404959563,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark53(-16.3625731829095,-1.4999999997449642,-53.95661475895326 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark53(16.40629831589097,-0.31227802588131226,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark53(-1.6418147205193505E-288,-0.9860487370440656,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark53(16.419276308318455,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark53(16.422535911384344,-0.08650759409250064,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark53(16.47285589120358,-0.20389211935652796,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark53(16.500526178179776,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark53(16.50368946637689,-1.1868958870645248,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark53(1.650960188471223,-1.4999999671506994,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark53(16.65341026972385,-1.4999999999999813,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark53(-16.685334887371102,-1.4283304034021558,1.0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark53(16.68728881434112,-1.3552839739642605E-8,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark53(16.716022436189377,-0.7614931888925329,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark53(16.733177809577285,-1.0683430454580929,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark53(16.841466879964415,-1.4636802007633136,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark53(16.853480057045438,-1.3870991139923294,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark53(16.858478459267715,-0.018134307652786674,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark53(1.6917924702947431,-0.7488506144763765,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark53(16.96458765898457,-0.22451956224153946,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark53(16.974703566861066,-0.3482982114070978,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark53(16.990479490389674,-1.0246511616806346,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark53(17.021105488410317,-0.8714216932407766,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark53(17.030389155826548,-1.2721274126881288,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark53(-1.7075306161500947,-1.3212330270550343,-50.90363762876224 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark53(17.093244930470537,-1.2193752874508692,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark53(17.104698180663007,-0.6245406242681604,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark53(17.120231644202704,-0.13937999075723928,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark53(17.190718126184144,-0.6425701540433782,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark53(17.25461857739181,-1.426817244312763,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark53(-17.267525890949997,-0.9400320475569188,89.70753369560884 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark53(17.318305364300866,-0.41474247304025375,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark53(17.340939576796615,-1.2058799090438101,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark53(17.371932551940517,-0.204608212408246,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark53(17.395114658474768,-1.1091350552861614,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark53(17.40351300474245,-0.6003651262096494,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark53(17.491829893437185,-0.30205976378605237,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark53(17.551033147508292,-0.9512876692937424,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark53(17.56409068096623,-0.3016236954471335,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark53(17.590080081020304,-0.913834806648035,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark53(17.623358463611392,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark53(17.65292397835662,-9.058667188278006E-10,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark53(17.667394628715655,-1.3727374076696819,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark53(17.676914155238716,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark53(17.69017449992101,-8.067518587320811E-5,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark53(17.716976024302525,-0.9150139205272115,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark53(17.742509583577032,-1.2575582093227693,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark53(17.760890758368305,-0.1757772308251333,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark53(1.7763568394002505E-15,-0.025272830285175463,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark53(1.7763568394002505E-15,-0.3060015494156829,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark53(1.7763568394002505E-15,-0.5233461044072456,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark53(-1.7763568394002505E-15,-0.7052513963184506,-74.08011867968531 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark53(1.7763568394002505E-15,-0.8765193740046535,1.0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark53(17.837934398944057,-0.04882056669579171,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark53(17.841327866413522,-0.7054660732380893,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark53(17.84678668459449,-0.2682876169936999,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark53(1.7940048411875864,-0.9722716459150328,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark53(17.943151870346924,-0.37398024303336896,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark53(17.968283266970467,-5.829735251851871E-7,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark53(17.994858080379743,-1.2271334162233813,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark53(17.999855071382044,-0.18626528363786954,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark53(18.005052679605576,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark53(18.00838567851926,-0.9634480303469708,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark53(18.011342409870167,-0.37848905976038294,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark53(18.051810527656386,-0.3972806283697423,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark53(18.06011885746824,-1.4999996504152355,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark53(18.107274533688724,-1.499999999998801,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark53(18.108741469363782,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark53(18.10988550940513,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark53(18.11458724734497,-1.3148298972274428,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark53(18.120987290000826,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark53(18.178549743500177,-1.116325025339589,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark53(18.194633041453628,-0.34990501118401873,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark53(18.20662852860613,-1.4999999999999805,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark53(18.22311137460504,-0.13213887787404932,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark53(18.24958497138354,-0.9567033501962214,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark53(-18.25271664863852,-0.6961757222348756,-1.0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark53(1.826867584880418,-1.4999996165675238,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark53(18.364283703612983,-0.13286531208346908,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark53(1.8377425617465208,-0.6790518427463504,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark53(18.40391074272741,-1.4999999450923993,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark53(18.420284028555614,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark53(18.43375810197842,-0.07574093118898784,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark53(18.451414930230015,-0.5264912189653375,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark53(18.46944208567075,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark53(18.498510436096765,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark53(18.534725967248477,-0.20463804374667482,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark53(18.536352621558834,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark53(1.859323287369108,-1.1679388638514712,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark53(18.67206816371651,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark53(18.697678632802074,-3.926029047039776E-8,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark53(18.705209676523076,-0.29266247299952514,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark53(-18.709952750495134,-0.8607302152443069,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark53(18.710694864422663,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark53(18.72023483653622,-0.7885090287210612,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark53(18.754260591894308,-0.7356543682339947,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark53(18.845732562311255,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark53(18.861260613435135,-1.1667406363368424,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark53(18.869952049404077,-0.4843278098898488,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark53(18.896325852115453,-2.2538313730655946E-7,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark53(18.90651380713861,-0.9666757696836927,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark53(18.90914194926318,-0.5987803669681631,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark53(18.940824707395272,-0.8493902880846252,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark53(1.899793290735758,-1.4591549138269073,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark53(19.004086940432785,-1.3820280200509831,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark53(19.011473129655645,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark53(19.09066459276356,-0.3215871602971333,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark53(19.095774740137955,-1.063640793796114,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark53(19.132170398463714,-0.7163385567807694,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark53(19.145661268743435,-5.67960683017355E-9,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark53(19.15043916993595,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark53(19.205019267028774,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark53(19.205992584565013,-0.6720340981441955,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark53(19.22505263901293,-1.3211993468971457,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark53(-19.24838699003033,-1.2196482332718313,-1.269753126991383E-8 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark53(19.254074563681158,-1.338795531344374,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark53(1.9258239480718373,-0.30193449337308476,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark53(19.31338486898393,-5.296795785787922E-7,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark53(19.337322181277898,-0.9504375889693402,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark53(19.360941708749024,-0.09886769951071983,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark53(19.368396957542572,-1.282645712400992,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark53(19.405335844587725,-5.439742301791331E-10,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark53(19.422628097735696,-0.3414302030566465,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark53(19.423730647727837,-0.04732374586690824,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark53(19.474712381518856,-1.276993610336671,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark53(19.48318096998743,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark53(19.516640508245487,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark53(19.545636815187194,-0.28417984825915,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark53(19.56193444701735,-0.9356926490531947,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark53(19.585409961744986,-0.43368293126664437,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark53(19.592605004537774,-0.22662442412621076,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark53(19.594782159105222,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark53(19.603579922809672,-1.2682420175606377,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark53(19.644416125742964,-1.3305861463082067,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark53(19.67706851063751,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark53(-19.68302937363441,-0.04690681386567921,0.05877209375269876 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark53(19.689518783988518,-0.9672279867516664,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark53(19.703447620278997,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark53(-1.9763977418950853,-0.02212426575922044,-0.5877832859472778 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark53(19.768585620288633,-1.0978856107129253,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark53(19.798837046861053,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark53(19.799816948444303,-4.8144629394275886E-5,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark53(1.982184745089718,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark53(19.843416058903372,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark53(1.9856042544139143,-1.4999999999999503,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark53(19.889481734972627,-1.4999997546777095,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark53(19.897523620613654,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark53(19.90308842770665,-5.1776451272827567E-8,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark53(19.91378691651535,-1.1357400178569925,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark53(19.920387590202594,-0.006035464312782013,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark53(19.964347024511703,-1.4999999995228834,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark53(20.043979359183076,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark53(20.066145471465163,-0.0958592402419356,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark53(20.10038928167586,-0.8591253574027189,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark53(20.104786416751082,-0.019350937129635426,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark53(20.163874349968154,-0.30189645605514037,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark53(20.173965301548733,-0.9533847980668781,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark53(20.201384837046305,-0.9512222418002798,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark53(20.211333676258484,-1.2428106166969703,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark53(20.22238457528269,-0.3330838043916913,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark53(20.236141389311058,-0.04794618688698549,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark53(20.26066461379365,-1.2250498464443482,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark53(20.268173967859454,-0.020746429289857815,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark53(20.322640889623628,-0.03251204051757384,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark53(2.0327100827593414,-8.564388860392266E-9,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark53(20.341164726946687,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark53(20.35557081121084,-0.603107228925063,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark53(20.391986115603558,-0.3004612874109256,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark53(20.42417228101163,-8.985819543010098E-7,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark53(20.436859448902297,-0.20251072422417327,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark53(2.0480787693126388,-0.286467427329157,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark53(20.49665028520684,-0.4211688799712512,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark53(20.509080494548023,-4.4392972738793245E-10,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark53(20.52021583059248,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark53(20.582897883602243,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark53(20.610085871774984,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark53(2.064755137464317,-0.5133915800872351,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark53(20.661998522725703,-2.136856753347482E-9,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark53(2.067080577007218,-1.358132470603664,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark53(20.699442145833487,-0.23179143437199912,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark53(20.706356644003066,-0.2833832083472281,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark53(20.709413235891333,-0.4838267489028141,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark53(-20.720670172956154,-1.499999999965925,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark53(20.74303095596784,-1.4038241785604413,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark53(20.750788986338264,-0.19424164364313734,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark53(20.76064517102769,-0.7272576147915357,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark53(20.779343796192222,-0.2265318878044783,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark53(20.815922319940967,-0.8202286400716048,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark53(20.833275185974987,-0.6536611744570995,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark53(20.88533293275381,-0.2873488224720684,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark53(20.928732188244048,-1.499813689402884,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark53(-20.953817954374998,-0.689051116869976,0.047439602882251075 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark53(-2.0965715389804203,-1.4999999999999964,-1996.3697400407498 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark53(20.97750571624823,-3.641516692856792E-8,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark53(21.032773692065547,-0.08659970340915812,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark53(21.064557103971143,-0.09776264005686208,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark53(2.11025272809205,-0.042745469018901194,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark53(21.11070559883798,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark53(2.115239836172094,-0.7987983485424621,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark53(21.16926890255428,-0.7107710446489017,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark53(21.227291171692713,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark53(21.242151867181548,-0.19758795002388396,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark53(21.308918480673384,-1.245460137277531,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark53(21.33618841879976,-0.3106545499987465,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark53(21.354952810141143,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark53(21.390398737541183,-2.934513107977296E-9,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark53(21.40078881784111,-2.157591526504707E-8,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark53(2.1404388173910186E-196,-0.005366562493381869,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark53(21.42323039198395,-0.7530987930687543,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark53(21.46220680771241,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark53(21.479676281014164,-0.7686069704328845,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark53(2.151153741840688,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark53(21.538561166959596,-0.6022021501560402,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark53(21.573419294410677,-3.9153601929465925E-9,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark53(21.582707840011835,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark53(21.59146421589635,-0.5900094034844514,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark53(21.595453796273176,-0.05877774707343114,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark53(21.59869165262036,-1.02816220120038,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark53(2.161315957001662,-1.3036614982087293,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark53(21.62975816181398,-0.9178486508962322,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark53(21.654480890006838,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark53(21.68567798698968,-0.12675900204591636,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark53(21.696427816345846,-1.4711511406547206,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark53(21.697184652610275,-0.8850114874459525,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark53(-21.70774134124747,53.25712901400183,66.81893556388823 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark53(2.1712960765126113,-0.5437704458904307,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark53(21.724245429026467,-1.1996458646506483,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark53(21.73539346309434,-1.0454385029544926,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark53(21.74960826842944,-0.5746202291350642,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark53(21.762371335711883,-1.2725325305205488,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark53(21.76512397347274,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark53(2.1772291310851735,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark53(21.81056027956398,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark53(21.83964582756174,-1.2512414757700026,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark53(21.863142403658898,-0.532380839247383,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark53(21.93355194077276,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark53(21.935815588380173,-0.29914225773523784,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark53(2.1964175100312815,-1.3377389389340753,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark53(22.046364559434522,-1.2594561085663685,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark53(22.09734917580882,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark53(22.099456150594634,-0.4350302225795657,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark53(22.119026591232014,-0.12145513986168766,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark53(2.2121312345705384,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark53(22.127430698936323,-0.3537332970954448,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark53(22.138919685690105,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark53(22.145175338296227,-1.499999999998714,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark53(22.18980813548761,-0.46347302172409854,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark53(-22.20979628913862,-0.7538727465945101,35.449017350649896 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark53(22.246733285244332,-0.2992287743019837,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark53(22.269350124218107,-1.266629107542637,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark53(22.281460925638342,-0.5845739596644854,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark53(22.287736411964985,-0.16611416355531894,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark53(22.309690900734363,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark53(22.395058332477635,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark53(22.436474651492897,-2.324628926234456E-9,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark53(22.462100946889432,-1.1998673241628444,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark53(22.47256384867264,-0.9236864811880556,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark53(-22.504581131178902,-1.0749859319979376,-0.06255302607238233 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark53(22.512381415809607,-0.13807982258865614,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark53(2.2518314026460615,-1.1161918861673676,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark53(22.55433085959038,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark53(2.2598872792996465,-1.2008633783325506E-9,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark53(2.26087610120625,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark53(22.621998892262923,-0.18355175734142737,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark53(22.631137689861717,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark53(22.646577189533957,-0.21402795362901017,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark53(22.657103753797372,-0.9473097757326956,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark53(22.715299688924464,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark53(2.2717723284564304,-1.4914691330798304,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark53(2.2750841245915154,-1.490569705917025,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark53(22.75554388469252,-0.8273755923314958,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark53(22.769118009066887,-0.71270054129536,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark53(22.771731239478555,-0.2566706158983578,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark53(22.77809585054689,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark53(22.812435912130553,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark53(22.87581973070067,-1.0978161562966449,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark53(22.897109141751965,-1.089048805163809,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark53(22.917455580741052,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark53(22.919143970788063,-7.491415443265764E-9,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark53(22.923718521879138,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark53(22.945408868974937,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark53(22.959015167843617,-1.3006969165504485,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark53(22.965090836466118,-1.4980427426117542,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark53(22.976302245894246,-0.5443738461687904,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark53(22.99228642340661,-0.31492375196453437,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark53(23.008140968530327,-0.3206408017002218,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark53(23.00985684161958,-0.2141775587812873,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark53(23.02271965745786,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark53(23.039443835406196,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark53(23.04539125189497,-0.9418865005105204,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark53(23.046641372332815,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark53(23.05629544761642,-1.4999449143308607,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark53(23.059435915707155,-0.5041632769298321,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark53(23.0596213581046,-1.4995048125109294,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark53(23.07627706693494,-0.8964037813050931,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark53(23.09167587675834,-6.874486877432086E-10,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark53(2.310035279751221,-0.1920432705930728,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark53(23.125866811016664,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark53(23.152781677566452,-1.185836563344223,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark53(23.15579963626526,-0.8950472909830823,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark53(23.16842287937628,-1.4999999999050107,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark53(23.191253669751347,-0.009977952691158976,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark53(23.20575479301785,-0.8539565872105761,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark53(23.234995713172708,-0.010471037151930318,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark53(2.3253026213975656,-0.34831330372216507,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark53(2.3254606346532256,-0.5706286861338441,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark53(23.27683597188141,-1.315855650190473,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark53(23.286329074475148,-0.580862618945746,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark53(23.314362657382702,-0.4846626916178853,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark53(2.332510759078417,-1.2753539646396916,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark53(23.32800721803916,-1.4436339893324566,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark53(2.333442196812257,-0.5309998326392273,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark53(-2.3356952962205213,-0.7389906701594351,1.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark53(23.366580574235016,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark53(23.37644775833592,-0.05708615443467213,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark53(2.343021852277232,-0.9461466596676222,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark53(23.43760809901778,-0.7001216440654521,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark53(2.343818223335318,-0.14480736041797604,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark53(23.45183462667073,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark53(2.34952810541256,-0.87969464027341,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark53(23.5061833035084,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark53(23.523464588280717,-0.7695382716801464,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark53(23.530910324061075,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark53(23.535798227842754,-2.1008514528677514E-7,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark53(23.54267617068946,-0.9386352477809314,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark53(2.369312721953335,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark53(23.70441352722632,-0.696288079570115,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark53(23.70541410728488,-1.2901532472688766,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark53(23.72879876493694,-0.15577716724171964,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark53(23.74125983944488,-0.5536054284808443,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark53(23.75409009278819,-0.20018497461407492,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark53(23.760819363757832,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark53(23.779590707316977,-0.6357052043949496,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark53(23.863549950690725,-1.0524031539535854,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark53(23.866941649885874,-0.6134461620190546,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark53(23.870810724057627,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark53(2.388137872971143,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark53(23.888262187200453,-1.3810594093326267,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark53(23.93400958074229,-1.3758505205090765,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark53(23.949392243854298,-3.232441439962476E-4,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark53(23.96134556779393,-4.118514459935756E-9,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark53(2.396311037895387,-1.318557160804976,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark53(24.006748283887475,-1.3450054170663037,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark53(24.02950277716068,-2.9277963808839734E-9,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark53(24.03351729032738,-0.20995390644453948,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark53(2.4049571620851973,-1.4999999999748694,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark53(24.051196025565474,-1.005331426029155,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark53(24.073610506242844,-0.03192664540753376,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark53(24.08553598841931,-0.7138495816728594,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark53(2.4087846993454605,-0.9500218698970462,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark53(24.105722853774964,-0.792182455136095,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark53(24.125593153679745,-1.280510108228586,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark53(24.126948646043772,-1.2634173768626265,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark53(2.413616950723285,-0.6318063699530456,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark53(24.144336819089972,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark53(24.184341968398954,-0.9199563391988678,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark53(24.186268424225982,-0.1313962742392202,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark53(24.20145025074882,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark53(24.26295613146263,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark53(24.265940904990067,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark53(24.27315069768592,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark53(2.4305669824526746,-0.7175781739445171,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark53(2.433654600405511,-1.4724554784322939,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark53(24.37114605338624,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark53(24.38305195973132,-0.9126730975261378,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark53(24.383070960779293,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark53(24.42967941278493,-1.4822084598841951,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark53(2.4443087807046164,-1.372177929663074,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark53(24.45457505171223,-0.30935443710992105,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark53(24.469349159066013,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark53(24.503010527818958,-1.4999999999999822,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark53(24.519375503787373,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark53(24.527206485600203,-0.07912236723609342,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark53(24.535132519427606,-1.427777728170574,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark53(24.546235054206946,-0.03417449342980383,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark53(24.553524856168366,-4.569757027071354E-9,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark53(24.561409441930195,-1.4999999999997993,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark53(24.625066304313208,-0.5620638235571074,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark53(24.654609964335947,-0.7634886143944293,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark53(24.684088818748407,-0.08626059662679708,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark53(2.4687606337206347,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark53(24.69435634575592,-1.0552464965672743,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark53(24.700626028360688,-0.8093021894903423,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark53(24.716241187274562,-0.9976837363205249,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark53(-24.725959416389955,-0.47373901122340456,-1.0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark53(24.728406251216995,-1.4589979372532866,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark53(2.484167287534717,-1.1075718901400933,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark53(24.865644078375713,-4.7774626476977676E-5,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark53(24.883865209055614,-0.8785936666860668,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark53(24.919578145950915,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark53(24.98334408122318,-0.27546179638130375,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark53(2.50422961792977,-0.3182133139215928,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark53(25.07100614882718,-0.7657505627044163,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark53(25.081151442225007,-0.5345176043169011,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark53(25.0899141332548,-0.8251023844879946,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark53(25.10734729227653,-1.4856143222901312,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark53(25.12930312316699,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark53(2.5138625674487827,-0.4129465334529957,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark53(2.51571691993324,-1.1437104377720275,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark53(25.171983098408717,-0.43698622179615965,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark53(25.195842416620494,-0.6109703134530318,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark53(-25.24290007920925,-1.1155080579895264E-4,0.15826831584535037 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark53(25.422297588484668,-0.11522140741615772,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark53(25.43884846368188,-1.3651028741465643,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark53(25.451489301879228,-5.768981524945505E-9,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark53(2.5482160591135994,-1.4657925760181598,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark53(25.48227138179074,-1.1541519334311818,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark53(25.49951647102546,-0.329038133324449,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark53(25.531641755218956,-1.499999999999952,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark53(25.53972331456673,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark53(25.559184142105067,-0.12180933161678198,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark53(25.585890436963638,-1.3177926000445268,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark53(25.604045660197272,-1.441848276793291,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark53(25.618717534035852,-1.093978563731099,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark53(25.63716590719818,-0.4059396882498534,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark53(25.65808538964079,-0.033889923523188537,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark53(25.664968644578785,-0.35912470547405784,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark53(25.66798298853827,-0.3243706782199247,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark53(25.670369524524418,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark53(25.671713540416345,-0.23638218312337342,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark53(25.678327487609614,-0.40333271136162985,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark53(-25.69188065028181,-1.4999999999999998,-0.48114389648196015 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark53(25.699484454666127,-1.4734789484642192,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark53(25.729027758852354,-1.466427542074399,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark53(25.746916654264346,-1.2450534213094322,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark53(25.74716893416616,-0.5152537467154743,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark53(25.757561196173512,-0.044101718454164995,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark53(25.757837932737612,-0.06636998335960143,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark53(25.765429468208055,-0.6503420858299673,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark53(25.803121856639976,-0.4239682857164692,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark53(25.804455623157224,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark53(25.83501659107104,-0.03737036601566124,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark53(25.845797007357024,-1.4736897300023704E-6,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark53(25.86794422714229,-0.9011402331240408,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark53(25.882471725219602,-0.15680721784818275,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark53(25.889937393815316,-0.14269851189768223,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark53(25.891350944739536,-0.6895219270756543,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark53(25.912508103236064,-0.23021592352379372,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark53(25.916946895448397,-1.0547163159282338E-6,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark53(-25.91879671061723,-1.2683050182373524E-4,-1.0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark53(25.958427608485795,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark53(25.970032098650854,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark53(-25.97921436076153,-0.10690414494267486,18.469983018309108 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark53(25.99466446238367,-0.1127601156935976,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark53(26.006334411507222,-2.9904409856312182E-9,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark53(-26.01863112354274,-1.0669949703689652,-1.0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark53(2.603297038683926,-1.0460584003278908,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark53(26.05094811402735,-1.358579906614066,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark53(26.06420437200174,-0.24613033604515627,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark53(26.068860533268932,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark53(26.10697836172067,-0.7587427331528468,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark53(2.615146034324553,-1.2468000355531483,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark53(26.165753727149422,-0.26104185960879533,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark53(26.21170165749858,-0.23678803158722417,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark53(26.25521801021074,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark53(26.28614923895512,-0.25883747328658213,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark53(26.31781344753125,-0.5743194624980295,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark53(26.427772090030174,-1.4530046304601711,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark53(26.44823064320238,-1.1088775456416187,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark53(26.459051106227278,-0.042610511043354844,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark53(26.477288037442648,-0.22043313102375528,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark53(26.496951200254145,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark53(26.514914087000506,-0.2993237610539019,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark53(2.6538372950850544,-0.938567945229142,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark53(26.539766376267366,-0.10615283223718563,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark53(26.543832181730153,-1.1403759594906973,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark53(26.68108676782552,-1.0728133394507395,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark53(26.7103604443016,-0.9878710931865626,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark53(26.710628717027703,-1.1248606070628,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark53(26.713591064722998,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark53(26.752432520236553,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark53(26.772973433946206,-0.07188615693106659,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark53(26.77773841875646,-1.4999999999599338,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark53(26.797793144670436,-0.393285026700414,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark53(26.803446459527787,-7.142026089607007E-10,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark53(26.805804400743583,-0.18338344947864016,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark53(2.6831694608909658,-8.326412525799071E-7,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark53(26.852638119142554,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark53(26.857582525085647,-1.3929861184592869,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark53(26.87371525039157,-0.9706002854797255,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark53(26.889586350912225,-0.5057339620953022,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark53(26.894711467736656,-0.5440190707400889,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark53(26.92979578091744,-5.458183164592135E-10,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark53(26.931563779271997,-1.354197117255552,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark53(26.93692890363276,-1.3766493679784704,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark53(26.939170469253156,-1.499999999999969,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark53(27.00237278235101,-1.4598889678679843,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark53(27.00976354952367,-0.6697584853819656,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark53(27.01804494557178,-4.827973590083352E-9,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark53(27.06040554879971,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark53(27.07123265757241,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark53(27.07314894518089,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark53(2.710505431213761E-20,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark53(27.180178503054293,-0.20833453319119172,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark53(27.193794624203576,-1.3108214530017577,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark53(27.203224672518218,-0.7169898383228293,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark53(27.214422639301887,-0.8954673127352635,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark53(27.215993494142072,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark53(27.21844377848454,-0.5496963180178938,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark53(27.2276684389265,-0.5716143441272266,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark53(27.277057082428627,-0.6090703698598425,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark53(27.27715431115056,-1.3824521674664523,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark53(27.289650302012518,-1.0815586876284224,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark53(27.29934837527091,-0.3952864540244434,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark53(2.7301301900800414,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark53(2.732248975980241,-0.03481525233836558,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark53(27.332257641371683,-0.5243111149645872,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark53(27.359843156343672,-0.9039244146729253,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark53(27.36651919422475,-0.7118615518740228,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark53(27.37339806610779,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark53(27.37342111164331,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark53(27.384922928078634,-1.1174324732339045,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark53(27.40915854883182,-1.3502467075076217,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark53(27.41258226702712,-0.757738822219974,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark53(27.43657949060993,-5.082421697076255E-9,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark53(27.466893308018136,-1.6866681711368601E-9,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark53(27.499161571872406,-0.6088720161475134,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark53(27.5150607345426,-0.5076754806243287,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark53(27.529428348780137,-4.9489229451195035E-6,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark53(27.547653956371704,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark53(27.56368184662288,-1.0449873013583328,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark53(27.5765816714092,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark53(27.581013437743636,-1.499999999999992,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark53(27.61910985453497,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark53(27.62532664075662,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark53(27.649942459836225,-0.5832762529543203,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark53(27.66339815521983,-0.21436720363168854,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark53(27.686145788761667,-1.3667706971575875,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark53(27.71281078620976,-4.6772272998330675E-9,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark53(27.716140474009407,-1.3785070066419625,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark53(27.723517392213907,-1.3388744546671076,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark53(-2.7755575615628914E-17,-0.39463400843927116,-0.90083907479023 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark53(2.7778332006783675,-1.1355377843823922,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark53(27.786103405210923,-0.5724572847801428,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark53(-27.795641581899275,-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark53(2.7820459930207084,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark53(2.782781632328607,-1.162793895961098,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark53(27.838745496653928,-0.9367814169694952,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark53(27.894733078327747,-0.0030687516476137766,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark53(27.980694759174593,-1.4005224394825393,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark53(27.99337949099536,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark53(28.008810325241143,-1.0423270278982493,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark53(-28.075831219673454,-0.8818116899544892,1.0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark53(28.077657558596627,-1.2700339446367934,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark53(2.8103360080719497,-1.4859687078069705,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark53(28.118020366270464,-0.05516619374605369,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark53(28.118434579704427,-1.1655786278925842,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark53(28.160413129723537,-0.10991399635413135,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark53(28.16369835217992,-0.1355331654762848,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark53(28.216401380814602,-1.0262380603038146,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark53(-28.232390739613987,-2.8530970452583275E-7,-47.33549787551044 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark53(28.247335286529296,-0.05103071686775529,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark53(28.258497990816238,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark53(28.269620394215252,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark53(-28.275733685408294,-0.21428571428571427,0.05234941896507181 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark53(28.30041664822363,-0.7664852581649639,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark53(28.31902928013713,-0.9332231086252945,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark53(2.834303296884496,-1.3406051512384958E-5,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark53(28.34322082612809,-0.5154860293452644,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark53(28.361389716167768,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark53(28.38187521582492,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark53(28.391251950379456,-1.27877650304616,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark53(28.39541861762575,-0.5802110612216009,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark53(28.436746365834722,-1.3939140837482578,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark53(28.445575919450533,-0.5682943779577718,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark53(28.45732809430248,-1.1161513545487942,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark53(28.471165943416082,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark53(28.476033505794078,-0.25472958409795166,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark53(28.481721370266087,-0.7687027563777369,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark53(28.489925982258512,-0.32026096218183575,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark53(28.497651189900505,-2.619445864655629E-5,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark53(28.50487950084232,-1.2973109622914523,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark53(28.51252140074419,-0.007074789212881955,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark53(28.52744915558278,-0.021279949389338526,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark53(28.52796637401664,-0.002888981881949526,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark53(28.565720751343292,-0.4649329976903417,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark53(2.8633831463840167,-0.96652757941514,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark53(2.866729937184971,-0.3308800449492777,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark53(28.692469400098933,-0.043343413058341884,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark53(28.73179196979521,-1.125304280952666,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark53(28.747570467827273,-0.9333483204942041,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark53(28.808028487966652,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark53(28.83309914451027,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark53(28.865907506187334,-0.5425202130474318,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark53(28.92652106097598,-0.5935068345636486,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark53(28.938670875023632,-1.4469196200434098,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark53(28.940895701164152,-1.4828177684112092,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark53(28.945558052948115,-0.39755860122480025,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark53(28.960580354837163,-0.2005619441976565,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark53(28.966223208933584,-0.4293620176393853,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark53(28.979962668399764,-0.007857123394253485,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark53(29.051120126404214,-0.24275178560614252,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark53(29.0689284325501,-0.8271976317753185,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark53(-29.075689009702856,-0.14268723184815713,1.049742927038157 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark53(29.088981422843574,-0.6426864926856735,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark53(2.90951549607783,-0.3576228542195645,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark53(-29.15524859031241,-1.404844676962739,26.822022107975613 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark53(29.217040886304233,-0.09998150251182314,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark53(29.245457307031884,-1.209481866844528,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark53(29.331690729727427,-0.9236919013668256,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark53(29.346796004289587,-1.3078232694216645,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark53(29.361680490069062,-0.5994812875817388,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark53(29.411682647640333,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark53(29.459420604373975,-0.36580796745252786,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark53(2.947190917732899,-1.0350599064140056,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark53(29.47844176961329,-0.11971350464815209,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark53(29.514090962940827,-0.4945238493328432,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark53(29.557660805397887,-0.033123226259083705,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark53(29.558802808101646,-0.9312967856478858,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark53(2.956205389440818,-0.7163474963534782,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark53(29.57149484033365,-0.4392980527651331,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark53(29.57877673494887,-1.2271776327277761,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark53(29.60232029906328,-1.1883226274452197,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark53(29.624272636794586,-1.4818463541168976,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark53(29.666915820217454,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark53(29.677036690810553,-0.9347339842488793,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark53(29.70767239555883,-0.7247977676063186,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark53(29.726279029038807,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark53(2.97959603770353,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark53(29.806322066755627,-2.21788735583796E-8,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark53(29.840600007866357,-0.18831065121706203,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark53(29.863144237275122,-0.8725246654439625,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark53(29.8690130073862,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark53(29.884029567177322,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark53(29.939691625287452,-0.7641683810283126,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark53(29.952695590459797,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark53(29.981306628103027,-0.586514278286904,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark53(29.981504372456385,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark53(30.028231599007476,-1.6861294198060848E-7,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark53(30.030506044841957,-0.16904756462130166,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark53(30.04222106767287,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark53(30.0605875216705,-0.3884904449275979,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark53(30.078698139235513,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark53(30.079037293433345,-0.9072968341089473,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark53(30.132802118245422,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark53(30.133786052457715,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark53(30.135441921888955,-1.200822196620538,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark53(30.21105805144215,-0.960974227413334,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark53(30.220160457237675,-1.4630733404027154,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark53(30.226694528770594,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark53(30.23535224718612,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark53(30.240125802958612,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark53(30.245666785147428,-1.453089649649777,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark53(30.25963924952626,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark53(30.260852186353077,-0.48779324970031723,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark53(30.287176701609837,-0.880222143493441,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark53(30.34827973836726,-1.4429497540264893,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark53(30.38075511930512,-0.018512862220248394,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark53(30.391072433573257,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark53(30.40653635587043,-4.416944516837547E-6,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark53(30.41755270248772,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark53(30.43098314128189,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark53(30.460318343046367,-0.2661502593845311,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark53(30.507617766996333,-0.16594609487211187,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark53(30.509384296496563,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark53(30.53549492584448,-2.5010045357656876E-7,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark53(30.541324336728138,-0.40161708075954294,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark53(3.05462654932424,-1.438627116036173,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark53(-30.55630313551623,-1.4226266219715944,-1.0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark53(3.0564472485364718,-1.157589069521881,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark53(30.567547591759485,-0.43775404139900864,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark53(30.591320910231925,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark53(30.596116362435623,-86.64375202782813,-77.98241100548253 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark53(30.614017629052263,-0.2329669555518834,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark53(3.0620295555347896,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark53(30.625587177412843,-0.6918974791646537,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark53(30.639258908310552,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark53(30.64452268150646,-0.8896891260887076,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark53(30.665038644874528,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark53(30.690202616633638,-1.4999999999556637,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark53(30.70991698175311,-1.0312705975485543,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark53(30.750715765226175,-0.5502085533372885,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark53(-30.756981443429083,-1.1809880924789127,-33.51903036372643 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark53(30.763390339877475,-0.9225922271154303,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark53(30.826155741213796,-0.06549583750809695,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark53(30.8308920085438,-0.4939039553253899,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark53(30.86517123966678,-0.6248979761927558,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark53(30.880174146984928,-0.45517538711200944,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark53(30.893544285901754,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark53(30.919711134649496,-0.07169851203742916,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark53(30.96597072894184,-1.3024832835349969,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark53(30.993148624171567,-0.24961848084862492,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark53(31.03504143227653,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark53(31.114455415351706,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark53(31.134217045106226,-8.338059713550545E-6,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark53(31.180145024894617,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark53(31.182012215008008,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark53(31.305342942444234,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark53(31.30768962163097,-0.5677591635535149,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark53(31.36114436994572,-0.7175760932929935,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark53(31.366590817370678,-0.42410717941154985,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark53(31.383433705532585,-1.8187345002708818E-6,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark53(31.461605610259227,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark53(31.464265608326173,-1.3593599773485465,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark53(31.467109490288987,-3.9024478936597536E-16,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark53(31.468291640707758,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark53(3.1491701516458654,-1.1634795090715357,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark53(31.539193863818127,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark53(31.55045338621101,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark53(3.1567965261416333,-0.19103511902100578,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark53(31.59353446774816,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark53(-31.62385863473274,-1.417488179593736,-0.9999999998891632 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark53(31.65736736459209,-0.4349249939282916,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark53(31.669566537570343,-1.4106010815613428E-6,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark53(31.726830122753046,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark53(31.743540729929492,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark53(31.761281540908413,-0.16922882842028386,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark53(31.78311962317585,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark53(31.800663773824937,-0.282338041874894,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark53(31.805055008025985,-0.48805171008937975,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark53(31.824817872901054,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark53(31.829327524593236,-0.8976476117391554,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark53(31.837775751051964,-0.17561295301639213,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark53(31.924169920181868,-0.2582667509912966,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark53(31.954767317257474,-4.442681204444024E-7,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark53(3.1982233721734588,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark53(32.04018295952164,-1.4999999973888474,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark53(32.05294111434702,-0.645990168994407,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark53(3.207803772547461,-0.004193736938170711,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark53(32.079805238715394,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark53(-32.08352241504199,-0.3661921239199312,-0.9999999999999996 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark53(32.093433707704946,-0.45236219444286974,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark53(32.10459601141039,-0.3739462451736131,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark53(32.10683567570888,-0.3607592376397317,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark53(32.177803020591256,-0.5575599147486905,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark53(32.2099036973041,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark53(32.231571947756095,-1.0179837166363992,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark53(32.24569465116417,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark53(32.2492973385429,-1.412688369238154,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark53(32.29585109182119,-1.0837772026197001,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark53(32.2977460296862,-0.3002741398281472,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark53(32.34642525569407,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark53(32.34928657241781,-4.187174653542913E-9,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark53(32.36090360251591,-0.5490557704952765,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark53(32.367482708661214,-0.6964518914722022,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark53(32.39829303136787,-1.352837094737751,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark53(32.40210810775403,-0.771468286544214,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark53(32.40422812212472,-1.3439835394528714,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark53(32.43732669631825,-0.0113977836993584,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark53(32.4640226260596,-0.8709819474241085,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark53(32.483762724471745,-1.4511218844119367,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark53(32.50162282045968,-0.8612055036572916,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark53(32.51248028119426,-0.23303769018163223,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark53(32.52415501241862,-0.9884052816542663,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark53(32.53247428395893,-1.3028435850284591E-6,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark53(32.54239946146025,-1.4154061466948809,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark53(32.557583748257365,-2.2927437149303793E-6,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark53(3.2565462990028777,-1.0928733197331608,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark53(32.581611235721084,-0.4963977141621636,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark53(32.618919909102175,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark53(32.65403713601558,-0.9427578992548047,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark53(32.65655979221839,-0.611589047345385,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark53(32.66548681666948,-0.07311674642172217,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark53(32.721673168267465,-3.864468584836877E-9,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark53(-32.725134285862126,72.5345823523036,-94.36704284901545 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark53(32.728159898679735,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark53(32.733494703603384,-0.23461073893613094,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark53(32.73770438688163,-0.089475779546217,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark53(32.73887849188813,-1.1171595042745563,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark53(3.2758514936308463,-7.59370493893476E-6,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark53(32.76053726468129,-1.1150961035901847,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark53(32.76377545871637,-0.18546677931571764,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark53(32.85274395420086,-1.354252528030159,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark53(32.88347690427747,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark53(3.293287977372862,-0.5140444028423374,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark53(32.947740767111455,-1.4921124542768207,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark53(32.97564913894201,-1.4999989899827089,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark53(32.99361006160076,-3.3946126571008496E-6,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark53(32.99563212947773,-0.0871684918257789,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark53(33.0868397122959,-0.46722587976419927,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark53(33.137675002644784,-1.052836740221819,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark53(33.14052943675588,-5.8360072963059756E-8,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark53(33.17411374853845,-0.5967367529930669,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark53(33.17723022944737,-0.0019247846411037462,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark53(33.182818933389854,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark53(33.26345823642429,-0.1813352942876616,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark53(3.3267178074560633,-0.18939704674301172,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark53(33.36018880228913,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark53(33.36703457138904,-0.10982502568171526,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark53(33.40251670465883,-0.6823291005949449,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark53(33.41038746787649,-0.467906389668018,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark53(3.3415716377547593,-0.8541744479193767,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark53(3.3472816959689453,-0.6471690725618546,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark53(33.480367626143476,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark53(33.49919928695181,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark53(33.53779243668524,-1.4883756923628906,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark53(33.584534708768075,-1.4270786398627138,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark53(33.591085707250556,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark53(33.600719647631564,-1.2597812592816515,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark53(33.62269839055091,-1.0312828075954954,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark53(33.62686475376074,-0.5400485648104771,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark53(33.637775523397806,-1.4999999999999467,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark53(3.3673713308952946,-0.26334026316485987,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark53(33.67378293941974,-0.19909045624378496,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark53(33.69525648754088,-1.0643905550776358E-8,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark53(33.70826412455392,-0.1986224479364509,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark53(33.734382804701085,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark53(33.82358228558559,-0.5420338654720882,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark53(33.830628632623615,-0.031129594603967803,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark53(33.831789321999885,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark53(33.86468725335604,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark53(33.870248846040795,-0.17719078448600456,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark53(3.3881317890172014E-21,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark53(-33.88189961246,-0.4369244902748335,2511.9663994309535 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark53(33.91089503427699,-0.6809660883609467,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark53(33.91631133187548,-1.488377274462458,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark53(33.94566118576856,-1.4832711316780758,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark53(33.946578048024435,-0.07309991417945128,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark53(33.96814513679814,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark53(33.97551426925489,-1.140104787383365,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark53(34.013353177877406,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark53(34.05571754568189,-0.7781462411165805,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark53(34.061010101071446,-0.2672253009167882,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark53(34.08221477547599,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark53(34.08373035906308,-0.3525037909338522,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark53(3.411219279865078,-0.04986740121321809,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark53(34.161786184266845,-0.6661014988908072,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark53(3.4201962405132447,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark53(3.420313929292945,-0.6056692145645787,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark53(34.2083019264469,-0.927855455350282,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark53(34.22728833232,-1.4617336581205223,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark53(34.24426717496483,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark53(34.25267799621159,-1.2335368511474485,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark53(-34.259911593189806,-1.6087169676126146E-17,0.0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark53(34.30170897108334,-0.9754471390421342,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark53(34.31275623588701,-1.068556485337508,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark53(34.358302125202414,-0.7035806136446674,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark53(34.37026013642091,-1.4550706639887396,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark53(34.37093705890243,-0.5364644105331564,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark53(34.42730026312802,-0.10793960970423311,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark53(34.45451417379769,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark53(34.4611764048571,-1.1674205692234603,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark53(34.483088449370456,-0.7513893230538287,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark53(34.51766477929178,-0.22479873280574403,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark53(34.55218531552353,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark53(34.625594353076735,-1.0888244192621004,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark53(-34.66068923155147,-0.15359266439354258,0.844446008819804 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark53(34.66463014165487,-0.12688648184912665,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark53(34.67046207639015,-0.5743523274908817,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark53(34.681665072081955,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark53(34.68852155365062,-1.4629086477743378,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark53(34.700357194507404,-0.6459061162388546,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark53(3.47161543876895,-1.376067311474685,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark53(34.739347177478535,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark53(3.474305653329955,-1.4999999999620075,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark53(34.75198050992353,-1.0530358764694387,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark53(34.792040247537784,-0.11955055917130278,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark53(34.85450463035525,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark53(34.85734017975396,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark53(34.88502801811674,-0.5607653132942363,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark53(34.900073846062355,-0.3285105567127228,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark53(3.490983598377298,-0.09303525182788253,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark53(34.935244990065144,-0.9245311511624337,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark53(34.93534980124032,-0.11840570012159457,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark53(34.9901898082791,-0.38951996566964375,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark53(35.00384048571132,-0.9823394867424273,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark53(35.072382545001545,-1.0320299453038768,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark53(35.092104282089394,-1.3445941768201415,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark53(35.116121461803516,-1.4481589886750044,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark53(35.120706042623425,-0.6491482822312129,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark53(35.13901942331972,-0.6826862877904745,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark53(35.188101405788075,-0.5840565111663665,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark53(35.188888495361226,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark53(35.2018178370337,-1.7627016180543861E-16,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark53(3.5221861923119775,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark53(3.522666193837134,-1.3337239937041878,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark53(35.25466513006263,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark53(35.30379333360003,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark53(35.33705396650507,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark53(35.36624861388674,-0.6008120361787821,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark53(3.5366555657114986,-1.3718571525410237,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark53(35.40556757213734,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark53(35.427246773071715,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark53(35.455507823016305,-0.08816018953824128,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark53(35.47571868297149,-0.4168225995038716,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark53(35.47743354612383,-1.175694100113276,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark53(35.50074183451499,-0.957390006713335,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark53(35.502680891216386,-1.1175482130783805,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark53(35.5113575058254,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark53(3.5514899843922763,-0.2606517424991335,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark53(3.552713678800501E-15,-0.05457581473343964,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark53(3.552713678800501E-15,-0.06401168010103797,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark53(-3.552713678800501E-15,-0.15357087429548377,-1.0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark53(3.552713678800501E-15,-0.3223475304278196,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark53(3.552713678800501E-15,-0.8490742345304381,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark53(3.552713678800501E-15,-1.4795803665786709,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark53(35.530272451728855,-2.9295724271078868E-9,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark53(35.54413329658939,-0.9848672747093301,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark53(35.57390022501917,-0.4717350930458091,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark53(35.57517039191645,-1.2048644460631646,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark53(35.57774609330225,-1.0831221841448402,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark53(35.58917484876355,-0.004857766150046239,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark53(35.641108793115876,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark53(3.5662355398356596,-0.8810819384912747,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark53(35.68582873042587,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark53(35.775605111907744,-0.7675994252866495,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark53(3.5802852319909277,-0.9334512374698112,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark53(35.82881578099364,-0.8371731132059093,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark53(35.90922622176602,-5.894562423457403E-9,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark53(3.591428001553851,-0.13663484828871808,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark53(35.92678782282329,-1.416691768853438,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark53(35.92868356861682,-1.223799922373856E-8,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark53(35.94006371629595,-0.20506388441123136,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark53(35.96625882177297,-0.689592396936554,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark53(36.03444010253305,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark53(36.049332434916494,-0.3537220134528747,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark53(36.05192595275981,-0.2953313752820277,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark53(36.088407518560544,-0.18013993431757314,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark53(36.1424268266078,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark53(36.17553760635227,-1.4100272686748223E-9,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark53(36.22616430379429,-1.0081649987156567,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark53(36.24099397632003,-0.6388516766908197,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark53(36.24209190875126,-1.077414187837178,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark53(36.245176095356406,-4.225859491349362E-10,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark53(3.6247158923763503,-4.787855876316523E-9,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark53(36.28167254542592,-0.9924098804736161,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark53(36.28231356321922,-0.9401600592237873,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark53(36.2850775311757,-7.25833253173745E-10,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark53(36.28574300416517,-0.18950661974912464,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark53(36.28748761274312,-1.1193323762161,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark53(36.30330164674746,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark53(36.33651277972612,-0.4574089780104398,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark53(36.33878941521897,-2.8496274916572242E-8,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark53(36.33908092006665,-0.6019353884065892,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark53(36.385967483984956,-0.13565101366079801,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark53(36.40244679313042,-0.39398116475382317,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark53(3.6437329326771137,-0.41807372086449446,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark53(36.46595504673487,-0.3656140833835513,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark53(36.46640632183451,-1.4999999999999698,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark53(36.496769492767854,-0.10917277862481956,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark53(36.51373167950326,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark53(-36.51998571067078,-0.20614371457645753,0.912222882389683 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark53(36.54589452809429,-0.36134305686716384,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark53(36.56476561856579,-1.284467678305215,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark53(36.610913231268086,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark53(36.63451338053883,-3.37286015478466E-9,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark53(36.65543810966025,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark53(3.6667889032498806,-0.03637420737230129,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark53(36.682534833743944,-0.9858335258499027,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark53(36.72197067275971,-1.4999999997425941,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark53(36.736684889352276,-0.5342945390654084,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark53(36.76779228356364,-1.413012018634177,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark53(36.80443780186505,-1.101487669399838,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark53(36.821420046723354,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark53(36.82290427971324,-0.8324016242517063,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark53(36.89636934947257,-0.7805194719852615,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark53(36.952602294071,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark53(37.0054711022635,-0.5065857214484097,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark53(37.0224481235916,-0.22465219972787676,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark53(37.02668399205015,-1.445735001688571E-5,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark53(-37.02689229127436,-0.8307558160570014,-67.26698158887828 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark53(37.03041197523774,-0.8260910068166964,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark53(37.05318361827739,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark53(37.05431635228294,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark53(37.09293899953002,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark53(37.10934967647975,-0.7041680222870043,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark53(37.127811132313695,-1.1057818631506393,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark53(37.16625225289109,-0.025187519640954475,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark53(37.168068521467575,-1.4155239959121373,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark53(37.2031181880177,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark53(3.7257462668604395,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark53(37.2933217647726,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark53(37.29813598500592,-0.9817464593807141,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark53(37.30004386618825,-0.03470274678548435,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark53(37.30509739054756,-0.11043274982308654,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark53(37.308951308478015,-0.270621928419553,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark53(37.3120884421231,-3.863850574075302E-9,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark53(-37.313254198617045,-0.6079730548791789,1.0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark53(37.32460684195564,-0.48045591460000425,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark53(37.34365455679535,-0.5829211998853547,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark53(3.7348862197526866,-0.583340098120182,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark53(37.411604411426254,-0.1927426878615126,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark53(37.41211441982705,-0.21977894502073259,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark53(37.41870144490194,-0.5535882446477869,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark53(37.42013083938647,-1.706254512059121E-6,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark53(37.43771722580996,-0.10326622547157172,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark53(37.50986002796961,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark53(37.52909936732641,-0.6654105847112023,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark53(37.53753139982288,-1.3730784759958203,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark53(3.754412298243939,-0.7147716249887708,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark53(3.760644096601766,-0.0763423335644311,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark53(37.6305549704645,-0.5900979424850812,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark53(37.644551591509156,-0.8086815061479542,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark53(37.705457886758964,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark53(37.72666262526579,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark53(-37.780309359115705,-1.4999999999999991,-1.0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark53(37.794623936031456,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark53(37.822343264801106,-1.3960546609632472,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark53(37.84585875702784,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark53(37.8486156769809,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark53(37.91040394410493,-0.43486731442860993,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark53(37.91110923385236,-1.0911326757357473,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark53(37.913565794698115,-1.0817959792573504,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark53(37.931466798359224,-0.07614022254800545,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark53(37.93766920241259,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark53(3.798004030943223,-0.04648368374082174,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark53(37.98102855280473,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark53(37.993479233785784,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark53(3.8013185086621206,-0.7188722581834099,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark53(38.013802187306794,-0.026649284435734888,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark53(38.04497726390173,-0.9454841849008488,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark53(38.05096087067449,-0.07711677064557573,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark53(3.8105655783214445,-0.9288604936988207,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark53(38.12636766594156,-1.4352286614810472,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark53(38.1486555488691,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark53(38.15671507192272,-1.3562735533795431,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark53(38.17859697243681,-0.08583533195555298,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark53(38.19811526556971,-1.0209488805581983,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark53(-38.20910226943139,-0.16650547810191318,0.9999999999999999 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark53(3.821349649838063,-1.4868795888455537,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark53(38.254087558138664,-1.43411403698379,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark53(38.26429773134989,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark53(3.8291434170497234,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark53(38.33334179184072,-0.5976342680015083,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark53(38.37752994609832,-0.6088605766101409,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark53(3.840395100673291,-0.5038443233063958,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark53(3.843647016583354,-1.3066853922863073,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark53(3.843976706376205,-0.16999551043862926,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark53(3.8450325572683965,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark53(38.491806401207185,-0.24719604343643842,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark53(38.515008129582185,-1.065609527325552,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark53(38.52353990125653,-0.08314056712925322,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark53(38.53888220437405,-1.114201815458282,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark53(38.54105386915781,-2.1072525273891943E-7,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark53(38.55249118035181,-0.29320399431034616,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark53(3.856410367336789,-0.7029798785120014,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark53(38.61935200341571,-1.0572064425400143,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark53(38.62573705415568,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark53(38.66015451163804,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark53(38.69438372172744,-1.4005091604477933,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark53(38.7147502998466,-0.7768446845183803,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark53(38.73674234697198,-0.24604164328580425,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark53(38.74147344945473,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark53(38.752166479221444,-0.846179470888134,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark53(38.75968088571328,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark53(38.76050280224905,-1.1686711807438819,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark53(38.7789126151155,-0.8166549603893429,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark53(38.835750897418706,-1.4723705004622896,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark53(38.88852862663575,-1.2291259674285626,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark53(38.949144576877046,-0.7855898798193408,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark53(38.95972327725451,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark53(38.96019989169082,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark53(38.972500410595586,-1.3110230489983223,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark53(38.980582434205616,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark53(3.8982914133401243,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark53(39.00341630854761,-0.8095985502223719,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark53(3.900710279583393,-0.09505577838992973,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark53(3.9020770455338436,-1.297625416652056,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark53(39.035858810240256,-0.25421553952264775,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark53(39.14427073254768,-0.8218172174159193,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark53(39.16746247480351,-0.6589275362113363,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark53(39.189975510502734,-0.31705461359556975,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark53(39.253914987756275,-0.16957960383655069,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark53(39.315604774335625,-2.1791502389765163E-8,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark53(39.31951755578766,-0.20889125107460482,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark53(39.35791831630057,-5.761256058164247E-4,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark53(39.374049733119556,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark53(3.937838540982328,-0.6069002502153635,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark53(39.3857957702069,-1.2556904892476872,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark53(39.40230665847755,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark53(39.46196150247064,-1.1191286278706407,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark53(39.48590841248132,-1.0460784614718324,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark53(39.5108217136611,-0.19891932745069707,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark53(39.51264002985399,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark53(39.51844350537377,-0.04543724447995601,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark53(39.53021766529093,-1.0342893910366473,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark53(39.538266337298865,-1.3973396645962692,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark53(39.54625946758975,-1.0931917015868085,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark53(39.566426187361714,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark53(39.58119961407498,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark53(39.62571705046861,-0.501192082078294,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark53(39.628969879121314,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark53(39.63063683720071,-1.4789863070118956,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark53(39.667347818574996,-1.2229349386811252,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark53(39.684401821107116,-0.5834812478586286,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark53(39.73381085090094,-0.18187377663866755,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark53(-39.743151494540875,-1.4609090018022106E-8,1.0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark53(3.9757116638611985,-1.2070683541994265,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark53(-39.76525199154786,-0.9833752984165485,0.0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark53(-39.78440010687112,-21.539691800270603,45.611062509845056 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark53(39.796027618075016,-1.4999999999993872,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark53(39.80563678355375,-0.1219085772464581,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark53(39.81384503238288,-1.3144197473923516,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark53(-3.982543239752804,-0.05702834790893796,9.09259199638679 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark53(39.88015758171451,-0.08439524370015028,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark53(39.905478036111546,-1.3811726480582838,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark53(39.909068532490814,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark53(3.991552137761502,-0.14781966312290576,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark53(-39.95579173918976,-0.24913407207718363,-0.5806000484991445 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark53(39.95664007229063,-0.3948423314893923,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark53(39.95740326757041,-0.12433848381902024,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark53(39.95887555110285,-0.13088353684379173,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark53(39.96547819824457,-0.38501275830021764,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark53(39.98367805802628,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark53(40.0291491068562,-1.1177868629186118,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark53(40.0365782020894,-1.1069869198867535,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark53(40.050482945484674,-0.8364710726039717,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark53(40.05763633395558,-0.1761763810611493,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark53(40.07817437617813,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark53(40.08110417518423,-0.7704305753792323,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark53(40.11081284839676,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark53(40.115747287015154,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark53(40.13242354197798,-1.499999913405961,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark53(40.154973503407234,-0.02234951314038043,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark53(40.18737718479666,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark53(40.253221589574366,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark53(40.273989844103994,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark53(40.29050516671572,-61.34411021221955,10.243890793618078 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark53(40.295664882654506,-1.0800938678484187,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark53(40.29651483879238,-0.9422989450172157,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark53(40.325138966923674,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark53(40.33439784743857,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark53(40.366286972390895,-0.15943230450812962,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark53(40.367948041887125,-0.28662100082217,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark53(4.039620808044745,-0.12530960945682068,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark53(40.40380954691836,-0.22092973453559495,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark53(4.040761968617458,-3.2375633070669843E-4,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark53(40.442562783418765,-0.5899927511243277,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark53(40.48472671105807,-0.8034970932879126,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark53(40.507921357834086,-1.3787083206911177,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark53(40.52592966307154,-1.499999999999968,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark53(-40.5480052795695,-0.01064331779367889,-1.0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark53(40.57851749819115,-0.042460241973810424,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark53(4.063762608107362,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark53(40.63787626352763,-0.6224432429446285,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark53(40.68796060625357,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark53(40.73853156601723,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark53(-40.74466793982744,-1.432993860956057,3.614855870267892E-12 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark53(40.75269288975035,-0.7383893558753454,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark53(40.7798467161339,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark53(40.792033780856286,-0.6214055265001681,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark53(40.810154837797924,-0.7345201578617697,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark53(-40.826420198921106,-0.35198888903071573,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark53(40.870302459306856,-0.4272322859573101,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark53(40.92291332332667,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark53(4.093964815773489,-1.1359167431984645,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark53(40.96039488136947,-0.908471425910166,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark53(40.9914852633423,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark53(40.99456585010182,-0.4520200103027448,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark53(41.00657029982008,-1.0292334072322262,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark53(41.0101443926836,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark53(41.020763393377734,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark53(41.02765919663906,-0.6265094448458572,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark53(41.06875101891231,-1.5289361506533964E-4,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark53(41.06901201814533,-0.7402011991280206,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark53(41.08542649013581,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark53(41.08788332564966,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark53(41.12643274281244,-0.4256980155393594,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark53(41.17418636468989,-0.6077831593644041,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark53(41.17685964337592,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark53(41.19044056395783,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark53(-41.1945393817021,-28.956161058341934,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark53(41.19856373465623,-1.4961848504391604,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark53(41.19993777578701,-0.9792270231784181,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark53(41.276230934103765,-4.5094674936100554E-10,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark53(41.29463983637213,-0.4666094966145238,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark53(41.325509199608774,-0.14143778681064723,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark53(41.346483165072954,-0.25649194721782564,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark53(41.34994190550273,-0.4961177470005462,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark53(41.35254266968781,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark53(41.36040232980315,-0.8796852033172845,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark53(41.36867480696333,-1.0535799434775202,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark53(41.37398775359932,-0.7657595853739967,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark53(41.38074012981264,-0.4762243177845278,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark53(41.41333682860977,-1.261855935139028,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark53(-41.54391243002883,-0.42083367068588545,0.9999944068315156 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark53(41.562927283642885,-0.781713993997744,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark53(41.612871027289124,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark53(4.161870963640583,-3.5606242211379774E-9,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark53(41.67037165189739,-3.594126546495473E-8,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark53(41.71271400380522,-1.2247822755201772,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark53(41.725099905156725,-0.7884363031874693,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark53(41.73377949273765,-0.8402879100088256,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark53(41.73888984955502,-0.8222259997270811,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark53(41.81112647414835,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark53(41.8751148207314,-0.5586471844364098,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark53(41.881083384435364,-1.2319685107433638,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark53(41.884825622468945,-1.1071897162084882E-4,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark53(41.91087958431689,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark53(41.94813551844125,-0.700902106541634,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark53(41.96282690049193,-1.581906363521773E-7,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark53(41.9762920741083,-1.324321454723979,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark53(41.98657357336586,-0.9213936643823786,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark53(42.01499546059421,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark53(42.02451378501425,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark53(42.03625775451789,-1.077724825527691,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark53(42.049628313297305,-4.462583769829787E-10,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark53(42.0547434459682,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark53(42.059608498850665,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark53(42.06082487367985,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark53(42.06371140603161,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark53(42.07854470744326,-0.21145610041551421,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark53(42.08489531547161,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark53(4.2109551254919895,-0.39355730711301673,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark53(42.12037017895602,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark53(4.213164765554865,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark53(42.145572588878956,-1.051362432888644E-9,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark53(42.241455039550324,-1.3025317685729458E-9,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark53(42.251820864254924,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark53(42.26889652104245,-0.025916773473207415,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark53(42.287484809445935,-0.8458459332139121,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark53(42.29956672811309,-1.4999998162132235,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark53(-42.30890309185412,-0.07971917820282509,-6.0006101962781506E-9 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark53(42.31673436491997,-1.430172474710798,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark53(42.41141899555817,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark53(42.41904828726403,-1.3363106435097851,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark53(42.464919735353135,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark53(42.465237895540156,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark53(42.48398637535401,-1.4893928385559418,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark53(42.49166085051979,-0.5245597661084584,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark53(42.53376751717525,-1.1815085484434107,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark53(42.544880721522276,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark53(42.55429003516245,-1.3802528122020359,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark53(42.57361261631374,-0.15804932056947685,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark53(42.57786160630158,-1.061957905049095,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark53(42.58401976804453,-0.5862471416814847,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark53(42.66795362163395,-3.492026838109358E-8,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark53(42.69411844596781,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark53(42.725083948317234,-0.1198611148457207,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark53(42.8079163533728,-1.4255780022127535,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark53(42.82423053977061,-0.12114388311003144,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark53(42.86126129286859,-0.5023654805718163,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark53(42.90316268066414,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark53(42.92643825954514,-0.1860703260858827,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark53(42.92700145229756,-0.015920486744988693,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark53(42.947367438574304,-2.970074398850623E-9,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark53(42.950155313158305,-0.2843668878533361,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark53(42.97418790459134,-0.18841358627164162,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark53(42.97937485299048,-1.064131657017152,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark53(43.025723372081195,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark53(4.305975160795313,-0.5705967792209494,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark53(4.312198875152774,-0.7951797073480522,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark53(43.125405997896024,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark53(43.178647249899335,-3.8724955551573133E-5,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark53(43.19088379458713,-1.4726757702944402,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark53(43.19712177947254,-1.0333481199660655,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark53(-43.202193161129095,-1.4999999999999982,-51.24143808412276 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark53(43.2466686928254,-1.3212041673844768,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark53(43.250376242112424,-0.5994234607851041,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark53(43.270616347552135,-1.49999999999994,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark53(43.275634374095645,-0.8163334551267717,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark53(43.286884669028495,-1.1774785212069645,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark53(43.300674651905226,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark53(4.330509757196941,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark53(43.309021656900455,-1.15877391194579,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark53(43.321529269605776,-0.14438638530804226,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark53(43.34835461938559,-1.30269613786732,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark53(43.37754120666082,-0.3622147216253193,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark53(43.38434594133443,-0.5316138338340848,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark53(43.410959726618756,-0.27323375885832224,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark53(-43.41254716515262,-0.1030092259646715,-1.0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark53(4.341729417088899,-0.8359408932587963,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark53(43.43946547201805,-2.975048797811807E-7,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark53(43.45906327933375,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark53(43.495535129061494,-0.24579311008548688,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark53(-43.521167649188484,-0.7652241272176958,1.0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark53(43.53532115476897,-1.4999999999388731,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark53(43.5640781299642,-1.4221079214079628,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark53(43.59705408827452,-0.03230596141827391,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark53(4.360779498091844,-0.04231391713986454,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark53(43.6299632918506,-0.09698908370255718,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark53(43.682348371863895,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark53(43.71859959220632,-0.7839263079943473,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark53(43.72342956185688,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark53(43.72900335039165,-0.08871096474423723,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark53(43.73327036375042,-1.17463348874303,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark53(-43.759825010662134,-0.05174767461208369,-52.264533454214245 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark53(43.777390346728765,-1.2983834577358095,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark53(43.78505422611232,-1.3353955846317547,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark53(43.78837684600231,-0.020578425678024814,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark53(43.83741755614358,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark53(43.84089055820459,-0.9876022389638166,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark53(43.86503508829368,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark53(43.86519062585293,-3.7056654048550963E-9,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark53(43.86588575711076,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark53(43.87926780003508,-8.700653130973889E-7,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark53(43.90874821206171,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark53(43.956934948132414,-0.18805967274444493,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark53(43.982238924733366,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark53(43.99025546261194,-1.325470202074058,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark53(43.99784341675769,-0.7974315141646438,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark53(44.000124649747065,-1.032165047573283,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark53(44.01531466326513,-0.015835393035644074,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark53(44.04342004189806,-0.5906164850315605,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark53(44.04927014747827,-1.3488592543170075,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark53(44.06220123346525,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark53(4.408007099462491,-3.867705895662172E-5,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark53(44.15066424299596,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark53(4.415260926127118,-0.03726581099913773,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark53(44.17975172132478,-0.10195388850547937,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark53(44.206543940680774,-0.7672719851039895,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark53(44.2131778460064,-0.6263379653541147,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark53(44.23830021782834,-0.16176735784664192,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark53(44.25184087075539,-0.004323341050007201,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark53(44.26121555645692,-1.4085310319349125,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark53(44.27332596448855,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark53(44.295376669977344,-1.0180210022428595,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark53(44.366885803142225,-0.7600156858793472,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark53(44.377960440181106,-0.20208701634942428,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark53(4.440892098500626E-16,-0.2819526223356341,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark53(44.45230308366341,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark53(44.497254492258655,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark53(44.544584796385266,-0.8653655643069307,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark53(44.55244490950926,-0.5377971817619578,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark53(44.57213997767707,-0.8392171552002594,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark53(44.57274264483996,-0.23211496325916414,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark53(44.57355602860147,-0.23630834173625814,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark53(44.599037064553045,-1.0005723267427165,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark53(44.6175576578591,-0.24377706569987778,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark53(44.630084582753994,-1.4258194773170905,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark53(44.637300531407426,-0.09329349165210532,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark53(44.704315335187275,-0.46754944194462544,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark53(44.75882535780144,-0.9693820043458885,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark53(44.76404502766612,-0.1577070258246125,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark53(44.77205969291859,-0.6295623124392904,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark53(44.84640406427954,-0.763265857097494,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark53(44.8613869861872,-1.0563107570002266,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark53(44.87563726715724,-9.686778152866011E-8,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark53(-44.87668789265946,-0.7544881429446191,-2421.275671667889 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark53(44.889970290929675,-0.2653290714046206,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark53(44.91979491596579,-0.20661288610864173,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark53(44.922073978508706,-0.4137184862769728,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark53(44.93302006115917,-0.2044876614049258,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark53(44.942611845548896,-1.0164708613453683,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark53(45.01961126008328,-1.1602105317237061,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark53(45.081964271490904,-1.2841451262574277,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark53(45.09592312362072,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark53(45.09886201888487,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark53(45.14745056807817,-0.3874692831834419,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark53(45.14832931812533,-1.3871002473151252E-6,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark53(45.171121740435105,-1.4999999998699385,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark53(45.175815909661225,-0.8306312354866741,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark53(45.23797380074815,-1.2091795926981863,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark53(45.24015342153993,-0.2550700953246121,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark53(45.29714300068858,-1.307091979583753,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark53(4.533841891136859,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark53(45.3423463823211,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark53(45.40456891690581,-1.491876403800191,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark53(45.4577133383152,-5.031815821692171E-6,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark53(45.480168026942444,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark53(45.48287719133711,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark53(45.491994970629065,-0.3431669696491042,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark53(45.499676244622066,-1.5235470542492922E-5,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark53(45.51978015569291,-0.551663522200684,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark53(45.55072640559666,-1.2528203732747847,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark53(45.551475141160665,-0.1285422429936922,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark53(45.57748055958882,-0.3899270936194128,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark53(45.57999040672898,-0.44743949198598143,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark53(45.5805564655571,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark53(45.6151904719282,-0.8253518642412394,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark53(45.700418455971715,-1.4332093299593918E-8,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark53(45.73846182515035,-0.21776151097112084,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark53(4.583628464867999,-0.3793462441273966,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark53(45.8494228196831,-0.9366292867419311,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark53(45.85716333615894,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark53(4.587213607505561,-0.27312863647766505,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark53(45.93454493035668,-1.185541123344515,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark53(45.936502301334656,-0.9704462343354692,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark53(45.93770829526314,-0.6954437515996843,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark53(-45.94349202696058,-0.4783599263820939,1.0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark53(45.95261894484003,-2.7623789405961685E-9,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark53(45.9614904500161,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark53(4.596905325294036,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark53(45.996239218977095,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark53(46.03524486821715,-0.5928991956367939,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark53(46.04527913547008,-1.0199100905440446,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark53(4.605589762409405,-0.7463343421289785,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark53(46.067425046695064,-0.0035429948086466404,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark53(46.06847185735811,-0.5996730387546316,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark53(46.077013446885275,-0.15595749335326392,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark53(46.17004964431203,-0.09268730724369334,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark53(46.22440812204118,-0.1532281272518432,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark53(46.27112343956597,-0.4662463801300385,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark53(-46.28859787175838,-1.4999935226917234,-0.11344844308887558 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark53(-4.629532452536523,-56.7113643575408,-6.079094652345148 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark53(46.40932568944076,-0.29678525123132776,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark53(46.41783954777798,-4.018281107006418E-9,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark53(-46.418250208023245,-0.028260289449271406,-10.078365815442538 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark53(46.438713436759464,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark53(46.451780028612205,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark53(46.489873194870995,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark53(46.519520014413814,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark53(46.526837469263896,-0.4110704403345809,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark53(46.58301747536862,-0.31469280390611454,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark53(46.59486624592822,-1.1937913593917078,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark53(4.661627318764855E-16,-1.3055133521310365,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark53(46.642845104187955,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark53(46.65459618365869,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark53(46.669133143406384,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark53(46.71374610258809,-0.3590044464268942,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark53(46.732823191403995,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark53(46.73802652616391,-0.7699710164690998,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark53(46.799745388523064,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark53(46.893625367131676,-0.9872969836396184,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark53(46.93837293435005,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark53(47.018801224088776,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark53(4.701919550112498,-9.612668763266425E-7,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark53(47.077451466815376,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark53(47.139510213087135,-0.02372709685952773,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark53(47.15214608336248,-1.0490169695345832,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark53(47.17211166250242,-1.302492339896387,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark53(4.720584089249712,-0.14829391768210604,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark53(47.2662981051881,-0.7144323744919028,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark53(47.26713762662595,-0.764500286377995,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark53(47.26863021873359,-1.3278992906210192,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark53(4.728930242108746,-0.5299438503520046,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark53(47.309591282784254,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark53(47.310212055076164,-0.044419242575791884,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark53(47.36755214557414,-0.0680685930086895,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark53(47.373333387816785,-0.6844524579720677,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark53(47.45438851066302,-0.08889090122471544,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark53(4.748791010598634,-0.9968950651075232,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark53(-47.495030836313326,-1.3594253958317921,-1.0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark53(47.5105452563547,-0.7076513018812767,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark53(47.5863150611205,-0.045211601592352935,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark53(47.63911660531684,-0.8000002879898744,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark53(47.6508603259972,-0.44151900015916823,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark53(47.683765351983965,-0.16603879120185638,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark53(47.70766173512939,-1.4764441308308367,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark53(47.71690356844658,-1.4937842707188906,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark53(47.75006040077683,-2.2138510898427334E-6,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark53(47.76176871750271,-0.630498173171361,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark53(47.77044057493988,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark53(47.789776433409685,-1.207378009015713,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark53(47.79251584248186,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark53(47.7948984682709,-0.29369419219634096,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark53(47.82932384694735,-1.2082728415605404,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark53(4.786239888084749,-1.963711996674568E-8,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark53(47.88649258678947,-0.9795311194709484,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark53(47.89162113201729,-0.6383090684532788,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark53(47.927868344204086,-0.08175234446742423,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark53(47.95130829890684,-1.9577475641869487E-8,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark53(47.970125353350056,-1.266231503709112,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark53(4.799029804466019E-240,-1.427835718501404,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark53(48.01564256115961,-1.054048317283474,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark53(48.036591481178995,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark53(4.8076810391613325,-7.71020518429477E-8,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark53(48.07901111085354,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark53(48.09042044437268,-1.3249544007947622,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark53(48.091935356847756,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark53(48.10812283433799,-0.39081139431888645,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark53(48.108960318159774,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark53(48.115655328160756,-0.5161739378498931,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark53(48.18650982959422,-2.1724626605940538E-8,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark53(48.19627235118148,-0.012426487650145646,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark53(48.211345597811,-1.865463777960416E-9,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark53(48.23688116839426,-0.23708636493660418,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark53(4.823779768309798,-1.3670701874910156,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark53(48.23981759311678,-7.555434359659495E-10,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark53(-48.24034145445341,-0.3401778702087017,-1.0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark53(48.25582087768808,-0.8613021991126004,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark53(48.28871171089057,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark53(48.31274836249314,-0.017229635107046892,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark53(48.32358078695239,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark53(48.33010435524031,-0.9578927603874283,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark53(48.34288669671818,-7.276976963394679E-5,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark53(48.38108369150903,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark53(48.38330933316607,-1.31856966538063,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark53(48.38825249567111,-0.16535971387928217,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark53(48.39307532355531,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark53(48.39649977845767,-0.7567795215979674,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark53(48.39938291192877,-0.012222594157327737,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark53(48.42158529277546,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark53(4.843388922014629,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark53(4.844157242003732,10.627946455732257,36.757215226518525 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark53(48.51527630956011,-0.5060680681242502,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark53(48.55713226840869,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark53(48.58139582904616,-0.17769670509697139,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark53(48.59182864727413,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark53(48.61787450048911,-0.6163346265140481,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark53(48.61928773916036,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark53(48.62269732978746,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark53(4.862496789560323,-0.7599251795554546,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark53(48.62948127952299,-0.3116439827228561,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark53(48.632317511030394,-1.4999999999181173,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark53(48.65364347536326,-0.4545092463147644,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark53(48.656960196826816,-1.4309861502874872,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark53(-48.67469164852047,-1.4395408145059139,-78.98371147297351 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark53(48.72081930751796,-0.616210538045479,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark53(48.74376317391153,-0.655414406301909,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark53(4.876144309030423,-0.9473221356723371,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark53(-48.82315021706862,-1.4759743063566217,0.6171834029343746 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark53(48.86106690001089,-0.12507998456703362,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark53(48.87399563458939,-0.760358035180019,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark53(48.875001802656385,-0.6113745875219909,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark53(48.90067890100768,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark53(48.96104601542086,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark53(4.898308903030781,-1.1250130654518395,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark53(48.98619349281256,-0.0723276505093926,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark53(49.029121309527255,-0.2548495824262318,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark53(49.03061317570679,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark53(49.035462053774324,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark53(49.04555702462619,-1.2179777849698628,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark53(49.07918000166316,-0.22861870265044626,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark53(49.109009276174405,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark53(49.14225467019048,-0.8715615615608954,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark53(49.14445631158994,-0.3871311003779886,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark53(49.18642848740416,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark53(49.1965258950903,-0.23608545877049814,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark53(49.20138724251805,-0.006941183991902772,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark53(49.27412016685637,-0.9523015224243467,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark53(49.29553615264401,-9.71386152851046E-6,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark53(49.31553974567049,-0.4197206376399265,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark53(49.34565941722053,-1.4999999999570346,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark53(49.34757033382435,-0.3448543568129452,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark53(49.3499348516987,-0.1821936497658152,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark53(49.39257636734738,-4.099238393464373E-8,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark53(49.40919419215794,-0.5011330062864516,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark53(49.47185054125283,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark53(49.51312358684649,-0.32352767638936664,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark53(4.952034503822967,-1.1213287076325018,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark53(49.556288894478996,-0.22475620265009688,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark53(49.557277754124556,-0.8431309568232315,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark53(49.55867000111695,-0.02772211168592209,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark53(49.57201845040231,-0.30078881198500795,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark53(49.5789084970919,-1.2207708594336975,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark53(49.58896792284483,-0.5480994527897245,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark53(49.671248988385734,-0.24697301032351257,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark53(4.967249064270973,-0.895340867078521,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark53(49.690218699869206,-1.499999818176473,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark53(49.7228963773708,-1.1774774014845684,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark53(-4.9776639040484785,-1.300411036262899,-1.0598939654755962E-168 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark53(49.78299353118669,-0.1335540044047308,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark53(49.86816084531253,-0.5010767468671276,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark53(49.870861800928594,-1.406468245897969,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark53(49.952534214496694,-1.0184490696314574,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark53(49.99351331561118,-6.592407888714254E-9,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark53(50.02594580414396,-0.14325012758589706,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark53(50.06401151097481,-0.18983242851642723,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark53(50.07273793789132,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark53(50.12173133499155,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark53(50.1477381632842,-0.9297633678739601,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark53(50.150333073072886,-1.2866343204777484,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark53(50.244727676449806,-3.7304344105601105E-8,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark53(50.2775551112151,-1.2188733095240805,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark53(50.28181229043852,-1.3040991982916381,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark53(50.29702751304558,-0.018609710634677867,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark53(50.29965083549962,-0.607398858146027,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark53(50.30384761575929,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark53(50.34376121205105,-1.2878858737642203,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark53(50.35415442939839,-0.43120904881439515,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark53(50.36943157088948,-0.975359621361897,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark53(50.41255484582949,-1.292501079603183E-4,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark53(50.565681767597425,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark53(50.594081506647626,-0.14077670159449518,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark53(50.607256308483784,-1.1334821080826032,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark53(5.06204214002743,-0.5944257259700694,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark53(50.63181744852591,-0.20795366591018238,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark53(50.63574522346025,-1.4999999999998188,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark53(50.65670015700004,-0.18286638437353453,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark53(50.66144102001988,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark53(50.73798958287813,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark53(5.078066604191153,-1.2173791979808417,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark53(50.786995442942754,-1.0858013391032477,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark53(50.78859137004653,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark53(50.81258274873687,-0.912677170008275,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark53(50.81712743520413,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark53(50.84999865014325,-0.20654216390362778,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark53(50.88272362555833,-0.12262363399643894,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark53(50.940070113323905,-7.052737229013244E-6,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark53(50.98024254176394,-0.5290367402646923,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark53(50.984492484589374,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark53(51.02506444755113,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark53(51.037243462905195,-0.6167688140675125,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark53(51.08089287734966,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark53(51.09012528977988,-0.7375863655436814,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark53(51.09716342448692,-1.456347595902141,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark53(51.12564473252249,-6.468390518496451E-4,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark53(51.14196599232571,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark53(51.18127058515084,-1.2709148827618417,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark53(51.27367048846932,-0.2675002618666582,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark53(51.28185426582724,-1.5972674449585415E-15,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark53(51.31021040834176,-0.27192934507162647,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark53(51.34457829204436,-0.4690040450079209,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark53(51.36232957207011,-0.13330148437163813,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark53(51.369570843772436,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark53(51.39792059692502,-0.7783473118699931,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark53(51.40257621251493,-1.0194196010405534,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark53(51.42893508204011,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark53(51.453916502546946,-0.048717208590135286,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark53(5.150332756660299,-0.8195327227917129,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark53(51.52262209625647,-0.2321600475634349,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark53(51.53660793031358,-0.5240752099026764,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark53(51.53905711367025,-1.499180636104569,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark53(51.54763942336277,-0.18750448704331546,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark53(51.560013269364006,-1.4410343299233837,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark53(51.58685460211095,-1.1638313507754827,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark53(51.609581586553496,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark53(-51.63540453356897,-0.4931663873956893,1.0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark53(51.67044706484788,-0.30475073536107544,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark53(51.69006848257206,-0.5006982742501407,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark53(5.1717500788368795,-1.007067142885749,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark53(51.72426463616256,-0.19408780259337366,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark53(51.73868677563783,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark53(51.77024175877179,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark53(5.180172488392741,-1.1568323957514133,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark53(51.82575340085333,-1.3729167231682817,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark53(51.831016284162104,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark53(51.84920508070664,-0.17903684531392727,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark53(51.855031838233,-0.7937583425069104,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark53(51.87372966960675,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark53(-51.881732481381746,-1.3486391763254435,1.0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark53(51.88881079894415,-0.11595802912593278,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark53(51.90018989464849,-0.4731709113121667,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark53(51.91907032348334,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark53(5.193070312039815,-0.06949200721788318,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark53(5.193948275310539,-0.1945636038031604,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark53(51.974500180271065,-1.1469013056710022,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark53(51.9802382732052,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark53(52.00002230363922,-4.035595967269475E-7,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark53(52.107833676713,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark53(5.214886718203918,-0.37001333373659884,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark53(52.166603868438756,-1.4999999999999432,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark53(52.185777062924785,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark53(52.20192534303254,-0.4471130610636562,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark53(-52.246156083288774,-0.28997622541364887,-1.0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark53(5.22662575439783,-0.23195644903512802,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark53(-52.30827724056152,-0.7277637060162204,0.023904747924465154 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark53(52.3242621144874,-0.9661736351642287,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark53(52.33502592453175,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark53(52.39397401508006,-1.3256030604839233,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark53(5.241363031930973,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark53(5.245226648482969,-0.6991255019385165,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark53(52.46244125477331,-1.3454665327892172,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark53(52.52670296133997,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark53(52.52906836756068,-0.5657789148542349,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark53(52.543841458708165,-0.133506851231032,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark53(52.562927980813676,-8.180902400012172E-6,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark53(52.58121555612746,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark53(5.258308179801466,-1.4999999999717382,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark53(52.60206380459303,-0.8551893083236664,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark53(52.682806926709816,-0.6635700050175495,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark53(52.709469227291606,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark53(52.71061659159936,-1.4999999999075528,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark53(52.729661774135025,-0.5113088755603457,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark53(52.74158290295071,-1.208651649132186,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark53(52.74187484511154,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark53(52.74575545099265,-0.15354286863695576,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark53(52.75168842941284,-0.7722745063909198,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark53(52.8891352825635,-0.6586702885755524,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark53(52.92671889011491,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark53(52.960599692572885,-0.09273801238468726,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark53(53.02911926435115,-1.4801932314189914,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark53(53.02978069485246,-0.3018660892712459,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark53(5.308552551156922,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark53(5.3099369250711135,-1.491880213665463,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark53(53.16525119199424,-1.2602181899523703,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark53(53.2148135127386,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark53(53.22778539935848,-5.530059621036016E-4,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark53(53.2532338723945,-1.1858451289906355,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark53(53.26273063155921,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark53(53.26741654945829,-1.4429372516626362,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark53(53.31390618885344,-1.2712013125356205,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark53(5.333913503183747,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark53(53.38258464159818,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark53(-5.341869432102193,-0.8736779329477107,-99.14296261600461 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark53(-53.42146186065243,-0.6663407609971159,-0.20728614725682415 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark53(53.43944577035961,-0.5229998852648556,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark53(53.471710201652,-0.362536409442086,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark53(53.47399721668583,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark53(53.485660740770214,-0.004042031309751337,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark53(53.52521554966515,-1.2777625438090325,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark53(53.53373625121179,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark53(53.53802091837554,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark53(53.54465271110064,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark53(53.558702965690884,-0.057361133766027805,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark53(5.357376665452193,-0.6453532178825945,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark53(53.58224639372585,-2.586485038965212E-9,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark53(53.58548906302798,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark53(53.60076109975182,-1.2356427987105425,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark53(53.60290845534624,-0.08803826387447544,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark53(53.66269365392898,-1.3152057716301613,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark53(53.681298743333265,-1.4997369376997203,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark53(53.69162502947779,-0.34030102229140446,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark53(-53.73206747898304,-0.19020055835844119,1.0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark53(53.74174537190651,-1.0565606143226889,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark53(-53.746663771773086,-0.889772244964008,0.013258884761697173 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark53(53.759376557406824,-1.0272066569956726,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark53(53.7829740265737,-0.06655212278469888,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark53(5.380804989449883,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark53(5.3816519353237595,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark53(53.84940485406658,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark53(53.85144837107837,-0.21401826914013214,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark53(53.86262313927023,-0.1812012592444816,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark53(53.87196505987072,-1.0493777386685137,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark53(53.87609612272311,-0.43565440390021676,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark53(53.8761520466484,-0.3223522211560371,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark53(53.87679559843755,-0.33566380601701695,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark53(53.87706351742787,-1.0089610148543633,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark53(5.388601783797299,-0.09494167465109626,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark53(53.889115367327804,-0.35743764842212045,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark53(53.924118501906406,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark53(54.01291006914544,-1.499999999543135,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark53(54.04726836815749,-1.49975392774917,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark53(54.05536506662717,-0.46508016662115875,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark53(54.09067870022969,-1.498366266757092,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark53(-5.410309654428275,-0.2759201157402629,54.25588423970902 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark53(54.11026393147148,-1.3314913375056552,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark53(54.11091892110256,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark53(54.11674733425378,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark53(54.14078665524726,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark53(54.146775697841996,-1.350676350994835,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark53(-5.41711258910216,-0.5406176502756661,-1.0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark53(54.1811898441495,-1.7737179958607597E-8,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark53(54.29911201517233,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark53(54.324108803861826,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark53(54.32498549921968,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark53(54.35806801987312,-0.8047305585920629,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark53(54.36477536305597,-0.11899762780809055,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark53(54.38183383875891,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark53(54.40487336999897,-0.8726276013414829,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark53(54.42539947134074,-0.4097898661621535,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark53(54.43834931821114,-3.699276240028028E-6,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark53(54.448384319718855,-0.08970517990989313,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark53(54.449277125206606,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark53(5.446934141111283,-0.09187554380678614,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark53(-54.541024219231375,-0.004581803036558085,-1.0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark53(54.57558912187103,-1.4999999995873434,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark53(54.584659643285704,-0.6221874222824226,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark53(54.59576231687038,-0.7156711874632633,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark53(54.62111087494196,-1.3924519496557886,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark53(54.64455346815757,-0.50200817185052,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark53(54.660684875705186,-0.602804475227221,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark53(54.70012158684588,-1.0998471933741478,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark53(54.71890285672123,-0.8207431813724146,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark53(54.79545768116202,-0.15862162242046632,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark53(54.8526168255998,-5.183014921369913E-8,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark53(-54.89740521196539,-1.4999999999999996,1.0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark53(54.9395438535544,-1.4131715651352028,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark53(54.95226585449021,-2.0109694730794187E-8,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark53(-54.955083851059584,-3.552713678800501E-15,43.202957290841866 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark53(54.96705539933663,-0.5961583173651293,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark53(54.998878132437966,-1.4999992063765435,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark53(55.009231934242536,-0.7974259220577247,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark53(55.06359628414491,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark53(55.06816402495244,-9.217428171041846E-10,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark53(55.070231765494015,-0.5245008265132197,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark53(55.114254991657475,-0.6453188446351428,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark53(55.14648236784793,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark53(55.164329109190135,-1.0325922520537074,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark53(55.16451193054357,-0.0663607022292041,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark53(55.1659493170001,-0.16278485963731754,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark53(55.17893439127171,-1.0863465466252924,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark53(5.518269633797004,-0.9647948710627996,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark53(55.200567925406745,-0.9975753425837078,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark53(5.520400811366841,-0.02215544792303592,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark53(55.251536382381005,-1.3709449450063504,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark53(55.279203385608895,-1.4356219354102677,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark53(5.528820693642037,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark53(55.33013330026523,-1.1432081452721867,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark53(55.340281788506104,-0.2071929290107306,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark53(55.35714676191,-0.21635734725169797,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark53(5.536790670647235,-0.8427653348950088,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark53(55.3777092962749,-0.17579293747567393,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark53(55.50597401414079,-0.2613410455836469,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark53(5.551115123125783E-17,-0.804198961560475,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark53(5.551115123125783E-17,-0.9430412591522079,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark53(5.551115123125783E-17,-1.2156189472843042,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark53(55.51379173298605,-1.3956755100018272,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark53(55.53606604542742,-0.004983675063385817,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark53(55.626652486170144,-0.46191905642519615,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark53(55.667966248704886,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark53(55.67571423955371,-1.4999999999683904,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark53(55.67701348149684,-0.08429028372531658,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark53(55.70372066790742,-0.30188884871875565,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark53(55.720184741502386,-0.3159821022843301,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark53(55.72452815933057,-1.0290990170322234E-4,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark53(55.74933931640538,-1.3529337454360624,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark53(55.798638697757156,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark53(5.5822155039655,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark53(55.824311079038495,-1.3820239381469683,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark53(55.834496671025434,-4.0980676871659915E-9,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark53(55.876559317218266,-0.9999356783488846,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark53(55.889132892050824,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark53(55.898730597718725,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark53(55.89985214133867,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark53(55.9516546917549,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark53(55.993455167881706,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark53(55.99439327953763,-1.2882582106466973,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark53(56.01714962593181,-1.199968209212044,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark53(56.02863660492309,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark53(56.10256442775244,-1.4359679852408789,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark53(56.104826430543184,-1.4436999259798444,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark53(56.10646292680778,-0.17339404851890095,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark53(56.11984119452799,-0.06305000645649184,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark53(56.14697574762016,-1.0611626012337165,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark53(56.17166338737576,-0.8771362153304381,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark53(56.19066666625022,-0.8721398360489983,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark53(56.19652965741756,-0.866804033245022,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark53(56.22564657102579,-0.9754619027893643,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark53(56.2395576681554,-0.7507953975625252,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark53(56.25341943047684,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark53(56.264920476317755,-5.759108608576133E-8,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark53(56.28031517397889,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark53(56.293816928868694,-3.1716633238851355E-9,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark53(5.629892640929086,-0.9331253124829999,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark53(56.32295952408782,-1.0111092262928025,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark53(-56.329764447645715,-4.2093389042227425E-9,2364.6195695222127 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark53(56.369552179362074,-1.1935986207670162,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark53(-56.39812542020843,-60.952699747104134,35.82324961396131 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark53(56.403352441712855,-0.37507624341345336,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark53(56.40715618762636,-0.4020534412747225,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark53(5.646588344581156,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark53(56.524741605232826,-0.8623763741468515,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark53(56.59088333144118,-1.4050163211740907,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark53(56.629466872607736,-1.2064652299346985,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark53(56.6477770199609,-0.1704270649183952,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark53(-56.672136917660204,-1.1996486599095277,-1.0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark53(-5.667733362919845,-1.2270170438929147,-0.029589911526895905 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark53(5.668686742789845,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark53(56.695697398153754,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark53(56.70019805930053,-1.0278899861884216,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark53(56.76888813199868,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark53(56.7821832554436,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark53(56.81465772111713,-0.8727381805286356,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark53(-56.85518225309315,-1.7763568394002505E-15,-11.72181303267128 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark53(56.87980076118765,-1.4999999999291074,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark53(56.89068727791408,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark53(56.91442506599461,-0.4576088217193295,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark53(56.95179853826385,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark53(56.955640683707784,-0.24789644885645945,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark53(56.960707336674744,-0.7631132345230753,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark53(57.00718364878384,-0.28389420497487095,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark53(57.08559856082661,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark53(57.09488490900233,-0.6336012033789323,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark53(57.12181439574903,-1.2765172377916616,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark53(57.12521211374292,-0.32405544076450266,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark53(57.1263328860629,-1.2499946537590445,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark53(57.201482671893416,-0.6179413338031443,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark53(57.20775870415676,-0.2237490897884351,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark53(-57.215825013530306,-1.4999321102595973,53.60822637657892 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark53(57.23005214655681,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark53(57.253760682011034,-1.369984745802583,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark53(57.26678130417185,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark53(57.2983110916866,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark53(57.30256416570033,-0.6928534603441752,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark53(57.3392917730973,-2.0437241816943569E-16,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark53(57.360223730788704,-0.05886490602533749,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark53(5.736669202937776,-1.4999999999999503,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark53(57.40260546407409,-1.0280530682602202,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark53(57.434523264593636,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark53(57.448568075116526,-0.8469814407912288,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark53(57.471946302375784,-1.4414740103614794,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark53(57.508958947172005,-1.3959693103994653,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark53(57.54752969250194,-0.2513893311766253,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark53(57.556319517298505,-1.3342535086271128,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark53(57.56030192583202,-0.4748835188724314,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark53(5.757809039905283,-0.10052040991652689,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark53(57.588687446417424,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark53(57.629320166917054,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark53(57.64417211488819,-0.5317377747468024,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark53(57.66666787757481,-0.03193106379292267,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark53(57.670928125928725,-0.8509452402187208,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark53(57.67864607910304,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark53(57.69749136961372,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark53(57.70684670845469,-0.15179532707340115,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark53(57.71904327079929,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark53(57.75677398835683,-0.35103647714961816,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark53(5.783916918882883,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark53(57.862187984547006,-2.942582280769712E-8,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark53(5.79034482940412,-1.0549119059109602,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark53(5.791255819673917,-0.3871574261585533,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark53(58.01870697933359,-0.25176594913703343,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark53(58.0363759656102,-0.3441779021294736,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark53(58.0367325935666,-1.0604259897641413,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark53(58.12229451845508,-0.5364842696131404,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark53(58.16050131286252,-0.1495238080532174,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark53(58.18836554840115,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark53(58.25361968627729,-3.3000270756413455E-9,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark53(58.27873295391001,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark53(58.373665312924395,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark53(58.37494044457958,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark53(58.384396866848356,-5.0302399417698806E-5,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark53(58.39974279712186,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark53(58.435028008595495,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark53(5.845398785677716,-1.168141386666122,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark53(5.8489005960263425,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark53(58.51177485844309,-1.3286774238355576,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark53(58.58700738746677,-1.4202941349679064,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark53(58.591073481324656,-0.4091060394882362,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark53(58.614987417770834,-0.36581148122271756,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark53(58.67832010729409,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark53(58.70556722899602,-0.02218721678669444,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark53(58.744721052497965,-0.8890030565709424,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark53(58.746950864444415,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark53(58.76510320639899,-1.386257027626741,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark53(58.781234388559085,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark53(58.82621136047345,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark53(58.867628189287885,-0.7852264174014787,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark53(58.86904751505057,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark53(58.88264399237801,-1.4999999997763926,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark53(58.912526622204524,-0.49700073126294364,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark53(58.9286251040961,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark53(5.893121654424348,-0.389101116846561,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark53(58.95772920784803,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark53(58.97442584111215,-0.3316798861816608,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark53(58.97598388241244,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark53(58.98040342914925,-1.0994534037647394,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark53(58.983170303235966,-0.3160733283013023,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark53(59.09528641851159,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark53(5.910993725417526,-1.0713910696620548,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark53(59.11876671185322,-1.1803572791728696,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark53(59.13514069810347,-0.09968721620032664,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark53(59.14080610308267,-1.0429446593005656,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark53(59.14787381247735,-1.3722445371867058,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark53(59.16602204121483,-0.2809769304424021,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark53(59.190261265427694,-0.5989109564181392,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark53(59.22169120964372,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark53(59.22982657896725,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark53(59.247996180722666,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark53(5.929338627914078,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark53(5.932865750943183,-1.0942111685327522,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark53(59.3929343629639,-0.06771968274534201,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark53(59.4001153251237,-0.8782902220234412,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark53(59.43954909844976,-1.4293726966379836,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark53(59.51136304307627,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark53(59.51603309434856,-1.4640303697016037,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark53(-59.531311384670644,-0.046971046916078674,-1.0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark53(5.953669645659282,-0.34478536546878047,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark53(59.537196378143136,-0.995244211993791,0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark53(5.954589239238692,-0.22876187513958862,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark53(59.554017284199965,-1.1394087186871884,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark53(59.58202542096122,-2.6490118837234313E-9,0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark53(59.58622806671511,-0.2800059540644204,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark53(59.60398083672891,-0.9871251165170634,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark53(-5.960498483378203,-42.396318497365606,-53.4944701935498 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark53(59.61594290876101,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark53(59.64668575434039,-3.7148783083309237E-9,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark53(59.6743695351648,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark53(5.969820800953272,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark53(5.97143144094723,-0.778751261241434,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark53(-59.71756073660054,-1.4211379017161672E-9,-1.0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark53(59.72516065535092,-0.7964756126512835,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark53(59.77404337008998,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark53(59.78171003523153,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark53(5.9782254609392425,-0.24723060052953372,0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark53(59.78862988245393,-0.7772851686490991,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark53(59.78867240227123,-1.467748500691071,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark53(59.818585203919355,-1.321366865724023E-4,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark53(59.82981578628688,-0.6311173580719864,0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark53(-5.989890156142668,-1.2056516172429506,0.355618300094555 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark53(5.99063339946791,-0.5326735487782344,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark53(59.93504495463736,-0.13336960715470525,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark53(59.99857594974537,-0.3688468763345627,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark53(60.00012235911444,-0.28422622404974573,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark53(60.02069812438583,-0.38428552604463206,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark53(60.05902330146279,-0.35707538054215693,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark53(60.073027798314,-0.4447151283710724,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark53(60.077818960217456,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark53(60.13372663538078,-0.675268324444001,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark53(60.20279389669921,-0.41028954237598825,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark53(-60.21697330759348,-1.3972147932815204,-97.5973308430278 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark53(6.024996068949179,-1.423772221047221,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark53(60.28563857910443,-1.4404524892058639,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark53(60.30179378436429,-0.9395066300859591,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark53(60.31533822386126,-0.37124624901585435,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark53(60.35717151347956,-1.3108846154222533,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark53(60.35718179888991,-0.21689387910814162,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark53(6.039384235909367,-0.3488979624444255,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark53(60.41102937330468,-0.8241352061970741,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark53(60.456542230398554,-0.3217117607045938,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark53(60.46355600524964,-1.3784645761104173,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark53(60.47439489266998,-1.2729734230867518,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark53(60.544617868164764,-0.24989047738400694,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark53(60.57315235754476,-1.3880892370773807,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark53(6.064991789706511,-1.1442076042268923,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark53(60.7324416576983,-0.010072695420115352,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark53(60.732966404917136,-0.2958680094838839,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark53(6.078745343133889,-0.0027743664849608773,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark53(6.079975626271178,-1.1701763091160464E-9,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark53(-60.83021684072372,-1.429510446339813,-0.9706079783837399 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark53(60.85543754608995,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark53(60.866351513892596,-1.4563821655342988,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark53(60.86737067001371,-1.2923250912017892,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark53(6.089052123578867,-0.3635263311840664,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark53(60.89369953349478,-0.6126112499818621,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark53(60.9623491993201,-0.6626141188345898,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark53(61.028315835114356,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark53(6.110204818771564,-0.6081552098894321,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark53(61.16769246290997,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark53(61.17093183881517,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark53(61.17821557987253,-0.2958598424892074,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark53(61.2019823490684,-5.552081429341915E-8,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark53(6.121608931331906,-5.593144103635689E-10,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark53(61.220211086027305,-1.4410323538507797,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark53(61.2640613352869,-1.499999999999968,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark53(61.33579925854909,-0.5679831826446984,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark53(61.348652520516964,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark53(61.41672957695893,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark53(61.45449932300579,-1.1570804108866124,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark53(61.47770716022319,-1.3495069444118384,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark53(61.51331551480516,-0.2995490444109734,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark53(61.54571966621586,31.19879581310613,-60.98128161053778 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark53(61.581393026945136,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark53(61.62580225620249,-0.6758092855902831,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark53(61.642247926221195,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark53(61.84202357791929,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark53(61.87083344654528,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark53(61.88368819195031,-1.386374256594275,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark53(6.1885011975491295,-0.930499441482715,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark53(61.92020167099777,-0.250834353465597,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark53(61.98511339229367,-0.31780937670126086,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark53(61.9925347858119,-0.9024459049083617,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark53(62.054495188246875,-0.8323000512248868,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark53(62.06376467652083,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark53(-62.076468913122355,-1.057676222433968,50.64292808968631 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark53(6.208528483750142,-1.2310199416688619,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark53(62.09033623668029,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark53(62.12739488409454,-0.9162320306872065,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark53(62.14272084314868,-0.22976695870456298,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark53(62.15705025171269,-1.3464643474701634,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark53(6.215805084449751,-3.57963470903916E-8,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark53(6.217016821942622,-0.7863241011586837,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark53(62.218843019556516,-0.09803499488980183,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark53(6.223325136327816,-1.346136847072592,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark53(62.314875645342624,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark53(62.31505990377818,-0.7011805550120158,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark53(6.23530285511093,-0.7617189144435148,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark53(62.36963920901001,-1.4229116112001021,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark53(62.376872806667336,-0.8268595375491469,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark53(62.38841276034528,-0.1716376572586792,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark53(62.431696205898376,-0.08961265982266098,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark53(62.4575442088528,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark53(62.48485930866673,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark53(62.499943090648514,-0.8558614188816289,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark53(62.50033944644852,-0.21393846699005437,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark53(62.58850292609391,-1.3054056179005233,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark53(62.616170412615816,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark53(62.64409781537182,-1.4315445229889363,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark53(62.64744896788231,-0.6580054893497749,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark53(62.65245328718876,-0.6138918960508621,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark53(62.663025106308936,-0.4630637712441583,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark53(62.66736614360795,-0.32923683894750866,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark53(62.70108511415515,-1.312691133373491,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark53(6.272430232293139,-0.03336823347439122,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark53(62.76427990997045,-0.6701539104278229,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark53(62.785238041276926,-0.6033237554434656,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark53(62.794736701576774,-5.611500732230418E-9,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark53(62.805008545849546,-0.1976940123749813,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark53(62.81033213090434,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark53(62.92715135167995,-1.3812177072396312,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark53(62.93955120237757,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark53(6.296143227445199,-0.5499807843117441,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark53(62.99719685276197,-0.5303824512017403,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark53(63.03220981297292,-0.5037140759785602,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark53(63.03255009485099,-0.6065554422907695,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark53(63.040979765077196,-0.8950564751691434,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark53(63.053514330978764,-1.0422064566479552,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark53(63.055693804765156,-1.1865034478818652,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark53(63.09872578982194,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark53(63.11996561350192,-1.46591740003052,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark53(63.15957402835312,-0.17349742632972598,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark53(63.18949549493034,-1.4721713622383776,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark53(6.318985493163879,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark53(63.19608844497859,-1.1777802010754055,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark53(63.213146518311646,-1.0821451931107324,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark53(63.23668218841604,-1.2746973493308502,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark53(63.288700381004276,-0.6180726072828688,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark53(63.29160462021818,-0.9189743849545664,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark53(63.295193962425145,-1.3859947431776476,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark53(6.3334955784919025,-0.280919827790857,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark53(63.34177612193603,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark53(63.43213425448687,-0.0019728575215598454,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark53(63.433931248715716,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark53(63.453857987614754,-0.5779378530924362,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark53(63.47792794854047,-0.22554836836936776,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark53(63.50700036283132,-0.5187574100673997,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark53(63.52450900533813,-1.1196165135361582,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark53(63.56060865352798,-1.8510114460791631E-9,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark53(63.59508724464692,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark53(-6.359946810431332,-1.3451698435784976,1.0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark53(63.606001300774366,-7.187635579548754E-9,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark53(6.369680604707511,-0.5172670153410541,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark53(63.69884549422646,-0.6041041883233333,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark53(63.73736098425175,-0.16453953805444144,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark53(63.742115102088334,-1.019832441430907,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark53(63.779725968181964,-0.49168978159552523,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark53(63.8120762926693,-0.3084435161321295,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark53(63.859444301465274,-0.5090140187585632,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark53(6.389657932187729,-0.015716672920834895,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark53(63.93370887444742,-2.6748962020950786E-8,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark53(63.94394687510132,-0.20781888402955,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark53(63.96067295692359,-1.1462070100698685,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark53(63.97109956579547,-0.5838335759970636,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark53(63.98900328469687,-1.0434490739197102,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark53(6.400174087411074,-1.4921908122280456,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark53(64.04860322168888,-0.46089815702439907,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark53(64.07603775418356,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark53(64.0984894178211,-0.9184349975608886,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark53(64.09896507460411,-0.9553785403746375,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark53(64.12058537011461,-0.7873059444713988,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark53(64.1371273013969,-1.2289057244322237,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark53(64.23122084989333,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark53(-64.24689200965355,-0.46006025534207584,0.9999999999999982 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark53(64.25674559409964,-1.2963210763321383E-5,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark53(64.27697254714408,-3.977780402516397E-8,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark53(64.27714276791713,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark53(64.35221441351348,-1.7663211165296847E-5,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark53(64.38802233841602,-0.21944208561912149,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark53(6.439983883861217,-1.1609723033929953,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark53(64.43410728109644,-0.8371431595954443,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark53(64.50919399026237,-0.2994596002420651,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark53(64.5545625333123,-0.6289653407795299,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark53(64.56825617704636,-1.4999999844775227,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark53(64.58177287803665,-0.18550951753609013,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark53(64.59303893949328,-1.499999999920666,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark53(64.60055675554597,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark53(64.65703252176283,-0.6083973648488255,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark53(64.65759822271193,-0.752032128021483,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark53(64.66793348717559,-0.013887348194976199,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark53(64.69012650231176,-1.4229962814326569,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark53(64.70450031078792,-1.4999999999999831,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark53(64.74672824957634,-0.2410304979269391,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark53(64.75709534375392,-0.44740284288115717,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark53(64.85172275470111,-0.43027616618587317,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark53(64.86287181460737,-5.937639751461512E-7,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark53(64.86388583225008,-0.19334467025569488,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark53(64.87842569721303,-0.3774045049835668,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark53(64.88485374780038,-0.6240027718977785,0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark53(64.8865236482151,-0.0688598444311257,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark53(64.94397544135776,-1.3476208810541954,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark53(65.00862175857455,-1.4842977953661336,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark53(65.11522529383905,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark53(65.255580731564,-0.10420262626274807,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark53(65.25703059037119,-0.33293611369747145,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark53(6.530163805087464,-1.4999999997062878,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark53(65.35692567248832,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark53(65.37681608855382,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark53(65.39401261166859,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark53(65.40328413823245,-0.8456265167095391,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark53(65.42290210293552,-0.06645888191860294,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark53(65.42547776308089,-0.7805750624901577,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark53(65.42748076281794,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark53(65.43244076117739,-0.9531362209079463,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark53(65.50005686503206,-1.2053315311869173,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark53(65.5114485900738,-0.53636532468132,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark53(65.52833262481951,-0.14071212002513356,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark53(65.60397862682406,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark53(65.61894724760717,-1.2096741584454662,0 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark53(65.64515718864804,-0.9204506812820016,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark53(65.66646601017702,-8.687876928532259E-7,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark53(65.68067664599425,-0.14248755992086012,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark53(65.70476229763949,-0.5555865407344456,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark53(6.570937229617611,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark53(65.7222578461978,-1.089684301406153E-8,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark53(65.7402404058023,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark53(65.78016537042606,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark53(65.7879671242247,-0.45997837600547825,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark53(65.80968897039679,-0.28248815798930593,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark53(65.83345779673269,-1.0696791268720744,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark53(65.87441104002812,-0.21137053523069937,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark53(65.92887616319615,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark53(65.97208917543497,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark53(65.97869813064383,-0.7455427691082122,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark53(65.98618187928292,-0.4017463664702761,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark53(65.99381377932713,-1.2682326795065961,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark53(66.00397725961258,-0.14024687961395177,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark53(66.00844505828144,-0.3131451546445163,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark53(66.01950876702068,-1.3640778090064885,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark53(66.02560096521509,-0.37159620666620385,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark53(66.02823006199486,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark53(-6.604908808677898,-0.023926074060206748,-72.43287458354314 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark53(66.05875587514886,-0.6800304100768553,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark53(66.17491506554026,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark53(66.17540861825307,-1.3937361092021137,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark53(6.618197309467135,-0.3695170695453811,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark53(66.19192615854854,-0.4139816080886337,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark53(66.24065384689698,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark53(-66.29395371827906,-0.35738905336039295,55.47563545782066 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark53(66.3872030357815,-1.081559146198551,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark53(66.4130016911538,-0.45859401869255123,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark53(-66.43801836091029,-0.12139193312124519,0.6302056086341356 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark53(6.6459937926513675,-1.2974738083571213,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark53(-66.47691868641166,-0.12439521441027068,73.44751866159075 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark53(66.48039812023808,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark53(66.48970575730664,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark53(6.650787043225722,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark53(66.55306942248606,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark53(66.56040477343603,-0.48034476152211975,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark53(66.56294893233189,-1.0888497793329224,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark53(66.57052716424872,-4.323576058559276E-16,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark53(66.60276760683419,-1.350988519150074,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark53(66.616463703964,-9.507960617448683E-8,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark53(66.6196905004176,-1.0080333568944138,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark53(66.64480306017416,-0.8512658676008957,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark53(66.65395976159797,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark53(66.70111815119998,-0.6620563050138921,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark53(66.829877427029,-0.21072691117413456,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark53(66.84882767783942,-1.3640019942692987,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark53(66.85328341904088,-0.29607082314892974,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark53(66.86167761595443,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark53(66.86573541196903,-0.7931515493385655,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark53(66.87043399639458,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark53(66.88514009008261,-0.2515090712348127,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark53(66.89551714035207,-1.1786082196701066,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark53(66.90359488541,-1.4723999514154256,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark53(66.90747022611666,-1.1061448348808183,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark53(66.9371945336747,-1.1985426990282937,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark53(66.93888166166568,-0.4218144802799788,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark53(66.94587301150627,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark53(66.96953755908521,-1.4439191172882317,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark53(66.97235766505352,-0.6792110867223125,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark53(66.9770333334553,-1.4337946359875673,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark53(66.99623914210105,-0.9705373105545032,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark53(67.04690929924199,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark53(67.10128885927925,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark53(67.10585073465327,-0.6027743978099522,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark53(6.7108496255142285,-0.6885336451736066,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark53(6.713987142387424,-0.07167782948529577,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark53(67.1442223967893,-1.3897964398283307,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark53(67.14960245689834,-1.2359645703787168,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark53(67.15483155033512,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark53(67.17800390064463,-0.3322470535504345,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark53(67.20729261393836,-0.45752080622205227,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark53(67.27385443369201,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark53(67.33311979885673,-0.7422684346203718,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark53(6.733968714859375,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark53(67.34103421946159,-1.2179754490800718,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark53(67.34137639611819,-0.9678160809278893,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark53(67.34547743191996,-1.249265337588028,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark53(67.34695982116351,-0.511922512078882,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark53(6.73888970816917,-1.3878746988977904,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark53(67.39361174983074,-1.4344792670729305,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark53(67.41748079874122,-0.10479523478757358,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark53(67.42532307567333,-1.1869706019125879,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark53(6.7482178976551594,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark53(67.48423673412256,-0.05206854697716908,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark53(67.4941086134765,-0.02080343868566544,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark53(67.51235361451029,-0.6940792582445026,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark53(67.51275020669527,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark53(67.5161778590222,-5.357820863617056E-9,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark53(67.53645589192868,-0.38835457324140066,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark53(67.5436793594883,-0.6366337818342966,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark53(67.56875965917587,-1.1596955465568706,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark53(67.57977539748408,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark53(67.60506567055567,-3.429069037403902E-8,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark53(67.65016598350655,-0.9009756471382779,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark53(67.664929025362,-1.4996981955062592,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark53(67.66985831187361,-1.4761092817710875,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark53(67.71025203547916,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark53(67.7117082362506,-0.06448896439922147,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark53(67.73628644786072,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark53(67.74183311481903,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark53(67.77001907958291,-0.3260268742291055,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark53(-67.77055596576953,-1.3357504545168787E-9,51.86147883934894 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark53(67.77641407344404,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark53(67.80696842190918,-0.10059369005576535,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark53(67.84394924248195,-0.164683532782135,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark53(67.869839726441,-0.3229560340624933,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark53(67.87146888919197,-0.017515289934573342,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark53(67.87735842851843,-1.4265033638724498,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark53(67.89668231339738,-0.42621958451011066,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark53(67.90597644773194,-0.14514572725772334,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark53(6.790707072650221,-0.42514655775778465,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark53(67.91517596764544,-1.499640975776436,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark53(-67.98309835234602,22.851434993931406,90.45537516178777 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark53(6.79850781267646,-4.438364390941786E-9,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark53(68.03583167319226,-1.0124042316383708,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark53(68.0530281454576,-0.08746746454757215,0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark53(68.11361816987201,-0.8544082129571287,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark53(68.13739064185927,-0.8393830414872618,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark53(68.19513901414581,-0.9919768165621317,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark53(68.20748433073162,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark53(68.22279588349792,-0.003933222490973831,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark53(68.2553716219254,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark53(68.27038223890396,-0.726406644954917,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark53(68.2826733168119,-1.3418016738096554,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark53(68.29213086626918,-0.22424342878989023,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark53(68.30233877642222,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark53(68.31676985556055,-0.3934323847851262,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark53(68.36470140240705,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark53(68.40996107409661,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark53(68.50553957472556,-0.28652476918714864,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark53(68.50948709595332,-1.0489509970079518,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark53(68.51571010861448,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark53(68.51921717239443,-1.3644753660110471,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark53(6.852196176719005,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark53(68.57162342210182,-0.8433119706643506,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark53(68.58135758501905,-0.19613143367553398,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark53(68.59042551117938,-1.4475917493998676,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark53(6.86181870247114,-0.1657720616795757,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark53(68.6399475291323,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark53(68.65394930762096,-0.3950085355983983,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark53(68.70258253385379,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark53(68.71634393419035,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark53(68.7214345757499,-0.865684580621652,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark53(68.74464434970426,-0.09522468446157006,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark53(68.76781995520952,-1.0912392493614114,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark53(68.80508820276336,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark53(68.81513768275457,-1.4724403832957194,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark53(68.8430042861736,-0.8782483637586949,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark53(6.886201085347977,-0.56874497748436,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark53(68.87049244394521,-0.6532307537151123,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark53(68.88351280540121,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark53(68.90797898170518,-1.4198142804388372,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark53(-68.93088227521547,-9.47903744663294E-10,-20.245790747256514 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark53(6.893994582153667,-1.432552134864423,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark53(68.96717924595076,-0.40488705535905467,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark53(6.89676671633859,-1.204309199972343,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark53(68.96964448996641,-1.3385222647273265,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark53(68.97025113109885,-0.7697112501952508,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark53(69.01737432054621,-0.10703829256160327,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark53(6.903571533457949,-1.1398673283688652,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark53(69.04778056781811,-0.05026968180255392,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark53(69.0631564958743,-0.23790994057856452,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark53(69.10211693380549,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark53(69.11019965640392,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark53(69.12499283108306,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark53(6.9162345745127505,-8.830158500457479E-10,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark53(69.1937534948631,-0.22736405605933924,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark53(69.26207696843477,-0.28252359616827505,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark53(69.3144862400568,-1.180993487304513,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark53(69.33689329038745,-1.0615843531586648,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark53(69.35857181819887,-0.2658746641439955,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark53(69.36549389931294,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark53(69.3771805296376,-0.16329914714318383,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark53(69.38827340106764,-1.0496886889705337,0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark53(69.39352567943982,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark53(69.46160244741208,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark53(69.51394170590308,-1.09808259113818,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark53(69.56520287345826,-1.1625976775070521,0 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark53(69.58759460836131,-0.411054386877828,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark53(69.60639111769672,-0.06922418594163915,0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark53(69.63315848387529,-1.0139961728144025,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark53(69.67094900805645,-0.9731628380405932,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark53(69.67807857254854,-1.2382401342767455,0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark53(69.72259358515188,-1.089845708018295,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark53(69.74380720836376,-0.6378730593758534,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark53(69.74753337377862,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark53(69.74916800339156,-0.4123745385818989,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark53(69.7621131306388,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark53(69.77768793661244,-0.22311077831632875,0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark53(69.7859211595986,-0.17693377022164836,0 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark53(69.79128353507132,-2.3098504600083854E-8,0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark53(69.83463782479564,-6.793929955644242E-7,0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark53(69.83687511248027,-1.18774093508654,0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark53(69.87653468075204,-0.18306796120117053,0 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark53(69.92856599175884,-0.44550805587696674,0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark53(69.94421077961931,-1.2331837488866437,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark53(69.97041625391236,-1.9088820455359275E-6,0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark53(69.99903254480728,-2.4312633750796134E-8,0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark53(70.01125220827498,-1.3852112785777513,0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark53(7.003911516813651,-0.3192429044398917,0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark53(70.07704239250273,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark53(70.11370712709208,-1.0385497791405403,0 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark53(70.14052660702791,-1.2604841401108433,0 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark53(70.20510402459723,-0.4307006519092282,0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark53(70.22148586330304,-1.4653060287478599,0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark53(70.22243476818014,-0.6275724010245085,0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark53(70.25336575007712,-8.091035896585707E-7,0 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark53(7.026013196234615,-0.6860965215840054,0 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark53(70.28340110880686,-1.0358673745849725,0 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark53(7.029457376453223,-1.2043826272713112,0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark53(70.31310874219149,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark53(70.32046985864272,-1.085274368686031E-5,0 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark53(70.35823529262578,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark53(-70.3986720467278,-1.3085702090843092,1.0000000004280616 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark53(70.40505130673992,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark53(70.42668251658735,-0.01677013607649816,0 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark53(70.48536963626614,-0.058859778798483,0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark53(70.49457892103291,-0.30939311695859395,0 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark53(70.52539141736608,-1.106658910832854,0 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark53(70.54740707305561,-0.12345294583232658,0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark53(70.59084412520288,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark53(70.65260781438309,-0.24911848255892632,0 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark53(70.68008362791483,-1.03355319163812,0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark53(70.68528367437804,-0.8935050041898309,0 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark53(70.83296694141416,-1.047453076450941,0 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark53(70.83507681902577,-0.5926161042092595,0 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark53(70.84409212354831,-1.2293299421694943,0 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark53(7.084763072422291,-1.1223354689530254,0 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark53(70.87715782354964,-0.37714067317550715,0 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark53(70.94516946780624,-1.1823390207011073,0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark53(70.95311284690165,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark53(70.99556945221343,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark53(7.100431140782754,-1.1956854320120067,0 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark53(71.01598139428317,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark53(71.02039062508405,-9.282652790924306E-8,0 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark53(7.105427357601002E-15,-0.04360470634558944,0 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark53(7.105427357601002E-15,-0.09912648672755608,0 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark53(7.105427357601002E-15,-0.6423491235867296,0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark53(7.105427357601002E-15,-1.108215898990772,0 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark53(71.07639331462713,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark53(71.08198697218765,-0.8918668949407333,0 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark53(71.12219323095553,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark53(71.14460215875368,-0.9746136863003239,0 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark53(71.15734425413352,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark53(71.17421586351905,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark53(71.17968156253146,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark53(71.22475591643544,-0.6798233903370772,0 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark53(71.22520559237648,-0.5877950079426881,0 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark53(71.23385503786713,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark53(71.24119692429741,-0.36683856153853983,0 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark53(71.25406610462014,-0.424850985127621,0 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark53(7.128516281289521,-0.7232740512453394,0 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark53(7.13150605554919,-0.004592033904627257,0 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark53(71.31903019556025,-1.1819607535965524,0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark53(71.32481327266514,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark53(71.34511799826025,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark53(71.37185781526355,-1.4830249062725347,0 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark53(71.37897772197192,-0.09976178273103642,0 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark53(71.38768899023165,-0.0033769043761182616,0 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark53(7.139266268252655,-0.3415996574659883,0 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark53(7.141576219157031,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark53(71.5301043692391,-0.6204976195514975,0 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark53(71.59408927006234,-0.05939763516482943,0 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark53(7.165836940229937,-0.38848924457590783,0 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark53(71.67647841168736,-1.0651015659289786,0 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark53(71.69016530733467,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark53(71.73183030449432,-1.2055003178727124,0 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark53(71.74315804194902,-0.025279894719318463,0 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark53(71.75175297452334,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark53(71.8244003267992,-1.4999999999996803,0 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark53(71.82876466666588,-0.14492453893898982,0 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark53(71.84377903947623,-0.4800660957041649,0 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark53(71.92491222099176,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark53(71.99413477213393,-0.5948698040219966,0 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark53(7.209031014819843,-0.6433459471501237,0 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark53(72.1256836801035,-0.3827179386226298,0 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark53(7.213904629260263,-1.4999999998675082,0 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark53(72.22032849978476,-0.848041109646247,0 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark53(72.2376083392925,-0.5223749057955098,0 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark53(-72.24633586320176,-0.8884368154633737,-0.05283991500499585 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark53(72.3115713888229,-0.08523234812078886,0 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark53(72.31487406365885,-1.731156122111804E-9,0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark53(7.242948357939923,-0.5461089486781532,0 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark53(72.46165351087325,-1.335958431531978,0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark53(72.49018382551078,-0.3774143375941159,0 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark53(72.53582222783596,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark53(72.55483711967955,-1.066719879171135,0 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark53(72.57834010725546,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark53(7.262231882007377,-0.027116709600020106,0 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark53(72.64111870291026,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark53(72.65623567204845,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark53(72.66038517075945,-0.8529187508185642,0 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark53(72.68037621983876,-1.4185425457610137,0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark53(72.74098193439072,-0.7237486043650312,0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark53(72.75332326505216,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark53(72.78115276154787,-0.36058356524206536,0 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark53(72.78854551349116,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark53(72.80757323623305,-1.1194776319523676,0 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark53(72.81264109202408,-0.23265160745492008,0 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark53(-72.91864684329425,-4.440892098500626E-16,1.0000000000000016 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark53(72.93831133710157,-8.043145588372064E-10,0 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark53(72.95727264034107,-1.422918558953043,0 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark53(72.98925937945523,-0.5100448544664475,0 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark53(73.02052999858562,-0.02262599818595401,0 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark53(73.02062320480896,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark53(73.02556326114231,-1.1975759863091628,0 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark53(73.02958060874792,-1.3285657438544993,0 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark53(73.04112488225309,-1.290757327162467,0 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark53(73.0488094140679,-1.4776710647516664,0 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark53(7.307751948263501,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark53(73.09966910109867,-0.5541579568004771,0 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark53(73.11902605286957,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark53(73.13545816254307,-0.18018769711816907,0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark53(73.14373024072566,-1.050841858339167,0 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark53(73.16469200057429,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark53(73.19224770743968,-0.9079547375001402,0 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark53(73.20489522217035,-0.05471687462582963,0 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark53(73.23283749285619,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark53(73.23391678075058,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark53(73.26097045675942,-1.4817818864938772,0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark53(73.29851776574256,-0.9449277182634009,0 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark53(73.32047478571369,-0.7520216942832391,0 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark53(73.32423116629687,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark53(73.3549204401796,-0.11348998977800079,0 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark53(73.35646504458404,-1.21621491053142,0 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark53(73.35703732238105,-1.3186658711610022,0 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark53(73.38133027503068,-1.425762677142913,0 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark53(73.381579833121,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark53(73.41917558347828,-1.081681008828122,0 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark53(73.44197261380211,-1.0013557962888622,0 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark53(73.45369198462913,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark53(73.47686483689519,-0.8820498949261051,0 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark53(7.348459308188004,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark53(73.53192223177402,-1.4999999999999796,0 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark53(73.55238473278321,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark53(73.55307024337148,-1.4470356566613671,0 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark53(73.55641362295398,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark53(73.56433178280125,-0.701601057459377,0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark53(73.5684969926516,-0.32127583697481255,0 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark53(73.58649129870719,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark53(73.58891508116147,-6.938893903907228E-18,0 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark53(73.62954046246792,-0.7941198519326091,0 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark53(73.64931855536244,-0.6875250428962922,0 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark53(73.67631185711332,-0.5460545331960276,0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark53(7.367898710639608,-0.47884352532589247,0 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark53(73.68699941220379,-1.290582928128586,0 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark53(73.7345851806787,-0.0038793805815570542,0 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark53(73.74708566227397,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark53(73.76049482425805,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark53(7.378079175140641,-1.440764909156492,0 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark53(73.84239236620283,-0.562468097173073,0 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark53(73.87918780013698,-0.008708279835519637,0 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark53(73.88044722870427,-0.6405093784706906,0 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark53(73.90536222906172,-1.4401027159862423,0 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark53(7.393263942260148,-0.16184912201872415,0 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark53(73.99553511071444,-1.2744330530293757,0 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark53(73.9957041313308,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark53(74.00267934102123,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark53(74.01351452849482,-1.2217589569963438,0 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark53(7.405634614053027,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark53(7.40563709480675,-1.283726828297778,0 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark53(74.05911585853053,-0.5874838904475137,0 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark53(74.10697273007256,-0.25999804755684863,0 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark53(74.13722757471888,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark53(74.15686348882912,-0.16398971814786023,0 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark53(74.18780622014302,-1.1677559999987892,0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark53(74.21787618606771,-0.550645834981607,0 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark53(74.25413692805004,-1.2411932781188981,0 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark53(74.28042459843238,-0.6354485664136109,0 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark53(74.2906885494088,-0.017527544308194365,0 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark53(74.29909837156467,-1.1203746477916618,0 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark53(74.36812659200567,-0.7280976057994906,0 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark53(-74.37325883140701,-0.20164421422189371,-1.0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark53(74.37731384792318,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark53(74.501798662737,-0.6524341301754908,0 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark53(74.54893763171859,-0.007680235198524787,0 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark53(74.55841732497518,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark53(74.55882028009248,-0.09041535187105765,0 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark53(74.58730663539953,-0.20102012631623278,0 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark53(7.4611000484845045,-1.4152996932876254,0 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark53(74.62366769958311,-0.0356728735156151,0 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark53(74.65807619674911,-0.25797325008865846,0 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark53(74.66895425492375,-0.30570968123089237,0 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark53(74.71404612557316,-1.0850809304942972,0 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark53(74.73811694475086,-0.10013066246894553,0 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark53(7.475781674637206,-0.0854859036317418,0 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark53(74.81335938298692,-1.0056716313054004,0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark53(74.83458836953298,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark53(74.85843994089899,-0.4259164022549421,0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark53(74.89677885135822,-1.4579771919231743,0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark53(7.49086696636283,-1.3926057657906699,0 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark53(74.92344180490403,-0.8997842916562888,0 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark53(74.9247660433914,-0.5561170754383031,0 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark53(74.93771589224374,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark53(74.94951436278211,-0.4576486991746407,0 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark53(7.499439139139872,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark53(74.99520187328324,-0.4594353954200301,0 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark53(75.02034544846248,-0.32174744962208646,0 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark53(75.04494914762124,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark53(7.504719452616143,-0.5289190890818043,0 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark53(75.13185232280459,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark53(75.18403568126016,-1.0272367245732257,0 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark53(75.19589491118238,-0.8616688121286127,0 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark53(75.19961851024257,-1.2764312232884851,0 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark53(75.22679491451879,-0.49526191977770395,0 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark53(75.2308087389275,-1.4491522271416142,0 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark53(7.525053537829898,-0.11913722590134745,0 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark53(75.35431140301316,-1.1759462802872527,0 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark53(75.36185427196143,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark53(75.37868655924811,-0.7664462130904384,0 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark53(7.539140693191953,-0.9755311931341666,0 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark53(75.41030528229939,-0.10840772736568839,0 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark53(75.4287732357055,-1.4539152070471775,0 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark53(75.46164968318834,-1.4523002491133283,0 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark53(75.53685454241193,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark53(75.53827491713135,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark53(75.55740440371186,-5.4139944672438846E-8,0 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark53(75.56207593668957,-1.2694746255825407,0 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark53(75.57168226564274,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark53(75.62529871344984,-0.5256003972492067,0 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark53(7.56388221341291,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark53(75.67808082786283,-0.5485752175107876,0 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark53(-75.69352509333481,-1.3961724283176984,-0.01604779208619042 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark53(75.6964517656671,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark53(75.70749899534411,-0.42477794446574,0 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark53(75.71550753978245,-0.00828723489517813,0 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark53(75.7439648787464,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark53(75.75513488797654,-1.1234247159462,0 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark53(75.76160376511811,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark53(-75.7933473701814,-0.39335917939427417,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark53(75.83503398824742,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark53(75.84318950305666,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark53(75.87698547394345,-8.067871228249709E-9,0 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark53(75.88844346420248,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark53(7.5907764422971775,-1.8565067358651252E-5,0 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark53(75.92754607972802,-0.03968543878796532,0 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark53(75.95347032349005,-1.210611367681878,0 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark53(75.98060138726072,-0.06844715739029805,0 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark53(76.0033776140052,-0.9291695663318312,0 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark53(76.0847216240548,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark53(-76.19512438075265,-1.7763568394002505E-15,-26.063255044887782 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark53(76.20449149996944,-75.23336569201405,86.70213826330965 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark53(76.22117435018825,-1.2768642715234648,0 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark53(76.22536001476729,-1.0693369733600377,0 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark53(76.27040297036066,-0.28586061827188725,0 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark53(76.35028345286369,-1.2794298918488707,0 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark53(76.35551545051487,-0.1073507946137271,0 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark53(76.38986372570218,-1.4109374574017082,0 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark53(76.4097848364035,-0.5873243839135904,0 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark53(76.4159601713445,-1.1533023656708752,0 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark53(76.46572963652346,-0.7710831484614804,0 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark53(76.46988529159796,-0.553926746454863,0 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark53(76.51011617650653,-0.4956469863120301,0 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark53(76.52464621645647,-1.052364799236642,0 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark53(76.56093154900032,-1.1080176196416491,0 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark53(76.72996768686045,-1.3022206401319067,0 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark53(76.74105162368184,-0.9307551932649005,0 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark53(76.75679513348334,-1.4958468183817462,0 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark53(76.82052391107788,-0.6074821955554199,0 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark53(76.83032201217148,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark53(76.83414999771284,-0.26854645202885324,0 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark53(76.84359377133788,-0.38329068503063857,0 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark53(76.91308540711577,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark53(76.92187502445464,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark53(77.01233676246932,-1.3251237922185015,0 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark53(77.02610181762833,-1.2994339094084353,0 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark53(77.1150252008629,-1.2745575181683657,0 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark53(77.21569718540985,-0.11892090060410965,0 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark53(77.21830101507754,-1.4469003898457657,0 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark53(77.23806995792316,-0.08445236009117596,0 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark53(77.26065054116935,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark53(77.30363237084258,-0.25107264972525023,0 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark53(7.734548499719864,-1.0720968907836141,0 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark53(77.36917325621006,-0.706216944427819,0 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark53(77.39813846910445,-0.48599946300371144,0 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark53(77.47484120994984,-1.4999999998837392,0 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark53(77.56389694406937,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark53(77.59799767165805,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark53(7.763111385307443,-1.111473689035623,0 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark53(77.63619599585482,-0.8644941200342364,0 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark53(-77.64296089203856,-1.4608230978971375,0.6565744511560982 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark53(77.64966644133534,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark53(7.766106361201118,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark53(-77.66404447704116,-1.1112103458928297,0 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark53(77.67023317697628,-0.7824440849916297,0 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark53(77.68033841778939,-0.2564799867311092,0 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark53(7.7695543049114875,-0.48332192253675954,0 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark53(77.70277010393535,-1.2151982444331086E-9,0 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark53(77.70340117366838,-2.274222853359747E-6,0 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark53(77.79033984158397,-0.6697634528047445,0 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark53(77.8835096219887,-0.016055643421073563,0 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark53(7.789773295486441,-0.20569260483048168,0 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark53(77.89893967260599,-0.030880160571516768,0 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark53(-77.90195795591717,-0.13297426103200394,0 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark53(77.94341551718182,-0.47349594753165114,0 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark53(77.95835624952255,-0.09537000751451086,0 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark53(77.97378740814632,-2.3347598543313074E-9,0 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark53(7.806400720962543,-1.0489012344962987,0 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark53(78.06701635905259,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark53(7.808058020636153,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark53(78.11763961070082,-1.4297521172179688,0 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark53(78.12438503147047,-0.887139977573355,0 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark53(7.815303386007983,-1.4787748954642037,0 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark53(78.16479282407775,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark53(78.20209009580753,-0.7706797891110284,0 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark53(78.21571482870465,-0.7303033394005638,0 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark53(78.26584832629919,-0.3295329121842623,0 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark53(78.31448060165914,-0.7086186882655625,0 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark53(78.35259173739038,-5.487573177133162E-10,0 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark53(7.836293036548781,-0.48243174403449274,0 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark53(78.41506568032528,-0.28537010367445176,0 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark53(78.45768909842235,-0.8416555964110075,0 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark53(78.51606198433149,-0.5685337855013801,0 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark53(78.5991149056984,-0.49126568785303526,0 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark53(7.860427724105795,-0.5507096219238665,0 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark53(-78.60782020889886,-0.23974609930335192,44.004327453741354 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark53(78.60982367967267,-0.290330573275412,0 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark53(78.67917048513206,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark53(78.71753867555609,-0.583012512337546,0 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark53(78.7519208578729,-1.17297957482603,0 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark53(78.78169343121431,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark53(7.889780684242997,-0.17449873166346208,0 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark53(7.89025744829148,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark53(78.93246786139463,-0.9161111308711192,0 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark53(78.93750481702106,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark53(78.94954594795426,-0.9703945220805976,0 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark53(78.96343834179066,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark53(78.97906744543388,-1.3450705867786183,0 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark53(78.98621921423279,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark53(79.05412457246209,-0.3230259003723943,0 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark53(79.07204577002517,-1.1460860412051233,0 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark53(79.08424414854018,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark53(79.10831472463926,-0.8315527582530038,0 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark53(79.13389456717474,-7.53522542456053E-10,0 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark53(7.914883064005977,-0.4665773786102818,0 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark53(79.16314501601214,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark53(79.20864331166811,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark53(79.24373383438282,-1.4324725052558165,0 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark53(79.24813454295193,-1.3218364790602521,0 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark53(79.28124356083265,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark53(79.30988200290724,-0.2562994375454548,0 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark53(79.35739380743343,-1.4377485808598056,0 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark53(7.937572414089615,-1.38528928784292,0 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark53(79.38774527670508,-3.511680358478361E-8,0 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark53(79.39783755120018,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark53(79.47739694972245,-0.48254912779303893,0 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark53(79.49256829603877,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark53(79.50164841823829,-0.20981963276203353,0 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark53(79.56324501657888,-1.0360713282279175,0 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark53(79.62189013902173,-1.0806813604268726,0 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark53(79.6257118010883,-1.2956870616203444,0 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark53(79.66435457387043,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark53(79.70573393463037,-0.8297510698206167,0 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark53(79.71888717635198,-0.3912483143635237,0 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark53(79.7618567243082,-1.1769200399492492,0 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark53(79.78863256875519,-1.0484328039189288,0 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark53(79.80775408406134,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark53(79.81363121273034,-0.4232633104879806,0 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark53(79.81587763997982,-1.324976041545498,0 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark53(79.85202724207511,-1.275203801492883,0 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark53(79.9280893699873,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark53(79.95069569071666,-1.2821893742987527,0 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark53(79.97444821321301,-1.3281020208961536,0 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark53(79.97496339677502,-0.5886675741079284,0 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark53(-79.9837462539893,-1.2400581430917186,55.582556694337825 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark53(79.98702276693737,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark53(79.99716593691403,-1.0019373801109452,0 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark53(80.06718690215054,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark53(80.06836209312175,-0.9940389753845107,0 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark53(80.08425976043932,-0.32693645558252626,0 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark53(80.13749610752544,-0.8933019312927541,0 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark53(80.15199459499006,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark53(80.18256355080024,-1.068336815125836,0 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark53(80.21380538503655,-0.7335394672204387,0 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark53(80.22933688018139,-0.5723391096974938,0 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark53(8.025581072123705,-1.48876621762997,0 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark53(80.25811433461934,-1.2036162244572746,0 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark53(80.27755239439298,-0.17028105586149045,0 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark53(8.02793288872445,-0.9782106703460665,0 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark53(80.29258444746952,-0.6635429743281938,0 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark53(80.29370517843637,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark53(8.03147233388735,-1.0516148869042308,0 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark53(80.3240747872114,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark53(80.33044723579138,-1.3326946544229656,0 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark53(80.35954922159692,-0.6688538367241676,0 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark53(80.3832245671675,-0.6790633360047582,0 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark53(80.4067078163472,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark53(80.44115676064268,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark53(80.48931010890465,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark53(80.49112793387602,-0.3349997148219541,0 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark53(80.50945334203321,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark53(80.54033749547474,-1.3173156549705876,0 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark53(80.55228477629684,-1.1572404069932678,0 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark53(8.05894828680998,-0.8078505621162417,0 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark53(80.66759874710539,-0.8162132594432489,0 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark53(80.6798644036339,-1.0852946717233136,0 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark53(80.73440085379761,-0.40926632788358575,0 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark53(80.7719068589492,-0.4241655106294385,0 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark53(80.77763835108115,-0.5110197566813146,0 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark53(80.78841058303163,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark53(80.90652660600392,-0.6491182230723638,0 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark53(80.9164609500003,-0.047989987362925035,0 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark53(80.925566964203,-0.3220029183289379,0 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark53(80.97013930765277,-0.9399528758849875,0 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark53(80.97612641315547,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark53(81.0686712428839,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark53(-81.11238322121565,-1.73045635131348E-9,-1.0000000004623313 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark53(81.17408235412178,-0.1024724038153828,0 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark53(-81.17578756010916,-1.1407777847286038,1.0 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark53(81.18015185417981,-1.0030077656569811,0 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark53(81.2452953584251,-0.7761625188640404,0 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark53(81.32574477623155,-0.30030276305883863,0 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark53(81.34687621713327,-2.0306246712107106E-8,0 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark53(81.37381505979616,-1.455872575656353,0 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark53(81.42124208143238,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark53(81.42995560536963,-1.3623484733099644,0 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark53(81.48474633807962,-1.2388613321024096,0 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark53(81.52068168356962,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark53(-81.54465022742671,-1.4999999976591631,-72.79378549844202 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark53(81.55363101817707,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark53(81.58513431834638,-1.1214070809569394,0 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark53(81.63610898443176,-0.9499025160277768,0 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark53(81.6751709088506,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark53(81.70740863947002,-0.9635552885839822,0 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark53(81.8155533084594,-0.6031781105790568,0 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark53(81.81963379028772,-0.41200023258533847,0 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark53(81.89647292434677,-0.06729945735930043,0 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark53(81.89678148875768,-0.5681828082970097,0 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark53(81.96385310545865,-1.3297138806610302,0 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark53(81.96421032431601,-0.45694741486889523,0 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark53(82.01164258696278,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark53(82.01630318028143,-0.995209658770948,0 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark53(82.05076051542713,-1.368844399291893,0 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark53(8.205651850269135,-0.7793186246954988,0 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark53(82.08760916018909,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark53(82.08968204438479,-0.929402240155111,0 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark53(82.13050677974827,-1.3251898767602616E-6,0 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark53(-82.13689652165093,-1.7763568394002505E-15,-0.9008113149751358 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark53(82.14918462182644,-0.3839925478753372,0 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark53(82.20977188623189,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark53(82.24602844264078,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark53(82.26904073747849,-0.1273901975648446,0 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark53(-82.27067689512884,65.96973382069967,-19.437711363943635 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark53(8.22846820381168,-0.4531413643836184,0 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark53(8.229210931619528,-0.013332047790865947,0 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark53(82.31311760990229,-0.032824016629883324,0 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark53(82.35328824806047,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark53(82.35699699643618,-0.15441025285926457,0 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark53(8.243454771803812,-0.9158682980839254,0 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark53(82.46502216543723,-1.2026978530816086,0 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark53(8.247778236122855,-0.6358119587739113,0 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark53(82.48540379415107,-1.11984627499681,0 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark53(8.250105366040799,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark53(82.51727236170925,-0.5763542734135436,0 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark53(82.52425055548511,-0.02336530223947801,0 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark53(82.571381549678,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark53(82.57317475632192,-1.1705360507622653,0 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark53(82.59749417199967,-0.0044092151438300045,0 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark53(82.63875104121686,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark53(82.6467420514094,-1.4999999999999867,0 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark53(82.65224281634315,-1.2780784267118817,0 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark53(82.70309642944612,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark53(82.7238005967989,-0.14745355407381433,0 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark53(82.726086091349,-1.277356607098622,0 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark53(8.276746513121594,-1.4347174798280888,0 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark53(-8.282722504127975,-0.03080928704152297,0 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark53(82.84241470711868,-0.9170602690203715,0 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark53(82.89870956102871,-1.3255176099343666,0 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark53(82.90968011405329,-1.1907057366466351,0 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark53(82.99453958947474,-0.891191698796134,0 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark53(83.02734925211928,-0.2805784426395581,0 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark53(83.08673454642278,-0.4441083941400801,0 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark53(8.314683506712958,-0.9950720357162859,0 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark53(83.15153987462523,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark53(83.15523338826938,-0.30653711622689706,0 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark53(83.32550617197467,-1.347689026368716,0 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark53(83.36929119093563,-0.04492737143887804,0 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark53(83.46672890067744,-0.37762701436799173,0 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark53(83.58759520793545,-0.568086172174191,0 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark53(83.60737132103056,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark53(83.72680986161586,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark53(83.86323508385414,-1.1277296217875534,0 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark53(83.86467766962707,-1.117454072333755,0 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark53(83.87660219117473,-0.2384963851399326,0 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark53(83.89254522027906,-0.971214528461589,0 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark53(83.89274115348792,-0.5744615640819579,0 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark53(83.92154899760834,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark53(83.9361157651403,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark53(83.94271414947937,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark53(-83.9454153163996,-1.1131180544938897,0.0 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark53(83.95032988751663,-1.4640224972886955,0 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark53(83.95966001997286,58.97839362857036,0 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark53(83.97541023128659,-1.2189716297133941,0 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark53(-83.99288810767251,-1.4999999999999982,0.6083922946146653 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark53(84.05252474904766,-0.37073230599398554,0 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark53(84.10498218160606,-1.2997587368673484E-15,0 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark53(84.13640931213143,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark53(84.17913816725144,-0.924657485142049,0 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark53(84.19031618831073,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark53(-84.21662768368891,-0.030726618546531803,0.2217449041437033 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark53(84.25169841782196,-0.7230400211497265,0 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark53(84.29430420263921,-1.0480840401073408,0 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark53(84.3590688680551,-1.4379585421052146,0 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark53(84.39336597185093,-1.2835810731095798,0 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark53(8.4438465230036,-1.1582010311420712,0 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark53(84.43903345371344,-0.0680874227139463,0 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark53(84.49010762699288,-1.245422977873318,0 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark53(84.57761179296764,-0.39590938495933814,0 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark53(-84.57960536788616,-5.5198061120771E-8,-1.6155871338926322E-27 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark53(84.59473677398762,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark53(84.6526189146052,-0.06137291364971986,0 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark53(84.66530043585163,-1.31634025937457,0 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark53(84.68023542589482,-1.1140738085940773,0 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark53(84.68364839702232,-0.65386444173354,0 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark53(84.68580000193319,-0.3789265097018797,0 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark53(84.69285129136094,-1.4551990746587848,0 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark53(84.71612777399406,-1.4064569527074502,0 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark53(84.76101521094449,-0.27704783822346624,0 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark53(84.76524551885728,-0.007901224898245296,0 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark53(84.8172341726283,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark53(84.82174375710166,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark53(84.83042466266406,-0.7111000037915289,0 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark53(84.836398107124,-0.04806223230251597,0 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark53(84.93486811208473,-1.0666906114580996,0 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark53(84.99012535033324,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark53(84.9997399852034,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark53(85.00245307562406,-0.9250687624480491,0 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark53(85.00896599025751,-1.3361596660144297,0 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark53(85.03685839118953,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark53(85.05217645640607,-0.4481464752837389,0 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark53(85.10829732952342,-0.4857564901976703,0 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark53(85.1225923672772,-1.4101819924829535,0 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark53(85.16033158213955,-0.45379197171716257,0 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark53(85.1768171871305,-0.32886805858365786,0 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark53(85.18304998125578,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark53(85.2700630812845,-0.970326664281691,0 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark53(85.29886507033493,-0.9852178415653281,0 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark53(85.31960792838132,-0.12984896648895417,0 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark53(85.33742750069399,-1.1713112514331812,0 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark53(85.40220831074936,-0.9926905400762134,0 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark53(85.43289422781518,-1.3054579237853563,0 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark53(85.43912711552116,-0.1730514386343316,0 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark53(8.548690323293433,-2.5014945122063933E-9,0 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark53(85.49872719528483,-0.16951817756041743,0 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark53(-8.551055968936923,-0.7971938574811477,-0.17673527044235016 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark53(85.52159980901331,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark53(85.55311717282471,-0.6938780640360572,0 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark53(85.59792312903846,-1.1263048451666404,0 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark53(85.76199697596402,-0.0727293689657813,0 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark53(85.7623995205833,-1.3341664120167565,0 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark53(8.580494127611246,-1.1829856763959142E-9,0 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark53(85.80683440724287,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark53(85.85471933772075,-2.1356341447063887E-9,0 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark53(8.588476241065784,-0.7621379770400152,0 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark53(85.89489613261244,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark53(85.91087344484906,-0.3673217275346774,0 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark53(85.92546928394933,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark53(85.95842127929042,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark53(85.99301381694548,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark53(86.00829302222061,-1.3877787807814457E-17,0 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark53(-86.02495635149705,68.35338199631721,44.81852180923036 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark53(8.602816554461675,-0.5942805229361472,0 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark53(8.60373714077862,-0.24417701080881749,0 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark53(86.04559643927686,-0.65351210451793,0 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark53(86.05317349376075,-0.16516922304690684,0 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark53(8.608335994916999,-1.2769044228814284,0 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark53(86.11856767195351,-0.8332851625550299,0 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark53(86.1248014150701,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark53(86.19121582190925,-0.706377397084804,0 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark53(86.19409285780327,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark53(86.21209536880653,-1.1943754872602064,0 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark53(86.23327075102434,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark53(86.23550101237734,-0.9346220925890947,0 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark53(8.630220305915827,-0.18813979986220208,0 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark53(86.30920960519987,-1.030332713595313,0 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark53(86.32714791146557,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark53(86.34059981848853,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark53(86.34422223097371,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark53(86.37174492612286,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark53(8.638035012451859,-1.8704671773448386E-9,0 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark53(86.38568486053649,-0.39166825369481373,0 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark53(86.41472992953595,-0.09306541669543655,0 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark53(86.43507670161591,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark53(86.44211878003637,-1.3689272246485853,0 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark53(86.44691057043002,-1.3606295958396235,0 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark53(86.45916076257916,-0.2180629948427246,0 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark53(86.47520839623951,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark53(-86.4794613762149,-1.485512723783354,-91.72055712148457 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark53(86.51962095974841,-0.3959684595995334,0 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark53(86.53376812877141,-0.7743813856197059,0 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark53(86.5653705867008,-0.9386203152961446,0 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark53(86.57175453637188,-0.54805677184702,0 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark53(86.58607809904197,-0.35067125647309716,0 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark53(86.65998857539893,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark53(86.71379795494977,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark53(86.74831647524687,-0.5118333730706599,0 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark53(86.8375794046843,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark53(86.88225416774675,-0.1995681082566465,0 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark53(86.91573150186031,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark53(8.693060827802327,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark53(86.94580702383254,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark53(86.94939906010285,-0.09697654847170156,0 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark53(86.95963116457864,-0.6236264388978574,0 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark53(8.700891843560271,-1.092885568922307,0 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark53(87.04483021075714,-0.1469567935542515,0 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark53(87.04944195603929,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark53(8.706842636322609,-1.3692773986669124,0 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark53(87.0738301320718,-1.1086584582346006,0 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark53(87.11755603867249,-1.1605004580391522,0 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark53(-87.12895714203094,-0.3441609265995261,-0.9486196726857824 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark53(87.12931321813684,-0.6229654353027902,0 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark53(87.14612775193422,-0.12206079141334669,0 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark53(87.16165033240887,-0.07700426279377837,0 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark53(87.17095067162072,-0.7894878100873655,0 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark53(87.17165340175526,-1.0844930032474398,0 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark53(87.17910894737162,-0.6377806165014146,0 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark53(87.20816620313032,-6.058938570414617E-8,0 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark53(8.721460051885582,-0.7700574140200587,0 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark53(8.722144790471617,-0.19686725766495528,0 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark53(87.26488599426705,-1.082193978312362,0 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark53(87.33775429075087,-0.5538460879375862,0 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark53(87.35728103418012,-0.29789297588100005,0 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark53(87.37397794554832,-0.843985914693695,0 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark53(87.4825751349533,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark53(87.49762309315102,-1.293375251326438,0 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark53(87.50826065441117,-0.4011966264413527,0 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark53(87.54345969701768,-0.7543906394077169,0 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark53(87.62545551728215,-1.3446719659688915,0 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark53(87.63608815016474,-0.2559258528808357,0 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark53(87.68093471903893,-0.02988597400165431,0 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark53(87.72167749471694,-0.8280606185484487,0 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark53(8.774174203090652,-0.204022907672476,0 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark53(87.77957593987784,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark53(87.85405020740816,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark53(87.87468720077325,-0.18088759347596195,0 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark53(87.89571338899333,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark53(87.91476117688478,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark53(87.95527003433449,-1.4906101253736481,0 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark53(87.95897735369269,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark53(87.97742960769926,-1.0039796180998684,0 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark53(88.00837764753877,-0.10345362454297735,0 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark53(88.0269734742948,-1.057786078144438,0 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark53(88.05402838423436,-0.27098123028992305,0 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark53(88.11050508917813,-2.102069830486395E-6,0 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark53(88.11476323712765,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark53(88.17366536534509,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark53(88.18508225624433,-0.23374927493932637,0 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark53(88.20736246330395,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark53(88.21069451636194,-7.718488285683023E-6,0 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark53(88.32897341589444,-1.0741477865549456,0 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark53(88.41538045734745,-4.996270297929186E-10,0 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark53(88.42379732117888,-0.6382013216513087,0 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark53(88.44526469728888,-0.9522499390003816,0 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark53(88.44627734768105,-0.25688784008104903,0 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark53(88.47138014454993,-1.3483158157982764,0 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark53(88.48096319540166,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark53(88.50960266585304,-1.227084625501793,0 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark53(88.51267904697119,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark53(-88.60492815936388,-0.2818897132124781,1.0 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark53(8.86130616422571,-1.0740747648385138,0 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark53(88.6869401632351,-0.43218444390477195,0 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark53(88.72878827900132,-0.7449683695767284,0 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark53(88.74049736794863,-1.4791997352639765E-7,0 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark53(88.75929943579249,-0.6288370444653317,0 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark53(8.877521057877843,-0.7658986309558884,0 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark53(8.881784197001252E-16,-0.106736556350981,0 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark53(8.881784197001252E-16,-0.3640431342308892,0 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark53(8.881784197001252E-16,-0.3930961040572729,0 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark53(8.881784197001252E-16,-0.4077371256251159,0 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark53(-88.8347958606647,-0.12169120930406395,1.0 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark53(88.8841228010613,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark53(88.95764585217009,-0.6382332951726681,0 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark53(88.97122443140466,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark53(89.02112036139707,-3.40461772767402E-9,0 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark53(89.10417129636802,-1.1381783788872484,0 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark53(89.11090018807427,-0.5785510578575987,0 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark53(89.1212052583187,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark53(89.13446596246067,-0.1674159538461314,0 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark53(89.16040974518967,-0.8228186889896484,0 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark53(-89.17794435990761,-1.3854759185299985,-0.1702526361158554 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark53(-89.21004013286762,-1.4999999999999991,1.0 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark53(89.21870924165589,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark53(8.923999825829698,-0.002698390035385914,0 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark53(89.26879339060065,-0.9195081096649504,0 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark53(89.28791554554151,-0.8752636331754218,0 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark53(89.29414293650584,-1.4660622049926673,0 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark53(89.29734796756438,-0.8947186865951711,0 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark53(89.31938255607716,-1.1202035906636612,0 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark53(89.35598573690353,-1.2493238038874268,0 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark53(89.38269055190773,-0.11398849087203189,0 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark53(89.39267606714648,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark53(89.40806035650962,-1.1106470555909596,0 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark53(89.41794815042434,-1.4685870193170256,0 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark53(89.4728081336261,-1.2698580643552975,0 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark53(89.48768969680549,-0.9763654425874433,0 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark53(89.52102713011419,-0.0021961330202344698,0 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark53(89.56718837776182,-0.9622355695896605,0 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark53(89.56792297506618,-0.019977367663031487,0 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark53(89.6363476999519,-0.5237345351278435,0 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark53(89.69315888446897,-0.18272769253437815,0 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark53(89.70356013383056,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark53(8.973689669600304,-0.16477143081438017,0 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark53(89.739683269169,-0.42887755477691414,0 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark53(89.75917913705442,-0.1954053816910748,0 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark53(89.79445587931534,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark53(89.84250397323194,-0.12138776168147558,0 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark53(89.85452294742846,-0.8317124368667095,0 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark53(8.991979989159773,-0.04637250161418649,0 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark53(89.97309145957006,-1.4883804870870019,0 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark53(90.00604384145117,-1.1547181678651417,0 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark53(90.02037766678026,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark53(90.03033814356674,-0.7735702408857263,0 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark53(90.03644924514845,-1.0101607710757303,0 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark53(90.07922899439268,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark53(9.021809158325956,-0.14354460710545386,0 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark53(90.2322913324816,-0.8480617084031206,0 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark53(90.23249182390893,-1.3298137200831042,0 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark53(90.23536980561556,-0.26995633216008563,0 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark53(90.29448595684458,-0.1098694223033192,0 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark53(90.31116585911703,-1.5031247276871906E-8,0 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark53(90.31218857224475,-0.20193004981977392,0 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark53(90.31749497603363,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark53(9.032386835946756,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark53(90.33154330768559,-0.6900169326565617,0 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark53(90.34416446229966,-0.32515975840983635,0 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark53(90.3520558755024,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark53(90.38827959307189,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark53(90.38892395797109,-0.31270057654863814,0 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark53(90.38901651845862,-0.27315930961258283,0 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark53(90.39181769333345,-0.004061715117905873,0 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark53(90.4207519400382,-1.4060110311050522,0 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark53(90.4228337052535,-1.1029898536351848,0 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark53(90.42944617566522,-2.0128437098981134E-8,0 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark53(90.4600448183374,-0.7817125276467429,0 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark53(90.46930551019094,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark53(9.053517769034798,-0.047536930587507825,0 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark53(90.54727778447551,-0.6561228545927804,0 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark53(90.55534684550761,-0.8991175475827902,0 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark53(90.55956883187051,-0.8322508400420316,0 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark53(90.62447591465275,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark53(90.63559415680862,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark53(90.66185313838008,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark53(9.076834452978375,-1.4999978864224182,0 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark53(90.78258617037397,-1.0392345731703934,0 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark53(90.802421667629,-1.4071133802218203,0 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark53(90.81272086142431,-0.09296812388973752,0 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark53(90.85256478986946,-1.007502399121634,0 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark53(90.87091855680492,-1.229388759143478,0 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark53(90.94217557285921,-0.9896549334862481,0 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark53(90.9485948878096,-0.8974117939016111,0 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark53(90.97507594749905,-0.10825122559554723,0 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark53(90.97801899770599,-0.13926194830896704,0 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark53(91.05833736967145,-0.513583965903436,0 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark53(91.06210869075565,-1.2710754202733379,0 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark53(91.08737785400713,-1.237223808358573,0 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark53(9.110109704429727,-1.4999999997328592,0 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark53(91.1118225077395,-0.467295442868491,0 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark53(91.17388418595289,-1.4988585719591865,0 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark53(91.19379264775046,-0.11845255146684985,0 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark53(9.121846892511257,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark53(91.25033891398604,-1.1053298186517169,0 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark53(91.26120177575098,-1.5509403062407367E-5,0 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark53(-91.28119929102844,-0.4815874448945173,-66.06367414661148 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark53(91.36713574616456,-7.836538867898626E-10,0 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark53(91.45453723463768,-1.0801516637263324,0 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark53(91.47557279701272,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark53(91.49773192179202,-0.9078660109251313,0 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark53(91.52536557769446,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark53(91.53382273901244,-0.34996563985051665,0 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark53(91.58895593694203,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark53(91.65944443071118,-1.1266247644159364,0 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark53(91.66128077099731,-1.234070481743803,0 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark53(9.170155053922713,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark53(91.78900117933162,-0.9566278569891913,0 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark53(91.81029105225014,-1.4205402549642647,0 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark53(91.83470143602679,-0.11718018784433348,0 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark53(-91.85004938273826,-1.4549191255292375,0.678097569897666 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark53(9.187280632127127,-0.512180974603984,0 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark53(91.8772969371966,-0.8105794210537312,0 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark53(91.9137127154739,-0.26680522254109906,0 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark53(92.03710633172575,-0.7544590814064032,0 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark53(92.0667573983726,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark53(92.19932584003325,-0.005530968526797686,0 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark53(92.33099863605742,-1.2672227438673305,0 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark53(92.40624400058653,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark53(92.4530739053562,-1.0915756334579852E-7,0 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark53(92.46228297577136,-0.8371528719025043,0 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark53(9.251567134342224,-1.2034206210510714,0 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark53(9.257509344979434,-1.0707292242914064,0 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark53(92.5776673761075,-0.8575170689790423,0 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark53(92.66023197275058,-1.4114378875073206,0 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark53(92.70180628136237,-1.487440855450938,0 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark53(92.70899843234528,-0.9070525860707253,0 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark53(92.75344781404863,-0.5462420001043711,0 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark53(92.78698403523254,-0.7190863601350379,0 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark53(92.79364547428379,-0.3888940176830231,0 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark53(92.79463098946012,-0.4445237778016442,0 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark53(92.82654838919564,-0.7083726847766165,0 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark53(92.83539137247863,-1.02564941998817,0 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark53(92.84183485815859,-1.1265771900009334,0 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark53(9.286039099634618,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark53(92.89257779948431,-1.06232368997339,0 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark53(-92.93133996935069,-0.7891703304883988,6.462348535570529E-27 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark53(92.97042168023623,-0.33336867873180687,0 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark53(92.99798277688473,-2.2199369812738957E-9,0 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark53(93.00868528404104,-0.9512652160649777,0 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark53(9.303612462186251,-1.0879030325557666,0 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark53(9.305915570202103,-0.5449632940731641,0 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark53(93.0625413810871,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark53(93.07389021260116,-0.09052138638494678,0 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark53(93.12474927514918,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark53(93.13896645997585,-1.1586147870202215,0 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark53(93.18832709674209,-0.32185405352078233,0 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark53(93.18976081090352,-1.1381332804898567,0 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark53(93.21660498990164,-0.21664623489374302,0 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark53(93.24029162290412,-1.3738189451807292,0 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark53(93.31764569374229,-1.2471693403599249,0 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark53(93.32875991188524,-1.3189198026434568,0 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark53(93.37958896762296,-0.11641686015542518,0 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark53(93.40088146619317,-1.2407832875443932,0 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark53(93.41668067369505,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark53(9.342761719918542,-0.8993900636597001,0 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark53(93.45323415469142,-0.8801048664053752,0 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark53(93.46002884115487,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark53(9.348019596354389,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark53(93.49414036018658,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark53(9.351658756098075,-5.510150999413462E-10,0 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark53(93.53054279888647,-0.2740028628806541,0 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark53(93.54751733400798,-1.3278405391105697,0 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark53(93.55674198142484,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark53(-93.59814721981135,-0.7138300796244579,18.364485582555623 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark53(93.62347481588864,-0.5274063293810771,0 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark53(93.65270157939787,-0.7773901228256364,0 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark53(9.365849392012166,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark53(93.65860334821788,-2.9437482414441153E-7,0 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark53(93.78230382015437,-0.9852936234746181,0 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark53(93.78623874208674,-0.7366933194873324,0 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark53(93.83939812962555,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark53(9.384145996281347,-0.1641422748698943,0 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark53(93.93388583649237,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark53(93.96330349375782,-0.43317941350818984,0 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark53(93.98118173276683,-0.6054063374988417,0 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark53(94.00207407194365,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark53(94.00903558237906,-1.1238923154751688,0 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark53(94.03396620102728,-1.2381909828174429,0 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark53(94.03649179702822,-0.4534095318038345,0 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark53(94.04125525965588,-0.9754600543690071,0 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark53(9.409342789300297,-1.1051994654063648,0 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark53(94.1338537060198,-1.4661629076619676,0 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark53(9.417454899218452,-0.39526975965662103,0 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark53(94.2271177041985,-0.0011661094255604792,0 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark53(94.23804693153451,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark53(9.428439930904588,-0.39230617424285585,0 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark53(94.29753122769897,-0.17547070326860936,0 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark53(94.31725333644849,-1.041537862960439,0 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark53(94.31913921285636,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark53(9.435483907979176,-0.2723090990299113,0 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark53(94.37951722923165,-0.37545371689869356,0 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark53(94.38664529181247,-1.4551493743206478,0 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark53(94.42020074946839,-1.2367415503070198,0 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark53(94.43005441835066,-0.036716609440199166,0 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark53(94.48983816298417,-1.1631699381814782,0 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark53(94.52284264620891,-1.2960321111183504,0 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark53(94.6880544843121,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark53(94.76651617950091,-0.22547919196945898,0 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark53(94.78055212693098,-0.5880408497615726,0 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark53(94.96207051332738,-1.279694469973137,0 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark53(9.505457831475799E-212,-0.7626107416633277,0 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark53(95.10269800073796,-0.6409281982981083,0 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark53(95.13330935327423,-0.20275370802933423,0 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark53(95.1637543598244,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark53(95.20573032538707,-0.3689106049022596,0 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark53(95.20704205897673,-1.4516873333131883,0 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark53(95.27995950572122,-1.1387826871473976,0 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark53(95.29358571902287,-2.889663249554603E-6,0 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark53(95.29399200782456,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark53(9.531156359253687,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark53(9.531914917684972,-1.2455048711010015,0 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark53(95.38282712319202,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark53(95.43292008231222,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark53(95.46795599342497,-0.9658397511794642,0 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark53(95.56486689480178,-0.6355321138568009,0 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark53(95.58617230901399,-0.2606379957350711,0 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark53(95.68732294472159,-0.6175836772171075,0 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark53(95.69936584365709,-1.4999999999999787,0 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark53(95.87557028568702,-0.8741816917710565,0 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark53(95.8974871733732,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark53(9.590063762428187,-0.05167636174917534,0 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark53(95.93324069558773,-1.4999999999999836,0 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark53(95.9389384612387,-0.34961612427573385,0 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark53(95.96792850571262,-1.1090726297318554,0 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark53(9.598557062045415,-1.4368786230811867,0 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark53(9.599705137942479,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark53(96.00472007209991,-0.04240356620838348,0 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark53(96.01409881675507,-0.41862302950352487,0 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark53(96.01530230440281,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark53(96.08552280229696,-1.4423642100958888E-8,0 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark53(-96.14743553623691,-1.42040607971785,-0.21385844645116614 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark53(96.15447363657746,-0.16382259531995236,0 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark53(-96.19736262353456,-1.1608699262549251,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark53(96.20839764107907,-1.2296573261116874,0 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark53(96.21570727519139,-1.1949875745809493,0 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark53(9.623874279132622,-1.2667364578346699E-15,0 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark53(96.25540485467056,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark53(96.30516648451163,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark53(96.35688281901938,-0.08331571323987086,0 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark53(-96.38234548504379,-0.03205921776001472,0.3731777807808613 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark53(96.45338580498559,-9.18256356827522E-6,0 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark53(96.47642564283271,-0.6125502184398697,0 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark53(96.486666926276,-0.9397050552168018,0 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark53(96.63246407424205,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark53(9.664246012434916,-0.97128126076709,0 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark53(96.64520178751968,-0.6561741954781866,0 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark53(96.64566455813568,-1.001494935941845,0 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark53(9.667008437565897,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark53(96.70778673401475,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark53(96.72298664872407,-0.5828672851889489,0 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark53(-96.73379850488075,-1.3373036764423485,-88.16972811068952 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark53(9.681190092663272,-1.4999999999717382,0 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark53(96.82079305053298,-0.37775081224905516,0 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark53(96.82405051260022,-0.9935460902404927,0 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark53(96.84117682254772,-0.18510689114467915,0 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark53(97.05516036346685,-1.0017586244141228,0 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark53(97.0844819861957,-1.4620400344546767,0 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark53(97.14742558836122,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark53(97.16035466275994,-0.09451229841430475,0 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark53(97.19481595247456,-1.2783159344430184,0 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark53(9.722716181905014,-0.35553492311829904,0 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark53(97.22729001096772,-1.212321257591574,0 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark53(9.726113560577517,-0.15928676372712602,0 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark53(97.31648515979444,-0.13036604325447226,0 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark53(97.35826760674831,-0.8796745484479089,0 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark53(97.38865560794429,-0.5538543089650148,0 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark53(97.3952752607128,-1.4822546028314123,0 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark53(97.41081132292919,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark53(97.44661872588077,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark53(97.52716141885938,-0.16840000156154034,0 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark53(97.57448365543515,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark53(9.76106379739889,-0.6811244408092172,0 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark53(97.62114528753284,-1.2813962781805628,0 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark53(97.64334150749448,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark53(97.6463940594875,-0.276041169916565,0 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark53(97.64979841143125,-0.05205223667157255,0 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark53(97.67966717332968,-1.3379369858921963,0 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark53(97.73228952917137,-0.6211359795002389,0 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark53(97.79101011654768,-70.63415207148856,-58.688178342922946 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark53(97.83794081143994,-0.9925215708950723,0 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark53(97.846489968815,-1.2815147868352765,0 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark53(97.86862717555786,-0.2332655315413774,0 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark53(97.87994721295848,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark53(97.89322670579439,-0.3555213613501691,0 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark53(97.8951216192288,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark53(97.92928643016597,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark53(9.793240228564898,-0.8494764012042992,0 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark53(97.95734155727511,-1.2501555840574077,0 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark53(98.0207724267689,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark53(98.0299211406928,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark53(98.03528390335029,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark53(9.803591648307886,-0.16380958081887337,0 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark53(98.05622906774681,-0.29364967430292716,0 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark53(98.07678565589089,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark53(98.08694514664424,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3992() {
    coral.tests.JPFBenchmark.benchmark53(98.10586477762037,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3993() {
    coral.tests.JPFBenchmark.benchmark53(98.14506777177729,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3994() {
    coral.tests.JPFBenchmark.benchmark53(98.14677932693519,-0.4744441215663735,0 ) ;
  }

  @Test
  public void test3995() {
    coral.tests.JPFBenchmark.benchmark53(98.16122073555823,-0.8573298585368452,0 ) ;
  }

  @Test
  public void test3996() {
    coral.tests.JPFBenchmark.benchmark53(98.16360900668849,-0.7669430762130958,0 ) ;
  }

  @Test
  public void test3997() {
    coral.tests.JPFBenchmark.benchmark53(98.20059898414794,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3998() {
    coral.tests.JPFBenchmark.benchmark53(98.24399525533042,-1.316109442349994,0 ) ;
  }

  @Test
  public void test3999() {
    coral.tests.JPFBenchmark.benchmark53(98.24544031046406,-1.2815592266131683,0 ) ;
  }

  @Test
  public void test4000() {
    coral.tests.JPFBenchmark.benchmark53(98.28677720294542,-0.1614947546944383,0 ) ;
  }

  @Test
  public void test4001() {
    coral.tests.JPFBenchmark.benchmark53(98.30033392577418,-4.8520891805715496E-9,0 ) ;
  }

  @Test
  public void test4002() {
    coral.tests.JPFBenchmark.benchmark53(98.32771506814692,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test4003() {
    coral.tests.JPFBenchmark.benchmark53(98.34237354826885,-0.8280771239485745,0 ) ;
  }

  @Test
  public void test4004() {
    coral.tests.JPFBenchmark.benchmark53(98.43604945064666,-0.9091182502615638,0 ) ;
  }

  @Test
  public void test4005() {
    coral.tests.JPFBenchmark.benchmark53(98.45077670188459,-1.3244217013869701,0 ) ;
  }

  @Test
  public void test4006() {
    coral.tests.JPFBenchmark.benchmark53(98.48444762589489,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4007() {
    coral.tests.JPFBenchmark.benchmark53(98.58579635654601,-0.6366869705104001,0 ) ;
  }

  @Test
  public void test4008() {
    coral.tests.JPFBenchmark.benchmark53(9.860761315262648E-32,-1.4978182329286065,0 ) ;
  }

  @Test
  public void test4009() {
    coral.tests.JPFBenchmark.benchmark53(98.65744939080449,-0.7461586256476073,0 ) ;
  }

  @Test
  public void test4010() {
    coral.tests.JPFBenchmark.benchmark53(98.67014393483458,-0.8418164292122099,0 ) ;
  }

  @Test
  public void test4011() {
    coral.tests.JPFBenchmark.benchmark53(9.867509185138326,-0.24040102369501426,0 ) ;
  }

  @Test
  public void test4012() {
    coral.tests.JPFBenchmark.benchmark53(98.75069381757878,-0.9577628561891212,0 ) ;
  }

  @Test
  public void test4013() {
    coral.tests.JPFBenchmark.benchmark53(98.75123450140532,-1.4859814037601184,0 ) ;
  }

  @Test
  public void test4014() {
    coral.tests.JPFBenchmark.benchmark53(98.7562292238826,-1.1271382842056283,0 ) ;
  }

  @Test
  public void test4015() {
    coral.tests.JPFBenchmark.benchmark53(98.77672352413535,-0.9241576778522074,0 ) ;
  }

  @Test
  public void test4016() {
    coral.tests.JPFBenchmark.benchmark53(98.80011232025677,-0.31442145954820155,0 ) ;
  }

  @Test
  public void test4017() {
    coral.tests.JPFBenchmark.benchmark53(98.83919655061072,-1.4924498800723143,0 ) ;
  }

  @Test
  public void test4018() {
    coral.tests.JPFBenchmark.benchmark53(98.88676055546145,-0.21390671959770824,0 ) ;
  }

  @Test
  public void test4019() {
    coral.tests.JPFBenchmark.benchmark53(9.896047008830369,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test4020() {
    coral.tests.JPFBenchmark.benchmark53(98.9611259219003,-0.06328642684669072,0 ) ;
  }

  @Test
  public void test4021() {
    coral.tests.JPFBenchmark.benchmark53(99.00069750649828,-1.10309670141649,0 ) ;
  }

  @Test
  public void test4022() {
    coral.tests.JPFBenchmark.benchmark53(99.1683567603732,-0.5350663085491594,0 ) ;
  }

  @Test
  public void test4023() {
    coral.tests.JPFBenchmark.benchmark53(99.17101550395037,-0.07815561653354863,0 ) ;
  }

  @Test
  public void test4024() {
    coral.tests.JPFBenchmark.benchmark53(99.19549478159975,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test4025() {
    coral.tests.JPFBenchmark.benchmark53(99.23476123885678,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test4026() {
    coral.tests.JPFBenchmark.benchmark53(9.923903368300245,-0.10257213097686702,0 ) ;
  }

  @Test
  public void test4027() {
    coral.tests.JPFBenchmark.benchmark53(99.25920608952141,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4028() {
    coral.tests.JPFBenchmark.benchmark53(99.26019590029892,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4029() {
    coral.tests.JPFBenchmark.benchmark53(99.26420875142225,-0.3194743367985069,0 ) ;
  }

  @Test
  public void test4030() {
    coral.tests.JPFBenchmark.benchmark53(99.27316819601802,-0.638228713896936,0 ) ;
  }

  @Test
  public void test4031() {
    coral.tests.JPFBenchmark.benchmark53(99.3179147626389,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4032() {
    coral.tests.JPFBenchmark.benchmark53(99.32090204160588,-0.7377222651344391,0 ) ;
  }

  @Test
  public void test4033() {
    coral.tests.JPFBenchmark.benchmark53(99.32640188281164,-0.38373970345668296,0 ) ;
  }

  @Test
  public void test4034() {
    coral.tests.JPFBenchmark.benchmark53(99.34889923545242,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4035() {
    coral.tests.JPFBenchmark.benchmark53(99.37559238699654,-0.21102761555658267,0 ) ;
  }

  @Test
  public void test4036() {
    coral.tests.JPFBenchmark.benchmark53(99.39054539895182,-0.5258314950518548,0 ) ;
  }

  @Test
  public void test4037() {
    coral.tests.JPFBenchmark.benchmark53(99.46293135824956,-0.31116552446702617,0 ) ;
  }

  @Test
  public void test4038() {
    coral.tests.JPFBenchmark.benchmark53(99.47686786347583,-0.5449048549653996,0 ) ;
  }

  @Test
  public void test4039() {
    coral.tests.JPFBenchmark.benchmark53(9.95454782298885,-0.3233223657196932,0 ) ;
  }

  @Test
  public void test4040() {
    coral.tests.JPFBenchmark.benchmark53(99.56596594386342,-0.0016352425339726403,0 ) ;
  }

  @Test
  public void test4041() {
    coral.tests.JPFBenchmark.benchmark53(99.63078280717825,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4042() {
    coral.tests.JPFBenchmark.benchmark53(99.68706455987706,-1.4991337578220083,0 ) ;
  }

  @Test
  public void test4043() {
    coral.tests.JPFBenchmark.benchmark53(99.69466649134117,-1.241167913182942,0 ) ;
  }

  @Test
  public void test4044() {
    coral.tests.JPFBenchmark.benchmark53(99.70159170882062,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4045() {
    coral.tests.JPFBenchmark.benchmark53(99.70498048218454,-0.17057991127789407,0 ) ;
  }

  @Test
  public void test4046() {
    coral.tests.JPFBenchmark.benchmark53(99.72057400224952,-0.7544269090203994,0 ) ;
  }

  @Test
  public void test4047() {
    coral.tests.JPFBenchmark.benchmark53(9.972893829008811,-0.5115436645026081,0 ) ;
  }

  @Test
  public void test4048() {
    coral.tests.JPFBenchmark.benchmark53(99.73268956958003,-1.4300348104580616,0 ) ;
  }

  @Test
  public void test4049() {
    coral.tests.JPFBenchmark.benchmark53(99.75254824451494,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4050() {
    coral.tests.JPFBenchmark.benchmark53(99.83979640466649,-0.49351530871500415,0 ) ;
  }

  @Test
  public void test4051() {
    coral.tests.JPFBenchmark.benchmark53(99.86929155104582,-0.5765670463446333,0 ) ;
  }

  @Test
  public void test4052() {
    coral.tests.JPFBenchmark.benchmark53(9.991058444733028,-1.152834508657591,0 ) ;
  }

  @Test
  public void test4053() {
    coral.tests.JPFBenchmark.benchmark53(99.91447320612545,-0.4070975929485574,0 ) ;
  }

  @Test
  public void test4054() {
    coral.tests.JPFBenchmark.benchmark53(99.91508966802323,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4055() {
    coral.tests.JPFBenchmark.benchmark53(99.94354085184268,-1.2874794645943228,0 ) ;
  }

  @Test
  public void test4056() {
    coral.tests.JPFBenchmark.benchmark53(99.94485821672811,-0.9795007284999852,0 ) ;
  }

  @Test
  public void test4057() {
    coral.tests.JPFBenchmark.benchmark53(99.95435713198881,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test4058() {
//    	UnSolved;
  }
}
