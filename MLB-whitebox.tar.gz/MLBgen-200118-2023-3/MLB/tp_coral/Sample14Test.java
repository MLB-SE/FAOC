import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-0.17905521249970774,-0.4932956822402492,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(0,1.8708197948159295,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(0,1.9367701547375589,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark14(0,-2631.9160116636945,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark14(0,-2731.0762387442264,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark14(0,-48.07543407291603,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark14(0,-4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark14(0,-53.57021090422229,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark14(0,-56.0471118654136,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark14(0,-57.04230593240525,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark14(0,-60.47087046494066,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark14(0,61.969109995363794,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark14(0,-6.447225061352711,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark14(0,80.67215388777649,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark14(0,-80.75026754240278,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark14(0,-85.30983456519674,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark14(0,-8.881784197001252E-16,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark14(0,-89.867202359461,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark14(0,-95.95422398717406,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000013,-1.5707963267948912,-73.6266418565823,1.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000018,-0.04623779880247464,-55.70360556982377,-0.03359664041478956 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000018,-0.9211482154104473,-0.3028415866029426,100.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark14(-1.000000000000007,-1.088161503500078,-171.76315026617613,-1880.3417026596933 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.004645737250952993,-69.85858640620741,1.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.006552136777984157,-1.2111600915659437,-0.7539027359953536 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.011184259523381201,-0.5022229263355769,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.012122718036249076,-100.0,0.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.01633912243734508,-1.5707963267948966,1.0000000864172391 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.022893780226204585,-14.429227986294265,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.023379572802830602,-926.0843072912313,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.029860460023764683,-83.25220532012952,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.04371296944609175,0.0,0.9999999999999937 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.051156514391227266,-10.500502803808844,0.06255680159917432 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.05398025045680721,-95.69105429771763,-0.8899815573005725 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.08527655736358714,-34.703279014125016,-1.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.08983519158036991,-73.96576083579093,65.38872695747588 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.10563725746904398,-0.236339842378003,-90.93631311032394 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1067048487350181,0.0,0.024363476959538048 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.12234538411713755,-56.58081520025408,0.9807255047605807 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,0.13987238097151092,0.0,40.6985498893277 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.14228147005695457,-1.487596152673792,-0.3718364761886155 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.14266725069386066,-1.5707963267948966,0.0039309204036263035 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.14725976686450054,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.15904391050551547,-63.58800099959892,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1825836040832738,-46.81490235435868,0.859310998117452 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.19769470695227298,-17.469667578373503,1.0000000000000036 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.20493925677864033,-14.783895060030881,-1.7720722428986715 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.2090099172768909,-17.517358656270353,-52.31407499501686 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.21207781334582276,-54.00910876942902,-29.791560283593427 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.22127474605802483,-71.52763973502064,0.006530996294497337 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.23248449889603273,-3.1661689130764614,-0.06305812041494903 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.25235177940865494,-1.5707963267948957,0.9243141634031322 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.2610061816543518,-19.111295148668844,-5.2710989716152616E-82 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.27992746317219286,-88.1553459768192,-1.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.28648323507334356,-4.636008802932309,-1.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3200225598650057,-26.426559087632064,-0.06310738723433022 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3471009826855642,0.0,-9.137654705843957 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3707567178485659,-1.5707963267948983,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3945733642117271,-1.5707963267948966,-45.416608162398525 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.42539697069906557,-32.63045491003412,0.028616647379270766 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4422739314105626,-32.465555810334564,-18.558466900182296 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4470129571027128,-11.049964699894044,-88.70027433530906 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.44928810873439184,-0.246983124747314,1.0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4576467346388908,-1.5707963267948966,-0.05175448844722369 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4598717763540414,-45.169371372995485,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.46481969264518186,-1.5707963267948966,84.05379458674649 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.47578207548389173,-95.58768806218296,0.8305194621224519 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4764918386704865,-1.5707963267948966,0.15643861094162126 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4774110639713002,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.48117637972587285,-24.74887663307853,100.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5061323262090986,-100.0,1.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,0.5141719395304232,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5216564534278221,-1.5707963267948983,0.06022433456674564 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5311542860346433,-78.61666600982728,-34.67497389840473 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5422954818273362,0.0,-100.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5480344059635218,0.0,0.05330276618328146 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5598645877482147,-0.06257884337945295,0.0061081409023730346 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5609144496760763,-1.5707963267948966,43.37933393268355 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5665580280699198,-67.05062341400149,-1.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5758708693013337,-15.745809188935112,-1.0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5817239138016641,-164.53587025633132,-0.7492670772189598 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5901445062395005,-66.8857231043624,-1.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5968425031873734,-86.65512221800604,-100.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6071249664540801,-1.570796326794893,1.0697101414704009 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6274260385209519,-68.75094617492272,-83.88795279989877 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6295514786817134,-99.3245521866688,1.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6456428044343935,-0.13205423516815984,1.0000061918710668 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6678544154114532,-52.159902280223584,-41.75977221210954 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6753679174709262,-31.834923531582515,-49.71005121716044 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6878287889475873,0.0,-0.9392514251356007 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6946869942426006,0.0,-31.44009033698447 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7347506289977499,-67.28067510867433,-1.0000000076662727 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7385475836091757,-53.6918018659851,-1.0000000000000002 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7397607070820698,-89.06081356741117,-0.8819425775246225 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7408543212062094,-1.5707963267948966,-0.08139979880185544 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7843603681972999,-24.608020870648296,-1.000005749069735 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7861457789366523,-59.68463472519256,-0.9046397829815263 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8029408738911874,0.0,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8102772010129344,-31.34738614759668,1.2556195445801151E-6 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8126093756393402,-67.18167581760792,-1.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8160119452443537,-95.41626672851949,34.786259906973555 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.822494903062644,-100.0,0.9999999999999991 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8259755780386897,-58.17571979879456,-0.8810972322473181 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8399921095426631,-88.91480740813769,1.0000000338579669 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9118539595022291,-0.04181738161328402,100.0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9211903165545954,-76.30846947072128,0.937012373801574 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9251229448841942,-9.60551007296068,-1.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9337649901259364,-35.79007367952878,0.06060439484530453 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9374992211249534,-27.51562562332792,-82.66620294138448 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9528550732047656,-55.295897353863516,-38.92253266785199 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9602401166099783,-53.86739047449079,1.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9717273069797445,-10.978847775758794,-5.2202435743988196E-54 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9750362545508098,-29.671862005090723,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9897235876600092,-51.03973936797081,1.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0076781524263545,-1.5707963267948966,-51.815105184674294 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0092399685559037,-1.5707963267948966,25.69368541527753 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0095390130371504,-16.07670602815576,1.0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0688058559387066E-16,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0785158560469574,-48.44381312311191,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1085732670130453,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1102230246251565E-16,0.0,-1.6704779438076223E-52 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1212289792928898,-1.5707963267948974,-0.8441739345941253 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1405481669218676,-31.056659710252642,-0.9852453608495334 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1439110369768661,-72.68811225276784,-0.2846508014655793 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1484177008422034,-27.748623038905425,0.10489618629759068 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1541091761951496,-41.28410808368374,-1.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.177701135430217,-100.0,0.03170964387820113 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.177888663666054,-0.19713946258963622,-61.44052169568002 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1818320200828816,-100.0,-1.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1951901285909177,-31.71633058410369,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2092442215712356,-34.564472316812704,-40.830745308673585 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2268623684435143,-46.2689556628618,-1.0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2409327607004628,0.0,-61.823317771827504 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2436366384629187,-73.37576097050334,1.0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2541908126670105,-51.50000547899217,1.0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2604674092827606,-25.20331938010415,-1.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3007078636236287,-18.054094649819703,-1.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3152082078602967,-26.869927928855702,12.622364226325374 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3256870360033037,-26.556463881952183,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3329325581257294,-94.20510407710685,-20.3668213059411 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3533280969711106,-41.917220127626514,78.94053402644069 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.358136036864508,-9.909221423099439,-41.747870804529065 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.374408926283793,-88.32679035322855,0.9999999999999997 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3823767342188704,-0.3405962121484438,0.43447481113640407 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.396913460877187,0.0,-1.3250168064042844E-17 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4047509564595948,-1.5707963267948966,-0.2395904810471805 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.442240652969275,-51.53988706391964,-0.04335162085886828 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,14.429205403640267,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,14.447214248220824,101.53387623769132,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4470430041376257,-68.52535704115583,-0.9434883242478724 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4783444240361827,-42.11146311531553,-0.04003677286700691 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4787696572848168,-0.5701546722067173,0.9999999999999996 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4893037692481892,-62.7825684806386,1.0000000574817114 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4975512997786482,-60.37406564104702,-0.9735748916917246 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5007753335344365,-52.57249011343953,88.31080119098502 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5070802100347147,-21.909090566614992,1.0000046461909002 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5224291374784642,-96.14776253678718,0.06268141511240263 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5260964657538523,-23.60840021683856,-0.9950665493785565 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5272715124879852,-10.619282252443952,0.9999999999999891 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5375987824475033,-20.40215586321918,-1.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5381071094783199,-1.5707963267948966,-0.9999999999999999 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5394156544100464,-19.08165335348357,0.0625525445820222 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.553933826349678,-1.3959243285860068,0.39025326491993906 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5620216859713618,-1.5707963267948966,-0.9142371797799036 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5622094967822944,-3.1312166290157073,-1.000000672119729 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948042,0.5132954652593156,-0.00997228884509707 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948521,-1.0646526356494865E-12,-1.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948652,-72.91933458566932,1.0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948788,-1.5707963267948983,50.22363610880748 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948877,-58.173485557238834,-52.50178041434258 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948895,0,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-100.0,1.8991135491519597E-65 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-30.36443028243757,5.420997303711701 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-42.10809528399498,100.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-45.35199452564285,-0.2751648442480241 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-5.786590539075263,-1.0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-61.93496988342459,-90.08919784261695 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-76.86997770528492,0.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-95.31331399542819,-1.000000004535981 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-100.0,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-39.404343864653164,-1.0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-4.9431971421432905,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-52.18625212185193,-47.05504762445739 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.570796326794895,-6.162975822039155E-33,4.48037851475884E-16 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948957,-2355.5959800588444,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948961,-58.18133198010455,1.0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-11.208123354651725,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-12.407185359334967,-1.0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-34.15223505735125,-1.0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-35.068781353433465,-0.5884685742805976 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-45.02954374790944,-0.9459512483380683 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,6.487136846172111,1.0000000000000002 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-68.36181654455764,-0.06258455200604152 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-95.67101047667978,-1.6472184286297693E-83 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-96.70595340433093,0.8557393520250258 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.570796326794896,-58.050402948855705,100.0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.6367794069241752E-15,0.0,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-2.220446049250313E-16,-1.5707963267948966,-1.0000001003705061 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-2.220446049250313E-16,-29.487782748902113,1.0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark14(-1.0002961385650435,-0.0016587397200466315,-10.724853047285585,-1.0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-5.551115123125783E-17,-13.23993712165159,-0.362089278313878 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,6.460897144539559,-0.904380455558492,-69.05477771868986 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-7.105427357601002E-15,-32.54725813758758,0.008615814829021184 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark14(-10.017924503147555,-0.5273704026603525,-72.65203382776988,54.877743957337145 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark14(-100.45661296412756,-0.4913397785674852,-1.5707963267948966,-1.0001461156988274 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark14(-100.75046970298926,-0.5861463237846758,-157.10333006495617,54.445460111511125 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark14(-10.106962110789283,-1.4370029639471,-0.5465973137752584,-2089.7258137239296 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark14(-1.0,-1.570350808353647,0,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark14(1.0,-1.5707963267948923,0,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark14(-1.0172066832353557,-0.8241107410034247,-1.5707963267948983,76.17341519692748 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark14(-101.87289544607106,-0.4150218513037266,0.0,0.0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark14(-10.228657390581013,-1.5707963267948175,-89.59714778572484,54.07642169864096 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark14(-10.237778874114973,-1.5707963267948948,-6.651551554841703,-0.13147619905481633 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark14(-102.51894575567877,-1.5707963267948202,-49.45785920965757,-2195.926597805808 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark14(-10.269330849192498,-0.121087948170335,0.0,-0.04717022116948045 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark14(-10.284083241132095,-1.4307576885329554,-37.31628675695102,4.141235466236324 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark14(-102.991551880961,-1.528066101324947,-65.05969318565033,-0.9999999999999156 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark14(-103.41016242928885,-1.3792205546683696,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark14(-104.31431670900986,-8.881784197001252E-16,-97.43150293968219,2147.924572851554 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark14(-10.453240508276393,-1.5707963267948963,-2.642064843108585,-0.03894579406616385 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark14(-104.66421802939236,-0.90473239564967,-71.39678142030834,-2153.977143706078 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark14(-104.86390166814778,-0.8408342987422851,-83.62121001490496,2212.5091728536 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark14(-1.0497462122951853,-1.5631442966998645,-40.046653118881125,-2.7117791282331737E-7 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark14(-10.515471429375449,-0.3350247544184789,-22.78976469500428,28.36134827211477 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark14(-105.42350812762282,-0.657544714085836,-5.039367432050014,-0.8838109642250036 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark14(-10.605673390864787,-1.5707963267948948,0.0,0.0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark14(-10.626361128791515,-0.201525145836569,-65.87836957827554,100.0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark14(-10.627447921810003,-0.38973854487179727,-64.69961240981932,-0.5186301881771938 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark14(-10.701659122254258,-0.8494526153971829,-44.83070747638537,0.9999999999999929 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark14(-107.76010745194644,-1.3994718670618225,0.0,2223.6457205809265 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark14(-10.856424722357124,-0.22115658354328582,-24.705071345460155,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark14(-10.955670755095383,-0.7363178950237738,-44.06576239493846,-87.57734418803429 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark14(-110.0470485389668,-0.11419299079541201,-18.08185794560545,1.0230788298742544 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark14(-11.077313416723852,-1.0989466029193071,-32.642693066349146,0.9980852625702245 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark14(-11.100944474356785,-0.42660221156471934,-24.163723222957387,-0.03484582345033613 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark14(-11.10510879232605,-0.4491079820902583,-65.2019199588908,1.0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark14(-111.15817016304139,-1.2938179876156681,-31.529528130542097,2147.0567711503645 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark14(-11.123054195884503,-1.541791427004848,-52.743308951610324,-0.20431085160084145 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark14(-11.12452517584673,-0.30567387711153393,-1.5707963267948948,75.83823409939072 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark14(-11.18274782979918,-0.151241201799922,-1.2403422380761013,-0.7416183054040169 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark14(-111.98776942271988,-0.008775618945089825,-128.31753705587764,-0.9999495665246887 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark14(-11.2053767202552,-0.3608101414593627,0.0,-1.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark14(-1.1297007458909953,-1.0392966530149124,-26.439569662109154,-41.039503504616086 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark14(-11.312447862534924,-0.41821836995029116,0.0,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark14(-11.335396610620393,-0.6173782517011239,-3.2631210284517964,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark14(-11.362948077874227,-0.015944044452311783,-31.690775509794257,0.8484615817055081 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark14(-11.364141897253287,-0.1733159407390065,-2.220446049250313E-16,22.074739301936887 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark14(-11.395671155320874,-0.46834052058510994,0.0,-1.0034114689822125 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark14(-11.405699435277821,-0.5414430362371698,-17.77634984512035,0.6583531615911429 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark14(-114.11093585420707,-0.21353193598780323,0.0,-0.047994703698888724 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark14(-11.485574342865362,-1.5707963267948948,-37.89628439050192,58.96132058925653 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark14(-114.98868846533257,-0.6343916988908409,-94.32480093644094,1.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark14(-11.584389064753882,-1.5707963267948948,0.0,-1.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark14(-11.621560846991002,-0.9505674389243293,-15.383676698679594,-1.0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark14(-11.65880290756135,-1.5707963267948901,-11.587525734695959,-0.01397823511873919 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark14(-116.87981755208217,-1.0674994861598048,-1.5707963267948966,-1843.0073844398837 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark14(-11.705176680339445,-0.632767439885331,-34.124506105920126,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark14(-117.15608136507291,-0.48242253877540797,0.43051817779376905,2014.737497224401 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark14(-11.740097077072747,-1.5707963267948948,-1.5707963267948966,-0.023514815127167722 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark14(-11.745686885015289,-1.5707963267948948,-67.58180273134096,1.0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark14(-11.771576777134726,-1.5195795825770837,-1.1270381385092931,-0.3429686004840753 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark14(-11.855681028998754,-1.5707963267948957,-66.53786891306818,1.0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark14(-11.899948957342252,-1.1743364557277178,-1.5707963267948963,-75.03767421723626 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark14(-1.2141812599956083,-0.30584247933876063,-71.53922679548116,68.70170137382507 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark14(-1.219268793977733,-0.0445920897003519,-98.31508410155291,-61.77748109618906 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark14(-12.24455943357764,-1.0018753454749432,-93.86451383292685,-0.04879707716850841 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark14(-12.245423121854031,-0.7955747088075243,-65.44679803186881,-0.4169607494125128 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark14(-12.354067625175011,-1.5707963267948957,-96.09308091939153,0.9907313600336668 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark14(-12.451963335567452,-1.5707963267948963,-4.2153549191226976,-1.0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark14(-12.452893601671192,-1.1427850819666971,-32.46127232047746,0.0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark14(-12.467836995690346,-0.38585659945657347,-100.0,-0.3562767241189202 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark14(-12.501357336824418,-1.4447270363999059,-4.482813204460384,1.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark14(-12.502656501251074,-1.5347933384986605,-48.642469942569036,-1.0151566554133094 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark14(-12.557364695946497,-3.667058418930377E-15,-63.33286294438391,-0.7969575152147638 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark14(-126.4046370615536,-0.3835518786826384,-46.46244962089864,79.87947711871175 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark14(-12.643939768380514,-1.5276088801289698,0.0,-6.6174449004242214E-24 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark14(-12.696349288068507,-1.5707963267948948,-51.72403702752542,-1.0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark14(-127.44352919777464,-0.04819748358234857,-26.440362007756697,-1.0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark14(-12.764839199027588,-0.408573215059832,-21.327505742065163,-0.25223248614198024 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark14(-128.14716011018848,-0.8989886916803584,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark14(-12.825148141466075,-1.5707963267948963,-27.814039365651134,-0.4484636729610827 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark14(-12.975924613160625,-0.48259663207275727,-136.1520955142018,-1.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark14(-13.037245150889726,-1.0695283370286375,-62.856099240124394,-0.030086219835429695 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark14(-1.3082636874589753,-0.597194354303132,-49.53557676184583,0.0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark14(-13.08657141551215,-4.440892098500626E-16,-88.09291331028913,8.438628550094894E-10 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark14(-13.2125224067677,-0.056564131283001175,0.0,-37.96390621485676 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark14(-13.241873834022856,-0.16760116609586054,-1.5707963267948912,24.04758733353529 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark14(-13.28368465670812,-0.23375608823987318,-1.5707963267948968,0.9430869620842998 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark14(-133.51152254760558,-0.49429969473776464,-24.76675418684859,1.0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark14(-13.407714199013862,-0.4904690951129882,-91.35266396511972,-9.836047584001454E-12 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark14(-134.0832930008067,-0.2268586768166952,-9.90362867368222,0.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark14(-13.424096617122908,-1.151394794841746,-55.92811815882392,0.10168783301065126 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark14(-13.570267332452504,-1.5705178415224619,-5.625413587965404,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark14(-13.583988072062304,-0.9975088331492401,-46.94239669989297,1.0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark14(-13.608910411720565,-1.197950129489322,-15.97534367837936,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark14(-13.614369629537352,-0.404742538920317,-73.44799639716017,21.276294474717936 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark14(-1.3717337303902855,-1.5651191051600997,-18.805124830404836,0.022622803409228842 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark14(-137.76430143386273,0.010055939837608885,0.0,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark14(-13.831556778721755,-0.6594443126466655,-1.0511325969625562,0.5720952561415391 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark14(-139.79201602141381,-0.8150044961787017,-4.665161478288635,53.09633638526188 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark14(-139.9340505125069,-0.9700935539858511,-84.48453312044293,-12.619076777136868 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark14(-14.018087545255824,-0.6691035077643528,-100.0,0.49127408124597344 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark14(-14.100532906660895,-0.17021110702352552,-47.44743496306557,0.9489598144636338 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark14(-14.134448914204507,-1.1407545580871266,-84.76951185182081,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark14(-14.208721820330823,-1.468564473775088,-60.84659242015857,97.13385067670245 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark14(-14.223242634344047,-1.2227949562927514,-72.7158620454938,0.9999917051037065 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark14(-14.223830120484353,-0.2370448881097273,-58.52544390752428,-44.784617126572016 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark14(-14.26340661217036,-1.5062535282698448,-1.5707963267948966,59.8375770208779 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark14(-142.94287182648375,-0.05705784324160966,-0.4128913139306358,0.0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark14(-14.377144299057498,-0.01876981006580692,-43.96820352342465,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark14(-144.49289768172594,-0.7658275466436493,-50.91538806443039,3.552713678800501E-15 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark14(-14.466514942365833,-0.8212055825802977,-61.35126166851488,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark14(-145.5640521521505,-0.3764081109156776,-131.34012176119145,5.995086375421721E-10 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark14(-14.593729533140138,-0.7303752461122355,-67.54813037705728,-100.0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark14(-14.66232419183335,-0.01532788035114896,-88.01336520841483,-0.45834773348600777 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark14(-1.4725368857464236,-1.4051814117519554,-51.205364347819796,35.58274903831392 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark14(-14.737465928063854,-0.6338925042010146,-43.18030104562995,-1.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark14(-14.782709522231485,-0.045500911616616645,-37.93708667479717,1.0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark14(-14.787627037070232,-0.5126475461594451,-38.91012156054736,-100.0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark14(-148.13560004906145,-0.1917652785447778,-1.5707963267948966,-1.29423933588006E-15 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark14(-14.90976992461627,-1.0462219193761322,-1.5707963267948966,13.553191836754458 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark14(-14.911979712112508,-0.6136724013422579,-3.469446951953614E-18,0.4755350076044782 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark14(-14.934248072637391,-0.046408962712603925,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark14(-14.996044398662734,-0.6627981694001817,-0.3901219162848455,-56.04961845403069 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark14(-150.16624977755828,-1.5406319642034219,-1.570796326794895,-0.9774391808296129 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark14(-15.096523569258213,-0.5460160810276607,-75.66336306497416,-3.2903311210082118E-6 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark14(-15.105798304550204,-1.0959384456360795,-0.21763291651205074,-0.21065692210230047 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark14(-15.142921508272309,-0.4892690910313664,-83.39355959401487,1.0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark14(-15.143006693550372,0.024032163311061974,0.0,0.0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark14(-15.201880877577146,-0.7648981062106238,-1.5707963267948966,0.8590802397201189 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark14(-15.306378928899662,-0.6668243763745298,-5.908149276394009,0.35848964622184987 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark14(-15.341044120864417,-1.5556999635513604,-4.3406763471996195,-6.430698213771224E-16 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark14(-15.429310736524409,-0.43566552502529005,-1.1102230246251565E-16,48.75953155965588 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark14(-15.46337665131484,-1.5216858717126303,0.0,0.0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark14(-15.46363958315066,-0.8573539337496475,-66.32416523858923,0.45651908083866843 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark14(-1.55398626445717,-1.3222445089041086,0.0,-33.56966614031759 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark14(-15.544257187577845,-1.1122095847198243,-1.5707963267948966,-84.73751916178239 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark14(-155.55283408638417,-1.2153765143403064,-35.25284363577168,0.5977470920092074 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark14(-155.64711619706054,-1.3186196880239933,-37.77099168958781,-1.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark14(-15.599216070321258,-1.4984788525871087,-89.40911747752938,-1.0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark14(-15.63682704378894,-2.9333023790567884E-4,-73.66661319332226,-0.043663645622666745 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark14(-15.690946361094941,-0.16591117790055718,-1.4957371778919306,-2.0501330894674953E-143 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark14(-15.767224838568765,-0.029214469676546173,-31.156637711373094,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark14(-15.837289940782107,-0.07465137514421794,-62.367914029377516,-22.18556830159673 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark14(-15.961198848069486,-0.7340310296380039,-23.585137908669523,-71.70089097307871 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark14(-16.025818133390466,-0.2155606860312531,-1.5707963267948923,-1.0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark14(-16.026967191924854,-0.5847953671019207,-30.31244763948197,54.142921826216835 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark14(-160.53000690014113,-1.3598796892312104,-88.5301404261707,1998.8362357508386 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark14(-16.064702687058613,-1.5707963267948912,-2.1445150729394413,12.30713892946153 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark14(-16.068182537750303,-0.006367530258196641,-13.885739072060858,-1.0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark14(-16.11598615330159,-0.8462957399887046,-100.0,1.0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark14(-16.13087949303904,-1.5504711336235497,-33.49936162344195,-1.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark14(-16.17284379970853,-3.552713678800501E-15,-0.7662779683064213,-1.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark14(-16.214225951461703,-0.16944520953367784,-68.36824255217479,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark14(-16.28437214115474,-2.220446049250313E-16,-100.0,-0.9999999999999999 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark14(-16.40932352848047,-1.2657441295446707,-49.95755056546679,-0.05185030468490037 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark14(-16.480144610079527,-1.5707963267948961,0,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark14(-16.533652853610533,-1.2568027126781733,-46.941292390174674,-1.504632769052528E-36 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark14(-16.606430166683857,-1.2513652363216885,-5.901693233235676,-1.0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark14(-1.662126180948463,-1.5707963267948912,-58.38925556870365,0.005283248123375144 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark14(-16.621859902850726,-1.5707963267948486,-39.039809960140225,-1.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark14(-16.643110114275903,-1.5707963267948948,0.0,0.004632686311339285 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark14(-16.644549648001217,-1.1806978943599087,-42.607761423689084,-0.8670961654878618 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark14(-1.6644833079298753,-0.7190843067865426,-72.22792664746,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark14(-166.83114897033425,-0.6909920582127853,-83.39531346683194,60.020079361738624 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark14(-16.68778243190981,-1.1104062150905363,-10.625182786447056,17.75219247409251 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark14(-16.762648755104067,-1.458409235110928,0.0,-83.9890187987049 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark14(-16.815093972848985,-1.5707963267948961,-8.864335924575947,1.0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark14(-16.86788820799424,-1.4210657136647606,-32.24709558727163,1.0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark14(-168.77108584414853,-0.9611079759065326,-43.84668596934904,-39.62199404131137 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark14(-16.88978091745495,-0.15590542807753158,-1.5707963267948966,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark14(-16.900398155565245,-1.5707963267948957,0.0,0.9999999999999964 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark14(-17.009339412142552,-0.2357915034499553,-10.476964951291954,-0.059638401863384274 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark14(-17.221490469971037,-0.5635413879176066,-19.016350191648684,-2181.7727912159785 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark14(-17.254555307367436,-1.5707963267948806,-20.334549744198785,39.87603093982402 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark14(-17.26346717027319,-0.03802274851666286,-1.5528589835029731,-1.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark14(-17.275100344562453,-1.5707963267948954,-45.141481086344285,-0.0625525480896996 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark14(-172.86657482227528,-0.8112750985510875,-73.32962630676775,1.0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark14(-17.325176840936052,-1.5707963267948957,-67.07426156678052,-1.0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark14(-17.34213759714698,-0.9435853246476144,-6.193438341945686,-1.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark14(-17.353959474551644,-0.14344318947169668,-22.868010066039755,-1.0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark14(-17.443089585843712,-0.6363608850963414,-1.5707963267948966,-0.06255346951026848 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark14(-1.7455708465428472,-0.2707643861426874,-13.102033082047342,-50.67118264796906 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark14(-17.45824984082786,-1.567508729769665,-67.50057194972652,-17.532267468966417 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark14(-174.9480812450542,-0.6819425844639939,-192.05682307529,-0.4999748659389418 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark14(-17.587726210480426,-0.6271720349477327,-87.9138038104941,3.9330871354739857E-11 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark14(-17.597545260448765,-1.5707963267948948,-23.46572893779353,-0.4703249559118996 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark14(-17.629176496486167,-1.2473480086071143,-0.2606390938403819,1.0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark14(-1.7640061457256966,-1.5618557035908016,-83.91881211760915,0.22993515773417128 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark14(-17.64768736333049,-0.3404961477276913,-45.55033408980304,-0.021551248820734892 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark14(-17.66987609613431,-0.09911471344312028,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark14(-177.09085870412198,-3.552713678800501E-15,-100.0,2252.150638257612 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark14(-177.2635501401108,-1.2348630491065187,-45.50326635524669,-20.080109219142713 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark14(-17.817236208507474,-0.012354764106589755,-37.160839761427795,-0.1207990445018794 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark14(-17.940100603973356,-1.4835586835327672,-46.76029565032596,0.6043947857843904 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark14(-17.991948020086816,-0.9125210364786124,-67.06030931605615,0.06048560639095428 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark14(-18.011310670489845,-0.8953675020470929,-98.06839163155684,-1.0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark14(-181.20442372816643,-0.30551881612055354,-72.62271048792155,2113.1188443889487 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark14(-18.210968802527407,-0.41459878047850895,-42.94324452858284,-44.991189144036504 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark14(-18.348803765643094,-1.515230919893182,-87.2412824320875,-1.0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark14(-18.428215966050956,-0.679151555806998,-37.638894227758776,-1.0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark14(-1.8439038831735117,-1.00898677701982,0.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark14(-18.462990352155796,-0.17881367180345273,-1.5707963267948966,77.09587760182538 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark14(-18.51957946023579,-1.3799363245218816,0.0,-5.397484419585437 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark14(-18.5722346315672,-2.220446049250313E-16,-31.73843181547322,1.0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark14(-18.597467039163437,-0.6003487798440719,-19.181411084025058,-1.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark14(-18.614091005983056,-0.4338118618981221,0.0,3.944304526105059E-31 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark14(-18.62369620564482,-6.038409241577176E-16,0.0,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark14(-18.62770097268885,-0.5572992691827551,2.512464009422659,1.0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark14(-1.8638650059011515,-1.5098222659480487,-1.5707963267948983,1.0000015263566908 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark14(-186.7347689662624,-0.5084396279549699,-35.800151921164804,87.56909676859118 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark14(-18.708935551085688,-1.5707839559822465,-60.95503439817294,42.03222552406598 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark14(-1.8732332126028108,-0.2992933088173233,-1.5707963267948966,0.475322737347471 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark14(-18.791477837435046,-0.39245458036337344,-0.3606320713628286,-1.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark14(-18.914440747123095,-0.9031875607426996,-61.32210781364299,0.8450201555386518 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark14(-19.037631971491734,-0.6315993780284543,-1.5707963267949019,1.0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark14(-19.07641769139881,-1.1774559671971865,-73.19600951114923,-8.470329472543003E-22 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark14(-19.11322022322763,-1.5108545008939769,-43.434657427769466,0.9999999999999991 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark14(-19.11409472587782,-0.4643383351330418,-52.658924896618785,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark14(-19.213781059058974,-0.06223442960061809,-67.39901014803519,-56.13837695367074 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark14(-19.268067573910944,-0.5002861796036439,-38.860539979031714,-1.0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark14(-1.9298037256712313,-8.881784197001252E-16,-31.349412318791693,-78.89684005313548 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark14(-19.305614603953423,-1.138160448551126,-44.01080925056249,53.56323369550043 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark14(-1.9332621822512337,-1.1267791492625128,-92.63347374025128,1.0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark14(-19.408302568347395,-1.0481369503758644,-1.570796326794992,0.059397595777974876 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark14(-19.4174821860467,-0.7779766699619342,-17.937378026641152,7.203362236772371 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark14(-196.16684341329938,-1.5707963267948948,-25.409437040123265,61.70963943384839 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark14(-19.66549456779545,-0.2376436467829667,-37.068759493616724,-0.13122382190516002 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark14(-19.687741625588288,-1.5707963267948912,-97.38945807426832,0.034919301848976736 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark14(-19.776083699797038,-0.7473258520160186,-77.53796339634248,-0.06255274259819674 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark14(-19.868649531444532,-0.495493292742583,-52.31170047676405,-2.5988524414112248E-113 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark14(-19.959444982987264,-1.5707963267948963,-81.28882905073647,-1.0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark14(-19.963522846536634,-1.5707963267948961,-30.50773950877006,-11.683000633547637 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark14(-19.97163574190178,-1.0895400005716773,-23.58127563969596,40.62400993054382 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark14(-19.972773000897536,-1.570796326794895,0.0,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark14(-1.999893565968108,-3.552713678800501E-15,-1.3753945548972046,-0.06366471463663748 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark14(-2.00193737350721,-0.4984735939986567,-1.5707963267948957,-0.03387962766223476 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark14(-20.02535925438915,-1.0511982326405427,-33.92858054539509,1.0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark14(-20.190710371400243,-0.3074186863606361,-47.59220116508672,68.92029101321657 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark14(-20.20282314385514,-1.5707963267948912,-87.25440679077127,-5.69685682419032 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark14(-2.022583596702912,-1.5131531623268986,-72.55710894194961,5.551115123125783E-17 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark14(-20.27202797507731,-0.9384491466282896,-37.81519394391883,0.966593517819819 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark14(-20.311036093426512,-0.1905138189308,-53.3983812305712,-0.5430531207260009 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark14(-20.351480300362795,-0.01699080910676515,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark14(-20.354674492583403,-7.105427357601002E-15,-84.10320546888248,-33.63750838608715 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark14(-2.038643443387116,-0.002803887284429093,-61.59781654832202,1.0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark14(-20.396637480680432,-0.2675579341032865,-44.25936499899386,-1.0600268417339163 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark14(-20.448282782666578,-1.5452206370984678,-1.5707963267948966,-0.5247801149403373 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark14(-20.5814903548643,-0.8270010951325979,-39.10529873522864,-0.7912148390268605 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark14(-20.5945529927206,-8.881784197001252E-16,0,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark14(-20.605861552551797,-0.786714501942928,-1.5707963267948966,-79.41994187313408 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark14(-206.1664464245261,-1.4720979830354182,-121.97235893831919,0.026062602619643646 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark14(-20.63499312189461,-0.07189693424182812,-27.979118648635648,-0.6032674571288826 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark14(-20.66982870622998,-1.548482886535666,-18.981261652491305,-36.316355922741735 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark14(-20.725618767466074,-0.21448497238546552,-1.5707963267948908,0.0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark14(-20.760749578028253,-1.5707963267948957,-83.97008164463848,-87.81785453713735 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark14(-20.826110135326893,-0.11653382785546208,-72.88778048747679,-0.299311509198818 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark14(-20.907917484362066,-1.2825711957968076,-100.0,-2335.1151774468676 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark14(-20.925804639500804,-1.5707963267948961,-83.89879429430557,-0.9999995384858517 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark14(-20.94287823553643,-1.316703951191268,-1.451999030280466,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark14(-20.995370414036294,-0.2519636556422397,-1.1965137763508782,1.0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark14(-21.13144932091229,-0.35790782263353305,-7.590824872668484,-66.24335859518528 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark14(-21.141507325927112,-0.13021554797012413,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark14(-21.16285724014113,-0.7908102057988129,-5.233427620755101,-1.0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark14(-2.1165313249701736,-1.2467113371907201,-81.73153863063857,-0.9926919769409254 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark14(-211.69063079270538,-0.360514319615973,-100.59537697764509,-100.0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark14(-21.1775450214761,-0.9211388648386633,-23.87317672929831,61.40256122850184 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark14(-21.2461897967748,-0.8700910568202771,-42.21495397600117,0.0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark14(-21.253106683322645,-0.01652676515870068,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark14(-21.282413503091036,-1.4772982645470973,-33.11190052092162,-1.0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark14(-21.411949831164602,-0.9829074883077578,-21.3882786151555,0.2782820664735283 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark14(-21.42700544803506,-0.7020532405040036,0.0,-69.9946247722991 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark14(-21.432419659312234,-0.6959875279522064,-25.269460075617033,2.3408381773460992E-97 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark14(-21.5394464272924,-1.228152123993035,-70.34202010119475,32.229173964299406 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark14(-21.56423497064813,-3.552713678800501E-15,-54.347721463303486,-25.782182185489006 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark14(-21.6037882696057,-0.46103188125805594,-4.5334617443543195,-1.0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark14(-21.604490812953465,-1.189313033662801,-1.5707963267948966,0.028726425753960658 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark14(-21.681132693136583,-1.5691325524064854,-1.5707963267948983,-1.0000214060981796 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark14(-21.7658263745368,-1.0630133628681706,-3.261345856032989,-1.0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark14(-21.82376654592308,-1.4908316947166185,-100.0,1.0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark14(-2.1828327656942252,-1.3805287897427458,-74.52295564568577,-0.6357992824209369 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark14(-21.870258723450064,-1.552196483965194,-1.5707963267948966,32.57373242296251 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark14(-21.904361249833535,-1.0167497849581082,-1.5707963267948972,-0.03008331590599711 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark14(-21.91131440264931,14.429204332199724,1.5707963267948983,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark14(-2.201813920481391,-1.531572915527347,-11.594461462087754,-0.031019555288339447 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark14(-22.05385639543179,-0.10024275819720942,-72.2914957774353,-2.6469779601696886E-23 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark14(2.217778841829144,98.63032884658321,67.65133604811774,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark14(-22.249342542048634,-0.009557060463138816,-100.0,-0.9423667299095778 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark14(-22.31858253240668,-0.7637298441286108,-0.4260156671797884,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark14(-22.379497706221752,-0.136647963390279,-1.3302965955560462,-1.0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark14(-22.405791125589893,-1.5707963267948948,-61.389390971969746,14.437711993702116 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark14(-22.419108796194934,-1.5707963267948912,-78.60710358901433,-0.6118928475529177 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark14(-22.637925075751355,-1.407192560359622,-0.004738862690911164,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark14(-22.674572932566612,-1.4310157191571506,-96.49732756360217,-0.9171839642091583 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark14(-22.816938684646487,-3.4612008517837693E-15,-63.56521694650747,1.0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark14(-22.82425119588511,-0.5654947277853464,0.0,-0.23730278949691197 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark14(-22.861080596529373,-0.9595087632757924,-37.84533615262853,48.117361197087746 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark14(-22.900442107898442,-1.5622286474242135,-1.5707963267948966,56.69042034836201 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark14(-22.92134768635586,-0.503411678315441,-1.5707963267948966,-0.49526587894473906 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark14(-22.93257432453813,-1.4156055402426988,-1.5707963267948966,0.9486303839657227 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark14(-22.952342683624188,-1.1273159142244777,-67.30925345458476,1.0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark14(-22.98465621615471,-0.8273498766733165,-5.588303310974375,-5.697396154566727 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark14(-2.298486831233541,-0.59850588908937,-70.0393298483899,1.0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark14(-2.302668636439023,-1.0205476139444798,-56.31155362099953,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark14(-23.056140026019552,-0.11581179284215226,-53.43404081149805,-0.6845576310770114 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark14(-23.059293589788965,6.5406487029735,-4.440892098500626E-16,-102.75664709466145 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark14(-23.08130319474557,-8.881784197001252E-16,-99.64712905062171,-1.0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark14(-23.112038186466762,-1.57079632679489,-19.395796565141772,0.14551703099177993 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark14(-23.148463322444954,-2.7016136048916335E-225,0,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark14(-23.200129088784724,-1.5707963267948963,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark14(-23.237439670099388,-1.5707963267948946,-3.460444916343144,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark14(-23.255622364408772,-1.5707963267948912,0.0,0.9927676281449709 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark14(-23.336503568677674,-1.5078161498745852,-103.50085886426064,-10.834809080767343 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark14(-23.35354575124311,-1.1441771904477114,-15.469160347883012,-51.44365694704223 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark14(-23.40428003836257,-0.9375741254371235,-58.919813097791994,-2247.618756034726 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark14(-23.502079096181976,-1.5707963267948912,-0.2900983677296205,1.0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark14(-23.54140497283553,-0.4207286516977177,-4.253347049617378,-0.7105969647850742 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark14(-23.569701471768838,-0.33955705158226035,-75.70745881769956,-82.36137104736167 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark14(-23.85243724668075,-1.4926131699432947,-25.10172206309373,0.8782099533317691 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark14(-23.877364637561527,-0.064147382143382,0.0,-1.0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark14(-23.889994797900858,-1.5707963267948948,-5.506153282193411,0.7477384787574133 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark14(-23.9544257537189,-1.5707963267948912,-30.985634061556095,1.0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark14(-24.010042239307964,-1.5707963267948963,-1.4935825004885863,-2106.408663306775 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark14(-24.03006963858403,-1.57079632679489,-82.43787550017818,-1.0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark14(-24.133151880872134,-0.01069138751271281,-67.2762844942333,0.07339997072822259 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark14(-24.144651420287147,-1.530177637915148,-30.23590414219919,3.469446951953614E-18 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark14(-24.16426307170086,-0.612488008655383,-20.95002911597956,38.91510233028572 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark14(-24.21166664449011,-0.9164314830259528,-84.18650180762123,0.6363746479193004 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark14(-24.266446324599666,-0.21157138432657485,-8.881784197001252E-16,25.531440413325413 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark14(-24.464629698567343,-0.291044222544258,-1.7763568394002505E-15,0.0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark14(-24.476350420307146,-1.145142603153536,-1.5707963267948966,0.44384702162754536 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark14(-24.502077835838094,-4.440892098500626E-16,-25.24380990178139,11.042169259912058 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark14(-24.552204980337425,-1.5707963267948963,0.0,-1.0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark14(-24.55779852979461,-1.1215615183019025,-29.93293954940963,0.042997987562156864 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark14(-24.653556406241325,-0.009400484210859261,-31.792480961665106,-0.9999999999999982 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark14(-24.676470349851357,-0.5280162813218112,-58.02501924337457,29.33560720466872 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark14(-24.6933929709147,2.4438273251634963,0.0,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark14(-24.708441128376805,-1.5566942239099418E-15,-85.91062098989333,-36.164297750877715 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark14(-24.709392571202585,-1.1668189568589376,-12.173355735007041,0.0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark14(-24.71613706758516,-0.0325822268299133,0.0,0.0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark14(-24.7775616317681,-1.5707963267948961,-44.209858597413806,-1.0000001796127487 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark14(-24.878265914489646,-2.564175202608162E-15,-1.5707963267949054,1.0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark14(-24.88115599700195,-1.5707963267948912,-27.388447873960864,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark14(-24.967905574758007,-0.0020494332415843066,-48.23473177421248,-0.01760551941610583 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark14(-25.000713162413753,-1.550714654524505,-1.0337206194902082,-0.03954382214785237 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark14(-25.020547932094413,-0.06802108112381586,-24.846125548512696,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark14(-25.027859517032056,-1.4216878450954424,-0.12193303813638146,1.0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark14(-25.197612994126843,-1.5707963267948961,-1.5707963267948983,0.6892743258749598 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark14(-25.256994776693546,-0.019212198644109953,0.0,-0.006066114204975853 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark14(-25.287045028709255,-1.4849928519874216,-1.5707963267949019,1.0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark14(-25.30705072096368,-0.624875440288651,-60.03159668962874,0.3462996107926985 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark14(-25.40295730631116,-0.8619426430534349,-16.99935690032514,58.62756722614945 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark14(-25.418841979783245,-0.34784525931266613,-88.5962922928271,6.776263578034403E-21 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark14(-2.5487850744415703,-0.8891137704917211,0.0,0.0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark14(-25.506058525707715,-1.5707963267948948,-75.81317298206724,0.21374335443145565 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark14(-25.518220081619134,-0.29018809341771307,-67.03074278567601,-1.0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark14(-25.522067979967403,-4.733564525891012E-16,0.0,-0.45550315594213187 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark14(-25.525512474608597,-1.5707963267948948,-82.18859386145907,-0.7312759862187359 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark14(-25.55101961962902,-1.1957975845381588,-1.5707963267948966,-3.1366622541576556 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark14(-2.5567797231451905,-1.5707963267948948,-53.8066718779159,39.306221827443295 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark14(-25.597333249114307,-1.5707963267948912,-10.918842504845065,0.007256004996512078 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark14(-25.8658828029929,-0.05003078757774837,-46.797174512990864,-40.826580282164464 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark14(-25.908646072421725,-0.01750201692509812,-77.00791187439198,0.346186141566944 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark14(-26.09460384704135,-0.5061804082164039,-13.333736982462202,0.6351966079030293 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark14(-26.158519895751976,-1.1517666190147406,-100.0,-1.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark14(-26.209717216020902,-1.2790140511483319,-0.026946249315248798,0.32029600595140306 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark14(-26.216502505317894,-0.5277595168321755,0.0,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark14(-26.278189541768285,-2.220446049250313E-16,-1.7763568394002505E-15,-7.401004444769165E-5 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark14(-26.372603964947967,-0.047283078908881414,-22.632982654634162,-2.6355494858076308E-82 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark14(-2.6373179030800884,-0.23515853540439038,-0.4996506372671534,13.06118304344816 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark14(-26.38762439388642,-1.3095585988116802,-92.04013799209314,-0.04040050065036649 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark14(-26.388229778875,-1.3117564796434773,-198.66132690472514,-65.28784822838307 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark14(-26.39466341477162,-1.0588825374139055,-70.05662538293716,0.25280501975663694 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark14(-26.495322322314074,-0.2952035014385359,-58.79578678677947,-28.448797837028827 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark14(-26.53112855075619,-1.3035718849874058,-1.168587955110682,19.08580158776594 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark14(-26.606076639101794,-0.4867312837242004,-1.5707963267948966,-43.103296212202444 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark14(-26.619448842255707,-0.6642827270676812,-62.12652543616853,63.05942070252869 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark14(-26.680749923284644,-1.1682055712418888E-15,-45.093547332293575,0.49339524096284526 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark14(-26.898359807659254,-1.5183178205554935,-94.82344120705301,-0.9999999999999998 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark14(-26.95034046437916,-1.4821225083981078,-36.48828487170932,0.06255412746109068 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark14(-2.701739953909442,-0.1191654679603742,-46.04997490697636,-5.892134088645214 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark14(-27.102409931569376,-1.4958410858522546,-57.15906982985577,-0.7962152227968572 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark14(-27.11117625192055,-1.5707963267948963,-14.266872901991729,0.012229630052547558 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark14(-27.149409962895906,-0.4023450956929594,-2.9219199324357107E-4,9.723461371658034E-63 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark14(-27.17587462307728,-1.5707963267948957,-1.5707963267948966,79.40665444383117 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark14(-2.7246416988009763,-0.8063554767584744,-46.00083055509516,-0.010230555801567724 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark14(-27.26770361310375,-0.19478835291891716,-166.03515316682456,79.96042822669969 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark14(-27.341875937188608,-1.3150625572461725,-23.85740427265145,28.83423613830763 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark14(-27.394755648563496,-1.5363078821306346,-8.951964417613635,1.0000280900243883 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark14(-27.574719467123124,-0.8564613601665321,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark14(-27.589519105452275,-1.5707963267948888,-1.5707963267948966,-0.13050839928449087 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark14(-27.60020248107405,-0.1994897974891443,-38.398753214148954,39.49391256348315 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark14(-27.601286420738695,-1.5325461279012567,-71.28212567579305,-0.297728332852238 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark14(27.651251114329035,-0.8089146369340139,0,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark14(-27.66249792290226,-1.5707963267948912,-33.80699595489686,-1.0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark14(-27.68010798294452,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark14(-27.70018876983991,-0.17230714253605464,-36.79845083643717,-0.49019605138927624 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark14(-27.787044534866,-0.4811311381877178,-1.5707963267948912,-16.25219807909895 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark14(-27.894245730793173,-0.15824944280645942,-37.458096144362564,0.009568075142563831 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark14(-2.8052101785084176,-1.5707963267948912,-4.1841621030115235,69.59527352337554 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark14(-28.07293480149538,-0.08101327773967909,-65.00614971148477,0.9520809506963985 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark14(-28.07654890299559,-7.105427357601002E-15,-3.209264186542768,-35.02680148682924 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark14(-28.110667655940702,-1.0743235325396103,-73.3282802707636,45.549209608802585 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark14(-28.149420038866594,-0.7614572183119255,-1.5707963267948968,0.05455151837763971 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark14(-28.205188719457496,-0.9467203614572546,-39.07606406530552,76.49404335745085 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark14(-28.217519367938447,-0.3735400869420005,-24.3124500527166,1.0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark14(-28.404749972690027,-1.3532277302332782,-3.5612145089158957,1.0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark14(-28.409470520311757,-0.3689928901091857,-4.473737269949197,1.0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark14(-2.842132601882583,-0.23145574596437418,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark14(-28.52650518135017,-0.07239062244478482,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark14(-28.67515436522372,-1.387812850118614,-45.120139613596024,-23.987524998216387 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark14(-28.74987928947752,95.3828870109459,-41.326972222866964,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark14(-2.876087481945518,-0.9497593604689314,-87.93101690254636,-0.9218236470811121 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark14(-28.79637411769867,-0.04687300135562217,-1.5707963267948628,-1.0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark14(-28.876849989312284,-1.4640458426309957,-1.4052900008400384,-1.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark14(-28.884029782451517,-1.5707963267948948,-100.0,-0.4353382132436323 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark14(-28.9772259531294,-0.3382740918153391,-9.586023435570961,-14.276368386320968 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark14(-29.033822246890747,-0.9617750199953696,-13.213022396324249,57.977870279728975 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark14(-29.170459388148537,-1.5707963267948948,-32.776221922119646,-0.8249913050599197 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark14(-29.26654300251925,-1.2028184764940313,-4.410887775511406,50.22325116202063 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark14(-29.352098066223846,-0.6426983518917879,-0.5298996174462666,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark14(-29.426987312676037,-1.5707963267948912,-129.97556279868533,0.06251068120102396 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark14(-29.457576434895536,-0.9689815512470461,-47.72760664234181,0.23330176893907817 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark14(-29.508209474625936,-3.552713678800501E-15,2.220446049250313E-16,-28.97676895755176 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark14(-29.56667697642775,-1.5223344245258206,-12.61514512310815,-1.0544369506927362 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark14(-29.58008864412255,-0.8012581227874112,-17.03498541652617,0.0010152216787844281 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark14(-29.612361573802406,-1.5707963267948912,-3.8527796133254935,76.43192959923451 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark14(-29.668669308810543,-1.3463466058189166,-37.37557573288187,46.693529443174555 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark14(-29.77243529090297,-0.015804460266505758,-60.323558679970816,-0.46878989107762736 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark14(-29.95105124449931,-0.14737272853532035,-73.62760245581546,-0.9543294630516493 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark14(-30.026302943869965,-1.5707963267948957,-88.33511707223136,-1.0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark14(-3.0046239516072717,-1.4936980745126505,-1.5707963267948983,4.4896687407852625 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark14(-3.005305817477692,-0.7891507478919182,-53.92601386187532,-0.9092436797911256 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark14(-30.10062913641278,-1.5525915799203442,-100.0,86.99889052864015 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark14(-3.0139508532011803,-0.9788907255002052,-77.32292703603163,5.449903777647183 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark14(-30.147952814597303,-1.36156335145251,-158.47235290611846,35.58870214744973 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark14(-30.157770314574556,-1.0963989719926865,-20.300874803353608,1.0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark14(-30.23736380417683,-0.22972608679445672,-88.27545939477442,-1.0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark14(-3.024468693389167,-0.9170158594620723,-2401.4002240861237,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark14(-30.27557091798137,-0.24756781726951615,-0.8058883561253667,31.293818546419658 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark14(-30.278204126452366,-1.5707963267948912,-7.9889543217724786,-15.005389554050836 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark14(-30.305618242788,-0.6953587958313909,0.0,-66.03950016755581 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark14(-30.351613490682713,-0.80815893716259,-65.45502219566384,0.4360673834996902 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark14(-3.0453639036494637,-0.7054591162635083,-0.6449764251415364,-29.247977396830144 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark14(-3.051469857445633,-1.1294436940384385,-0.733632400682261,100.0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark14(-3.0654469624780063,-1.4642063524423665,-1.5707963267948593,93.72397099836957 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark14(-30.676461201465408,-1.8253031302864636E-16,-8.264095007824217,0.0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark14(-30.680884739357154,-3.0833022264583005E-4,-44.17586704218634,0.008576589862398093 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark14(-30.735535777405406,-1.5707963267948961,-3.248659883566104,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark14(-30.77063725619688,-1.5707963267948912,-47.46330927842424,1.0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark14(-30.986313753462596,-1.5707963267948948,-63.25591357272086,-1.0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark14(-31.036067947850327,-0.017694608355202535,-100.61514714202873,65.31278184379843 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark14(-3.105155931147479,-0.057111257213616706,-39.37251478468218,-89.39692539830975 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark14(-31.118167643674713,-0.389201889774657,-58.50680445007219,1.069155171840498 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark14(-31.13080990703619,-0.11255125169027558,-65.96754425031321,0.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark14(-31.401254367172157,-0.2617709136129063,-32.50168277856539,-0.19197220951168303 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark14(-31.41970348990306,-1.3069657536474504,-91.60254614528183,-1.0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark14(-31.423310211502464,-1.4474220927022543,-45.00245903514245,28.819227851327213 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark14(-31.42839919943296,-0.4178103018701904,-130.0213264828031,-0.5555869202143953 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark14(-31.428449291482472,-1.390264162127767,-73.06573972620005,-1.0000000002256495 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark14(-31.542748820701476,-1.5707963267948912,-72.42581650703761,-0.15308974034869738 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark14(-31.592300099138676,-1.4262564963387212,0.0,-39.27818309047555 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark14(-31.601070461828755,-1.3684008847828437,-1.2463896189913912,8.881784197001252E-16 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark14(-31.689184434721273,-0.6456376498484673,-1.5707963267948963,-0.9747189020767699 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark14(-31.691733475738857,-0.40099848544588823,-63.39521093436775,1.0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark14(-31.827997780728168,-0.6985587725221566,-1.5707963267948983,0.9169449162217307 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark14(-31.837585045909986,-1.4930913047425138,-116.03018584933346,0.9968002343233328 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark14(-31.852206529160057,-1.5707963267948961,-2.1620875665040455,-1.0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark14(-32.0563538983713,-1.5707963267948948,-12.359178113317533,2361.7268557836724 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark14(-32.12765877442011,-0.020624224696761607,-43.08266288539849,100.0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark14(-3.2189529398900305,-1.2379681593079466,-138.22410475580867,-59.19400818168744 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark14(-32.292644212146335,-1.003244987848293,-48.82470644762449,0.03501191751891977 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark14(-3.230518948782742,-1.2023668396244749,-40.56274758448881,33.88481725713049 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark14(-32.365011965532005,-0.21553173346664972,-55.02698718268586,5.852095443365248E-98 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark14(-32.42013570226937,-1.506840763093947,-0.12539587749622094,-1.0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark14(-32.5410101181765,-0.25678573352868894,-0.2682509550865926,-1.0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark14(-32.7013034327494,-1.5707963267948948,-94.3120559445047,46.343323313796134 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark14(-32.776291735841156,-0.1302290679457711,-38.93104905724507,-18.155592794402537 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark14(-32.93276368621405,-0.9197305057616205,-24.61495443612702,-0.16960605357734393 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark14(-33.12637807391798,-0.29249676713312733,-1.5707963267948966,-2.0590230357872116E-84 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark14(-33.12920982955545,-0.19620977668472983,-37.988251047663816,0.14113816563930148 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark14(-33.15348883396261,-1.5707963267948961,-71.16340882256576,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark14(-33.21046553727176,-1.016570218118777,-99.0031675997757,98.56873979793781 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark14(-33.258361592382485,-1.453340588465165,-6.649810136434047,-0.04354948201471026 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark14(-33.29750038970438,-1.5707963267948961,-83.40656598633802,0.4027074451839081 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark14(-33.315289559534705,-1.5707963267948912,-28.023750751254667,53.332306265371784 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark14(-33.45388110060463,-0.8327459674282078,-37.85784952208624,0.0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark14(-33.52601528741343,-0.3475027378543991,-45.15830853224969,0.0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark14(-33.563859726175785,-0.9536973879044004,-37.724694576937345,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark14(-33.58827618593145,-0.22609980773284333,0.0,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark14(-33.62287828722721,-0.2841297473785733,-0.6805966644077337,-0.3632406081566444 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark14(-33.62741928614011,-0.2200480445675641,-66.14616331639307,0.6481310299118515 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark14(-33.64029100073388,-0.010597864750017949,-31.888000293950775,-0.010552217257805196 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark14(-33.7086552449038,-1.5707963267948912,-1.5707963267948966,0.23927838900314535 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark14(-33.7470455489032,-0.6420599156081721,-10.51126142832859,1.0145736950717092 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark14(-33.75007118189226,-0.25498584122219725,0.0,-0.061424707843634796 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark14(-3.386428250884137,-1.5706997027849334,-1.5707963267948966,-0.9982203832055307 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark14(-33.889197508184196,-1.5707963267948735,-56.300523718000846,-0.2773842328408438 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark14(-33.92014871382205,-2.220446049250313E-16,-90.74194646843296,-73.23201676413781 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark14(-34.02124454552492,-1.5407708498976453,-73.72320656387501,0.4835261847082416 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark14(-3.4035986361833324,-1.5707963267948912,-31.63667750943521,-29.99056263319678 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark14(-34.23463521235544,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark14(-34.36040933483673,-0.15509926251910144,-95.76839523172947,-132.9856632132886 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark14(-3.4378046814228664,-1.2997202473483702E-15,-1.5707963267948966,0.01174890246845706 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark14(-34.38569276079801,-0.44669018512417547,-4.440892098500626E-16,26.83775961834141 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark14(-34.396160425793425,-0.9033209182106307,-1.2267547627003548,49.855190195704715 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark14(-34.42847326512066,-1.4067041282653314,-14.321122486525425,-0.91350469486337 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark14(-34.449990861117215,-0.011455340291468552,-100.0,96.71977759241545 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark14(-34.48039557375229,-0.3271812373416997,-35.99029719375477,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark14(-34.529728301359526,-1.5707963267948912,-88.96411598362994,2336.422378704674 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark14(-34.57536433749052,-1.536828246170416,-100.0,-88.99852118256143 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark14(-3.458151934819801,-0.01358826842391842,-4.669414917741648,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark14(-34.688794365353395,-0.29064621836924154,-17.496420746265347,-1.1619536772479293 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark14(-34.70507772178864,-0.8184819928345803,-7.2876575939046795,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark14(-34.88572444447067,-0.2512953414407577,-24.341103762146858,0.2679965237597625 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark14(-3.4929378933894415,-1.4097742169289529,0.0,-78.33449127309582 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark14(-35.00463147823713,-1.5707963267948961,-15.036771625465818,-1.0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark14(-35.02162969298416,-1.2094218354801618,-122.77114937297725,1.0000000000000018 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark14(-35.084114574880594,-2.220446049250313E-16,-0.8102506969782028,1.0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark14(-35.095799665202556,-0.03314638701488071,-18.996208582263428,-0.03067585515687853 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark14(-35.21369911986818,-1.5707963267948841,-31.736944342004335,1.000002205352428 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark14(-35.27158755599977,-1.232347446279361,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark14(-35.282957691437346,-0.6301386253321742,-4.528944962848519,1.0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark14(-35.393468620048495,-1.3005205754891058,-59.14719616863738,8.098133117938346 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark14(-35.40643043053639,-1.5707963267948948,-9.476451563788398,0.0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark14(-35.4385759186184,-0.4308821292828027,-38.93412244097258,-1.0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark14(-35.482241339216,-0.7656626329627854,-8.530709945388805,-0.06257910849483303 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark14(-3.5648857649422325,-1.4241788216105449,0.0,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark14(-35.668754002536076,-0.7632784627660187,-34.288661544968356,-0.5600039669296724 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark14(-35.68933465286812,-0.12401901254035863,-94.30729820609929,1.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark14(-35.730931134536334,-0.613108797700103,-38.8303875305597,1.0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark14(-35.76027145710849,-0.2666564074781022,-1.3811675884309758,-1.0000000498777455 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark14(-35.822641550788845,-1.5651585045675502,-1.5707963267948966,0.6440461601803129 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark14(-35.84093310267602,-0.19864043969785047,-17.98221525054094,0.620236109150578 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark14(-35.90328197977021,-1.5226546786233666,-1.5707963267948966,0.9999999999999996 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark14(-35.941527716617784,-1.4075510862334992,-1.9150175590356042,-43.59331031210736 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark14(-35.96792014937193,-0.5788071187878008,-6.756567356100049,-0.7381822422638178 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark14(-36.04694696622726,-1.5707963267948912,-53.73275161853856,-1.0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark14(-36.091093959618,-0.891487088558742,-1.3641535293737854,-1.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark14(-36.11471245661215,-1.5707963267947918,-123.86570691689815,0.1818035802274487 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark14(-36.172998877650166,-0.11878715708758376,-64.2242835374093,50.62182477121394 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark14(-36.18304796530849,-0.3580570793839898,0,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark14(-36.23294399657882,-1.0266673567688744,-9.781538526074133,-0.5344784533392514 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark14(-36.260204072803894,-1.1672202816205735,-49.57931393566733,-0.06312131877078442 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark14(-36.26589679761098,-0.03334992971967353,-73.40774724933625,5.421010862427522E-20 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark14(-36.35316277125402,-0.9711367101065701,-9.194936370135395,-0.032725336810054184 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark14(-3.6387784753290977,-0.13426298044260584,-1.5707963267948966,7.31511930420656E-99 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark14(-36.45930011311557,-1.0860543677331205,-19.0029263139965,-1.0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark14(-36.52960528225801,-1.0437007999154866,-100.0,1.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark14(-36.61754691630449,-0.9065343584549573,-34.36768408233161,0.054112505208751036 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark14(-3.6707883286863936,-1.5707963267948923,-3.765535606124736E-15,-0.9999999999999951 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark14(-36.70963885171036,-1.5694275893014291,0.0,-2208.8284080982903 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark14(-36.711017589349346,-1.2667549094658812,-74.45564597284037,0.9999999999999982 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark14(-36.90866646538115,-0.007635634721084722,0.0,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark14(-36.90927469161905,-0.20850949995566084,-4.664142737113429,1.0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark14(-3.705336629320925,-0.30879239225242733,-17.079429417793783,-1.0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark14(-37.098638249625864,6.871263212421849,-0.540634248799379,100.0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark14(-3.719066536561567,-0.9098130205088704,-36.17471283643386,0.9999999999999982 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark14(-37.195896654271046,-0.6422496469900221,-1.338494403642997,-0.5671255416432791 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark14(-37.22109150383578,-1.3875844930709362,-19.369139308759152,1.0704430486879013 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark14(-37.24827773946334,-1.2847176477127855,-62.59781608576986,-1.0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark14(-37.48297771457689,-1.286952557557406,0,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark14(-37.55586531291111,-1.11003318813556,-85.52191167758801,-1.0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark14(-37.58344084346295,-1.3110247334107576,-9.506467453777432,36.93865436293484 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark14(-37.68786346916675,-3.552713678800501E-15,-54.116910086700564,-49.65010883874002 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark14(-37.70734533795761,-1.1358313407646392,-44.92295835957116,-1.0000000000000024 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark14(-37.733558431206845,-1.5284769764891453,-6.454887561772036,-1.0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark14(-37.80328069306011,-1.1007274299088952,-0.5519920639821396,0.04164169960067157 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark14(37.84537850321479,86.15995580920807,43.37749816535944,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark14(-37.93186642950336,-1.5707963267948954,-61.52595322776867,-0.44611075241336495 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark14(-37.991010838921554,-0.5881259589781536,-72.96981118016586,-1.0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark14(-38.03356933348986,14.43187599074593,0.0,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark14(-38.148332054494226,-0.9670274707795299,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark14(-38.19254937446405,-0.3980706999166778,-100.0,-34.83621975005638 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark14(-38.20960265761451,-0.6130316190939247,-38.732431571203385,1.0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark14(-38.22747118938088,-1.5707963267948948,-40.44164822486995,0.9999999999999982 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark14(-3.824101521229835,-1.5707963267948895,-17.525712959574975,-90.83611701100007 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark14(-38.330232854597924,-0.40934338467743275,-62.110662868406905,-0.9999999999999929 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark14(-38.346577343896485,-0.45337305013745777,-43.96188608904574,7.487736820081437 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark14(-38.37776150179245,-0.16447511103795875,-12.297862793175739,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark14(-38.38621855896565,-1.0650493716698597,-83.46519530610065,-33.66850994296973 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark14(-38.56373956649774,-0.6283015104064594,-95.48464815151718,-1.0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark14(-38.57023872347107,-1.5707963267948948,-8.247922016864905,0.6486832514063057 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark14(-38.57996172487104,-1.4815801111862001,-0.17705147725129358,0.0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark14(-38.63037591505901,-1.0861512018372679,-0.9105743584459948,-17.025131552525526 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark14(-38.63749218971574,-1.5196299842703036,-57.058574901819924,0.9999999999999993 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark14(-3.8639821476441356,-1.5707963267948841,-99.3581384727746,1.0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark14(-38.850967592636025,-1.5707919890357769,0.0,-0.04795408897029904 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark14(-38.92745774081963,-1.5707963267948912,-77.22803525443453,21.060014689028435 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark14(-39.01337388986884,-1.7763568394002505E-15,-18.743728960511035,21.94701253707126 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark14(-39.037444181247125,-0.20671243311811535,-62.32848634074388,0.675396428043961 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark14(-39.08732176313975,-1.5707963267948952,-68.49346515446709,-1.0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark14(-39.27494379339335,-1.5707963267948948,0.0,1.0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark14(-39.31140474883178,-1.0029161346497517,-28.1557623510368,0.0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark14(-39.48367312713085,-0.7089775624456198,-65.08882896189274,-1.0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark14(-39.49661793775982,-7.105427357601002E-15,-61.291019720115855,90.04558466202178 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark14(-39.52154834410211,-0.9114760369879693,-76.08164408874117,-93.14478110622701 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark14(-3.9605923303099377,-0.6059720561913208,-66.69658185419352,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark14(-39.63899700767433,-1.5707963267948946,-1.5707963267948966,0.9999999999999999 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark14(-3.9727019415657026,-0.06890788622815633,0.0,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark14(-39.733719732796466,-0.25574206441371783,-75.90624708385235,1.0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark14(-39.755572672914376,-1.5707963267948948,-33.0023932142868,-1.0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark14(-40.04211336263525,-0.448883150373664,-1.5707963267948983,-65.99853283981936 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark14(-4.00612696975079,-0.5873433540759772,-86.37909911276576,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark14(40.10364812997278,21.47198560709849,-13.863783504288634,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark14(-40.111292836033506,-0.591292697350646,0.0,51.43148272076951 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark14(-40.220794923108585,-1.5511513846208493,-77.13158544516956,0.4371913658896742 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark14(-40.32051757529811,-0.9245769081923307,-94.4997890426986,-1.0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark14(-40.384067582424926,-0.9370265159294598,-60.89500146645129,-40.83889225860663 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark14(-4.041547870522814,-0.3744831152056849,-67.0001317261174,0.33910647531172344 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark14(-40.523185769253026,-1.3657119239331692,-70.17070767144365,-1.0000074737315052 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark14(-40.532579960140225,-0.15650450000570348,-1.1102230246251565E-16,94.67742825445144 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark14(-40.59837215881365,-1.5624390573794846,-4.2197635180503,0.6775923884240622 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark14(-40.62074845990229,14.447405042830013,0.01671284615430852,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark14(-40.64348843554801,-0.6169333315604608,-95.89318670598375,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark14(-4.067563899463641,-1.4514028114865996,0.0,-0.6366333292148779 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark14(-40.692198654946374,-0.6766140060236867,-44.92845942876205,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark14(-40.76095058229521,-0.6789556091880943,-24.489864038855387,0.36382872989304477 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark14(-40.82527100761948,-0.1604863789374184,-78.59224017935526,-76.28111637555534 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark14(-40.881690775903294,-0.8993928191690923,-1.5707963267948983,-0.4495898147292542 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark14(-40.9140166897046,-0.8926208702129745,-20.449965062899903,0.6187883183417036 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark14(-40.91499240082392,-1.4391086064210654,-10.74426447428199,-0.8484505223178171 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark14(-41.06615402598611,-1.1342449610558525,-63.29140264601125,-35.03720131196155 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark14(-41.25657739267341,-0.8181012751338733,-0.9233815972484432,31.14743726593388 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark14(-41.29649856159368,-0.14903119516132507,-72.47319778485583,0.9792841531839727 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark14(-41.30294918771596,-0.06262732783044667,-14.95423204585913,-1.0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark14(-41.324199095857026,-1.5707963267948961,-32.80597511665283,-23.920300482207765 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark14(-41.34454550953311,-1.3070152573352501E-15,-59.816213774099225,-79.9702382216623 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark14(-41.40453311232342,-1.5707963267948912,-95.75690288274942,1.0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark14(-4.144246320219439,-0.9078676931040971,-34.39783942124468,-1.0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark14(-41.63683856453262,-2.508921803784848E-4,-78.67205000179595,0.9975405614218684 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark14(-41.80838168144357,-0.6413548174874518,-10.964157361849459,-2155.1913817650066 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark14(-41.9049425617786,-0.6895574512315119,0.0,-1.0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark14(-42.06566249496946,-0.3603214707952952,-54.6965964971172,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark14(-42.09926111953777,-0.8351349972664268,-28.20568945910888,-1.0000011270955296 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark14(-42.12413615265214,-0.467032888211959,-64.10301221079597,0.2026104517281162 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark14(-42.216022759453615,-0.8620693490300544,0.0,0.1383752519924243 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark14(-42.24790041465835,-1.570796326794803,-1.5707963267948966,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark14(-42.31847697369488,-0.682377257760139,-49.515943374940015,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark14(-42.32391469580869,-0.6808010987473381,-127.82376159108308,-0.0029074070935165633 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark14(-42.3702050728122,-1.5707963267948912,-15.083794553322942,-0.999999999999856 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark14(-42.48022127814106,-0.03296106126509453,-80.16053195539429,-52.72983947532491 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark14(-42.48929016439871,-0.0661901999997968,-29.56976905990041,-1.0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark14(-42.64355973340598,-0.13840140895728464,-94.30576247213956,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark14(-42.66644706934426,-0.06065127141304307,-1.5707963267948966,4.840313634992514 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark14(-42.671351087355916,-0.8612274985643429,-1.5707963267948966,0.8425928662872124 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark14(-42.77115843900097,98.21976023023703,-28.273330621913345,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark14(-42.80137358294312,-1.4992690995108144,-1.2525721588954033,-29.10410455086982 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark14(-42.81898525188,-0.740623583382239,-92.13408383211905,1.0000000427582951 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark14(-42.87617392119277,-1.196204906461698,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark14(-42.93293318176055,-0.6689354244624326,-67.09134140863198,-1.0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark14(-43.00868490534243,-0.3014168092478853,-67.78976980498753,58.25819059978336 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark14(-43.029299793201126,-0.05514167188811536,0.0,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark14(-43.065137696886225,-0.589557006354293,-1.564832040125418,0.8722096595740823 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark14(-43.204519449172075,-0.7787256823467175,-74.97876970788745,-14.175049390374568 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark14(-43.35144179099506,-1.5707963267948934,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark14(-43.52216470085368,-1.4174898859122407,-10.918795878365255,48.92203911050282 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark14(-43.53072524531407,-0.7094677545953663,-45.170667966514905,90.40932540662202 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark14(-43.53383769359523,-1.543857449841671,-1.5707963267948966,0.9859039456804415 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark14(-43.55290088438258,-0.6625808320193168,-25.967565862147648,63.727730382034636 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark14(-43.68424466810019,-8.881784197001252E-16,-25.436081897205938,7.105427357601002E-15 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark14(-4.389738433025718,-0.8263809284337128,-42.76480675316526,-0.2224772411925128 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark14(-43.9521327205901,-0.4815696210387126,-70.0050447968431,1.0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark14(-43.959279994485456,-0.793976210828794,-9.920979435005995,-7.594487740989678 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark14(-43.96096395156617,-1.06277459592034,-33.68996693188927,-0.3520027446192895 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark14(-43.962654577359885,-0.5654704931333994,-75.89388935443077,-1.0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark14(-4.39782242867298,-1.5422013093183011,-70.83207583475615,0.6995497786742143 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark14(-44.011831126377835,-0.007693962456387796,-0.0701033175030189,0.050646295451587844 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark14(-44.13599249840899,-1.5707963267948963,-9.262386683385767,45.825555318894125 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark14(-44.19178042103481,-0.2377438526629083,0.0,-1.0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark14(-44.21262648415107,-1.1007588442630765,-56.38328185645295,0.0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark14(-44.27037077657536,-1.5599059112141878,-10.858800779840141,0.7773916802831058 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark14(-44.272876273733,-6.191080861143994E-4,-0.3858318845354628,0.0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark14(-44.28156512875957,-1.4947106402937465,-45.4790699292185,-0.7743353985630237 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark14(-44.3024618351111,-0.16226599128935604,-34.48821378680053,50.47828895221914 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark14(-44.33810939993248,-0.11846252571283206,-33.359573446419574,-0.9864302396072127 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark14(-44.365222502766414,-0.21214265968632162,-46.20952241922751,-0.9003646261878213 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark14(-44.39390545418362,-0.002811498896685374,-85.29650179075577,0.9722854467439079 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark14(-44.41682247804444,-0.4434613126366309,4.332448522990973,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark14(-44.44246653224637,-1.1208512040523493,-96.73916383169035,1.0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark14(-44.45396210865892,-1.570796326794893,-8.389671036759367,-91.25582359510165 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark14(-44.49799602537085,-0.016120722139447374,0.0,60.13315305353811 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark14(-44.57924687535419,-1.059142170190183E-15,-0.9433460048613612,-0.768658174993921 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark14(-44.592525820707905,-0.6756861872654735,-33.18569528293268,2080.9324346178482 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark14(-44.67575359053139,-1.5707963267948912,-163.7640091088287,-2217.3180626938847 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark14(-44.67967231176209,-0.0015512607827901093,0.0,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark14(-44.75998404876698,-1.5707963267948948,-1.5707963267949019,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark14(-44.7724148875187,-1.5707963267948963,-70.67344293883528,-0.36296953751039207 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark14(-44.95695212585744,-0.44849363969267697,-12.667974099069031,-0.018813855165954557 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark14(-45.03773964627894,-1.5707963267948912,-52.27986107083076,-16.661455011304056 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark14(-45.041270354687526,-0.8930833942299515,-90.1412677896408,-0.05298151602720225 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark14(-45.088855020726704,-9.885199214779397E-15,-1.5707963267948966,-53.67693974356403 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark14(-45.09011703216223,-0.18045497203160465,-39.60444304555309,0.6933066980549221 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark14(-45.10817441654742,-1.4748265211728133,-26.863001511773035,-33.20628044997187 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark14(-45.10957674828883,-1.493980308475718,-122.71051505716615,1.2012894578336888E-4 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark14(-45.1635832608619,-0.6148321742622187,-23.366065216782033,1.463023860841312E-98 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark14(-45.27239019859984,-1.7763568394002505E-15,-44.76005810649874,5.551115123125783E-17 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark14(-45.273973659324064,-1.5707963267948952,0.0,-1.0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark14(-45.34142504787822,-0.3404174721707977,-33.443958922689916,-1.0252136055131464 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark14(-45.35732688222756,-1.2391138433591555,0.0,-0.06256995031539604 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark14(-4.539857146877424,-1.5019005808325803,-68.57269253765243,-1.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark14(-45.40094189151706,-1.5707963267948948,-54.8999975522324,0.9308208774888378 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark14(-4.5439072731147405,-1.5707963267948912,-72.84210394315704,-19.82682294642811 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark14(-45.44853952529123,-1.5413639189598431,0.0,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark14(-4.545379480360367,-1.2662425657704974,-0.041448103145649354,0.9999999999999999 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark14(-45.459350217402246,-1.2874271795733385,-84.75867091581925,26.537294375908086 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark14(-45.51608553548928,-8.881784197001252E-16,-59.13756008077385,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark14(-45.523685188044276,-0.694417833781813,-71.34078112293767,0.2201115991209841 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark14(-45.59908690273993,-0.331929213132753,-37.93756102041288,-0.9637106416666308 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark14(-45.66699410691545,-1.5707963267948912,-0.8240032023059882,1.0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark14(-45.695928744914625,-1.0231653392768987,-1.5707963267948983,-91.72227956441782 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark14(-45.71119864796685,-0.5428423364301245,0.0,-1.0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark14(-45.731890522891064,-0.13149244387222447,-48.992922634471284,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark14(-45.80339854818668,-1.7763568394002505E-15,-17.10699839266935,0.740111085788481 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark14(-45.884610456271844,-1.5707963267948948,-49.66662876401231,-1.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark14(-4.600338563408395,-0.06602362970792192,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark14(-4.621164859162192,-0.1468785333455831,-99.42499585250455,-1.0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark14(-46.31155900112225,-1.4130992493618548,-0.7745974349624636,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark14(-46.47306164821109,-0.9846133989588066,-32.49032871333774,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark14(-46.49804223400641,-0.05374350865020819,-38.870860817020144,-47.182684369617164 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark14(-46.526070096867684,-0.6775055376008456,-4.63246343749843,-78.10812559369606 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark14(-46.5934767530962,-4.440892098500626E-16,-55.89450172460981,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark14(-4.674410897839598,-0.5307057052393027,-1.5707963267948966,0.9999999999999982 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark14(-46.79011014244345,-1.313742450090666,-100.0,0.0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark14(-46.84938791942818,-0.16791500889724315,-61.41708704188646,0.4547222915987029 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark14(-4.689242209137134,-0.018462793669395152,-0.11686812166238641,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark14(-46.96216053396339,-1.3703144463324382,0.0,-0.19398705633192642 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark14(-47.03569139121566,-0.03667568669470889,-22.484345033403372,17.287384474000163 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark14(-47.119066187066274,-1.4004286480902852,-123.57448005077123,-0.6310750266241782 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark14(-47.165995003394144,-0.5743284397310617,-6.059962829073882,80.37990819525444 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark14(-47.1941614686856,-0.7443356668766512,-146.4217839889222,1.3026460300594778 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark14(-47.2047843714751,-1.4926983962230027,-44.8787746262208,-1.0747329423606675E-4 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark14(-4.722263595853881,-0.7536983566265132,-1.5707963267948983,42.76518714273711 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark14(-47.22679345671702,-0.9313944441520192,0.0,-1.0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark14(-47.2285447433558,-0.16166465720531553,-1.5707963267948966,-61.29175641650809 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark14(-47.29555729883441,40.594402381959384,-26.785996629369265,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark14(-47.29672609228086,-1.3584030427073808,-95.44128285285986,0.042112826233739103 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark14(-47.41217440085387,-0.3454766933715927,-51.93333978617565,-1.0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark14(-47.45195374331986,-1.1353805938532022,-1.380266629553227,-1.0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark14(-47.49292305319068,-0.9055116526681459,-17.35523554839297,-41.335726566452124 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark14(-47.51754639011431,-0.9829571338908889,-31.89395927874053,1.0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark14(-47.530103299266436,-1.4517808347947294,-94.56520992047274,0.03325842348251067 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark14(-47.62234449710478,-0.6748292787821812,0.0,-1.0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark14(-47.7462037882512,-1.0693995616972147,-88.36552175387429,-57.32471821377649 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark14(-47.830783404941606,-0.016431208166693523,-17.530665609565006,1.0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark14(-47.85181651244731,-0.20425047917506944,-44.08789759002471,-90.2809596662717 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark14(-4.790901711195932,-0.23828922183254628,-0.6879057913177569,0.06258277897508693 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark14(-47.922873136804874,-1.4617238877321004,-64.28106637656029,0.005771986167322454 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark14(-48.03538063344649,-2.220446049250313E-16,-12.885316426741124,0.0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark14(-4.806276634897003,-0.37180200340633773,100.0,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark14(-48.075569044603775,-0.9315698360249725,-21.856998756930103,-17.05999185367493 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark14(-48.09037382184456,-0.8324386786982776,-34.855722726883485,-42.07182034108954 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark14(-48.25672991246191,-0.21857186584391136,-61.91644481630677,0.012363866302023435 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark14(-48.26631189366572,-0.7512567863856364,-95.54724044308418,1.0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark14(-4.831775961047779,-0.12315050532054085,-0.1347384769999461,100.0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark14(-48.32101936485258,-1.5707963267948948,-58.13537426696158,0.05806457196163495 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark14(-48.40461155648609,-0.20054293511591587,-77.56998382910143,-1.0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark14(-48.40754896588262,-0.8523235813684864,-31.78144711839421,0.32301809890020916 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark14(-4.842300747822549,-1.2193085643648802,-100.0,-57.584343476187925 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark14(-48.48404379914064,-1.1267567202694388,-69.01836643769542,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark14(-48.59398362775667,-1.2301397962570029,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark14(-4.8632009420031626,-0.6873231272226668,7.342091693247949,554.9010629886358 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark14(-48.773485005058646,-1.2304360615353769,-54.848068194579994,1.0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark14(-48.852969505871656,-0.162374517804823,-73.73548726999479,1.0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark14(49.065836154998834,-0.9860995774461943,0,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark14(-49.36699638165496,-1.548782636971255,-46.207447389557,74.42258960543504 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark14(-49.44939701450839,-0.856481928422426,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark14(-49.4684558867366,-1.224205613344319,-140.82631966039708,0.0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark14(-49.49790639654222,-1.0554874181139926,-100.0,0.13175245871175523 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark14(-49.53797634134843,-1.570796326794893,-16.81177994126191,-37.423903114400574 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark14(-49.60664435633055,-0.09208467752961973,-30.658458270174116,12.775042012527686 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark14(-49.65716933761397,-1.5707963267915659,0.0,-1.0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark14(-49.69700555188437,-0.19785973428211673,-43.59753099348747,-0.012976744207238489 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark14(-49.70906296715276,-0.9052976029626427,-11.013063450910641,-1.0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark14(-49.718550409116865,-0.014828156098945331,-33.81888994036259,-0.018589864629663833 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark14(-49.94429778147516,-1.160629961193561,-35.15238511479237,-0.2893675560732909 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark14(-50.04197931592078,-0.03660458711422614,-62.067373493538405,-8.198454428460096 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark14(-5.005545872580484,-1.5707963267948912,-13.009010278544352,-3.276136162794117 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark14(-50.05632111763618,-0.7455347834311146,-1.5114066437984968,14.834971387358536 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark14(-50.146524684667085,-1.5117014591523605,-28.30947879587498,-1.0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark14(-5.0236516916360054,-0.020557299528027918,-62.5932792152537,-0.3683033343234241 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark14(-50.2501878247516,-0.7216750053792321,-39.95235748611906,1.0000005661768427 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark14(-50.27366815881094,-0.25805970245408516,-0.41415250904585027,-0.003863344337957201 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark14(-50.27817071111298,-0.12141344272184162,-37.95836215865002,-5.0460832858599645 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark14(-50.30408620539998,-0.4980461473476767,-16.838032586815043,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark14(-50.31177626905851,-1.0618045096202633,-72.73642993393152,95.81176112603197 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark14(-50.414804441295246,-1.0568441622358078,0.0,-9.783581112754739 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark14(-50.499113926679925,-0.9486274629648199,-102.08631905257398,-0.9208044225092615 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark14(-50.506535721975894,-0.35639931170866196,-0.5320316804679459,-0.011982718147141636 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark14(-50.612430796707365,-0.11115516424600215,-57.879442070656786,0.1589639504913407 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark14(-50.884211633402366,-0.3510355765956703,-29.867608054021666,23.939870617310845 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark14(-50.93643284346698,-1.2744260191355368,-1.5707963267948966,-59.30332686143111 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark14(-51.15351446444579,-0.061827740357552154,-1.4456664929994631,-0.7098208796269643 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark14(-51.389880508259495,2.573809813767516,0.0,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark14(-5.145434762470392,-1.1237325209550049,-32.502520489029735,1.9460376505928179 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark14(-51.615905783844774,-0.6338185819510147,-4.627695405537423,0.05883593182330521 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark14(-5.1637599568069685,-0.5159115470955983,2.713594045734584,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark14(-51.6387005037963,-0.06483555261203629,-49.32605335961302,-0.8519734527389193 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark14(-51.66347790548482,-0.008321260367213075,-22.701834477119476,-1.0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark14(-51.7465477175077,-1.5707963267948948,-88.43810620416714,-1.0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark14(-51.77646669580833,-0.017132086226972376,-2.888546723603751,1.0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark14(-51.814384979116866,-0.4488776086835962,-38.674791181363204,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark14(-51.890512292902514,-1.3942210790759426,-64.40589438917151,0.7533488010430256 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark14(-5.191242123941855,-0.6658386921052468,-1.5707963267948983,-58.887384615724244 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark14(-51.93713930712591,-1.1566902295069488,-163.40568739883338,0.8459040129052715 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark14(-51.938596778555294,-0.0027686921339493686,-43.441695259336555,-0.029220927790514495 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark14(-52.00317895952402,-0.5772690421184081,-1.5707963267948966,-8.96769821196159 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark14(-5.2100234845647435,-0.8356440484332393,-53.89106725369982,0.05075512875877898 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark14(-52.19452612421156,-0.479024352036778,-77.50772920135367,-0.9999960519988379 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark14(-5.22347104355342,-0.016167836726501184,-1.5707963267948966,-0.7311847381282467 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark14(-52.36361988296825,-0.5175673221191079,0,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark14(-52.400657553286486,-1.5705673124198776,-82.63006726726033,0.8842065305046959 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark14(-52.44219382667745,-0.0021875027544219217,0.0,-60.858514223035414 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark14(-52.44268246628915,-0.5114115747189303,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark14(-52.46461022089899,-0.13796166952372474,-27.211353066522527,0.9999999999999982 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark14(-52.495254366886364,-0.34209749676560125,0.0,0.45620707134450056 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark14(-5.249751205088591,-0.05960370418138611,-0.542300544376929,1.0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark14(-52.49805560152252,-0.19153191539888687,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark14(-52.50940583379371,-0.35694763804237645,-23.699193477456767,1.0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark14(-52.51779281777875,-0.16847589855467077,-84.3769779322149,-1.0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark14(-52.58085862929671,-0.49116128725768,-14.626859605290022,57.406232400911165 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark14(-52.806515357319306,-0.6511067455561914,-2.1478275314549222,68.6562704696994 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark14(-52.98870449776378,-0.12109673033911884,1.1102230246251565E-16,-0.06867216621700845 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark14(-53.004859364351766,-0.959534952765238,-1.5707963267948966,0.0625580032279826 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark14(-53.07227672868775,-0.9671565288730338,0.0,-0.8776257129834272 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark14(-53.07292690472262,-1.5580685392489202,-23.455513901821284,-1.0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark14(-53.08305447559872,-0.6013280081061796,-74.7270835925325,-1891.0892603259576 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark14(-53.21394217101749,-0.002101698138875994,-45.17263549465722,-0.6993789035434306 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark14(-53.2358513087146,-1.0119449851142635,-105.3348007743599,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark14(-5.3265047716437675,-0.03616860458150444,-19.36787874142019,0.013337057524325083 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark14(-5.326895661595014,-1.5636962367935388,-31.95177378255717,1.778206999588062E-161 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark14(-53.27127409365465,-1.5151968846425021,-15.104049708962833,11.241142743313357 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark14(-53.36529095201696,-1.5707963267948963,-44.14510563750072,-0.03360177562446853 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark14(-53.40839888746596,-1.5707963267948912,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark14(-53.43796381392728,-0.20651493754770156,-93.15894497450354,1.0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark14(-53.4454662129108,-0.5182658002528298,-30.629096502044227,48.66048873515026 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark14(-53.46170912439003,-1.5707963267948912,-45.14659959541476,-74.5110673991215 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark14(-53.625822026573786,-0.42443293174013236,-44.13395043584991,24.618903564292168 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark14(-53.6275915341335,-0.9308333894891649,-23.66638732243996,1965.2538771482634 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark14(-5.367956734217722,-1.0368690159552796,-0.10409716786535872,0.5595120594993703 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark14(-53.73479524692706,-0.39665573311371,-17.57494031401588,49.067676659171156 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark14(-53.78612850740074,-1.4808893215081802,6.5194272130956366,-27.55666375093164 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark14(-5.379938713456813,-0.9434412134851267,-7.49121024616062,-1.0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark14(-53.869429990112536,-0.39182965830263305,-1.1187276602373377,1.0000000130618394 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark14(-53.8748908772694,-0.5822249286325892,-1.0374173411643899,-89.07514406715886 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark14(-53.92954446216597,-1.520687014753688,-42.82990569439934,-1.0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark14(-53.99430713516692,-0.4349053948518807,-88.15654486997411,0.4907692541293701 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark14(-5.40777612232781,-1.5707963267948908,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark14(-54.08241312860209,-1.5707963267948948,-16.89229555265248,-25.74882661156923 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark14(-5.416529215927568,-1.4796439912519759,-4.6308548636609785,86.99961680710592 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark14(-54.21771739367423,-0.3497749157421404,-90.71934209614017,-58.643404090158526 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark14(-54.21794440879584,-0.4601508826172087,-1.2330217398757277,0.510655948408471 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark14(-54.248579787276235,-1.5707963267948948,-66.43241560063755,0.7306162628227497 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark14(-54.27429708275062,-1.5707963267948948,-36.92437744197733,7.751348475253074 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark14(-54.342870036211835,-1.2029773033619713,-37.994733702242264,-0.2153296706911857 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark14(-54.388460996481015,-0.013056136436966329,-21.20644361689215,0.8566669683993303 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark14(-54.38854513862399,-1.5707963267948961,-4.027232872642443,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark14(-54.478670904158825,-0.12239932135411036,-68.81463308050634,27.403754145239773 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark14(-54.62412475950906,-0.7510603460247701,-32.425920587377846,1.0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark14(-54.66863777889937,-4.620543181893902E-5,-10.796919875237258,-1.0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark14(-54.738660036963935,-1.5707963267948961,-1.5707963267948963,78.5609185469796 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark14(-54.93447242016296,-0.1707663849993608,-27.279062092210978,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark14(-55.12237077643793,-0.25106851887374965,-82.3000223399222,-0.4699176420501041 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark14(-55.1381898045848,-0.014916156879208605,-2.5878326560585614,0.05463646138006547 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark14(-55.19382483880526,-1.2568629160401186,-42.88422742391517,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark14(-55.20077693926898,-1.4155905262965405,-89.04688597813472,1.0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark14(-5.54815695230697,-1.3488197839970935,-1.5707963267948912,-1.0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark14(-55.551002623704626,-1.2566846830065843,-31.91069432276987,-1.0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark14(-55.570394861564615,-1.5707963267948948,-33.763756085197734,0.024513402754485103 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark14(-55.76038244373162,-0.3733706738877487,-100.0,-1.0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark14(-55.80632736212673,-1.3284235265653748,-10.752066467981278,-6.999539294305066 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark14(-55.93927997866795,-0.015065069747543229,-31.217002157376,1.0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark14(-56.12800204926869,-1.1997506492939252,-67.15410300748181,-9.455909626698844E-6 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark14(-56.19313614017792,-1.0886174261589807,-2.187104367239627,-0.6084531301241439 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark14(-56.25136418321372,-1.5447405222467474,-43.341279278579144,-2198.057979272568 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark14(-56.32924289168097,-1.4014744915848807,0.0,-1.0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark14(-56.46350090058786,-0.2907354892712981,0.0,-0.13326163303352212 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark14(-56.53595888395905,-4.871833810106138E-16,-47.44193859162193,0.8200520653442573 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark14(-56.55637322317616,-1.5479865068931653,-73.7933936852146,1.0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark14(-56.61322988995112,-0.4795222165914734,-1.5144689532133668,18.086970132794562 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark14(-56.62653151837934,-1.2810458557580688,-57.311808973110566,80.01371978856409 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark14(-56.666217996422844,-1.570796326794893,0,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark14(-56.67266682678253,-0.20391277799583013,-11.08095488815955,-0.04068325052802165 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark14(-56.73091343429453,-0.6141053959578273,-1.5707963267948966,-0.0507506528919941 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark14(-56.733779615790645,-0.9551243270480398,-35.80172812841357,1.0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark14(-56.766861952653926,-1.117596450249395,-30.92711543858168,-1.0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark14(-56.81003226875701,14.42974287429071,-1.5707963267949623,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark14(-56.82263169507278,-0.2301971963741424,-42.41218020428277,0.2765984270769857 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark14(-56.845894336738034,-1.5707963267948912,-11.10789245898087,-0.9999999999999998 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark14(-57.14065954346415,-0.5154155654311169,-46.14213206834619,-1.0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark14(-57.21913157223956,-1.3560888859533438,-3.920155666448535,-0.9999999999999991 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark14(-57.25172573771333,-1.0166909076554373,-31.72677444316181,1.0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark14(-57.31481706248559,-0.34671471798813736,-1.4769516363034823,1.0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark14(-57.34344355849702,-0.11878729301364999,-100.0,83.4023046585869 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark14(-57.39150721246126,-0.6712776776619468,-45.54009768874675,0.0629495992935362 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark14(-57.405094764101875,-1.0110731844822265,-46.25785399248188,-8.339168814678118 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark14(-57.513727368244,-0.5623486015379886,-0.006614247368398813,-4.5182995600416 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark14(-57.53405698947668,-0.19745026915628078,-14.865921055590917,-2069.5951606328945 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark14(-57.54438421260475,-0.46395389291357164,-1.4398599241117624,1.0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark14(-57.695734230982836,-0.1024907060107019,-38.46799433678691,-41.76749062624228 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark14(-57.72606345456032,-0.9445339846741378,-80.92540120283161,-1.0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark14(-57.8115358563422,-0.3555864109790363,-31.070310876874515,0.9999999999999929 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark14(-57.83527241978856,-2.220446049250313E-16,-88.50839142817645,-4.665442479286674 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark14(-58.0196438576164,-0.7385556238608743,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark14(-5.804809990148991,-0.001208088737577657,-27.568063858564294,2.252191300966544E-5 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark14(-58.205561104638015,-0.6059446366584319,-80.02630814244927,1.0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark14(-58.414573691234835,-0.6108859052438806,-5.17953534177766,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark14(-58.45472404291162,-1.3298056935854736,-19.33110495085178,0.03628057901449526 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark14(-58.61889146601802,-0.9363306672990334,-14.311340713150067,1.0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark14(-58.62743835548906,-0.3955602233845119,-49.0666601312757,-1.0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark14(-58.62801710082074,-0.8754838752715656,2.83740837515098,0.07807685018563316 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark14(-58.65552376085138,-1.3815588533759678E-16,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark14(-58.759016297887214,-1.5707963267948957,-94.3430898447605,-1.0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark14(-58.88940871854666,-0.0397054336206466,-64.10263041927135,-34.22940318916208 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark14(-58.979078389997504,-1.5691059953227138,-1.56652863857244,-0.20198376041298247 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark14(-59.13845041686066,-1.5132134137369173,-1.088363255961939,-0.06061580742120233 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark14(-59.15547875548318,-0.1833453758207293,-54.18670787771961,1.0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark14(-59.322978487698705,-0.4073076404552214,-0.7911391149943818,1.0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark14(-59.3913882473118,-1.0819556873173815,-66.08936014720688,1.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark14(-59.42737148229253,-0.46232671695093996,-1.5707963267948966,-0.0369804277798127 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark14(-59.453918109694264,-0.1913786223907723,14.467279971916753,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark14(-59.488001332124774,-1.2559398393322767,-37.80227404758137,-100.0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark14(-59.5131448999299,-1.3993298695591871,-1.5707963267948983,-23.847154823453913 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark14(-59.58511325572209,-0.6063593889143215,-66.47080811422384,-14.51412600583268 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark14(-59.588966399366996,-1.5707963267948963,-1.5707963267948966,-0.0472042858378916 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark14(-5.960825973715931,-3.130794363343273E-15,-45.495657109381334,1.0000000107421347 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark14(-59.66536130070286,-1.4034753739030954,-67.95024952902183,0.9940500548031471 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark14(-59.823972283303775,-0.5286560791026659,-39.02906371686509,21.801285508872464 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark14(-59.894231593175675,-1.5707963267948957,-23.431997740938137,-0.06408329131547835 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark14(-59.89811912944238,-1.5707963267948961,-1.5707963267948966,-60.67716060489354 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark14(-59.90782690694422,-1.3615143838888448,-39.081497738625885,-40.63120375401744 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark14(-60.02400786159106,-0.830673842077647,-98.89911798000837,0.0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark14(-60.065891405672104,-1.5667720743361382,-31.47313694036017,-1.0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark14(-60.26868242981429,-1.5707963267948948,-87.41173286553862,0.8726244421862931 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark14(-60.3685823954132,-0.06595325216341297,-85.76727383739463,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark14(-60.40413423282,-1.5707963267948963,-49.069763685027596,-1.0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark14(-60.42075403687052,-0.7179369060261394,-63.407575440814284,0.0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark14(-60.483361528560465,-0.4702163836693184,0.0,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark14(-60.55885607695415,-0.2539935377264325,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark14(-6.0623612796680675,-0.33627262798167656,-45.4112656127808,1.0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark14(-60.64207524093659,-0.19601697300016152,-18.338178525972822,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark14(-60.64560323247419,-0.9292034055679252,1.5707963269038963,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark14(-60.78626421815819,-0.6852429883340607,-65.09715194142572,1.0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark14(-6.084246154492938,-3.003215550020556E-15,-79.3924167549946,-0.9938254863238427 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark14(-60.89722614386892,-0.8477971817005052,-5.174826537415109,-55.340725271684946 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark14(-60.90344273551798,-0.714935452256084,-40.72929996705146,-5.759060877924775 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark14(-60.909449671621616,-1.5707963267948941,-38.72491669712147,-19.237687297338272 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark14(-6.113065783676777,-0.5624199513811285,0.0,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark14(-61.210094437593916,-0.22215249612355456,-74.71359403216287,0.039292315631350286 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark14(-61.294389286352214,-0.10032598656912839,-15.583201509589756,-0.012798585196326179 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark14(-6.1309930217570106,-0.061935045012821016,-86.5240647447318,-0.16765299306659998 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark14(-61.32637388088904,-1.2704932649724254,-1.5707963267948966,4.156410928703725E-16 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark14(-61.360764995801915,-1.1102230246251565E-16,0.0,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark14(-61.36771083626675,-0.0887560362079476,-4.497015989328638,-0.965027617675609 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark14(-6.13869535985279,-0.2051097347162811,-1.5707963267948966,-99.66918582802 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark14(-61.420099693776294,-0.19311514945454702,-43.312124388671336,-16.642729351328693 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark14(-61.55203651932715,-1.2346344255794643,0.0,-1.0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark14(-61.58613972514228,-0.15878296262749947,-41.751588997950996,1.0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark14(-61.69747042982243,-0.16040161822901308,-44.1704566857901,87.34514647950266 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark14(-61.705822502786496,-1.5707963267948912,-7.7700725768366254,-0.7823040122266818 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark14(-61.84584776097119,-0.19015609282051146,-1.5707963267948966,-0.5680527713698613 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark14(-61.897674007779706,-1.5089622855479397,-93.33091448750656,-0.888292955337215 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark14(-61.9186538695571,-1.532494618466471,-1.5707963267948966,0.2556903605439188 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark14(-61.960807173412,-1.3877787807814457E-17,0.0,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark14(-62.12110947700191,-1.2279299534455859,-0.01403709038949709,-1.0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark14(-6.21268179975473,-1.4879310818951392,-14.538599397457205,1.0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark14(-62.249931394068284,-0.12274927465544716,-0.05415697843776213,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark14(-62.333799562881396,-0.965424123842994,-68.34032800135111,-1.0004051317724774 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark14(-6.235809299251201,-1.0741676199879144,0.0,0.20182359279445194 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark14(-62.38064509999941,-1.1063617753544435,-1.2643036382551425,-30.15071044532769 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark14(-62.52422812941075,-0.21379265097460767,-61.60757356023855,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark14(-62.536960578418245,-0.10104047731775978,0.0,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark14(-62.58494020236546,-0.05580076849662897,-1.5707963267948966,-2163.8743413559437 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark14(-62.67012818134634,-3.552713678800501E-15,-66.12054852145538,23.464490792452146 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark14(-62.69990451099334,-0.6618942179259681,-1.570796326794877,2128.1304431055046 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark14(-6.286329953940458,-0.9654619913543464,-51.43189191038928,-1.7122597232112946E-14 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark14(-62.898714566252636,-0.3930835927740606,-89.74905154085586,0.0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark14(-62.97925806970244,-0.03415458007024905,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark14(-63.07293457614952,-1.430142418290441,-68.82295815161442,0.972627895832847 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark14(-63.08503032477491,-7.105427357601002E-15,-1.5707963267948983,37.91767271424799 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark14(-63.08711113371174,-0.9191761170476512,-99.1258053945786,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark14(-63.115106350470185,-1.5707963267948912,-100.0,-1.6472184286297693E-83 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark14(-63.16259179787557,-0.25366801148409274,-82.98711097302224,-0.9820560707141045 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark14(-63.29951674555236,-1.179247370282547,-47.103804620990545,-1.0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark14(-63.34469827122491,-0.3321491734412505,-37.70136575063366,1.0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark14(-63.36786521139092,-1.308271636678212,0.0,-0.46119374650431655 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark14(-63.41008620610127,0.012621380757663317,84.72066845763054,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark14(-63.51980709003647,-1.0967221888085694,-21.552309698776952,0.5420002356049043 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark14(-63.524748187965145,-0.8161618657213628,-15.017008677782329,0.8382486107356877 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark14(-63.53205633903836,-1.2295867262443456,-98.87938490693737,-1.0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark14(-63.59499799733558,-0.2820253674904283,-75.28851480764534,-1.0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark14(-63.66037076854921,-3.552713678800501E-15,-40.98610023689213,-0.559354458409114 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark14(-63.665370866959876,-0.8595993980363712,-16.943870918305578,1.0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark14(-63.7059697437996,-1.2092202228056659,-1.5707963267948966,4.899089007209739 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark14(-63.727326007150594,-0.9003837547691944,-1.7763568394002505E-15,-0.7597994389738858 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark14(-63.73516213038344,-0.9002881623365138,0.0,14.713944841570163 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark14(-63.757952256735265,-1.5707963267948912,-97.16734475578835,-0.843410718013331 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark14(-63.777217331971215,-3.552713678800501E-15,-95.15614352854043,69.15169315570202 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark14(-63.7793771756415,-1.5707963267948912,-55.44649274861789,0.8442818262358925 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark14(-63.84469724757727,-1.5707963267948912,-85.7251402469226,-2371.12790225165 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark14(-63.89300742588175,-1.3673192081823549,-4.6307088393707545,-1.0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark14(-64.06514941329256,-0.5528972843213324,-20.671541789883904,0.8657054369892525 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark14(-64.12672029952314,-1.5707963267948948,-10.682911266748636,-63.515830023199165 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark14(-64.2808577468256,-1.5707963267948957,-10.569354491897162,5.421010862427522E-20 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark14(-6.4344722298241654,-1.0924039109964157,-43.159561474413806,24.65877930871102 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark14(-64.37898472042932,-0.09675951730112825,-30.347238729591723,0.060906316586058384 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark14(-64.38114258489094,-0.3497451379759209,-45.24880904468014,-2068.6194346201987 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark14(-64.54348396422178,-0.4522658134802633,-74.41303294790434,-0.0594418824637071 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark14(-6.4602800002322525,-0.04370611706730132,-4.7112410488137,3.453892140923685 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark14(-64.62125435933358,-0.1640038098848965,-29.03052364704419,-0.7785357870644516 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark14(-64.65014630280464,-1.2966361701006601,0.0,-25.441442851287427 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark14(-64.65663884080914,-0.598006343426158,-6.126580139102714,0.608714916889286 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark14(-64.68552710436637,-1.1629070551531653,-1.5707963267948983,2124.4180272162857 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark14(-64.79410958068809,-0.40761638631416136,-69.01124742362397,0.09907558788766346 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark14(-64.80734278935337,-1.5707963267948912,-52.380619748503634,14.365093194579764 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark14(-64.8600670204131,-0.07159274525017523,-1.5707963267948966,-1.1106882113571444E-6 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark14(-6.486330396886129,-1.5707963267948948,-42.80913710919186,2182.6145459423396 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark14(-64.86715363237244,-0.6405763442887972,-67.14596614335262,-1.0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark14(-65.06795374438592,-0.4003603285552444,-66.03820150063511,26.888274931187823 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark14(-65.08794293025204,-0.49614096475019515,-16.316022620604052,0.7142483208393873 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark14(-65.17281916188037,-1.7763568394002505E-15,-1.5707963267948966,-0.9455563013931079 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark14(-6.520066442673935,-1.2294884279951503,-25.767774739625786,-0.7368414862618049 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark14(-65.29456826936712,-1.3111788533507056,-1.5523022806035864,-0.06255721714903584 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark14(-65.32170187615613,-1.4695236013288726,-0.6598898993939395,2.4932702835357777E-16 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark14(-65.56017568030438,-0.4164684448528069,-4.581010759613422,-34.12359164019543 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark14(-65.58413085297299,-1.5707963267948963,-51.87241307177292,90.95730223756567 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark14(-65.59252099989956,-0.7556433106859984,-96.38346708399095,1.0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark14(-65.61516113598803,-1.5707963267948948,-9.957487211951957,1.0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark14(-65.67203232641238,-0.0011168066463389363,-0.0064845342316857246,0.4809974942678763 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark14(-65.71208447807133,-1.3622148741167308,-152.7443808731242,-39.62929833264699 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark14(-65.75998094050499,-0.6991717950748149,-100.0,-1.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark14(-65.77156302823313,-0.9190305360758089,-53.71534263997199,-52.971030035029074 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark14(-65.83482935071842,-0.8871534233227534,-0.15215578416564207,-6.504824542767506E-15 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark14(-65.9030785503804,-2.220446049250313E-16,-32.54178050089363,-0.05018395415844797 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark14(-65.91309318454233,-0.13659021535900043,-38.90743240412313,1.0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark14(-65.9420393402253,-0.03048511576677626,-115.25880200119784,0.8618947340097378 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark14(-66.0613671930171,-0.4445963274101048,-7.791582027192206,1.000001639476479 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark14(-66.10576038418925,-1.436480284703062,-50.69312794278865,1.0000000000000004 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark14(-66.1246752289568,-0.16627730702832388,-45.76176487328215,-49.68797992956814 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark14(-6.613538288308724,-1.5707963267948948,0.0,-1.0000000000000004 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark14(-66.17418333693807,-1.3615861099666566,-0.1575696053383564,-1.000002902356284 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark14(-66.29237062990711,-1.5707963267948912,-106.0004313155662,0.01072841043702688 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark14(-66.29500901729298,7.017844465775725,-52.84987024848541,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark14(-66.31476020679004,-1.5707963267948957,-95.67959667281261,-0.8542226808182107 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark14(-66.3650619223265,-4.440892098500626E-16,-65.29118838566316,-0.36681816570784065 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark14(-66.53743011704708,-1.5070046301527817,-19.156073413359962,0.0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark14(-66.53810434509415,-0.5145947704477917,-0.16749501403940253,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark14(-66.59932264039735,14.435472653957923,0.0,0.0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark14(-6.661633270947135,-0.5911024601469572,-1.9268820839416616,-1.0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark14(-6.669338254953658,-0.10777681844653944,-5.998901872337555,-1.000000000000001 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark14(-66.70029336789857,-0.06000302512135755,20.026740902859878,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark14(-66.70467482848026,-0.29702112302537953,-0.20058419599667135,1.0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark14(-66.79831641183465,-0.6336753687629031,-53.367779388921,-51.32117736344397 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark14(-66.828338728311,-1.0645958690127406,-36.99209052851053,0.41707465843694536 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark14(-66.8725742633485,-1.0028459181477911,0.0,0.5321448717401018 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark14(-66.88798423615394,-0.5727086155090948,-88.29485975046124,0.9999999999999991 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark14(-67.10312431734454,-4.440892098500626E-16,-1.5707963267948966,5.819458425684828 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark14(-6.726057931700826,-1.599447651667021E-15,-1.5707963267949365,21.787934683288793 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark14(-67.27579566640006,-1.3364913984418232,0.0,-8.008332380732404E-146 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark14(-67.54253135511284,-0.1694731617879981,-1.5707963267948912,42.924119708503156 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark14(-67.56193312171109,-0.10496769259490746,-25.78438005919082,-17.854631689265673 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark14(-67.5677842453873,-0.24372127319456638,-61.159607312008575,43.632502816806614 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark14(-67.63790624092228,-0.43327708968505296,-36.30889763025336,-0.4750561239775095 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark14(-6.764135772964534,-1.1540460768105496,0.0,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark14(-6.764880915981967,-0.32909725667941814,-24.71640730109081,0.6875043474816457 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark14(-67.6504938087583,-0.6938148140760836,-72.69802092588003,1.0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark14(-6.767078145601508,-1.3222280251660696,-65.3987042683063,-1.0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark14(-6.768877055840008,-1.5469253754721048,0.0,-13.887525913844765 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark14(-67.70227237312662,-1.4031863317532653,-92.15074559254766,-0.5752614581551729 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark14(-6.774097949645771,-0.8251398571816334,-54.30827075623942,33.69252533173372 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark14(-67.8311608765243,-0.8254966462367854,-42.48225666950857,-10.114597554631018 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark14(-67.89127707591894,-1.4286155966623504,-1.5707963267948983,74.7283582428168 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark14(-67.95589676637083,14.430529003820844,-0.16545835554271943,1191.23392981309 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark14(-6.802566780531308,-1.5528617290871076,-7.179668633588825,-4.1541052236246045 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark14(-68.08232222967705,-1.469357524500766,-96.2822747902855,-63.441963255528584 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark14(-68.22099821888432,-1.2761762494562134,-6.1895858236044266,0.3096628251479162 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark14(-68.26318533093186,-0.945082705028918,-1.5478824098262285,1.0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark14(-6.830019659548558,-0.010283598882919028,-31.83077262085401,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark14(-68.31935276313715,-0.07923339288419184,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark14(-68.35408891876855,-1.3613884779601924,-20.95399062431305,-0.9999999999999852 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark14(-68.41779887230179,-1.2464308924131533,-5.218180936447665,-1.0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark14(-68.41930216299625,-1.093022554880798,-56.524052712417294,0.7236880015814982 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark14(-68.57637125451515,-0.28032945996104414,-51.523739298544555,-85.0965003001927 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark14(-68.58330259558528,-1.2156348256641498,-1.5707963267948966,2197.4734706277018 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark14(-68.60169637660668,-0.646437215700234,-51.32939580614523,2231.9865531223954 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark14(-68.65932743440442,-0.49832649438373267,-1.5707963267948966,0.03730030872998252 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark14(-68.72139432473578,-1.0116174885536688,-3.433313601586459,99.87460389800427 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark14(-68.7280112257923,-1.0327043137348275,-72.34985501266613,0.4705804772999618 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark14(-68.8012422308545,-1.5407675838383654,-4.549366002519951,-1.0515937936473643 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark14(-6.885250337613938,-1.0730413427924148,-19.41229172033526,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark14(-68.87097492487871,-0.970503817302902,-0.8404596144335691,-1.0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark14(-68.88152503540076,-1.5648309589686646,-37.8563949471407,0.06202419903197629 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark14(-68.94611624542569,-1.565050101596377,-44.331001541066215,0.8818723118641182 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark14(-69.11803799038518,-0.727671396050371,0.0,0.01717510196706644 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark14(-69.17938655454954,-2.220446049250313E-16,-9.81668066199906,-1.596933005575849 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark14(-69.6172624763862,-0.05840234912450973,-55.24501438363107,1.0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark14(-69.63538239658133,-1.5707963267948963,-36.36082729336469,0.0017195163601606278 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark14(-69.6445442663886,-0.14265039887856246,-90.1899327777755,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark14(-6.975675986225591,-1.5707963267948912,-10.303881535497297,-1.0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark14(-69.79389264081497,-0.648784220881395,-53.73728537251412,0.04022830625934892 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark14(-69.85929068390098,-0.37974843781199785,-49.696657286999034,53.116115741066054 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark14(-6.986728864576614,-0.0025340774020641277,-33.36063891364755,0.7177867838488072 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark14(-69.91942678040326,-1.0946780481420717,-0.5707304574874413,-20.67496916597686 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark14(-69.95167123935815,-0.6968100848185566,-83.11905311943063,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark14(-69.96311936362572,-0.20366539965610142,-164.99989424246462,-96.67680050715423 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark14(-70.01803428179053,-0.335884346365915,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark14(-7.009565870402741,-1.5707963267948912,-35.22878908116918,2172.809786084038 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark14(-7.011029782605915,-0.06253896455266748,-34.92422458453296,-2247.1956005018865 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark14(-70.12483303406778,-0.5983326753678437,0.0,1796.3672859000335 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark14(-70.14767135868594,-1.3571803351985867,-1.141066094148357,-99.30466237591627 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark14(-70.26913013689366,-0.5464671562903343,0.0,-1.0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark14(-70.27721779177374,-0.2835800940027274,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark14(-70.69908774108396,-0.46836770392324545,0.0,-0.8554834648515701 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark14(-70.8186569337151,-0.3857528857763188,-31.638410075525425,0.041281120284622164 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark14(-70.85719024628261,-0.6180254118300752,-0.2365027357003537,0.6495184259444527 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark14(-70.98151419686721,-1.5707963267948957,-26.686805284023293,16.285046097815737 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark14(-71.01378930752831,-0.10727409453751591,0.0,-71.6765314699415 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark14(-71.19241023556415,-1.5707963267948963,-0.02206222826082782,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark14(-71.32221278579192,-0.2148070035236458,-58.46986967698673,0.9688798328114152 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark14(-71.37198976019033,-1.1126117672224067,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark14(-7.143556702224851,-1.5707963267948912,-6.868246683055195E-5,-0.04637011184779147 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark14(-71.53498038078571,-0.7564666717903634,-23.585762912308397,-72.30347997112403 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark14(-71.64027269807639,-1.319066399103913,-44.51396035065691,-1.0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark14(-71.65439563554933,-1.1747928428143268,-6.661871797851717,-58.264590071525724 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark14(-71.71673127115359,-1.2678837205306124,-67.42265065371389,-91.75797709770377 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark14(-71.85768543200493,-0.521968020265706,0.0,-1.0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark14(-71.87412641185034,-1.5707963267948961,-94.93489954266725,1.0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark14(-71.90512091118084,-1.3953126616834497,-6.552929436203897,-1.0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark14(-71.92320852672174,-0.1925704695646202,-16.515452162221052,1.0128213439043023 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark14(-7.195590477586684,-1.5203171699445406,-23.185356285642637,1.0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark14(-71.98812090720119,-0.7550959023351395,0.0,-0.3013566513835573 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark14(-72.01812176907268,-1.4466579270710285,-0.21936393283762978,-1.0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark14(-72.09180304863612,-0.03041680122627119,0.0,-2.6515892908405903 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark14(-72.28962889013776,-0.9214467896620196,-15.591859023468757,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark14(-72.29887022029644,-0.04058117478795853,0.0,-1.0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark14(-72.35279043132547,-1.5707963267948912,-7.782935508209107,-1.0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark14(-72.37996855719439,-0.22542248827642866,-89.57748680991597,0.6504055152362582 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark14(-72.40150728441319,-0.5079287203487595,-54.42614689284806,1.0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark14(-72.41045265121336,-1.1147931653737193,-65.06382076894786,-9.218034721335954 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark14(-72.59974011164371,-1.349825814737036,-65.20653225629812,-0.954024684380731 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark14(-72.75233351777666,-6.110168798120973E-5,-68.14572251696056,-1.0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark14(-72.75362258685372,-0.09383728850773138,-4.210119726351223,-9.081666247017615 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark14(-7.278060595399594,-1.5276315001614191,-1.5707963267948948,2.884217054826692 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark14(-72.78334744484096,-0.4231142438567408,-62.15733437628302,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark14(-7.283967211169752,-1.4913907986556936,-18.685491155564463,0.0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark14(-72.87289037208963,-0.09558591888967016,-62.69907735636091,-0.3607831484515316 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark14(-73.17641630056004,-1.3681473991053963,-73.30352895718761,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark14(-73.2417838509848,-1.4073261249854812,-32.44792991095744,-1.0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark14(-7.329065339943764,-0.707179102058211,-33.869826044793854,1.0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark14(-73.45809183590833,-1.5707963267948948,-74.94079012125837,-78.96095025053633 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark14(-73.49711797743373,-1.2741565940870458,-44.08720576395192,-0.9995045531098794 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark14(-73.52991944637428,-0.34095855220155613,-71.31237882811013,-0.057143088338458936 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark14(-7.354034835109033,-7.105427357601002E-15,-46.34783435637664,-1.0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark14(-73.68606253110237,-1.3307287291395677,-181.97973537458034,0.9998391580817136 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark14(-73.70099719484222,-0.7129827781969424,-10.086766493594622,1.0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark14(-73.8849672100917,-0.09863992513938075,-96.69696037906638,-1.0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark14(-73.92451094194458,-1.2643410799385626,-19.069118527830092,-0.8427014402562101 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark14(-7.393606401217152,-1.5707963267948963,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark14(-73.99228576236507,-1.5707963267948957,-40.90661444365209,34.6584687800663 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark14(-74.1031101495062,-1.0247813786867808,-57.69771500138944,-1.0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark14(-74.18876373254396,-1.5707963267948948,0.0,-1.0000000000000002 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark14(-74.20940996503613,-1.4774034852680293,-12.293198300909483,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark14(-74.21779077087358,-0.08646576267848599,-40.91641430474329,4.319392519539871 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark14(-74.22061714308371,-1.3872605069449229,-46.054001318471165,0.9999999999999998 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark14(-74.33140646351116,-1.5107494516253952,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark14(-74.36280423338025,-1.5707963267948737,-59.73045546140449,1.0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark14(-7.446718207951193,-7.105427357601002E-15,-78.99358689704658,24.008805133157466 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark14(-74.51182430110386,-0.21214644492642276,-6.1334095195986436,-18.494045111456757 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark14(-74.52020682681766,-0.9470245295588329,-1.5707963267948966,-93.10006646929226 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark14(-74.57153540444679,-3.048244366154919E-4,-68.69659088720009,0.5304088451468938 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark14(-7.464748554777178,-0.007200734335020568,-7.63084067801497,1.0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark14(-74.80555891012621,-1.5707963267948961,-0.15490638995897546,-14.902248696715063 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark14(-74.826548963836,-0.18074942778674932,-3.175056943199195,-1.0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark14(-74.83898408233023,-1.5451967832939824,-1.008884509745838,0.5739632522276881 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark14(-74.89580326985269,-9.015026097338064E-4,-35.57705752939445,-0.05886719765410059 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark14(-7.510403776687298,-1.0950485049969627,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark14(-75.15200172074188,-0.6608347132037751,-0.8862971400131621,-1.0000000000000153 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark14(-75.19939669974906,-1.0815731938186537,-32.08006669177574,1.0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark14(-7.5214485628375565,-0.5393369158380001,-21.3189209832733,-1.0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark14(-75.26651940057958,-1.5707963267948912,-45.31263958090243,1.0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark14(-75.29698371970962,-0.5856863428416108,-9.860761315262648E-32,-0.9999999999999689 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark14(-75.3084780526203,-1.5707963267948735,0,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark14(-75.31887580821603,-1.5149877495135742,-85.24646508419929,-0.01120375536895301 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark14(-75.32109825361556,-1.4845343585545834,-0.07470088948534226,67.6302152521639 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark14(-75.33940704532782,6.430046433925956,0.0,-84.58996465969238 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark14(-75.37692884153937,-7.105427357601002E-15,-91.38436516102495,-5.204247371379395 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark14(-75.44197759530341,-1.4843035463663046,-10.683430581584346,81.25592611869973 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark14(-75.51719732319249,-0.17913983386333143,-1.5707963267948966,9.93605679356844 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark14(-75.52518641122936,-0.8847971704384585,-55.52851366872743,0.9999999999999999 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark14(-75.58104566684726,-0.5738460598236914,-41.15348275941954,-41.18097210010117 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark14(-75.58878015610252,-1.4270022792070924,-45.394027498517104,-1.0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark14(-75.69381746014584,-1.5707963267948912,-40.799181438505485,1.0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark14(-75.7010420115298,-1.5468257009523831,-2.1861002206390694,1.0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark14(-7.570869780537974,-0.6518157717626306,-14.534523032022989,-92.2092967084342 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark14(-75.75950638855309,-0.8683988632273063,-80.67782829252504,0.03873655206201492 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark14(-75.82878765688248,-1.5707963267948957,-75.08665347769121,13.672660355664393 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark14(-76.0316121783607,-0.8777616261068886,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark14(-7.610777765294787,-0.20775348685005832,-1.5707963267948963,-0.016305180653162096 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark14(-76.13483417679346,-0.7235914038774129,-56.21783737752493,-1.0000000000000002 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark14(-76.17222784572284,-1.0902089379791806,-5.971081529504374,-1.0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark14(-76.21678609964016,-1.0809770427592043,-99.96921228378854,-1.0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark14(-76.38384074148973,-5.485681001741023E-15,-100.0,0.498750208454533 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark14(-76.60953560019232,-1.5707963267948273,-1.5707963267948966,-89.63115161256007 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark14(-7.66736930207839,-0.7247622990956373,-31.164578914634532,-74.17097004023687 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark14(-76.72567712122896,-1.3548791872751735,-1.8787698332468779,-88.83747266898129 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark14(-76.91192878470542,-2.792178488133005E-14,0.0,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark14(-77.00735606096426,-0.012316329814454153,0.0,0.0011099264565263064 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark14(-77.10216052187913,-1.033523322596256,-82.45806709767804,97.64044987011528 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark14(-77.12939729570593,-1.5707963267948912,-13.268976656663625,-52.858727891844715 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark14(-77.2470633038818,-0.3014203657571383,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark14(-77.36027659742844,-0.6179150465727636,-83.62206752042671,-16.21017298392411 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark14(-7.736141801990335,-7.105427357601002E-15,-74.03323139347917,-1.0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark14(-77.36176200286675,-0.1459019786120166,-18.13368807388494,-16.154867195168393 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark14(-77.38441079726852,-0.09656352434301337,-0.4819969131982216,0.0494560698531664 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark14(-77.3967973345333,-1.3768631745614173,0.0,-1.0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark14(-77.39917820186045,-0.33194000904283383,-88.53089364611174,-0.012668145233166332 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark14(-7.753475385869436,-0.7522064465400149,-60.84854381627329,0.09189918567391064 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark14(-7.761247188162912,-1.4949968543398549,0.0,26.916953896742196 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark14(-77.699155303408,-1.406715994720374,-33.14772170674043,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark14(-7.770902736824766,-1.509339164845408,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark14(-77.71943540045572,-0.13379826774939457,0,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark14(-77.74400718604181,-1.5707963267948957,-90.94538392740147,1.0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark14(-77.75329459070389,6.43213004671948,-1.255153850117656,0.0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark14(-77.82006710374122,-1.5707963267948952,-4.835867329015454,100.0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark14(-77.8530998546709,-1.4880133934438566,-0.169035024114352,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark14(-77.87903549197263,-1.1986575763233276,-3.2881973849565402,0.010335882162008578 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark14(-7.790515955219689,-1.9047376270787615E-13,-88.10543680267573,1.0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark14(-77.95448847301479,-1.5707963267948961,-18.581310150952795,82.79477699155372 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark14(-78.0104886390955,-1.4601472989101019,-78.28319256651966,1.0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark14(-78.18804116547007,-0.38392217669642476,-53.8183384155574,-0.9999999999999991 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark14(-78.22712604087741,-1.5707963267948963,-74.77736013162406,-0.12066992490056005 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark14(-78.29343294306562,-1.2323851674729658,-43.40873442467168,-1.0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark14(-7.850514200167796,-1.067726653972464,-0.4633260141846985,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark14(-78.55442192773792,-0.06562278480374062,-30.27224791602228,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark14(-78.61995711263656,-0.102390853457071,-0.2599313027644118,1.0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark14(-78.65118738368177,-1.5707963267948963,-22.376626645377428,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark14(-78.6665003928674,-1.254053170029655,-0.4420904534149276,1.0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark14(-78.67073433824152,-8.881784197001252E-16,-68.53447507499595,-19.09431513490963 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark14(-78.69136859769085,-1.5707963267948912,-1.0809589931222683,-1.0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark14(-78.71851072429516,-0.251558952304606,-16.562910438332622,1.0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark14(-78.77082505631472,-0.8415188790281047,-61.02055806504696,0.9999999999999964 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark14(-78.89530864261421,-0.7428358115103597,-164.7068845164255,-0.9999795294208347 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark14(-7.90747027454961,-0.3230607832578061,-10.505301475701103,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark14(-79.14776186886374,-1.5707963267948948,-60.743165164076515,0.021303744407768693 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark14(-7.916941388578566,-0.06585831707976597,-10.788324959020574,-2282.7641442642475 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark14(-79.22501854351462,-0.7905049412654915,-1.5707963267948966,-55.29951202494505 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark14(-79.22658825718071,-0.3951476988293081,-11.442285208292802,-0.7292992958469602 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark14(-79.25535803427329,-0.2759623265476679,-72.95745101218012,-0.18631925762599624 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark14(-79.359668842342,-1.3821432592944314,-19.205375827500262,-71.45060308063402 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark14(-79.50170925127047,-1.570068982303181,-22.76451426383929,-1.0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark14(-79.82191237643238,-0.054808599298452054,-1.0074266378169507,0.4261723151401089 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark14(-79.83227909515603,-0.06839985611309009,-11.28614048171714,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark14(-79.84389499666594,-1.5707963267948948,-59.060588681359235,0.0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark14(-79.85764431280805,-0.16657450784065692,-1.4042234887877667,64.01006083725801 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark14(-79.98402148156687,-1.058064401383632,-1.2780898500113895,1.0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark14(-80.22146465083036,-0.052562473401806906,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark14(-80.30552906756834,-1.02253695613369,-9.662936320735277,-1.0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark14(-80.39978283445184,1.8898034826139216,-6.431074757441,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark14(-80.42312031594503,-0.006407940762082107,-36.037264112731336,0.9880260676302698 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark14(-80.42602664202026,-2.220446049250313E-16,-33.81285484734009,-0.00268498543541551 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark14(-80.60236923243001,-0.9350679946326231,-0.439226988414494,1921.9948323122476 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark14(-80.6379013785177,-0.46247180404597543,-33.01642057929668,-60.10470611112596 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark14(-80.77311591636284,-1.463498398553987,-90.37172511075723,-1.0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark14(-80.78212802044123,-0.3778516593128718,-3.6524337907405884,0.15487827475267324 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark14(-80.80282339663408,-1.5707963267948948,-70.95360090647,2215.953391432443 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark14(-80.85355497873043,-1.5707963267948954,-78.28594049258103,-1.0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark14(-80.87787344640756,-1.390665074982471,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark14(-80.92867464166956,-0.5942394556034234,-57.80880629480252,0.60261893258631 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark14(-80.94990878379318,-1.5277138537795045,-95.5027494425388,1.0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark14(-81.02333211649359,-1.5707963267948948,-10.934895007822476,0.20501179739347303 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark14(-81.07849838192249,-0.2235256355472683,-14.354459935137868,0.03584779423392587 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark14(-81.10907683150283,-1.2212933807670838,-1.1099291764906423,-1.0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark14(-81.1287875772233,-0.9809654464552414,-25.315244799232477,-81.35501368206712 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark14(-81.20290241281151,-0.0946563589174409,-1.4252211533204537,-0.6445240579842126 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark14(-81.23175676108633,-0.1272188987116818,-44.471487000924384,-1.0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark14(-81.3538817215302,-0.3912821088665377,-11.867907169889207,25.1847643648847 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark14(-81.35904313960572,-3.002708563479396E-17,0.0,2.5988524414112248E-113 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark14(-81.36647399745634,-0.327416299214498,-97.35822899112823,24.343024671195295 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark14(-81.49760237796546,-1.5707963267948095,-22.805896023177723,-41.59181890369188 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark14(-81.58680227342161,-0.022596566962540705,-42.49253873388285,-1.0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark14(-81.5885011202644,-1.0731209024213868,-31.375121500525594,-57.7013764920975 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark14(-81.6166013684029,-0.5988376721429409,-51.57781934973124,14.947720434398851 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark14(-81.92271934375933,-0.5697986282987123,0.0,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark14(-81.9563754357556,-0.45661233546588353,0.0,55.42177735192754 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark14(-82.05059250552728,-0.44487828415095176,0.0,0.04441157083385991 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark14(-82.09757719776516,-0.4667514880058608,-73.57344294232388,1.0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark14(-82.18590147532625,-1.5707963267948963,-63.786578592213004,0.7233321131936755 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark14(-82.25035626911443,-1.570796326794896,-83.9925945977573,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark14(-82.26080779928554,-0.04525747387642032,-0.38583861223189064,0.0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark14(-82.63280286647675,-1.0255742575238962,-10.830588714599841,-76.72018864637607 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark14(-82.68193542591742,-1.1655117501288355,-33.86669870793608,1.0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark14(-82.7048396270628,-1.2624592444146259,-67.87696022540737,0.007287049061347778 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark14(-82.85444035300891,-0.3424750443421196,-21.950232366623347,67.28645655105419 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark14(-82.95054227721849,-1.3360301545849507,-38.02342794213754,-8.55769613810831 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark14(-83.163538237036,-0.9312617250273718,-18.852077095009406,0.07053963801959484 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark14(-83.18185655860603,-1.3482065730274777,-45.410671556312806,-0.6933990937403196 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark14(-83.18229079986729,-0.38711969546791586,-32.677275397033036,1.0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark14(-83.28433435893263,-0.617010921758701,-12.045451719297645,19.101560285054 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark14(-83.31008479867216,-1.4880210204874846,-84.19440860302099,-0.915836811428735 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark14(-83.3261931029827,-1.5707963267948926,-29.993825069825846,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark14(-83.34747840445813,-0.9635941918300945,-20.746131056632763,32.75130723203142 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark14(-83.41072378689401,-0.1810653107040454,-3.552713678800501E-15,-57.21618255327166 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark14(-8.348430994127128,-0.03805799466628659,-11.905029244161028,0.12373681272384829 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark14(-8.353060508887886,-0.7855163793259141,-88.23028876924788,3.9000548324331845 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark14(-83.60940588076798,-0.7804999025889714,0,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark14(-83.69191558310757,-0.2969042962573602,-81.63498094274651,0.2964522493742654 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark14(-83.72246203045577,-1.5707963267948963,0.0,0.0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark14(-8.391727003440266,-0.7587311918244245,0,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark14(-83.97922578214371,-0.8270798478820648,-0.864862265626973,0.02484360606727498 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark14(-84.06489802661228,-0.07041295418521963,-76.28795163558105,97.43036376360554 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark14(-84.2020269595069,-1.5707963267948912,-3.552713678800501E-15,-1.6543612251060553E-24 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark14(-84.3716644533105,-1.5707963267947846,-68.37622810457843,0.31620358076884514 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark14(-8.439714803783552,-1.4261292474174807,-18.040722762803103,-0.03542722606290061 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark14(-84.56820938267117,-1.509159588958406,-72.67761146621343,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark14(-84.64154065662045,-1.3838830618684008,-13.497712835281305,-1.0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark14(-84.66354835463842,-8.881784197001252E-16,0.0,-30.709872649641195 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark14(-84.89908977732132,-0.25416114096451103,-157.5139905282934,8.277922976200628 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark14(-8.493713379032005,-1.0472370366704693,-29.478712080501523,78.4572701449489 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark14(-85.16069874317249,-1.2079654715944719,-27.575661508022705,0.0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark14(-85.31078445955656,-0.1981768663684348,-15.18583246467075,55.240058263849576 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark14(-85.32073368956274,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark14(-85.37176440231373,-0.9948245143715161,-20.756000067117114,-0.23705869402764534 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark14(-85.47634824638651,-1.0991729853936114,-30.242445063414944,-1.0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark14(-85.58040220343659,-0.38915453732871935,-1.5707963267948963,-72.78599310686226 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark14(-85.61321388860404,-1.3394153091359555,-46.28906209651813,6.294985240143262 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark14(-85.61369178263988,-0.4711707435308736,-10.566191928053257,1.0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark14(-85.61965620817935,-0.08995989119261746,-1707.3700066810582,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark14(-85.73818888342252,-0.49219942627917,-100.0,89.05192311622694 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark14(-8.574209402105994,-1.5707963267948961,-1.5707963267948906,1.0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark14(85.88154671160976,-39.44756171221548,0,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark14(-85.9367630567488,-0.03411897756030582,-40.81409058613883,0.36673821125968276 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark14(-86.03816535341538,-0.04002008657347189,-23.916840175235208,1.0000093363959126 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark14(-86.04535233779166,-0.15737186691378868,-0.22203538742411155,36.54205614106522 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark14(-86.21700826140079,-0.448683499045615,-1.4632066704233497,-63.9053207681374 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark14(-86.25640388900436,-0.7229432751037523,-100.0,-1.0000276648344764 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark14(-86.49231158383304,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark14(-86.50615352992479,-0.38734389703526517,-39.029565371930126,39.98207665921797 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark14(-8.6568321684573,-1.5707963267948948,-20.53208445350939,25.435207057324806 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark14(-86.60884367996451,-0.05852080437836684,-15.462737893456207,-0.9996302849932109 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark14(-86.63811106368811,-0.2506148515001575,-1.5707963267948966,-0.38889162943395433 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark14(-86.6557570714393,-1.5707963267948952,0.0,-0.996714006704723 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark14(-86.6592744354118,-0.019892535116037058,-0.04113508224762494,0.0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark14(-86.67738296458108,-3.552713678800501E-15,-66.34432347267722,45.23773198509528 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark14(-86.8125123214395,-0.027528309562677853,-78.72726434766794,1.0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark14(-86.91610926941473,-0.710057862245626,-32.65261756879626,-0.9999999999999991 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark14(-86.91698622942734,-5.54845564244344E-4,-32.84881208980484,-0.05367885364245495 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark14(-86.96183851054094,-1.4107683968506417,-2.969957783400215,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark14(-87.03410858847528,-1.138115371079567,-28.40072275299643,81.80139604460106 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark14(-87.06195653764078,-0.7161679992138339,-0.07086471235648314,-1.0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark14(-87.10218855484877,-0.6561153288004613,-17.3397765877195,-0.9999999999999929 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark14(-87.1512475978888,-1.0419751536153723,-0.7375617557077112,-52.69216890498119 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark14(-87.15708744162967,-1.5312838477733322,-84.37672404517429,30.002796430429225 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark14(-87.1817160788634,-0.0048452266170508785,-81.30766983578421,-0.06255252804840493 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark14(-87.21271160695925,-0.22385022262063328,-40.06790794754741,-1.0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark14(-87.22200074848097,-1.5707963267948961,-71.1208217023112,1.0000000000000018 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark14(-87.32316526635037,-7.105427357601002E-15,-39.95651322896847,0.05016550544263197 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark14(-87.38216307362332,-0.9101480086763205,-67.3055731405154,91.20830341295925 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark14(-87.45260980169844,-1.5665647826436597,-35.070101999696206,-1.0001219331556817 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark14(-8.74817532443302,-0.47671671954727873,-88.92564279552253,-2334.5363475948084 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark14(-87.5749856396546,-0.7582111065522117,-32.730323568230574,9.953140465530264 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark14(-87.58778046841796,-0.319493015648197,-0.4162669057332917,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark14(-87.63628646464632,-1.5353737381758048,-18.36371655567008,-1.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark14(-87.65744843994733,-1.186809618029676,-31.453505793823595,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark14(-87.78487463209109,-1.157638905746656,-1.5707963267948966,-0.7396066361386691 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark14(-87.78945200339666,-0.007186749311522078,-57.63154955688418,1.0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark14(-87.81213293615698,-0.1608277263118083,-38.922775503653895,-1.0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark14(-87.83573364500995,-1.5654199872034613,-1.5707963267948966,-48.75978163874078 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark14(-87.9013529064763,-0.10785647503466936,-50.601131311607844,0.03438749459842683 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark14(-8.79256045907324,-2.465190328815662E-32,-1.4249248191566437,6.612465687951559E-11 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark14(-88.0221581013519,-1.558284813762449,-9.78181611042202,-54.41715506606204 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark14(-88.04083552773047,-1.5707963267948912,-145.04390955913038,0.0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark14(-8.805439759137288,-2.220446049250313E-16,-21.325748091805313,16.01721377532335 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark14(-88.07582936418996,-1.5707963267948963,-44.01184002787868,33.602931125177165 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark14(-88.22598323029062,-0.21712666936363748,-0.013011605321167822,1.0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark14(-88.24397505879266,-1.5707963267948948,-9.686776676524104,1.0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark14(-88.56997093252198,-0.5455433660327467,-1.5707963267949054,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark14(-88.7080296433927,-7.105427357601002E-15,-33.35349622496713,30.9070239179903 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark14(-88.82590881310715,-0.10007739139745786,-57.60478394708505,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark14(-88.8811953749177,-1.049376359749627,0.0,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark14(-88.98972332142658,-0.1252305694439288,-1.5707963267948997,1.0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark14(-89.02129833592568,-1.386465557239518,-1.5707963267948963,0.05134231373626186 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark14(-89.03075730552301,-0.38996991588772445,-59.01843015990051,-0.99984175424682 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark14(-89.05100834109827,-1.5707963267948961,-29.917165947380223,0.06256089407636228 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark14(-89.16963796853737,-0.7966638799675309,-1.5707963267948966,5.118795808039409E-16 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark14(-89.27639287001905,-0.027835058843659,0.0,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark14(-8.931451501837483,-0.02928270876145811,-117.55188002643499,61.76278883879689 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark14(-8.93228599884688,-1.5707963267948912,-21.25247897981579,-1.0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark14(-89.43753603717651,-0.873702333776931,-41.740663187709174,74.88458824623017 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark14(-8.953945452918866,-1.4579381599714516,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark14(-89.72580250204011,-0.30842377330466025,0.0,-1.0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark14(-89.99865700545624,-1.1102230246251565E-16,0.0,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark14(-90.03886894028005,-0.005106423691778772,-31.653455487778956,0.5548200318376213 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark14(-90.05596769336861,-0.005612395274610882,-67.4478434263309,-1.0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark14(-90.27424393489414,-0.01994147226287879,-53.47317496654796,1.0000009988938712 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark14(-90.45499973345436,-0.04235298605530691,-1.5707963267948966,-0.864587480030621 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark14(-90.46374590295821,-0.6060919693335602,-16.59271990200037,0.9999999999999964 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark14(-90.56376808166506,-1.5230757777742103,-0.6301080660713191,-57.69233245344349 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark14(-90.61782745790346,-0.6273240714173234,0.0,-2185.346995294635 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark14(-90.87800715303486,-1.5707963267948912,-37.66518034552736,11.579834291955734 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark14(-9.087930207515377,-1.3803093354993374,-12.964167950962057,0.6268811369491194 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark14(-91.02538933493045,-0.006021524568110906,-1.358651111025412,0.3591412718378059 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark14(-91.06080568844813,-0.5884828616150113,-4.514910523172714,0.6835576089431433 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark14(-91.06236261452378,-0.11847994668700501,-85.70004535134983,-0.8778828400399619 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark14(-91.31911041540017,-1.5195394882554751,-48.98730737225736,-1.0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark14(-91.43008205538585,-1.1769446698332542,-40.58814657824461,-1.0000019628397754 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark14(-9.153349700554166,-0.8868081429734223,-0.5479375351167963,100.0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark14(-91.54158296946139,-1.0233654564563832,-5.207054577588847,1.0000007891201304 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark14(-91.58035945296447,-1.1414871605241093,-17.030421683903093,0.9999999999999994 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark14(-91.58672630279119,-0.0038405178939430696,-59.81756699982375,0.029889410631991797 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark14(-91.59875463183782,-0.2795841081152728,-1.5707963267948966,-0.36727997393097506 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark14(-91.6366347220535,-0.16608985419027308,-88.41371194737096,1.0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark14(-91.66881483924512,-1.2582136759981615,-8.935097168737258,-71.17302953390963 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark14(-91.70894823791429,-0.428917904847086,-29.66313892009832,0.0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark14(-9.184805791106962,-1.5527990158948464,-51.16529548003968,39.768802780323604 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark14(-91.85538660419476,-1.5707963267948766,-4.210794174792344,0.878818560001828 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark14(-92.03902598153452,-0.10049822578170978,-1.5707963267948966,-0.757195436782107 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark14(-9.211397241626573,-0.8139524316290636,0.0,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark14(-92.12554528606715,-1.5707963267948948,-72.93959347380871,-1.0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark14(-92.21941643679754,-1.2997387326524226,0.0,-0.0694796221069468 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark14(-92.27176224524864,-1.4995660128562305,-26.956520478007874,1.0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark14(-92.315627319157,-0.3189846185191668,-50.91611206069386,0.9999999999999998 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark14(-92.67286323904423,-1.5305592127685441,-71.04173396067058,0.8614939159157934 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark14(-9.281992934065059,-0.18702272913418658,-2.9651136097500057,-60.79407591026526 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark14(-92.84484887064768,-0.713382244359252,-9.485404245404366,-0.053260218017812555 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark14(-92.89392486841214,-0.08213418915221483,-66.05035792500675,41.834082108438395 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark14(-93.04938917173548,-1.5707963267948912,-62.12769296024376,26.211933051687723 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark14(-93.05927056611729,-0.530852918993105,-43.89393589968091,-1.0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark14(-93.1100249702844,-1.402004311427793,-14.806407208399364,-0.0020955180974524257 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark14(-93.39719825685715,-1.5521700279261137,-66.38607147732985,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark14(-9.355797748729422,6.431974191616356,-1.491985570461627,953.2315860855873 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark14(-93.69820514897305,-1.5707963267948963,-25.20529959329459,1.0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark14(-93.91103006958411,-0.7150706130703242,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark14(-93.93432311692895,-0.2369353382754622,-0.009389207859225214,-32.8362981578052 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark14(-94.00362478423067,-1.545064112327237,-65.31112102268972,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark14(-94.0509069395283,-1.2534040163997342,-49.33489807629063,-1.0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark14(-9.410229979236819,-0.2843696482803957,-1.5707963267948966,-0.02687172027330007 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark14(-94.13310560251122,-0.21990536504840974,-60.85638438434386,0.0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark14(-9.429483263068168,-0.9209509336746089,0.0,-37.47474260456676 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark14(-9.430950520436571,-0.3260965649583676,-23.852882888232983,26.525270065925564 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark14(-94.31371478613528,-1.5707963267948841,-73.61303076128391,1.0002346193583505 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark14(-94.48713163724217,-1.570796326722678,0,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark14(-94.52172095557923,-1.188964621387213,-18.231068778348728,1.0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark14(-94.57375802849502,-1.3008454173267843,-0.05504495775339366,-1.695659434550569E-16 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark14(-9.45852419380114,-7.105427357601002E-15,-56.76998386479131,18.408560099982935 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark14(-94.58548273363445,-1.4051280449520331,-22.008424051097883,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark14(-94.74229334423417,-2.220446049250313E-16,0.0,-49.94126228856403 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark14(94.75890368520626,34.09551901538924,-88.77026474715146,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark14(-94.8102381123196,-1.1789522005482524,-39.40008708590332,49.21104529709078 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark14(-94.94234314288916,-0.9189085857179347,-31.652951129762968,0.12452459182026132 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark14(-94.96894771740192,-1.5265557710173472,-88.3868233830454,-1.0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark14(-95.02228862949543,-1.012179534113617,-70.57724110490777,0.025502464657506642 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark14(-95.02364441052032,-0.8379532485081711,-43.39857600862636,-41.920703734930626 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark14(-95.06115292322475,-1.0179952200491913,-67.10241845493941,-46.468308045439755 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark14(-95.12782461815554,-3.3343753986096764E-15,-45.25488193153895,-45.77554952044116 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark14(-95.14191427082852,-1.358412768828586,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark14(-95.25701181398847,-1.1892568820562388,-0.05339052157286206,1.829237050227382 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark14(-9.530863141032663,-1.3392859288404666,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark14(-95.321684199679,-1.5707963267948961,-1.5707963267948966,-1.0302731653289783 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark14(-95.49482909862395,-0.7583137259953228,-75.18332805011012,-0.03535733106978014 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark14(-95.6767493045497,-1.3044443592932455,0.0,-0.10198184112577402 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark14(-95.89018925770625,-1.5642783027786393,-67.28828226670383,-0.00909227574357141 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark14(-96.02117794129386,-1.5707963267948963,-12.687111801231271,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark14(-96.08414847849487,-1.5349626101882,-73.70530810981406,25.743774775301997 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark14(-96.08781468629404,-0.2401516721467223,-73.32979580421747,-1.000000000000002 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark14(-96.11796440661205,-0.6996470038524312,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark14(-9.617796526192649,-1.5364540890817309,-32.48965266090804,0.47058332588418367 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark14(-96.21717820200146,-5.610398473507083E-4,-90.45593379014544,11.078033222773321 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark14(-96.40371450122262,-0.26278778688105714,-72.41891764970931,-31.039805392336035 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark14(-96.4321716797636,-0.7297549998154409,-59.177653858090636,1.0450251780812352 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark14(-96.47639934172695,-0.7083685259183232,-11.805115486922976,65.19512899590454 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark14(-9.65067174830423,-1.5707963267948957,15.04134248464539,144.29195128362772 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark14(-96.51171687337309,-1.5707963267948961,-38.60865377163974,0.09079067317430534 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark14(-96.53362616461133,-1.5707963267948961,-72.55805641165455,-0.8641105114704482 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark14(-96.63791279326416,-1.3569875926181312,-100.0,1.0000007532114605 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark14(-96.70060354516423,-1.4645060049741503,-0.8522841886829311,-1.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark14(-97.02319950708875,-2.220446049250313E-16,-1.5707963267948932,-1.504632769052528E-36 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark14(-97.04398531023801,-0.16405295985031287,-1.570796326794895,1.0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark14(-97.12961923108907,-0.5034923476644122,-20.28994755896889,-1.0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark14(-97.13252344812679,-1.5707963267948912,-10.959278346406819,-35.25484205232887 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark14(-97.14400893969406,-0.09748387891592915,-78.61336359094247,-0.5161862744342578 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark14(-97.18691306475814,-1.0070441832889474,-73.67338822709195,2097.245850461612 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark14(-97.19830063916444,-0.36817127707308445,-41.61164242127648,-100.0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark14(-97.27558859976797,-0.7962971656222423,-1.5707963267948966,1.734723475976807E-18 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark14(-97.33257727701753,-0.04004720075526072,-0.031091522285859097,0.0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark14(-97.48931386622158,-0.5661488452194746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark14(-97.58057601015896,-0.9726380739311108,0.0,-0.9999999999999999 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark14(-97.61330416999027,-1.4839227016617726,-0.14869467927656393,1.0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark14(-9.786429077068208,-0.16557779911435774,-0.05193828436659753,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark14(-97.90903868027434,-0.8968873719503461,-100.0,-86.96670972626774 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark14(-97.94595523947082,-0.4761743448145611,-29.53925569384525,1.0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark14(-98.04721928432917,-0.2520521762150125,-0.4045343004420095,1.0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark14(-9.805902821958629,-0.26900819894140016,-75.40782317589499,-82.08423460943567 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark14(-98.10794807596193,-1.4689204917121384E-13,-14.268621748872455,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark14(-98.36170072732595,-1.2228292358992345,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark14(-98.45208297555929,-0.7962763817715715,0.0,-1.0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark14(-98.46659026692731,-0.4861114486556823,-18.941541183090628,0.008660553622766187 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark14(-98.7241547689167,-0.3136219442651348,-46.00474620575938,0.06258513326133121 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark14(-98.82386818651015,-0.256314776516257,-86.38411239860139,-1.0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark14(98.88641136280202,13.199508772225926,-5.167429649505067,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark14(-98.93757867783214,-0.30374806234867574,-0.35381089854879244,1.0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark14(-98.94715540252652,-0.41849353623219454,0.0,-286.81242403564505 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark14(-99.01015665159667,-0.12518163487364897,-65.10933276116486,1980.2375657827392 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark14(-99.15918110170287,-1.1785956564484974,-10.864117520553677,-0.8770746064917385 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark14(-99.21591471975712,-1.5707963267948957,-0.26433414273575656,1.0000133801787814 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark14(-99.41750333795152,-1.2603357790832694,-68.09541013674614,-0.5897808790174297 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark14(-99.43059362349594,-0.3555474266327645,-22.47871088219756,-71.08271396417105 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark14(-99.444491795267,-1.3705999916631217,-44.33748742330121,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark14(99.46262888310085,-87.72821976617232,0,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark14(-99.47357485117494,-0.10302202313607671,-59.45126742793441,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark14(-99.53196310769839,-1.2775913464491915,-0.7875867588791576,-83.50756389504726 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark14(-99.58301548177903,-1.5350502464935616,-22.46062891528662,0.0625526783758037 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark14(-99.59630857606987,-1.4133525157691236,0.0,-0.3871815338722794 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark14(-99.5980962925549,-0.7146629026326505,-7.86921931422693,4.1359030627651384E-25 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark14(-99.68869154014295,-1.5707963267948912,-15.129943378204993,-9.654813004479154E-6 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark14(-99.79663394512485,-1.570796326794577,-58.80366300883345,0.8368770750546517 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark14(-99.8125377360936,-0.7240974078892048,-23.9908113281017,-0.1745911079275464 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark14(-99.8157184259791,-1.5665718811747575,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark14(-99.87137930972116,-0.004312335219692128,-1.5707963267948966,0.23233283548330286 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark14(-99.88143292130196,-0.0986157507238703,-24.01393867709128,-7.31511930420656E-99 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark14(-99.88754751566798,-0.39741470683798413,-9.585760419018056,1.0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark14(-99.90852183542069,-0.21573546347918415,-62.96863415132427,-0.5430656768469049 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark14(-99.93578112299647,-1.296469144147946,-73.4969572567543,-0.8653779837109815 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark14(-99.98357736860189,-0.05911847230160913,-2.8437117242855363,-0.7782031441008097 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark14(-99.98396511546397,-1.5705188609555498,-1.4337486072940606,-1.0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark14(-99.98407317796588,-1.5707963267948948,-1.5707963267948966,-64.58914376842068 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark14(-99.98811682676124,-0.14549848589516134,0.0,0.05493720296297712 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark14(-99.99183419501944,-0.031162349113793397,-1.534699419532274,0.9990397495170602 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark14(-99.99600438019485,-0.44303473853580494,0.017960538279766354,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark14(-99.99629945750105,-1.2657119303430542,-1.5707963267951364,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark14(-99.99740640434831,-0.1406495972394024,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark14(-99.99999999993074,-0.8424655145430564,-1.5707963267948966,1.0000002475772383 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark14(-99.99999999999983,-1.5707963267948881,-1.5707963267948966,-34.54844805946453 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark14(-99.99999999999997,-1.5707963267948402,-21.476317486274993,1.1985091468012028E-94 ) ;
  }
}
