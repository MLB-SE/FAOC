import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(-31.138117758576954,-2.454505648850187 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(-37.22297641457138,5.936097348860841 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(98.69596609219946,-6.1703776774815395 ) ;
  }
}
