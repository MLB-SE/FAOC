import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(0.5683551474595845,-0.5683551474595845,-78.74241865682859 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,0.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,0.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-100.0,-40.19140624999985 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-40.19140625 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-709.3929444002601 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-100.0,-709.5791406638886 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-709.5930750466623 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-100.0,-709.8741006113436 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-713.6299469292701 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-720.7776100859501 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-721.4537720515915 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-724.341401492427 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-734.6921214875238 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-739.6885101119523 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-741.142653293994 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-745.2455379892775 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-745.5375916351138 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-745.7436382227603 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-746.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-746.6650705951766 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-825.9938636770295 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-199.58444676874404,-1.494140625 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark47(100.0,22.68058671965582,0.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark47(100.0,49.78739286488161,-745.7886554863369 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-616.4546624589688,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-642.2588849272731,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-646.0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-649.19140625,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-71.25574236870536,-709.0279770356552 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-97.4957110175329,-709.8050078769622 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark47(-104.05147962745737,-605.6453522168906,100.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark47(10.44231903433027,-11.932995891095729,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark47(11.120320839534912,-81.01661982155484,-745.9999999173247 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark47(-117.26031591558437,-736.1195033638988,-709.458512403217 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark47(-11.738923881853239,11.738923881853246,-40.0061225321607 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark47(-12.08523097447602,-93.1809237043411,723.39773300572 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark47(-129.82396857303138,-579.554817267732,-1.4941406249999991 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark47(13.159532937247477,-82.74654246145137,-709.2271727718112 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark47(1.320723815719134,70.32125511359061,-780.8528098407534 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark47(1.4081973894881847,91.36797337538347,0.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark47(-141.62372872169962,-604.3762752669992,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark47(14.876436399645684,91.55121225734217,67.8616445608809 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark47(15.251441215679804,6.041946624925302,-778.4532437120503 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark47(15.257516587958257,61.56739318296805,8.881784197001252E-16 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark47(1.5273538590741254,100.0,-708.6325470651695 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark47(152.7576616286918,566.9064404522672,-709.4271521412992 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark47(15.382912893414797,76.79705733944374,-53.522835738163856 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark47(-154.32511908804304,-554.9012738236707,-1.4123425685044153 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark47(-162.3624775524154,100.0,-709.5856885830411 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark47(-164.79410403282543,-563.4032974219677,-745.7326530147326 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark47(164.81121506204727,653.3099106741487,-709.5558090784658 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark47(1.6589250282661965,-98.17013574833247,-746.0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark47(16.82560694532127,34.92156836756118,-720.1013715515427 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark47(-170.1321307410168,-539.1341366270801,-709.9992459536594 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark47(-171.11143469021098,-576.0962239954803,-745.7243418997989 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark47(-171.11552117463202,-579.0054300485173,-709.7148797116665 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark47(-171.1547801371951,-615.7725530841382,-709.0329847737696 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark47(171.73175160990536,538.8837668649343,-745.5533793828932 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark47(-178.01621634716588,-545.7596777906572,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark47(-188.08317325447652,-557.9168267442883,731.2109299740085 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark47(189.98854496767865,531.0361256444835,-2.5250687552531312 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark47(-190.51796868843937,-555.4820313115606,-100.0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark47(190.5605603486585,527.3570315944311,-100.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark47(-19.169818396766033,88.28253565222425,-40.64154518608021 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark47(19.39051222012725,-19.39051222012725,-40.191406241897376 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark47(-194.1427641582925,-557.8910280024921,-720.6320476690116 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark47(-194.23688389726544,-551.7631161027346,-3.6871354230222977 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark47(-1.9455811498895912,22.645707822454114,-709.4996254657344 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark47(19.47181767071622,30.186418096195098,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark47(196.09629172968224,521.1761810902924,-3.0000292511725988 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark47(19.711638949841515,46.97295061546532,38.18893031773098 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark47(-199.40548115135525,-529.5151936796113,85.39126394170319 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark47(199.5921872508231,511.03779397098714,-708.3013268074252 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark47(-201.9851723741325,-507.71222634734363,-708.8528452111582 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark47(204.14985178101483,520.703195119953,-21.588621267735874 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark47(-20.83815835712879,-55.51916978811593,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark47(-214.28986984783677,-501.7650296028787,2.678973177334697 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark47(-21.791521863126434,10.890177990391152,-717.5981818995256 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark47(-220.56834941890924,-511.2652030462081,-738.4934360218164 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark47(22.48602283185666,-96.97343417503592,-745.8135277723849 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark47(-22.561572843242587,36.34052196123724,729.7560440207906 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark47(-226.54987737543496,-558.1678035307378,-745.600487289561 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark47(22.816285043296958,-84.01335843462707,-745.997467799365 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark47(23.05822204171281,-83.75300664478466,-16.41935669912567 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark47(-231.21165700510113,-514.7883429948993,-715.1339362708143 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark47(-231.34257447439046,-505.94119431018396,-711.0956823723695 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark47(-23.144288426062165,23.14428842606216,-770.4364812150088 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark47(-234.9367590740428,-575.5890215070177,-38.863073917973054 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark47(23.60005474977423,-75.13629341215648,-738.7644646012004 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark47(-238.52046914140365,-507.4795308585964,-17.02249844172559 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark47(-238.73752138687658,-515.9395179389373,-21.07015175610192 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark47(-24.162038963364225,25.215348524114958,-732.6462414381101 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark47(-243.3329572242163,-500.5239063280006,-709.6185693834101 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark47(-246.05550585309663,-463.0752375198351,-709.5585668826134 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark47(24.72538376280366,-60.356737755298816,-36.23512508462352 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark47(25.2000610271161,-25.2000610271161,-1.494140625 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark47(-252.3126966333785,-469.953801348906,-39.193292829476164 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark47(257.0346102525868,504.9216033577413,-708.2137160920324 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark47(25.712610113175757,50.80556635572384,-745.3680795938499 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark47(-25.74934257755885,30.796767271533895,-796.9322733713467 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark47(26.07318665635299,-26.073186656352988,-754.664867779163 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark47(26.273867465972202,-78.01824374581341,20.99878117048148 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark47(265.2383260594199,460.48578549140757,-40.19140625 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark47(-265.3557192580039,-464.1945287266076,-66.96360868640801 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark47(-266.34569911138425,-511.38875563539114,-726.3907978570629 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark47(-267.25675077996254,-478.0167126640416,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark47(-267.90271875279933,-465.9236752467433,-713.8337706336159 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark47(-269.1485249417925,-441.166193962909,-709.2448599892348 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark47(-26.92196146902444,-30.350741183249113,-709.3876748554471 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark47(270.6783887148132,439.90586357211487,-709.5588268820902 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark47(-27.165718711715385,-62.43781872150429,49.185874894313514 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark47(-272.7056996969537,-472.31638185953204,-746.2949715810638 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark47(273.1461489480813,452.3651428536778,-709.3569393157939 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark47(-27.320944634884142,5.4454578308797466,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark47(-27.529720314046486,46.12673645992251,-723.717809207734 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark47(-275.396297793454,-480.8812874603138,-714.0219249367257 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark47(-275.93275699627094,-468.229337154845,720.356876758987 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark47(-281.3312180633086,-464.66878193669135,50.527101795500386 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark47(-281.8301695599205,-461.8751392872734,-709.9995171380091 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark47(28.361679322646324,39.6160125523179,-86.9522079494815 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark47(-283.82965960151006,-462.1703403984899,91.44720364100951 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark47(283.9237856213594,477.2891563100118,-716.0546888530627 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark47(-286.55299397573714,-433.4344768511893,1.7051557160630162E-16 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark47(-29.017372551062948,74.24185551230691,-1.494140625 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark47(-294.9833993059259,-429.7913970680106,0.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark47(-296.15701843352014,-451.33721084925014,8.881784197001252E-16 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark47(-300.4717250916191,-409.1172383633204,-14.734305934007438 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark47(-304.17911833020554,-459.53530987032167,-745.6121470629183 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark47(304.4396810822196,462.778743007121,727.4151206361014 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark47(3.048764722707631,33.36740054913585,-729.7405446500371 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark47(-305.6710570739949,-404.1087392368449,711.5266487485114 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark47(-306.62422860070683,-419.63911926430774,0.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark47(-308.4185403231995,-411.9920417280169,-709.3944222565091 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark47(-308.6160626475736,-400.5965576728665,-745.8954876364197 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark47(30.891958206317312,24.20363881814893,-40.19140625 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark47(31.013838299317456,96.94895991867395,-76.60312145281152 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark47(-310.37545098437124,-398.8890462052044,-754.2700456502032 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark47(31.079999941394334,-31.079999941850232,-709.3094207149366 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark47(-31.209244667598583,-72.22620289637838,726.2363951548815 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark47(312.31364007429386,429.27662090505385,3.0970857157226785E-5 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark47(3.1503955012707507,100.0,-1.2359354615029337 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark47(-31.512830152481865,31.51283015126931,-745.7038892569187 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark47(-317.04530765264315,-428.95469234755376,-746.23094767606 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark47(-319.08275806339884,-398.0343547188328,2.417174514616889 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark47(-320.1937443195195,-388.98449819137016,36.86723067126124 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark47(-322.15182912429884,-442.80688266823057,-84.28280107334453 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark47(-325.1805760174108,-384.81740045989693,-745.9712716201547 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark47(325.21125685607535,386.2630063692788,-736.5484123605115 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark47(-325.29737015411007,-384.3384402051056,-709.7298788075062 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark47(-3.257217206037069,-43.98585767046927,80.33260820938855 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark47(-327.39132517059346,-427.2200190756688,-726.1498117920154 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark47(-327.75667285706714,-429.4617801140349,-745.9999997372192 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark47(-328.7933789346074,-417.20662106539254,-139.23090502609728 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark47(-329.65047535224187,-414.65858754481053,-46.200337271796286 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark47(329.8737541921159,401.01437940152323,-709.4677426105667 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark47(-332.29740558575554,-415.01628157590784,62.287470715205814 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark47(-332.9241752640529,-391.18947439947374,-733.3300305225637 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark47(-33.372163803987405,-16.178415190867156,-710.0523998134927 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark47(-333.72363878637753,-385.36915628356655,-40.19140625 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark47(-334.89275411606155,-374.63659400680433,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark47(-336.0270745566411,-426.76655341782094,20.59688425814099 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark47(336.27963286622503,390.18149681577677,-709.7861517727841 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark47(-337.20982652249324,-473.85233260289624,-78.95316143963404 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark47(-337.46097271012275,-435.4998642522526,-40.071882306010934 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark47(-33.84693202206923,33.84693202206923,-39.20323694400297 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark47(-338.9897193339512,-391.44547613924027,-1.69880969317505E-14 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark47(342.232881264046,385.92360357851453,-774.4543873213648 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark47(-342.59916652722694,-417.39596884571574,-754.6946591170486 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark47(-346.5516066514643,-399.4483933485357,46.8925645826524 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark47(-347.36841109492013,-381.14307771790095,-1.4941406249999947 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark47(-34.77654931699503,-6.726178413972136,-709.9625272149484 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark47(-348.33347180348505,-363.95437725195336,-746.0000000000412 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark47(-34.95346286368353,42.962659170797394,81.38468987866219 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark47(350.56494140337634,360.69023859262467,-746.0000000026743 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark47(350.6559860151323,419.1622178413353,-709.757755318712 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark47(-351.2941295931041,-402.1353883583887,-732.6803102899985 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark47(-355.0774723531043,-356.3737388228634,-771.1212084350545 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark47(-357.5343566787714,-352.21900764874783,-709.5357797814141 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark47(-358.40624342517737,-383.6554643858048,-45.224589169166585 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark47(35.85188764055013,-97.53428703296908,-75.44400103458675 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark47(-358.5804559478717,-350.6253833562887,-754.2094305457632 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark47(-360.406036075516,-420.84666629792395,-712.9835439975514 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark47(-360.8508484660715,-366.98208331222065,-709.6111051146672 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark47(-361.08771302072836,-348.23145759900075,-748.2514412306193 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark47(36.4643979855128,-36.4643979855128,722.7711818729864 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark47(-365.55826394554174,-380.4417975767118,-749.7310612314125 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark47(-366.5444481479001,-343.110125715325,-40.030986199874064 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark47(-366.578053449006,-343.1741179451567,-744.9901461136445 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark47(-366.8863194329375,-346.2373215515111,41.826633122585946 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark47(-370.27055071108697,-375.729449288913,89.16083926405395 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark47(3.703332418351792,-88.31098982083891,50.40931745230927 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark47(-371.58288175927987,-347.7702756072175,-709.98653582595 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark47(372.2005614193725,444.35186343813905,-6.782052788823349E-15 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark47(373.0588054303393,389.101420825866,-743.2687966861037 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark47(373.8764488601112,343.6325303503173,-709.1796046687549 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark47(-374.46652723793966,-343.5085110466611,66.50033503090413 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark47(-375.02623513374124,-372.5865071808519,-709.8897854326967 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark47(-375.1528473387933,-367.7553207057914,-711.784668898908 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark47(375.2064774629987,341.7170953769225,-728.2199137792077 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark47(-377.18223889933904,-398.01465360715315,729.1722693265222 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark47(-378.2528648836094,-374.87117816208126,88.48294454899667 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark47(-382.9996056709134,-326.91560165680835,-724.5066640259653 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark47(-384.9378371766348,-324.91290737263745,-741.384948286683 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark47(385.3003804130551,377.5001859067015,-50.215151912196006 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark47(-386.6499022695371,-358.6383126079203,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark47(-386.6799806138783,-323.1645160574103,-745.9998788711728 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark47(-389.62788924284166,-319.6536596263367,-710.1989006353018 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark47(-389.8144199594944,-319.4659164962659,-722.0834770864569 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark47(-39.061616606522186,-6.119589748721719,0.0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark47(391.2906273299445,409.8396977205424,-40.11810783605968 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark47(-392.1890524513753,-370.7874397792136,-709.3374187321699 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark47(-39.30325261304584,39.30325261304584,-761.5199263341888 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark47(393.86840459485234,382.35635761533825,-709.9869377551704 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark47(395.80169165567025,314.75341792286326,100.0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark47(-39.70561399600094,2.4897052931800516,-745.8881841109755 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark47(-397.8974823032127,-354.3100187565285,-709.9716613101064 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark47(-398.7435467944263,-310.5000691174534,-0.013756716221070744 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark47(-402.1452718470199,-343.85472815298016,28.406628916287303 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark47(-402.68673229274975,-343.6131759120031,-733.4983499776123 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark47(-403.2504710727608,-305.91481228848045,-745.3621033352355 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark47(-403.646754929208,-341.40658077376855,-709.7299123487402 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark47(-404.0198975936994,-311.53365330355746,-25.308063522850176 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark47(407.72056856989377,351.3691214190601,-709.844677449249 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark47(-409.2494792419221,-301.9852392620966,-745.8303214000189 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark47(-410.7132850043573,-394.9514207373877,-40.19140624999999 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark47(-414.0046353431905,-295.5812891105678,-709.6025737989269 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark47(414.531535645772,318.30068040566573,0.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark47(414.730832213779,297.0231250787823,-709.9863783445863 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark47(-415.12594828628363,-294.2843590533574,771.6366971383352 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark47(416.4005270546569,306.05418367479444,-708.1615083292234 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark47(-417.78637522336567,-295.4725214402317,-721.6965584009425 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark47(-419.9878623588952,-295.46936946865264,-709.202804564834 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark47(42.015943179547136,100.0,-752.1542139291098 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark47(-423.22841653997045,-286.6653769903157,-32.4066075195704 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark47(-424.5787832049341,-285.1725363190154,-58.18725153925001 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark47(42.91215735976609,-42.91215735976609,-100.0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark47(-429.728583366408,-351.95687210470675,-728.508881639566 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark47(-429.93056255219057,-279.72888476720243,-44.141047542765534 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark47(-430.15226597364426,-296.1675750650467,-100.0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark47(-43.09388912758325,8.798096663794453,-40.19140625 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark47(-432.07192312204774,-277.43960968561913,-746.0000012376072 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark47(436.5372822565439,307.86301421477754,-1.0197338967712324 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark47(-438.76844354991647,-274.4865056096906,-730.5458460676335 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark47(44.008581898274386,-44.008581898274386,-39.30640358489947 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark47(-4.416174222882859,35.956833115608475,57.60123563976046 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark47(-443.031948416325,-310.6379191119121,-709.2532082635087 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark47(443.64173858747677,269.9422891730744,-709.4807818761449 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark47(44.58096968160862,-2.452240362050844,-93.56037402768571 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark47(-445.9500833193096,-263.0972816435226,-728.7962645162372 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark47(446.79432723405466,270.15690657694375,-704.7658251617188 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark47(-446.98556064343404,-409.01988236943754,-100.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark47(448.4063377096434,356.3154459400573,-47.62265367660876 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark47(448.5829750742989,268.4445116343402,-733.6848873111551 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark47(453.3517053931116,280.38801234383976,-713.9664561189051 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark47(-455.08714716608915,-254.06703987689377,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark47(456.6526698469288,257.4627478430723,100.0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark47(-457.04525964181875,-259.23807585380314,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark47(459.1670537271819,296.47456928438686,-709.4188272504031 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark47(-459.2278485229384,-250.3601610712304,-709.5686587694033 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark47(-459.273597035375,-249.97311870442707,-744.690169775702 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark47(-461.39787487976224,-285.80108109879086,100.0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark47(-462.6832792371696,-247.06445496997642,-40.19140625 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark47(-46.476747584131914,-2.5829010133663957,28.442292357889784 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark47(466.0783779830627,270.7996711186946,-100.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark47(-466.3827548324234,-243.03739213610288,100.0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark47(-467.9809525123223,-259.35820184879447,-709.5543741649719 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark47(46.88209339633258,0.3360538512700657,-6.051912873167481 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark47(46.931442806756905,-76.25451787488504,-814.9056891270667 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark47(-471.2157249304888,-275.3261662341075,-709.9082442159392 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark47(-471.43932867638574,-245.5119734541395,-85.31045457446591 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark47(-47.38787882842648,-81.37287955306005,-70.72526766249038 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark47(-479.27309599179705,-254.50748132095777,-1.2448207404745943 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark47(-480.05311730263054,-290.45628685409645,-1.0168067331476807 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark47(-484.51581705116894,-224.52648594269192,-709.8643265901671 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark47(-485.5622298896037,-260.43777011039623,-100.0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark47(-486.3360260242848,-228.27666570467835,-766.6650090264345 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark47(-48.69700359563545,48.69700359563539,-746.0605094836509 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark47(487.3023696892437,275.47630123434146,-731.5947261761241 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark47(-487.48102706190207,-258.5189729380979,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark47(4.882131697656874,77.26467013329975,-746.0000057305303 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark47(49.09337717801009,-87.20578779123072,-74.47329117464108 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark47(-495.8914752836131,-213.45096658977118,-718.2711008223918 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark47(-49.655174292491736,-85.61866650778018,-708.9639387440608 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark47(-503.211185469125,-205.95941079968958,-709.1530245811763 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark47(-503.86253256101054,-270.9139782154299,-1.494140625 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark47(-504.68850495804077,-260.60400812650516,63.259896526942725 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark47(-506.2773437250623,-203.68210164987514,-112.66808975880912 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark47(506.54265078383446,233.53332073055623,-709.688002284623 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark47(-507.43441603150296,-230.82993841328596,746.4933695997829 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark47(507.94334472551463,222.3145615350728,-744.7416850837598 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark47(-509.26078330696646,-237.47334017598928,-93.5131306939431 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark47(-510.21316663540875,-199.29631772523433,69.92309071623737 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark47(51.03314435590528,-67.285413465011,-790.5993967786592 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark47(51.04701818169449,90.35938429501373,0.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark47(-517.1550743284781,-192.39689512354659,-802.2480742458719 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark47(-518.3660433230174,-191.21970104115823,-86.88675603732545 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark47(-51.88441801751582,-82.4658314040121,-79.32574285467393 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark47(51.90416341478658,81.13279711041181,-17.25188374352568 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark47(-521.72600243857,-219.07970555262048,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark47(-528.7713359625222,-219.2477442639301,-709.092987643618 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark47(53.063442718825996,-62.052382200821164,95.10096160414389 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark47(-53.068955582918285,23.645740769597708,-710.6724962390375 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark47(-532.400519176327,-213.59948074871522,-709.982184498062 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark47(53.26161619304511,-53.26161619304511,0.0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark47(-53.322468883687144,61.47586658427497,-745.6703750700558 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark47(-534.868903377343,-247.04488021120568,-709.9725680269064 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark47(-535.5058907379334,-186.6268114470118,-736.2371899879295 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark47(-538.1964271880543,-184.86234189914643,-709.1382840093394 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark47(-53.88547832165458,-16.501561163983876,0.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark47(-53.97393517630364,-33.57483099569288,17.92697593385519 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark47(-545.1781101430047,-280.60210437113693,-709.0414045478287 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark47(54.64053707233529,-99.60272620741728,-745.3504337206568 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark47(54.64379691213864,-72.27593190415378,35.76230608561994 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark47(-547.6346997360436,-161.58284345306544,-709.3463263421847 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark47(-548.1709104021909,-182.259661688324,-749.1157842597796 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark47(549.0842999098163,226.62730124540667,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark47(55.262637807608115,-95.45404405760812,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark47(55.34323424566436,-55.34323424566436,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark47(555.9719048945627,215.67872939376358,-741.5637508940501 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark47(-556.4949782593283,-189.50502174050618,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark47(-56.04366036331781,-689.9563396366821,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark47(-561.0155159712868,-249.81159332317657,-709.6340405418343 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark47(-561.3294151964988,-147.71733632187818,-709.0348109722909 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark47(561.7961421254337,336.463095241111,-1.4941214117655417 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark47(56.334035299516586,-59.00147360113619,-744.8910265817133 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark47(-56.519220543779646,-13.222431511133152,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark47(-572.967544799266,-146.9350145096808,-745.7288672262586 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark47(-575.1097772669144,-140.27506548709027,-745.9418913138892 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark47(-578.4786506280028,-131.5168684482462,-709.9988084178333 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark47(-581.2367250759331,-164.7632749240669,-4.359653326550699 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark47(-585.0114793431743,-135.37170516306,-709.695370391528 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark47(59.02634959934077,-59.02634959934077,-40.19140625 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark47(-591.3270407569961,-136.5268743229654,-709.8917495988607 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark47(-594.9241348181366,-114.4101769908833,3.093713905383467 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark47(-59.53798521159881,-46.58918380516142,33.663983282804 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark47(-598.9117277220384,-147.08827227796152,-0.005992130446877297 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark47(-602.6082768639816,-150.56821290909514,-745.4594997566586 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark47(60.828609934191235,95.99683070347064,-97.24685178128136 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark47(-60.97978119576653,-57.93638025032717,3.7976213773471983 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark47(-609.8508393446665,-99.72707010094561,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark47(-61.040437449984154,43.654737219883344,-13.623545189599383 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark47(-615.4631964281292,-94.5368032942121,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark47(-62.1747255966296,62.1747255966296,23.559209250998038 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark47(-628.4468803266817,-81.11100958841483,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark47(-63.428301137028406,41.052074768371114,-745.2782544593855 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark47(63.519756394887,86.56150962330545,93.4517421059198 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark47(63.63455718988246,50.736984117718634,-714.3056765425883 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark47(-63.88539235587423,63.88539235587423,0.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark47(640.0289542514083,100.0,52.58527273891315 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark47(-640.8142416451544,-105.18575835484558,-99.21011245773718 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark47(-643.1359252359428,-66.86407472053146,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark47(-64.32265767256087,-94.44741157668102,-734.5763972055681 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark47(-64.51769110734921,64.51769110734921,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark47(-646.0,-100.0,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark47(-646.1992828554077,-99.99212345710022,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark47(-64.91248494370251,17.280102962717073,-1.212636433880258 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark47(65.33323580844481,44.95215412707577,66.49546422172193 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark47(-65.68301737872187,59.36587337626469,-0.990634172095767 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark47(-658.6410665233882,-50.54858759277132,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark47(-671.0143390957775,-92.77204098117156,-45.51345075467539 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark47(-675.8659241800713,-100.0,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark47(-67.68907756782644,67.68907756782644,732.5788748232869 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark47(-69.23313650634137,-640.439220868036,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark47(-698.2847958650796,-47.7152041374292,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark47(-70.2519116655895,70.2519116655895,0.0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark47(-71.57406405455743,-67.1810871257855,-721.5716596163652 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark47(72.13021186928754,-72.13021186928754,-746.0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark47(-72.28863342312813,-673.7113665768719,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark47(-72.3182131595524,61.08430353130947,-22.07931777728743 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark47(-72.85949124044684,-37.6991740522153,-709.260590617168 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark47(73.46075625092611,100.0,-717.3436235852315 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark47(-73.55893668239648,33.367530432396485,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark47(-73.77728929523843,-39.53440219605309,-709.9725474418054 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark47(-74.00683978693431,-70.01214117510514,0.0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark47(-74.76969916383412,-31.05062380418757,-40.19140625 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark47(-74.84768683573728,34.656280585737285,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark47(-7.497855337428632,-84.41793277429443,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark47(75.13734746528861,-76.63148809028861,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark47(-75.6603475993628,-80.61312863988414,-5.211166191625452 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark47(-76.19432388765296,76.19432388765296,8.391917603963646 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark47(7.667972209134533,-7.667972209134533,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark47(77.34283702525718,84.90618923035825,-745.9971038334738 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark47(-77.48646695774829,77.48646695774829,-1.3935248203108497 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark47(-77.8495853249141,74.33478053128962,0.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark47(78.11854803788316,-16.74695790536566,-44.38590603289252 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark47(-78.38479169297298,13.811832650909125,-1.2766468492406204 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark47(-78.52802113575754,-667.4719788642425,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark47(-79.67493138039924,-52.750704699450445,70.57627878334623 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark47(-80.0780252183059,31.10422873385977,-58.049762355493215 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark47(-83.4017154567644,83.4017154567644,-744.3517240310482 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark47(-83.52238286591201,82.5426758026334,0.0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark47(83.77863035769792,85.30548765128515,84.0943797557583 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark47(-83.90976859616241,-63.58541552269095,0.0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark47(83.96391855278564,8.811893169823316,0.0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark47(84.02471939374351,59.60308531876322,750.2194087263881 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark47(8.433767771435726,3.2375282343439267,18.573172973568575 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark47(84.57712640785988,-88.00102064359928,-40.02327296833329 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark47(86.95026036874319,45.655786824263316,73.13795978713091 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark47(87.5145422287803,-73.29898806387632,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark47(-87.89374503023652,47.70233878023652,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark47(-8.90453459235772,26.465172708406357,-709.1768701313766 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark47(89.2718841040411,45.28048226741646,-734.8800808445299 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark47(89.99345595677553,27.41944789102517,0.0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark47(-90.79224277006286,-92.86016174567395,-5.345276835866827 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark47(-91.16571735500857,-618.8342298270425,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark47(-91.75625889100571,84.18310172796217,-765.8288988858285 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark47(-92.03954188234651,-34.79367682952382,-737.6895357713137 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark47(-93.48535179261997,-616.5006483054393,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark47(-94.04651017842245,100.0,-709.7722963954061 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark47(94.39780028754708,-31.51884088256635,-25.01861347291252 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark47(94.77419630507399,17.767201369180114,-709.606342184346 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark47(-97.0043978380027,-644.993153335931,-100.0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark47(97.12284106948805,-100.0,-709.8045315260151 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark47(-97.26915241450362,-612.3612756369333,-69.41321958640198 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark47(-97.93006833692799,-648.069931663072,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark47(9.868429598349188,-9.868429598349188,5.7661873481025925 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark47(-99.56885435134213,-45.79978290037596,-708.5834550490532 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark47(-99.58087545428779,63.74751194124485,-21.6444008421349 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark47(9.997766916660012,56.31782928376521,-717.0424913138659 ) ;
  }
}
