import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.0015090068678849794,-0.06089105823916044 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.00246347017555304,-1.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.010079421583479367,-0.6908416289210108 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.01680588148138895,-1.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.018305287116655578,1.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.024671086847775806,1.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.03044651729272248,1.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.06886777955596313,-0.04006283927402708 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.07579835488112133,-1.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.10467437263554302,-0.0537988677145933 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.10963993097207703,0.03639851014638955 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.11379777850445405,1.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.1267234006839279,-1.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.147075422100959,-0.8662010495384806 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.14887510888362468,1.734723475976807E-18 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.1715932365265787,0.7819316408650869 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.18512761101253758,1.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.20336491660044909,0.9480998023255759 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.22839394422483325,-1.0000000021731867 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.230263525696065,-58.67383723545461 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.24523985560631445,-1.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.2577611050481181,-2417.2808163212258 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.27818136042755137,1.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.29123199008804934,-47.037879487808375 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.29589452481583023,0.6270397325626171 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.3049423628700173,-0.9999999999999981 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.3182959313380215,-1.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.3200805693219868,24.88126247081574 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.3268110795448271,15.957764323876276 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.33595137776264217,2239.3388196538135 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark52(0,-0.036694807442614774,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.37857017354187406,-1.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.38410738024802504,-52.740988403556265 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.38867765206035076,-22.47013236935271 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.39078327146379604,-91.34419458265842 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.391843972092645,-1.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.4054548867132479,55.16098228543778 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.4314523962558796,0.9156149617173821 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.44336386092356106,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.4584402394642937,30.61188300656211 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.467566584042143,0.9994415800840936 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.49506046330797915,-44.542824139414925 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.49880815665994405,-93.58172882166882 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.4997088879169018,-78.26719172128871 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5036476076227037,44.37678954926622 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5262025318396044,-0.17435892710354575 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5441140390333853,1.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.554106668185906,0.9059640121785488 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.5764262472297911,0.4662530804227031 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6116229209140217,1.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6275158018796373,0.7954969043421997 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6553127242189176,-1.0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6622213923528376,-0.9803594739698523 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6812718512054702,8.328620636992267E-17 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.6879742009519988,-1.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.7255104822365006,-1.0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.7401472218419514,-0.8457249822221274 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.7486966974811495,1.0000000000002016 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark52(0.007614226429993209,-1.2299451677722288,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.7827843944686961,6.776263578034403E-21 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.7927740104699047,-0.13043432492150941 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.8089408071170873,-0.6010314334594555 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.8185216579740714,-1.000000005903445 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.8886390151796117,-1.000000000000007 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.8892067721162716,-2318.415201319764 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9027757443227724,0.06044493649944614 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9153225091506642,0.9875145711265033 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9308461849414276,-0.17714456668582368 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-0.9740437118462048,-1.0000000000000002 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0082743402880257,-75.02015429788993 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0324010320975958,0.9741452832542657 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0501177417788075,-0.6636304685062144 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.0627303432914204,96.51541913139408 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.085175754135323,100.0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.1031955173232766,1.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.1189744442024192,0.9379770731815222 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.1600232354616962,69.10525796790398 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.1640046754903057,-100.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.1717452345038595,-0.9851143855400684 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.1933822809455847,0.015428859955710847 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.1969372289330154,1.0000012076180183 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.226081100787269,17.34317007296479 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.2831915971514471,-28.50452392374532 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.303488552281804,30.234920037425756 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3090587735851962,0.5781457186494166 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.329182268270717,-17.59531238708392 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3449472621226024,1.2634920662350609E-175 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3493245037925519,40.662519983667465 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3513820959470202,0.9999999999994297 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3543117017291755,-8.324989663719589E-258 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3835145978876877,-7.742096478425098 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.3899058758989518,0.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4074815324814793,1.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4234075041889207,-25.848711667747345 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark52(0,-0.14242560284462025,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4424506533357973,-0.4226155543508032 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4509024676091289,-1.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4514777221701427,1.0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4537934851583199,-0.8460467897354835 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4614870642522815,64.42185396723491 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4633127032912965,0.06255259219294809 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4642068932903927,1.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4657334019663912,-1.0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4793699227985542,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4821975048163711,-0.0475940997298612 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4864964484398004,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4922429368095131,-0.06255258977680539 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.49318292122768,1.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999730783509069,0.9978971604554866 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999992403906846,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999398544541,57.92446917762076 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999995667777,-1.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999998643068,-0.006345082473110518 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999083098,1.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999954043,6.8030983511269545 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.499999999999993,1.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999987,-20.85522574377605 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999996,-23.031594684893268 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999996,70.13051884466982 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.4999999999999998,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.58E-322,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.6249892766531608E-16,0.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.7763568394002505E-15,64.88829030598515 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.999901510702706E-9,-0.49660740759562016 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark52(0,-0.20305535749875325,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark52(0.02094910412957316,-0.778265263964567,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark52(0,-0.2662956054000176,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark52(0.0,2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark52(0,-0.29886228924659597,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-3.2581633124488328E-15,-1.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark52(0.03735629656622036,-1.304155645987266,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark52(0.04519780780440438,-0.4916869212797934,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark52(0.04567699952636198,-2.537128877163662E-5,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-5.177341062923513E-6,0.04418867736731876 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-6.208885579616028E-16,1.0000000000000004 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-6.397368599581827E-10,-1.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark52(0,-0.6916918255123363,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-8.574610379473332E-4,-1.000000036973591 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-8.7289360978111E-9,1462.4202405255526 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-8.881784197001252E-16,100.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-8.881784197001252E-16,-16.44168977381944 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark52(0.10702614529463339,-0.01924381895189131,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark52(0,1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark52(0.11452589387683698,-0.08023838214842402,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark52(-0.11867399028956527,-0.15640324822980012,-92.12685907731574 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark52(0.14521162010710895,-0.6581339507243392,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5000000000000004,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark52(0.1537964035266448,-0.9213751452920036,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark52(0,1.6196594832738498,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark52(0.18563204401216638,-1.0098223339825396,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark52(0,19.931216878743044,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark52(0.21370059021546695,-0.9443785578147725,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark52(0,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark52(0.22989710800719831,-0.8014728479369247,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark52(0.2374284043665824,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark52(0,-24.87922529172198,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark52(0,-2628.1489856081093,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark52(-0.2647443663130247,-1.7763568394002505E-15,24.391551144432455 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark52(0.26680426529159224,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark52(0,-2733.7861714098176,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark52(0,-29.12585776203551,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark52(0.3005047459555654,-0.8777737314797394,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark52(0.30943628780413945,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark52(0,-35.06134016373056,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark52(0.3600656881845027,-0.06346401189235074,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark52(0.387773452846929,-0.9412363080168742,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark52(0.4094241392226811,-0.34408833523281873,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark52(0,-4.243991582E-314,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark52(0,-42.999538782008194,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark52(0.44196883220315897,-1.338084489023705,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark52(0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark52(0.4528563353665698,-1.220024044786807,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark52(0.4582303640520058,-1.4999998363729603,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark52(0,-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark52(0.49379056875726235,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark52(0,-5.070418146500714,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark52(0.5123481715211722,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark52(0,-5.570381800084604,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark52(0.6103217874917062,-0.795512836478105,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark52(0,-63.187297936555574,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark52(0,-64.20267962557287,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark52(0.661185069574061,-1.956561591451446E-8,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark52(0.6658124941489234,-1.468490039896908,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark52(0,-68.43714491761246,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark52(0.6895251237935804,-1.4999999899487073,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark52(0,6.938893903907228E-18,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark52(0.7191489393354971,-0.8868579868140706,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark52(0.7287235855184804,-0.3547609340435727,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark52(0.738158781784719,-0.5717777345553259,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark52(0.8173904476160394,-0.06122472533536227,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark52(0,84.00244698881295,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark52(0.8439649400300295,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark52(0.8468122439206525,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark52(0.8480444297043448,-1.0100734686973372,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark52(0.8672761661475619,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark52(0.8851772491316439,-0.019525681980938046,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark52(0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark52(0,-89.71873041449533,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark52(0.9385320268211288,-0.3816398887961052,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark52(0.9470037886344755,-0.3452880726068486,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.0020492635308460017,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.0046397407553081344,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.004791309467343326,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.006609486963740693,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.008719407218106125,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.03340532920579914,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.040229573817451736,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.04433019501371216,-0.8111207046028722 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.04709783195945516,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.05460409089949625,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.06970981764339812,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.07825315302658588,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.08938985849719394,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.09268712336899942,1.0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.09430871296278687,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.1113247949137095,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.11949137811427833,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.12223171113945963,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.14014405300723926,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.14197185180894023,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.16619912750500798,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.17840893239175826,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.183662160508551,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.20024394706555748,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.20407283643362495,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2149023572654637,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.21802760919618258,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.22704978306809553,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.23818343841394432,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2670052078505546,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2755331392321776,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.28101716084974204,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2885557653804258,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.2898691460563261,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.3015137275838029,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.32502156970210755,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.4040005917138978,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.41034442207004884,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.4119614041660191,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.42822788886121277,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.43583691047194495,0.0626134853836358 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.43870044720009477,-4.0389678347315804E-28 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.4482857025518554,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.44985868570984167,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.4714661028648845,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.4983459262972161,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.5010258220965467,21.90922557200223 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.5086401015915601,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.5191089382130067,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.5232596723420616,-0.9801222892611678 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.5406057779665643,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.5546939745350546,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.556200350138504,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.5675666558229739,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.613295198491898,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6418469147701107,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6854987646677212,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.6886459050250212,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7004859999428171,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7110037689015014,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7233436902735603,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7348343144602136,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.7420646663440867,100.0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.751988569840776,0.9999999999999996 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7551222153380186,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.7849580804154686,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.8080917136547453,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.8187985924994461,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.8826666766445713,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-0.883068293922177,0.944408804489395 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9283723490142004,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9421913855567337,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.949570593338332,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9676182916145482,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-0.9703610919964714,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.003736661766066,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0392266128237435,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0393422583649266,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0436067147876882,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0446248949965184,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.048009194687485,-11.418020059792541 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0511218750189868,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0512456503815024,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0666468399456717,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.0937603642408789,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.1067937475256677,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.2006737954380498,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.201158626108915,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.2071185950911087,-0.9999999999999982 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.233532681665996,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.2397425525051495,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.2433334395649749,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.249683172658432,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.2876947600624438,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.3320227689746398,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.3428285264709399,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.3864294010825915,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.3866762199473999,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.390097289922253,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4330484117848306,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4458552572439802,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.499999999045534,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.4999999999745217,0.5199293117233585 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999993336,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999662,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999822,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999938,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5816520280489647E-6,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.6456856650351274E-7,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.8134800419793512E-4,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.039270939519441E-5,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-2.189216141283492E-7,1.000000083079866 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-2.2119786224694107E-6,47.02072740257462 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.3506414892280044E-6,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.669813882721831E-7,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.69266553267223E-6,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-2.904654155202636E-4,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-3.106659652915821E-7,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-3.319846957095639E-8,-100.0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-3.866653181758658E-7,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-4.4279051124852606E-16,-1.8084745567372096 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-5.897970764309844E-9,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-6.911202922505643E-8,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-7.171977551998929E-9,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-7.52347467255744E-8,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-7.790963815165174E-5,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-7.95336694200142E-9,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-8.54369657474086E-9,0.9999999977778146 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-9.640892287398922E-8,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark52(1.0015045126775766,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark52(10.04498731542776,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark52(10.05733121962069,-1.4999999998911537,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark52(10.079897555109113,-0.5863040867309479,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark52(10.085899532935613,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark52(10.095351866081238,-1.320804786116577,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark52(10.151228785508211,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark52(10.162846110880022,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark52(10.197838207502972,-2.300625953611517E-9,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark52(10.314102086742789,-0.8349417891762095,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark52(10.327459444245083,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark52(1.0372583408606602,-0.8605351223599769,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark52(10.396930489743369,-1.9981974756688998E-5,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark52(-10.42549029262507,-1.4999999999999996,-1.0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark52(1.0478758831512271,-0.6828446774058374,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark52(10.498206046245471,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark52(10.548489609812918,-1.499999999999984,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark52(10.548631176151432,-1.3398013553195272,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark52(10.704480364519114,-1.4074688594918676,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark52(10.771028957676236,-0.8388996029102804,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark52(10.77195355960067,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark52(10.779933166964469,-0.16717362959002993,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark52(10.792281857601896,-0.689639899219074,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark52(1.0806635166501914,-0.2639285890311447,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark52(10.851820449425169,-0.726475410373979,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark52(-10.89269473192723,-1.4592730252870656,-0.04590649491622723 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark52(10.91708201656283,-1.4999999999601863,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark52(11.028665485842053,-0.3172025018413396,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark52(-1.1102230246251565E-16,-0.5506349320003688,-73.9312052648465 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark52(11.11227129181617,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark52(1.1120114085960466,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark52(11.124618312819393,-0.03303770710564724,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark52(11.18739225404469,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark52(11.20589642469509,-0.06354957212527601,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark52(-11.21627555664881,-0.829153750888409,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark52(11.231265908034644,-1.3776156340590888,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark52(11.261332261680806,-1.3732341586131867,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark52(11.262154848398282,-1.3993856326022467,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark52(11.273137586683475,-0.8284037462219587,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark52(11.282038750110331,-0.4136222045088238,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark52(11.297030731486288,-0.0528145148150166,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark52(11.312980319267993,-1.3591308111146327,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark52(11.339578007138826,-0.1175057414319165,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark52(11.39971460052125,-1.499999999901494,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark52(11.428326077135118,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark52(11.464628297788828,-1.0302475561420184,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark52(-11.470820494896637,-1.4113308577635593,-1.0000000000000002 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark52(11.500372110536887,-1.321679222693021,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark52(1.1513703022019826,-0.22430057772747214,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark52(1.1538135420691873,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark52(1.1553244005534909E-274,-5.510243865083486E-7,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark52(11.627208118738192,-1.3087856869048176E-7,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark52(-11.641614049885533,-1.332789601757475,34.315206710183276 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark52(11.701435369797778,-0.8987762939235653,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark52(11.702447707796352,-0.9747358967398583,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark52(11.783280523120647,-1.114973325844074,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark52(11.804850877027405,-0.12426085081084182,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark52(11.841346292859198,-0.05535636188988424,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark52(11.920080968229641,-1.4999972933623154,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark52(11.922833932840703,-0.9527118754981148,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark52(11.953688192775761,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark52(11.96306229893284,-0.3455762534295035,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark52(1.1971414764534654,-0.051009181581197174,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark52(12.003651566457904,-0.18600600938344325,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark52(12.050637642110516,-1.4496901567962492,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark52(12.120828719057286,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark52(12.135972477921015,-1.4279691758884396,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark52(1.2150264248330904,-3.448953842501945E-9,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark52(1.2213611708432666,-0.5346068782853024,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark52(-1.2245886903930738,-6.077845381446414E-10,0.9564484395673115 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark52(12.251826333626113,-0.8232889490561726,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark52(12.2751392947026,-1.4505496372488482,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark52(12.306769598421045,-0.2822741936526705,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark52(1.232595164407831E-32,-0.29784072666143024,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark52(12.326576168056121,-0.6835321360242437,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark52(12.358695722927266,-1.2159460583008963,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark52(12.361188378713223,-1.0908534878865639,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark52(12.37406214651613,-0.1203342360651849,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark52(12.376833736965189,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark52(-12.390103921219644,-2.3780964111616565E-4,0.9999999999999999 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark52(12.410327115707972,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark52(12.435680780018373,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark52(12.528248952135002,-0.642100102875677,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark52(12.62366500750774,-0.889494087110339,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark52(12.694781267665126,-8.82268848899443E-9,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark52(1.2716995609126176,-4.70498267457692E-9,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark52(12.735688156906349,-0.390737825621446,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark52(12.744480705383054,-1.3250603167453683,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark52(12.81508983535132,-1.1126010065714524,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark52(12.826298460611767,-0.41054087290226704,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark52(12.827215523397399,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark52(1.2842687733970308,-0.5143306687651419,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark52(12.918477484318116,-0.9744517153483907,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark52(12.921593256488134,-9.52512194139755E-7,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark52(12.958638687415732,-1.4999389640723104,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark52(12.96393292582956,-2.123799169960352E-9,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark52(12.968722898703742,-0.7577686920839959,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark52(12.998986098436333,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark52(13.004608762087017,-1.3229708247619083,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark52(-1.3016180878718817,-0.33758640474546553,1.0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark52(13.038074413168333,-1.4999971395208167,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark52(13.044971774929778,-1.0572001088598229,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark52(13.148542463578778,-0.4948184307193486,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark52(13.18257371336054,-0.8720913963824254,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark52(13.209636113389564,-0.3596254928456126,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark52(13.228594685173007,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark52(1.3231024887020908,-0.32271312945254194,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark52(13.394436174681033,-0.9131592970615028,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark52(13.449215133037853,-0.5806452909711766,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark52(13.449264215031675,-0.14724756137916944,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark52(13.526419647846467,-0.0671682954577788,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark52(13.595827921174454,-1.499999999928081,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark52(13.607786675839106,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark52(13.637938495661608,-4.305390827047215E-9,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark52(13.64504242801057,-0.04221204977612558,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark52(13.661011244678093,-0.44754476015671685,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark52(13.661344449004453,-1.2581170644175853E-9,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark52(13.684103140912823,-1.497691696638261,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark52(13.70914802310375,-0.47528171978912326,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark52(-13.732366066406184,-3.552713678800501E-15,-23.054999586720122 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark52(13.752979706034381,-1.0246558846020948,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark52(1.3755696960673973,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark52(13.82953219538472,-0.6429504996131106,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark52(13.839906569602519,-0.6438185572925788,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark52(13.851576131234864,-0.9231798295665623,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark52(13.876213035150785,-3.945770916248025E-9,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark52(1.3877787807814457E-17,-1.4953636692617152,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark52(13.92501113886702,-0.8228968697633565,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark52(13.932027961528732,-0.38233217593430185,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark52(13.938359592336191,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark52(13.967982454197271,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark52(13.97158249305565,-1.4999999999999822,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark52(14.009943063584956,-0.14783397441653712,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark52(1.4047197018650195,-0.11742151376226784,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark52(14.11789183899532,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark52(14.117943752475732,-0.4535339762787203,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark52(14.122738580822315,-1.2719029105085415,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark52(14.132105659429094,-0.07323397060864334,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark52(14.137486976365409,-0.5106910141439865,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark52(1.415656481109779,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark52(1.4210854715202004E-14,-0.08564441074893248,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark52(14.287401843227464,-2.5429050061851E-4,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark52(14.304024235777277,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark52(14.33020910427733,-0.3029109236628831,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark52(14.335841624716906,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark52(1.4360750944691176,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark52(14.42557008653323,-1.3005469640996141,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark52(14.440217936289514,-0.9717010990102182,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark52(14.528094721439675,-0.07179838256055904,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark52(14.534108126493209,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark52(14.5383745467676,-0.32976060454141987,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark52(14.574637351219422,-1.361955420391891,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark52(-146.05983602423325,-0.04369563703363777,12.206133696963422 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark52(-14.6093539167679,-1.4999999999999998,0.9563301686645981 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark52(14.631520906140054,-0.3719797337763424,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark52(14.643785785635995,-6.574727980873194E-10,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark52(14.662150350399543,-0.6586928036254223,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark52(14.681142718262308,-1.4666957603147555,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark52(14.684409921936215,-1.2593156838589624E-5,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark52(14.718182903512613,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark52(1.4720204412827709,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark52(14.721146895065843,-0.9384280891527936,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark52(14.776644478166027,-0.5551933989033784,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark52(14.817276476028377,-4.111513985903548E-8,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark52(14.829857994039063,-0.0835601559210124,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark52(14.872658397914222,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark52(14.898752944724777,-0.09548973476725475,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark52(14.9205666095913,-6.300988376418127E-10,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark52(14.944022691148156,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark52(15.045156016833383,-2.1015670403174854E-9,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark52(-15.114736836181537,-4.3282304753139394E-5,-1.0002146116994013 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark52(15.16032865404944,-0.5758168680107926,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark52(15.23401760797853,-0.5239295691833696,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark52(-15.255313811431563,-0.1495148704684004,1.0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark52(15.259973685219876,-0.08042469470222213,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark52(15.270653306046952,-1.456701317666952,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark52(-15.279060348745446,-0.10919978795206828,-28.704442742571715 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark52(15.295598732840517,-0.09102311998132961,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark52(15.392004183008964,-0.10233138531370578,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark52(15.395698395388365,-1.4410244171820992,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark52(15.477147904882926,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark52(1.5480492002608202,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark52(15.490180237217047,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark52(15.502347686158156,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark52(15.512576346376274,-0.11939239807005418,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark52(15.551931587433046,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark52(15.685928508264581,-1.499999999999984,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark52(15.758317675829828,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark52(15.77386500108577,-0.7666228194606275,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark52(1.584185433370891E-16,-0.06367092521813772,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark52(15.841910079731633,-0.29325045930794325,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark52(-1.585938843266242,-0.5419464666610032,-7.862920633975446E-8 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark52(15.905935573787772,-0.7234009623290747,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark52(15.917442347028327,-0.741836626668757,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark52(15.927850545214557,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark52(15.955751733833418,-5.891542061719715E-8,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark52(16.04150595223791,-1.4784743335256714,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark52(16.043530880914894,-9.864819481055567E-6,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark52(1.6058175152137615,-0.41465198983190343,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark52(16.068621551889404,-2.1192266825313715E-16,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark52(16.12548685988961,-0.15685088261538926,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark52(16.14279897971747,-0.47147446633257406,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark52(16.145411713743925,-0.021801735525311727,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark52(16.228464631506185,-0.21508599926973815,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark52(16.262513636811477,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark52(16.29496821883727,-0.7529567610538876,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark52(16.396457827825998,-0.49148411348483023,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark52(16.406949125318953,-0.42259698940573553,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark52(-16.40736347165396,-1.4999999773856318,0.8046783996998546 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark52(16.408772845792498,-1.4583607539046453,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark52(16.465796438306423,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark52(16.55388489813737,-0.5112915247188914,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark52(16.554721898369976,-0.01975897374898139,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark52(16.56371404411587,-0.0198763119525438,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark52(16.566384935482354,-1.4182399106588974,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark52(16.589705618749967,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark52(16.60068720029156,-0.5394283282832548,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark52(16.614563561825744,-1.657739801043854E-7,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark52(16.61774504362556,-1.3476518390746524,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark52(1.6731603876197596,-1.076047722771886,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark52(16.762920805796547,-0.8452641982488034,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark52(16.774592303358602,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark52(16.78289313038877,-0.8160390174961729,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark52(1.6792042084780263,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark52(16.79935064917737,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark52(16.894825457810455,-0.15020635192063492,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark52(16.90430311885554,-0.08330278720003978,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark52(16.90562122962265,-2.212464706844224E-7,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark52(16.942689456660016,-0.252973413553371,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark52(1.696055577786467,40.794173129869876,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark52(17.052561011366823,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark52(17.05374394757024,-0.829019181376836,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark52(17.23391215480781,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark52(17.244883104418882,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark52(17.315706563989284,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark52(17.32345880630939,-0.5136014326217833,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark52(17.32937167385056,-0.5914898187905199,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark52(1.7408413014605855,-1.4590540529263518,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark52(17.51763108839978,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark52(1.7537309310109102,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark52(17.679056183399595,-0.9983061282154049,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark52(17.70043865865322,-1.4996924611471119,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark52(17.712590156440893,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark52(1.7763568394002505E-15,-0.3836993084354483,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark52(-1.7763568394002505E-15,-1.0666192839147879,1.0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark52(1.7763568394002505E-15,-1.2115867175801953,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark52(1.7763568394002505E-15,-1.2133543215158937,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark52(1.7763568394002505E-15,-1.4901561039452815,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark52(1.7763568394002505E-15,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark52(17.824666214070433,-1.396851971799535,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark52(1.7843034853776558,-0.8398229186051712,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark52(17.854179741809702,-0.47431510953892797,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark52(17.886133791772323,-0.8881272796851079,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark52(17.899148024817624,-0.7960691033551905,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark52(17.910440553340592,-0.02214129763389394,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark52(17.949888990978863,-0.810951705336211,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark52(17.953148012701533,-5.964037583019963E-4,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark52(17.974426042064607,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark52(17.9965224400775,-1.4999999999999378,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark52(18.003184529170696,-0.1523300950363371,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark52(18.04120733677621,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark52(18.050534594501716,-2.7401697977507413E-8,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark52(18.108854553705456,-0.4149836370819704,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark52(18.118699255007883,-0.06133235022099992,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark52(-18.12402495170626,-1.4456138813507577,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark52(18.221910073770033,-0.023724968034912308,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark52(18.29336391685213,-0.6238869905618794,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark52(1.8378335619922268,-5.32348689157359E-7,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark52(18.402779182218637,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark52(18.404419172489654,-0.37661488126876463,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark52(18.40613837754661,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark52(18.488277211334264,-0.13183689982762736,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark52(1.8520199769730397,-0.16358774761850725,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark52(18.522448525017154,-0.6783331569337046,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark52(-18.56226211131707,-0.9527344205978473,-1.0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark52(18.562451970375022,-0.28052987072244207,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark52(18.70096494056564,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark52(18.701613523156453,-0.5650052632269791,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark52(-18.703365073109687,-1.4999999999999996,1.0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark52(18.755856041307254,-1.3616506319098045,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark52(1.8786436038675305,-0.51673157087113,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark52(-18.82596038830639,-0.034158073720650606,-0.7511753679122593 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark52(18.837528983698377,-1.2010318528080361,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark52(18.8447879940283,-0.9265293778840211,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark52(18.855980641724297,-1.2711022590514807,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark52(18.85876483004713,-0.015091228757800113,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark52(18.883639139032525,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark52(18.905964229386555,-1.2620325122051415,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark52(18.94814139064877,-0.419574545120204,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark52(-18.99070629737929,-67.4006422619465,30.012242717732562 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark52(18.998694939429168,-0.8608232217360188,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark52(-19.08411912543171,-0.8503794086376653,-78.88906901480365 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark52(19.08694361331642,-1.3523983606877366,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark52(19.087756498837607,-1.2046262516906836,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark52(19.096386001806096,-0.34026359188948163,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark52(1.9111665758840872,-0.0025726231313352166,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark52(19.195804763123846,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark52(19.2706545453037,-0.6678635354656159,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark52(19.317495106634297,-0.8311452416207095,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark52(1.9317922413664803,-0.06023151700132712,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark52(19.36201066827728,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark52(19.417857122538166,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark52(19.43762421268596,-1.4536217669879257,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark52(19.470654918374436,-0.13988865610046863,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark52(19.521221052660877,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark52(19.522961208811527,-1.3378596172078652,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark52(19.52374060114244,-0.5386078637085472,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark52(19.563175184169854,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark52(19.657163199989,-1.4966372370360566,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark52(19.66522421659505,-0.997340965878788,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark52(19.709991940459332,-0.9574820917684042,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark52(-1.9721522630525295E-31,-0.06357896056838944,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark52(-1.9721522630525295E-31,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark52(19.739124055599262,-1.2922031942522767,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark52(19.764085831202326,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark52(19.929750603546452,-0.2201768844147356,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark52(19.936388347445913,-1.0022082916274897,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark52(19.96599608662703,-0.767272625352216,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark52(1.9969458903345867,-0.05742205732042294,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark52(19.980452223862255,-0.02530683046270532,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark52(20.006259875855,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark52(20.080821529245725,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark52(2.0168425888627155,-1.2665221650006164,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark52(20.188653784855546,-0.5527714373315691,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark52(20.20498582533065,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark52(20.212529622663865,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark52(20.214359415421796,-1.101593350445218,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark52(20.234483852515723,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark52(20.267647820113282,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark52(20.36369737830344,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark52(20.41101304262334,-0.915064508729817,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark52(20.413292681967512,-0.8489532257236887,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark52(20.456235409994107,-0.9228437568343071,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark52(20.494797821382463,-0.35622475461658243,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark52(20.5040277401324,-0.37851503867243963,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark52(2.0527200368509426,-0.9608596620964036,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark52(20.568936270985823,-1.4999999993854451,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark52(20.590119623832035,-1.7424345883005024E-4,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark52(20.59362297213653,-1.029190329601998,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark52(20.59903268021515,-1.4304099010408704,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark52(20.636281935795182,-0.6002767321735429,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark52(20.670820518239253,-1.0141866040533358,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark52(20.758329813904354,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark52(20.777486131454584,-0.1682127892373,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark52(20.804981394530756,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark52(20.85294343125426,-0.42905746236845843,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark52(20.869020318309367,-0.5194237362524063,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark52(20.90659539823082,-3.0787235165311696E-8,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark52(20.92845617056433,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark52(-20.971576673408975,-0.9171726488239499,0.0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark52(20.977123775048568,-1.339729306104345,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark52(21.01674855810289,-1.0354961878561886,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark52(2.1018427838834555,-1.443229455120505,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark52(21.06031831780941,-0.9543890627483553,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark52(21.113752515186633,-1.3602625445665062,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark52(-21.130726686810874,-1.4999999999999991,-69.44287659351974 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark52(2.1144759981119785,-1.3941167965739014,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark52(21.174006424283434,-1.23748884786326,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark52(21.224887342457464,-0.2318709829277421,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark52(2.1241376729573904,-0.33180065060132335,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark52(21.25783030276471,-0.6156904043630524,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark52(21.28986243329321,-1.256349396296391,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark52(21.296639933912914,-0.18196752842679942,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark52(21.299257235579617,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark52(-21.332598015254938,-1.4772288740136987,1033.6038415813262 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark52(21.34093647242814,-1.0445328771827607,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark52(21.3772437953738,-2.4267053134889707E-9,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark52(21.390369071940967,-0.07029779995471586,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark52(2.139516786148154,-0.19651256960014718,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark52(21.43056088471515,-0.04712884707834457,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark52(21.557197200282133,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark52(21.623122991414483,-0.21865215502690827,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark52(21.623251789360996,-0.12542249817764808,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark52(21.633909659461903,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark52(21.666088534493042,-1.1453184842793749,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark52(21.70371607670853,-1.2487578619445827,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark52(21.706262894275994,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark52(21.70924685964541,-0.3598718506833214,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark52(21.719471367567,-0.47205888574982335,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark52(21.822363181424336,-0.14130987331195044,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark52(21.835046170685374,-0.47106474879679705,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark52(21.84112681059374,-3.5005820116471354E-6,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark52(2.198038980720085,-1.4733745114571093,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark52(2.198141844265185,-1.4999996341897217,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark52(21.9966160848613,-0.033915345185709045,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark52(22.00655349408325,-0.9410755447850647,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark52(22.02979335310353,-0.5035993214445825,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark52(22.04423718948631,-0.05358866454581701,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark52(22.053513938492006,-1.331758790550868,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark52(22.065271598862267,-0.050818462450560986,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark52(22.127275684746593,-0.5168648770598259,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark52(22.154099725948903,-0.12188818063582363,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark52(22.164471202240914,-0.018799403732050923,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark52(22.166591955862998,-0.053736696279302,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark52(2.220446049250313E-16,-0.13615052607533595,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark52(2.220446049250313E-16,-0.2996961904748332,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark52(2.220446049250313E-16,-1.2738704506519964,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark52(22.211245526307152,-1.287239757861041,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark52(2.2237663530689353,-0.5651881576659037,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark52(22.247667745857825,-0.09726361366651659,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark52(22.268194926792802,-0.6554505819153436,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark52(22.330613009763468,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark52(22.38012951862946,-1.4999999998666667,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark52(22.44846200686858,-0.6369029666053285,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark52(22.491221729826265,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark52(22.51158160008024,-1.0608538970554987E-8,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark52(22.514281588963218,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark52(-22.543903843038706,-0.19604168324028315,1.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark52(2.255347836369765,-0.09824136422421681,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark52(22.555172876510127,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark52(22.567111635228976,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark52(22.634510133876134,-1.0965260960131066E-6,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark52(22.661485384505028,-0.6532869040144647,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark52(22.720873448034688,-0.28518202863160447,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark52(22.736473277251537,-6.938893903907228E-18,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark52(22.75374119004097,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark52(22.821389519854257,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark52(22.915219407353987,-0.049805462505033475,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark52(22.915280067696475,-0.8791823390635817,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark52(-22.97826340967488,-0.28024043756360517,-1.0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark52(22.979850637973186,-1.4242784921010005,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark52(23.007102041338797,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark52(23.01764689719581,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark52(23.07864543687026,-0.5427253764276827,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark52(23.081151207713717,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark52(23.115137307171388,-0.0944852854295648,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark52(23.216614106255548,-1.4053271320894716,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark52(23.217431481660153,-1.4999999997823266,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark52(23.252943137538338,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark52(23.295377221112304,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark52(23.320007493874797,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark52(23.35308461838474,-1.0817700081856518E-5,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark52(23.392737707733133,-1.4877697844356388,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark52(23.447585345541484,-0.47333789069113497,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark52(23.479894824215215,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark52(23.498404257782795,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark52(23.59470876724319,-0.7089623086394916,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark52(23.62869255246374,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark52(23.63185316281529,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark52(23.63953179669856,-0.2861161875903804,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark52(23.706261849890087,-0.8074598576480827,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark52(23.73704256552353,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark52(2.3737436442451108,-0.2847497810245576,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark52(2.377726988224522,-2.7594555795984544E-5,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark52(23.802925963994596,-0.516313446151635,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark52(23.804988475603565,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark52(23.867211691647228,-0.10675133745299092,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark52(23.87231058550124,-0.5252942776741385,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark52(23.911178665464202,-0.31440081578356915,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark52(23.935507285986404,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark52(23.94880609087784,-0.017105752141201025,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark52(23.97254501643424,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark52(2.3974732003613366,-1.110692102971035E-9,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark52(24.018694274243845,-0.6095035623716711,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark52(2.403169678521591,-1.494917366657401,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark52(24.076039561232847,-2.1293570341641957E-16,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark52(24.10233193112046,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark52(24.106450253788164,-3.404618353918449E-7,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark52(24.134260482510527,-0.35439785778658894,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark52(2.4135513235188584,-0.17715452998138995,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark52(24.144436838154242,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark52(24.16909269028376,-1.4082463759205828,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark52(24.174882500882617,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark52(24.200140314924653,-0.29019943997087694,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark52(2.4200320104608197,-0.9005138647655615,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark52(24.20662537237461,-0.3386235967976857,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark52(24.262582436909526,-0.46734306888988897,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark52(-2.429710208810743,-0.5158225377794565,-1.0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark52(24.30623905169324,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark52(24.3758472638073,-0.5475691081953871,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark52(24.377259292279025,-6.468892604278305E-8,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark52(2.4460827154444944,-0.025205345867742344,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark52(24.505083795264454,-0.3136334370317988,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark52(24.518163622330874,-1.477813256881302,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark52(24.571950459068987,-1.310407863311738,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark52(24.572384988900957,-1.3549257797612566,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark52(24.59156465662558,-8.814475014861292E-9,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark52(24.59310970702218,-0.7121494901714307,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark52(24.641963333424272,-0.014923511234119058,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark52(24.64755047055145,-0.03835494584176752,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark52(24.657127190184895,-0.6396319446813976,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark52(24.67316076117116,-1.4434998496310065,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark52(24.72072920553336,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark52(2.4739741664051316,-1.4999999524563337,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark52(-24.75474524009502,-0.15596221125836962,61.2304475725424 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark52(24.76029608414801,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark52(-2.4761945045794693,-1.461835620165884,1.0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark52(24.76849391078938,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark52(2.4814510164601415,-4.291317445035685E-9,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark52(24.819562546228084,-0.05218223477815709,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark52(24.82701109285648,-0.6667857151084164,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark52(24.887440071316604,-1.4032048059607831,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark52(24.99382387536909,-1.499999999999993,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark52(-25.00385265477685,-2.0258777054975017E-8,82.60200898572359 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark52(25.038657170070437,-0.8621350636579153,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark52(25.062100484175517,-0.40112877352204634,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark52(25.073154497604968,-0.8729005732400782,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark52(25.199646109539096,-0.3629389633067479,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark52(25.20976313328218,-0.077290026307125,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark52(25.279012265781216,-8.399398203112993E-8,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark52(2.5359138907258725,-0.4226547648874265,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark52(25.39452192304394,-1.1609760526524493,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark52(25.398645177370227,-0.2502530457358816,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark52(25.439170323377,-0.9216329551455229,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark52(25.475676322899258,-0.6510600473995929,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark52(25.523338860116297,-0.9561356735599832,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark52(25.551812060358728,-0.3066288828767623,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark52(25.67716676174702,-0.27649071919057633,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark52(2.5831110226769844,-6.863455117575581E-8,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark52(25.870750962275622,81.48815123532194,-33.30709163937395 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark52(25.909428057064602,-1.0619556202371,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark52(2.5921264777526862,-0.04070518230416647,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark52(25.92136826915352,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark52(25.930318162304573,-0.9330156208742331,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark52(2.595499875343687,-0.39504438369731876,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark52(25.982707812110817,-0.3163472472811577,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark52(26.0663951914988,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark52(26.115661038371048,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark52(2.6142372349844596,-1.4095269955195855,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark52(26.144884791490178,-0.08176025108166685,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark52(26.17594671183503,-0.3054553061872632,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark52(26.19857126127434,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark52(26.202956460638617,-1.222239394278513,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark52(2.622104949091387,-1.2370345795161701,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark52(26.254229927341683,-0.8973496853478136,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark52(26.273825462743208,-1.109346982692009,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark52(2.630706273869592,-0.07089915554522919,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark52(26.334322460819944,-6.333001840403173E-10,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark52(26.349502780430313,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark52(26.4011758013977,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark52(26.409651531510534,-0.1429910919056283,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark52(26.41653475925031,-1.2198389616988985,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark52(26.451266747608443,-0.7028496688482448,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark52(26.459954243893577,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark52(26.47347743927379,-2.1319631484483214E-7,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark52(26.497218649085106,-0.691476811598275,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark52(26.50535899851863,-1.1567723237294922,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark52(26.50838692415944,-0.9935455027366231,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark52(26.50931526865223,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark52(26.592384457749546,-0.8922700502990524,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark52(26.73060241651129,-0.6268283234299794,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark52(26.736180940072924,-0.4552805786185006,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark52(26.74830062016376,-0.27630916505449954,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark52(26.751722816618525,-0.26186981623202144,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark52(26.766040348495835,-1.2073996112438152,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark52(26.83158282503104,-2.3018560318752545E-9,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark52(26.887658739305536,-1.1806681255820715,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark52(26.916422523730702,-0.29911187444486087,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark52(26.95636767995559,-1.3364367266067888E-9,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark52(-26.99754000435439,-2.366302299557444E-7,1.0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark52(27.035789608979375,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark52(27.0533046699896,-0.10923637975248068,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark52(27.12676184683416,-0.2714656026284916,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark52(-27.16234104601424,-1.429561957753064,1.0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark52(27.196789093171986,-1.4999999999999871,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark52(27.2531649105683,-0.28851236158524873,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark52(2.7262158133343206,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark52(27.309458902095084,-0.08059636810515425,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark52(27.32149647544619,-0.05364471063555154,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark52(-27.35574668241827,-0.17494756879820444,1.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark52(27.37756314556043,-1.372573217169176,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark52(27.39098042738386,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark52(27.411141619262885,-0.6459829861697699,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark52(27.518407472736186,-1.4736079507839572,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark52(27.54123480106692,-1.1808168233679668,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark52(2.7543168316120976,-0.17523544266451552,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark52(2.7547971901447,-1.3106406969893007,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark52(27.55557071138326,-0.6019511725489206,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark52(27.587967839193762,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark52(27.628455601117153,-1.448489058261329,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark52(27.630125295444927,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark52(2.765430581757395,-4.070933093883098E-4,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark52(27.70722958070388,-0.11684654170694309,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark52(27.72664916001966,-1.4999999999998437,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark52(27.753576120544274,-0.4653991333119356,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark52(27.86923335711151,-0.7038106675787272,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark52(27.869986224168414,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark52(2.791742308843154,-1.4564006757707673,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark52(27.91765600056602,-1.3380337296506468,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark52(27.935103559750175,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark52(27.943661352491418,-0.388138009048127,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark52(27.958123030491905,-1.4988152620762003,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark52(28.023978660467748,-0.6293161277474546,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark52(28.14721835736954,-1.1413360762616636,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark52(-28.17698100072825,-0.6535902343639293,-1.0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark52(28.190740206303815,-0.7538645751289152,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark52(2.8217550499559763,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark52(28.271614078107632,-0.21893852078265663,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark52(28.276381492537382,-0.36377244464096714,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark52(28.277283501714777,-0.7907754761852885,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark52(28.315717364576017,-0.19057466500062992,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark52(28.34880274211694,-4.481677972824533E-9,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark52(-28.36029088777468,-0.2125874906457368,71.37362624461673 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark52(28.37078303363836,-0.834000582722775,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark52(28.398939570328537,-0.7930868221038105,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark52(28.416744849703868,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark52(28.53620554899324,-1.5241548573024E-4,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark52(28.595088873883263,-0.3937903998218433,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark52(28.70483314981729,-0.4505047352224739,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark52(28.705342003484304,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark52(28.7516231112063,-1.2611585331123412,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark52(28.751998137702156,-2.8710490961495806E-9,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark52(28.83209958931938,-6.19997307590437E-10,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark52(28.85237942042436,-1.4905578756211502,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark52(2.8853534635024305,-2.149660510639147E-9,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark52(2.893889633553837,-1.4999999989794655,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark52(28.94214647627296,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark52(28.963789303139322,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark52(28.964606475169596,-1.287661568576624,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark52(28.98825551675185,-0.5692200529349165,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark52(29.041722109539933,-0.7142093282500701,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark52(-29.060014536077066,-0.020839609206678496,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark52(29.079148138907385,-0.5381668090020071,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark52(29.11456058189438,-0.8048771146151379,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark52(29.128739436403947,-1.1104555103879274,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark52(29.141622462180667,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark52(29.179851767953153,-1.4999999999999827,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark52(29.205910147351293,-6.128508167442053E-5,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark52(29.22570494725997,-1.3089375220252069,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark52(29.243270165152275,-0.017788790429236884,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark52(29.291533760680863,-0.9498102374811273,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark52(29.412633611403066,-0.03887137306401378,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark52(29.44475629518658,-0.009890075159717071,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark52(29.466455505201505,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark52(29.557716795714327,-1.1096140266944898,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark52(2.961281426389185,-9.502623513995998E-10,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark52(29.635506104822724,-1.4999999999423272,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark52(29.656510672380936,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark52(29.687803494682896,-0.6006639125970139,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark52(29.807028855607605,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark52(29.808608587978753,-0.8153038984709857,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark52(29.819916357202402,-1.1786835241345268,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark52(29.828758552951967,-0.0045135003730703074,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark52(2.9829177546231165,-0.3447808600222291,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark52(29.865327807436245,-0.32372578610791924,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark52(29.871603046817313,-0.6219229132587545,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark52(29.879831112765288,-1.266951900497375,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark52(29.89503084409067,-1.4999997777831222,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark52(30.00553355632212,-0.2461297598126343,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark52(30.01692323686401,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark52(30.034264302507786,-1.25434049737801,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark52(30.097506426789806,-1.0955359221227043,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark52(30.100403655627307,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark52(30.118154487451033,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark52(30.127022795330703,-0.018324740805855555,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark52(30.134065327514584,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark52(30.164989803220795,-1.4999999964072857,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark52(30.167766019447754,-0.4734525413073284,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark52(3.0167866852096075,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark52(30.186779211172855,-0.6753252554832732,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark52(3.0209144468743716,-1.1094573996807071,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark52(30.22407545088904,-0.7855825909933779,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark52(30.236116889612106,-0.43078632767448255,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark52(30.259512492603733,-0.658463499688196,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark52(30.262713043920485,-1.4987140896634301,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark52(30.279839434666144,-1.217374789938967,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark52(30.2824181911203,-0.850881227502041,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark52(30.303716903839728,-0.18756552992801545,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark52(-30.337694773721918,-0.7674519676640168,0.4682892323364095 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark52(30.3957337745085,-0.14526577046308375,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark52(30.401625607314635,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark52(30.437119358766466,-1.3111822650322176,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark52(30.504292692040107,-0.08419517297218704,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark52(3.051956874674161,-0.27089545218908384,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark52(30.535121442545158,-0.12564930891681114,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark52(30.539386147417503,-1.4106820886280156,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark52(30.57441916210442,-0.0028613435418536337,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark52(30.63136884900061,-0.7336468383083012,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark52(30.68999263914994,-1.4081447049745988,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark52(30.694131985557643,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark52(30.715502807666752,-1.1927076003668549,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark52(30.744974765956254,-0.9545436609682798,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark52(30.773103454066984,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark52(30.78068673950841,-0.38739659616149424,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark52(30.87664568862195,-1.2973250240060628,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark52(30.93892594911435,-1.4543839997027845,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark52(3.1055940263983217,-1.035478700523143,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark52(31.082803165225407,-0.5923808474073515,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark52(31.09658499513779,-0.05802315668694291,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark52(31.142474124922412,-0.48107116555183094,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark52(31.1434969900738,-0.12541407902857316,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark52(31.191697082252546,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark52(31.253936400218787,-4.0979089596257155E-8,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark52(31.300365221531933,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark52(31.391318777046955,-1.554393131423396E-8,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark52(31.404045150841057,-0.9524770700089875,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark52(31.406076971701424,-1.2429143859401446,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark52(31.43615985870852,-1.3419716698049804,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark52(31.449034697426555,-0.4277089645236737,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark52(31.457726011141204,-0.6935438198716772,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark52(31.469149320395786,-1.0890152703944977,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark52(31.47570089358959,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark52(31.51850793467625,-1.11700203071705,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark52(31.56046471344143,-0.1915009992791026,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark52(31.56679207469523,-1.3078631248736556,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark52(31.569148014285428,-1.0590976717800968,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark52(31.603913882519322,-0.8762585112256939,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark52(31.613027116485767,-1.350831344049018,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark52(31.67452089592959,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark52(31.70383292765456,-0.18749835015680127,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark52(31.731716646202415,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark52(31.77918071148942,-0.4236634547531263,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark52(31.783138724507012,-1.0999119821300134,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark52(31.79445433840625,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark52(31.81236627035591,-0.16361100402808298,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark52(31.814478560915035,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark52(31.820667932408355,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark52(31.825766508881003,-0.4491174159941824,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark52(31.87352914619895,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark52(31.888233054949428,-1.0934324886399462,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark52(31.915338213417527,-1.0414426646637889,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark52(31.921408092073573,-0.16930258487546945,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark52(31.922296706700177,-1.3835866386246836,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark52(31.985324279757833,-0.8414610088530754,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark52(3.199748403912329,-1.12470525845057,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark52(32.0053312618879,-0.8654047834522345,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark52(32.04869165397854,-6.739312970446945E-8,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark52(32.05340745147293,-0.43606447321413055,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark52(32.05558844465227,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark52(3.20739892880335,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark52(32.08307249373553,-0.5264061551987698,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark52(32.158909311391966,-0.0959555979653306,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark52(32.17860028890321,-0.4308070271496547,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark52(32.18688195888305,-1.1313582176580361,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark52(32.23188598342754,-0.720687914714003,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark52(32.25757078675818,-0.48449926886019057,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark52(32.26445206075075,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark52(32.33583951386666,-1.26741184328351,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark52(3.234369104690586,-0.2295666825259417,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark52(32.37631548653639,-5.017311710976638E-9,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark52(32.459591214952496,-0.43235322576486324,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark52(32.46191679138284,-1.0687335799911479E-15,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark52(32.47821878980312,-0.8983788216975155,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark52(32.4914805290521,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark52(32.51779038464399,-1.4986526643050149,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark52(3.256120732143742,-1.2956008510936439,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark52(-32.588197896830195,-0.31492538798175257,1.2621774483536189E-29 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark52(3.266985366143359,-1.4398279434467582,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark52(3.2722638044949974,-0.9222702169570975,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark52(3.2780439902931944,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark52(32.81751669446766,-1.4235259020726154,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark52(32.83910141225226,-0.3553837133847617,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark52(32.96768034854322,-0.6336302648544887,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark52(32.9878413734275,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark52(33.02936235490756,-1.4999999999999698,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark52(33.05682869446018,-1.3934707114324367,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark52(3.305740790013715,-0.2783638812232674,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark52(33.08784516991744,-1.35215108064203,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark52(3.309659772760739,-0.9661766674930208,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark52(33.10248318966208,-1.4313819346700338,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark52(3.311152752961192,-1.2357196891556335,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark52(33.1775741970552,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark52(3.3179927215677374,-0.11909448120398025,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark52(33.21659557853303,-0.8256859133016965,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark52(33.23137116285602,-0.5889772072488069,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark52(33.27083866806157,-1.194623347867128,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark52(33.27748481993428,-0.6760239923028081,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark52(33.29482146438016,-0.30776709759198617,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark52(33.32277106453748,-0.6486203573329021,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark52(-3.3323118041393838,-1.4999999999299949,-0.3621191550204607 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark52(33.33380335679584,-0.38810561910982566,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark52(33.339378912624085,-1.089692773905739,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark52(33.36813010470238,-1.097098575405786E-9,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark52(33.37364029880301,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark52(33.419337912096466,-1.4999999999999218,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark52(33.42174707359865,-0.8799866003881905,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark52(33.45443903555599,-0.3347670538154839,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark52(-33.49922068466778,-1.1315273767762248E-4,-1.0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark52(33.50178667343317,-0.5380702686264502,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark52(33.50226881416047,-1.430706801135675,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark52(33.53031365301106,-0.5989456317833373,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark52(33.538573197141105,-0.025222486817956236,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark52(33.61080631254102,-4.39079502481528E-10,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark52(33.624546890994566,-0.060677289342725864,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark52(33.653263183489734,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark52(33.66328059479922,-0.2229955947688888,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark52(3.3667481062614,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark52(33.7151445503576,-1.4074784227557728,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark52(33.75614300890155,-0.9276484337278728,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark52(33.77383298510722,-0.26450264047316807,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark52(33.78945780063771,-4.407159946605695E-10,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark52(33.810539600390385,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark52(33.91630028829738,-0.9473928750312774,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark52(-33.96182582148069,-0.36760237209140584,-1.0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark52(33.96527264940488,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark52(33.98126710031556,-0.24758404714368965,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark52(33.99157897984266,-0.4944581479783856,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark52(34.04819065297812,-0.3263415141446302,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark52(34.057025753946505,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark52(-34.08118605033542,-9.341688771953544E-6,-0.999980368508945 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark52(34.099911209077334,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark52(34.12549879339437,-0.6983027744180603,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark52(34.149195199184305,-0.7774172875004979,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark52(34.15361669859207,-1.0024371598622803,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark52(34.16313668362224,-0.18665046781924843,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark52(34.191276147876806,-0.5189818198845004,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark52(34.22123429214162,-0.07818986597410693,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark52(34.223080165748286,-1.350714678242118,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark52(34.25483494418319,-1.06390299594608,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark52(3.426972110534493,-0.40727651974242907,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark52(34.297680700613896,-1.6033840025176637E-7,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark52(34.30357958435596,-0.023972434901347928,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark52(34.30437190091459,-0.1428617297456185,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark52(34.30599891287679,-0.3412054123998214,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark52(-34.3281266237981,-0.22445898383904042,-1.0000000000000004 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark52(34.34090973466645,-0.034370309363250584,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark52(34.3434924923578,-1.499999999999997,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark52(34.34967303281289,-1.4184553869799323,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark52(-34.38218678625305,-0.01817965408525707,0.19834893536544898 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark52(3.4385116611404176,-1.0829316070485937,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark52(34.43748885702968,-0.5862502633101601,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark52(34.46570904976139,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark52(34.46821780259404,-0.01568465274123909,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark52(-34.49838262078378,-0.7331409185744855,0.9917995831025491 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark52(34.507791694530106,-1.3431370916924095,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark52(34.515931501228906,-0.05918228426695738,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark52(34.62038309538065,-1.1267573895704255,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark52(34.62464989570486,-0.08218331484651854,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark52(34.651734117618616,-0.9336326115093669,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark52(34.653057063309674,-0.315428402076563,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark52(34.692974045221234,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark52(3.472716511295417,-1.099868270657658,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark52(34.76357265869953,-0.8842077972101823,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark52(3.477367742431497,-0.5522442428640355,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark52(34.776082762789514,-1.2291297705842696,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark52(34.78258956972887,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark52(34.802186210797345,-0.42983456377298523,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark52(34.813213284451905,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark52(34.83835661147636,-1.3045177783261686,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark52(34.89962062917286,-0.10239353928484718,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark52(34.91126650408623,-0.4010279086840718,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark52(34.94915052657638,-2.7727415556869757E-6,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark52(34.97972642788102,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark52(35.02390751665996,-0.09206378905664714,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark52(35.05845455305558,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark52(35.07085853962615,-0.8930582011257684,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark52(35.10603459154139,-1.1027786641918595,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark52(35.11384406099043,-0.5937210831173019,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark52(35.31805582115922,-0.15652839329581347,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark52(3.5348715266675472,-0.24006256262752612,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark52(35.37626060236357,-0.004872415844745848,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark52(35.39510520803958,-1.1006079289064523,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark52(35.41819045920823,-0.666443062324042,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark52(35.44384846183843,-0.6323576565624469,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark52(35.47469254763954,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark52(-35.51102516295164,-0.09620043274880419,0.951909493287384 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-0.3621554077197124,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-1.1401209981663785,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-1.227890885058173,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-1.2677990684813665,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark52(3.5563257146969676,-0.06495569457935702,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark52(35.6031674098103,-1.44585218982197,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark52(-35.68047876556817,-4.910798153263948E-10,1.0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark52(3.5704523837773876,-0.620049320779607,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark52(35.70855141548796,-0.8762433495371056,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark52(35.76585077657378,-1.2312462382587398E-8,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark52(35.76650678254671,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark52(35.84885322406021,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark52(35.868809973377346,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark52(35.87731427633034,-0.7486055010457875,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark52(35.87764167505631,-1.0225244638511914,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark52(35.88310015574791,-1.4874948671553572,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark52(36.01337139059183,-1.2765713091218203,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark52(-36.10081614236341,-0.24827462187371996,0.38948655356767536 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark52(36.108781548588915,-8.750526245161224E-5,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark52(36.146698515791655,-1.1555806924932455,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark52(-36.18227387387297,-1.400028926243487,-2247.679345324535 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark52(-36.23167946627151,-0.4345877292222242,-1.0000000000000004 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark52(36.25482570461628,-0.35592336363115207,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark52(-36.28351063830984,-1.4999999999999996,-54.734855108419985 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark52(36.29508042797232,-0.8186620904064308,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark52(36.29922389037846,-0.004508944526474622,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark52(3.6455610097781987E-304,-1.6023475384270569E-15,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark52(36.46505109514172,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark52(36.494433354798645,-1.2267056167010253,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark52(36.50260424972448,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark52(36.52337058707553,-0.7544374699475229,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark52(36.525499160155675,-1.4367996527100573,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark52(36.52823238044877,-0.5195092580227083,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark52(36.535280197874414,-1.0627838523964641,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark52(36.54928090819979,-0.3088030716605553,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark52(3.6571567482009044,-0.3751435409191739,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark52(36.57429397026603,-0.7415021019553638,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark52(36.603943349027844,-0.6540418849653937,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark52(36.61440424063812,-1.357172729339922,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark52(36.659607998643224,-0.8197527810979324,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark52(36.73229282171047,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark52(36.851503143944456,-1.0833759922419193,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark52(36.94769547970297,-1.1246904460536262,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark52(36.962641151030084,-0.10457239285011577,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark52(3.6985395611952185,-1.4999999999999787,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark52(36.99847837495696,-1.4398347405959853,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark52(37.03707329688632,-0.772292378445151,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark52(37.04255744861544,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark52(37.08181936807644,-0.4895139041453742,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark52(37.092031601487776,-5.130097161387859E-9,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark52(37.10052742951365,-1.3040845581135017,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark52(37.10692633999648,-1.198349950286854,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark52(37.14891493793285,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark52(37.214406888368536,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark52(37.29157736583048,-1.0468291200583293,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark52(37.303331569980536,-1.1747002504188444,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark52(37.359695449802196,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark52(37.366650571090105,-0.45263374198742845,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark52(3.73964246906111,-0.6336730209418886,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark52(37.39786191567339,-1.3932642618511162,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark52(37.41085792930957,-1.4314455373336585,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark52(37.43764446218293,-0.6732287493936298,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark52(3.7452183387723323,-0.575530743701762,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark52(37.4602188717176,-0.2921790045987773,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark52(37.51335582894092,-1.3026628981804578,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark52(37.550324399285245,-1.0809685058060046,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark52(37.61161685425197,-0.4288440998138038,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark52(37.63228229451955,-0.8967001699659702,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark52(-37.63826688278695,-0.2532354190159225,-0.0467486099532779 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark52(-37.645560414601896,-0.8406096152072848,2.2983853329720034 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark52(37.65507263397441,-0.4983862765245881,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark52(3.7656226905190096,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark52(37.6619730969561,-0.1513683822149403,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark52(37.712636454867805,-1.219892745204116,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark52(37.71981721557438,-0.8551834937662587,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark52(3.7733670770918835,-0.3942630408453738,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark52(37.762391660513856,-1.082829253797641,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark52(37.787295095614326,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark52(37.933478940688644,-0.05577324538737116,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark52(37.94286553179077,-0.302148045025751,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark52(37.963291286667186,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark52(37.97266706682868,-0.9234391484468815,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark52(3.798550609518813,-0.670210302547842,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark52(38.03155014455476,-1.1717426291721944,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark52(38.05334605734933,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark52(3.807010123262385,-0.7139152208433743,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark52(38.10262464423373,-0.30498353584019355,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark52(38.151286227558984,-0.10429426719254997,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark52(38.1525698665509,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark52(38.20629549985386,-3.8845434517726123E-7,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark52(3.8212565283750166,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark52(38.21560712953106,-1.2295622777619069,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark52(3.8392238435728152E-239,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark52(38.437392336450216,-13.469260670015075,31.012927409992187 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark52(38.48130571871798,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark52(3.8536574413662965,-6.656978132137891E-10,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark52(38.58199282763488,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark52(38.62843715669317,-0.15509833812031792,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark52(38.684562092473556,-0.26956951541927054,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark52(38.726379620108,-0.34164480657641466,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark52(38.766975790330264,-1.323045579860464,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark52(38.78244602036142,-0.2889451157981995,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark52(38.83792543318518,-1.4751619227292565,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark52(38.89235622475155,-0.40707830819638957,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark52(38.89290744740343,-1.4999999867889162,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark52(38.92185788842363,-1.20579839174912,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark52(38.94930770046719,-1.1949973356659456,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark52(38.975566803564504,-0.4269094286935906,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark52(38.9781912412775,-1.4686831740066282,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark52(39.033750194836074,-0.8754926896431279,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark52(39.03782683904153,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark52(39.047757304485856,-1.4803473806825227,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark52(39.050502192863014,-2.971780595765567E-7,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark52(39.06578593421956,-0.2263051476634742,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark52(39.07291871673837,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark52(39.14956648605602,-1.3974760760597957,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark52(39.16793697372218,-0.036736396505195223,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark52(39.228215336281835,-0.9849800923804537,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark52(39.2401580491767,-1.290750933940645,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark52(39.30934618243117,-0.19147696050647878,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark52(39.33152318657082,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark52(39.35577403225991,-0.7265260976767355,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark52(39.36091209991645,-1.291819838894373,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark52(-39.378277016889626,34.049798594071035,-90.02810994875921 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark52(39.380039294831306,-0.26556793094982734,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark52(39.41968284067846,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark52(39.437764265839974,-1.3754700822361592,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark52(39.492276392028856,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark52(39.502043197852345,-0.9526608361809537,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark52(39.506339134565025,-0.8426451020816774,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark52(3.9569345400346236,-1.1130070253503583,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark52(39.62923351190804,-1.4999999987723882,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark52(39.674605054946866,-3.5965957256356127E-9,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark52(39.719957330053234,-0.47698151691123325,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark52(39.72297795143385,-1.0009478067358515,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark52(-39.723374745456354,-0.2958595139468421,-1.0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark52(-39.90697655364414,-0.5173429256159725,0.0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark52(39.90972293477418,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark52(39.973750380823105,-0.08310588793207169,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark52(40.06995142654367,-0.03919507598116079,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark52(40.13141785837766,-0.13965295112552503,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark52(4.017158891067979,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark52(40.19194778132904,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark52(40.257158308368815,-0.8953354156840252,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark52(40.2782731022933,-0.5239689680761412,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark52(4.028117077314491,-0.4071699697859543,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark52(40.28729634407705,-0.19000183119787373,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark52(40.37306892801482,-0.6962655836615759,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark52(40.38604051266651,-0.2660530375220862,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark52(4.050697841135204,-1.032306660299608,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark52(40.55957814437798,-0.21934451111052178,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark52(40.58799566367074,-0.523437807025398,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark52(40.60593113781127,-0.5375664927359334,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark52(40.62815392341248,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark52(40.64226984198697,-1.0529806286646846,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark52(-40.65832132428042,-1.9985337696522832E-9,-0.3767126075107735 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark52(40.76408048939669,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark52(40.76449970514872,-0.5868225287365476,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark52(4.077068174469062,-0.9070643172292618,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark52(40.77837349887749,-0.7889422715305946,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark52(40.88051590897001,-0.26766136050231637,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark52(40.88177054172783,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark52(40.90571996297214,-0.6535031979688029,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark52(40.96984913451567,-1.4217360724876142,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark52(40.97738210018218,-0.5182310627548095,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark52(4.101373143152721,-6.442375916036759E-7,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark52(41.03723900718521,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark52(41.11100152242241,-1.1021874886893184,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark52(41.16474874853469,-0.562172686794753,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark52(41.19104688779859,-0.791060748278511,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark52(41.19809615837866,-1.1575655589492628,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark52(41.21455969530452,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark52(4.121855088493675,-1.2554206084877966,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark52(41.24166400279705,-1.2395502596691301,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark52(41.247967858051126,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark52(41.280476707543215,-1.3393270031791038,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark52(-41.289030671127804,-0.271675465491787,-1.5208732530361279E-210 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark52(-41.31073375934481,-1.4999999999999996,0.016245187852364944 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark52(41.3181622657207,-0.4905209784375595,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark52(41.32703299910559,-1.3268151426437633,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark52(41.33184932447372,-0.3588147518367464,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark52(4.134397789917383,-0.22043119297124067,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark52(41.36782779045012,-1.4017259500350292,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark52(41.41644436053977,-0.32495843312686734,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark52(41.45365780427841,-1.1507333246789173,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark52(41.45543659421021,-0.013458091596239896,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark52(41.474601820919055,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark52(41.48019340542437,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark52(4.1582132358381925,-4.2880697517790135E-7,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark52(41.58333314372696,-0.6454555179740159,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark52(41.608020541189106,-1.5367924214327896E-6,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark52(41.66213204385892,-1.213133448168918,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark52(41.66838404727429,-0.687041037776293,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark52(41.68384874821521,-0.7091615644075517,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark52(4.168808289092089,-1.4713131477838761,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark52(4.181444159339822,-0.22928800052848952,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark52(41.84424426345376,-1.2319462096513085,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark52(41.906806378331304,-0.3284427644628355,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark52(41.94685185519842,-0.4306571745829473,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark52(-41.98186274841073,-1.2975185763806507,0.9424153055914688 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark52(41.99794300172573,-0.12060907255062148,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark52(42.00391663112549,-0.037096359779079435,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark52(42.01216507356958,-0.8002321159143548,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark52(42.04025242093539,-0.16233569431835804,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark52(42.11576895279549,-1.342739400774982,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark52(42.14360499256643,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark52(42.14930411841826,-0.30395988874209623,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark52(42.16273003422623,-1.0442186320168698,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark52(-4.221422182550867,-1.0613599117761354,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark52(42.22990976166312,-0.5736747799085989,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark52(42.27237992342856,-5.239814819468635E-9,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark52(42.27314769937033,-0.2840845359735127,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark52(4.228836553510391,-1.2393752760065553,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark52(-4.23151208963222,-1.1102230246251565E-16,-92.699449262828 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark52(42.332205359280124,-0.8117271978277216,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark52(42.33241781369595,-1.823483032222554E-8,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark52(42.3953179825192,-0.3903945973218921,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark52(42.41556390325214,-1.4999999952938345,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark52(4.243898263529971,-0.016741216052848173,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark52(42.44142163910033,-2.4216271904030493E-8,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark52(42.48766741529883,-0.7955958566579249,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark52(42.52987217186501,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark52(42.53585710360409,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark52(42.5428530136308,-1.4999999837350437,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark52(42.550175066382934,-0.2879076307392102,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark52(42.55563826720978,-1.0477380643466534,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark52(42.559934727968766,-0.8707255340132605,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark52(42.56143185465427,-0.813792470701705,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark52(42.57975173292765,-0.8988773782483117,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark52(42.58835786454998,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark52(42.61615434381382,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark52(42.64252724289295,-0.1948123932901069,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark52(-42.65064209244177,-1.3860900246506143,1573.691389377539 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark52(-42.69573036798666,-1.2219239275880553,-0.9998448012875643 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark52(42.700219855860794,-1.3764331953395466,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark52(4.273737760775672,-0.28829470869274587,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark52(42.78642257821972,-0.11116244318927082,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark52(42.791290495231635,-1.4134116480516563,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark52(42.797969088038855,-0.27029485427915745,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark52(42.80820364515006,-0.40987401884377395,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark52(42.862104030953134,-1.111934952458648,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark52(42.870367389354385,-0.2866656328608268,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark52(42.87948525334454,-0.6125232339969227,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark52(-42.88306639139334,-3.552713678800501E-15,0.033412195968619995 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark52(42.90280939942362,-4.072374269709393E-10,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark52(43.013176455288715,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark52(43.071708692917554,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark52(43.07207530377792,-0.5882130550409586,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark52(43.07447930843293,-0.16962381428509854,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark52(43.18101568455382,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark52(43.1989134625112,-1.0668877961271193,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark52(43.24283189573646,-0.061021574486815666,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark52(43.28559712279277,-1.3755337792659872,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark52(43.30924008505332,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark52(43.310256976094024,-1.3693764905718704,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark52(43.31044654220533,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark52(43.32144199975011,-0.010301790845433229,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark52(43.33175545478219,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark52(43.43027857717557,-0.7691610472925983,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark52(43.440353605701105,-0.712165512679125,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark52(43.45593012673535,-0.8337161778159725,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark52(4.348419543836911,-1.3854704120177839,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark52(4.352049162202263,-0.9942974462365726,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark52(43.548833977725764,-0.437359336670605,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark52(43.5575006681029,-1.2567562119647793,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark52(43.589256648450885,-1.0172974747502126,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark52(43.61744813697342,-0.015886403719532427,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark52(4.364138309366908,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark52(43.68196158694806,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark52(4.375299877297913,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark52(4.376397434128435,-1.413609397358357,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark52(43.827939265174365,-0.4655883010719917,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark52(-43.88729826655372,-0.1189956459477803,-0.9999999999999996 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark52(43.890300125127354,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark52(43.90393655823797,-0.8688415698271754,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark52(43.91771223960656,-0.2786141915563727,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark52(43.93322364269977,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark52(4.403418207353947,-3.397995279817145E-6,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark52(44.07816886439966,-0.5425843349120294,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark52(44.12124776248373,-1.1616345137675168,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark52(4.418199394773392,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark52(44.19125386217516,-1.1047043592135788,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark52(44.19536312069252,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark52(4.419972633771522,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark52(44.22945765440923,-1.093701743001608E-9,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark52(44.34346024336014,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark52(44.39255985832341,-0.8312814337709113,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark52(44.393931785253216,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark52(44.40077746730691,-1.2690797944152492,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark52(44.40689044908276,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark52(4.440892098500626E-16,-0.29292304095592214,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark52(-4.440892098500626E-16,-0.4346854640683677,1.0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark52(44.44630935451056,-0.7390794920358251,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark52(44.47180035367336,-1.2449839027263465,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark52(44.54240010858613,-0.534876418747205,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark52(44.60668123719378,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark52(44.60807919878297,-0.6258042969954781,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark52(4.460885360710006,-1.3105455426817018E-7,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark52(44.70897239817785,-1.4796080846005113,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark52(44.71694604933671,-1.2163619083629311,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark52(44.74576884876521,-1.4680024153463904,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark52(44.7626663950634,-3.091785805547424E-5,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark52(44.797667742475795,-0.4969721376119747,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark52(44.81381322322692,-0.5931971606686,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark52(44.82263489567539,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark52(4.488584327710981,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark52(44.89254223120136,-1.1525562332175294,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark52(44.917555899284565,-1.0822740108150484,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark52(44.952885007643616,-0.9028041159574993,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark52(44.96505367138279,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark52(4.498314038110607,-0.630883883590144,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark52(45.02901462854411,-0.22147282420886233,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark52(4.507756556015011,-0.4499313812985122,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark52(45.22356452251588,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark52(-45.22440835930294,-0.1288980675853028,-0.9999999999999998 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark52(45.24553656640409,-0.05301633469577993,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark52(45.253272700757464,-0.9482755535740566,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark52(45.30385126917891,-0.8305612120277301,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark52(45.3073459236341,-0.4291676788885255,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark52(45.31557537400987,-1.0266149771930269,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark52(45.32309600154741,-1.1707044770096486,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark52(45.34464955318427,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark52(4.537906960834703,-1.4999999649838522,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark52(45.39782979344188,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark52(45.412234516392004,-1.3014748036423214,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark52(45.461769138114846,-0.030079501560669186,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark52(45.462462096972885,-0.49502710691415935,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark52(45.52978709316339,-1.499999999232353,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark52(45.58587012958375,-0.15083452165037414,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark52(45.6688305870926,-0.4341394517302322,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark52(45.67658966949156,-1.4869197758449815,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark52(45.689122556549165,-0.3760559036154518,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark52(45.70589521153289,-0.7437189270553848,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark52(45.75120841892402,-0.05341560107408583,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark52(45.81046002719725,-1.442109047435725,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark52(4.582541516346964,-0.7919035707793398,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark52(45.90557720609212,-1.4547064223129809,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark52(45.911181273729,-0.06716690384178729,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark52(45.940535036602014,-0.2568514417857069,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark52(45.96419895131483,-1.3116361570727193,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark52(45.9665063020357,-0.21709507589366694,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark52(45.99300018857207,-1.207539675915359,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark52(46.033670796350776,-1.4465726915952501,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark52(46.04052127109654,-1.357427102031238,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark52(46.060429089321985,-1.2020311585691594,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark52(46.08131932230131,-0.45584961295094883,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark52(46.10014240059772,-0.3666005321791692,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark52(46.11369375989031,-0.6466758897436478,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark52(46.12738320606958,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark52(46.14679664530904,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark52(46.15840736031896,-1.4378958365399868,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark52(46.17221990806179,-1.2592216455774201,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark52(46.2025042750511,-0.5190843556583502,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark52(46.21062485378769,-0.8448541340812268,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark52(46.27748933355781,-0.12467094736475037,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark52(-46.28451437730896,-0.08719080095673348,0.0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark52(46.35501638788466,-0.745479264648921,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark52(46.362573742201164,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark52(46.36531009106909,-1.2273153487314508,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark52(46.38886192135489,-0.7459135634611345,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark52(4.6412528740010455,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark52(46.455863890063824,-1.0647515198039086,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark52(46.48411459412747,-0.30270813533907387,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark52(4.6618201066929785,-1.8159638626337963E-9,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark52(46.67928323461268,-0.3727350513182177,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark52(46.681392672591244,-1.1833347607629725,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark52(46.68421600026201,-0.3673217423120856,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark52(46.68475203704045,-1.4764325630060204,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark52(46.72187239690695,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark52(46.73912651000373,-0.6273674041270378,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark52(46.757164040391615,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark52(4.676555828450891,-8.521932911974577E-10,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark52(46.79206562430058,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark52(4.680755772997809,-0.11303729317200684,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark52(46.8104586679497,-0.40637721665079973,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark52(46.878594061578895,-1.0225114504666815,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark52(46.892717864546235,-0.22690174049065082,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark52(46.91726323480685,-0.1098612249725972,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark52(46.98732931040673,-0.3307638903193313,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark52(47.006687278658774,-1.0366115411114123,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark52(47.06180740583578,-6.143147681732476E-9,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark52(47.066496020741766,-0.8199026769657427,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark52(47.07684559624896,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark52(47.08702964860784,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark52(47.097944623974456,-0.7321362695353173,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark52(47.10282844092819,-1.3746243307519572,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark52(4.716963519717837,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark52(47.185759804025906,-0.6199026336950573,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark52(47.21108490265149,-1.3879103256370797,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark52(47.22923629381281,-0.3781616911476178,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark52(47.27394892965975,-1.2793308418910954,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark52(-4.729106685638881,-0.022439502194089155,-0.988929834683198 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark52(47.31897825970117,-1.1655390439745028,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark52(47.32351177477838,-1.0665545302715707,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark52(47.39297193042637,-1.1163027300370016,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark52(-4.741714978154832,-0.49153834257455253,5.824652137052132 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark52(47.4826979290559,-0.5256646331231778,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark52(47.51074458949534,-1.2144929967529026,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark52(47.51383455614219,-0.3281857531157014,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark52(-4.760845323070133,-1.1820009923787835,-0.7149205899894042 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark52(47.611436549256,-3.471682946126885E-5,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark52(47.65963163606418,-0.5238019927691795,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark52(47.67509239271776,-1.499999999999999,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark52(47.68721915032269,-6.22661678938306E-9,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark52(47.70221408703151,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark52(47.74469382448933,-0.5698679613795026,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark52(47.765468662015,-0.26292343550219033,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark52(47.798045626650804,-0.8481629311962919,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark52(47.89842777977785,-0.8413499509496107,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark52(47.899047100063285,-0.4892134458543107,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark52(47.90616393502668,-0.5465872983828671,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark52(47.91805310262052,-1.2655892710028098,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark52(47.97374929901602,-1.3310277048813255,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark52(47.98169798169181,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark52(48.109215297641796,-4.0721348084834287E-10,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark52(48.17079997391121,-0.2992670506246409,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark52(48.17198658172411,-0.6433323885714217,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark52(48.18088712658317,-0.14222937930921375,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark52(48.18799228636021,-1.4240502521560474,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark52(48.19759070601829,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark52(48.226302327705156,-0.27409757304641535,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark52(48.25474334338048,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark52(-4.826357716193527,-1.42593034976518,-78.92014699933316 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark52(48.26853519644987,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark52(48.28069490500307,-3.666602123472306E-8,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark52(48.28214991234452,-0.40304228093063754,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark52(48.28704351097254,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark52(48.30078600835215,-1.4885047817692185,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark52(48.377932187776956,-1.455835645439545,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark52(48.43592492709371,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark52(48.43791491854101,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark52(48.451082962294954,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark52(48.46053077741118,-1.1534762827707477,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark52(48.50102333514562,-1.4999999999511293,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark52(48.545082291783174,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark52(48.58132972412587,-1.4999999995771538,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark52(48.66645208022811,-0.6186508490500757,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark52(48.684188903002486,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark52(48.70611805800246,-0.5693483085006932,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark52(48.93540563332644,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark52(48.94375250943139,-1.4868828304229704,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark52(49.00443458057592,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark52(49.01973457474875,-1.0121699821008008,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark52(49.054842014496415,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark52(49.085672788607475,-6.394900612039267E-10,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark52(4.909390005174829,-0.03274339252073321,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark52(49.09545130245621,-0.46717955568481173,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark52(49.150509486130915,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark52(49.191955040695234,-0.24977436591719648,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark52(49.235290059838775,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark52(49.26180842436052,-6.351462141488448E-10,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark52(49.26513307880117,-0.7156573469298877,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark52(4.930380657631324E-32,-0.3627736703346154,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark52(49.33720667761983,-0.35114155374943135,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark52(49.35706912141629,-0.5257958091639381,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark52(49.38534413791292,-0.6619607874183329,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark52(-4.94039221616743,-1.0206079668721204,46.81323672095356 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark52(4.943149515664061,-1.006953441160083,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark52(49.43249906832549,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark52(49.43343824186868,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark52(49.44203322502503,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark52(-49.44706970747157,-0.5947110752420922,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark52(49.48583997126269,-1.1537692684336491,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark52(49.486352117874,-1.5560305710438221E-7,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark52(49.48845586957685,-0.0324739540402561,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark52(49.50330004655771,-1.1669994538844148,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark52(49.52484905222386,-1.4682714625508697,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark52(49.54734273749567,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark52(49.59863769004372,-0.5205236388445202,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark52(49.606638590883335,-1.091169550070019,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark52(49.6265510776516,-0.21602322008239305,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark52(-49.80119217550947,-1.4635955580211402,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark52(49.864686520652526,-0.19828093078422526,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark52(49.910338321720815,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark52(49.91584666664522,-0.8894393786600148,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark52(4.991686078112536,-1.1867813143870354,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark52(49.931831932332955,-1.2110453911284393,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark52(49.93409646541183,-9.062874667141412E-5,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark52(49.94950355779807,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark52(49.96765067649299,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark52(49.981805077377366,-0.7650145377016957,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark52(50.09418895680453,-1.7719931479064193E-8,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark52(50.125255479787654,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark52(5.014838845309114,-1.3981217155377408,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark52(50.157425324985915,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark52(50.33864026755086,-1.3210182584455623,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark52(50.35762688009308,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark52(50.37433550219986,-0.05102516133467805,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark52(50.420336765221066,-0.5340959260648914,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark52(5.043204294584198,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark52(5.0446976657679325,-1.0665901818145471,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark52(50.46897406753199,-2.7414633992223596E-8,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark52(50.475077495522584,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark52(50.526387442823506,-2.3848589298447852E-4,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark52(50.5326797982905,-1.3100864173365356,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark52(50.53348438086746,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark52(50.57367481181544,-1.262636572165301,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark52(50.6829729196791,-1.2326760557367875E-8,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark52(50.692804390513096,-0.9432384078630266,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark52(5.073594643801215,-0.5733026712333924,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark52(50.759609017028595,-0.8984714354418712,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark52(50.808084937536016,-1.499998766646028,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark52(50.810027777691595,-0.02380458647934964,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark52(50.8481426568033,-0.028826194957127654,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark52(50.85227781005588,-0.5731064507043004,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark52(50.873894026198336,-0.05206708253553712,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark52(50.896176716960966,-0.7250202157582333,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark52(50.9311759387962,-0.7105780569993669,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark52(50.94817454926951,-1.019090970805189,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark52(50.97220399743867,-0.5082761058206415,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark52(51.02109404345151,-1.412504382259371,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark52(51.0256469682748,-0.9359551236512127,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark52(-51.02703772076342,-0.791905199616511,0.05866783215052952 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark52(51.02765600386044,-0.25583928348982266,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark52(51.03356948855432,-0.46289414780162375,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark52(51.049791711018315,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark52(51.06102458849585,-0.776729574712224,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark52(5.116656892525325,-1.499999999969595,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark52(51.171208370196524,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark52(-51.1901729402084,-1.2131237490475923,-1.0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark52(51.355793493670845,-3.8449191623083425E-7,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark52(51.37774180038401,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark52(-51.384122329580265,-1.4464688447369467,-0.9999999995569805 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark52(51.40314913792702,-0.8092803391166551,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark52(51.45682762156312,-1.0362793421407446,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark52(51.496692705205504,-1.0611297836352513,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark52(51.52548772556514,-1.4828299081734337,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark52(51.59905120342104,-0.2371732909349491,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark52(51.62017563963042,-1.0843863997526444,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark52(-51.63405228722132,-1.1912917791276278,0.0660510535874721 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark52(51.69142239119218,-1.4906990034821552,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark52(51.797388442233284,-0.09484998346019324,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark52(51.800466095160175,-0.612053620750558,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark52(51.80304615632326,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark52(51.81717885798108,-5.1049995055524294E-6,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark52(5.1903279353663985,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark52(51.94442245315635,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark52(52.078612556170626,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark52(52.08447073732438,-0.506147654063094,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark52(52.11744493643638,-1.1376388948625493,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark52(5.2141358806287315,-0.7485736882259459,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark52(52.177195805474405,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark52(52.1964520061656,-1.236221797117949,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark52(5.226041379573393,-7.852852667459025E-16,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark52(52.264824278696814,-0.7023576529131651,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark52(52.295294972286,-0.4596164181174487,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark52(52.308561172359816,-0.8570859926540999,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark52(52.32405937936781,-1.4195834985858795,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark52(52.328953552037746,-1.1106892540430073,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark52(52.402145971651436,-0.8385441007480807,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark52(52.40369728018014,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark52(5.24099886049113E-15,-0.64056126616587,2.8947542266320534 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark52(52.424381291055056,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark52(52.47923799448739,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark52(52.506655271630315,-3.607510962044126E-8,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark52(52.519358698334685,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark52(52.56612112887444,-0.1492199691240705,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark52(52.58875997339672,-0.10018053195345235,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark52(52.60049832077809,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark52(52.706528530187875,-1.2458442551074755,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark52(52.755584719891715,-0.00608863285613559,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark52(52.765648652077516,-1.113611396060488,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark52(52.76815676635515,-0.40513913728658046,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark52(52.78764719488291,-0.8373648675481604,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark52(52.79338392114136,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark52(52.798758128759744,-0.027081277523663516,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark52(52.83368369175366,-0.7785709039676192,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark52(52.838958731248596,-1.1927194840737751,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark52(52.93222267580907,-1.2288656517563474,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark52(53.06821518168928,-0.7260046722957725,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark52(5.313267849733403,-0.5713059427641978,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark52(53.2066273831281,-0.4023438302900315,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark52(53.20791350868569,-0.49591232328099233,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark52(53.22589069924601,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark52(53.24012538878177,-0.02171019656720069,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark52(53.295134123720565,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark52(53.301511380789485,-1.0099762260144654,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark52(53.30500770437442,-0.09563407165173526,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark52(53.30963981149915,-0.3475200149050721,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark52(5.332249081000077,-0.5267811452287474,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark52(53.32987667053269,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark52(53.36690698274228,-1.1174382838990917,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark52(53.412956641861825,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark52(53.479263891480926,-0.37685052467610164,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark52(53.483776398108354,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark52(53.51990491099065,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark52(53.529913201709704,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark52(53.62596219876755,-0.46070877367360785,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark52(53.639511531527006,-1.367012772119322E-7,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark52(53.65385163592964,-0.09129688330855856,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark52(-53.66689346678662,-0.17342084658145818,3.377017006114542E-226 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark52(53.692861525498216,-0.7329035408538545,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark52(53.72594566205285,-0.1704974170638076,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark52(53.7420909490678,-0.8816668349407948,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark52(53.77573161791575,-4.507838226225612E-9,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark52(53.854769771991805,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark52(53.85861445795669,-0.8997613405807696,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark52(53.891135901699016,-0.13195747576069916,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark52(53.92302968041696,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark52(53.93216147321175,-0.4295891874165054,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark52(53.954341896242624,-0.6145438714239235,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark52(53.966352256700766,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark52(53.97350170060932,-1.153530084944208,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark52(54.00655118767354,-0.3463819926969757,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark52(54.10077821389521,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark52(54.126208533614374,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark52(54.215796424093924,-0.35501029163433007,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark52(54.25989458639137,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark52(54.27664354249529,-0.9270966387382487,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark52(54.30703333590071,-1.2945690275880044,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark52(5.432225410496187,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark52(54.34630306695421,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark52(54.37839058559857,-0.13237003211191833,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark52(54.43981508760737,-1.191568981087053,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark52(54.49979354089529,-4.2282309633140527E-7,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark52(54.53422286221661,-0.17093080780040992,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark52(54.54072322470224,-1.2115479318801041,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark52(54.55676309212173,-0.29501184059215646,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark52(5.456412097829698,-0.22529784445582868,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark52(54.610368249247855,-0.1745929750868549,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark52(54.6273574810767,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark52(54.6638904243334,-0.8001412603242404,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark52(-5.467508585359474E-5,-0.0023336505781262912,0.04438673958428019 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark52(54.706928413577366,-5.165568902574613E-5,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark52(54.72120014646146,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark52(54.854087695419366,-0.5473086192256886,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark52(5.4865362595802445,-0.14585369339404614,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark52(54.89078171104039,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark52(54.891587335164274,-1.4085248156028405,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark52(54.90290281264967,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark52(54.90726212487624,-1.308519965698851,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark52(54.910727496766455,-1.458736155245731,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark52(54.93419216791808,-0.1943872414869479,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark52(-54.99036208066191,-1.3505056239429458,51.469990694081794 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark52(55.07378365280397,-0.0966905578259381,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark52(55.11537163097145,-1.4471795516672046,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark52(55.13352037935903,-0.8273316604132219,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark52(55.19843230158651,-0.13607326034510542,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark52(55.25888319981888,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark52(55.293596708835736,-5.683572827322111E-4,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark52(55.35685151114843,-1.1128336055446755,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark52(55.36103480355888,-5.901250943089343E-6,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark52(55.37698091324134,-1.0358175316837617,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark52(55.392800413419394,-0.07040560401212304,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark52(55.445459167460356,-1.8803781488475196E-8,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark52(55.46969965701027,-0.7758803086583808,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark52(55.49558701900216,-0.1471907022067815,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark52(55.50339756127439,-1.0673639901407554,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark52(55.504068428858545,-1.262331429188393,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark52(-55.56617688163066,-1.3093330411678803,-1.0545326910719255 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark52(55.65979998523599,-0.7528323123479463,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark52(55.661070020915915,-0.364069243387366,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark52(55.735678668027276,-1.3832279216260748,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark52(55.79025992760981,-0.2934662916454842,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark52(55.80039248880663,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark52(55.82647803486631,-0.9908072893872344,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark52(-55.94665948012813,-0.002344867620852803,70.73122391489662 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark52(-55.97464739435496,-1.4250405964438317,-1.0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark52(56.10414134678871,-0.3826080310843085,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark52(56.10725604932435,-1.2442838541678825,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark52(-56.12838644799928,-1.4768336528953858,-0.024965090659599138 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark52(56.13170036654387,-1.4097331793315675,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark52(56.375318425238135,-0.15449393884717377,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark52(56.41892036744821,-0.014185042432285577,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark52(56.46023788150228,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark52(56.478621682180574,-0.41761005812827534,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark52(56.51564157669954,-0.6165053748006946,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark52(56.578110514959235,-0.25030210193274827,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark52(56.601462244396885,-0.8474176728128127,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark52(56.618842283203065,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark52(56.64853444353932,-1.3476763913208223,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark52(56.69113395023044,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark52(56.714181768263984,-0.8335159372698655,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark52(56.73925335771024,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark52(56.74776422054032,-0.5632319488917674,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark52(56.763000494094456,-0.6967643289569176,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark52(56.9006114744945,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark52(56.90888126835351,-5.127712215660978E-10,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark52(56.976490007780825,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark52(57.00527078669725,-0.8201434996337058,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark52(5.701519178878129,-1.2162629334661492,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark52(57.066932532074425,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark52(57.104897950551305,-0.46178379077843457,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark52(57.14708283308997,-1.2878098953548403,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark52(57.219614089588966,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark52(57.24023618847397,-0.20328838818927747,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark52(57.30395259574678,-0.08167528648866657,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark52(57.32744029359276,-0.11079847069246185,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark52(57.32842944542355,-0.4513694762844409,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark52(57.33192506898503,-1.39350037839057,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark52(57.36306811696931,-1.2069461924532754,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark52(-57.3661724976711,-0.8389774711869435,-52.25938810486169 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark52(57.36892900886389,-0.7746561371478222,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark52(57.383584578665506,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark52(57.38535744826059,-0.003619430596351947,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark52(5.7393072190709375,-0.5930619975918994,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark52(5.7430142462584115,-0.45116153427885614,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark52(57.45877834374102,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark52(57.46586244142841,-0.18552832996534263,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark52(57.48258852960669,-0.627227331900119,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark52(57.512868584160856,-0.4873693191107691,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark52(5.757901412617201,-0.7767346589172064,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark52(-5.764686125220605,-0.25367916592313833,1.0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark52(57.6897142142914,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark52(57.75099999657564,-1.3101329064400176,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark52(57.88873242691034,-0.8325316863381289,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark52(57.9038502770652,-5.624541617041672E-8,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark52(57.92750527410485,-0.06352712072535849,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark52(57.93100357995607,-1.3482977395631792,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark52(57.93955395016519,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark52(57.96723219602356,-0.7795798692781121,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark52(5.798160197479136,-0.19967742153818674,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark52(58.00867569067066,-0.39534351962526504,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark52(5.802363362581019,-1.3662739570700495,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark52(58.0647032648508,-0.1518407802022242,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark52(58.105056350725334,-2.5742362804900164E-9,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark52(5.810800179127497,-0.24099256643582606,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark52(58.10965007576158,-1.0078798800541797,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark52(58.15390018419376,-0.02623483690435746,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark52(58.17707252783353,-0.7896803981540517,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark52(58.22458150566439,-0.12536940794254592,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark52(5.829641848852333,-0.28448980120461576,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark52(58.30003943849158,84.25176871950202,32.08623905958626 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark52(58.31411817240655,-0.5486523858808106,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark52(58.33479037956167,-0.5678127009782514,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark52(58.35064603816028,-0.8505233434739683,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark52(58.417302087513576,-1.4091668953368726,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark52(5.846657113209957,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark52(58.481701068542634,-0.7013472886056036,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark52(58.49051889026953,-1.1511265026597517,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark52(58.581710289283414,-0.8735864656344083,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark52(58.612798844091884,-1.0183560854525444,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark52(58.619221838989965,-1.2853802247172443,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark52(58.67817554162977,88.39686375828416,24.028049639609648 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark52(-58.745160945550644,-1.2793520874995208,-1.0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark52(58.76464655585639,-1.0146739478357603,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark52(58.92486196772117,-0.003262521884854314,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark52(5.897857806782341,-0.3576506071078853,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark52(58.98015118562907,-0.2841687793143244,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark52(58.990443172525744,-0.504186048813312,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark52(59.01821067620395,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark52(59.019833086104825,-1.3822602961455632,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark52(59.045649159286114,-1.3945509519753485,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark52(5.904574110549547,-0.7241041125439756,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark52(59.05668408138828,-0.6758747151578525,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark52(59.09031399792151,-0.32127554081318366,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark52(59.098778216259944,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark52(5.911122516714414,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark52(59.17535834461944,-2.5717318233432695E-8,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark52(59.27632839267059,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark52(59.32841593563843,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark52(59.32859855651691,-1.351054987364229,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark52(59.33043022809598,-9.613965787532077E-16,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark52(59.34083755926869,-1.046530793185875,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark52(59.4206276708841,-0.5386197114811249,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark52(59.52443806905568,-1.7037704111283579E-9,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark52(59.535365937070026,-0.5021411229811426,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark52(59.54483128804526,-1.424944836100078,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark52(59.547289811453055,-0.03787273928182344,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark52(59.557872731424055,-1.4999999999999885,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark52(59.67336283510397,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark52(59.7044176724002,-5.634304962367433E-10,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark52(59.7333385410844,-0.724116826517137,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark52(59.750587868078384,-1.1268440505972923,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark52(59.77818525571274,-0.9048494241880896,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark52(5.981881734486578,-1.0185492488043406,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark52(-59.85798382559846,-1.489903305789866,-1.0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark52(5.98800607920804,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark52(59.88875770613055,-0.043523181816826906,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark52(59.894578450809064,-0.11013414860774162,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark52(-60.02901585120092,-0.6271828009160623,-0.06255511896002165 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark52(6.003109729695041,-0.15935900888166632,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark52(60.05993936870365,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark52(60.07963229693335,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark52(60.13952130518068,-7.544143696748529E-10,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark52(60.15056863820386,-0.2932597602527498,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark52(60.218198551901054,-0.08804762875433744,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark52(60.223169856664214,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark52(60.26922852639217,-1.3593227420248581,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark52(6.029822346253374,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark52(60.30487700690056,-0.5656678795723384,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark52(60.314670788475325,-0.897266156433373,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark52(-6.031857190877713,-1.038257619975281,-53.298299540297606 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark52(60.35045253092133,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark52(60.35716158078459,-1.0153886616209528E-9,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark52(60.39668376773038,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark52(60.47734227831822,-0.5421670614887688,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark52(60.48532043804905,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark52(6.052598537859797,-1.2799724457222963,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark52(60.58777689506735,-1.058208861600889,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark52(60.6229274536893,-0.7559434112287526,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark52(60.710225316998134,-0.3132411140118023,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark52(60.75977784209802,-0.9825490646105688,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark52(60.76018544005286,-2.0945286641201653E-7,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark52(60.76452115995684,-0.2937336106833599,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark52(60.80525387127946,-1.0889440891966662,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark52(60.81447979739472,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark52(60.84274349583572,-1.3746083415416166,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark52(6.092127440091556,-0.566367980870277,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark52(60.94785604614452,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark52(61.02876119723198,-2.048153307068323E-4,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark52(61.06487193847447,-0.45246221779423873,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark52(61.06669419733055,-0.2857340164727247,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark52(6.108448244528091,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark52(61.10838734056558,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark52(61.126967949154846,-0.8448015467897338,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark52(61.13453826658148,-4.629371977714301E-9,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark52(61.16908620195008,-1.1424872613888626,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark52(61.25845673876839,-0.8333106766249756,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark52(6.127915884744988,-1.0081544067409758,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark52(61.29288010291759,-1.4227853082116724,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark52(61.299328698523794,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark52(6.130998702246018,-0.21802509948460624,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark52(61.34352731108697,-0.49563315946062936,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark52(61.37764503171334,-0.06661181452853526,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark52(61.4493193523846,-1.4840555958133939,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark52(61.49615228940073,-0.7499383647791418,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark52(61.55634008086298,-0.7578126865276031,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark52(61.619655860300355,-0.5672867566043421,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark52(61.66095626151791,-0.23222205430038667,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark52(61.67507099559444,-1.076139366293475,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark52(61.68739069448345,-0.5385489977296913,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark52(61.696112930089555,-0.7624011879201333,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark52(61.72812977024199,-0.3415601714784664,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark52(61.859841175451436,-0.38935311022068575,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark52(61.87449675299803,-1.270037874398872,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark52(61.87939555085193,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark52(61.90379762082676,-3.475249575524802E-8,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark52(62.06408787298031,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark52(6.207366646293465,-0.9932302833418789,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark52(62.07469557216254,-0.9984913181528157,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark52(62.106739090192406,-0.7574758615750437,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark52(62.18006265287092,-1.9973198462186677E-5,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark52(62.195025374163436,-1.2126491387134624,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark52(62.20366641680782,-0.898300546763981,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark52(62.20864735145946,-1.3129221594391396,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark52(6.226550144496388,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark52(62.277432246191836,-0.7862562976874401,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark52(62.29423766208012,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark52(62.31436545985443,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark52(6.236674524281739,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark52(62.412606467464194,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark52(62.44054094687107,-1.3833088426390225,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark52(62.477901161312225,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark52(62.489784487941876,-0.8935137185661031,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark52(62.51274727758184,-1.1982654118142437,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark52(62.52176176375599,-0.06725159589086616,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark52(62.57324146987466,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark52(6.2674108812855005,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark52(62.77246109129058,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark52(62.78468261628808,-0.193895813944863,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark52(62.820408427967195,-3.7930595685412584E-16,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark52(62.82977010723499,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark52(62.83207817297792,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark52(62.835055563176866,-0.0030291521411596844,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark52(62.91212052458718,-0.22084704066706512,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark52(62.92385699060131,-0.4457774641236978,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark52(62.9331977734677,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark52(62.976695254601864,-0.4906224110127304,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark52(62.97794704574443,-0.3014707616124923,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark52(62.9784397348202,-0.5849456492448555,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark52(62.989119956914976,-0.14485709489134196,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark52(63.04532573822951,-1.4721723651598153,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark52(6.306630356259248,-1.3407715383172203,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark52(63.071113505557946,-0.41847642784075845,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark52(63.12393861560051,-0.6255747639385696,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark52(63.186597435177646,-0.6963430897469776,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark52(63.196067090168896,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark52(63.197875400234636,-0.6235107192791116,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark52(63.213682632281504,-1.4062825159416676,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark52(6.322237855746991,-0.038508869148795866,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark52(63.31936571740931,-0.3138410120114514,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark52(-63.39476237842044,-2.220446049250313E-16,0.03851777785537619 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark52(63.411648267367326,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark52(63.44699601395811,-0.5038877005697486,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark52(63.45256108936215,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark52(63.456086068476964,-0.60795654087873,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark52(63.47265142537256,-0.05907232402394623,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark52(63.50377272254349,-0.30179249358168914,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark52(63.50749294546645,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark52(63.52013081894761,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark52(63.5414393767563,-1.106733358534863,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark52(63.55822345292865,-0.3447679541865072,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark52(63.59091443657576,-0.8440044495752232,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark52(63.66455440495163,-0.1815998721834064,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark52(63.704301236158074,-0.06922829374495354,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark52(63.742983540009774,-0.021549555338597925,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark52(63.80399664121546,75.91558023517223,65.87233628365726 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark52(63.82038345382017,-0.7121650746452417,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark52(6.382203390704192,-0.06147804325571469,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark52(63.85358123283521,-0.3441860159398189,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark52(6.387479262769062,-0.5641910406315844,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark52(63.92633971713406,-1.088594961869979,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark52(64.01638877152294,-1.1528224303504473,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark52(-64.06585593494914,-0.40204742009223793,1.0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark52(64.08052556328192,-0.8941509787762305,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark52(-64.11049276762331,-0.41144643011637516,16.07524294693129 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark52(6.412088364555174,-1.4305120615057532,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark52(64.12218012062388,-1.4999999999996376,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark52(64.15146751871251,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark52(6.418651415971482,-1.3534932918226588,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark52(64.28498528723392,-0.6205892092888456,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark52(64.29793840397508,-1.4837741963477162,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark52(64.38623396790433,-0.16509181181299937,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark52(64.41698108588318,-0.3398546288066244,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark52(6.4420713767209925,-0.07207405606682649,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark52(64.48342154818354,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark52(64.51738176860363,-0.2689549680208261,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark52(64.53261297494363,-1.4837234302656785E-5,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark52(64.55190662462867,-1.2388650473201646,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark52(64.56889166250237,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark52(-6.461986284587823,-0.9584474641780645,-43.13123526453515 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark52(64.61994145868852,-0.671394732455326,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark52(64.63057044239656,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark52(-64.67809856245859,-0.20080756739384498,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark52(64.70218511615002,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark52(-64.71657892085852,-0.15151547909540852,1.0000000000000002 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark52(64.73352966937728,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark52(6.474969130279723,-1.338019165380931E-9,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark52(64.75874110943295,-0.7767169371530969,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark52(64.76694513143256,-0.3083534000441551,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark52(64.79090262397523,-1.4092293171491228,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark52(64.7939857573565,-0.738028208095241,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark52(64.8266031090947,-1.116950981506399,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark52(64.85217066167453,-0.0987985283792927,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark52(64.85492090895028,-0.2736420135539479,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark52(6.489105101609029,-0.019575984260816304,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark52(64.91794999781345,-1.741926867397402E-9,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark52(64.94791573328096,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark52(64.99056355768985,-1.1738491365639937E-8,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark52(65.00131377445608,-1.2881406119713473E-9,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark52(65.11940791240207,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark52(65.13319951896122,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark52(65.16139877527807,-0.01119522793157035,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark52(65.17373012590167,-1.4283462625674037,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark52(6.520364646255501,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark52(65.2088787035836,-0.7096083414263885,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark52(65.24862770912654,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark52(65.27932023739939,-0.7751310625813126,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark52(65.42941839985602,-0.42661617439305655,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark52(65.4690005989003,-1.45405670891118,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark52(65.48222633851162,-0.3963492566985156,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark52(65.55772188029124,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark52(-65.59214103445416,-1.499875261508376,-0.9999999999999998 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark52(65.6242445265051,-0.13311579566213094,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark52(65.6302691294261,-0.8472621740069473,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark52(65.64287950070425,-0.646896539302851,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark52(65.65364816340752,-0.6038434331621354,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark52(65.6742249645923,-0.46259911873733206,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark52(65.77696717689756,-1.4769544669265855,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark52(65.83956406468874,-0.530082706195742,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark52(65.89907749763842,-1.0729345038758278,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark52(65.90913288090866,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark52(65.95141372707116,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark52(65.95829262894662,-0.9739266596013474,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark52(65.96175739473988,-1.326306255321735,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark52(6.596698654577835,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark52(6.599178209852912,-0.4373417011459161,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark52(6.600581241175533,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark52(66.06596893600576,-0.4410464680328836,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark52(66.10370205777754,-0.5088702378587637,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark52(66.1044322515034,-0.6713609936745595,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark52(66.12074967192106,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark52(66.15154564635858,-0.6137554455241649,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark52(66.20897651762908,-0.634246691837987,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark52(66.21891089977717,-0.023965611663330666,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark52(66.26646153477321,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark52(66.346607923965,-0.24370483663191622,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark52(66.37499281217865,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark52(66.3975270776429,-0.7497173055261754,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark52(6.642987573044053,-0.5180831702081867,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark52(66.5046878551382,-0.3644903921246766,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark52(66.53666038598215,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark52(66.54697918457552,-0.0031629815129016973,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark52(66.54809351555372,-1.4999999999999822,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark52(66.63603126044707,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark52(66.65060540091272,-1.3414577243005779,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark52(66.66669621315998,-0.22779311145786973,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark52(66.68009351313917,-1.1351037726226982,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark52(-6.672164428950438,-0.5626871530888979,-1.0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark52(66.8135457393121,-0.717161881758603,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark52(66.82582298096773,-0.3973456351252332,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark52(6.6855471499733214,-5.286497888885114E-10,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark52(66.85652940425953,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark52(66.86260154889743,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark52(66.8862503352022,-1.3768723539618903,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark52(66.9898264969901,-0.30112920018303635,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark52(67.00277176259587,-0.09631319682340278,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark52(67.06908969278425,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark52(67.08878089491199,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark52(67.14205753167138,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark52(67.15502058278884,-0.5144916976063367,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark52(67.15803294523711,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark52(67.1715270922709,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark52(67.22801249573703,-1.4672472413727813,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark52(6.723242385586417,35.96298927586105,-50.62429143546705 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark52(67.24968949304494,-0.5933927031670263,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark52(67.25475356037545,-0.951807760805581,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark52(-67.25615724046123,-0.651886828108791,-0.04134942836634581 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark52(67.35380617029722,-1.0837519475655029,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark52(67.36310636517992,-0.6152221170663199,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark52(67.40458042677062,-1.138091166037583,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark52(67.42565262318321,-9.738579211169245E-6,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark52(67.43198112860819,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark52(67.47881454308572,-8.17481299261624,68.2007251374597 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark52(67.50275366656336,-0.42789812836110636,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark52(67.50763584091541,-0.20394356863468555,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark52(67.52295768213835,-0.11110171816660314,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark52(6.756610250194058,-1.2657023176400228,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark52(67.61995427441634,-1.2391099633107328,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark52(67.67744754123791,-0.132794014425472,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark52(67.6774652870057,-0.6894570672982041,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark52(-6.77130160999781,-0.17997383803406808,5.551115123125783E-17 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark52(6.773847608614608,-0.3189332274235719,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark52(6.779808675589379,-0.6994579723397485,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark52(67.81802373885472,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark52(67.9663235373799,-0.9646239201456167,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark52(67.96988897851742,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark52(67.99416226590412,-0.7059999587055046,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark52(68.0256273622501,-1.0793295615639533,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark52(68.15129580221807,-1.1750460431310614,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark52(68.16957009188143,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark52(68.17904471172798,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark52(68.19298456960007,-0.1796538187530814,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark52(6.828192580308709,-0.5567415452491999,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark52(68.29624740572496,-1.4826649568417452,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark52(68.38959701591095,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark52(68.60357860247333,-0.9239749181364658,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark52(68.62331547776833,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark52(68.6622897183654,-1.2914389431436684,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark52(6.868283696211691,-0.798851279009885,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark52(68.7299155182202,-0.030730543588676884,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark52(68.7567863693161,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark52(68.77248364190004,-0.5038915439388347,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark52(68.77640977234324,-0.5199177827635204,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark52(68.82515445096507,-0.7512649600666759,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark52(68.84912192300989,-2.793537976966835E-9,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark52(68.86660867511509,-0.16471965800044863,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark52(68.90398009265994,-1.4945831896418964,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark52(68.92663250909362,-1.336126301468399,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark52(6.893214831571171,-0.10916578080440474,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark52(68.96254267252192,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark52(68.96803391177626,-0.7989958237445949,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark52(6.898340855817949,-0.494297870550664,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark52(69.04128875373854,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark52(69.04447558720622,-0.6424976032370289,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark52(69.1170730677365,-0.2626154164025234,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark52(69.13133850045901,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark52(69.32751852723601,-0.3040646439983874,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark52(69.39740310760831,-0.3769643982863262,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark52(6.948513422510921,-0.41916210513371044,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark52(69.49560726059224,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark52(69.51224993897516,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark52(69.5764549869879,-1.1755025841397746,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark52(69.61176216816912,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark52(69.63142539869119,-1.4800747670315582,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark52(69.67136016188473,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark52(6.970884400040262,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark52(69.72967749814393,-0.37408271604371635,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark52(69.76334733530862,-1.038962569595185,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark52(69.78363650161589,-0.7125555500772439,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark52(69.80994203989536,-1.10340984321576,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark52(69.81080544431359,-0.9675600051696058,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark52(69.88461105058136,-0.761032284976209,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark52(69.89984730109751,-0.7409946235605205,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark52(69.9146106880705,-42.60243708996148,29.835302895266977 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark52(69.99429778933225,-0.17210030591360237,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark52(70.02635962726738,-0.3731503452392513,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark52(7.005969966981951,-0.7015230431838546,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark52(70.08653796304806,-7.3418010123235485E-9,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark52(70.08922221843255,-0.5075583334014286,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark52(7.009052719825146,-1.0467374655308586,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark52(7.010238500895795,-0.778737827764341,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark52(70.16546472262146,-1.1999620383957925,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark52(70.17815796161557,-0.8768122199863662,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark52(7.019108529594562,-0.34531176921482754,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark52(70.21631000866637,-0.05835673040757361,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark52(70.22982064003178,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark52(70.27605464126961,-1.498512588422322E-9,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark52(70.30356960846774,-0.7704081945321093,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark52(-70.33479162981,88.2984731838749,-76.41659707272545 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark52(70.35967812494188,-0.5669610894655948,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark52(70.3618915994225,-0.31096957628562694,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark52(70.39222418486284,-1.163649601983444,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark52(70.4190624341515,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark52(70.45109501592043,-1.0321537683078144,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark52(-70.49281122705108,-0.9178682802911079,-1.0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark52(70.5567208208466,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark52(70.56858072786589,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark52(-70.57904229986988,-2.220446049250313E-16,-0.616801214685325 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark52(70.61313460196112,-0.8551485782939791,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark52(70.62357547128855,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark52(70.63358213147959,-0.33816969684582965,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark52(70.66099106880642,-0.07528095483831088,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark52(70.6713471045359,-0.12968793538590884,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark52(70.71508223691251,-0.7375048706932472,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark52(70.73832194182583,-0.5756443650896852,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark52(-7.08095599379931,-1.079363539314674,0.8980570071287595 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark52(70.84669507831714,-0.08039537860094659,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark52(70.94685626007336,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark52(71.01644508994954,-0.8797488086881557,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark52(-7.105427357601002E-15,-0.6165542415235485,0.023080312524980634 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark52(71.1405940978205,-1.1811128080341007,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark52(71.17037020148894,-0.9708603180242195,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark52(71.18873767035515,-0.8348747231493601,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark52(71.36933552966934,-1.4466169884103692,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark52(71.46376765809254,-0.8322450083743945,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark52(71.46808199419459,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark52(7.148320694893158,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark52(71.48945825110592,-0.15782547433116,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark52(71.49344582317843,-1.0875726524532283,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark52(71.49973640706952,-0.5271394758183754,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark52(71.51237014825617,-0.06270617325771433,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark52(71.53253819576997,-1.386879406490828,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark52(71.55750840920884,-1.2148798622543993,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark52(71.59248374229571,-1.0206865120883322,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark52(71.68314951144956,-2.760434099683056E-4,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark52(7.17979189663869,-8.63695197264461E-9,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark52(71.79836582748814,-1.4147294727838537,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark52(71.83310599665057,-0.6010079667449162,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark52(71.86529239172364,-0.35495266823714644,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark52(7.191135291337218,-1.1418422707212779,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark52(-71.94586110755408,-1.4817803814348345,-0.9995670435240546 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark52(71.98287950440819,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark52(72.00544166414011,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark52(72.00829208034253,-0.08723953405630791,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark52(72.09661718201565,-0.8806084620993122,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark52(72.12849284271937,-0.6667474358784493,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark52(72.1950010339415,-0.7761823886232009,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark52(7.221177907438459,-0.03566536391124586,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark52(72.21483806743512,-1.4468538864057265,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark52(7.222478896562509,-1.2536664662649595E-7,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark52(72.25922704461871,-1.1963873788986485,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark52(72.27639958189289,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark52(72.32800177113603,-1.2751869936993436,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark52(72.36970754598123,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark52(72.43324270565157,-0.7285821070435139,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark52(72.45321453119797,-0.3973874569678202,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark52(72.46240475840256,-0.7289541212752757,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark52(72.47119407266668,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark52(72.5090006562616,-0.5076051154638463,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark52(72.55570024176882,-0.3037378388187477,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark52(72.67541974042791,-1.4321230212810434,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark52(72.7163633821461,-0.12566140854904692,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark52(72.73173667164255,-0.4633209682312085,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark52(72.7872024187665,-0.7623629267228438,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark52(72.78753912735603,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark52(72.91725904225555,-1.1909123008162794,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark52(72.92018184698944,-1.3386734827059734,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark52(73.0656133586064,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark52(73.0706830545565,-0.9320127956998794,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark52(73.08017233861926,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark52(73.08037399040013,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark52(7.309718545997157,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark52(73.10781997965063,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark52(73.13038743807542,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark52(73.13602708302054,-0.6200517557854859,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark52(73.35547605025872,-0.12348038678473472,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark52(73.3640473610868,-1.076630498368171,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark52(73.44696952192541,-0.4949425063426611,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark52(73.50932826250852,-0.17483139989501262,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark52(73.57257907607132,-0.46271032199604556,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark52(7.358763828295196,-0.2844597576398703,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark52(73.60181978845353,-0.13146350055096412,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark52(73.6158048517035,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark52(7.36389324838234,-1.4540782620844084,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark52(73.79142567509223,-1.1944651678400575,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark52(73.8306670297053,-1.2580354048959368,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark52(73.83655594073227,-0.7371562870592991,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark52(73.85442389444566,-0.611899823744962,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark52(73.86245313766452,-0.11486845582455074,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark52(7.389535341997276,-6.881782768471301E-9,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark52(73.92464026773717,-1.1450372103346496,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark52(73.93350609158631,-1.168863226084335,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark52(73.93415910121077,-0.32718531824981345,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark52(73.98403939940978,-5.534984429269705E-9,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark52(73.98598297501587,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark52(73.99306633699776,-0.08010055371990706,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark52(74.01797171563481,-0.1989021142570965,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark52(74.02891950793935,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark52(74.07887150785146,-6.440171110623484E-10,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark52(74.0876220415592,-0.2818249518898259,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark52(74.20323556932121,-1.1247811429709458,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark52(74.20423013556254,-1.392801870251077,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark52(74.22256557377202,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark52(74.22875691782903,-0.5087797469169715,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark52(74.2855197814674,-0.8871567856458,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark52(74.36021944910726,-0.8435250529683724,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark52(74.37005721592524,-0.5520487303899291,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark52(74.44559374903925,-1.6259948878052433E-8,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark52(74.53010691312971,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark52(-7.455895101514585,-1.2216668791083523,0.4165735305645206 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark52(74.5617945241003,-0.5590197652207234,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark52(74.57624676315365,-0.49448750634854527,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark52(74.57773807094611,-0.6921023087422118,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark52(74.58534323964838,-0.26102387552425577,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark52(74.60254921621404,-0.4429612957660396,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark52(74.67017335924129,-0.6665830751296937,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark52(74.7275061671229,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark52(74.75896241743703,-0.16002703077668912,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark52(74.77066498303509,-0.04305148227464173,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark52(74.77255605632877,-0.23602613350081347,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark52(7.480478442455222,-1.1674995905372523,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark52(74.82191661437139,-0.3810762739865381,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark52(74.86506666872427,-0.47559211703643633,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark52(74.87934880008794,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark52(7.488830365179279,-1.5950706011085703E-7,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark52(74.89982121407661,-1.0192658165657633,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark52(74.98795710982768,-0.3354492896406929,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark52(75.04572371891754,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark52(7.506092402139487,-0.4555975966433463,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark52(7.511723037105861,-0.002226744799464643,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark52(75.15330109483727,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark52(75.19391059510076,-0.3647663893620319,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark52(75.24366440214689,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark52(75.25476495412053,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark52(75.36954206307652,-0.2376173788454256,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark52(75.40471668616922,-0.3925342653302626,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark52(75.4378459153167,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark52(75.46176324473406,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark52(75.54402771423396,-4.837401780615838E-7,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark52(75.54985186760176,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark52(75.59122434455898,27.241172131021756,-77.60183993163949 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark52(75.64921521886606,-0.015534683981684339,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark52(75.66041665703861,-0.4817623420101427,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark52(75.66573602749578,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark52(75.67431392036481,-0.925784019760219,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark52(-75.74668628582286,-0.003204932158206382,1.0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark52(75.7599868579189,-0.18820370684365173,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark52(75.76067633615867,-0.25367927462944806,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark52(75.82460950300947,-4.3519356486931397E-7,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark52(75.83612246441739,-0.0037969345935542696,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark52(75.88611811577921,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark52(75.9270739939812,-1.1582082091898543E-5,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark52(75.9414646923441,-1.2670235882045235,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark52(75.94263333760804,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark52(75.99692693658423,-1.098275916599121,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark52(-76.00988647209212,47.71052505051088,-70.39152503539236 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark52(76.21630835219511,-0.38829003697972553,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark52(76.27173060768268,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark52(76.2842361966458,-1.3306090678390936,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark52(76.29981885045743,-0.34945356350748114,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark52(7.635587178107244,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark52(76.37493111939472,-0.41657767805658497,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark52(76.39293271490587,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark52(76.41259797499038,-0.9688392915380604,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark52(76.42450257205113,-0.3078554335135746,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark52(76.53373786342436,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark52(76.5920666664442,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark52(76.64765937684211,-1.0362529362603716,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark52(76.64878397021826,-0.7377925501234462,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark52(76.65153085095724,-0.4525630681900589,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark52(76.65743413266065,-1.0105087429440118,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark52(-76.69869431810088,-1.045769333873272,-43.28138691045207 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark52(-7.673025233774339,-1.0582806825455955,-57.53308408519524 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark52(76.76549615549237,-1.1068351793682893,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark52(76.7835410936269,-0.05292969173889822,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark52(76.82768615288924,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark52(76.836366317691,-0.6679880971641801,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark52(76.8608898647912,-1.369948682399106,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark52(76.87627463711382,-0.14436426416694825,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark52(-76.91160116157894,-0.8578400037906371,-58.40790660839124 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark52(7.707088189566917,-0.05281762564278836,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark52(-77.09998926765944,-0.09952057820534768,1.6155871338926322E-27 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark52(77.1060109915027,-0.5812965876596694,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark52(77.13728687439811,-0.2641961283275087,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark52(77.14979049337009,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark52(77.17097059149631,-0.23550947659831678,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark52(77.21093936121977,-0.6652225668589296,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark52(77.21494790514501,-0.9828768764983331,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark52(7.725717998108109,-0.0510896920299162,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark52(77.34479998047559,-1.0133331451108294,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark52(77.37107276081392,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark52(77.38673963015478,-0.20625658660249258,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark52(77.4059308193005,-0.4502502243415929,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark52(7.7432893493836445,-0.9610645474864761,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark52(77.43613518005756,-0.890128481609139,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark52(77.56010483497975,-0.47356130360314175,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark52(77.58848067895468,-0.7749403673207631,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark52(7.7593616974332065,-0.7257932990589389,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark52(77.59827645316244,-1.1446805955075692,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark52(77.67664641527294,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark52(77.7076774129138,-0.7699530242201149,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark52(7.771421617222634,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark52(7.772119267350712,-0.221765728977026,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark52(-77.81985198358892,-1.4670274171120297,-0.9794741261662494 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark52(77.85229714926356,-1.409166361780521,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark52(77.88765222623041,-0.26861122531938975,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark52(77.91872007259849,-1.4695203960849614,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark52(77.97165819319838,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark52(77.98034158457449,-0.798652053783087,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark52(78.05525205868716,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark52(78.13043963040715,-1.2200225587640665,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark52(78.1528185234215,-0.03223013445667716,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark52(78.19359949854757,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark52(78.21997707716824,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark52(78.22938462664416,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark52(78.23359756065398,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark52(78.23646933987243,-2.0879614719689422E-5,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark52(-78.23897318405793,-1.3342760884688545,1.0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark52(78.25885544703362,-1.06351024288318,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark52(78.40313354967657,-1.4570424261922865,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark52(78.42732139615217,-0.7515911077700175,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark52(78.45164752236576,-0.06481833222476041,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark52(78.46976343384804,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark52(78.49844951594005,-1.440583430563085,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark52(78.5110134838948,-1.3206947951168644,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark52(78.54840863979089,-0.28081889063055687,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark52(-78.56235442922274,-1.4999999999999998,0.9929332603107532 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark52(78.59200436204442,-0.5046620681576712,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark52(78.61043292717201,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark52(78.62580922148537,-0.029686327695294334,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark52(78.66098781824263,-0.5421820253853092,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark52(78.69897551311777,-0.7807178532527903,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark52(78.70413022034421,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark52(78.71921903287638,-0.3599457873868945,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark52(-7.881985789494038,-0.165285075099673,-1.0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark52(78.86492552017435,-0.24425853116352836,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark52(78.9186946343348,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark52(78.94129307983496,-0.9208646991396776,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark52(78.96191626431673,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark52(79.0293466293822,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark52(79.04135871135455,-0.08126958130158357,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark52(79.06695359412598,-0.19231590368700324,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark52(79.13473498999092,-0.3525975801715645,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark52(-79.14219600010597,-1.4999999999999982,-0.0068858526325176585 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark52(79.19076468345727,-1.1156409861518228,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark52(79.28400530966232,-0.9585484288478945,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark52(79.35450685153957,-0.4235518248132709,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark52(79.35545571616689,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark52(79.3830567098855,-0.04640829333239005,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark52(79.39849675412853,-1.4906172927375465,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark52(79.40340415810172,-0.7375518109539865,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark52(79.50021967519478,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark52(-7.950266538115741,-53.850728789570624,-80.88570871856602 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark52(79.5247199065183,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark52(79.54234625132794,-0.20434060123156134,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark52(79.56151621112915,-0.6401609352108153,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark52(79.57935156571061,-1.4999999998353006,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark52(79.63607573371092,-1.3611823418939366,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark52(79.66696431482694,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark52(79.67912126710718,-0.199531632318795,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark52(79.71845715081206,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark52(79.75165345124654,-0.5775205475210168,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark52(79.82477970068874,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark52(-7.991835658074671,-1.157750963539575,1.0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark52(79.92333734714292,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark52(79.97000808064533,-1.0752139061261285,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark52(80.01364550027408,-0.267087580501576,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark52(80.01629303600058,-8.832023119415552E-10,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark52(80.04714206060984,-0.3508136686996086,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark52(80.09092187007542,-0.36007375325781155,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark52(80.10097968436759,-1.0645273788174663,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark52(80.17465326407358,-1.1758437387866674,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark52(80.20111715466943,-0.057374165446997805,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark52(80.2349285393079,-1.0521863695423121,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark52(8.029244145867413,-3.917026506286688E-7,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark52(-80.30921488513233,-1.4995604346382136,-0.4235418018528585 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark52(80.34797258309615,-0.559102827852783,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark52(80.38100814737226,-0.15914722678306764,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark52(80.38994410509264,-1.0925637396574217,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark52(80.40257344683332,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark52(80.42262130306943,-1.038486670311598,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark52(80.51022804422325,-0.34401481895258357,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark52(80.54483881273643,-1.183881083590922,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark52(-80.58204434626656,-1.3269400131151614,0.0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark52(80.64638191042035,-1.0527048124408579E-8,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark52(80.64702292257621,-1.6980285341187509E-6,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark52(80.65781479142441,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark52(8.071865113962719,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark52(8.074203383322667,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark52(80.77252665321532,-1.2767388010141651,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark52(80.77913233374653,-0.9749755405633822,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark52(80.80650383675618,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark52(80.85602156115829,-0.6137011329549988,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark52(8.09437658981107,-0.7757575336139579,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark52(81.02754499552373,-1.3838141429952913,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark52(81.08501780996424,-0.3077120679982315,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark52(81.1015440707053,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark52(81.18666282666038,-91.69473260903145,74.56206191062913 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark52(81.20178031382764,-0.9472185387219696,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark52(-81.20344512205133,82.82024965192335,80.27235412669461 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark52(81.20825183166359,-0.22193599284289967,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark52(81.21914601390071,-1.4323783234508634,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark52(81.22063659910152,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark52(81.2359061495381,-0.923872893504551,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark52(81.26029086219779,-0.8150687998879089,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark52(81.29420977412408,-0.5013780861630153,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark52(81.31004971531078,-0.7406003946239537,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark52(8.13176895163916,-0.333770428269895,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark52(81.36135547908275,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark52(81.40412554948534,55.57094824768035,7.875851561908263 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark52(81.42206850065872,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark52(81.47693182646671,-0.21820092336988406,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark52(81.49000110630834,-0.7548406034565005,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark52(81.5414549181987,-1.413082483620351,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark52(8.154334889869048,-0.45409184988211626,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark52(81.58141406229686,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark52(81.6037372288302,-1.2942780049905007,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark52(81.68770796162889,-1.0642896839492977,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark52(81.71106172332676,-0.26979827398603945,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark52(81.73544447610226,-0.7080628919086731,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark52(81.76561148777432,-0.0068647938844567935,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark52(81.79248999856662,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark52(81.94780481037324,-0.14892149859684783,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark52(81.94897494846977,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark52(81.96198073587101,-0.2564057848018053,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark52(82.02852909666369,-0.852870331588921,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark52(82.07002999901721,-0.7174821370967095,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark52(82.09445502286755,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark52(82.11439191586663,-0.9776946681024272,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark52(82.14967925847537,-0.417232779325981,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark52(82.16067636836334,-1.122304819204885,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark52(82.2144433467544,-0.5790781868410289,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark52(82.24543846677398,-0.44221941849848556,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark52(82.2580950582306,-0.24978937999002682,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark52(82.29555711570646,-1.108202702242437,0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark52(82.3091129664655,-0.8754629497087376,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark52(82.33068442787469,-1.2596868400332448,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark52(82.37892488818258,-0.7711235844233864,0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark52(82.39936799321445,-1.870111918342558E-8,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark52(82.50101732890573,-0.670483460232453,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark52(82.5652048860612,-0.9585013046095696,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark52(82.63209227065687,-1.0066210611713458,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark52(82.66896747523911,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark52(82.71427345269727,-0.9717145410295309,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark52(82.71454057855048,-1.6743261928428909E-9,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark52(82.75082683905732,-0.6264010971398426,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark52(82.76592846070216,-1.2385021463721282,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark52(82.80725327178389,-1.4281283065302834,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark52(82.8413073805595,-3.2905455403621826E-8,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark52(82.84150464557644,-0.9292795711866562,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark52(82.94449357082263,-0.7518399602084429,0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark52(82.96908949558984,-0.40092961680133854,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark52(82.9952656621173,-1.4259899700563512,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark52(83.01269031780532,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark52(83.03816312943871,-0.06327619205192647,0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark52(83.05559155235872,-0.5970590926598582,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark52(83.06278354964364,-0.5342598433173107,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark52(-83.07426755191787,-0.7408887034690479,-2462.099577460717 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark52(83.07741068805171,-1.2951044574902224,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark52(83.0831984304788,-1.0821695090727594,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark52(8.30833510890352,-0.1993873186926285,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark52(83.10777094474065,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark52(83.18391045221243,-0.8493252420667323,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark52(8.322548410205883,-1.4653694490815328,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark52(83.26568447750043,-1.309272771795401,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark52(83.31170762772936,-1.1556412888680758,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark52(8.333164849919612,-1.1137507628641115,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark52(8.333370627839713,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark52(83.33549310957955,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark52(8.334526910104303,-0.7930168269156017,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark52(83.37860517714549,-0.21799591405522634,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark52(83.44268182997635,-1.247762224187636,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark52(83.4541221678341,-0.6006938996558295,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark52(83.47984142778756,-0.7303798614490575,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark52(8.348848055491342,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark52(83.53809356252424,-0.07657279195337918,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark52(83.590951897742,-1.1492540714667712,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark52(83.59834131704781,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark52(83.62202366743142,-1.2552971225103806,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark52(83.64250954390337,-0.8236523409077492,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark52(83.69577043540461,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark52(83.71150168584374,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark52(83.71576169744642,-0.11823597735455893,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark52(8.383487696671494,-0.7528201268968777,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark52(83.84886852044929,-0.6307855665715354,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark52(83.87360431782895,-1.1974157848121818,0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark52(83.9278120200074,-1.3603778869968746,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark52(83.94471693742457,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark52(83.95036978115455,-0.14386356133356792,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark52(83.97171158958186,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark52(83.97906062366637,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark52(84.01290999007418,-0.238143590614877,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark52(84.02529368504429,-1.3659044274972274,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark52(84.08596671757769,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark52(-8.41232762268487,-0.22656959161815848,-56.26926831666137 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark52(84.15580874771905,-0.42066847168823074,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark52(84.24494600962055,-0.6664284386166628,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark52(84.30901287462288,-0.4876620694170062,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark52(84.34907232596316,-0.006201765387246463,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark52(84.41716996939297,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark52(84.42718737638562,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark52(84.44751626426171,-1.2435475854693172,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark52(84.56603021521886,-0.2661542715428147,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark52(84.61130432610048,-1.499998916869093,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark52(84.62199980257168,-0.6741754410479359,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark52(84.63076567820926,-0.15776767290800997,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark52(84.72486992645278,-1.485662568758284,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark52(84.72722080084577,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark52(8.473352832038302,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark52(84.76657478072616,-1.0605948221087198,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark52(8.486184449647567,-0.24717574726389788,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark52(84.90232148839493,-0.5273958275722403,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark52(84.92185196751808,-1.0992156897281546,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark52(84.92824476059872,-1.3267156301565552,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark52(84.93583334254083,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark52(84.93841176610347,-1.3972102327597818E-8,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark52(84.95574721949214,-0.6307665504915745,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark52(84.97271920289265,-1.030606879034226,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark52(84.9821140222192,-0.5906845966999725,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark52(84.99912915506644,-1.499983344161888,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark52(85.028462821738,-0.4969347387508971,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark52(85.05351972492915,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark52(85.07549134907347,-1.3079697458531072,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark52(85.1001707380309,-0.040631585190245456,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark52(85.10626683641681,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark52(8.514289454422268,-0.17384842394136513,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark52(8.515870136146276,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark52(85.24735095003251,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark52(85.27583532687504,-0.29608586579400353,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark52(85.27979853454954,-0.4960547314400543,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark52(85.28401271580717,-0.5796421927313684,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark52(85.37862499406215,-0.807356910354823,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark52(85.41526865732749,-1.327310093697065,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark52(85.45674358457481,-1.4999999999999938,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark52(85.47274351148829,-1.1595852580168744,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark52(85.48118785090273,-0.36904669835160275,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark52(85.4897211512478,-0.3068191507442366,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark52(85.54835026552566,-0.009099574910383046,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark52(8.555547542312016,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark52(85.59656539200557,-1.1383115627774614,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark52(85.66429346200881,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark52(85.71587996356268,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark52(85.7204208578859,-1.2105577593673549,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark52(85.73858483928035,-0.4810173868960774,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark52(85.75240566018897,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark52(85.82503786008598,-0.2929456978594658,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark52(85.85978252363381,-0.21431056055859266,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark52(85.8637609403961,-1.4119941266681622,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark52(85.89370801923567,-0.4462333577303321,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark52(85.90944277982906,-0.945890316212624,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark52(85.95803883169623,-0.8583069825525831,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark52(85.9895740033195,-1.386789917099148,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark52(86.01471236888273,-0.1900814245699442,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark52(86.02009117157581,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark52(8.603053484329209,-0.48961471799489686,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark52(8.603768047922578,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark52(86.03848150174409,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark52(86.31333236618624,-1.1967900089024415,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark52(86.32302992779624,-1.1163402308700086,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark52(86.49398425630633,-0.1794995027256211,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark52(86.49600487096046,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark52(86.49635940994321,-1.1697619902380174,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark52(86.50787305528986,-6.691899487253823E-9,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark52(86.54807496208466,-0.7845286308854011,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark52(86.60197415137614,-1.3704252752996808,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark52(86.71700586766535,-1.1599744261060119,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark52(86.72207579543038,-0.2006296738203157,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark52(86.75295766370519,-1.4999999999999938,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark52(86.77191138311595,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark52(86.8007796875707,-0.4166717907077633,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark52(86.80491101451543,-1.4999999999999831,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark52(86.80542720521595,-0.4616964790429705,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark52(86.81831783456332,-0.5203549334093264,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark52(86.8790387264992,-0.0018150633976245876,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark52(8.68939539656468,-1.7958098020431036E-9,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark52(86.94318888964355,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark52(8.704162126965628,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark52(87.07827863475643,-0.5310050178865424,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark52(87.09103778871261,-1.4569387647971155,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark52(87.16158632683027,-0.08971653285717972,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark52(8.717616101277486,-1.188952765439048,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark52(87.19350173415881,-1.3743078914489661,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark52(87.19627791544646,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark52(87.19706652899552,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark52(87.22219058449875,-0.5211510043456826,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark52(87.2447274785111,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark52(87.25332563397342,-1.1030325036853754,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark52(87.26051966349272,-0.4982385109962524,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark52(-87.32308998121492,-1.0679096919742799,0.010138966182110834 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark52(87.33305630848861,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark52(87.459527187019,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark52(87.47525778195146,-1.208365680827697,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark52(87.51961822443826,-0.7698535331751151,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark52(8.761746139658547,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark52(87.65919353338188,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark52(87.69202804806534,-1.2742002651274564,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark52(87.72573737013036,-5.632439691630236E-9,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark52(87.73474092648931,-0.5655805427045575,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark52(87.7771493206642,-1.4337962794160006,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark52(87.79928286025117,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark52(8.784924425369937,-1.1148578989755578,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark52(87.96913412241855,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark52(87.97806550710786,-0.01655815289306517,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark52(88.0359855069672,-0.681488689578476,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark52(88.05305693952823,-0.7662717749038368,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark52(88.10489266447831,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark52(88.15343759623596,-0.6772491351557619,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark52(88.2197988720738,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark52(88.27543249768087,-0.727828629414633,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark52(88.32247646142751,-0.14259743477688636,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark52(88.41277038705869,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark52(8.85017572960956,-1.053452904303465,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark52(88.53571388290777,-0.32333357083509284,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark52(88.58473063259626,-1.0312924476816643,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark52(8.860244517634214,-1.3718758758763245,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark52(88.6296144958554,-1.4999999999999822,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark52(88.66818726558449,-0.870328080598398,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark52(88.7414711299091,-0.4497260150008051,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark52(88.81209407940841,-0.46069396712454136,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark52(8.881784197001252E-16,-1.02319516326423,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark52(8.881784197001252E-16,-1.324113972011773,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark52(88.83557629049375,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark52(88.88126169965042,-0.28303825353340206,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark52(88.92016059840529,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark52(88.92940496628128,-0.5960203605172865,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark52(-88.93680854867486,-0.19461398893295823,1.000000000000002 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark52(88.94271451626494,-1.4792656653443457,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark52(88.9519877867225,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark52(88.96226031388682,-0.8333963114014384,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark52(88.96878468778104,-0.09021653004697949,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark52(88.98605666837324,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark52(-8.898804450444777,-1.1399468565410782,1.0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark52(89.01948259147753,-0.09370709148637091,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark52(89.07571912363554,-0.9994025746292716,0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark52(8.909981051550004,-0.47375221092447006,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark52(89.11573414870949,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark52(89.1423158256502,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark52(89.1596943228576,-1.4002078980401649,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark52(89.21696130525379,-0.6239622318834608,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark52(89.22202089562148,-0.12200579137151557,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark52(89.31181902383526,-0.6611123259885403,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark52(-89.37392349778132,-1.4798829419300439,-1.0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark52(89.37822754575001,-0.22543705351351795,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark52(89.47188246913171,-0.7120855258623848,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark52(89.66593509376536,-0.1664897650541315,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark52(89.68725902937842,-0.9184451550496888,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark52(89.71902763222738,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark52(89.72556592301459,-0.48986791049801504,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark52(89.79401464505139,-1.317616499729386,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark52(-89.80978680194936,-0.11040167153282049,1.0000000001103377 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark52(89.81985815242354,-0.0654347925822194,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark52(8.986699051766273,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark52(89.93799971876658,-0.6576855886804083,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark52(-90.00060303057064,-0.001721058786792589,42.57147759786563 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark52(9.001951576246997,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark52(-90.12548998718115,-4.440892098500626E-16,74.27970256141435 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark52(90.13205951289345,-0.004149558371928208,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark52(90.1689037705128,-0.01153503093674857,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark52(90.25859944576032,-0.7670628342548871,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark52(9.026188716497117,-0.3217808014082806,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark52(90.26249049081045,-0.016375269902535905,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark52(90.27114803373638,-0.9495391149838737,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark52(90.29196406287015,-0.35558318003378453,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark52(90.36383736735199,-1.0242274056369203,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark52(90.38323378909249,-0.09640578646333342,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark52(-90.5290312414235,-0.987295859125997,99.78884830794206 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark52(90.58531797535434,-0.34625372184611214,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark52(90.5855381486048,-0.005929307604450429,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark52(90.61516758603634,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark52(90.64883230661076,-1.0831104291767106,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark52(90.71682521489473,-0.8651652727154264,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark52(90.81517149258454,-0.5680179972803773,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark52(90.8563285789923,-0.47764172734245924,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark52(90.87190696360676,-0.9072852183446912,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark52(9.091053958903974,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark52(90.91428846250741,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark52(90.95210157987589,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark52(90.98922635058318,-0.43694283977087967,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark52(91.03630497843724,-0.6836196875941596,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark52(91.21181184533748,-0.3144488989867045,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark52(91.27564963330096,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark52(91.28186628764493,-0.9842421830229426,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark52(91.5519294490426,-1.0276987816869176E-9,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark52(91.68373230535789,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark52(91.69086882385645,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark52(91.80200488248553,-0.9911003474498358,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark52(91.81175776377395,-0.010655124538591187,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark52(91.84114504536737,-20.647237773446705,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark52(91.86656685796967,-0.5200631756386327,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark52(91.99115295208716,-0.40281487488876166,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark52(92.0278763594024,-1.0310997457748732,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark52(92.09578810138564,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark52(92.16203268798228,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark52(92.16943842023576,-1.3658926850961146,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark52(92.23226244863186,-7.346172276279967E-10,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark52(92.27918018608368,-4.0883908007914836E-10,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark52(92.37335869836915,-1.3372938790551672,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark52(-9.242595204427927E-274,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark52(92.45063960128283,-0.7524605873340757,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark52(92.51391326324682,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark52(92.51466022576787,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark52(92.55892624959549,-1.4114263487278178,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark52(92.58878891372623,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark52(9.259344324149012,-1.2509665609560923,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark52(92.61315249092002,-5.791182646628123E-10,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark52(9.270219439289502,-1.7533887700305287E-9,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark52(92.71563148698502,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark52(92.84526645098964,-0.7274903198158168,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark52(92.8926064843408,-1.3859224902301506,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark52(92.89861360527223,-1.4754760824879174,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark52(9.295532670644064,-1.361451271071593,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark52(92.97868586060886,-0.6953689419071561,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark52(9.298783415492155,-0.00864350917780161,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark52(9.30282143634986,-0.17928965507759287,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark52(93.10132060503332,-0.751840997063315,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark52(9.310463103816048,-0.06048459727503541,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark52(93.13199429472829,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark52(93.17700031177714,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark52(93.18793483134473,-1.0994041264110148,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark52(93.19180927713799,-0.40810958108377804,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark52(93.24310205756137,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark52(93.34025539942951,-0.5825900404028014,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark52(93.45081050548458,-0.4581550414730806,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark52(93.46734418072737,-0.02999487027957387,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark52(93.60397118238225,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark52(93.62286137749217,-1.4954914638871912,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark52(93.73505488664932,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark52(93.76063872382605,-1.2411226945562106,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark52(93.76544432325906,-0.6266525590330776,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark52(93.8231170055075,-1.315203744610613,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark52(9.385508454457408,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark52(93.91914424539948,-1.0876872943612357,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark52(93.94686994394152,-1.237210553524739,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark52(93.95792314832772,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark52(93.99804104672458,-0.9780797941969199,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark52(94.0505345341916,-1.101389774008433,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark52(94.06964716698803,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark52(94.14224444655954,-0.9786571029592148,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark52(94.14425371745307,-0.9646845808432545,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark52(94.14432445141125,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark52(94.20509127147173,-1.1802890972683997,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark52(94.22149749540517,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark52(94.33410026986232,-1.2043448075000267,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark52(94.33695724086502,-1.0709007434046356E-8,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark52(9.436092943132477,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark52(9.440625165705097,-0.02070463474526193,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark52(9.442949874411738,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark52(94.46393343631675,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark52(94.5617866762851,-0.7402970821014243,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark52(94.5798230058371,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark52(94.66076631958623,-0.520606956278116,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark52(9.468747649857633,-0.7432176493842801,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark52(94.69188502487003,-0.6672676741967765,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark52(94.70065835869133,-0.41181733205301896,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark52(94.72866504857086,-0.09007008166438918,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark52(94.76353588968678,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark52(94.76853030531481,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark52(94.77676255670048,-0.17398259686969553,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark52(94.82663935519423,-1.4185053614629175,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark52(94.8304349604913,-0.5710300221909765,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark52(9.484154014879817,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark52(9.487815315558892,-0.3649977688815176,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark52(9.495565590110768,-1.4888724589891291,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark52(94.96285432294624,-1.4780763888964095,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark52(95.14042591730137,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark52(95.19901500133625,-1.491535718492227,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark52(95.22559647702784,-0.3415655362074079,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark52(95.23373448810341,-1.078522914561475,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark52(95.28813325246966,-1.0562816071236796,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark52(95.32339490030907,-1.4999999999999627,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark52(95.38802025820206,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark52(95.41965047131,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark52(95.56494363067964,-0.6019591195182841,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark52(9.562240528627399,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark52(95.6703127202909,-0.9393008843505235,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark52(9.56839670985407,-1.4123580562981175,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark52(9.57460061475166,-0.8433694017547184,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark52(95.75589904444638,-1.480103455456188,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark52(9.575832711947854,-1.4999910285782612,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark52(95.76241738285117,-1.2293147881649453,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark52(95.7840806325818,-0.5721474789106509,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark52(95.89090493769709,-0.3902479612529248,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark52(-95.96749905057789,-1.2809466803577656,-1.0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark52(95.97109911730192,-1.386762060126756,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark52(95.99136456545193,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark52(9.599430167642371,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark52(96.00129088926664,-0.3413323517833697,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark52(96.00724244735963,-1.023726438959116,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark52(96.0373867602579,-0.23393577534636112,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark52(96.14134999552537,-1.360310208637145,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark52(96.16403954856347,-0.7376356523815648,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark52(96.18409376559421,-0.87722523261988,0 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark52(96.28365535665469,-0.07002274021342814,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark52(96.33340870607455,-1.4326029371969191,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark52(96.3339606368283,-0.7072332704700911,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark52(96.37795661307206,-0.7091928956209741,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark52(96.37918447386627,-1.4749387065616464,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark52(96.43808511792471,-0.8718826216671971,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark52(9.66415072889464,-0.7191452882620029,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark52(9.673306189027997,-0.010744996474052027,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark52(96.80210342239354,-1.122972114189106E-9,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark52(96.82678942684043,-0.2034129318954434,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark52(96.84705298511423,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark52(9.699371318690226,-1.105258352250587,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark52(97.00778710178275,-1.002929708570455,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark52(97.05126238823644,-0.16080069363087546,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark52(97.09233895873953,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark52(97.16865124094711,-0.6765975738795762,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark52(97.19645055677924,-1.747828416712011E-7,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark52(97.29392000961093,-0.10920864392497176,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark52(97.31934828613538,-0.904947562809788,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark52(97.37214536591995,-0.049230344699313575,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark52(97.4076707037585,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark52(9.747235427877072,-0.2445674642528508,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark52(97.47294617113394,-0.11348836533772477,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark52(9.757810089474358,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark52(-97.67121268342433,-1.3158896583395658,2.3478235549776514 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark52(97.86003521934612,-1.0613577819917817,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark52(97.8919695667069,-0.7820566107124876,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark52(97.99685037945198,-1.2017479076887345,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark52(98.13686037311732,-0.5117429110180343,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark52(98.14748039507299,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark52(9.823303294426424,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark52(98.30493338779112,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark52(9.839862041895216,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark52(-98.40136054498352,-0.33796429344123596,-0.2482279030227159 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark52(98.45201003512031,-0.3156725637976471,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark52(98.49330221970357,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark52(98.53278241599156,-0.5488013501737683,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark52(98.58861094307665,-9.21959809310429E-10,0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark52(-9.860761315262648E-32,-0.8537693972098612,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark52(98.74460316192327,-0.35911707198088716,0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark52(98.77610577700082,-0.06812644758211661,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark52(98.78651261057115,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark52(9.878914244805522,-1.270490674886755,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark52(98.81651648441357,-0.25451254667059686,0 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark52(98.82035490901612,-1.4778408598710833,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark52(98.82166051115419,-0.41167986164585346,0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark52(98.89017866386015,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark52(98.9195877079078,-0.07485604191993023,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark52(98.94492850966009,-1.3026025525179739,0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark52(98.94943853753705,-0.5864634216510893,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark52(99.26038108426715,-0.02665157537654611,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark52(99.29085625006147,-0.0779712429331723,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark52(99.35067481359178,-0.3195884473165478,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark52(99.35595429049691,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark52(99.36311919679545,-0.5912246060223518,0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark52(99.36655279044172,-0.6082890556109009,0 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark52(99.49808446561175,-1.224179808955681,0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark52(99.50235940381765,-1.250422519452357,0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark52(99.53504038937984,-1.202189963887595,0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark52(9.966847879395615,-1.0721872053709518,0 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark52(99.71594234853524,-1.066272649523998,0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark52(9.982255859177783,-0.20514513686511537,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark52(99.82957841203171,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark52(99.83086617057123,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark52(99.84648407785136,-0.9862342721539221,0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark52(99.84924950673027,-0.9153636606483841,0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark52(99.93899637968283,-0.12479268862830128,0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark52(9.995661784525973,-0.434011147042771,0 ) ;
  }
}
