import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(-0.0010512857974165346,1.5707963267948966 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(-0.002411821081643728,95.88637817503422 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(0.004713947534383475,-37.44592737342447 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark02(-0.008924635609250239,46.950301216933646 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark02(0.0,-21.991148575128552 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark02(0.026586702696071107,-32.94762826652353 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark02(0.030000558201912497,36.22967180927324 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark02(-0.03915223051549632,1.5707963267948968 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark02(-0.04404719934525758,-83.54630498677261 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark02(-0.049519948628025154,-0.09219872102984417 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark02(0.05447849831641775,-1.5707963267949054 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark02(-0.056983398456623036,-37.97044280116609 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark02(-0.058863591938761894,-36.06945192424369 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark02(0.06539006863675464,-1.367561708632107 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark02(-0.06563869047036092,2465.0580166109007 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark02(0.06746855229742305,1.570796326794897 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark02(0.09284029727005816,7.643157917178229 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark02(0.09358612446963516,-1.5707963267948966 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark02(0.10411730297950028,-25.172852620352984 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark02(-0.10889660783701327,-2583.0207437460717 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark02(0.11043779247417262,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark02(-0.11457407367390893,-0.5707918980776113 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark02(0.11514771625935794,47.798312611062215 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark02(0.13113070921260217,-46.43045757713669 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark02(-0.13932376363804738,70.51824908391805 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark02(-0.1415163342968142,52.318625337772744 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark02(-0.14736874609646863,61.84565030152804 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark02(0.14851169923443097,-80.25912436567305 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark02(0.1512065326944929,-26.330300724889362 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark02(-0.16085284010680506,10.878037537933867 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark02(0.16168730368310946,-70.12361489047436 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark02(0.16460472728296624,-0.3437593422354014 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark02(-0.17439675929042206,53.64649467267774 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark02(-0.1789578340870377,-90.87173154680266 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark02(-0.18403739652048934,1.5707963267948983 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark02(-0.18677448961194898,-0.7064394819826134 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark02(0.1900868703656769,-59.113009721012546 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark02(-0.20678683401448605,-54.650644189761685 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark02(0.2078226903659314,39.06208547960868 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark02(-0.21170320896948405,0.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark02(-0.21715206528097292,64.96705512607592 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark02(0.24759969843559482,0.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark02(-0.26002497519549794,1.5707963267948966 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark02(-0.2792858077781091,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark02(0.28483407634412045,0.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark02(-0.2868290964216593,-39.28703072142614 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark02(-0.2970036047620882,0.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark02(-0.3179257247349129,-93.30253941604016 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark02(0.3268779225435168,-2503.338938288331 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark02(0.3345964189965884,-3.23098163263794 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark02(-0.341768525507149,0.0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark02(0.34305625905846177,-1.5707963267949054 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark02(0.3447911038378013,26.026951522337455 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark02(-0.34658821320919325,-42.40116659482343 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark02(0.35172075631039945,49.224392523537915 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark02(0.3542558298675236,70.33157887600944 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark02(0.35881781169775673,-2553.201852870035 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark02(-0.3734711636159034,12.620584376500886 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark02(-0.3737867858939745,-0.2132304097201186 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark02(-0.3817455743225405,52.1773287364651 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark02(0.38236706426474276,0.06692588867593463 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark02(0.38816669417875294,0.0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark02(0.3989417673058252,1.1648528391416022 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark02(-0.4032424568111363,-0.7326303325748 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark02(0.4038449005670586,9.678300002651469 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark02(0.40983839810950107,0.4412217763875799 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark02(-0.41899759809437453,1.3345441934947093 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark02(0.4199079263825105,168.07539999931961 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark02(-0.42387698575441846,-94.23191157171019 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark02(-0.429336476666134,20.849688725109772 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark02(-0.4327582979846949,-1.532107742741923 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark02(-0.4475954571777443,-135.14581745017048 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark02(0.4535634952915306,80.74627923740758 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark02(0.46403988255225315,-79.61268978659663 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark02(0.4686319475738232,54.285121057239195 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark02(-0.48925688972127146,73.19202524543789 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark02(0.5076899272858032,-38.762218242701046 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark02(0.5139596043444454,55.503518399856176 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark02(-0.5145077423714781,-45.07709742700179 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark02(0.5168756056750544,30.362005814663064 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark02(0.5591008797217715,-6.793931189068193 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark02(0.5689473528769564,1.5707963267948957 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark02(0.5743721670798739,-49.269058297602555 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark02(0.5766950368782665,-1.5707963267948966 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark02(0.5839952337413509,0.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark02(-0.595835027957449,71.28166973384862 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark02(-0.5975456441998802,1.5707963267948963 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark02(0.6022560581703225,1.5707963267948966 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark02(-0.6035524717124274,38.754529479064345 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark02(-0.6050027677531344,4.107386212509975 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark02(0.6171172098208159,53.71847034896955 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark02(0.634284100919895,0.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark02(-0.6458091580161001,51.95320636845402 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark02(0.6546335094818307,-60.676698728697275 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark02(-0.6664549775779913,73.2853315355942 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark02(0.6742878699104438,44.25666020406886 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark02(-0.6795228005108527,-1.5707963267948966 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark02(0.680897511088375,36.68448243163401 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark02(-0.6888985703345881,-1.5707963267948968 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark02(-0.6906909825468777,17.278760775241953 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark02(0.6909754739133874,1.5707963267948966 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark02(-0.6928368448030824,-44.34524425775374 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark02(-0.6963032753209859,0.0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark02(-0.7023552026991229,-1.5707963267948966 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark02(0.7183069981284997,-69.96752770777466 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark02(0.7369929632095733,-4.874225638984029 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark02(0.7413086667289264,1.5707963267948966 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark02(0.7540800319450316,-69.11503837897546 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark02(0.7690727397717115,-29.72621444936466 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark02(0.805320622875124,-16.178561862485196 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark02(-0.8180766817501455,1.5707963267948966 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark02(0.8206209207758948,15.951727950301375 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark02(-0.8354201550019819,87.96459430051421 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark02(0.8465887585330178,0.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark02(-0.8580109257640771,-35.59009175443282 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark02(0.8698971584283259,0.35250300640416976 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark02(-0.8965105119898059,0.0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark02(0.917724938167126,35.74319957497801 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark02(-0.9318712251173278,-12.566073757264377 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark02(0.9366740493413663,-0.10001692059835288 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark02(0.9373059298145172,40.41789628339188 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark02(0.945175619816027,22.743139774541234 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark02(0.9477088683742707,-1.412923304465099 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark02(-0.9522655038068231,-100.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark02(-0.9692450345636536,-6.5071632746859835 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark02(-0.99461524449584,-68.03919148599479 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,0.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark02(1.0000006123233996E-10,-1.5707963267948966 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark02(1.0000006123233996E-10,1.5707963267948966 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark02(1.0000050532154981E-10,1.5707963267948961 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-0.569987177698272 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-1.2218660202694702 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-1.5707963267948948 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,1.5707963267948966 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-1.5707963267948968 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,1.5707963267948968 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-1.8460531456232943 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,2613.3142758532113 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,2634.40604501499 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,26.703537555513243 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-37.811867017160665 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,46.71951873877271 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark02(-10.004806326486843,38.91757570834494 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,5.608155182120896 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-5.613684276991457 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,88.1898310074 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-9.231362311005896 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark02(-100.20235167408217,-5.212388986470596 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark02(1.003334314103796,49.365475077182595 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark02(-100.4072810792232,-74.18016232542443 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark02(-1.0050004263103422E-8,-20.445720280787803 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark02(100.53758394927964,-186.92476288182164 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark02(100.77848005896657,-95.40744693006545 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark02(-100.87202873196667,-86.91608638880746 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark02(101.11299322208737,-107.37338182740127 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark02(-101.17824182301713,73.64949200854383 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark02(-10.12539232655638,-29.500238192231578 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark02(1.0164072680448744,0.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark02(101.77107525038605,-24.42792659217734 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark02(-1.0196078293668798,-92.67698328090762 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark02(-102.05525498285434,32.444720968406756 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark02(1.020554469832073,88.52376297191594 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark02(-10.224191659722791,-67.54424223332158 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark02(-1.0270826245341114,0.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark02(-10.287746185986428,0.5706542107923674 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark02(-10.369753977697854,56.49367495675756 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark02(-103.75033020997157,30.810443439586088 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark02(-10.408150220214623,-57.594572439544244 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark02(-104.29061242844874,0.0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark02(-10.434013718165676,-4.637618362178614 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark02(-104.41586012221876,66.17514808207989 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark02(-10.496653676827961,-68.85933486258601 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark02(1.0544335372081377,6.823031690744731 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark02(-10.569272377011176,-18.599751934828163 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark02(-106.8148284736856,-32.98672286260625 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark02(-10.723440444288443,-0.3992755566866323 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark02(-10.72759023480701,1.5707963267948966 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark02(-1.0800152572838826,-0.009142165491535287 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark02(108.21807082712638,0.1668757223234928 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark02(-10.825417181850497,0.0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark02(-1.0836016649833118,1.5707963267948966 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark02(1.0842021724855044E-19,-1.5707963267948966 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark02(-10.863365587850254,-87.49826533657152 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark02(-10.86654623038747,-1.9893991309174401 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark02(-10.886308187714922,-56.65793386538255 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark02(-10.902522160100485,-1.5707963267948966 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark02(-10.908814945663455,30.792450079903205 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark02(-1.0943828609332718,67.1824173513028 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark02(-10.95343124976565,27.44200625405272 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark02(10.986290649362942,-9.252270746242147 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark02(-109.95421933054213,32.98672286183902 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark02(-110.3148794371097,14.433309077890627 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark02(-11.068691807681034,0.0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark02(-11.078656448359126,1.5707963267949765 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark02(1.1102230246251565E-16,-45.555046602052 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark02(11.106927624609057,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark02(-1.111866528454998,0.0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark02(1.1177872775790663,0.4530090494443112 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark02(-111.95881104582548,-112.66506368560603 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark02(1.122826660063165,1.5707963267948966 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark02(-112.34853750154979,82.31006919690543 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark02(-112.6190241615375,37.4410321150854 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark02(-112.66180575638109,164.49808454072297 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark02(-112.76176794196964,62.296999957015885 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark02(-112.84205063252566,36.21816475288273 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark02(-11.289641097370136,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark02(-113.04091333997422,106.00609343705203 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark02(-113.09494187499476,95.81869800480125 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark02(113.09733648510345,1.57079632679498 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark02(113.16542354023935,-4.837395188156244 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark02(113.27941472699985,-61.44313594266658 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark02(-113.5062061532012,-1.9796669508725289 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark02(113.92061325435009,94.99529820951827 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark02(-11.400554969989557,35.96563895150095 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark02(-1.142304605294534,-25.528308242314267 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark02(-11.426651852198177,-5.6646379729663465 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark02(-114.37908732469303,2.3919772315434358 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark02(114.62300486388007,-2540.6417689052055 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark02(-11.526247463863253,1.5707963267948983 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark02(-115.38204162322866,-15.075774755120754 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark02(1.159230431571069,21.86494545109572 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark02(-1.161300647582087,23.978623866653876 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark02(-11.658092071277238,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark02(1.166752139392503,-36.648360839728134 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark02(1.172332568061577,-1.570796326660245 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark02(-117.49845985098125,158.19251483308813 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark02(-11.750520107151388,15.524609205190345 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark02(-119.05360579689864,191.34815730030823 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark02(-119.3804406129517,1.5708109226348492 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark02(-119.38052083640686,1.5707963267949383 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark02(1.194182904147496,26.23190869502278 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark02(-120.0447854915469,158.34720553998176 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark02(120.57828290200783,-44.35533141173071 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark02(1.2066596313397042,4.5611314265804515 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark02(-12.072214795633876,2.919267272996062E-11 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark02(-12.215437005674316,5.07027476219686 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark02(1.2229159641389797,0.0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark02(-122.6594486404867,-1.5707963267948983 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark02(-1.2289730380048378,-34.21569590099599 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark02(1.2296153694003786,-22.138981432698543 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark02(1.232595164407831E-32,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark02(1.2368485113704208,-42.41163167726924 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark02(-1.2423765129706856,-72.58505084607943 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark02(1.2443597164494709,62.505416461138594 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark02(-12.566370614259178,-10.995574287564272 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark02(-12.566370614264303,-1.5707963267948966 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark02(12.566370614459172,1.5707963267948966 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark02(-12.56637061546761,-1.570796326795083 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark02(-12.56637156803349,0.0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark02(-12.566371568033642,1.5707963267948966 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark02(-12.566371568033835,1.5707963267948966 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark02(-12.566372850468591,1.5707963035722896 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark02(-125.66481852665703,64.40264939838578 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark02(12.566615136041118,10.995324795138572 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark02(-12.568323739359188,-51.83627870840304 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark02(-12.568856130815202,-29.85294282114638 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark02(-12.573972820464075,2604.8698069885186 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark02(1.261980850512522,17.117043395655116 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark02(-12.640345670292689,1.5707963267956089 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark02(126.93497112936348,72.47126133625835 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark02(-12.74160370806025,0.0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark02(-12.75560583259242,-10.80633906922921 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark02(-12.835127043439478,60.799290899275206 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark02(1.2837231151505797,-52.718471305219516 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark02(12.855342223293633,0.07671100488438809 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark02(-128.8051005533655,-36.12831593353239 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark02(12.898119940969877,-28.248896264354272 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark02(-12.90263388529867,-1.5707963267948974 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark02(-13.00083895477762,133.38780565152382 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark02(-130.03602744911802,53.20486066675525 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark02(-13.014200908144531,-101.98044762039865 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark02(13.05009915014029,63.96413475175252 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark02(1.3118696718018157,0.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark02(-1.3155849386253653,2524.1157372533653 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark02(1.3167332578247861,0.256918366215814 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark02(-1.318360494541147E-21,1.5707963267948963 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark02(13.213783215263547,92.16186788774095 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark02(13.214447830677072,-5.360466196577157 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark02(-13.24534268496619,-6.9128837554503235 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark02(1.3277604012686797,-1.5707963267948966 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark02(-13.313221387631913,0.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark02(-13.353672604588638,39.17532013594023 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark02(-13.381097523298962,-1.5707963267948948 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark02(-13.389160293988134,0.0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark02(-133.93376847128684,-76.64745671050318 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark02(-1.3448450552976514,108.30895166296258 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark02(-1.3460948866939262,1.5707963267948963 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark02(-13.492573725189729,46.47929658804898 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark02(-13.497738549276576,-6.429644317238865 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark02(13.513034694608166,80.23045294108566 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark02(-1.3607031611107394E-20,95.81857593446273 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark02(1.3618545069608052,1.5707963267948957 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark02(13.691966430221141,4.440892098500626E-16 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark02(1.3695107422034734,45.67547677351956 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark02(13.761088495307948,0.0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark02(-13.80693426625082,-25.959663893284898 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark02(-138.2300620564811,1.5707963267948977 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark02(-13.828466093062275,72.48118931248288 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark02(13.833975372983238,0.5550973933792297 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark02(13.840182891212043,-56.251683714332536 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark02(-13.84506297461133,9.017840995630092E-8 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark02(-13.85463219040022,21.591252724841937 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark02(-13.865162147853184,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark02(13.869145965616255,-32.30295323844207 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark02(-13.870527292705852,4.069066076517521 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark02(-13.883352182678152,100.0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark02(-139.81139849301582,-97.39989766007334 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark02(-139.8993834407392,-61.703763238410744 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark02(13.989938847886332,-64.66163202039692 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark02(1.3999866704579684,-15.977132383540209 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark02(1.4013077431937118E-15,-54.97787143772138 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark02(1.402576713646416,88.37488329737505 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark02(-14.048017693902935,0.0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark02(14.097236235759496,-3.0202255749436375 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark02(-141.08686571306515,-83.38910077106016 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark02(-141.09016884896832,165.21511487614063 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark02(-141.15527498349758,93.57760772360365 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark02(-141.3708904540211,83.25220531770162 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark02(14.137166941151543,0.0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark02(-1.42117729440429,68.6383133478106 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark02(-142.88983695563437,-1.2205713477353384 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark02(-1.4296595677443342,9.4728893961953 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark02(-14.423588503544593,-0.12285881964564382 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark02(-14.467103821543503,-53.07713823094571 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark02(-1.4470708676941444,-0.16307795390819374 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark02(-14.489154291555622,-234.9642013520297 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark02(-14.49869504892392,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark02(-1.4605137716594827,-15.856610533748468 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark02(-146.3935181092044,-59.40839250920437 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark02(-147.53232011933383,-62.42684974804308 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark02(-147.73593163708998,-69.69622208412375 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark02(-14.80147611711784,3.5805104137319935E-16 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark02(-148.7908455412773,-0.35679189921352783 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark02(-1.4893533628392854,-67.22429556566885 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark02(-1.491267527608615,0.0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark02(-14.921004930086951,1.570796326794742 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark02(-149.38913247874302,20.628160232026787 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark02(-14.973275505724871,0.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark02(-1.504632769052528E-36,-42.41150083091279 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark02(1.5115672432199716,81.1364317662763 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark02(-15.173061353772432,3.2399312462967984 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark02(151.74545414066714,0.019944625126650024 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark02(-1.521152802437752,-1.5707963267948968 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark02(15.218221542781563,-89.74554317906443 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark02(1.5219715611671571,-6.449276420788331 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark02(-15.237196914400158,-10.070001795062808 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark02(1.5380537602358555,-0.0327425696118587 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark02(1.5387767934502143,-12.620143627793562 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark02(-1.5407439555097887E-33,1.5707963267948963 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark02(-1.5411215616645646E-20,-54.97787143782141 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark02(-154.12690825198527,-1.3866668442933414 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark02(-15.53358619215679,-16.753509300937125 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark02(1.5550407345546973,-1.5707963267948966 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark02(1.555990012202303,-0.08541788539287343 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark02(-1.556110932838338,-1.5707963267948966 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark02(-1.5561177110660722,-58.119464091411174 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark02(-1.5681841371815144,84.59997742833454 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark02(1.5702985927595068,-0.4999999949804666 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark02(-15.703256157989037,-2.070796326794897 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark02(1.570520774736077,-4.706254149168311E-6 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark02(1.5706806556370432,-23.555075240267726 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark02(-1.570792272126463,3.141592978303178 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark02(-15.707960062530901,0.5693366505940142 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963165262242,100.0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963229527657,0.0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267415523,1.4073854500982002 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark02(1.570796326791399,91.8964926133792 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267942135,0.0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark02(1.570796326794337,69.9926691776636 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark02(1.570796326794671,-63.741055573607966 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark02(1.570796326794813,44.11360972816269 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948735,1.5707963267948966 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948735,-44.15075807501256 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948826,-215.19909677090078 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948877,-0.051682871156219994 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948877,-3.772635785984529E-6 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948912,-100.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948912,-4.292283458919634 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948912,57.11636651425354 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948921,0.0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948926,1.5707963267948966 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark02(-1.570796326794893,-100.0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark02(-1.570796326794893,-1.2756554817850545 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,-0.6907314318357098 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-123.87384033258365 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-130.380031179644 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-17.278759594743864 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,25.104323888559275 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-2614.5739718716877 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,28.572407358585906 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,3.0726459412963116 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,32.931945363633965 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-42.83253347475691 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-55.4176784835505 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,55.4376873670428 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,-59.69534356516701 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,-63.465638709558384 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,75.96892841317089 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-77.61095603906892 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,87.6681594688678 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-91.98968299852847 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-93.88283293196626 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,98.1354310720543 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948952,28.65119515814041 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,100.0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948957,14.173510829079405 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948957,1.5707963267948968 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,1.5707963267948983 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948957,-46.4776639607237 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,-81.10145506083708 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948957,-88.32156948880842 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,-89.43385266531129 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948957,-93.53552777833085 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark02(1.570796326794896,0.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948961,1.5707963267948968 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948961,-34.39131963733173 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948961,55.30353448013264 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948961,9.818605899875257 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,0.22770096061811174 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,1.5707963267948775 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,1.5707963267948963 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,-2449.0600608380005 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,-24.821255213005003 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,25.091212663433353 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,-54.66873763978422 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,56.55791925016253 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,90.19342552068835 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark02(-15.707963267948964,0.0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.0045249288303042595 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.02226201080760564 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.04570887575078914 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.061097314305296746 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.11165269107849163 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.33768821347153877 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.4391656651143495 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.4506850206451346 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.5698810467425593 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.570326841505922 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.9043628961625738 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,10.790471883102244 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,11.011199287564278 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.1583651879855292E-16 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,12.812403056977729 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-13.197764353303182 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-135.0884841043459 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-136.14811150399885 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-14.137166941154067 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.4575049794897872 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.4636221850650326 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,15.309946402960053 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.538613666298314 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948561 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.570796326794869 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.570796326794896 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.570796326794897 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267949079 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,16.004889379998314 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-18.60282653931087 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-20.42035224833365 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-21.991148575128552 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-22.350709391865173 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,22.729865298320775 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-23.56194490192345 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,23.781892750504902 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,2566.749696915182 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,26.140695732920623 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-2633.913685406969 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,26.703537555513236 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-28.274333882308138 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,2.8540102014405574E-16 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-29.845130209103036 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-31.191079274950894 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-31.2324481081772 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,3.1415926535895577 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,3.1415926535897936 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,32.3792556708589 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,3.2665926535897936 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,32.98672286269282 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-33.22918402678279 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,33.30623628693681 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-34.5575191894818 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-34.55751918948773 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,36.03104776121512 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-36.616395155648654 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-36.76945697764001 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,37.8609135200727 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,39.25761115002572 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,39.26990816987241 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,39.53089559023354 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-40.840704496667314 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-4.141592653589794 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,4.14159265359064 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,41.91631809510835 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-42.41150082346224 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-4.396782689314996 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-43.982297150257104 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-44.44968616767346 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-44.48387324415668 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,45.23262821164489 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,45.36213866335161 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-45.55309347705197 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,45.64558524241943 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,4.7104358553846915 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,47.123889803843085 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-47.12388980384566 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,4.7124518636388695 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,48.6985923806418 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,48.71128135164526 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,48.794371339063055 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-49.849603378983716 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,50.18003733992257 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,51.07557468376015 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-5.145636995750641 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-53.36573659483021 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,5.449017127086563 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,55.476182828471 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-56.751327215861224 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-59.27520123363621 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,6.123234012906241E-17 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-61.26105674500097 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-61.4714162909974 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,6.283185307179566 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-63.708043570751464 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-6.429328681347891 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-65.97344572538428 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-65.9734457253887 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-66.5422898387735 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-68.9381616413542 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-6.914916618233957 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,69.77806658437545 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,71.12853209176984 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-71.346464415713 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-71.77429071408292 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-72.17327128386971 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-72.25663103256524 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,72.25663103256565 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,73.48776146011414 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-73.84305235936014 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,7.853981633974482 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,78.84968442849447 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-80.07147828072097 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-80.23561266653974 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,84.82300164693022 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-86.06371951037023 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,86.20717273227858 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,89.81736574662466 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-90.00249216394107 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,90.88888091144526 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-91.43227989741081 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,92.67698357844381 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,93.84167661479603 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,9.424777960769113 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,94.2477796076938 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-94.32769931935684 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,97.38937226127803 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,9.860761315262648E-32 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948968,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948968,-105.24335414115623 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948968,-1.5707963267948966 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948968,-6.42920556893688 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-1.57079711778997 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-16.90667675525953 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-31.78407830860246 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,3.504961171838441E-5 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-57.88373798183193 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,80.36969752619268 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,80.38430618648101 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949012,-1.5707963267948948 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949019,-37.78007364737811 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949054,0.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949197,90.53930392818602 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949,2618.5868895169574 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267952003,0.13987556969459014 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark02(-15.723588267948967,-1.5707963267948966 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark02(-157.65659264440845,2.1477562918329967 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark02(-15.901512656124225,77.18154660351797 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark02(-15.931028069344208,-35.896623583950586 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark02(-15.950085613081798,-107.73951048252663 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark02(-15.99109246065839,30.30139666749285 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark02(-16.08796072787463,0.0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark02(-16.111905550557402,12.790817077498929 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark02(-16.11666229298138,5.121088005308129 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark02(-161.2776293395494,0.5143923205282009 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark02(-1.619093905664976,59.66776827322586 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark02(-16.229367581379762,103.49488952021426 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark02(163.380359004678,70.68589574756194 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark02(-163.81038686883045,-89.53539062730911 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark02(16.416421904828198,91.2795721478708 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark02(-16.432543119874733,-0.014628620382101715 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark02(-16.435972016271265,32.930990117547836 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark02(164.86099561396725,-135.63994855303372 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark02(-16.60564209325659,-38.095519223907374 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark02(-1.6643878489591748,0.3171554946720413 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark02(-16.689020764376977,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark02(-167.03778368270642,-67.888887067345 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark02(-16.708653136143848,0.5701064587852951 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark02(-167.854353409368,-0.220853558142415 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark02(-168.42581753318717,94.59839017411818 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark02(-1.690863020619594E-16,-1.5707963268948968 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark02(1.6940658945086007E-21,45.55309347714872 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark02(-169.4133401459707,-34.87862245878908 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark02(-169.64663056840814,54.97799350814666 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark02(169.92345162177827,-91.42123387009084 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark02(170.09128522495325,-110.3471734458283 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark02(1.7242346832866673,-31.47888784080841 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark02(-17.249133337368818,-1.5707963267948966 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark02(-174.20885113002885,45.09494096766103 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark02(-174.23631770887252,-3.042916564526593E-16 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark02(1.7424026601269276,44.22273555223856 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark02(-175.60452092781816,6.283185307179586 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark02(1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark02(-1.7763568394002505E-15,1.407794981309479 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark02(-1.7763568394002505E-15,-36.908091628997 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark02(1.7763568394002505E-15,-37.25879459250445 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark02(1.7763568394002505E-15,-45.288902632615475 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark02(-1.7763568394002505E-15,-64.90662882491432 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark02(17.87974864956739,-38.64583711646561 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark02(-179.075958334714,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark02(-179.14990643543914,99.11538325519604 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark02(-1.7930897221079731,0.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark02(-180.78850377657577,2.3941315892231162E-14 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark02(-18.088289082317672,93.2956906189795 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark02(-180.98241324993847,-46.90883659221761 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark02(-181.14714010793324,0.8862947720193568 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark02(-18.18504309253633,-96.58690904085506 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark02(-182.21182119046026,45.55333761791085 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark02(-18.222147467116613,-39.21266355668632 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark02(183.17068062761967,-14.326091547488407 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark02(-18.317302833496157,1.0385432388683484 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark02(-18.34825173472406,15.069090472604778 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark02(-1.8383669852030948,-2681.8089078660532 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark02(-18.531127732333808,-4.082481074720555 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark02(-18.731632076690197,1.5707963267948966 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark02(-18.76735561835929,1.5707963267948966 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark02(-188.49528021480805,76.96917714724444 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark02(-18.84955592143876,-1.5707963267948966 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark02(-18.849555921473623,1.5707963267948966 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark02(-18.8495861552885,77.35067007276022 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark02(-18.849586439375045,1.5707963267948966 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark02(-18.849800062163766,-1.5707963267948966 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark02(-18.857368428442825,-0.5707916840370687 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark02(18.878339272685164,0.0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark02(-18.89606639142241,6.8778754655778425 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark02(1.891166462856213E-15,42.41150082336221 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark02(-18.967870725162022,-131.03391406260994 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark02(-18.975992011668865,19.78116203166516 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark02(-1.900538416879138,-0.2446190180257971 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark02(19.038949306398607,-89.9668985982241 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark02(19.116388505923886,-24.925349297166797 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark02(-19.12361811239336,-0.26314789273020267 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark02(19.170985846815167,-1.5707963267948966 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark02(19.22969520544685,14.087034614733692 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark02(-1.9231242480489357,-57.416606328093835 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark02(-19.233330068969167,10.547507755481789 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark02(-19.241711153817434,-14.4292099693009 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark02(-19.242981623998872,0.6075891392557367 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark02(-1.9256700611045074E-34,23.561945378760768 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark02(-1.927803690091011,-54.2626453300094 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark02(-19.31901640435267,-1.5707963267948966 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark02(-19.451715897605958,-38.02264973627201 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark02(19.45633818215731,76.85937016483518 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark02(-19.46754107957227,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark02(19.521188335833763,-27.54460022078598 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark02(19.57850080623482,-61.39658134328849 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark02(-19.620248045236515,0.0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark02(19.684828970839853,-17.250371313997377 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark02(-19.688090763194282,-1.5707963267948912 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark02(-1.9721522630525295E-31,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark02(-1.9721522630525295E-31,-36.13236687478782 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark02(19.73226690264181,-0.43716408478758684 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark02(-19.735146922659844,-12.797834240922867 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark02(19.770726662710118,-72.17187601652036 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark02(-19.79020077197471,-100.92690089383274 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark02(19.792912083344532,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark02(-19.80852110307311,68.17789926761148 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark02(-19.820545031795376,-29.808978136097977 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark02(19.99331349628895,29.21825854024388 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark02(2.0005652599617463,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark02(-2.002427850214005,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark02(20.16906050553966,4.379782301064012 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark02(-20.221897937460582,-90.43028090242545 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark02(-20.239297819338702,71.86232968960255 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark02(20.25945634464226,-26.63506462017999 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark02(-20.288417028743318,-3.5543224515586083 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark02(-20.33598294779422,19.378324689946183 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark02(-20.36097129498615,53.46645606268943 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark02(20.36109140269511,-11.155921222989164 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark02(20.36581739807906,0.0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark02(20.41960324987855,-52.11492016325971 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark02(20.42035224823927,0.0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark02(-20.497047563451126,0.5025579055127399 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark02(-20.518947454017795,-8.429464066954907 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark02(-20.57770918194353,37.90340404242605 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark02(-20.675630120184984,14.429216703190832 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark02(-20.68130475035728,-15.916568921771557 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark02(-20.69914036211395,1.5707963267948968 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark02(-20.699709390518123,87.75395349768729 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark02(-2.0746253945408652E-16,139.8008692832685 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark02(-20.807848246772448,96.97880335506761 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark02(20.815552284169485,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark02(-20.878620303350278,44.1444940752676 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark02(-20.92897339800576,-1.5707963267948966 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark02(-20.939953512808714,-6.461839960376126 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark02(-20.949768005070098,-98.83837241668886 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark02(-20.954597049731817,-123.89209864936225 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark02(-20.97634650013832,-1.4905031052847417 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark02(-20.978541041435207,-10.688048893719056 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark02(-20.98455084016497,-17.278759594743864 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark02(-21.076496737019838,140.98472385175987 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark02(-2.1096138726340894,66.51226327102997 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark02(-2.112411144644028,-60.888210795408625 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark02(-2.1175823681357508E-22,0.0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark02(-21.180008494376224,-67.2926475202394 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark02(-21.202074696015558,-45.37286964957136 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark02(-21.237813809236144,-57.04287172942561 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark02(-21.33447101939541,4.143855466310358 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark02(-21.356067609656975,-1.5707963267948966 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark02(-21.461790979555524,-1.5707963267948966 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark02(-21.5268566502008,-23.30275223697258 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark02(-21.543684860800028,72.89905064472495 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark02(21.596096469307952,35.94269447072017 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark02(-21.63623675877174,1.9257081432583625 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark02(-21.65210967722629,3.1300603087520926 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark02(-21.665579398172586,0.0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark02(-21.68329754349662,71.42996503290061 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark02(-2.1684043449710089E-19,-1.5707961986169474 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark02(2.1684043449710089E-19,-1.5707963267949019 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark02(-2.1684043449710089E-19,-32.98672286269282 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark02(-21.691513937878824,-47.58886075837769 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark02(-21.805643247097173,1.5707963267948966 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark02(-21.823041614979303,-8.585821122222171 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark02(-21.94680842774308,-1.5707963267948966 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark02(-21.96726114853703,-1.6332963267948968 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark02(-21.9896884334277,14.429204129819908 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark02(-21.991147317442422,-0.5707578835598356 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark02(-21.99114749626643,-124.0929205468491 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark02(-21.991148261071707,-1.5707963267768605 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark02(-21.99114857508907,-32.98672068356592 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark02(-21.991148575128253,-1.5707963267948966 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark02(-21.99114857512855,-1.5707963267948963 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark02(-2.220446049250313E-16,0.0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark02(2.220446049250313E-16,0.0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark02(2.220446049250313E-16,-42.55186367755273 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark02(-2.220446049250313E-16,6.123233995749878E-17 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark02(2.220446049250313E-16,6.183552081423763 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark02(-2.220446049250313E-16,73.18507088745946 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark02(-22.20833716587896,-34.982179443633164 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark02(-22.244849494703843,10.819685865805454 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark02(-22.249341413179906,-75.17906080483672 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark02(-22.271941601917305,0.8635051736030679 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark02(-222.72586807169768,83.25664188779876 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark02(-22.278823141741,163.4893845588138 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark02(-22.322938713164604,0.5209991952941834 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark02(-22.350202833338358,-1.5707963267948966 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark02(-22.399345901803105,-1.5707963267948966 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark02(-22.402614533662017,0.0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark02(-2.240636769221922,61.90724055997188 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark02(-22.42570331407556,26.47494073425058 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark02(-22.426989175182708,-149.16180018643348 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark02(-22.471111505498747,-39.132466166880505 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark02(-22.486594859061213,0.2672472130606295 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark02(-22.515490181294386,-1.0464547207445833 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark02(22.580907055528044,24.407673677100902 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark02(-22.91668338982474,1.5707963267948966 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark02(-22.94218493349374,0.0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark02(-23.053400371244155,-11.580522008807954 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark02(-23.11787874624765,-32.4479691986793 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark02(-23.385292018792498,92.6769832808989 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark02(-2.357222560403392E-12,-139.79977694753063 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark02(-23.62443716263614,-81.68140899333463 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark02(-23.66684071617781,-46.24311696136323 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark02(-23.715393287743325,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark02(-23.753825747718608,0.0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark02(-23.79826143978076,-2624.378800970729 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark02(-2.4104630875338098E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark02(-24.295354549252508,1.5707963267948717 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark02(-24.416836858733326,-3.958549087405223E-4 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark02(-245.04097302647608,92.67698328089888 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark02(-2.465190328815662E-32,-51.83627878423083 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark02(-25.04597715714567,-110.21944284568728 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark02(-25.094873771331223,17.27875959820635 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark02(-25.132731413859105,-4.712388980384689 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark02(-25.13274122355612,10.995574240380584 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark02(25.132741228818222,-1.5707963267950202 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark02(-25.133230080152636,-29.845130328356163 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark02(25.13664747871835,-1.5707963267948966 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark02(-25.136647478718444,-1.5707963267948966 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark02(25.145716895982858,-2.174608477235214 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark02(-252.02552815267754,-52.76175779124688 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark02(25.249494229757694,1.454043325856234 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark02(-2.5283595422458975,-54.364638326355205 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark02(-25.39261604687195,1.5707963267948966 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark02(-25.462382617397623,0.9442355889087023 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark02(-25.47860672771121,42.37748760611027 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark02(25.50371229069981,-1.5707963267948966 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark02(-25.536543884357116,-89.91949939172355 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark02(-25.567260580421507,0.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark02(-25.590490423938732,-30.367573857378844 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark02(-25.605144346282394,-0.05454991727056954 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark02(25.607076066998026,-6.379453566190179 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark02(-25.69734466881141,30.841039312648473 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark02(25.749467036982594,63.500661830540764 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark02(25.763541834955852,1.5707963267948968 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark02(-25.8285097812689,1.5867304074761606 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark02(25.835158032508218,84.25762236448472 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark02(-2.5857045999216837,-40.91337908810422 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark02(-25.8853051700184,77.00417395906499 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark02(-26.00013419789728,-16.03573243019136 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark02(26.049366676685068,-0.4914010410963936 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark02(26.08414242774046,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark02(-2.6085348383602707,-43.11916769988202 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark02(-26.165546107424234,62.250881900901675 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark02(-26.17255891404524,-54.09497854212655 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark02(26.209389846512067,-0.0010178529558268028 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark02(-26.21105211602324,1.2456432305374676 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark02(-26.251268789802797,-44.21131441039594 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark02(2625.2722724584487,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark02(26.267370797763917,95.3906151049344 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark02(26.282275777005324,5.913902203515951E-16 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark02(2630.425208073576,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark02(2.630468827380966,41.53295445932966 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark02(-26.335779881807596,-1.5776613046744927 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark02(26.342571572128804,-58.051384028382124 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark02(26.36382919639645,29.600194022101604 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark02(-2.6469779601696886E-23,86.3938286903259 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark02(-26.47132485379543,-10.873108218465138 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark02(-2652.2099994804685,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark02(-26.59583821265592,4.208382985362874 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark02(-26.707141403146707,-76.80683804569045 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark02(-26.769914226920903,-51.08430284525484 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark02(-26.799904346917334,0.0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark02(-26.835481870382495,98.69027897004857 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark02(-26.909814166787683,32.996447108312424 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark02(-26.995372572758157,-60.827169682714086 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark02(-27.03260149700735,3.208943863908372 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark02(-27.064821252407825,0.0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark02(-27.073436216903588,79.434415636263 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark02(-27.18898388448909,0.0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark02(-27.198121477054325,-83.65747763192589 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark02(-2737.574200668758,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark02(-27.448032232703078,75.78310136613246 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark02(-27.549236028777088,44.004658457204734 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark02(-27.609692428832417,-95.74284933525621 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark02(-27.708838208581664,1.5707963267948968 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark02(-27.713967501780488,2491.2031128364206 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark02(-27.73043523463474,1.5707963267948957 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark02(-27.7416822898781,-0.3735535393773313 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark02(-27.742902566498785,-84.04735358706822 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark02(-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark02(-27.770378963003935,88.13961209324282 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark02(-27.87169663175564,-1.5707963267948912 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark02(-27.898541451625775,-20.796144679123522 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark02(-27.930665400919395,1.5707963267948974 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark02(-27.969743314561818,16.96381375003844 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark02(-27.9845735326235,13.971898522014497 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark02(-28.001635691673183,-57.99553807823232 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark02(-28.017877289681095,-93.80691274561788 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark02(-28.153301254411573,-92.08649978211908 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark02(-28.16931866337042,0.0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark02(-2.81998848834111,46.87323646375904 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark02(-2.8225347699675893,-20.813648399289292 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark02(-28.274308294770066,-2.0707986859664707 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333717224263,32.98672265760558 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark02(-28.27433386454224,61.26300987000667 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark02(-28.27433388121686,26.703537541939397 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882305775,0.0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882308103,1.5707963267948957 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark02(-28.27433388236855,1.5707963267948966 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882405944,-1.5707963267970915 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark02(-28.285916790948164,0.006807839766070307 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark02(-28.28977998474692,76.1348412866675 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark02(-28.32922806121705,1.5707963267948966 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark02(-28.364386024396865,-14.24113805868879 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark02(-28.384869596019193,0.0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark02(-28.39577797840512,-48.9531190541268 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark02(-28.587897748416335,-1.5707963267948966 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark02(-28.604736568971248,42.88606564695934 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark02(-28.67594094210694,-16.617520604913977 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark02(-28.7900947647026,3.552713678800501E-15 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark02(-28.950438009469188,1.5707963267948966 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark02(-28.978097005465116,-23.56216462750937 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark02(-28.99078349491369,2541.1122139070326 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark02(-29.044819127592877,-9.381398421817074E-7 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark02(-29.126808608873954,-1.415634737949592 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark02(-29.137607492448893,71.33059352424816 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark02(-2.9162385720219675,-46.93297534663514 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark02(-29.207500280871226,-2628.5470639755918 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark02(-29.2192897600777,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark02(-29.388127668325296,22.957165808462918 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark02(-29.5099899312371,45.15689703473184 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark02(-2.951804826088272,-1.5707963267948966 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark02(-29.548019350333618,-14.017361005668974 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark02(-29.556069879913707,-33.100620672906764 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark02(-29.644902929907317,9.849890229320806 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark02(-29.650189241520522,-70.49191166104602 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark02(-29.69654506274896,-0.14858514702953016 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark02(-29.829348006273463,1.5707963267948983 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark02(-29.845130209103488,0.0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark02(-29.878902702586842,-31.38215403945431 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark02(-29.909569929371344,-29.769807984426194 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark02(-30.115512571287482,-88.8302995297845 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark02(-30.13740767967488,-2613.562941174986 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark02(-30.156649332373675,31.77498655154733 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark02(-30.269772475888928,-0.03408948616149843 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark02(-30.28331625511713,-63.02870225940889 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark02(-30.32186184776715,-0.4767316388820363 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark02(-30.39188967220807,-123.55012790805561 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark02(-30.398055069172372,-70.46985803018369 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark02(-3.0570855312442404,-100.0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark02(-30.65700797764879,81.00993273768883 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark02(-3.0695256127100707,-44.727376865671786 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark02(-30.732479831215116,-80.11061266653972 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark02(-3.0752368538875614,2.070796326794946 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark02(-3.0814879110195774E-33,76.96902001294892 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark02(-30.90010565511092,-53.03332179863369 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark02(-30.916282473738633,-29.89692829048817 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark02(-30.998938890460607,17.001315833907395 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark02(-31.289685774301248,-47.551583939973874 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark02(-31.351025980271363,-1.2398460589807154 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark02(-3.141530501857177,-14.429203700998961 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark02(-3.141592569955013,95.81857578711083 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark02(-3.1415926535897714,1.5707963267948912 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark02(-3.1415926535897927,-1.5707963267948966 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark02(3.141592653593428,-1.5707963267948983 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark02(31.415926553792595,-1.5707963267949054 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark02(31.41604862091081,193.20786066049877 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark02(31.416170676522952,-83.25269405197653 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark02(-31.416205485251602,-0.5646057981316895 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark02(-3.1416232407738636,98.96016855109023 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark02(-3.141801409178299,1.5707963267948972 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark02(-3.1422961031873533,-1.5707963267949 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark02(31.429809876048246,-1.5707963267948966 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark02(31.44717653634104,86.39379713334553 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark02(3.147799409345245,23.55573814607418 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark02(-31.524039622716458,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark02(-31.531596504344634,25.393678330094957 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark02(31.59955926367459,0.31003355094526036 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark02(31.684243346639107,-1.5707963267948966 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark02(-3.1685727283282716,87.28557758217477 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark02(31.826936981802298,-5.1233994261799705 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark02(-31.87237612037714,1.5707963267948966 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark02(31.92411863555833,0.9983790115756278 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark02(-31.927038906572022,37.07209063182319 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark02(-31.973512238365316,-0.01747211471612136 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark02(-32.030652111628754,65.61605226565159 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark02(-32.04972656299326,-2557.9710065945724 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark02(-3.2056454292601816E-19,-0.5706920316693861 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark02(32.17483482330687,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark02(32.23799136588032,-6.643874535211775 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark02(32.24407230197866,-9.734009178244449 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark02(32.24429113701291,1.5707963267948966 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark02(-32.26569682065675,54.83918713621796 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark02(-32.30187851620062,-75.55922516770698 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark02(-32.333854752563504,1.5707963267949197 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark02(-32.436930862956295,1.5707963267948972 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark02(-32.44225259947207,0.0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark02(32.44831279866304,-93.31761733473896 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark02(32.5077755003787,-28.067486380209743 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark02(-32.58467145837621,25.60580497353125 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark02(-32.62462348871976,-71.89453165887447 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark02(3.266592653589986,-51.84981001467756 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark02(32.66804414575253,-39.265472706239855 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark02(32.67138957182999,5.939384586698893 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark02(-32.71795095724346,-62.09886719202675 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark02(-32.733264409413636,-1.5707963267948966 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark02(32.75648722504874,1.5707963267948966 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark02(32.76753235220028,-93.81325700365414 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark02(32.82267625428777,65.35916783614681 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark02(-32.85303213737592,1.5707963267948983 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark02(-32.93282404820816,0.0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark02(-32.94129088980819,71.57099503007484 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark02(-33.04908598612953,2.7975342636546827 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark02(-33.06348977913887,1.284657557141549 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark02(-33.42942561268696,1.5707963267948966 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark02(-33.483003095870345,-91.73118214122042 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark02(-33.52170325228944,-162.49225822336274 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark02(-33.53100328507222,-62.00925762715779 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark02(3.3843722515139425,-73.58464776133297 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark02(33.967960674375746,77.11966996323537 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark02(-3.399245504980467E-17,-10.995574287564278 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark02(-33.994407744043784,44.357904332841485 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark02(-34.00777693183706,42.22914829944082 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark02(-34.05953304695474,-10.99603483502864 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark02(-34.49526022453121,-0.7250871086843094 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark02(-34.557519189487714,1.5707963267948966 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark02(-3.457313179295657,-49.985811994248564 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark02(-34.59548826738322,-4.837388980384691 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark02(-3.461196113642636,-55.96802606939667 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark02(-34.65493041870505,-1.3771547737019807 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark02(-34.66226804832611,-2.1466277952315878 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark02(3.469446951953614E-18,-29.845130209003052 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark02(-34.9769662880701,-1.5707963267948968 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark02(3.498317324913657,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark02(-35.11090183901334,0.20905003746200634 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark02(3.5121098711515035,1.941313544463887 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark02(-35.22790217884089,6.125001793123715 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark02(-35.32512002642943,-76.20409626399207 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark02(-35.35873549785221,32.185506554472056 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark02(-35.450825277995406,-31.004378329249008 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark02(-35.45116404495103,22.503875985078864 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark02(-35.48608466969074,30.23208563026222 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark02(-3.552713678800501E-15,-31.450024200181232 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark02(-35.57203530710929,3.4731320350849105E-16 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark02(-35.59208930907691,138.9799943761265 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark02(-35.59278847442782,-60.867784405530536 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark02(-35.604859481625226,-0.5706167961167693 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark02(35.65912246559421,33.30161078693274 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark02(-35.66253144624188,0.3066650631674655 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark02(-3.5673135110929337,-7.383691744544052 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark02(-35.68358487688336,84.82364890185107 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark02(-35.73562034510458,65.3523871317438 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark02(-35.871183763623726,-54.84177681145095 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark02(-35.89836288438386,1.5707963267948966 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark02(-36.11724938313419,-9.73717622402863 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark02(-3.628127902464663,-72.25663103256524 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark02(-36.478584821184114,0.0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark02(-36.60053439008914,-88.43681317454057 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark02(-3.6655038397323665,2640.8476181143765 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark02(-36.692394468314006,-14.368824540408722 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark02(-36.70989600580086,20.468654184653573 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark02(-36.766857332511265,0.0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark02(-36.82832547775016,-1.5707963267949054 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark02(-36.9091179703335,-7.1217727736971925 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark02(3.6950700328726134,39.823385549272786 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark02(-37.09082664293862,85.72704367292589 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark02(-37.09846405206743,-0.970148535906022 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark02(-37.23320556691429,-22.60173279449012 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark02(-37.5134060198335,-36.88431394262535 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark02(-37.69911976929738,10.995698518163366 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark02(-37.699204125064135,0.0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark02(37.7001329022776,-81.22989114903858 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark02(-37.714736843077524,0.0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark02(37.75569618587736,-93.27873574864608 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark02(-37.81487279700701,-71.88204557649556 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark02(37.887017917355564,98.90716256521335 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark02(37.924508474753736,31.81148293456809 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark02(37.95637002240889,1.5707963267948966 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark02(-37.97018055024539,-5.051691409119712 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark02(38.04778551820271,0.0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark02(-38.133082004602116,-32.76407502303739 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark02(-3.815992312279991,1.5707963267948974 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark02(38.252521013943664,89.59475476252547 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark02(38.28499645165584,-1.5707963267948966 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark02(38.35350704305361,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark02(-38.360316715254996,-46.214298349356184 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark02(-38.36486275032407,-33.004160245097104 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark02(-38.3899913778867,-15.385241191593003 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark02(-38.42871163589223,65.99970359119604 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark02(-38.45883656630998,0.0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark02(-38.47653673286864,-2612.4945050860065 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark02(-38.49577922891332,-49.57541186153775 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark02(-38.49730475581886,-0.9370538678835229 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark02(-38.52304597575973,-0.4955284319305147 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark02(-38.572328420565924,-56.01305764381954 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark02(38.59939183538049,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark02(-38.63560324836233,-35.875318306092495 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark02(-38.69909951524471,66.54389248676209 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark02(-38.86788070092055,1.5601616247792265 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark02(-38.88221123528684,53.79832567169922 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark02(38.887381009525484,0.2914040577096691 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark02(-38.89522553319307,41.21538713307342 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark02(-38.898204593648835,-61.40329137950018 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark02(38.96711543774779,19.876495500200605 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark02(39.04065045179699,1.5707963267948966 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark02(39.06496045800869,-12.89643722601315 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark02(39.132865052949604,-1.5707963267948968 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark02(-39.15979877217718,20.782592124906785 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark02(-39.18200076390157,-2.432211661828077 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark02(-39.19889580616849,-1.5707963267948963 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark02(-39.34576502296265,9.00691041243968 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark02(-39.44246556040696,-68.86416991436583 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark02(-39.46619578883528,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark02(-39.61273364234323,1.8863671087509175 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark02(-3.972012305423123,-100.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark02(-39.74176700969245,-1.5707963267948966 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark02(-39.81779090834925,0.0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark02(-40.180455184745256,1.5707963267948968 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark02(-40.35383152730414,1.5707963267948966 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark02(-40.64996429767301,-44.380668081606686 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark02(-40.652918376637686,1.5707963267949197 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark02(-40.75988305185297,-64.63836690129415 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark02(-40.81999636026688,7.468689081868621 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark02(-40.84065526473984,-0.5707947731747259 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark02(-40.84070449666714,0.0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark02(-40.8407044966673,-1.5707963267948961 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark02(-40.84461717835652,4.712388965578186 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark02(-40.84465721780915,4.717699932885925 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark02(-40.965704496667314,-1.5707963267948966 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark02(-41.00681707018567,17.444872168160824 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark02(-41.07634346994147,0.0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark02(-41.1030747390798,0.0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark02(-41.12049441521508,-74.56471707788393 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark02(-41.20474402859087,-1.5707963267948974 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark02(4.141592653589795,-4.318534220349651 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark02(4.141592653589891,-61.260609397530295 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark02(4.144385729380121,53.97507836184516 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark02(-41.76141002733089,1.0388095853304484 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark02(-41.781925728490464,91.74315101426217 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark02(-41.85696210733549,1.5707963267948968 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark02(-4.185758519223938,-45.547152248396344 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark02(-41.880535908786314,-100.0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark02(-42.031465948586494,0.3800348751452901 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark02(-42.09158432849328,-12.979571093988799 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark02(-42.14362814061686,88.23246698373737 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark02(-4.221915906253246E-16,0.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark02(-42.36069387946016,-32.67244149260331 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark02(-42.39411507383508,36.714873978512 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark02(-4.250094223081771,6.078860569280593 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark02(-42.51990887394006,-79.19455955814956 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark02(-42.57000173929981,-52.926524389803795 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark02(-42.57787405849288,75.23185045052055 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark02(-42.587627346660476,0.0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark02(-42.6272401204838,-15.910877611011813 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark02(-42.63114981364382,-1.5707963267948966 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark02(-42.659145014264176,78.53981633974483 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark02(-42.66629485731016,-1.5707963267948966 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark02(-42.675091461753034,39.95726320418461 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark02(-42.70201768173602,-63.12236993041877 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark02(-42.71238049942562,-2.47780449229127 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark02(-42.72065078394624,54.977871437821385 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark02(-42.72299980082049,76.65247006996158 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark02(-42.7368509545683,-67.09846362431131 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark02(-42.79014191295821,1.158348907356631E-16 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark02(-42.79471560645969,-0.38321478326492797 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark02(-42.80226309307281,-9.807458164605649 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark02(-42.81779364973846,34.363514451509005 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark02(-42.818455597942794,42.71985143139338 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark02(4.28245791005375,97.81930333137461 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark02(-42.855034368682574,70.68583470577035 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark02(-42.869007130667846,46.345849131053825 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark02(-42.89906483148431,-3.061988343450068 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark02(-42.92615502570555,0.0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark02(-42.926255984220504,0.0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark02(-42.933824437885306,-48.694686158045656 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark02(-42.94542632818928,-90.11519497890986 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark02(-43.06271838314855,-29.245609048018736 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark02(-43.2019503209099,-4.369720284195932 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark02(-43.31277871563631,-11.665092722057537 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark02(-43.48788414751663,-36.45849555329947 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark02(-43.58300090753022,1.5707963267948966 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark02(43.73066900110905,76.69725498788739 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark02(-43.87514380400004,-50.29724466718635 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark02(-43.96665720804427,0.0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark02(-43.98228830650909,-92.67698327759322 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark02(-43.9822971501571,1.5707963267948966 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark02(43.982297379640315,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark02(-43.98230617750325,-1.5707963267948966 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark02(43.99190097744196,-54.97787131148772 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark02(44.044797150257246,1.5707963267948966 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark02(-44.172902693984774,-0.1790400877913188 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark02(-4.419166545144179,1.5707963267949019 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark02(44.23062435696735,-70.43750749916327 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark02(-4.427288910339186,86.3954107131062 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark02(-44.29470628976217,-1.5707963267948966 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark02(-44.32074441864442,1.5707963267948966 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark02(-44.3279623082669,-36.81385545441926 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark02(4.440892098500626E-16,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark02(-4.440892098500626E-16,1.5707963267948972 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark02(4.440892098500626E-16,2564.6780647107007 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark02(4.440892098500626E-16,2573.3961556877225 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark02(-4.440892098500626E-16,46.343661076013575 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark02(-4.440892098500626E-16,-48.54751947915008 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark02(44.426988584908315,-0.6041568235851652 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark02(-44.51265149198577,-129.84574078213183 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark02(44.53090131592619,1.5707963267948968 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark02(-44.573261370396004,0.35435336746346346 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark02(-44.60486452065126,0.12220854364381145 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark02(44.62465830884091,-1.5707963267948966 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark02(44.64355045938248,-36.75031793433358 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark02(4.474860963905151,-53.169547094971925 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark02(44.758302354939126,73.86940399558983 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark02(-44.83186091579798,-45.27777939252262 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark02(-44.85729357756302,-53.7195902917734 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark02(-44.89691520053028,1.5707963267948966 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark02(44.92160043581649,-20.315838459435323 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark02(-44.924216929983274,-17.66313594767459 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark02(44.957225508673105,-0.5958679685570781 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark02(-45.019420281384406,2.6372138272869563 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark02(-45.050547495442615,-25.911315062121048 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark02(-45.103490200761485,96.59177092894885 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark02(45.119531804048364,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark02(-45.133142476259614,-14.429486248822556 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark02(-45.15166057723656,-0.5211780441638908 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark02(45.17351252024077,-32.58561540941826 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark02(45.19012839171347,75.97220520699854 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark02(45.28172597087362,-146.83552468110722 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark02(45.28829967774777,-1.5707963267948957 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark02(-45.3857790513019,1.5707963267948966 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark02(45.51465326922403,2576.9824996823722 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark02(45.5354708105454,-56.56137926643043 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark02(-45.591330618672046,48.78119490674291 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark02(-45.8823816417417,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark02(-45.90562029855021,-119.25869652491158 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark02(-45.98014736176511,1.5707963267948966 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark02(-4.6235332905370115,0.0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark02(-46.33311419010466,-31.048387361125847 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark02(-46.73594724279381,-124.04566624957279 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark02(-4.676952321520574,23.914966032116908 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark02(-4.6831891324329575,83.14287534781343 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark02(-4.697511533396764,35.97911372799226 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark02(-4.701980961513437E-10,-3.0473921289930707E-15 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark02(-47.04787538885143,0.0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark02(-47.099840994239386,13.958838488168752 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark02(-47.12387563546565,75.81661497634894 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark02(-47.12388905768333,17.279247875994052 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark02(-47.12388949825821,10.995696357883071 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark02(-47.12389147904378,98.96014510693482 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark02(-47.24613618637705,-1.5707963267948966 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark02(-47.39180484624378,-16.669700118344597 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark02(-47.52094136249141,0.0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark02(-47.67502353476652,0.05496384273340971 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark02(-47.69381584789223,-59.58397239651008 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark02(-47.76577637260631,1.5707963267948972 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark02(-47.910759951300165,17.21703152044003 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark02(-4.802648419405054,15.126290009600424 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark02(-48.03237288252325,76.64443548800132 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark02(-48.08938162930505,0.0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark02(-48.123889803846886,-49.694686130641806 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark02(-4.8148248609680896E-35,-1.5707963267948966 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark02(-4.8148248609680896E-35,-39.26990816987167 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark02(-48.15916871781538,0.0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark02(-48.17966287022235,-0.2608047069980924 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark02(-48.311670449211945,-2.6347305508675336 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark02(-48.33140691146358,103.71944664548558 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark02(-48.37989951765807,-44.29708376356381 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark02(-48.52566283902095,-2603.139414074574 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark02(-48.52809075743758,73.23176299989294 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark02(-48.66745834107577,1.570796326794897 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark02(-48.69497049021373,0.0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark02(-48.73049556284952,0.0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark02(-48.74425280253996,135.23305896944336 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark02(-48.79834294199106,53.41947094228698 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark02(-48.80081454867743,-81.57528057435508 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark02(-48.80736810501309,-10.77910660799262 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark02(-49.0494172277105,-1.5707963267948966 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark02(-49.249359422189286,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark02(-49.29528520428832,0.0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark02(-4.930380657631324E-32,-1.5707963267948966 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark02(-49.422074770798005,1.2788698193003358 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark02(-49.50991763477719,-7.671547552470187 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark02(-49.56069463969381,-1.4755659580693743 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark02(-49.698689384040854,-31.86350515865756 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark02(-49.69957293603602,51.76708326407614 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark02(-49.71935021580025,-34.19964268787305 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark02(-49.7469057289501,58.82716880706053 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark02(-49.75797346997134,63.556418001476366 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark02(-49.79567961740873,-101.63195840175247 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark02(-49.81382699230752,18.449978029813224 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark02(-49.81997677435688,-57.5835021200027 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark02(-49.82402388595488,0.0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark02(-49.82780491178818,-31.677607675801383 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark02(-49.848205227725785,62.59079938612362 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark02(-49.85891334380263,85.19799667025731 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark02(-49.8886382025814,83.12164793886082 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark02(-49.90434588841407,-1.5707963267948983 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark02(-49.905548678747564,26.703537555513243 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark02(-49.932937126928245,-1.5707963267948968 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark02(-49.93440614425884,0.15146709559704197 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark02(-49.949513429125815,0.0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark02(-49.9504272615883,-85.56177999471353 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark02(-49.95807948328306,1.5707963267948983 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark02(-49.95950360682338,-1.5707963267948966 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark02(-49.98254547629906,-100.0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark02(-49.9863421228179,-1.5707963267948966 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark02(-49.99489174123137,-5.719462587377631 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark02(-50.00158891811584,-33.5333642456507 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark02(-50.00401625500931,-32.93068657253253 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark02(-50.034423004606566,-0.5696858698217478 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark02(-50.05287178281952,83.91358578953901 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark02(-50.05639043849871,-2114.2522540467075 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark02(-50.074665587194154,0.0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark02(-50.10033782295345,-44.98354814826864 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark02(-50.107249213752596,4.859943600414855 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark02(-50.10840294716334,0.19459885616577796 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark02(-50.12541644473235,-80.4098570260535 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark02(-50.14532320457714,0.043308021731154646 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark02(-50.265477957532234,-186.924018349545 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark02(-50.265482280435855,136.65911743026808 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548242465081,10.995574286131909 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark02(-50.2654824538589,-117.79922329739043 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark02(-50.265482457336695,1.5707963267948999 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548245735546,-1.5707963267948966 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548245758128,-1.5707963243572582 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548245821654,17.278759818618447 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548245836802,1.5707963267948966 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark02(-50.265482461605984,-1.5707963267948966 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark02(-50.26560987895005,-1.5707963267948948 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark02(-50.29759505914077,-1.5707963267817988 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark02(-50.322296624663565,6.5530260080296205 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark02(-50.38426354198412,29.84513021001193 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark02(-50.39253807080948,-0.31909671394649786 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark02(-50.42408521755173,-90.96614193547393 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark02(-5.049330549197336,11.127487343634286 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark02(-50.60081850910139,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark02(-50.6267040531035,-31.534335564637786 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark02(50.75091963120083,-85.3399048015864 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark02(50.79327136163377,-100.0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark02(50.79493912914592,0.19222478353027994 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark02(50.80323624974682,1.5707963267948963 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark02(-50.8760626946122,1.5707963267948966 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark02(50.87658160784843,0.3476525819225992 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark02(50.92560786938646,-36.78844092810579 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark02(-51.09432431742183,0.045826820697330746 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark02(-51.17065633610464,70.3207929595984 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark02(51.215493099876284,0.0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark02(-51.245603921373394,-4.593003063374866 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark02(51.34384509415321,2614.129453202056 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark02(-51.34752743949571,0.0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark02(51.35431760473128,31.811141448838217 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark02(-5.139639563461245,-42.74335393224422 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark02(-51.39961277145848,39.20496714312898 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark02(-51.48855234103297,-21.355982056036368 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark02(-51.49047544236473,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark02(-51.51024350153484,71.39670743331979 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark02(51.5104409041241,-14.429265507722228 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark02(51.625272704000544,-0.04092043363214721 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark02(5.172907924861002E-8,-39.19514201891317 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark02(-51.88044712711564,135.28178822806342 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark02(-52.16425199344528,-66.20179859376842 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark02(-52.38180382388501,0.0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark02(-52.540697796523965,10.95088396750721 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark02(-52.85601041207091,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark02(-53.142572384068906,1.1089502742659398 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark02(-53.28131541403991,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark02(-53.406805313082764,1.5707963264732079 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark02(-53.407075111023914,1.5707963267948963 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark02(-53.40707511102647,-1.5707963267948963 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark02(-53.4070751111246,1.5707963267948966 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark02(-53.40707715449011,-120.95229405135744 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark02(-53.40902823602649,67.54424196325654 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark02(-53.45345171856118,-67.3295128419806 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark02(-5.349424565812484,-19.3991311622592 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark02(-53.527880147912875,-48.54301831303476 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark02(-53.55743602299829,-32.26169075340961 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark02(-53.63003756257041,34.01312973117243 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark02(-53.74265519679415,85.98986821815774 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark02(53.7979371595639,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark02(-53.85519861651527,79.34922666065663 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark02(-5.386474977361559,72.27193808676239 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark02(-53.87516380705658,88.90936659334292 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark02(-54.09631713500253,-84.06498876121483 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark02(-54.202219720709465,82.6468284411684 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark02(-5.421010862427522E-20,-1.5707963267948963 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark02(5.421010862427522E-20,1.5707963267949054 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark02(-54.24729915715329,1.5707963267948912 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark02(-54.38986897678495,75.66446938309392 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark02(-54.42168740027953,-31.759466452880794 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark02(-54.51022681019526,-70.77294854820387 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark02(54.52319761515878,18.097832487070647 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark02(-54.552623678084004,-32.183377613541424 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark02(54.614017418982485,-72.16262297317809 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark02(-54.68797825150911,5.047490212847135 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark02(-5.480380519392455,-18.709363903990265 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark02(54.95127174726855,97.59696911565015 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark02(-54.97787143782358,0.0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark02(-54.98650375342878,-6.441921748014274 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark02(-55.02707998184113,-1.570796326794896 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark02(-55.035805550872325,164.65978355159058 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark02(-55.04911389590879,6.211942847687641 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark02(-55.0875572847239,96.61446099243958 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark02(-55.100490015345386,-1.5090593022142542 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark02(-55.10618001689313,-49.32673300543069 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark02(-55.13763251815094,2.465318795857101 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark02(-55.159598813557295,-1.5707963267948963 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark02(-55.17502217519265,81.48425825545284 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark02(-55.189486447820045,-26.30833468992111 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark02(-55.192667686840636,16.725749288119168 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark02(-55.20908448328371,-14.4292041690954 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark02(-55.24109997650759,-60.3899598348861 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark02(-55.2849219173477,-66.10794478527781 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark02(-55.338247852592644,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark02(-55.34776197842772,1.5707963267948983 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark02(-55.40583141830291,0.0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark02(-55.412269663260936,9.867286701301197 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark02(-55.41487613668046,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark02(-55.422007701966535,86.41967160737934 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark02(-55.48564219315857,48.65666891098033 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark02(-55.50845237476873,-0.37831716076219735 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark02(-55.526824652844994,67.46943142298278 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark02(-55.545464388450505,-24.068212970970194 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark02(-55.55909897894036,-5.737829753476896 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark02(-55.602610988256856,0.0566505000249778 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark02(-55.961595238921056,54.79035162522112 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark02(-55.99494098462435,-0.8070745887496942 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark02(-56.027353202478146,44.05295456636108 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark02(-56.040391390033705,-0.1203332254795873 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark02(-56.041710542757464,23.93707742845683 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark02(-56.05428975891334,88.92447390075097 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark02(-56.08096793981883,0.42694665477743104 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark02(-5.608616535686181,0.0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark02(-56.094775030780774,-1.5707963267948912 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark02(-56.103265392428014,31.72848048198948 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark02(-56.12025152316662,-1.5707963267948966 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark02(-56.14117547766347,-2552.820245082845 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark02(-56.163751975887,72.52943472743097 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark02(-56.16802066457457,-6.526262539452787 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark02(-56.18873833479168,-94.39051683802185 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark02(-56.202701743818146,1.5707963267948974 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark02(-5.621478087968953,0.8037844774981835 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark02(-56.23120319750548,1.8828374473883485 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark02(-56.24035262785725,0.0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark02(-56.247667876353034,2491.4056799584546 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark02(-56.280643947981424,1.3027725102637453 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark02(-56.30094934466598,45.42400971097472 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark02(-56.33072164940098,-26.48622741298162 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark02(-56.33110205865583,0.41200382402441893 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark02(-56.343486020733195,23.56194490192345 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark02(-56.36207723301863,-54.90101766169563 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark02(-56.37743741027148,-44.2106067482107 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark02(-56.39603774391831,30.770392929255802 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark02(-56.421418722003736,-55.89963951425582 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark02(-56.438658566696475,1.5707963267948961 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark02(56.50410395582401,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark02(-56.51677433216436,1.533671006273849 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark02(-56.523854107070115,-77.52158295500051 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark02(-56.52744698972364,1.5707963267948966 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark02(-56.54834578294032,4.712710961960645 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark02(-56.54843800545349,1.571774157099043 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866561710752,-136.65916652678297 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776070523,-45.555736514351 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776253179,-48.69468612798612 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776451628,-1.5707963267948966 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776451628,17.278759594743857 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark02(-56.548667764552626,-1.570796326795191 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776461548,86.3937979735821 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark02(56.54866776471628,1.5707963267948966 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark02(56.56299344228439,1.5707963267948972 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark02(56.565027834396936,73.84378742904079 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark02(-56.57954802552073,90.79769434731634 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark02(-56.71233531912267,-37.04078130632169 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark02(56.723170699816954,35.8187516686057 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark02(-56.72760307522918,-1.5707963267948966 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark02(56.82796702127025,1.5707963267949054 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark02(-56.87503590318421,172.27883908196856 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark02(56.88699853920113,1.546701520092212 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark02(-56.94952812001631,-1.5707963267948966 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark02(56.99603202554987,5.212388980384701 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark02(-57.02911731722979,1.5707963267948966 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark02(-57.080353469579194,56.28237518121708 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark02(-57.095166272904606,-148.92427966413595 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark02(57.104226511713705,1.5707963267948966 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark02(57.21130787952504,0.0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark02(-57.263445750677235,-2544.592104809791 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark02(57.28352917842904,0.0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark02(-57.30643099617048,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark02(57.3141807385049,-98.74532204883435 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark02(57.371439209307425,-63.34483703037501 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark02(-57.381764400123565,46.801280408480494 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark02(-57.437075340634955,-94.128214216158 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark02(-57.48564541757631,40.2068858230013 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark02(-57.49188143380383,-78.9587796193452 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark02(-57.514857843820444,95.47194909599389 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark02(57.535239217469474,0.0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark02(-57.694192062681914,0.0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark02(-57.845076871589015,0.6074589494041049 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark02(-57.84876436631641,-72.1095243130963 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark02(57.86718760584175,0.0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark02(-57.93013295861858,65.78411459312439 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark02(57.94628549554923,-93.38326318602273 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark02(57.99515942827655,-0.25022898195644816 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark02(58.007835570706916,-0.11162852160185432 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark02(-58.03724952144688,16.64475258894252 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark02(58.06726992627711,-0.22008514104252144 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark02(-58.51147126947238,-39.486964137814184 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark02(-58.59521447955955,93.52733258368215 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark02(-58.61201732142989,60.71007029762956 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark02(-58.99525584626464,49.346725521265164 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark02(-59.08550651512623,80.31201704255554 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark02(-59.21953073010071,-67.07351236396299 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark02(-59.483920823166294,0.0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark02(59.64652429175709,-60.738943919208154 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark02(-59.682126576032466,17.049220599168535 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark02(-59.69024675799198,-23.56975740297246 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark02(-59.69026041820302,-1.5707963267948912 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark02(-59.69026041820606,-1.5707963267948963 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark02(-59.69026082708871,1.5707963267948966 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark02(-59.73118319217509,-1.5707963267949054 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark02(-59.80123955804113,-17.80468953504017 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark02(-5.984429309472091,-1.5707963267948966 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark02(-59.8764409713803,172.37230965008257 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark02(-59.89013663179355,21.680248363788806 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark02(-59.94055874319321,-6.502337362764487 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark02(-59.95528760478264,76.23675850773233 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark02(-59.97027082390245,-75.9338195538418 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark02(-60.16709763778229,30.3219674285667 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark02(-6.018531076210112E-36,-0.5707930448628181 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark02(6.018531076210112E-36,4.71238898028469 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark02(-60.242495737562855,-1.5707963267948966 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark02(-60.273945933587456,-34.614495930744326 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark02(-60.40424933888762,-118.17948803909786 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark02(-60.59237717865409,-57.2253849610366 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark02(6.0664559875744715,26.019581059513825 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark02(-60.69491029078836,0.2936716063550351 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark02(-60.852431904750674,1.5707963267948966 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark02(-61.09055883115589,1.5707963267948966 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark02(61.19432921656923,-54.06170921210367 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark02(-61.21634827219759,-6.432543923683519 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark02(-61.239896304221986,63.451646573713916 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark02(-61.261056744997425,0.0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark02(-61.26105674500569,0.0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark02(-61.300014502444064,26.58874265639419 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark02(-6.160530771347385,0.18381661346676437 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark02(-61.66044773924057,66.21674241232455 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark02(-61.660714049840664,6.733314259612685 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark02(-61.68220276899071,0.4211460242343589 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark02(-61.75001919772267,-17.623357754151357 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark02(-61.77565674440869,0.018979522451654747 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark02(-6.1986595081415885,6.987233326912829 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark02(-62.14583110480909,86.710050486781 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark02(-62.616190905017845,7.638319467298835 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark02(-6.2676750181647405,-4.743638980384691 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark02(-62.78543138106987,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark02(-62.82572442512524,6.123233995737832E-17 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark02(-62.83178511562049,-32.99062911269283 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark02(-62.83185300326761,67.54423907228984 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark02(-6.283185306904041,98.96016858774034 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark02(-62.831853071695875,-1.5707963267949066 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark02(-6.283261977339324,1.5708729970546336 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark02(62.838352505670485,90.34116768283448 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark02(-6.284161869679587,-1.5707963267948963 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark02(6.284162274790572,-39.26990816465965 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark02(-62.85776060520818,-78.29063291896338 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark02(-6.286437385742837,-10.992322838947137 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark02(-6.287091562243988,7.85612294801826 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark02(-62.89435307179587,0.0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark02(-62.89435307179587,-1.5707963267948948 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark02(-62.905669489160054,2630.805220860628 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark02(-62.92228447713578,-16.13762163218844 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark02(-6.2935467569991195,-48.684324680722405 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark02(62.98516587445129,5.212388980384698 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark02(-6.298810307180044,17.27778424190678 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark02(-63.00178471215332,-89.15432486097474 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark02(63.0293933388689,14.575735768260955 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark02(63.037749088632495,24.84448728853266 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark02(6.305542611893841,-63.06565109839785 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark02(-63.067083844028176,1.8060270991300407 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark02(63.06888236885953,-76.85785958750587 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark02(6.308549884779069,-68.30396069503962 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark02(63.088115688772575,1.5707963267948966 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark02(-63.10043083551711,-35.85973775245766 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark02(63.10836483965022,54.44881217839736 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark02(-6.314435307179587,-73.81006941279269 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark02(-6.314435790549063,-89.56664111070496 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark02(-63.14507480641291,-0.5706797664385436 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark02(-63.16806033977581,15.355442228309204 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark02(-6.318935320522717,-43.42081347052584 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark02(6.325278575858878,0.0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark02(6.33054091131253,-1.570796326794897 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark02(-63.32937751289095,2.071524391123137 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark02(63.33433940925576,-74.61239428870398 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark02(63.51629054484253,-72.61546686357275 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark02(-63.51736701495503,0.0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark02(63.52266186290461,88.24027366653378 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark02(63.53176027078084,-1.5707963267948966 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark02(-6.363141169811925,5.082980159654109 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark02(-63.67610312468219,-77.8132700659868 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark02(-63.68515149342326,0.08601647308576015 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark02(-63.68902182311602,0.0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark02(63.75503833841678,-0.17451627100197412 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark02(-63.91619489986547,0.0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark02(6.391920134188595,-226.75609799406502 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark02(63.919806497237175,-37.19593508093095 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark02(-63.92235966842601,-1.5707963267948968 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark02(6.398647952735604,8.260552286240344 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark02(64.00964439296531,0.9041311911740308 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark02(6.417100330817094,17.412516931748474 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark02(6.420373862613397,0.0024190921208130556 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark02(6.420757926761041,0.0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark02(64.21070643104578,87.81772529834706 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark02(64.21389358784434,-88.15335011179356 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark02(64.24533533110981,-2.42935393236846 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark02(64.29118055378805,44.09376599595869 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark02(-64.35770764897913,-44.59010371365639 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark02(64.39397817344047,-0.4731980309604539 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark02(-6.450838454518909,-80.67949877048565 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark02(-64.56151658196052,-40.27927827122615 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark02(-6.459930571154005,-64.57939466266677 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark02(-6.490578518199989,2596.699493765057 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark02(-64.92802351395744,0.03184862459598021 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark02(-64.94061763742427,1.5707963267948966 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark02(-64.96571350015012,-18.28267510554281 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark02(-64.98246898650751,-0.23313186021463672 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark02(6.512193241025932,-1.5707963267949054 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark02(6.533185307179605,-95.56977144665578 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark02(6.5331853071796075,80.21400625635565 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark02(6.533185307188664,45.309558794289224 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark02(6.5430617870285355,-4.972265460130754 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark02(6.545318960395652,-67.54505586828157 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark02(-65.51538285719522,2607.0046337610856 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark02(6.5793616162956,-87.83584718851223 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark02(-65.92548621403265,-49.16515348082879 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark02(-65.97344572548566,1.5707963267948966 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark02(-65.97344785475435,-48.69455716019729 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark02(-65.97347725474476,-1.5707963267948966 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark02(66.00259319394993,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark02(-66.02243318606322,0.0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark02(-66.09965583394187,-34.148279869856964 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark02(-66.23778398526952,16.36637073977728 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark02(-66.25901901402624,0.0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark02(-66.34465789221692,-1.5707963267948966 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark02(-66.38761867420251,0.0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark02(-66.4613255331455,-5.29344205445684 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark02(-66.46455790427939,-97.89590188827265 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark02(6.665196637004826E-16,-73.82742735926014 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark02(6.701286498839628,136.65940127350245 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark02(-67.01327713750466,100.0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark02(-67.12463000254546,-60.2368263475233 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark02(-67.12899999378888,-0.11093508888222214 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark02(-67.15120029779192,12.959412369008906 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark02(6.716375803447873,20.006640437780035 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark02(-67.1826250628846,1.5707963267948948 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark02(6.718734732507278,-80.52868290858663 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark02(-6.721691339577774,136.36006390583037 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark02(-67.22490110779862,-80.77472477884538 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark02(-67.42928305992965,0.5122318154604374 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark02(-67.44099619030992,1.5707963267948948 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark02(-67.48423686848285,-17.428003362069816 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark02(6.750788421293551,33.152336697407094 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark02(-67.5830547445606,0.0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark02(-67.62184603293109,98.04855850258767 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark02(67.75827494695801,-96.82886278509552 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark02(-6.776263578034403E-21,-29.845160726684917 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark02(6.776263578034403E-21,73.82742735926033 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark02(-67.96993768858863,16.174342984075963 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark02(67.9981788816014,80.95803037752466 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark02(-68.01219793114257,49.797526578252985 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark02(-68.01642549649765,-25.23475491814946 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark02(-68.10951778233947,45.216328725713076 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark02(6.824736373402342,1.0502479254303503 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark02(-68.37645029081365,-19.347360133475753 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark02(6.860712459633314,-70.1083091291417 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark02(-6.863389953599523,-86.39379797377391 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark02(6.869422724961069,20.500653145080847 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark02(-6.869718479565753E-11,-96.75398732073211 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark02(-6.905381716947702,-141.05075043366304 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark02(-69.06998886923755,-1.5707963267948966 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark02(-69.11503837873781,-105.24330741068101 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark02(69.11503838013543,1.5707963267948966 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark02(69.11503839525848,-1.5707963267948966 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark02(-69.11503895303322,26.703537538187533 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark02(-69.11699166620677,39.26982631014906 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark02(-69.11703201757913,0.501197951042257 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark02(-69.1171291342679,-0.5568640906456471 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark02(-69.13444846139849,-17.948756524014456 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark02(-69.14209225946803,-7.73572541246395 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark02(-69.15293902679485,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark02(69.1975533460516,-0.4229422378339823 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark02(6.921996547722629,5.3511993723808775 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark02(-69.24379712489157,-23.22413159729153 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark02(-69.24484553120217,-7.964547069289225 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark02(69.29825172880658,-0.11986493796065645 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark02(69.29985844628811,-37.37294214191631 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark02(69.32766998348072,1.5707963267948968 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark02(69.33551821197062,-1.5707963267948877 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark02(69.33968719926514,60.598704796779515 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark02(-69.37209531218384,1.5707963267948968 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark02(-6.938893903907228E-18,0.0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark02(6.938893903907228E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark02(6.938893903907228E-18,-67.54424205213272 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark02(-69.39098859733998,-1.3528836229781216 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark02(-69.44692805848547,61.261056790034715 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark02(69.45489782514306,-3.2249118946911395 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark02(69.45744096174256,1.5707963267948966 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark02(-69.55589750751867,-1.5707963267948966 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark02(-69.57150089858261,0.22941276230839064 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark02(-69.59364341764937,-88.54684062506615 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark02(-69.61181225451502,22.520899291778434 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark02(-69.7845411628921,-91.96880035044295 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark02(69.79387244821712,1.5707963267948948 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark02(69.7968164403802,100.0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark02(69.8231208840618,32.60953481731663 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark02(69.82985130818395,-84.48316128314505 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark02(6.982992815055994,2615.6705608893335 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark02(69.89872955208573,0.5038563363038958 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark02(-69.99143829101702,0.0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark02(-70.07235855159006,59.83986994409166 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark02(-70.18322536029504,-1.5707963267948966 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark02(70.20663587255663,2548.6926409617686 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark02(-70.297016329042,11.216456735609404 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark02(70.30276483177164,-19.352429361052113 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark02(-70.33446825999077,13.327225649272592 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark02(-70.34287434898164,107.74322786380198 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark02(-70.38468511789074,1.5707963267948966 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark02(-70.39991070954231,-1.570947790166934 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark02(70.40134028769384,-1.5707963267948974 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark02(70.40919119958443,-93.9979120121337 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark02(-70.41313929238676,0.0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark02(70.47262581889267,1.5707963267948966 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark02(70.48376006744247,0.20207463882610796 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark02(7.050026861046534E-18,64.40313767984077 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark02(-70.78091572425784,-1.5707963267948966 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark02(-70.9085117076452,3.3642696550118463 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark02(-71.00692637449903,48.65031967085639 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark02(71.16390048662652,61.02542158249321 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark02(7.120465595937603,-2677.1269001666196 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark02(-71.26427341607351,-59.28591214785679 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark02(7.131819975913501,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark02(7.141176114479897,-1.5707963267948968 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark02(7.14902961579783,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark02(-71.51466773872288,1.5707963267948966 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark02(-71.52433178599667,-83.1921081278177 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark02(-71.69180335579344,-1.5707963267948963 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark02(-71.87150483327326,54.265393174055134 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark02(-71.88048673698188,-39.646052465563294 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark02(-71.89758783678175,79.97102824575879 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark02(-7.2146836429381125,1.5707963267949054 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark02(-72.2561444281569,-1.633296326794897 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark02(-72.31009715800687,-23.391474616834643 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark02(-72.39945473881636,0.0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark02(-72.57117058482908,0.055640191702438155 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark02(-72.60428399931806,-31.667942906585033 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark02(-72.65653236560493,80.56526742446101 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark02(-72.65998022600945,0.0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark02(-72.66606118494835,-1.5707963267948948 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark02(-72.71972397483214,91.55571351348405 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark02(-73.04288488107022,-1.570796326794877 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark02(7.3143582103193205,100.0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark02(-73.29951316157897,-2507.9401767497216 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark02(7.332760002985895,88.48581593170363 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark02(-73.35913209226894,82.23450269843039 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark02(-73.49378199645788,-1.3231760161249884 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark02(-73.56250547497044,-9.742995175631336 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark02(7.359948932576273,-14.439802646956139 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark02(-73.67582941090194,0.0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark02(-73.79404698878366,-72.9618462014862 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark02(-74.1372747730694,1.5707963267948966 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark02(74.61337200060953,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark02(-74.63145571436618,75.91853736545212 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark02(7.478682491035289,-72.31838136843633 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark02(-7.49321666678336,97.02860729437576 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark02(7.516049010246292,-1.5707963267950333 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark02(-75.21788390479885,-7.551694763569658 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark02(75.30697260609264,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark02(-75.33379035754386,0.0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark02(-75.39714281449287,10.996655598356213 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark02(-75.39822368615503,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark02(-75.39834575649031,-39.26990816966595 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark02(-75.40086625194293,64.84306316454183 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark02(-75.410743055855,-1.5707963267948966 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark02(75.452249159321,0.0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark02(75.46656364988988,-0.4067384452753902 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark02(75.49580546599432,0.0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark02(75.54438880559593,-1.4246312074550829 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark02(75.59120015279052,1.5707963267948948 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark02(-75.61744016679721,-92.09943352169996 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark02(-75.63403086081789,-73.4330636481764 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark02(75.70298414675318,-0.49999995375143264 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark02(75.72459806823937,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark02(75.79725281144363,-87.15075789341222 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark02(-75.81088372514103,-73.83629187476872 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark02(-75.82405391700846,-54.86280865705031 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark02(-75.8360684939428,-108.00033675323894 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark02(75.86132539193943,6.414659605333227 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark02(75.88321425884224,-31.468247859171257 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark02(-75.89236581513201,-85.89965584462875 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark02(-75.91114973553942,86.51088750515899 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark02(-75.93949668219373,1.5707963267948966 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark02(7.613191645784909,94.00698961908489 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark02(-76.14836943058131,77.7191657575129 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark02(-76.16368906227483,1.3397063647398677 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark02(76.33546421368537,1.5707963267948968 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark02(-7.642406453943363,-53.61865029058143 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark02(76.43326540994823,3.860854206596798 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark02(-76.44226455577669,-53.524070920029956 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark02(-76.53856042207165,28.60607581306158 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark02(-76.58364198359737,-1.5707963267949054 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark02(-76.59413275131249,-68.50168667354666 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark02(76.62531348671757,28.669660084730936 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark02(76.6533352164991,-1.361766847504171 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark02(76.67121566009644,-0.29780435319430076 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark02(-76.68005886287561,1.8900234200442583 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark02(7.673555969737391,-59.645659047009275 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark02(76.93075727074182,-42.43398521701871 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark02(-76.99681972154812,-6.4297687593631645 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark02(-7.703719777548943E-34,124.1007223174595 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark02(-7.703719777548943E-34,29.845160726709796 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark02(-77.04320623919358,0.0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark02(7.704601924763075,-0.7895241620512485 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark02(77.05318970460235,11.412851076041221 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark02(-77.09399043170085,-3.266563071538498 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark02(-77.11407405585058,-88.17295912515455 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark02(-77.13134340799127,254.9374804482507 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark02(-7.715693641995554,1.5707963267948968 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark02(-77.23237206219393,88.73560455567261 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark02(7.729279107652479,0.1247025271259256 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark02(-77.34477815019925,-1.5707963267948912 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark02(-77.45824127311269,75.70572716525547 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark02(-77.46968883886909,-2677.8712610549 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark02(-77.49471530446687,123.04778020292937 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark02(-77.53816400238748,1.5707963267948966 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark02(-77.53920079742598,135.27374314814293 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark02(-77.88981812264575,-10.850682352510304 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark02(-7.791318155970496,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark02(-77.97718092951666,0.0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark02(-78.01797801196099,98.34829573098324 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark02(-78.03405051168323,0.0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark02(-7.805505224990867,1.3251528695217085 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark02(7.815942209683216,-0.20731477829200629 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark02(-78.2463090460282,0.0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark02(-78.3229234185723,-1.5707963282996984 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark02(-78.36161148996023,85.90725164455753 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark02(-78.47476501603748,66.50074140162657 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark02(-78.48115779958347,-1.5707963267948974 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark02(-78.53673168519947,-0.01387242300557417 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark02(-78.53860654397428,1.5747025767953908 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark02(-78.53981633640893,-136.65928929048147 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark02(-78.5398163397258,45.55309347195506 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark02(-78.53981633974479,-89.53515316389509 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark02(-78.53981633974482,-1.5707963267948966 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark02(-78.53981633974482,1.5707963267948966 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark02(7.853981633974483,1.5707963267948966 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark02(7.853981633974483,-36.74557390868575 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark02(7.853981634284925,0.05258017033548252 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark02(-78.54030462099483,-149.2255637650401 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark02(-78.69262193862477,41.248723459789346 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark02(-78.72413531828326,-89.43606953305645 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark02(-78.7320478988307,1.5707963267948966 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark02(-78.91240651523871,55.3504616132079 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark02(-78.91417142690673,6.488021906531969 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark02(-78.93697903559215,-61.78886691401817 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark02(-79.1962790184019,0.41259708272943785 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark02(-79.25291713342673,-0.18372048223927714 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark02(-79.53788005332675,49.56101899977199 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark02(-79.83218207964072,31.694357123160778 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark02(-80.05496836429275,29.23070716948019 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark02(-80.06288441961608,2682.485705167301 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark02(-80.1106126665354,0.0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark02(-80.37425435302742,0.42372598784683646 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark02(-80.39112602013145,56.51270406308282 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark02(-80.96655684101009,45.53489669501462 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark02(-81.11102459487014,46.16319209986045 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark02(-81.11527322641345,44.986957710249314 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark02(-8.113727627419536,3.404473297893931E-10 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark02(-81.29313533994474,-43.44327220479567 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark02(-81.32067484320416,-1.5707963267948966 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark02(-8.137630836131905,26.812695834348574 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark02(-8.148417167979275,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark02(-81.68140905334545,-1.5707963139367522 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark02(81.68143951091275,-1.5707963267948966 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark02(-81.68143951094294,-54.97888056329884 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark02(-81.68143955391598,1.5707963126021771 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark02(81.68144023857529,-67.54424196641281 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark02(-81.6815120804059,17.278761377073266 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark02(-81.6970340004461,-51.85190378423159 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark02(-81.79540735502862,2522.0013468860916 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark02(-81.83969252317314,0.0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark02(-8.187942666630164,0.0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark02(-81.92110275039872,27.892661208801094 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark02(82.04397843899203,7.490870650159437 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark02(-8.209895982097763,100.0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark02(82.10992378726888,51.40776399040727 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark02(82.17802645260221,62.60151848493513 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark02(82.19660214439054,-27.81122578510238 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark02(-82.19741742784167,44.234255880022346 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark02(-82.21617507531988,0.0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark02(82.26416376613045,45.434637256481096 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark02(-82.2874957400868,-2616.8528499788995 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark02(82.37048681201281,-11.451222231692682 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark02(-8.2376659519134,1.5707963267948966 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark02(82.38035628262779,-42.817774887745905 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark02(82.45188952515902,91.2084289312591 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark02(-82.46842209555349,-162.80010666766609 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark02(-82.5235108945723,-14.261348785329094 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark02(82.54523453609534,108.55061554473696 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark02(-82.59588747986398,0.0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark02(82.61494815654181,-0.10606587178137412 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark02(-82.68140899315308,9.995574287560736 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark02(82.70044241869107,226.29535215989094 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark02(-82.70180292001103,-0.9710642187822703 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark02(82.77563604720808,64.65746919675624 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark02(82.77936269421787,51.662729549318186 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark02(82.86899455936512,-88.20073142460208 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark02(-82.97549575193987,0.0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark02(83.06309013398216,0.0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark02(-83.09298063400675,36.30926786996099 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark02(-83.19718483070997,-67.41590446850331 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark02(83.23742301324351,-87.68985824576872 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark02(-83.24182834578131,-56.655611780275585 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark02(83.24558009814709,-2636.6019573213553 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark02(-83.35745701790809,1.5707963267956409 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark02(-83.3758731642198,-84.47571020832824 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark02(-83.38384583909864,41.93892069764604 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark02(-83.40601815418596,-1.5707963267948972 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark02(-83.55416683764601,1.5707963267948968 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark02(-83.6288674865526,58.89400013890145 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark02(83.85466769491069,-5.866568627333194 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark02(-83.90297146354992,52.75630896777116 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark02(-83.97484366269282,0.0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark02(-8.413111476752364,-44.30613356460793 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark02(-84.18764003388706,32.79037142431825 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark02(-84.2211837587157,0.0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark02(-84.25505813117694,161.22407814400825 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark02(-84.28406942315824,1.5707963267948966 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark02(-84.29372269107614,1.4095264966813734 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark02(-84.31451431865327,2636.275038925359 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark02(-84.34655717085202,-11.65324573507742 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark02(-84.5096882751695,33.038681893572885 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark02(-8.458075338088776,83.0620196496794 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark02(-84.63957658317565,-0.20677012766214464 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark02(-84.64279368111518,-2271.2402944687906 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark02(8.470329472543003E-22,-45.55309347715127 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark02(8.470329472543003E-22,61.26105674490097 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark02(-84.73044423998427,84.27029186069257 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark02(-84.73285312163554,-0.5554428276924362 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark02(-8.481325562904885,43.02625907407048 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark02(-84.82300148471043,-95.81857592950497 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark02(-84.82300164691814,1.5707963267948966 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark02(-84.82300398926317,-61.26105661722366 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark02(-85.04489868866354,-14.048823551867194 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark02(-85.10191453622605,44.31828452480951 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark02(-85.27658102990748,0.0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark02(-85.42048792702039,0.0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark02(-85.45004616250003,44.214174925873564 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark02(-85.49971218240172,-100.0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark02(-85.59706108640266,-0.002126399746061658 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark02(-85.62726142239585,-18.08301937007113 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark02(-85.78418780092065,-0.27470908655885556 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark02(-85.81531732222187,-1.5707963267948966 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark02(-85.8280053088228,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark02(-85.90562277092224,123.94295530562312 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark02(-85.90698734734022,85.03423580641353 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark02(-86.0412028983126,-95.41966480163052 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark02(-86.10767217683579,-36.55267121552508 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark02(-86.11961297892627,-44.25648214541947 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark02(-86.18505673548214,-32.1104352261505 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark02(-86.28829771093945,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark02(-86.39379797371734,0.0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark02(-86.49477094885883,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark02(-86.85071295492672,80.87853442159309 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark02(-86.85146315797168,-25.59040641319703 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark02(-87.20159928994862,93.52678784256639 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark02(87.66729486856849,42.48810343650493 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark02(-87.9645943079648,1.5707963267948963 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark02(-87.96460955930328,1.5707963267948912 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark02(-87.96460955930338,102.10176124117613 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark02(87.98842856327235,50.68770311104905 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark02(-88.02069429929422,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark02(88.12735561001654,-1.5707963267948966 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark02(-88.17299235120662,48.17552210259052 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark02(88.19814310648968,0.19748376021725797 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark02(88.23728694001395,0.0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark02(88.26085104688423,1.5707963267948983 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark02(88.30134513830771,-98.0841489232333 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark02(-88.37633348216029,63.917017311372945 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark02(-88.4273235506116,-110.48044452573082 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark02(-88.43072153301301,-68.86133450689888 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark02(88.4877060176882,0.0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark02(-88.49573411629689,77.7708437888388 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark02(8.853981633974774,-62.27776994067419 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark02(-88.55709690838289,3.2585436398620864 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark02(-88.66995729946791,66.0506296541175 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark02(88.70716641520318,-36.167580102773705 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark02(88.73981668699429,1.5707963267948966 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark02(-88.76804559220908,-1.5707963267948966 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark02(-88.7815361017279,-90.69320692380307 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark02(-88.79109788460534,-2.25134468938451 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark02(8.881784197001252E-16,0.0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark02(-8.881784197001252E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark02(8.881784197001252E-16,-24.519331641055487 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark02(8.881784197001252E-16,-9.763975603601523 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark02(-88.81812114922505,94.226114798851 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark02(88.83512952444116,78.41547726950947 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark02(88.86252254517316,-2614.154886227223 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark02(-88.86998950156533,0.0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark02(88.90757252037483,89.63089823962409 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark02(-88.91335770766162,30.002175349997998 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark02(88.96262081324986,16.123392703706102 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark02(-88.97052839616514,80.4584733077188 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark02(89.10448665483551,0.0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark02(-89.16424930683404,1.5707963267948966 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark02(-89.20442466808211,89.5317295532482 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark02(89.22733824327068,-98.73458378284532 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark02(89.30491834693993,0.0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark02(-89.3401352172202,-43.291763238354605 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark02(-89.34460565789809,2.7288186834333525 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark02(89.35838077801156,0.0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark02(89.3988849320344,-57.925087220578135 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark02(89.4144637813297,0.0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark02(89.51685637721437,17.36347988825804 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark02(89.5289120752424,3.2120484266907994 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark02(89.53432746830401,-12.567433865304764 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark02(-89.53539062730911,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark02(-89.64961807878913,-18.96442460110302 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark02(-89.6812824145805,-95.51049696474279 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark02(-89.78783920544555,-1.5707963267948966 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark02(-8.978867462777146,-0.07325393832722207 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark02(-89.87292813002783,-17.983306078914325 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark02(-89.87551909915106,-9.084649489227173 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark02(-89.94585169736294,-34.1470581196845 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark02(-89.98035566121845,-17.278760687116833 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark02(-89.99792157615408,-8.537546456006964 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark02(-90.02112350144861,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark02(-90.04007686386262,86.33309228957268 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark02(-90.17520255301513,-1.5707963267948983 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark02(-90.19832841564653,16.04147025545869 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark02(-90.25380163246129,-0.11412824673365479 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark02(-90.63978316823976,-183.8013771706488 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark02(-90.64674935067016,45.53415853151648 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark02(-90.65988246223982,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark02(-90.66290908317237,0.0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark02(-90.69139455719956,1.9855887238086078 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark02(-90.81503155025727,28.819320445361512 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark02(-90.82644800968687,28.53967690611612 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark02(-90.85269008135799,-25.9562278480347 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark02(-90.94947124258668,67.7353237275287 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark02(-90.96769196349052,-1.5707963267948966 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark02(-90.97708519322529,-3.563554254834358 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark02(-90.98259927639451,0.0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark02(-91.03287885725115,-79.72711138228894 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark02(-91.05502472134204,68.059854364538 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark02(-91.06932429182064,14.653147914956556 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark02(-91.07131815705893,16.138343023094656 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark02(-91.08986778443344,-66.39031001966963 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark02(-91.09491745274603,23.5619451069274 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark02(-91.10612630966705,-26.70353418235777 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark02(-91.10617641891189,1.5707963267751035 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark02(-91.1061869535258,0.0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark02(-91.10620221289312,67.54424205155293 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark02(-91.110093204104,-1.5707963267948966 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark02(-91.15311429659695,-4.837388980384691 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark02(-91.23546853751088,-62.56978277147485 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark02(91.32645817040509,-99.84056359016955 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark02(-91.71401074903594,-63.430494708213956 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark02(-9.195453558525184,2590.5766625475835 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark02(-92.04865499977781,-28.181675846562953 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark02(-92.10760070804436,57.64475999689972 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark02(-92.146018366223,-100.0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark02(-9.231227615319469,20.890506751490264 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark02(-92.52768151321538,24.93372448066521 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark02(-92.56571426135952,0.0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark02(-92.61247920178333,-0.570248312851808 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark02(-92.64538500119997,-0.12189307024275284 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark02(-92.714437857591,3.5992606505895566 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark02(-93.51543028389763,18.97191952319937 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark02(-93.63991559496053,62.17557767267214 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark02(-9.383590941799055,0.3340896652397146 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark02(-9.400661850657906,-44.01616842056615 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark02(-9.4039548065783E-38,1.5707963267948966 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark02(-94.07023059830397,-5.111822509964867 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark02(-9.424686555572768,-0.43351473746448266 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark02(-9.4247779581553,-32.986722802096715 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark02(-9.42477796003864,120.95131483341895 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark02(-9.424777960769378,-1.5707963267948966 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark02(-9.424777960769378,1.5707963267948966 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark02(94.2479016780063,-42.41150008314357 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark02(-94.24790361052665,1.5707963266515106 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark02(-9.424813659047697,-73.82742575877836 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark02(-94.26224349159223,-1.5707963267948966 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark02(94.27902960769404,-1.5707963267948966 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark02(94.32172462356215,-53.93873097498927 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark02(94.39539755605631,13.658725854322117 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark02(-94.40594697211449,1.5707963267948983 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark02(-9.449626438212182,1.5707963267948966 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark02(-94.51934413097831,0.0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark02(-94.52727533031447,99.5237821376135 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark02(94.75520403680608,1.5707963267948966 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark02(94.82762970305197,0.0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark02(-94.9313802794403,54.37827576954302 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark02(95.00884443847735,0.0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark02(95.01996757147938,88.1940405877281 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark02(-95.07799396140166,0.0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark02(95.11696977076878,70.90954646637445 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark02(-95.12230288816296,-38.63329717651614 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark02(95.14195379557472,0.0673037902526315 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark02(95.19331529827737,-1.1038437328276729E-8 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark02(-95.2332678233771,-1.5707963267948966 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark02(95.24978458748227,-38.400024520639505 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark02(95.2907330955205,44.51013998942385 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark02(95.32916215017013,-31.211153673422018 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark02(95.37751019817213,88.53421129789832 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark02(95.45280250218411,-1.5707963267948966 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark02(-9.555346301345338,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark02(-95.62984042051548,33.124368495624026 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark02(-95.7282090973594,0.0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark02(-9.573087097769829,2576.9202878215215 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark02(-95.74832475308119,100.0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark02(-9.5780473421504,-2597.463151295656 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark02(-95.81607562267673,-140.45569881683997 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark02(95.81857593448471,0.0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark02(95.81857593448728,0.0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark02(-9.584472873251968,88.18312655754784 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark02(-9.629649721936179E-35,39.26990816987241 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark02(-9.629649721936179E-35,-4.7123889803846915 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark02(-9.654859149114017,27.502568607802402 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark02(-96.59111277320136,-24.830379522983165 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark02(-96.62504689786833,-0.00749933252632401 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark02(-96.70416817744194,0.0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark02(-96.80361627456737,-18.84955592153876 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark02(-96.81374706485857,-2620.6731592113547 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark02(-96.83782574330179,51.98318087301838 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark02(-96.87294414860375,1.5707963267948966 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark02(-9.696076608420583,-1.5707963267948968 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark02(-96.98583386668751,89.93892902201392 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark02(-97.01910767215917,86.3937979738709 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark02(-97.37789841011573,1.5822701780627602 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark02(-97.38937226127702,-95.81850203081733 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark02(-97.39718476128377,1.5707963267948977 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark02(-9.751205684567239,0.0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark02(-97.67521910094062,0.0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark02(9.772480226439612,89.5354516624741 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark02(-97.74848255863412,61.62314029779455 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark02(-97.84941353039511,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark02(-97.96516242307618,90.06836962416318 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark02(-97.98622947371103,-63.80579218628422 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark02(-98.12220133514171,21.300595381989993 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark02(9.81783735315975,73.43436796686152 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark02(-98.21925334871689,27.64268211144669 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark02(-98.5915979136005,-74.21245114554112 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark02(9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark02(-98.6336331310388,-1.5707963267948966 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark02(-98.64457846361265,87.42775814445214 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark02(-98.84230885202987,-6.165325570280622 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark02(-98.87191608080246,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark02(-98.96016858805604,0.0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark02(-98.99023808182271,-70.31584512066954 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark02(99.21077172011093,34.51638562044786 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark02(-99.28960111970322,-31.05955684059802 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark02(-99.31063264971077,-2.5786151897685783 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark02(-99.48292113031363,2510.1818698034886 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark02(-99.60020012262984,168.66919590650969 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark02(-99.67001847043338,43.86793643595569 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark02(-99.9053355235501,-135.65410668993493 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark02(-99.91852912192329,30.45756600193092 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark02(9.997696859342775E-11,1.5707963267949197 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark02(9.999273376037743E-11,-1.5707963267949039 ) ;
  }
}
