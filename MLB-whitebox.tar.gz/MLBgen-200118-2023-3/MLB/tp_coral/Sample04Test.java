import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(-1.3857470901710602 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(-14.425510411237497 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(-1.494140625 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark04(2.0125861569016905 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark04(33.3811939529495 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark04(-40.096235671869664 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark04(-40.12186677536887 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark04(-40.19084461474219 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark04(-40.19140625 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark04(-57.251056361841734 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark04(-709.0433506572008 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark04(-709.2231155481064 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark04(-709.5017217943453 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark04(-709.8084888981833 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark04(-709.8892150841351 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark04(-709.89763397357 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark04(-709.920429299824 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark04(-709.9739131558156 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark04(-709.9868085423142 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark04(-709.995769510961 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark04(-709.998166010311 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark04(-709.9987895256518 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark04(-709.999849210918 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark04(-711.5740763148178 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark04(-712.0722571373898 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark04(-712.4104075253125 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark04(-72.52309740035835 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark04(-727.6842064901375 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark04(-729.9629368331331 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark04(-734.3154027301662 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark04(-735.4472895588659 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark04(-73.9737240177491 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark04(-745.3158490396295 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark04(-745.3765303427191 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark04(-745.9253266538394 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark04(-745.9999996495719 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark04(-745.9999999998012 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark04(-746.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark04(-746.0000001235869 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark04(-746.0000006566197 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark04(-747.19140625 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark04(-750.19140625 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark04(75.6684080047514 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark04(-757.0096090240183 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark04(772.3860583761998 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark04(80.90699381360639 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark04(-83.51758413356924 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark04(-84.49179221080085 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark04(88.25440465212696 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark04(97.65073587454734 ) ;
  }
}
