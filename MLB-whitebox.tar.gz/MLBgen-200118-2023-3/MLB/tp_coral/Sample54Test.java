import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.018705292809688467,-0.5586391566916151 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.02606179238318495,1.0596700999879283 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.027853929299065064,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.09914476215239496,1.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.10982414343081626,-83.225947870667 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.12659792754545318,1.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.12909071963177277,-0.5597578426460358 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.13063222015485643,-16.371947806581154 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.1322582006957309,78.30441330205247 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.14540933715959067,-1.0000000010072716 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.1522068306494333,5.35397095851885 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.15739531204551738,-100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.16443256719642863,-1.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.16623427067235105,2236.867152680913 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.16698033572634574,0.013838004837414264 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.16994899125512072,-1.0000000000000018 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.17436379797180251,1.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.17825860533472415,-0.44070928120476793 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.1959760518359347,-52.96892691221725 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.19738201942839928,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.20238408100710714,-96.93301627650298 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.20985201392732622,0.03698730146081211 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.22341532880291184,-1.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.2346399639770529,-26.286502829688448 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.24300889142119786,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.25964696163449763,9.903241978990906 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.30465196571622255,-100.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3055047733772991,-2169.7651410156905 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3181983473875514,-26.54643642149406 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3224693879474372,-1.2272733663244316E-91 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.32536656143414866,1.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3497181476419398,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.35506735886198726,45.46578978158638 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3561781698210114,0.9999999999999998 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3681909167361166,-1.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.37961906024673975,47.17951038575008 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.4299080825003756,1.0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.45069682424073676,69.48675014047521 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.4734779862264481,-1.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5052563831805901,80.90687573551655 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5077214050532737,-0.059126750400261774 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5225206640468077,-81.41561185214347 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.523946581833818,-0.36294577217235546 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark54(0.005325714193886277,-0.3342742772906432,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5435410621275898,0.003435573455293564 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5634567989668966,-1.0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6195836322093639,-1.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6954494623822693,51.929776876958755 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6957580671124344,77.66818672522187 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7260894168175362,-1.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7364161017533744,-0.9099286400772746 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7409625925061318,2525.996607041371 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7695865642462234,0.4011724976238442 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.775133498380479,-0.2359243594827456 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark54(0.007846531000228502,-1.4771265884240907,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8000449347352205,-0.9999999999999996 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8379384387406712,-10.186986407598061 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8609465497629178,-57.19241310977651 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8687009720168604,-0.054393582595269 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.872839393452124,0.06255255753203358 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8739689991970742,-1.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9246690230236059,-1.0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.931158752250937,-0.9999699401379449 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9469689175104037,1.522878841700578 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9530577930685933,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9874225677583235,-15.589414047158291 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.019369525371161,-73.71488964948527 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.138108986836516,-1.0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.142302039288964,34.07303076913855 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1616372440644227,46.60004378921782 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1882307310462465,0.05503640701916272 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.2378590623825598,-1.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.289140074045878,0.8677434097088753 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.2919284025109858,0.7453748474625272 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.303497059241975,-0.021293099262902154 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3065123826103928,0.5437750347964703 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3214969267630297,-0.18036345588773717 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3307209040790013,0.9999999999999982 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3387605041922865,1.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3427226281205922,1.000000089116593 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3534341838889332,1.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3603343278811244,-3.485666219022959 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3955412736241413,0.6951903881192567 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4097446072861644,1.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.413092532580841,1.2689709186578246E-116 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.418800589268689,0.8328883586096042 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4239277310461205,-0.933813259982345 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4311877657373144,0.12010995920924547 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4345860207491974,-1.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4520689119758856,1.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4544487331012004,-1.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4555384416277568,0.3649161585883073 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.466146507092219,0.6790657373306065 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.470847921560091,-0.9999999999999173 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4709101051916773,1.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.472189097831999,-1.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4724317003192064,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4732535771493651,1.0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4736753019049995,-0.04950174155160565 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4903426854517068,-1.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4925740437391104,-75.95079699001505 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4978298777711412,-0.923658916889726 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4995896890364924,-0.9999999999999996 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4998099763730206,-6.909057624975128E-9 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999993070255049,46.010720034898924 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999985828267,0.9995116165730988 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999820035,1.000000000125457 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.499999999999036,1.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999951,-2369.861886018475 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999964,93.98243867759342 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999982,-31.055789311430388 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999982,47.83001528910259 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999984,-0.048615379710573316 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999996,16.253849078824725 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999998,0.0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.17171706922066948,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.7763568394002505E-15,-0.8766482307050976 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.7763568394002505E-15,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.7989953112644962E-9,1.0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.18591547236276362,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-2.220446049250313E-16,0.0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-2.2601329739470403E-9,1.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark54(0.024841513205188903,-1.4078011083430617,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-2.9482959107952337E-5,5.292764745040215E-5 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark54(0.03396349055549308,-0.6845522079081388,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark54(-0.03554147524435531,-1.4927645632283568,0.0625527429098303 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark54(0.03622446713622196,-0.7039706598542934,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-3.76762043692937E-16,1.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark54(0.03915582435867293,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark54(0.044452411363874234,-1.2682327599089918,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark54(-0.04493406065420599,-1.2782983110995825,-0.37551678355966545 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.576664855185728,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-6.20260064581006E-266,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-6.881742311905665E-9,-0.0625525252315418 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-7.507835637389824E-17,19.366545013169187 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark54(0.07769961261780564,-0.06797367133268395,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark54(0.09594380366684163,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.0005512650323674,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.0131204156544413,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark54(0.1026310922349083,-0.16346123317201783,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.0372773074770976,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.0850776404248805,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark54(0,-10.976089422865272,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.1090023076410995,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.1392378155556871E-305,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.194103679508105,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark54(0.12120328507772626,-1.0107284175273321,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark54(0,-12.612423082827021,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark54(0.14367232699017007,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5145253578312055,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5707963267948748,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark54(0.16410244871167667,-0.5041119850561956,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark54(0.17454622810370568,-0.14942562049055708,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark54(0.17666445707355236,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark54(0.1819577503712395,-0.6716269044741836,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark54(0.23504949082340776,-4.6804998255934025E-6,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark54(0,-23.5672024059473,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark54(0.24346921114067666,-1.4999999985040962,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark54(0.25153326663703507,-0.11615413228337108,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark54(0.2582081957720882,-1.8630665201583676E-8,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark54(0,-2622.2276621843534,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark54(0,-2725.2599488109363,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark54(0.2917528048568272,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark54(0.3168158499517091,-0.03388130721553799,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark54(0.3256533392003149,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark54(0.3302402405218603,-0.9118667643085149,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark54(0.3462199724728663,-0.7848371812531547,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark54(0.34866547855384056,-0.010741168004976487,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark54(0.3540841126587111,-1.1049012480110605,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark54(0.3593620167647897,-1.4772666139480355,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark54(0.36450094033125424,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark54(-0.3665606166069686,-0.8621836831225965,0.9732140170128177 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark54(0,-37.84112951601366,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark54(0,-38.36189555369549,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark54(0.41615456983139154,-1.1522703054007248,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark54(0.4332330860093494,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark54(0,-43.69100169878506,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark54(0.4408880939845039,-1.2606844016320338,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark54(0.4415298170535209,-0.8282884453476904,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark54(0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark54(0.44828847219281176,-0.06941048447906624,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark54(0.4616733860645672,-0.5168703850908454,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark54(0.4676165675237378,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark54(0.4841758568168739,-1.3016268761465373,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark54(0,4.92886407155496E-22,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark54(0,-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark54(0.5132502774754273,-0.6812785931327596,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark54(0.5501359618319637,-0.2583115582458575,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark54(0.558369014077222,-2.068526573935391E-5,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark54(0.5687815319178431,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark54(0.6035060276555271,-0.6985302037582244,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark54(0.6401477286217299,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark54(0.6408711435478978,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark54(0.649188538049458,-1.1941792954786195,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark54(0.7048804624524883,-2.5372102546176536E-8,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark54(0.7245853512267217,-1.1405787361498374,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark54(0.7271841960670686,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark54(0.7314707117314754,-0.9152160938201823,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark54(0,-74.07057565453584,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark54(0.7420303162017644,-0.028835523828965925,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark54(0.7787522515845922,-0.45531950668588683,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark54(0,77.90822608157984,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark54(0.7795925369379404,-0.8828549340189572,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark54(0.7944587033491359,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark54(0.8159917083785229,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark54(0.849081966414523,-0.3518528465252182,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark54(0.863460870534518,-1.2779244460719778E-9,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark54(0.88338872694543,-1.867734913585407E-9,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark54(0.8966163103374019,-1.091702346717852,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark54(0,-89.76281347236005,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark54(0.9050979936596804,-0.3489156998015903,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark54(0,-92.45602395322776,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark54(0,-96.69136474551922,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark54(0,-9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark54(0.9989830912083055,-0.19986196237908138,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.0012682583179781752,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.0034924030105119193,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.00542310613465237,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.01415039658750071,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.021335354740429673,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.027029258874905253,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.028808145142240116,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.04112023385226716,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.054463962953493615,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.09550499366143114,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.12285715397450815,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.12287103323815762,-1.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.13920242217990975,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.14706851226909792,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.16727450091848442,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.1872238345419015,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.2200152197497829,-37.923874650483 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.2288768484439537,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.22935541774321055,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.24693843147909256,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.29586884067454255,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3118563067278599,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3188518102769565,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3220057330876016,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.32766410869935436,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3313389487594455,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.35360917902780065,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3693348421832532,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3841779101643439,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.39882658929353465,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.42074253900614433,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.4235585195042235,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.44557023220639813,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.4459629644048093,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.470086214345762,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.47664437143038496,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.4801586928867962,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5028773797940678,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5338348631688663,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.5539712899092479,1.0000000238290778 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.563685969092794,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5689677934773822,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.592051952838988,1.0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.6342910133155231,-1.0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.6371510127090265,-1.0000000000163562 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6750303529535358,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6766634826071174,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6831112392378529,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7371555807186508,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.744120631654735,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7508263852987573,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7599995312071571,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.7958964492631616,1.0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8416425863263818,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8512884823643023,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8600103766575513,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8790241504587865,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8801243860315417,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8818727447053718,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.913673530065326,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9168937830329094,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9693691309900263,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0090785770500212,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0245500295879866,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0652149491385625,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.0658013670735724E-9,-0.9999999997162833 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0775709123986725,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.1008515665138602E-15,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.1117464254723788E-8,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.120292257551358,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.1474842877515803,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2093934386579424,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2114757686082331,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.212363870098891,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2244449731476468,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2268712714218146E-8,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2391826906405083,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2440341137961486,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.256937899688564,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.272080013522367E-9,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2994080429899912,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.3066838610740898E-8,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.3074691691424545,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.3287163150254742,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.3690158019958183,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.3955567594524305,-1.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.401014183754152,-1.0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4021861093455086,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4052497746769916,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4525657762512103,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4722608209758878,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4825576297175944,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.4992660222836707,3.2061045910158045E-10 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999362136060328,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999998088450543,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999681231415,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999998087532,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999503,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.499999999999993,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999962,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.514016645595965E-9,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-2.0028755253997275E-6,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-2.8852936869480865E-8,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-3.372427088236366E-4,-2417.351655745415 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-3.584292888717063E-9,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-4.7083723479064306E-8,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-4.960242677995212E-10,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-5.203810700192914E-9,-0.9999999999951809 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-5.711412142494705E-16,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-5.9073851451123764E-8,1.0000000016511956 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-6.365635544801011E-9,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-7.391630079877998E-10,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-8.398005134720968E-10,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-9.118140284890763E-9,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark54(-10.0103399097313,2.8448461960014555,40.532991897171655 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark54(10.065857781094756,-6.000019930940992E-7,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark54(10.0729802460487,-0.2943499386347854,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark54(10.126121771265588,-0.06581728634403244,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark54(10.16858153133629,-0.5138100440370001,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark54(10.180964501672008,-0.18710623939280424,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark54(10.190577491490956,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark54(10.20187037773674,-2.2156898595344064E-4,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark54(10.211201915366075,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark54(10.261198961538895,-0.6680014893094111,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark54(-102.82655934447254,-0.2215216662030257,-84.25640826944738 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark54(10.420690991245493,-0.38881370823595934,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark54(10.454761424620472,-0.977197684512439,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark54(1.046437508708138,-0.9384423343417375,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark54(10.466330396160672,-0.43932329765203476,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark54(10.523596520306853,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark54(10.540424715022652,-0.32950802224347187,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark54(10.554597046664952,-1.1684215377397922,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark54(10.561524073671563,-1.1703654636126868,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark54(10.576053996772615,-1.454901426284522,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark54(10.583495100471623,-1.3108293319452287,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark54(10.623074821169856,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark54(10.644045681717884,-0.17534607362308052,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark54(10.650797390118372,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark54(10.655210371371318,-1.4838100290835028,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark54(10.660824335942724,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark54(10.664583987859508,-0.9443516453112535,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark54(10.700411944993931,-1.316633817372689,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark54(1.0815043200651298,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark54(1.0846821710615302,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark54(10.897472700721599,-0.4944417076749481,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark54(10.905470773538454,-1.1650267918341228,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark54(1.0906753164154708,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark54(10.992850049158378,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark54(11.022438166264223,-0.21565578524572807,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark54(1.1102230246251565E-16,-0.1302308516442423,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark54(-1.1102230246251565E-16,-0.20109812698639473,0.9999999999999999 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark54(-1.1102230246251565E-16,-0.5406477952008836,-89.36455949922167 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark54(1.1102230246251565E-16,-8.881784197001252E-16,0.09500549892941279 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark54(11.106210491794961,-0.20159295424502433,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark54(11.11046407944194,-1.0431218207299775,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark54(11.15600278663878,-0.05531870823021576,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark54(11.17084240261319,-1.0185182068367418,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark54(11.173379608893569,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark54(11.214736786121463,-0.9558941484287828,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark54(11.227751001202762,-0.001316966624095565,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark54(11.247432214890239,-1.4501353494415588,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark54(11.262159758948613,-0.5338275932382808,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark54(-11.262646431116721,-8.881784197001252E-16,-40.87258836652317 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark54(11.297855312796898,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark54(11.365268967546243,-1.1378157850362953,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark54(11.377598799322826,-0.08022466952699042,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark54(11.404667828741793,-0.5054487986138962,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark54(11.457118551649463,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark54(11.458488619190407,-1.4999999805705564,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark54(11.53143521421454,-0.9779923124040235,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark54(11.541775951462283,-4.4210732641563314E-10,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark54(1.1562445258819025,-1.1064266729633265,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark54(11.58072068568508,-1.3196874871855735,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark54(11.582600922362246,-0.09020207102776945,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark54(11.602406890567025,-0.17695144283723607,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark54(11.658467749091637,-1.1941926716200584,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark54(11.684873812989935,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark54(1.1859415740641737,-1.0247834878964492,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark54(11.907862487744888,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark54(11.957191746974488,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark54(1.1961648935622264,23.788812418359882,84.53621686457765 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark54(-11.969564793322146,-0.0027868357555550227,91.41612375302284 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark54(-12.018729194366754,-3.552713678800501E-15,-1.3832261657045163E-222 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark54(12.050246725296645,-0.07901485683788412,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark54(12.140798317630455,-0.03994360664180574,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark54(12.163438674654294,-0.39282506114430116,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark54(1.2171185977742098,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark54(12.206532073825244,-0.36754798955697154,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark54(12.23640389517055,-0.9620367286252542,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark54(1.2282202542611884,-0.38707309875343077,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark54(12.29175860860921,-1.0878618306378312,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark54(12.318100576708972,-1.011566972074462,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark54(12.338379501551657,-2.831645026480107E-5,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark54(12.411616670636779,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark54(12.414593244527572,-1.91094453877122E-6,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark54(12.427033804053577,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark54(12.44426144833966,-1.0961507047257122,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark54(12.452994829932956,-0.8748846672151247,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark54(12.48868166412585,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark54(12.501825195760286,-0.22686200704263015,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark54(1.2526647176904788,-1.0725148953254688,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark54(12.53610333506727,-0.29530355563866695,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark54(12.537777985405626,-0.13703684267995708,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark54(12.565887452313035,-0.7245244847029593,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark54(1.262383408719615,-1.4877297115107693,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark54(12.655220364435209,-1.1707235691174533,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark54(12.66553919213959,-1.499999999999993,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark54(12.673402848343326,-0.42543996078372004,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark54(12.707512603866817,-0.35932877655970685,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark54(12.761178160717648,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark54(12.78780850771733,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark54(12.790144084875656,-1.268678517259164,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark54(12.812081751850158,-0.5037782308852741,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark54(12.891721651107389,-0.06439601792214678,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark54(13.014983775459957,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark54(13.032172534859766,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark54(13.08299344177297,-0.746908954360979,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark54(13.182104520514697,-4.180052424912267E-10,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark54(-13.208114364979604,-0.7059086995378807,-1.0147226886812067E-9 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark54(13.2094196944212,-0.6051022742707326,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark54(13.225374626642534,-0.13312588318312635,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark54(13.260599308360263,-0.9438602854606883,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark54(13.267039682657307,-2.153247311456761E-9,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark54(13.300547873252228,-0.936182207732486,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark54(13.353083884181132,-1.350587137688919,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark54(13.358292834677329,-0.14944833682517356,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark54(1.336483499400103,-0.9061422114101845,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark54(1.3383089838068367,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark54(1.3416406099719866,-0.16176803306628607,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark54(13.491935745907973,-0.4333588160900823,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark54(13.506514508327607,-1.0061855611795725,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark54(13.511447380156113,-1.4749660511655494,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark54(13.517267392635787,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark54(13.52918509496574,-1.0494813976347412,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark54(13.539428800385195,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark54(-13.539595179459758,-2.220446049250313E-16,-1.0000000000000062 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark54(13.551435563131804,-0.41563188673327955,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark54(13.589935015001714,-0.42408134274827347,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark54(1.3698808431302519E-194,-1.2009821718679545,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark54(13.783740864565546,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark54(13.824669184045078,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark54(-1.3877787807814457E-17,-0.8932327702067999,-0.857855946806688 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark54(13.887408036445166,-1.3795030944790416,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark54(14.0216628629301,-1.499585464837246,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark54(14.022333142611421,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark54(14.028815177036458,-0.9431477714914233,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark54(14.102114328568206,-0.7830550204893001,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark54(14.143777081130878,-1.4586828730772234,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark54(14.144469544380712,-0.2106165587506924,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark54(14.154444360218921,-1.4999896352042323,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark54(14.155444770760226,-0.09041370142862748,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark54(1.4181685706445393,-1.4709442849076022,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark54(14.18361488861996,-0.09488610247131608,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark54(14.20843096857434,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark54(-14.257913749255714,-0.3437956627974739,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark54(14.295434756618224,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark54(14.313596938706059,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark54(14.430383446123415,-0.03498349830814451,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark54(14.439471631420012,-0.36861075304073987,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark54(14.491450182096173,-0.49468436557283546,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark54(14.52780753243772,-0.40186604464200304,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark54(14.570931736532415,-0.27737213697355756,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark54(14.582575168683292,-1.2849503912456584,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark54(-14.603746607205622,-1.391201240947309,1.0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark54(-146.264132407536,-0.8922839789910653,-0.14990310006360552 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark54(1.462713956460604,-0.19813892920936205,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark54(14.633133431674935,-0.45799833442575066,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark54(1.4639503547354735,-0.11939584745259424,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark54(14.687716889778144,-1.2001360226356894,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark54(-14.700577515516827,-1.4999965147620047,-1.0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark54(14.73767532240618,-1.057570784030911,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark54(14.7907884048891,-1.10797817955852,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark54(14.86639519559428,-5.2760396555891575E-8,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark54(-14.872849541788824,-1.499999999910496,100.0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark54(14.876591310989241,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark54(14.900786721995772,-0.7493499524622678,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark54(15.009943999062287,-0.036904957901228386,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark54(15.01230354636187,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark54(15.012630925168907,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark54(15.033169151337024,-0.778619065676501,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark54(15.033871002164638,-0.22031442688134284,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark54(15.05630597524857,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark54(15.158277425913667,-0.093559946017308,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark54(15.179625637756544,-0.14143002300735574,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark54(15.185381964911173,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark54(15.240345086783563,-0.37517350494717405,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark54(15.250628645538626,-0.04764645933315707,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark54(15.286053596975307,-0.09259505658412648,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark54(1.539201949253652,-1.4999999999993783,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark54(1.5473371378139262,-0.9666893082150652,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark54(-15.506909801074855,-0.4873070992613866,80.05238589528528 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark54(15.510084333721252,-0.0690085231674292,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark54(-15.512164374191343,-0.8251478178825117,-1.0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark54(15.516381891396563,-0.13843844435092478,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark54(15.517483558009527,-2.4524312562850404E-8,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark54(15.586550150955887,-0.8640127434847784,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark54(15.58816632332038,-0.1637960505321442,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark54(15.692970232482665,-0.12392238188497373,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark54(15.69513128615165,-0.35472335211865413,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark54(15.704664781001547,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark54(15.770380535354192,-1.4221199549252264,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark54(1.5837625240914974,-0.4262586251138377,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark54(15.844064474491072,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark54(15.869350299679084,-1.4620895370244213,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark54(15.958001648382991,-0.15815469912831553,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark54(16.001991054729572,-0.6478787870238136,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark54(1.603213513128381,-0.9518490116972297,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark54(1.6036818745857886,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark54(16.04406309958881,-0.7201731752188172,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark54(16.050363591622556,-0.951522611604628,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark54(16.075995709473318,-0.7033408530823433,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark54(-16.086862662410994,-0.9400580439545412,0.8732949098084823 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark54(16.10915552613986,-1.389525147137609,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark54(16.150243233088602,-1.0230028255806176,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark54(16.17406637424159,-1.2076593587705844,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark54(16.195943378661752,-0.6294350477069776,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark54(16.198255469343813,-4.240761085896902E-5,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark54(1.625342633824725,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark54(16.301969986606693,-0.37113277941445144,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark54(1.6369592740220869,-0.13728722871301802,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark54(16.407387814087144,-1.0565155933125596,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark54(16.424794924406598,-0.26555640046935025,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark54(16.432281311116597,-0.4028545651244997,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark54(16.47626227048616,-0.046537732458366676,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark54(16.47716940986916,-1.0173675956886465,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark54(-16.48729516157207,-0.44573539111110605,-47.53211698811006 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark54(16.50884877182574,-0.9123080979545506,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark54(16.539351331653933,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark54(16.553422424433023,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark54(1.6555331711272991,-0.9035515352839809,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark54(1.65621498883786,-1.3228814355988163,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark54(16.56627385843791,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark54(16.574276837402962,-0.47647345619733883,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark54(1.6628802536974518,-0.9054630838514889,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark54(16.697240329161318,-1.3071540404229445,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark54(16.72382926394951,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark54(1.6794375956568415,-0.11688934266680362,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark54(-16.796063555877367,-0.7061243309161727,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark54(16.79616886987469,-0.685978232036797,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark54(16.797453032350226,-0.32371082012544833,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark54(16.827601013183404,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark54(16.87661347795627,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark54(16.908098913840305,-9.200845831907448E-4,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark54(16.917087859427753,-0.36111106362150824,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark54(17.012115869635757,-0.7577714484822624,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark54(17.05853714529269,-0.7370588462734656,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark54(17.08716833599978,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark54(17.09993616875725,-1.1423817503181861,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark54(17.117596360841517,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark54(-17.14380285549232,-0.7774535371481214,8.470329472543003E-22 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark54(17.15297112724815,-0.7629560966152198,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark54(17.158575031063464,-1.1199649379943661,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark54(17.201280228956463,-0.4994950418520405,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark54(17.20638068855993,-1.2598484917185502,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark54(1.7235202093733997,-1.20185740520064,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark54(17.244208622337027,-1.4999999220069422,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark54(17.244288033179387,-0.5583832242777542,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark54(17.345734773835837,-0.8366699952765373,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark54(17.36099496048247,-0.2505320138737659,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark54(17.41406571542811,-0.06312449000541084,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark54(17.432377763748647,-0.5414894540952622,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark54(17.476329610096727,-2.8236600747289916E-7,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark54(17.477224994519204,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark54(17.58260838045365,-0.3019895965546522,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark54(17.645005897712565,-1.4447265077736642,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark54(17.734975403076135,-0.2288450376736786,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark54(1.7763568394002505E-15,-1.0181152834892941,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark54(1.7763568394002505E-15,-1.1087509154553175,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark54(1.7763568394002505E-15,-1.1392344068686384,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark54(1.7763568394002505E-15,-2.220446049250313E-16,0.5544611370227805 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark54(17.78418666177106,-0.1638938053968353,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark54(17.82055378563281,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark54(17.828387400680953,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark54(17.829463300745704,-1.2186416549155249E-9,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark54(17.86655818053949,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark54(17.90183378055623,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark54(17.926343839628775,-0.0024200290915104006,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark54(17.96930886608257,-1.4999999065458494,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark54(17.970195155263553,-0.30936489309516446,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark54(1.7974113605642117,-0.18049934109581578,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark54(18.00478401612902,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark54(18.026502845068244,-0.33831110529660346,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark54(18.040063414592414,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark54(1.8057477562814768,-0.12326116416062405,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark54(18.063635263593298,-1.434821277587278,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark54(1.8100311460770007,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark54(1.8104983096525586,-1.0085916461417552,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark54(1.8134715400433947,-0.9201169211284874,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark54(18.157228682246245,-1.7120816569822283E-7,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark54(18.186991940150932,-3.731787095679562E-9,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark54(18.200986115178324,-0.6587689630407176,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark54(18.208379810093312,-0.13242200225155282,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark54(18.3024679883373,-0.1742788233172976,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark54(18.32091365684581,-1.243924722835139,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark54(18.36027580513427,-0.31979388562068234,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark54(18.39258773828145,-0.3900732980039222,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark54(18.509203401036785,-0.08032966291702337,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark54(18.56672132778645,-1.49999999469307,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark54(-18.595379719476448,-1.4999999999999996,0.9238320538410607 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark54(18.601157146846802,-0.016332054541706498,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark54(-1.863361755668775,-0.4123337411372434,1.0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark54(18.667813922313584,-1.152150630108892,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark54(18.73106359292089,-0.15740092377183146,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark54(18.75376694257535,-1.4999999999493996,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark54(18.82601804536351,-2.6040085758095508E-8,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark54(18.840630286120454,-0.3133154551823988,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark54(1.88709288404912,-2.397777424707095E-6,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark54(18.891993627344263,-0.9342675160953497,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark54(18.949004044588264,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark54(-18.979992130206558,-0.6336005942932077,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark54(19.01898615696009,-2.8174150402454632E-8,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark54(19.066936088137695,-0.03652996200319163,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark54(1.90879105903295,-0.7345976879557139,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark54(19.10855636634298,-0.9125847500467552,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark54(-19.161701358142096,2.1726143025870357,48.05377731678021 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark54(19.189319778374497,-0.9419288580465466,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark54(-19.19813988092102,-1.1124700963328127,1.7293973762147659E-15 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark54(19.207532179126588,-0.9078248394879145,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark54(19.24495979876051,-0.03417204741813029,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark54(19.253039880120554,-1.4604939714252652,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark54(19.292092647585484,-0.33388017345145604,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark54(19.294490654199706,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark54(19.35467951016159,-1.4236936298473468,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark54(19.365361958616194,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark54(19.444985617564086,-1.1274592537279062,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark54(19.462129974039726,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark54(19.478424572189425,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark54(19.556203893350165,-0.017976787831935945,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark54(19.561620972958664,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark54(-19.562380420367383,-0.23995146262033507,0.22202556009421137 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark54(1.9581592491309436,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark54(19.620727917740894,21.758190165464626,69.04318953373698 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark54(19.69437102956644,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark54(19.853424870405,-0.5941991185501259,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark54(19.86516834366728,-1.0567629285238809,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark54(19.904146123745406,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark54(19.92081782335129,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark54(19.94456945790641,-1.2932389178960904,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark54(19.965223375475105,-0.8383563904614304,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark54(20.010692466708417,-1.4563970888175035,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark54(20.05787408027406,-0.9586023979488516,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark54(-2.0090424840382575,-0.4090704360287156,-0.6517208648716084 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark54(20.09555235508813,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark54(20.09700179700782,-1.0847173578066531,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark54(20.14445474296862,-0.504189344988425,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark54(20.154496635787588,-2.12111564436936E-9,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark54(20.17097428098711,-0.04909912316101379,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark54(20.17251730558881,-0.7609627083507604,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark54(20.187380580493517,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark54(20.19526231423059,-0.5444396722437741,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark54(20.206158445736907,-1.1635626269447745,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark54(2.0253283241726923,-0.31350620626309866,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark54(20.26800984294215,-0.12262774711911106,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark54(20.399099275698063,-0.06728864231537846,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark54(20.403353058438142,-1.299963692469806,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark54(20.438098244812082,-0.3496142292578416,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark54(20.44064015249161,-0.6697878015622585,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark54(20.457503197980785,-0.8319549686902312,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark54(20.489585108586226,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark54(20.500204945602192,-0.019747151102548877,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark54(20.564018393178195,-1.2192900597474243,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark54(20.609155092826995,-0.9662343784057326,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark54(20.631215092895033,-0.6587898626501256,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark54(20.632006628896264,-0.3678717768454325,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark54(20.64457719701405,-5.236471730524229E-9,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark54(2.066493058316965,-0.2217826546317317,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark54(20.913387312275518,-0.6184042976953574,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark54(20.927417360475495,-0.6312797111465507,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark54(20.927666079444126,-0.21492345580135785,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark54(20.930667472137646,-1.4953196962800064,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark54(2.0941404583830128,-0.14793135103060928,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark54(20.999779408878098,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark54(21.002698721927544,-1.2692676555574778,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark54(21.026086419093158,-1.3070195446698496,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark54(21.041667977101316,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark54(21.07186169886198,-1.4999999999999094,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark54(21.074628274426615,-1.499999999999993,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark54(21.084436890341067,-1.1933478129128048,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark54(21.10439480808028,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark54(21.221476822043513,-0.7920341482248723,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark54(21.231907971767956,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark54(21.348328227921215,-1.4999999999989484,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark54(21.46995380990458,-1.1939511388706023,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark54(21.537200364109225,-0.35290323623945175,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark54(21.54515665789154,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark54(21.610466771829053,-0.24453725520370329,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark54(21.625299434052252,-1.1863434181780987,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark54(21.631409737604937,-0.02861154183975656,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark54(21.637580046799343,-0.0999800552629253,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark54(-2.166299184664105,-0.10607967943801729,3.8532391494977247 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark54(21.671345189528164,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark54(21.680937340002174,-6.852175755600031E-7,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark54(21.762048637034045,-0.7704123118362856,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark54(21.763376554676242,-1.3393678355296714,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark54(2.1831630842153227,-1.3736016021917008,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark54(21.854836290647413,-0.5319169943100808,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark54(21.910320525282927,-0.7279454662784417,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark54(21.917692337781716,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark54(21.99987847952169,-0.0015963880929880155,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark54(22.025936107598753,-0.956123432370136,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark54(22.068764708427324,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark54(22.07606225590024,-0.9006384934928793,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark54(2.2140907835902084,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark54(22.1477266875944,-0.456223099630904,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark54(2.220446049250313E-16,-0.15853717453883576,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark54(22.209184851919474,-0.8941922539966534,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark54(22.26321175780677,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark54(22.296965281161405,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark54(2.2299215110688344,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark54(22.312773693714227,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark54(22.33633792643396,-0.377876880475176,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark54(2.2338697556829175,-1.0347199417588394E-9,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark54(2.235135838962691,-1.2636647927272833,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark54(22.369590319012886,-1.0470439046209261,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark54(22.380139214614225,-0.24171568396133902,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark54(22.419996455508297,-0.24211083757004914,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark54(22.436759551693196,-1.1182448406936142E-9,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark54(22.441534531888546,-0.014585465644966907,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark54(22.47103556812388,-0.5949753548907266,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark54(22.523194298858414,-0.7548432366002111,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark54(22.54024045883645,-1.29590507748172,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark54(22.61237719968723,-0.5047563724669035,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark54(22.61487267350237,-0.3525496950841073,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark54(2.2625651319689126,-1.3928906146386852,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark54(22.65460415021921,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark54(22.681082296485513,-1.028910010668966,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark54(22.704886572423618,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark54(22.72005512400486,-0.8215298560662347,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark54(22.727165020410958,-1.3897011146390439,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark54(22.836790184946445,-0.2883517262184607,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark54(22.865816357169603,-0.4575948084356618,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark54(22.870647947162404,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark54(22.9238801694315,-1.1128359696596692,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark54(22.97672729508406,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark54(22.989593976746175,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark54(23.03882778350001,-0.5235090022738902,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark54(23.042199190286034,-1.9726816697938336E-9,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark54(23.04449651098075,-1.2827553320783958,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark54(23.178070977813817,-0.3716123123625916,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark54(23.180998234839155,-0.30158335625313376,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark54(23.220895674067858,-0.0819163153388652,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark54(23.23124721899245,-0.3921599196492136,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark54(23.25250940493581,-1.3653581220524145,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark54(23.268522541319495,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark54(23.271192227003404,-0.17709050088100753,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark54(23.328952107150684,-0.06173729315499088,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark54(23.343426498761257,-4.118834081716327E-16,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark54(23.366588783354473,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark54(23.37153392264958,-1.2737588792235213,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark54(23.377116230557803,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark54(23.532799439387666,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark54(23.549835485023827,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark54(23.69926301274552,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark54(23.700293819824385,-0.7977526915812988,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark54(23.711855111830033,-0.08960849920991354,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark54(23.712343746420174,-1.3474839334582764,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark54(23.757982914618655,-0.4874027587252605,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark54(2.383883563020035,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark54(23.844537758706064,-0.4075751935339325,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark54(23.989331220614886,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark54(-24.06419280289805,-1.0496061910309287,2443.5192259215837 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark54(-24.080436492698027,-0.8194458920370109,44.72776032174761 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark54(24.117892958200834,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark54(24.1595688176269,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark54(24.202332902022093,-1.0432209984130765,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark54(24.26709565869413,-0.06581427644476179,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark54(24.30702595872738,-1.1023917954329185,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark54(24.322943141866347,-1.0248504158164367,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark54(-24.36280635965163,-1.2279648381513226,-0.362112970966548 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark54(24.370211805985235,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark54(24.37433973151468,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark54(24.399166395016042,-9.010844885245796E-10,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark54(24.4611681257903,-1.1192231324819835,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark54(24.465644399563917,-0.7355747047542707,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark54(2.4531920961210254,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark54(24.54850992459052,-0.9437178155561305,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark54(24.554583441904214,-1.0795896495072697,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark54(24.55463675681168,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark54(24.55653802608964,-0.646235646363678,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark54(24.579213909114994,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark54(24.661486816809415,-0.5731775831830248,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark54(24.712828429576206,-0.027095485051491508,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark54(24.740006541081556,-0.9942096276058034,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark54(24.78982091960637,-0.806238111571611,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark54(24.838395557600165,-0.7881852835379082,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark54(24.853531089215153,-1.4495646068385497,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark54(24.879882853126006,-1.1750498521657922,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark54(24.88726137543709,-0.09929480557602943,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark54(-24.891083556291036,-1.2022522560661062,-92.66411670573633 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark54(2.491314393545191,-1.4999668111267803,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark54(24.92504716283348,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark54(2.497414599425251,-1.4999999999641165,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark54(24.998980821960927,-0.026598178632811997,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark54(2.5001880919817445E-15,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark54(25.044842300215308,-0.30226713810578687,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark54(25.052757620625716,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark54(25.087796354186565,-0.46305868611590384,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark54(-25.094833300114686,-1.0195024661196546,0.0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark54(25.096399728554957,-1.4999999999999591,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark54(25.164882724883068,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark54(25.27414200608365,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark54(25.279451884903125,-0.8437857940265729,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark54(25.289006322505777,-1.000773716118223,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark54(25.32278138699904,-0.9941574522109454,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark54(25.324668671262508,-1.8205180370667698E-9,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark54(25.37747637174428,-1.4579431627461261,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark54(25.378066836328486,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark54(-2.547842198497579E-16,-1.4999999998898388,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark54(25.57801697653204,-1.146317113620185,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark54(25.624802433016896,-1.1378133099347592,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark54(25.63345466568599,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark54(25.69039505745326,-0.5521887863949901,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark54(25.690999083626238,-0.5046941748409859,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark54(25.72476274676474,-0.39135707317959323,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark54(25.768104876716887,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark54(25.77488781284015,-1.4999999999999902,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark54(25.812937178068182,-0.8479099392411769,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark54(25.83250455404941,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark54(25.834615688931557,-1.9015351667042878E-4,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark54(-2.5849394142282115E-26,-1.0505213780972735,-1.0000000001751428 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark54(25.851262541565735,-1.1974627498705397E-5,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark54(25.890651681893416,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark54(25.89944542458007,-1.389798424210154,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark54(25.978079211488307,-0.31865240873859363,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark54(25.99181203106744,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark54(26.00663034288972,-1.480191602437882,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark54(26.037322047401062,-1.2883825684855328,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark54(26.044873317939903,-0.3394387474153566,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark54(26.065489405478075,-0.937250650546547,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark54(26.126758842116132,-0.0612515128325658,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark54(26.132908034645585,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark54(26.1735750307068,-0.22897861351817905,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark54(26.18562383382968,-0.5019447650346933,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark54(26.250573936434904,-1.4936805878004622,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark54(2.6269035528309608E-287,-0.5563510114572097,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark54(26.272732240244807,-1.2223311003310924,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark54(26.283034505711882,-1.2703884409468373,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark54(26.303108145006387,-1.3327992208803723,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark54(26.305559993320443,-1.161717804596858,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark54(26.349983628961127,-0.49913427332327637,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark54(-26.35915490063531,-1.4999999387608334,-100.0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark54(26.409920184833112,-0.603292295591003,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark54(26.43501029937427,-1.367259826722318,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark54(-26.48763877413755,-1.321049475180525,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark54(-26.522755655246854,-1.4814628573319724,-0.3517352501432893 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark54(-26.563105204136733,-1.7763568394002505E-15,34.47069236847429 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark54(26.629322238208957,-4.1196957407868504E-8,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark54(26.743680873780846,-1.0304603223243163,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark54(26.77263687053056,-4.132583270018208E-6,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark54(26.803571845866898,-0.07228297882952639,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark54(26.823548552861414,-1.4999999996099167,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark54(26.83459699517421,-0.2392892771568441,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark54(26.893752343855027,-2.278642260534641E-9,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark54(26.966367908704342,-1.3003002964198807,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark54(26.97212388907066,-0.2235972408246588,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark54(26.97826094644344,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark54(-26.986552684442383,-7.479992426710942E-10,-8.527109935602867 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark54(27.00844239577617,-1.499999999999992,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark54(27.048331798646316,-0.6100455236629032,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark54(2.706305338891667,-0.015114006518240686,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark54(27.097760256440697,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark54(27.09825406709085,-0.40313894452696,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark54(2.7113227597500185,-1.457593334724307,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark54(27.147455669418093,-0.47998657005925416,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark54(27.208816410442864,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark54(27.21121066968972,-0.4486205631305893,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark54(27.230039993270097,-1.49649073293398,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark54(27.252532697620026,-1.253359072586022,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark54(27.25856880910665,-1.2514872219142898,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark54(27.273298810400746,-0.0074017943419057985,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark54(27.296316532857876,-1.209326169427138,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark54(27.31329515680312,-1.073161782335772,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark54(27.380814558414897,-0.17266114664832521,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark54(-27.472722029293564,-1.2848178628486673,0.762191048691945 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark54(-27.587091167661157,-0.062001134780244826,-69.9238573516443 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark54(27.67969888712379,-0.06710165616867414,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark54(27.699698321381433,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark54(27.70791859084511,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark54(27.72230202346124,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark54(2.7755575615628914E-17,-0.9397220695434425,80.15978233670862 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark54(2.7755575615628914E-17,-1.266192386394142,-1.0000000000000009 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark54(27.797844750493738,-0.9208985858844552,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark54(27.823770409825016,-0.5099886600661142,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark54(27.828055781510443,-1.168412031690127,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark54(27.915645652851055,-0.01754284930670913,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark54(27.947224214552065,-0.8760639941083288,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark54(27.98349247359728,-1.4822745665782886,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark54(28.02202408726015,-0.882134192887122,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark54(28.030911645658932,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark54(28.06413526201223,-1.379710897665558,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark54(28.073576552313142,-0.31546485846700634,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark54(28.144180179413215,-3.664414470286786E-7,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark54(28.184573008837287,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark54(28.21184787142019,-1.333885709984885E-4,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark54(28.25061121429397,-1.3677517521134845,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark54(28.277843714965798,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark54(28.37086102441114,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark54(28.37755165376041,-1.3954653446317962,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark54(28.37904250174296,-0.878954977529089,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark54(28.423695560047463,-0.11325449759252981,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark54(28.426120910389983,-0.024313487994049865,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark54(2.8437600619295162,-4.2441970213566355E-8,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark54(2.8444166475115367,-0.7699687898678467,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark54(28.45354656700536,-1.265226419111226,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark54(28.511352764016905,-7.212581784339594E-10,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark54(28.528117269580438,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark54(28.55291632431787,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark54(28.563988506718623,-1.075810255800584,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark54(28.596489437557295,-1.4886469123455228,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark54(28.60176207258675,-0.7482080707857932,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark54(28.696835907522075,-0.7546003390432552,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark54(-28.824191206457602,-0.4093983494513507,1.0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark54(28.856392860448057,-0.1147434897377162,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark54(28.870283696152114,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark54(28.885250778673715,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark54(28.893647279221113,-0.8754563242685158,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark54(28.916639774426372,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark54(28.932251398252163,-0.879588365988468,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark54(-29.027387637529493,-1.3941312787914655,0.8943790315691081 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark54(29.08190651032001,-0.28878196345591667,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark54(29.12376183825687,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark54(29.159182068193548,-3.441345312987008E-8,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark54(29.166258892283423,-0.8597595746953319,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark54(29.26682207522873,-0.7063502679734714,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark54(29.295689641497244,-0.8422407124208735,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark54(29.312095592261993,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark54(29.446607511076394,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark54(29.449980198087786,-0.985235043925826,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark54(29.479757442754874,-3.822787971053181E-8,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark54(29.508245263359374,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark54(29.562869106128858,-1.0778022124110234,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark54(29.574768539990398,-6.549264383942789E-10,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark54(29.672503060364306,66.62036904602698,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark54(2.968616363999267,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark54(29.6975215701315,-0.08956078601955264,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark54(29.70829574773556,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark54(29.717694275222318,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark54(29.72044933188016,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark54(29.724443530588616,-0.7913446792031338,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark54(29.73666467991518,-1.7600662195796106E-15,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark54(29.74086853114696,-1.3241926359393066,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark54(29.74175530365224,-0.8600712473723462,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark54(29.747536412839295,-1.5625569958513908E-6,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark54(29.786190258511752,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark54(29.81334644869254,-6.775695538773652E-10,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark54(29.850374629433105,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark54(2.9851524641962897,-0.37474851338140835,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark54(29.893264562428413,-0.9337441375165125,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark54(2.9943392221562988,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark54(29.977400680763488,-1.0367080279434484,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark54(29.98529063093667,-0.5236711255527275,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark54(30.00479694132971,-0.3153847063861268,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark54(30.056166281031278,-0.5496025181577373,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark54(30.07909006904788,-0.4664934671588523,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark54(30.125225975233853,-1.4831867399772323,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark54(3.0139134920487187,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark54(-30.172760061150196,-1.3512352666246978,-0.21822946491160788 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark54(3.0188757059886813,-1.3127084616761582,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark54(30.19553905223512,-1.232417044704576,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark54(30.297563885261134,-4.070684603378846E-9,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark54(30.299776007997707,-1.1644538042497712,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark54(30.30117503923404,-0.9584217494571217,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark54(30.400533464211367,-1.499999976423973,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark54(30.401292513811484,-1.0806113349890296,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark54(30.4301625479115,-0.8797912399488068,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark54(30.47586060008073,-0.08539011837442834,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark54(30.47789144964176,-0.5216929980242497,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark54(30.50866462483549,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark54(30.543609753448237,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark54(30.55804707114627,-8.856311608112381E-4,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark54(3.0579599569697393,-1.1159798405398609,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark54(30.644384779427114,-1.358215166940485,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark54(30.660354192328185,-0.6060827739141943,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark54(30.664957487139,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark54(30.719834778382904,-0.3706202460042815,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark54(30.777310631347724,-0.4021603929601983,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark54(30.79284648670317,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark54(30.823676829753357,-1.3182599441434402,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark54(30.82553043543325,-0.3718466755106591,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark54(-30.860985101713155,-1.499999999999993,1.0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark54(30.904420786320514,-0.7444720923097508,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark54(30.910910876627103,-0.9079700797185106,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark54(30.993775396630213,-0.41049519032490167,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark54(31.01265416018657,-0.7448438986404362,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark54(31.0137943439546,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark54(31.022264501380533,-1.4624092546437986,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark54(31.049256657771302,-0.42212048352320597,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark54(31.13577739155022,-0.5286128391189391,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark54(-31.136932238693454,-1.4708347357712936,1.0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark54(31.179333634130245,-1.0732171259009653,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark54(31.243128624882445,-4.673690590035278E-10,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark54(3.12543126466916,-0.16057520539562609,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark54(31.295662659632256,-0.3630179222090568,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark54(3.1309608796390123,-1.0143910640393994,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark54(31.39809977493789,-0.9636199472455576,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark54(31.40203579505055,-0.03581014145775668,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark54(31.411777698309862,-0.29568996494490185,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark54(31.46628210917399,-0.13266059941381456,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark54(31.4941889142942,-0.012252341101734565,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark54(31.511236965918897,-0.28550478224372,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark54(31.542260482614328,-1.4869463848772648,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark54(31.557602170287495,-1.0403438983057294,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark54(31.568612182393295,-0.13200296060134345,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark54(3.159048173643132,-3.5921914756217063E-9,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark54(31.61186633212081,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark54(31.619318222841493,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark54(3.162985731489412,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark54(31.641262767227573,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark54(31.70163036887665,-1.4999999999577358,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark54(31.706041404092275,-0.19964830381262555,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark54(-31.717536630626512,-1.159893261062844,-3.446274307835722 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark54(31.73573713853423,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark54(31.762496852188463,-0.7469105219179943,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark54(31.811625994199392,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark54(31.847893734168785,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark54(31.87443053003821,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark54(31.933191067171748,-1.4470692122617805,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark54(-31.934233369502877,-49.52103445197504,82.27619354547272 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark54(31.94047197242034,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark54(31.970247502315175,-0.1967932430976873,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark54(31.977882130938195,-7.725867657966502E-7,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark54(32.00286198244504,-1.2228894461472706,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark54(32.07731448698931,-0.04614566327920855,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark54(32.084685642740794,-1.4701969863948352,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark54(32.12506179350774,-0.09613803652928521,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark54(32.2013483401459,-0.8374680458933663,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark54(32.26038811761325,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark54(32.324653362979326,-0.02753294787040539,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark54(32.33144253111334,-1.0016820338225112,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark54(32.35208537660829,-1.4017665501838117,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark54(32.436695857005105,-0.617202585107278,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark54(32.47189721071791,-0.6353981298751039,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark54(32.493242742739056,-0.375416647428505,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark54(32.49900512452908,-1.3556510270670543,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark54(32.50429576050945,-0.7026815959254407,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark54(3.257684146189675,-1.1070595805252461,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark54(32.603755164079615,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark54(3.2629751489770342,-0.20880158002074722,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark54(32.644364423728646,-0.9635172211203042,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark54(32.67357100315945,-1.2363586733720666,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark54(32.69103658985031,-0.9527153286241613,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark54(32.697646452217185,-1.3304636126355973,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark54(3.2756834280121723,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark54(32.75865214079076,-0.11600962348623406,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark54(32.808365158471226,-0.6751608783217414,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark54(32.82691531508135,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark54(32.83667406107526,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark54(32.843698587992314,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark54(32.84705223126224,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark54(32.88390784075642,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark54(32.888687674588255,-1.4367671851940287,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark54(32.89554358337069,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark54(3.293179857850518,-1.41275862199174,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark54(32.937657959348456,-1.0263698919441766,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark54(32.941576047297076,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark54(33.0450600566906,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark54(3.309071463640734,-1.0129600058388006,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark54(33.10001476239179,-0.5170893298200108,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark54(33.11372910694911,-0.5346009167353998,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark54(33.16700921633473,-0.9584786046913507,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark54(33.21564678514949,-0.10499535587511066,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark54(33.25767253626084,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark54(33.28016473332351,-0.26099713274984326,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark54(33.32402555395046,-0.33104497899169827,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark54(33.335709375577224,-1.0122673322071492,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark54(33.35878899282678,-1.0408908429364379,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark54(33.37870878248887,-0.4339377787910337,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark54(33.40591276345301,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark54(33.423514595954806,-0.0011061690152067679,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark54(33.48853735660589,-0.5027134809696441,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark54(33.489364472690134,-0.20883468476352185,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark54(33.50533593796479,-0.8084758921962738,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark54(33.57997936954719,-5.87990497690297E-5,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark54(33.65168207323075,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark54(33.66616433237016,-0.7453895572272327,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark54(-33.69295115148313,-1.4999999999999996,1.2634920662350609E-175 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark54(33.70541850926273,-0.3913550833661894,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark54(3.3744685924991322,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark54(33.754368817953356,-1.3239325770148165E-9,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark54(33.78450408412908,-0.0035737623935716556,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark54(33.854142756816884,-0.9740978494423302,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark54(33.90899956986917,-1.4990032317699473,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark54(33.919689134158006,-0.18640649807217802,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark54(33.94395032246915,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark54(34.002953749646565,-1.3853065411682643,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark54(34.030004520841146,-0.22353393658198573,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark54(34.04830320935802,-1.127795645338016,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark54(-34.06474686096876,-1.499999127937255,0.9999999525588619 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark54(34.07701234692914,-1.4736521312684943,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark54(34.09295697081768,-0.3224659549859583,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark54(34.10332627570483,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark54(34.16526778414544,-1.3852849744595375,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark54(34.1790642969448,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark54(34.188760663884295,-0.04405473218309908,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark54(34.1995968237179,-1.3981701458871336,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark54(34.21487392714869,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark54(34.27230129394656,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark54(34.29290804924767,-0.21279940812661316,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark54(-34.29703267675217,-0.18777973322154473,-1.0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark54(-34.403587368975835,-0.2476176585732155,-1.0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark54(34.445143425202374,-7.21090834687349E-8,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark54(34.559748319407845,-1.079622994801242,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark54(34.57643721093885,-0.22435285870220056,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark54(3.4584151500676796,-1.025702208445864,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark54(34.58565054538951,-1.4999999994385789,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark54(34.5940841797969,-1.0185302238947318,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark54(34.638995644651885,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark54(34.663348140317495,-3.049676647322068E-8,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark54(34.68473891518852,-0.25396752133195744,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark54(34.75449390973201,-0.013423759032798799,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark54(34.8018964533552,-0.9798253463713991,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark54(3.4827631913362183,-0.5122864452970579,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark54(3.484969799212886,-1.4999999998098479,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark54(34.859093185421905,-0.7877306944382949,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark54(34.88350284794498,-0.3043359228408544,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark54(34.905135232244476,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark54(34.90604215624214,-0.21308076907026496,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark54(3.492269751818739,-1.4571392311721254,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark54(34.964688396235886,-1.1397020239158167,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark54(34.985048094167404,-0.5312531990215759,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark54(34.99127078382244,-0.9984306089437975,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark54(35.00452860477884,-0.36418724663244006,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark54(35.01969334262202,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark54(35.04223796682763,-1.4845922391538524,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark54(35.15699364335692,-0.8721137905439065,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark54(35.15953900716022,-0.7443344191926826,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark54(35.17238634600753,-0.12570495820702765,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark54(35.17449603622781,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark54(35.18264255606772,-0.6962602301045564,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark54(35.21061895517542,-0.9692140655555853,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark54(35.21084798893091,-7.53734243533339E-10,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark54(35.23242297406124,-0.8032338586664209,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark54(35.25671598968867,-1.0793861548814276,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark54(35.268262022432026,-0.9834626538838336,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark54(35.29342189328776,-0.14978745967319282,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark54(35.3125659381177,-0.2962462751538748,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark54(35.35009523712637,-0.22187941817077217,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark54(35.35937783695158,47.553474595390355,73.28736070401942 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark54(35.37614361429309,-0.13519725879347266,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark54(35.39490163269602,-0.17539680455539042,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark54(35.411584404245076,-1.3425406332380514,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark54(35.46720319482347,-1.1816600264379815,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark54(35.510592266195715,-0.1007438458084402,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark54(3.552713678800501E-15,-0.2388197070220741,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark54(3.552713678800501E-15,-0.9605674639503039,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark54(3.552713678800501E-15,-1.0468826349861393,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark54(3.552713678800501E-15,-1.2855123757688673,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark54(35.55765828384912,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark54(35.588489082604085,-0.6464182157503517,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark54(35.707299807624395,-0.9035392201918764,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark54(-35.711674182143355,-0.9783510353626355,53.36335829207954 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark54(35.772695169529754,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark54(35.79337228776629,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark54(35.8023079504039,-0.15487080778154422,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark54(35.84591244745923,-0.0786828361143539,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark54(35.91289326250563,-0.012053417853723047,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark54(36.04233230842448,-0.08576100030494904,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark54(36.04824142240966,-1.3615199299887033,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark54(36.07987162752008,-0.9023357969470756,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark54(36.10005413485135,-0.32136285651122876,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark54(-3.6144589956169733E-16,-0.137853553730857,-14.307063415630438 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark54(36.165900542569844,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark54(36.22060917354952,-0.21238314580511997,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark54(36.23116832989177,-0.5976256912019018,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark54(36.25111727126321,-1.2733403478329226,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark54(-36.35519385519017,-69.36758046364768,79.60162956660866 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark54(36.38640726551079,-1.4357804370116307,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark54(36.38831250656335,-0.7770564824843831,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark54(36.423541827980166,-0.3887157407896611,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark54(36.428393879646194,-0.07764508518217728,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark54(36.43785707581557,-0.8829703423397903,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark54(36.46905995958039,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark54(-36.50545934517822,-0.16682723544564426,1.0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark54(36.517047889098876,-0.30815871491758484,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark54(36.58636477170083,-1.104901606989141,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark54(36.62490204534886,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark54(36.63741413081439,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark54(-36.66624081487966,-0.2617817877529518,-1.0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark54(36.69682702881542,-1.4949887495642653,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark54(36.73337196398491,-1.3670436891981244,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark54(-36.736418749662604,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark54(36.74066109098844,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark54(36.8245918987308,-0.10648085735902715,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark54(36.87683734073822,-0.6130229757425919,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark54(36.88216883578987,-1.2253447186195725,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark54(36.88407556038474,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark54(37.052405513613365,-0.4560833409505296,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark54(37.066917072461166,-1.3890027591613987,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark54(3.7075450555089993,-5.536319058647324E-9,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark54(37.16627401564671,-0.5847214478770486,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark54(-37.16872592739291,-1.451943972473955,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark54(37.26697258483401,-1.2517314704857228,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark54(37.28008909741442,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark54(37.48941802434956,-1.4281183974402172,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark54(37.5235269081925,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark54(37.61543782153761,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark54(37.62270301271017,-2.588327756314704E-8,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark54(37.62599942996437,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark54(3.76413079530775,-1.2081678475366335,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark54(37.72319551746966,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark54(37.740415497673865,-0.22594344751802814,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark54(37.75780075681476,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark54(3.779834657692593,-0.41301425830923355,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark54(37.82747431867986,-0.011270366993511638,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark54(37.850052634729025,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark54(37.86033913054632,-1.2470825338199307,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark54(37.86593938843002,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark54(37.95894959484153,-0.3879434667694319,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark54(37.9930792881942,-1.417747882841823,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark54(38.064467123321364,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark54(38.06570937447435,-0.46230738886097344,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark54(38.07970665319479,-0.04753358870719815,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark54(38.08353315380586,-1.3379623198574648,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark54(38.11578137360405,-0.39812689427941095,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark54(38.12798435533969,-1.4999999999433662,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark54(38.29568815422879,-2.007897894806129E-8,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark54(38.31685009874016,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark54(38.36989816486142,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark54(38.38118612034964,-1.1174499746174726,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark54(38.38722087915911,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark54(38.43598157067656,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark54(38.43837941899352,-1.267044716297077,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark54(-38.48651254092591,-5.0699211003267055E-9,0.9999999999714669 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark54(38.58526832924295,-1.1795963953876605,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark54(-38.602429771052265,-2.220446049250313E-16,-0.03560483198957984 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark54(38.65703331025756,-0.6751742987880576,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark54(38.66955951060501,-0.5395152967537118,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark54(38.70612109391456,-1.2109747746396944,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark54(38.7084014732597,-1.480453094106001,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark54(38.846195529019724,-0.02586826545616816,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark54(3.89665304515448,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark54(39.02782654498563,-0.7414289577677664,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark54(39.03059136200753,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark54(39.03567431107785,-0.07196606127015914,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark54(39.132491361294655,-1.3481500971394862,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark54(3.914391328142525E-295,-1.456869202006182,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark54(3.9149751729871376,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark54(39.153346925676324,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark54(39.17740870485545,-0.5150820287052533,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark54(-3.9250318953472316,-1.0458268087630913,0.0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark54(39.25710352871521,-0.506088362904882,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark54(39.28574005239611,-1.1154767750280774,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark54(39.30083038501462,-1.4999999999515983,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark54(39.30664460604463,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark54(39.3127389614626,-0.3241665465850124,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark54(39.33511472668172,-0.21307063054501932,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark54(39.36688646279606,-0.08772653442288125,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark54(39.379980814388375,-1.2896275486779198,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark54(39.449575172439644,-0.3958961114208578,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark54(39.49440760274575,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark54(-39.57367936693533,-0.11007736483497932,0.025537175845644744 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark54(39.61041474231118,-1.3024607427368107,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark54(39.64566947927025,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark54(39.74625262736825,-1.4012235959796016,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark54(39.783466425786656,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark54(39.830349634897516,-1.173637054279086,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark54(39.86530745858559,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark54(39.86922400684821,-0.8968647069608628,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark54(39.87314331792072,-0.36050515988895837,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark54(-3.990855289630015E-8,-0.30181957525999076,8.86622035360428E-9 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark54(39.92292949462691,-1.0442067145435963,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark54(39.932737715027635,-0.7572638744417048,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark54(39.93414359937671,-1.1517781163025549,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark54(3.999781817847312,-1.4594277403751363,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark54(40.009875396978664,-0.7557504195137082,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark54(40.013078392452414,-0.02967613363195254,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark54(40.117635635932416,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark54(40.14071824061733,-1.48424702316008,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark54(40.248515833284756,-0.34804417604912885,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark54(40.30628384443199,-0.6455237797198095,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark54(40.347073165275035,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark54(40.446752788298966,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark54(40.47268191514519,-1.268721943738326,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark54(-40.533692654381696,-0.5759695584791586,73.82036685385324 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark54(40.58099881675136,-0.9499843974227815,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark54(-40.59686393308413,-0.11434995045627572,-1.0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark54(40.60513565423935,-1.4426438800530264,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark54(40.61403427837598,-1.4999996651351337,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark54(40.63380037847835,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark54(40.70962206480263,-0.6083668798195987,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark54(40.722407700632715,-1.3828052547668221,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark54(40.72965156657645,-1.4430535870314336,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark54(40.740947871921605,-9.735700533902152E-9,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark54(4.083018285326247,-0.49939086770619934,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark54(40.85365555119295,-8.669976283507959E-9,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark54(40.913658933253174,-0.19584523950299282,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark54(41.08981890419304,-0.30156986972845734,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark54(41.11301084298646,-2.1839560196863836E-9,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark54(41.11583443010677,-1.480209529729344,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark54(41.135799898300775,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark54(4.115856922796723,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark54(41.23695366880938,-0.08495433975594224,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark54(4.127759110546037,-1.0011741811486634,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark54(41.29868400597144,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark54(41.30406469279947,-1.049985570368463,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark54(41.43532127379501,-0.3763767098427868,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark54(41.466321294242576,-0.7202354368275996,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark54(41.51478226747188,-0.08181539923304279,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark54(-41.515316288696994,-3.5194545168057593E-6,0.061722094592015095 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark54(41.53595250837203,-0.9734542065719154,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark54(41.62510046362294,-0.8019945494964018,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark54(41.631821157046744,-0.6758273103083141,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark54(41.66123232000268,-1.3648912123832635,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark54(4.168552670090001,-1.4999922090997484,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark54(41.72597651798196,-1.330566754755182,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark54(41.74316186751673,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark54(4.181484205121947,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark54(41.81924546042143,-0.1668616306505477,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark54(41.845460123373556,-0.38025083178607133,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark54(41.865408358671345,-0.683218313291917,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark54(41.871245381379254,-0.28445898508997414,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark54(41.87638705278863,-0.02690560173061828,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark54(41.94783000326815,-1.2423417574465987,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark54(42.02381928514589,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark54(42.11846548775716,-0.7980884121106847,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark54(4.217461795566791,-0.1484237864069402,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark54(42.23111507571199,-1.4999999892779197,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark54(42.34708827446616,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark54(42.36330102206451,-0.5556530642901176,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark54(42.421244349829635,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark54(-42.48492999731616,-0.007562259412955395,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark54(42.49171795973171,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark54(42.51454049076324,-1.2636567552838724,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark54(42.56238591968727,-1.020931317371339,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark54(42.64341109937811,-0.3868536037046484,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark54(4.264523365997235,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark54(42.64974477498917,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark54(42.66402872212458,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark54(42.714118535634924,-0.9121859078412378,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark54(42.75610044192841,-0.5600239681081087,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark54(42.784735050937456,-1.0728068228261805,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark54(42.8529682814096,-1.472266022199152,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark54(42.96508714241514,-1.1466101030185214,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark54(42.967693930443005,-0.7011261429136404,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark54(43.00914559649762,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark54(43.07099822819116,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark54(43.12104560875405,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark54(-43.13412616790564,-7.105427357601002E-15,-61.70212473466216 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark54(43.147725846238814,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark54(43.1554925200929,-2.2395251326272725E-9,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark54(-43.16252743994245,-0.8514843035264658,-0.9507455430504317 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark54(43.18586541079,-1.0216446705558357,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark54(4.320393943746751,-1.3164242047541848,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark54(43.24823334979283,-1.292553993316429,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark54(43.29242329242584,-1.4421637713225488,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark54(43.314959262298544,-0.9210889012525332,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark54(43.317380828874946,-0.8698313626468931,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark54(43.32701139511562,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark54(43.33710891232684,-0.45573594602217016,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark54(43.363450385844956,-1.2872146879755633,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark54(43.383353231779495,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark54(4.342242650015976,-0.43451677299145847,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark54(43.458554461330664,-0.16633477166128544,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark54(43.54181435139854,-1.0461366535672836,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark54(43.55006781324877,-0.7591174970862768,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark54(43.62553644516561,-1.4470371183503516,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark54(43.62966101307319,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark54(43.65640807986955,-1.4682642999584772,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark54(-43.71636296557819,-0.5108251162014312,1.0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark54(43.74012733395142,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark54(43.817908792301154,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark54(43.826842119496405,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark54(43.85069690897594,-1.4670030809259025,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark54(43.87306540795325,-0.5558104995549726,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark54(43.882198559235576,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark54(43.89772804351774,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark54(43.937217504968025,-1.4654864233543083,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark54(43.94150606997928,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark54(-4.397345623836369,-1.276581869130045,-29.061718817931567 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark54(43.99312775649446,-1.410236884572095,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark54(44.03927035440767,-1.4975373195620036,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark54(44.1753657428639,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark54(44.20320601503059,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark54(4.424608730767613,-0.7596184767321972,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark54(44.30859859830898,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark54(44.33131057223662,-1.0579452536083014,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark54(44.33330791234195,-1.1494570701814255,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark54(4.440892098500626E-16,-0.971113085231772,-27.45301553222693 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark54(4.440892098500626E-16,-1.4196081278236001,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark54(44.44807706787884,-1.188713992868756,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark54(44.45171890310393,-3.873195449556669E-9,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark54(44.49837860969538,-1.490035429138544,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark54(44.57965912931681,-1.166183897342387,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark54(44.58408086901904,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark54(44.61256181540178,-0.3696406607231276,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark54(4.461391944218647,-1.1283539602584374,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark54(44.62391289606043,-0.6471531084123114,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark54(44.659242606381525,-0.9895321974709632,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark54(44.66823838243267,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark54(4.4689254987590585,-1.4999999999538192,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark54(44.69489296278991,-0.9322335010663068,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark54(44.71283217091951,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark54(44.718058817548524,-1.1758233133540619,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark54(44.754402942849794,-1.1489569146220922,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark54(44.7687976559867,-0.8099306751899531,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark54(44.77625893470624,-0.694872754024895,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark54(44.79982531957444,-1.3732840578371022,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark54(44.80277746939174,-0.9604730040430061,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark54(-4.480603741102357,-0.2724872106224709,1.0000000000000044 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark54(44.84091069686059,-0.09181933894503436,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark54(44.880516946046825,-0.6056600876293601,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark54(44.88192265352819,-0.3755410395363601,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark54(44.90075321214891,-1.4177818554182031,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark54(4.492637042391905,-1.3851985005683596,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark54(44.93996916338037,-0.5591871617215673,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark54(4.494981957532413,-9.73832232960349E-6,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark54(-44.96130566621011,-3.4934149817586818E-15,0.2817375176524785 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark54(-45.01525722757221,-1.178431062578778,1.0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark54(45.03370047111966,-0.5689705332474233,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark54(4.503618753648624,-0.9162909965147892,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark54(45.07484398803717,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark54(4.5141135174350495,-0.7720842851718719,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark54(45.14868313667978,-0.3749423898859505,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark54(45.15356570358505,-0.13770178665143623,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark54(4.5160402611345125,-1.4421196470003146,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark54(45.25397383551194,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark54(45.286790667316176,-0.17012771840041108,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark54(45.32199257120689,-1.4668340635412846,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark54(45.369848850225964,-0.37421961086477573,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark54(45.38289293291339,-0.15507356748381085,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark54(-45.4187595507068,-0.9125304078738091,-0.9999950722112221 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark54(45.463410025436374,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark54(45.47230666157958,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark54(45.476041020344184,-1.3519475939874277,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark54(45.48670965024047,-0.20534084653323248,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark54(45.498803310907675,-0.7178082560092456,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark54(45.5136940398162,-1.7054681858165067E-5,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark54(4.551933094080866,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark54(45.52210795097096,-1.297374554181971,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark54(4.553589641609946,-0.35481022554789954,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark54(45.55251099232407,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark54(45.587993788439924,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark54(45.59512807954773,-4.883053326498647E-5,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark54(-45.61242270591222,-0.21346300384388428,0.9999999999999988 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark54(45.6366268094714,-1.0349540117783327,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark54(4.5720041047325335,-0.7645838822564996,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark54(45.75909960071184,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark54(4.579176260551932,-1.4530057867432529,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark54(4.579275794855533,-1.4999999999341442,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark54(45.82284770739375,-0.16452416691913296,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark54(45.83713098013526,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark54(45.88095121304155,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark54(45.97870713449513,-0.0779415411177582,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark54(46.10728894813121,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark54(46.13082543246284,-0.08414829801874202,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark54(46.13297653287581,-0.9618066928691351,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark54(46.23357905086198,-1.405471645945281,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark54(46.241483541732165,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark54(46.294026595950044,-1.0401739840967394,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark54(46.31740076905939,-0.7231545168477864,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark54(46.37062506124943,-0.3049759868256202,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark54(46.42335230247761,-0.4536302823435072,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark54(46.44136092154014,-1.2727314103331935,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark54(46.45187481791183,-1.4630403454257959,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark54(46.48195687174963,-1.0891647820639223,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark54(-4.659188007028689,-1.4999999999999991,35.73358551368858 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark54(46.605774257546585,-0.2973926356339769,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark54(46.676052680180646,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark54(46.73638947730488,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark54(46.74974647831372,-3.178627473504564E-6,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark54(46.81283045674857,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark54(-4.6823098536904695,-1.4999999999999973,1.0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark54(46.86743459263835,-0.4352455547782341,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark54(46.87948700568231,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark54(46.88004124832398,-0.14154631298130793,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark54(47.08722325124362,-0.44227368945051443,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark54(47.09692106766056,-0.13366501576265577,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark54(47.11135727123113,-0.7575433690770268,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark54(47.19845417940297,-0.8514816038471196,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark54(47.22595969964241,-2.3865695712882813E-8,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark54(47.395073375734086,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark54(47.39670836491453,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark54(47.439929649283954,-1.0120404910066725,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark54(47.46760619102767,-1.3275580718980589,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark54(4.755203395560287,-0.4693081191043387,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark54(47.62021362824305,-0.1663826724330626,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark54(47.6425185881019,-0.5464724554128222,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark54(47.70404313036826,-0.1874919430943769,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark54(4.77080268252206,-1.056973148558356,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark54(47.732074204958536,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark54(47.742317814254335,-0.39037813044163305,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark54(47.83390004233176,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark54(47.84600310289022,-0.5508850811033845,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark54(47.86162171134121,-0.9890740761406711,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark54(4.787165911589017,-0.6993140084881846,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark54(47.87590341121185,-1.3001042402503806,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark54(4.795759175861229,-5.330207328854121E-9,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark54(47.969924493616915,-0.7717241751338548,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark54(47.972354713925334,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark54(48.03538138838797,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark54(48.099047108842086,-0.15916642601619235,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark54(48.1288687454099,-0.7157074558194552,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark54(48.13482510820904,-1.3593776725797178,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark54(48.20707631387458,-0.4219318942335235,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark54(48.27883368877238,-0.3161864955759013,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark54(48.30666454661118,-0.14775723175995853,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark54(4.833728778218131,-1.1239016217307665,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark54(48.35563411742703,-1.04180056066852,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark54(48.40097889528534,-4.794513701107663E-8,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark54(48.407865918130625,-0.8993598474361448,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark54(48.40913049810297,-1.4999999999999822,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark54(48.439869917009304,-0.8385921270574102,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark54(48.44255524024195,-4.79537071962867E-10,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark54(48.49524870275971,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark54(4.853503983459241,-1.3113316852538137,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark54(48.574345569248806,-0.6557424323298875,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark54(4.865003011766916,-0.21298901505959306,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark54(48.68458642887005,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark54(48.71622374593784,-1.385459662129776,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark54(48.77828073631292,-0.7491813144273274,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark54(48.797289129028286,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark54(-48.80633634470315,-1.4971954321948138,1.0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark54(48.85173027412867,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark54(4.891919984916408,-0.14254696443422987,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark54(48.95581021404837,-1.2923713297077604,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark54(48.996841729976325,-1.2233603614901511,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark54(49.005357690741334,-1.127876963145301,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark54(49.050979970536815,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark54(4.9057748448865235,-1.15299116814333,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark54(49.05964883076618,-0.9285737265530739,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark54(4.909510073934271,-0.9816729046846546,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark54(49.15046298338085,-0.7969508168164977,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark54(4.926765363297587,-0.9619485299289041,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark54(49.29742245412368,-0.4902818282513266,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark54(49.29897298093053,-0.038514139816179876,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark54(49.32746444859705,-1.2295367755810103,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark54(4.935112080308405,-0.4986630004269821,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark54(49.38482910106283,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark54(49.3979767188348,-1.1160492997963365,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark54(49.43560357842952,-0.10294000239979084,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark54(-49.490362028422986,-0.44761889355171236,-0.6429200541340818 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark54(4.950005489773332,-1.392797667654108,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark54(4.952711877756329,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark54(49.53045684988165,-0.0140289114979526,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark54(49.55036499597355,-0.10344308175593486,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark54(49.646954951875955,-0.2599053777665902,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark54(4.967468527763145,-0.5349103494726108,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark54(4.972902725490361,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark54(49.76965038110103,-1.2929384695746358,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark54(49.77568646256892,-1.6254368850595227E-9,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark54(49.84624431670318,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark54(49.8548836262772,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark54(4.985813211624631,-0.09740937177701345,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark54(4.986232834783451,-0.7966013420540352,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark54(49.938002697062004,-0.657452405560692,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark54(49.997130380027585,-0.05654391413695531,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark54(50.003130753609184,-0.4502387417179037,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark54(50.0241708218551,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark54(50.03117228265924,-0.7707327753100088,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark54(50.11397066465404,-4.1924658713596285E-10,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark54(50.12227471290436,-0.9952066750833772,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark54(5.0173874547237745,-0.8977728815185526,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark54(50.17754527938348,-1.4999999999999716,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark54(50.18343858296919,-1.4999999989364903,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark54(50.200517089830385,-0.5015034128905,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark54(50.25176909204772,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark54(50.28528444271038,-1.2349655575325267,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark54(50.294793934577,-0.36801362122053405,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark54(50.34374666994391,-0.5406836608936629,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark54(50.383509202636084,-0.5576531468871648,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark54(50.385191990078454,-0.8698668084519596,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark54(50.41660852883473,-0.40538106006266617,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark54(50.43728948705533,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark54(5.046025002701937,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark54(50.52395668695385,-0.38525410873381816,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark54(-50.53537669267714,-2.7755575615628914E-17,0.0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark54(50.575022373836305,-0.7312471104946541,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark54(50.67970336467421,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark54(50.68353667198362,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark54(50.69291553638341,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark54(50.70754205838048,-1.4134062650253187,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark54(50.720141499448985,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark54(50.81554606748966,-0.4286321485334099,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark54(50.82105951367157,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark54(5.083170685421866,-1.4327676184203026,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark54(50.832031780148604,-7.537086922547908E-10,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark54(50.851179317546496,-0.8524293107797121,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark54(50.86588516224731,-0.6192531279165361,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark54(-50.88041463833587,-1.4413099286062299,-0.7718828674625549 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark54(50.914005512889105,-0.7706753133177955,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark54(50.92971530380038,-1.0644583936502912,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark54(-50.959014913039844,-0.12667910474692332,89.85003494527797 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark54(50.97158716439881,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark54(50.98200184874839,-0.7381979608162736,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark54(51.061339206478536,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark54(51.067939628500454,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark54(-51.12748003322035,-0.06683271215284431,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark54(51.13142983342419,-0.6069111179689932,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark54(51.157430440689495,-1.499999999999997,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark54(51.173790024681395,-1.250114361274361,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark54(51.21127039347911,-1.2916905429679222,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark54(51.26583165058892,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark54(5.129870240982554,-1.0832953657112707,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark54(-5.1306710016229703E-290,-0.7299754348241898,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark54(51.32061931311752,-0.4295208532781478,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark54(51.35300720101267,-0.3250207782301716,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark54(51.39991459308985,-0.47694337076992555,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark54(51.403826009272706,-0.31280568737503955,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark54(5.14226358596181,-1.3879764180098166,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark54(51.44243382918,-0.00563873048893284,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark54(-51.4472008072804,-0.5818438554862269,61.96448074376906 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark54(51.489349861158985,-0.1050594006514072,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark54(51.498432145546445,-0.31742236597385154,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark54(-51.5027273890555,-0.30363474983623806,-1.0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark54(51.56403587401073,-0.11593367664284172,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark54(51.63787405416028,-0.44913483157291534,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark54(-5.169878828456423E-26,-0.8659947300152109,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark54(51.77873135994,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark54(51.77898049650261,-0.0486319234761563,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark54(51.833690929727204,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark54(51.88853924834217,-0.5429053909251906,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark54(51.98202890966223,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark54(52.00480046489885,-4.018959679236654E-8,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark54(52.006245779971636,-1.491291655631727,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark54(5.204765438176565,-0.15457218848217735,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark54(-52.072234689713014,-1.4506668484269228E-7,37.930448216220725 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark54(5.21477827833354,-1.2984051493226008,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark54(52.15952200902978,-7.269001955349424E-9,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark54(52.15972668588784,-0.535473452771069,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark54(52.22946694556032,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark54(52.27397785856156,-1.2432036678616682,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark54(5.22962012729969,-4.928501773231952E-4,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark54(52.32279899304743,-1.144053859024467,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark54(52.346444618779884,-3.3307783271754648E-6,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark54(52.36719073792558,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark54(52.421019702582925,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark54(52.44077050850589,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark54(52.446564111882566,-0.13559123730186098,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark54(52.448253887124096,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark54(5.245218704589206,-1.388061458161255,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark54(52.47290390289879,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark54(52.49273131545294,-0.1194781293758922,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark54(52.50897997711197,-0.2157561450382559,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark54(52.51892526408877,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark54(52.53133848993781,-0.0029919463703192766,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark54(52.53479077227752,-1.4641140046341397,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark54(52.567380553778406,-1.3157811687632384,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark54(52.622650320460906,-0.5758771535390679,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark54(52.64924866664248,-0.3091688610711948,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark54(52.6692849716502,-1.3852645163375996,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark54(52.789263410006015,-1.1702659702618765,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark54(52.81819134277538,-0.2109393233385678,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark54(52.85349083898416,-0.8284940376061698,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark54(52.86632654849773,-0.9095782266756808,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark54(52.90982909785904,-2.121792496796394E-9,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark54(52.96101147058232,-0.9005626571086509,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark54(53.0708626766893,-0.22478771263037345,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark54(53.08132594822277,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark54(-53.08905343271829,-0.7502264778607741,0.9230812151552237 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark54(53.10695497578935,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark54(53.17499598812384,-0.15514418679718744,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark54(53.1792190158732,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark54(53.234646804964676,-5.500058927051631E-10,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark54(5.33132646860679,-0.7315103710359836,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark54(53.325376515506065,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark54(53.326867991087795,-0.3104796743941387,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark54(53.3321910798698,-0.11594847062326963,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark54(53.343993624350034,-0.7141372477815416,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark54(53.36604681909708,-1.2853940754485307,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark54(53.37304929619873,-0.16365223132635265,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark54(53.40955240185127,-0.0534659522390003,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark54(53.487294031300564,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark54(53.56484910923916,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark54(5.359771752076836,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark54(5.359810078350975,-0.6084135952320935,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark54(53.63811873649419,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark54(53.67241166651087,-0.035264311646518234,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark54(53.72078222815779,-0.9010158378216488,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark54(-53.77317526016564,-1.49999999989855,1.0000000000370708 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark54(53.78943985953927,-1.209587311899986,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark54(53.79607800675697,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark54(53.8417679361467,-0.3185472979004232,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark54(53.85033684231214,-0.5548272900799454,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark54(53.87137357845765,-0.5342151506904873,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark54(53.88727154313513,-0.0030800133036476135,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark54(53.969534427664996,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark54(53.98704451933799,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark54(54.10273731794225,-0.09800857347510128,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark54(54.202179383517766,-0.013627765519996726,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark54(54.22036268829149,-0.676930855706928,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark54(54.26359441755562,-0.07965118284719508,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark54(-54.307993058406325,-3.756107109171998E-5,-2125.180347855518 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark54(54.31676412921544,-0.15752972222597883,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark54(5.435621837604515,-1.349375215392251,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark54(54.38944195172701,-2.8791921344102247E-9,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark54(54.405744008695656,-0.15819606314583962,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark54(54.451618315017896,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark54(54.517769387418895,-1.2123737726456172,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark54(54.53653656881261,-0.48489729831597356,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark54(54.56562413862878,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark54(54.580081714774195,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark54(54.68552512709411,-0.3997262887883508,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark54(54.69606089589237,-1.3254512972267243,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark54(54.71216391439114,-0.22043593608401335,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark54(54.713490816662556,-1.0815621148056223,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark54(5.4767948699771125,-0.3649592007316729,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark54(5.480801667183059,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark54(54.82839770517822,-0.9293233404561221,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark54(54.835909624392066,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark54(-5.485358594473254,-83.97062093420601,48.87027847668031 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark54(54.915223501810516,-0.24500050855892397,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark54(54.959063765720586,-1.4394031085148604,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark54(5.4983671067664375,-0.03408418087103582,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark54(55.005548251266354,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark54(5.502463808740288,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark54(55.039404112124885,-1.297181559650722,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark54(55.08831726606292,-1.0306438686936814,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark54(5.509838336208587,-0.8612778539373664,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark54(55.10722459408464,-0.13392935238853454,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark54(55.15799422066007,-0.1862249155508282,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark54(55.17239706039197,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark54(55.17963995612817,-0.21122716447776568,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark54(-55.22109077251183,-0.6935293667453244,0.12631867049503764 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark54(55.22369421129369,-1.0194521075548144,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark54(55.24643405032459,-0.9660017506123246,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark54(5.524759701264831,-6.044247092060289E-10,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark54(55.287048432120194,-0.5263548440389219,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark54(55.29931825559217,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark54(55.32136493248939,-1.0522719055118352E-9,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark54(5.536153484395868,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark54(5.536726891623417,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark54(55.38712404789557,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark54(5.54097533089957,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark54(55.41840751668124,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark54(55.45003266150064,-0.46988142248815834,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark54(55.49149593328099,-0.04333826014519104,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark54(-5.551115123125783E-17,-1.485976686171474,-4.1359030627651384E-25 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark54(55.51515312254723,-0.8252215033301784,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark54(55.545207990112175,-1.4349685146695421,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark54(55.58577878819986,-0.04100433353881762,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark54(5.559307340874227,-1.4867454155758324,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark54(55.59669755880546,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark54(5.559714286394097,-1.4148279841521116,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark54(-55.64911591134596,-2.220446049250313E-16,1.0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark54(55.69224880959338,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark54(55.70932936464078,-1.3507320393340052,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark54(55.769046265889344,-0.2979522733607264,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark54(55.77294896463701,-0.7901352803988146,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark54(5.57922600104763,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark54(55.804658222026674,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark54(5.590674059452092,-0.8996747824290917,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark54(-55.912734635626116,-0.7842699317998253,0.041612761908529916 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark54(5.5916967857063895,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark54(55.97133844000342,-0.14707493619300838,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark54(56.019151432555844,-1.3136499001934205,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark54(5.602148727544673,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark54(56.034213654747994,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark54(56.074992386073525,-0.3631739984986375,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark54(56.078185676540954,-1.394609090956648,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark54(56.10819084339147,-0.6669870112613978,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark54(-56.166083066730046,-0.11546944350357324,-0.49949177660981514 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark54(56.170092185811896,-1.1202915946462095,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark54(56.17344011725976,-1.2188405731805065,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark54(56.30335138061638,-0.1764701390053265,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark54(56.32600247152154,-0.12416402626322842,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark54(-56.34014857739844,-1.1825334770637208,0.9806276978364545 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark54(56.4126414419722,-1.4711530320134187,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark54(-5.648350718739707,-1.4999999999999964,-0.9999999999999962 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark54(56.494718919803475,-0.2935683264153699,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark54(5.654373128819122,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark54(56.55025465007927,-0.03307853697421148,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark54(56.55853863009196,-0.6919936176215007,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark54(56.5838242378642,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark54(56.59386177215541,-0.4134943932606333,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark54(56.60105028402517,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark54(56.61400933874256,-1.0946453628354398,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark54(56.621161852671804,-0.7415308621560928,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark54(56.68106950910638,-0.2054910774306844,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark54(56.70515615197163,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark54(56.80904903891238,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark54(56.84210779907437,-1.2679098942138077E-5,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark54(56.858174728604034,-1.3359726210147564,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark54(56.86736874286356,-1.4999999999999432,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark54(-56.8755466339377,-0.14449178619811054,-0.04444503334701172 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark54(56.901209982296926,-1.167597464753784E-9,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark54(56.952797923747,-1.4076868632644972,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark54(56.988968895558656,-1.2373956171679044,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark54(56.99315127231935,-1.2222580280387234,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark54(5.703084619560758E-11,-1.2106573293310703,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark54(57.04057450252776,-1.0752581971056472,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark54(57.046840597179255,-1.3424055194479507,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark54(57.10699882604746,-1.1238140072608296,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark54(57.1334991017539,-1.3878295831910812,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark54(57.1465094418397,-0.502604847975233,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark54(57.254984710581375,-0.5714346101371657,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark54(5.7265022055039445,-0.9204919147377488,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark54(57.3196988780206,-0.025403383131880397,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark54(57.320764331057404,-1.3843979182877388,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark54(57.32795626031972,-1.227229146964632,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark54(57.33226027459472,-0.7897655975667011,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark54(57.393321834249875,-0.26390699791677313,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark54(57.45195564675441,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark54(57.461187579192995,-1.1361983800772943,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark54(57.47751991807499,-1.2122411049930308,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark54(-5.74858035935474,-0.9603900293093971,1.0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark54(57.51668713566744,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark54(57.543313181244464,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark54(5.7604821269393796,-1.1112642965621822,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark54(57.676773875208646,-0.9601326084196369,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark54(57.74805046476342,-0.6305375137743873,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark54(57.86570957789493,-0.7767237456739764,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark54(57.8883951520838,-0.10179937984169651,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark54(57.917168365687544,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark54(57.935372836574146,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark54(57.93731933639873,-1.3527858479716466,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark54(57.94165106106544,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark54(57.97713724871021,-1.2467895741062391,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark54(-58.019792392230976,-0.8173408964741589,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark54(58.044662862872485,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark54(58.056659119169794,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark54(58.12185233234625,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark54(58.13648779013486,-0.027064061861452826,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark54(58.191365105143035,-0.7040043487437555,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark54(58.20593899134509,-0.08884085546808951,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark54(5.821831558543689,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark54(58.25733128632697,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark54(58.29974261114245,-0.915496444866724,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark54(58.342805779509774,-1.4802129893031208,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark54(58.38375557159192,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark54(58.40128787474629,-0.9031441638861963,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark54(58.47812056174172,-0.03232029618750065,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark54(58.51815499080211,-1.337699684931541,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark54(58.56084699143068,-1.2052050859728847,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark54(5.859261830819576,-1.094929664038451,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark54(58.65920657008495,-0.04754674820289406,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark54(58.66427685058832,-0.5599436222544547,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark54(58.66514359764062,-0.7005734238760226,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark54(58.67549142664902,-0.4649751760757117,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark54(58.681186838118734,-0.7161309228041972,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark54(-58.7050159975504,-0.9401826303848808,0.050112913012378094 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark54(5.870611847625909,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark54(58.71215216743766,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark54(58.80150725172341,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark54(58.82927316394529,-1.3463969176360289,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark54(58.829980839841426,-0.2681613799468634,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark54(58.84930969996287,-0.36054565227942414,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark54(-58.86064199673635,-0.03896094696239866,-34.877450806913714 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark54(58.873179585458274,-0.7815663608504008,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark54(58.96012867227478,-0.32370152825064613,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark54(58.98889588804167,-1.1476629505643325,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark54(59.004046784737135,-0.5986367185591833,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark54(59.060465881385205,-0.6095005065165147,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark54(59.1520119675416,-0.6713091095638419,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark54(5.926118836401538,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark54(59.29139112313661,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark54(59.310200588398715,-1.3710485520897355,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark54(59.395245107744955,-0.9392392753216683,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark54(59.39526635058502,-0.990000317827139,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark54(59.42502402723989,-1.4999999537774427,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark54(59.42741393231486,-0.7290265836096381,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark54(59.489101637591105,-7.507673653429713E-8,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark54(-59.53011154979728,-0.07313793829945991,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark54(59.54614989794621,-0.14937797215442705,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark54(59.5541589611791,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark54(59.57294277287269,-1.166946774350322,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark54(59.576693478120994,-8.215567504822704E-10,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark54(59.66018879506507,-0.047816802580442186,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark54(59.70808180172037,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark54(59.78712242913028,-1.132879627840329,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark54(59.788374654336685,-1.3602256022937744,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark54(59.7953491645591,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark54(59.86323665618593,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark54(59.91786792073083,-1.20685120049977,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark54(59.92125216523235,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark54(-59.96633673361221,-1.0202866392848868,-1.0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark54(59.9948095761946,-0.0976509357404236,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark54(60.00410065702372,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark54(6.001891515239996,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark54(60.12459144447769,-1.1343160260610006,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark54(60.162450613914245,-1.499999999999984,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark54(60.1685634117558,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark54(60.18289826807058,-1.4999999448630632,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark54(60.24103905938182,-0.07706104094623006,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark54(60.279292768768556,-1.499999999999984,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark54(60.31057305220648,-0.32820571747275,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark54(60.32822102827339,-0.4135547848232388,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark54(60.40857156549212,-1.2501525636315858,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark54(60.413701614601194,-0.14097048430481274,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark54(60.48588921165617,-0.24248461694000323,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark54(60.48850229447555,-0.12375772277786434,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark54(60.536343005193544,-1.2397095404248688,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark54(60.58225723521214,-0.5050634276856787,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark54(60.63335271110429,-0.26433261154259213,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark54(60.65230685944135,-1.2306340544715226,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark54(60.710428303069506,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark54(60.724825510835295,-0.4795289153473463,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark54(60.730481211419374,-0.5300253691582707,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark54(60.75013138440451,-0.26591063314342644,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark54(60.77583663493829,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark54(60.8000235770698,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark54(60.807489818317435,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark54(60.82810204891763,-1.2299265053846558,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark54(60.88753810559668,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark54(60.90615421614146,-0.17713434850002585,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark54(60.9771736497558,-0.8933558302456959,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark54(60.99418082609979,-0.800549891676341,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark54(61.06783371889071,-0.0403183806138423,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark54(61.087311656162186,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark54(6.113450614805276,-0.7182529622385534,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark54(6.114181417173441,-1.4179653102953784,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark54(61.145352014472365,-0.3345356821407961,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark54(61.26146510070478,-0.03243234894702485,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark54(61.274036998763336,-0.32784421907459926,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark54(61.28482652963216,-0.6969013535257389,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark54(61.30252292313557,-0.07093945514023403,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark54(61.32445103744544,-1.2925389295924483,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark54(6.134886259360144,-0.9690725393580806,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark54(61.38367742768898,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark54(61.45909724261574,-0.07979336060029649,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark54(61.519035431269685,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark54(61.54880731851219,-0.0466370160007666,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark54(61.70714918664558,-0.8590494070256616,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark54(61.7455257498753,-0.09014768318129995,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark54(6.1779697878901345,-74.0726715791822,4.162945186132944 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark54(61.87854457086467,-0.9268015708105083,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark54(61.966165286564916,-1.4999999999998224,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark54(61.981433469961445,-0.522833279957119,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark54(61.991208818008545,-1.3938223904681308,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark54(62.01521270051512,-1.098645774793649,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark54(62.051620549735055,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark54(62.11751069045396,-0.8403219714146537,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark54(62.12486153404572,-1.0544793473194511,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark54(62.15343037983576,-0.6270332522566242,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark54(62.19684431325376,-1.4812288393342818,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark54(6.220752754469421,-3.94699637353684E-9,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark54(62.265338060271404,-0.8630790806189748,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark54(62.270098693192324,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark54(62.29861438407988,-0.17778946035744925,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark54(6.240802116789297,-0.1031716775488567,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark54(6.240928572426711,-0.207370591880496,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark54(62.40943335041621,-0.8869346551977866,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark54(62.466892202660944,-1.3645272929510774,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark54(6.253165980771799,-0.7454864713035511,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark54(-62.53288606373444,-1.2567508271416727,-18.870490499436258 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark54(62.53901883740789,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark54(62.53906865526136,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark54(6.255272309293233,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark54(62.565863082128374,-0.9204810149152092,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark54(62.69666292230994,-0.6489474186917787,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark54(62.72098465969361,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark54(62.76429910959226,-0.23402291728220348,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark54(62.783464875681574,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark54(62.82542538115919,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark54(62.83098188029288,-1.446785810951912,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark54(62.83479189956779,-1.13530312390536,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark54(62.86416172388339,-1.5698708671194823E-7,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark54(-62.92062015012966,-0.6431517892120222,61.249800254890886 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark54(62.9471621268156,-0.9483385762405909,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark54(62.95241141614153,-0.6347294989460447,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark54(6.297006550340825,-1.1254097251972364,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark54(63.01318242592659,-0.3500358995396008,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark54(63.01793588887562,-1.223213349327887,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark54(63.03466027289813,-1.179211847728936,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark54(63.06303259192063,-1.1675956965033834,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark54(63.09367013947772,-0.7656833287778948,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark54(-6.3108872417680944E-30,-4.930380657631321E-32,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark54(63.11117334445864,-1.4999998983882712,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark54(63.11674699016467,-0.4878996358795131,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark54(6.313947567717655,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark54(63.14763780274519,-0.5048564866184349,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark54(63.149300394574595,-0.30448547420711236,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark54(63.158512164673205,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark54(-6.318679006201611,-0.3118818594524183,93.54694928638256 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark54(63.19554489711507,-0.8152596788687525,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark54(63.198735985344996,-0.964043075973736,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark54(6.320508046316029,-0.5442421366680923,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark54(63.213525868641554,-8.846582429374726E-4,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark54(63.26515281398363,-1.4652775687014594,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark54(63.294651246945236,-7.372338829278392E-5,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark54(63.313141573836305,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark54(63.35365816242785,-0.33961526385979374,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark54(63.37900830905477,-1.1593863939844393,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark54(63.38333724134338,-0.4664746028122124,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark54(63.438570206726695,-1.461094837458285,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark54(63.480098923360366,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark54(63.49043979255501,-0.5824555458755389,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark54(63.55973942118899,-0.12194465531443299,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark54(6.357240241295365,-0.40547713394481877,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark54(63.61120440631316,-0.45986012922051955,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark54(63.66980694537256,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark54(63.70199250342313,-0.5126854354037738,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark54(63.76931587762203,-0.003799242380565726,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark54(63.77606785434406,-0.7910832098055494,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark54(63.82206555700222,-0.09892578872390387,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark54(63.82507883208143,-0.8997360936342194,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark54(63.83756172642643,-0.879578583974876,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark54(63.84508013659848,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark54(6.389640953966612,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark54(6.39149488373844,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark54(64.05920076473532,-1.2445576185046203,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark54(64.13867990276006,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark54(64.14183130518987,-1.0403493368732812,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark54(64.17362349931776,-1.4378040863215675,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark54(64.24911671221729,-9.63292615131901E-8,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark54(64.28397517028074,-0.7247572125052342,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark54(6.4351761841080855,-0.6349739833155723,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark54(64.36472070178057,-0.332513564710667,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark54(64.37273285904763,-0.05994268847551365,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark54(64.39623731949493,-1.4322168449179884,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark54(64.4126452236425,-1.1831870939985971,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark54(64.43470742828089,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark54(6.445012901028555,-0.03338104513755569,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark54(64.50323388872448,-0.7330243091981998,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark54(64.53310542892453,-1.0450222798143696,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark54(64.55833700728817,-1.2342812392962799,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark54(64.5586069326574,-0.045827266313662546,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark54(64.56362896940007,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark54(64.56510985824099,-0.5492170266019798,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark54(64.61562574287201,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark54(6.461564083789094,-0.3530672171313256,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark54(64.62455729471986,-0.8419972102097546,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark54(-6.463815418281541,-1.7763568394002505E-15,0.940840752151605 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark54(64.64368692041637,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark54(64.70551242646565,-1.4068261631568149,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark54(64.77180164362389,-0.31700605583086805,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark54(64.85396279756586,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark54(-64.87796143552247,-32.758524718915936,-7.674326335543967 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark54(64.96799602844015,-0.8172612519714733,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark54(65.01314670349593,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark54(65.01683627033364,-0.9860089600940424,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark54(65.03851343459138,-0.8750029393509919,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark54(65.04114395947903,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark54(65.05398142488818,-1.230851735568829,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark54(6.509170269256259,-0.6492847928923453,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark54(65.12836548824222,-1.4294291412205515,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark54(65.13156095850195,-0.3720964730435785,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark54(65.13934000847746,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark54(65.18094326173247,-1.4123694675322014,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark54(65.19845410223058,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark54(65.2145815601809,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark54(65.2409664231991,-0.6631264705499547,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark54(65.25225171566845,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark54(65.35353064951241,-1.1517571903099189,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark54(6.53781706417243,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark54(65.4540460308703,-1.4999999994775652,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark54(65.50575156588522,-0.22334442218113942,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark54(65.56473053678206,-0.020312866432949134,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark54(65.56776490905364,-1.4733508089242815,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark54(65.57997551741707,-0.9359409574098827,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark54(65.6561102104603,-0.8581845248160249,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark54(65.67957944175919,-0.9160396749642945,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark54(65.71778295493269,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark54(65.72001491848832,-0.6213816761344837,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark54(65.7666284891884,-0.002530649784556971,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark54(65.79479159299086,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark54(65.89261797263697,-0.9319101487913741,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark54(65.90587936924501,-0.42633413761424377,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark54(65.9539707702389,-0.8029631573222389,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark54(65.98352271144486,-0.7595023780141034,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark54(66.13504002371627,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark54(66.16101458454503,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark54(6.6174449004242214E-24,3.1554436208840472E-30,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark54(66.26199644711883,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark54(66.36217650329547,-2.044862946341944E-9,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark54(66.40952916492125,-1.1428861213698953,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark54(66.44784326951674,-1.1414351964673415,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark54(66.49024277450981,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark54(6.650779052626902,45.09285971614804,99.87009590617376 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark54(66.56400934169261,-0.6710756770073658,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark54(66.57807136271545,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark54(66.62487825138118,-0.17062854039646538,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark54(6.6655288557282475,-0.10517449019433162,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark54(66.67783613659148,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark54(66.6958904626988,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark54(6.6705768368967995,-1.474639312909169,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark54(66.71676268163348,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark54(66.73580167073077,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark54(66.75502107679822,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark54(66.81182264123623,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark54(66.87852743693617,-0.5360142316197778,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark54(66.91663422927405,-2.641978126913795E-7,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark54(66.94298782561523,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark54(66.9526093875993,-0.22251591716471086,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark54(66.9996989901824,-1.2875427310046632,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark54(-67.01283207060642,-1.0460300734706736,-1.0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark54(6.7090657038288235,-1.0951045815961191,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark54(67.14575063405815,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark54(67.14795467439603,-6.244909037462776E-4,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark54(67.15416449078221,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark54(67.16414926973991,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark54(67.20505989231208,-0.820798617660687,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark54(6.727199172902701,-1.4326920675047123,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark54(67.30198650016183,-1.3551222323745353,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark54(67.30527460394734,-0.9505089718511641,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark54(67.30846469124594,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark54(67.33795391463596,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark54(67.4390044616172,-0.08116703455198149,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark54(67.4553765239308,-1.4783453407449174,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark54(67.48911100869753,-1.1528286596807886,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark54(67.50440635548819,-0.8430206403412015,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark54(67.57387329836234,-0.9434963488970263,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark54(67.70317436272595,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark54(6.776769910199732,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark54(67.77108229214113,-0.5033260002052149,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark54(67.77716794614628,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark54(67.8151852618737,-0.20552319489400434,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark54(67.82102390438268,-0.0778292036081536,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark54(67.82262818899267,-0.06617222778507426,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark54(67.85001937302614,-0.4790832127699361,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark54(67.86548692483748,-0.17164093187584162,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark54(67.88392838789446,-0.7139484432776726,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark54(67.93197792886583,-1.256761462913234,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark54(68.0368366142136,-0.987808238220873,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark54(68.09819747622231,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark54(68.10899181463402,-0.4951846815751533,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark54(68.11167952857124,-0.7947239563467594,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark54(68.15008733802924,-0.9371009042809391,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark54(68.16407763730362,-0.6588776905011144,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark54(68.20523114686426,-1.4999999999995435,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark54(68.21429426714198,-1.4999999999217708,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark54(68.22610142178289,-0.23523891506804517,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark54(68.26306078508156,-1.4999999999999645,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark54(68.29417445002633,-0.25605349860581805,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark54(68.32664553404695,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark54(68.36206352381416,-1.4999999565672517,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark54(68.37777133427994,-1.3185695122699457,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark54(68.39196788285614,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark54(68.44007839971695,-1.1660774077096647,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark54(68.45339512647291,83.40210437297463,76.35300517761786 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark54(68.46465637832472,-0.8525562759576673,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark54(68.4710283670014,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark54(68.64406591366051,-0.2381326695502839,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark54(68.67462978078493,-0.3190272980212162,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark54(68.7658873319287,-7.762850903536466E-7,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark54(68.86960402742064,-1.1897199640151412,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark54(68.87125648061829,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark54(68.95636702779332,-1.3578317102099886,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark54(69.05860369137505,-1.1931030407884982,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark54(69.06121640500741,-1.4899154672619026,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark54(6.907934580330891,-1.499999946272077,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark54(6.914815926760509,-6.387043207466082E-10,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark54(69.15156393869265,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark54(69.19877587213041,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark54(69.20763239165156,-0.6073864419513576,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark54(69.21561772375347,-0.0010408195355464452,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark54(69.33386003242278,-0.5539236533175718,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark54(69.33855963655202,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark54(69.34056339323905,-1.4762048979444367,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark54(69.34639131774662,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark54(69.34862995721937,-0.15013430248580972,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark54(-69.36140446911648,-0.20297188405034827,-0.9999999999999989 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark54(6.937299764557906,-1.227318515920399,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark54(69.38273024094903,-1.031309033443251,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark54(69.38924460508619,-0.8003333353382658,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark54(69.39715965413177,-0.2242405627759163,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark54(69.48204459415646,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark54(69.53018586019914,-0.3386814565075298,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark54(69.5755529010809,-1.6124320773899796E-5,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark54(69.5840906014896,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark54(6.962070199572137,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark54(69.6622172577659,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark54(69.67981013508663,-0.3534459406116497,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark54(69.72096920709653,-0.04899877982260877,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark54(69.74217332494445,-0.62461320367476,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark54(69.74940789922151,-0.2301459865511446,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark54(69.81516210401085,-0.3339810139330335,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark54(69.82759042065528,-1.0172963757344725E-7,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark54(69.83811399392481,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark54(6.996317140566375,-1.295671350734421,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark54(-6.997247458412377,-1.3157958573357702,-1.0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark54(69.98138537411506,-0.7520088275256338,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark54(6.998157310357062,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark54(70.05464465256557,-0.2584194554802888,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark54(7.006685617047111,-1.100354255402344,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark54(70.11610972849064,-1.0082475443456769,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark54(7.013992464510437,-0.6443925516837705,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark54(70.19599324206982,-2.5454358423208595E-7,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark54(70.19795249329533,-0.7168284012616302,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark54(70.20788259927681,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark54(70.21061888798371,-0.3979690908173026,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark54(70.226156015584,-1.1911606528302912,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark54(7.024675288528101,-1.1553024678306527,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark54(70.31670801039974,-0.7831050535390673,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark54(70.32257724770997,-0.3872612520075669,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark54(70.34262805679725,-0.22015415050193293,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark54(70.34265928381146,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark54(70.39657413786111,-0.014510007069333142,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark54(-70.50551797094215,-1.7763568394002505E-15,-1.056609595027343 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark54(70.57654017173198,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark54(70.58653194170802,-0.6643756251262519,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark54(70.58752619326262,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark54(70.60813604628878,-1.2362042828618507,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark54(70.61429853597195,-1.3708124122262575,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark54(70.63954063910361,-0.03340133877758067,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark54(70.65015213311025,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark54(70.67098266043797,-1.499999999999912,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark54(70.68973589430358,-2.5791084430724173E-6,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark54(70.7286964491786,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark54(70.7565054512958,-0.9870544975896394,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark54(70.7583400410165,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark54(70.79578484732045,-0.3730002210841499,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark54(70.8198402404023,-0.676873212279085,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark54(70.82134994619565,-1.0411051354605352,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark54(70.83231317744739,-0.03255862887210981,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark54(70.9336744243268,-1.255849446733643,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark54(70.97420456393212,-1.2123721778707193,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark54(70.9980283138926,-0.38059722867747614,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark54(71.00436868779525,-0.6928364050987375,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark54(71.00730239422407,-1.1541794750874392,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark54(71.01767765020477,-0.46417087764535836,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark54(71.02467174063966,-0.06646130200496714,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-0.10312938074331557,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-0.4520334686747165,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark54(71.07300739688242,-0.6243014458670189,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark54(71.15648417922253,-0.5850789941224988,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark54(71.23674548720209,-1.217263825999371,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark54(71.29594095552838,-1.3877787807814457E-17,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark54(71.32384096687409,-1.2447130564718152,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark54(71.33771872840825,-0.9279640134464131,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark54(7.139659467972907,-0.2224692445285541,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark54(71.40889660648051,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark54(71.51153818905439,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark54(71.52396700088053,-1.4405900231563051,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark54(71.5601221527341,-0.7229155898747476,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark54(71.57430819763084,-0.5680659277879982,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark54(71.60203231651349,-0.10915848786614327,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark54(71.60487905030683,-1.0672851347962364,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark54(71.64430536019941,-1.1760181539068455,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark54(71.66246483520621,-0.8817120748669032,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark54(71.69873167652253,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark54(71.74784947524137,-0.9292935155884976,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark54(71.82536004623,-0.6950364266355373,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark54(71.84177009223544,-0.1943156761872642,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark54(7.192064602150779,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark54(-72.02488066330633,-1.1868533336896913E-5,-0.06255254492318967 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark54(72.056415686051,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark54(7.205998110549399,-0.1964354923228196,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark54(7.208071411847456,-0.8679341164383949,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark54(72.13774043711351,-0.36978551003203464,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark54(72.16713330038661,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark54(72.18088061037423,-0.8739248268486222,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark54(7.2194309287660445,-1.3628598640246743,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark54(72.21334360763856,-0.7774300684269235,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark54(72.21763600913906,-0.5290231548424904,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark54(72.2593202698732,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark54(72.26671456826584,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark54(72.27403273035634,-0.2496900687623992,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark54(72.2793785506673,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark54(72.28576389517433,-0.2974566665787808,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark54(72.30319047345921,-1.283831874946587,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark54(72.38027599536821,-4.169169656149842E-9,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark54(72.39010382390016,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark54(72.40033350667454,-0.42311081069448164,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark54(72.43499120792208,-1.2114413862037234,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark54(72.47207904447401,-0.031248045694610482,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark54(-72.52190161888022,-2.747082918389059E-8,14.236898305394957 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark54(7.257322781189778,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark54(-72.60994980611018,-1.1901891844308778,4.440892098500626E-16 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark54(72.6326986665243,-1.2823114682648136,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark54(72.65912742971038,-1.2802043920111537,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark54(72.67171447130062,-0.8000497098380359,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark54(72.67275562002038,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark54(72.69722961491301,-1.2626915014413065,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark54(72.7199221047753,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark54(72.73366206162585,-0.2694377096641425,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark54(72.75517331693717,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark54(72.75810617196879,-1.2593417703669951,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark54(72.78236442353281,-1.0559824525617882,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark54(72.7943266647176,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark54(72.87989900892913,-0.43930229245666275,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark54(72.9089223490918,-0.6331538482194823,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark54(72.94955706884102,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark54(-72.98858555354974,-0.0775377754275681,-48.5220058242841 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark54(7.305683996656612,-0.053784238652148986,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark54(-73.10307113610705,-3.165060703124613E-8,2363.6748975273304 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark54(7.310891386585661,-1.4647004168388096,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark54(73.15066587312785,-0.3356926171793484,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark54(73.15594064524237,-1.292607145057757,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark54(73.15742775787112,-0.5443880574523803,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark54(73.19480327128639,-1.0070234573759356,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark54(73.2021467061012,-3.4004609139718623E-7,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark54(73.207957459092,-0.9947678854348254,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark54(73.2126104782219,-1.3918362709597842,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark54(73.24976916727803,-1.003284440449434,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark54(73.25918444311586,-0.48904271893779594,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark54(73.28569507957148,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark54(73.34041070274733,-1.2639329492045839,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark54(73.3558478636788,-4.079018514462185E-6,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark54(-73.45490375881458,-0.6621606427576601,-35.33694849482264 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark54(73.468108340345,-0.18781821235145335,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark54(73.4927754934908,-1.4483439577796544,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark54(73.56601010368306,-0.6295429646827493,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark54(73.60972176107285,-0.9201727169535925,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark54(73.6179280352112,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark54(73.63795380791518,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark54(73.63867623621431,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark54(73.68251452305981,-1.4139697373548785,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark54(73.70305537085363,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark54(73.75433024796033,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark54(73.75624426813891,-1.0641444668976847,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark54(73.78554285892099,-1.017094533956874,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark54(73.82801542303534,-0.9541259075793924,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark54(73.85119611203747,-0.5963989459378408,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark54(73.94543576878755,-1.1753331968616436,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark54(73.95409692814772,-0.5043759943928461,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark54(74.06314297113755,-1.3499256232071946,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark54(74.07108135650961,-0.41436485641196885,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark54(74.09285599471751,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark54(74.11391710552141,-1.1550696577712367,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark54(74.12549403674248,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark54(74.15613101967028,-0.40271332762321976,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark54(74.1624765170732,-0.5157179287987161,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark54(7.416664902672878,-0.2719772800697978,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark54(74.18441424027357,-0.038947961437238665,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark54(7.4190626829299235,-1.7176116817316459E-6,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark54(74.23936629482164,-6.282385616174224E-4,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark54(74.27457295287343,-3.658948473246866E-6,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark54(74.33241020922493,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark54(7.434750646917038,-0.4862769628283381,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark54(74.35379520674789,-0.8842309038712699,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark54(74.39164763662554,-0.33676567553668413,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark54(74.44933032345835,-0.04718481620056991,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark54(74.45746163366962,-0.43957029295468397,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark54(74.49548474185923,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark54(74.5474272359753,-0.7802599996100597,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark54(74.55249847528628,-0.09660231490938731,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark54(74.60033913148237,-0.2666084941476594,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark54(74.60163816388095,-0.8317973534189749,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark54(74.60597864226334,-1.4898203331671742,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark54(74.61079382041638,-5.57546066189987E-10,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark54(74.62560941676725,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark54(74.62824202928567,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark54(74.73139131518214,-0.5440382766574743,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark54(74.78959075867385,-0.49532875538873355,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark54(74.82623082566936,-1.0093064793933953E-5,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark54(74.87506185810584,-1.2056118963880096,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark54(74.88964514256399,-0.49051609133275315,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark54(7.489688749355122,-1.117120398573443,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark54(74.94007242734298,-0.7735796491397053,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark54(74.95644750975269,-0.4743180830119962,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark54(74.99445485468527,-0.36798587376922587,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark54(7.507615824814785,-0.9649498028664445,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark54(75.14225596699023,-0.16663284744143603,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark54(75.22701499427887,-0.8192912159307895,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark54(75.23906224641931,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark54(75.29152782118783,-0.4915622516189827,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark54(75.3832739262895,-1.052436017464832,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark54(7.540897556073965,-1.004850838870584,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark54(75.40908687431781,-0.9241127680571855,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark54(75.43244388045494,-0.9494098580552255,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark54(75.50003941861587,-0.7771377182027095,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark54(75.51630943512856,-0.7790701503249702,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark54(75.52765989415937,-0.8117251376282271,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark54(75.54808539364504,-0.859562422056289,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark54(75.59548941752251,-0.07765115195891958,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark54(75.64536946694074,-1.4869621838443123,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark54(75.70177955672011,-1.0021929168049635,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark54(75.71565605105485,-1.0881116255170014,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark54(75.7793391920037,-1.499999999999968,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark54(75.78408809499177,-0.40723557341064576,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark54(75.83426681353433,-0.42363479119946135,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark54(7.58353821631948,-0.31896793910853916,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark54(75.83549416176169,-0.11056767036204884,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark54(75.9109444658078,-0.3037801764127752,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark54(75.91413369109202,-0.0310422415284472,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark54(75.92586965624434,-1.1200691477952436,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark54(75.97174259918432,-1.3679327129236327,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark54(76.01319218358628,-1.1577097032332704,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark54(76.06224550599805,-3.3491821231784586E-9,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark54(76.07434041678974,-0.9045720209560386,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark54(-76.09816515114905,-59.4410441392905,-15.32027659849146 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark54(76.14782628706638,-0.05415226095379211,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark54(76.16438420403674,-1.2832171000495927,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark54(76.16485887643071,-1.4999999999999867,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark54(76.17353389849308,-0.6533323318168591,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark54(76.19313857608688,-1.3195773500403547,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark54(76.2000657622711,-0.6962233643229938,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark54(76.24111822965105,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark54(76.28333118743859,-1.4718209915342504,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark54(76.28579810585038,-1.0237051911855275,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark54(76.29620132643585,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark54(76.45133721995543,-1.3558180008637706,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark54(76.48852416720581,-0.41162784375640626,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark54(76.49021561870663,-0.6197673012690471,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark54(76.54621546915556,-0.7340169101694585,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark54(76.64561401188766,-0.19252649270447364,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark54(76.66563229938689,-1.0678698254141779,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark54(76.72644159723012,-1.1031714222967963,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark54(7.675383272791564,-0.28777561753975434,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark54(76.75564915517637,-0.7641227057253115,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark54(76.75783038538009,-0.4515375884347822,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark54(76.81503182245339,-3.9166409427063864E-8,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark54(76.83746260523313,-1.4999999999998406,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark54(76.86744101875385,-0.9537552945514669,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark54(76.95566830835025,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark54(76.9728972047782,-1.1748032328657345,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark54(76.97936984515329,-1.4548671056085665,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark54(77.01867312030112,-1.0442341897999938,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark54(77.06014513185681,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark54(77.06509059559454,-0.6494579043066522,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark54(77.07054385589979,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark54(77.13163337360939,-0.6556074422214238,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark54(77.15914435077667,-0.06198383014348963,60.331152000459355 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark54(77.16464301313425,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark54(77.18271784325476,-5.33571159126505E-10,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark54(77.23880824624968,-0.18837106687779226,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark54(77.25805332229467,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark54(77.28300462027129,-0.7770501783839601,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark54(77.40949984179338,-3.460328085833719E-15,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark54(77.45136227236483,-0.903307085654518,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark54(77.4783268073596,-0.3879313019522934,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark54(7.753795584563388,-1.474852478311006,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark54(77.54509858957371,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark54(77.55490009078727,-0.940075865229133,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark54(77.57058513838248,-0.6822945099538984,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark54(7.769890905402718,-0.25971539316141445,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark54(77.71800250792151,-1.4390792396013605,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark54(77.7511556700806,-1.6738184502308322E-8,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark54(77.77407243981881,-0.26009527069984095,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark54(77.78948609171037,-0.35442497443889875,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark54(77.81641494811392,-0.5727842224466588,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark54(-77.82813403281241,-0.5752698265671601,0.7135461910327656 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark54(77.86341823120574,-0.09783939070105596,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark54(77.88031620464778,-1.0859000764438278,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark54(77.89075609822302,-0.19971706775760367,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark54(77.93603070162399,-0.1815125060658005,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark54(7.795738788731702,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark54(77.9579477069468,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark54(77.96619709701832,-0.7148779955333566,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark54(77.99756336322224,-0.0020438539229745423,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark54(7.799784468135002,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark54(7.81522672627537,-1.3351621675086123,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark54(78.1562673776429,-1.4344374271800078,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark54(78.159515673132,-0.41965230607171267,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark54(78.18364900683673,-0.044709108781270324,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark54(78.20759025332143,-1.0290619570857782,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark54(78.25602460036356,-1.0773250531432472,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark54(78.27146247585512,-0.8797470700452639,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark54(78.28200931509815,-0.6250469202371782,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark54(78.28263007569936,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark54(78.4098952358971,-0.8274323830779053,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark54(78.46692977204339,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark54(78.48541506763357,-1.2108685784128603,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark54(7.8491383823524785,-0.9786945342587696,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark54(78.53080194439403,-0.755183686725232,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark54(78.55704886377671,-1.033428234188369,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark54(78.58315141147773,-0.1747332312394554,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark54(78.60559619996704,-1.0355270824981062,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark54(78.67232530321067,-0.12399544169157081,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark54(78.68003976371679,-0.7858658636202449,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark54(78.68832355441752,-0.7458342519708197,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark54(78.87753027164015,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark54(78.96633198713707,-1.2733674328265323,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark54(78.97878961135126,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark54(7.8993150769028055,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark54(78.99328984841597,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark54(79.03912951022969,-0.43889772151991796,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark54(79.05783950190798,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark54(79.05839258052114,-0.4148827663151202,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark54(79.06293764286696,-0.6898445812038623,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark54(79.0640028219708,-0.0044877613358522694,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark54(79.08947880074393,-0.03910700322389005,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark54(79.16691860008731,-0.06895376620890858,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark54(79.2325919040093,-0.09347306929814181,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark54(79.3062341722603,-0.1094346968107951,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark54(79.3255767533113,-0.6235207522706946,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark54(79.35062250469832,-0.020827016587625202,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark54(-79.36436536512034,55.69462886796609,-2.347429378415214 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark54(7.936640232470671,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark54(79.37348632321722,-0.1799868405595185,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark54(79.40813598621499,-1.3552665537890043,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark54(79.41211956326295,-1.0910548138613343,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark54(79.48483923423697,-0.0465462775010181,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark54(79.4907382423329,-0.8712690188831971,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark54(79.56488687830031,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark54(79.57348796697684,-1.1366633897899732,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark54(79.58640564568324,-0.6007238616398083,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark54(79.60290808239466,-1.306165334317894,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark54(79.72015696144013,-1.2480394978489826,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark54(79.78621387623062,-0.0892480423432418,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark54(79.85765851223974,-1.4999999999999325,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark54(79.87507469830342,-0.6287852985169184,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark54(79.88390495245494,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark54(79.94511754603323,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark54(79.95693390519617,-0.9243458879157395,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark54(79.95805159888849,-1.15777381177787,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark54(80.00843153312206,-0.97324189348272,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark54(80.0365113438175,-0.9121123780998346,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark54(80.07913825505054,-0.3064464500126576,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark54(80.14796404230299,-0.6952828918723446,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark54(80.19092603930083,-0.06934231231361729,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark54(80.19736940584292,-1.2453658832426413,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark54(80.20151153953549,-0.3475226212511018,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark54(80.26010579226204,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark54(80.32102300385247,-0.3254475591281858,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark54(80.33235863195486,-0.9591253569021845,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark54(80.35819803664336,-0.2145374338251438,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark54(80.43607743110749,-0.033809272507539845,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark54(80.4765742949129,-1.1323298715349566,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark54(80.4971156871901,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark54(80.52140472090355,-0.9885515431250553,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark54(80.55709647953061,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark54(80.57233775924146,-0.4987545520245096,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark54(80.65497731643458,-0.11698172762215919,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark54(80.66168161554756,-0.7546919612885006,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark54(80.67661119866469,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark54(80.70724812836278,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark54(-80.74533883051978,-1.499999925172189,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark54(80.75730679854266,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark54(80.75793630526582,-1.4589989280057152,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark54(8.077935669463161E-28,-1.8379455313622275E-9,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark54(80.8016123299679,-0.7048846009745944,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark54(8.083276852524914,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark54(80.8948751618963,-0.44002744688781414,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark54(80.91828121429283,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark54(80.9759157507468,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark54(80.98128436791207,-1.434812283768408E-4,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark54(81.02425859831351,-0.6293429318870594,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark54(8.108813826794993,-1.3877787807814457E-17,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark54(81.09409724325093,-1.4051031471329765,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark54(81.13357713922062,-0.6784319786625801,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark54(8.12234711072459,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark54(8.122821353850412,-1.4508389345145147,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark54(8.12326909633994,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark54(81.27920040015539,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark54(81.30829138624804,-0.4943421290350756,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark54(81.33973770727434,-1.1243201005948205,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark54(8.139748282781547,-0.31244478722036106,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark54(8.142481527572507,-1.3480857686075898,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark54(81.4465364033117,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark54(81.46136417572225,-0.4319263430582332,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark54(81.47956565260026,-0.18280007228503514,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark54(81.57516212529805,-0.3382972754639013,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark54(81.59497235959971,-1.4654265793277577,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark54(81.59899743542093,-0.7466486963932779,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark54(81.61220050065909,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark54(81.66698820760575,-1.1729739734647353,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark54(82.11790254054222,-0.023238714811105177,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark54(82.1306837362618,-0.6673144727955815,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark54(82.1391907396584,-1.0217808239811754,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark54(82.171066613706,-0.5780571980232692,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark54(82.21645992070819,-0.022307566094042386,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark54(82.22592104800592,-0.31824378746783655,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark54(82.33173406999944,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark54(82.3961729592574,-0.01576382060978576,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark54(-82.4227820360023,-1.4702027350815678,29.354852789283107 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark54(82.43171502834969,-0.9314973857347377,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark54(82.43781629508614,-1.0827420538896087E-8,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark54(82.53101750179856,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark54(82.59155873895367,-0.3009843665680876,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark54(82.68992748300792,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark54(82.73447523334372,-0.7485677986376831,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark54(82.75935018902446,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark54(82.78500136236812,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark54(82.7957171936695,-1.3229444671097834,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark54(82.81806189747155,-0.6744048414710733,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark54(82.85913522024893,-0.8984088939692987,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark54(82.87343044675421,-1.2368232555283214,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark54(82.8797112495416,-0.44376357210865347,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark54(82.93147836863493,-0.4086782562248467,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark54(82.94433759677545,-1.390318067869301,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark54(82.9467028102394,-0.01832787007491765,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark54(83.00689735484525,-1.2631981273929611,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark54(83.02787833973572,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark54(83.03436039791151,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark54(-83.04684772625927,-0.12756532531493292,1.0000000000000002 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark54(83.11957984970022,-0.3987182325108307,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark54(83.14256521354855,-0.1425077830264172,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark54(83.26792963084156,-1.4643400655910224,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark54(8.328246969033827,-0.40666437775918496,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark54(83.34533744375591,-0.8340450970127758,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark54(83.36775445448157,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark54(-83.56289945719035,-0.0758968490942025,-1.0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark54(-83.59424406294256,-1.4999999999999996,-1.0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark54(83.61918813616433,-0.8325987178587297,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark54(83.68055159082942,-0.20485863054466336,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark54(83.68762100266574,-1.3054573466009904,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark54(83.7308714909729,-1.2367388658528329,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark54(8.37485067716803,-0.2968880214642411,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark54(83.83435569582682,-0.11017927040821718,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark54(83.84394509254741,-1.0973592631397224,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark54(83.91522145801964,-0.04557291028455059,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark54(83.93351501014357,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark54(83.94716948692886,-0.2901639361452445,0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark54(8.401557960678016,-0.9423065799715225,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark54(84.01988476100735,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark54(-8.403958745916427,-0.7314749819898676,-69.10013182278537 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark54(84.13076656517057,-1.4334915062124631,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark54(84.18828160615706,-1.1761603925320978E-6,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark54(84.19673242531063,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark54(84.22060817918148,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark54(8.424018399163314,-0.5087304363610823,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark54(84.41624185748798,-0.056804641536202787,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark54(84.41698003092034,-0.9259653558870133,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark54(84.44855483234248,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark54(84.50475431729578,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark54(8.453134838628145,-1.235134982679961,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark54(8.453227933797208,-1.168779000554295,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark54(84.5376642427129,-0.8202148722477176,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark54(84.65927966219041,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark54(8.4669440504005,-0.06445537512562001,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark54(84.72905103722965,-0.8711776894437939,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark54(8.474822835941639,-0.7223141016046526,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark54(84.78714631242143,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark54(84.80607064358722,-0.6105023785969408,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark54(84.83417674038604,-0.1930933967197055,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark54(84.87746226195071,-0.7891930544797816,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark54(84.90122954694985,-0.5516003304378355,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark54(84.91209624582066,-0.0791589235769018,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark54(84.95635101930458,-0.10668628443544392,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark54(84.99756399918923,-1.2352140000261542,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark54(85.00142106436937,-0.3223603490151028,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark54(85.02075750109478,-1.2181408522904462,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark54(85.03417501679351,-1.1675767414590812,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark54(85.05987451598489,-1.0609241983422637,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark54(85.06271020054949,-1.2440754135115952,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark54(85.08054197078572,-0.18691892811536984,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark54(85.12355262397841,-0.5068068794412,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark54(85.14092077268776,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark54(85.16140744474464,-1.4731872689618644,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark54(85.18781139524134,-0.26186096797717656,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark54(8.519136628193323,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark54(85.34166139781439,-0.6538062010503154,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark54(85.36595732037324,-3.184025293272828E-4,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark54(85.36946272596523,-1.410835532361446,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark54(8.538867294314997,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark54(8.556322134547997,-1.1742150373397149,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark54(85.5769598906445,-0.6718566606302563,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark54(8.560467535065149,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark54(85.63696643276091,-0.7707034854700192,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark54(85.64480963994947,-0.25782166908548554,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark54(-85.67412288310217,-0.15591180682749028,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark54(85.68838686232459,-0.37155560205142013,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark54(-85.76733634406231,-1.4980544546833137,-1.0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark54(-8.580195410585887,-1.4999999999999998,-100.0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark54(85.86941455952154,-0.3717745691639305,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark54(-85.87454003438886,-0.8284587294438062,59.703138122037245 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark54(85.94525185671043,-0.41659766386885044,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark54(-85.98329916312017,-0.1996083684313998,-0.6984112621480645 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark54(85.99436500800067,-6.723158239948885E-4,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark54(8.605016753483294,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark54(86.07895924276221,-0.34775282057762524,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark54(86.08894121079739,-1.3222415722736622,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark54(86.22974318309565,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark54(86.25956528810812,-0.20897916669277006,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark54(86.25977816457171,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark54(86.27041459040018,-0.17196675891022295,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark54(86.33804168286076,-1.3467008207705078,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark54(86.3854650933701,-0.8875452404590023,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark54(86.45566099607285,-0.9971766956659103,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark54(86.45623562527572,-0.03860311685381479,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark54(86.48874980111003,-1.027963168382783,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark54(86.49867867276683,-0.29082478345275464,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark54(8.65037632349948,-0.7555251234066949,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark54(86.51521683473624,-0.48513804376413994,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark54(86.5794196004787,-1.2393447188802544,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark54(86.58465501977622,-1.322306118434529,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark54(-86.59662687169372,-6.167820709027466E-4,-0.42313471212588727 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark54(86.62148768064765,-0.18756021535121614,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark54(86.70652766880801,-0.26029724507283447,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark54(-8.672057639232264,-0.8278283723582831,-1.0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark54(86.84914140433446,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark54(86.85413792393092,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark54(86.96172355645584,-1.013002117715497,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark54(8.710182958860909,-1.0725515339250555,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark54(87.12731231812961,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark54(87.1735258254468,-0.39631834627782325,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark54(87.19393814537057,-0.5001501489826126,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark54(87.20198833671262,-2.1498891939033425E-8,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark54(8.7212577445448,-1.4617061319113107,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark54(87.2703883406098,-0.9206341089790016,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark54(87.27623473983014,-1.138369472609074,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark54(87.32141206057892,-1.465402415975305,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark54(87.3504349163372,-0.7916173764842427,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark54(8.739247162778383,97.6689676696779,95.28155150400133 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark54(-87.40107144932188,-4.663654963827348E-10,85.88576306179718 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark54(87.42756862943182,-0.7249474212743605,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark54(87.46512053887895,17.012504679334953,-22.549662693498135 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark54(8.748966778332985,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark54(87.51501557631741,-0.7497923327743496,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark54(87.51862496023693,-0.5728222678529278,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark54(87.57310914267927,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark54(87.5951018636776,-1.4655761292395082,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark54(87.59729634388769,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark54(87.71459270103088,-0.42727195426909903,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark54(87.72546898215023,-0.4032893196146574,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark54(87.89429304190571,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark54(87.90791139825205,-0.4404398562842857,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark54(8.795587201574595,-0.06798280658014733,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark54(87.97901011794792,-0.37137703396142285,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark54(88.05475132832731,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark54(88.05717966319766,-0.0027990933077135355,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark54(88.10543356224255,-0.990727678238386,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark54(88.12007306881705,-1.4249355575407994,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark54(88.19070491356476,-0.1259883432291673,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark54(88.232678237942,-0.6374894647991836,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark54(88.23915920000857,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark54(88.2718415698507,-0.07035740338893959,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark54(-88.29859430573512,-0.33025077160249816,9.790634727829655 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark54(8.833274749454304,-7.600439263555037E-9,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark54(88.4021624175199,-1.194201749107822,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark54(88.42720358417583,-0.9902717102636558,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark54(88.50707864715636,-1.1358019529969658,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark54(88.52040912155644,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark54(88.55490296436557,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark54(88.57533369047184,-0.062182218260858235,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark54(8.881784197001252E-16,-0.20420762883042087,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark54(8.881784197001252E-16,-0.22509272680735737,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark54(8.881784197001252E-16,-0.592728763197107,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark54(8.881784197001252E-16,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark54(88.87301060914741,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark54(88.87858717864302,-0.2516053882236882,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark54(8.89018496050599,-0.07750289536854221,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark54(88.93072509034046,-0.24903996629326725,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark54(89.00180773305853,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark54(89.07706487393071,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark54(89.124197821222,-1.001381876100254,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark54(89.17278978259581,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark54(89.1988812947535,-1.2320723275098762,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark54(89.23246014482947,-1.1835206576259907,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark54(8.925127902110091,-0.7318737924396435,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark54(89.35162033691441,-1.0303583489921806,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark54(89.37634944208,-1.3875795956902748,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark54(8.938178079460329,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark54(89.43330216086457,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark54(89.47366826417897,-1.3243840800773086,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark54(89.4842310155747,-0.9798385091565027,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark54(89.49243787874201,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark54(89.49390712382035,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark54(89.49789263106794,-0.5649397236552494,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark54(89.52269922188509,-0.3090925468159522,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark54(89.57296087407107,-0.020458916588168563,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark54(89.61134971342454,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark54(89.71551473199705,-0.7642498488872136,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark54(89.7188918750924,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark54(89.74899886629083,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark54(89.78584801681436,-0.5567428639622847,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark54(89.83150139180384,-0.5614223333296025,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark54(89.84084279948468,-0.08362119852547867,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark54(-89.8412687786886,-0.017862293906865955,-0.016714598364637817 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark54(89.86033398565492,-0.678500620203117,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark54(89.86794142360549,-0.5674671059195759,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark54(8.991184057563203,-1.0583255398579794,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark54(89.92737035007826,-0.8100426132493084,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark54(89.97042741064848,-0.8125261538072426,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark54(8.999052735426153,-7.636647034063988E-7,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark54(90.04583688558125,-0.7275586551791952,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark54(90.08428796326903,-0.14030670661281786,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark54(90.13983677887677,-1.0117125097287263,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark54(90.15874560039342,-0.7299676096107923,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark54(90.16081538579846,-0.470542239207212,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark54(90.18673575344786,-0.6175975953048578,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark54(9.026420413578549,-1.2385038333182479,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark54(9.026679709962146,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark54(90.28566099995601,-0.22179082034450914,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark54(9.044745905499871,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark54(90.4718002956865,-0.5752416213400966,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark54(90.52674103995048,-1.0497321820660348,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark54(90.58640058963887,-0.08504481172868861,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark54(90.61994982057692,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark54(-90.64627557516899,-0.8304721577142002,1.0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark54(90.6524438144587,-0.003035308240300516,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark54(9.069675319917806,-0.10264432338438281,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark54(90.73526321272402,-1.360844841121283,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark54(90.82180560950638,-0.02554474862185252,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark54(90.82226051197229,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark54(90.90161301322155,-0.5699759265338393,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark54(90.91115423450074,-1.1006407658149349,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark54(90.9312844361493,-1.0378026527212256,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark54(90.93605082877798,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark54(90.96135828301453,-0.8562549821189513,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark54(91.18218207499281,-1.4899904057886437,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark54(91.19851117741794,-0.891453260106271,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark54(91.24199016722864,-0.06566280660678103,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark54(91.25094828536834,-1.3883635448397342,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark54(-9.128670618322886,-0.9243537014189087,1.0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark54(9.129632174149123,-1.188302670975323,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark54(91.31900757430179,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark54(91.32262403423137,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark54(91.36215814381649,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark54(91.37902699841197,-1.499999999999126,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark54(91.43044188660217,-0.8361114337847276,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark54(-91.46992198949397,-0.21796957366604797,-7.9352603693363974 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark54(91.52215691813421,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark54(91.52862227756086,-0.46484177378327285,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark54(91.60334503268342,-0.674492380996611,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark54(91.6990538449792,-1.07501472335588,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark54(91.75666513195523,-0.23505725904644237,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark54(91.76832645953198,-1.4976888462957518,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark54(91.77629154189373,-0.23173487620967137,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark54(91.79084131316318,-0.49472306474737593,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark54(91.85783487408207,-1.4541774865729633,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark54(91.92526594846689,-0.7397175622430443,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark54(92.01830467965095,-0.7848078307086344,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark54(92.02006073749013,-0.6978093691120779,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark54(92.03155174426297,-1.097169741163114,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark54(92.05195922891326,-0.48728318919423863,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark54(92.08072510253993,-0.3239050198222342,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark54(92.10711535242976,-0.7308020731310911,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark54(92.11893435645845,-1.190038465343699,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark54(92.15874955259312,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark54(92.17419721241637,-0.2331826468149032,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark54(92.2059951218152,-0.3132302474903814,0 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark54(92.25439904112034,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark54(92.3410777795259,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark54(92.42826441295762,-0.8336538900192134,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark54(92.46429662142293,-0.847774946798258,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark54(92.49027904236684,-0.7699162201932402,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark54(92.49349267503325,-0.04151288550664911,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark54(92.54912718794299,-0.8280761672017718,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark54(92.64643987580067,-0.5112861754946767,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark54(92.6738067308724,-0.5259326054262187,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark54(92.67544626629024,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark54(92.67686030471384,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark54(92.71595123544711,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark54(92.82386556601128,-0.09684906488623164,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark54(92.83038530592901,-0.05625936363732564,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark54(93.0397385287583,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark54(-93.05957637108963,-0.7831659742768653,23.26975517906685 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark54(9.306138812176385,-0.7837417493635858,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark54(93.06465831105051,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark54(93.10110687603549,-0.18620492549442247,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark54(93.12382657969317,-0.966372479201572,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark54(93.12570560310135,-0.6528280424448809,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark54(93.15606831465539,-0.37098097105555716,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark54(93.18322477342883,-0.015402920523399422,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark54(93.21423888965802,-0.03750529393993042,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark54(93.24479893438041,-0.2567940263210349,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark54(93.40813516730853,-0.04080919864357213,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark54(93.41985716427655,-0.968023517992151,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark54(93.50368632744353,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark54(93.50844750282266,-1.2269415423001688,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark54(93.51450966815338,-0.13439650744469134,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark54(93.55855613994487,-1.3170483116836316,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark54(9.363601756171718,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark54(93.6454165423128,-1.1288219966389215,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark54(93.67139396225355,-0.23491631351127928,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark54(93.69844879266803,-1.3743025021488773,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark54(93.70605778093523,-0.2845659959943845,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark54(-93.718967977195,-38.79027646763093,-16.178786034079067 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark54(93.74539608998488,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark54(-9.374953815190342,-1.098951358015832,-0.01421626395459992 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark54(93.79547814988594,-0.187447928593845,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark54(93.80005421210203,-0.5519276084625138,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark54(93.83606827768999,-1.3178089802905848,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark54(93.8711414824605,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark54(94.03655038188725,-1.3849247469719792,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark54(94.07512476096552,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark54(94.12518896941523,-1.0051799559877423,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark54(94.14492097887495,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark54(94.1516251473819,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark54(94.15245622958167,-0.13084125408111902,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark54(94.20263307173187,-0.3717319105538365,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark54(94.2222744998636,-1.2318918441872597,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark54(94.24280183119825,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark54(94.31889077894544,-1.0084494203007361,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark54(94.33132141599586,-0.5688988194289242,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark54(9.433580987442339,-1.01403022585554,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark54(9.4366093808177,-0.7112899872638763,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark54(94.37434105830059,-0.719333879749128,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark54(-9.445614114331676,-1.3463771330873087,0.5404019700477668 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark54(94.48226917823504,-0.9024617362793084,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark54(94.50879426559987,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark54(9.460318007560645,-0.33861218735943055,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark54(94.7163077343809,-0.5821727673602537,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark54(9.473199099254789,-1.2349358005482076,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark54(94.77964306227763,-9.222628389149056E-8,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark54(94.80991566165972,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark54(94.93362795760643,-0.48408286655399024,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark54(94.96183134597709,-0.8235631114190198,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark54(95.14908308444262,-0.6307665998232799,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark54(95.15225925761442,-1.207323659306584,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark54(95.20364757374946,-1.0843206806043333,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark54(95.31230752971547,-1.248804992588319,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark54(95.36893054190932,-1.3120184204364023,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark54(95.37347467997492,-0.08523376064921084,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark54(95.41740260036994,-0.589344953338955,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark54(95.44505517962573,-1.1708446158043806E-5,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark54(95.46809086415846,-0.9259921114229357,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark54(95.47812560746341,-0.9745853932070379,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark54(95.48400147936246,-1.1978786357265037,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark54(95.48471651739672,-0.7409230252415568,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark54(95.51832764751425,-1.147783739354896,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark54(95.52983070781816,-1.3575373001347186,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark54(95.69469754064326,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark54(95.86488664691962,-0.49497884026180095,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark54(95.88976903158911,-0.657703947492559,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark54(95.98803377588561,-0.07289653384788153,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark54(96.10824383316677,-0.9823856363326375,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark54(96.11288704688363,-0.7531743931593979,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark54(96.22846348626533,-1.374260487692862,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark54(96.24011516959165,-0.8748226339045959,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark54(96.25871451166816,-0.2408099795863446,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark54(96.30956077631538,-1.2741165340594023,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark54(9.634055612108156,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark54(96.34670070926629,-1.4223064072707192,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark54(96.36673679238126,-0.42899010666996107,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark54(96.37752033025353,-0.8186159378743945,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark54(96.38644061281306,-1.1981875010147744,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark54(96.40838850113084,-0.34962687277763793,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark54(96.4453804666154,-0.5484106416163179,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark54(96.45808914433783,-0.6863222543360674,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark54(96.50218143106062,-0.46441114715598886,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark54(96.51217761186624,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark54(96.55261302229287,-0.15538020584662426,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark54(96.59149881011754,-1.4402733217261385,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark54(96.62034773926791,-0.19510485382744847,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark54(96.65416241470487,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark54(96.6851620932062,-1.3890336779220105,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark54(96.77495414051813,-0.8663660831071534,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark54(96.8115002228551,-1.0018775912536313,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark54(96.86493411615413,-0.04085243964365404,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark54(96.8678794969226,-1.4084574343963558,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark54(96.8795597878339,-0.7278542875485332,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark54(96.96597627508368,-0.7888983103455587,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark54(97.02935732827115,-3.3419965209660086E-8,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark54(97.0428312469196,-0.24188521767596693,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark54(97.09594619853917,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark54(97.20031137355761,-0.07492473128881727,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark54(97.24587845142443,-1.499999999999992,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark54(9.727494256580279,-7.025690193432454E-10,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark54(97.3352435333525,-0.3601562316091247,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark54(97.40487995949397,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark54(97.42321679916685,-1.2121672578653246,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark54(97.45776980362069,-0.3775223005970415,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark54(97.53937781395474,-0.3416283984521913,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark54(97.58193634657815,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark54(97.67318208127372,-0.8871050363096487,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark54(97.71263614207436,-1.0488690210482252,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark54(97.76104539270514,-1.054400223618447,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark54(97.83116463456928,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark54(97.8806780945289,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark54(97.88604927369886,-1.3760187467280888E-6,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark54(97.94047495969718,-1.2354826512223362,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark54(98.04182712902167,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark54(9.805265684010763,-1.4150951566710006,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark54(98.05887118631293,-0.007010716555015506,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark54(98.06421665194623,-1.4173840108150259E-8,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark54(98.07042662661439,-0.6413717499896148,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark54(9.807080859467348,-0.0940131392356488,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark54(98.11520154578498,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark54(98.2008320410014,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark54(98.20457613080112,-0.8837202758542186,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark54(98.23177158337711,-1.2542356310590606,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark54(98.23772598694356,-0.633369091460871,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark54(98.25171019254431,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark54(98.29398993455186,37.49821134098633,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark54(98.3183607141838,-0.37221812941842813,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark54(98.40116984716195,-0.9899780377254748,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark54(98.44006926936513,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark54(98.45443968279668,-0.7010301903868452,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark54(98.50306649970824,-1.1375939209877854,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark54(98.52667836391012,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark54(98.54360163913944,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark54(9.854690639447938,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark54(98.64408467694744,-0.44103142407752216,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark54(98.6858848948234,-1.2823534399556085,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark54(98.70638728981851,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark54(98.71956359998543,-0.8930701051637637,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark54(98.8376715288966,-1.1615693457142555,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark54(98.87968996988687,-0.45550887364728526,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark54(98.90923922162739,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark54(98.98971726458404,-0.036984468900172374,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark54(-99.06577941635642,-1.4485416910918034,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark54(99.17821138930435,-0.15834724844641812,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark54(99.2499507304417,-1.413263630934793,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark54(99.32514793798083,-0.15106089871405906,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark54(99.33930037516458,-0.5696512115324381,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark54(99.34214436041208,-1.4538539206859764,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark54(99.40054969797555,-1.03920900419519,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark54(99.46624813177928,-3.3553543628595987E-7,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark54(99.53555265988811,-0.5291481294166687,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark54(99.69880180653395,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark54(99.73286972830243,-0.548768665766923,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark54(99.79351879120287,-0.5783250133114564,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark54(99.83965457315759,-1.0320640444985933,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark54(99.88055557870021,-0.6477104075763105,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark54(99.94454662923931,-8.881784197001252E-16,0 ) ;
  }
}
