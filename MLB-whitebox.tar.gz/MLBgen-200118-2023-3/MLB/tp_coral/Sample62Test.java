import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,0.6165493751751683 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,40.51238820988149 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.44281899735502084,1.0440487148797639E-53,-44.27507357202829,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-7.2132645451451045E-130,42.64096793234276,-100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(100.0,8.881784197001252E-16,-74.94737431783449,-17.835965561806848 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(1.1576107925607717,100.0,100.0,1.1577053601733034 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(12.355641277387804,-1.7105694144590052E-49,100.0,-100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(12.37945154865217,84.02378540890967,-17.814202478080077,87.76085006496677 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(1.2822481307357712,26.77155714350843,26.772882803903144,1.2835737766215805 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(13.795115052560623,2.3884732630153787,-40.425741052153526,56.609329367729636 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(14.467823377733097,-2.1684043449710089E-19,66.62172923925036,-38.20780600557936 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(1.687706587471908,14.243985424139893,18.5046124264049,-49.96489448227954 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(1.7667940789789753,44.91620736682239,-24.819797304262224,71.50279875006359 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(21.837430677196835,55.89119960589352,-49.77939569148309,72.11791618417215 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(-23.336220733761095,91.26207768755287,-26.516640878972026,-27.423150022468363 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(25.265198292588643,8.552847072295026E-50,-98.33012933018023,16.807477694350922 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(25.560062509973115,2.0590230357872116E-84,-95.89627905426642,64.04780223049481 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(26.200310764995105,1.3363823550460978E-51,-100.0,100.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(28.731244144168585,83.09853518688658,74.0953238681459,-28.127771283236896 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(29.611437504826938,-40.68945111198063,87.31853515230537,-0.7277423679993591 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(29.664142108854406,77.29548436354435,3.605045707229195,39.94420103977191 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(32.514949670252946,50.699211357063746,-49.997616990210744,85.90993127856504 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(3.3184332419594824,24.230428085593132,54.78380624543044,19.364681141149816 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(33.63368649968881,1.3363823550460978E-51,-100.0,-99.99285836750487 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark62(35.28573624107639,8.881784197001252E-16,-12.458597909775813,-22.210982352782494 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark62(37.68773925515229,-2.7369110631344083E-48,25.642586814592022,-90.9166532549693 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark62(45.31783570525794,0.0,68.25964172201861,-64.1604975984491 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark62(45.88957248298665,-2.0880974297595278E-53,100.0,-100.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark62(48.395539295469575,-5.551115123125783E-17,99.38657941722232,92.91652387690016 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark62(50.86732007861593,-18.56645491909383,96.95310356921698,-2.739743278955416 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark62(5.305505337723432,-2.1935831505361265,45.74642142806255,-24.94806169696875 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark62(59.619020012313854,-49.82216262480274,-75.89347740503831,86.35358441645297 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark62(61.06334746572524,-2.4728041004554673E-68,26.292922437219918,-100.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark62(64.21852988563344,2.0869605423565503,-26.605100987135827,-56.293503815874104 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark62(64.92403691673363,-22.973072034731885,64.0356657130585,62.76638664114938 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark62(-64.97402191118309,9.04987822005738,64.03461140539613,68.98381881634836 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark62(65.23939239510459,-3.247676393264907,48.48355943796504,13.508156563874635 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark62(72.42591937013182,2.323248153167585,-42.929373571211244,-87.95962067820157 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark62(77.68551985330708,-45.251009111625386,69.79019368055225,20.121153856796624 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark62(78.54886182428675,-4.440892098500626E-16,9.007628602376073,48.100144579544356 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark62(83.76106760245798,-39.8875473925341,39.94650827340902,-52.33021521043453 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark62(8.622433672679705,-8.341693648178179,19.116720397553028,68.0940326606302 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark62(87.9187472741906,-74.53946100733972,-25.58728294992632,64.98236263708154 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark62(88.60661614701334,-19.972273625761645,48.09487665760105,34.68905096252362 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark62(93.20031276737652,1.7763568394002505E-15,-77.79372584951855,53.99255170350358 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark62(93.90720652870525,-48.35584944544424,83.0697994502363,-8.668043656287793 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark62(98.92034270365295,-3.014242823392571,14.478032814775048,9.538536738548501 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark62(99.32441107482421,49.953578661057264,88.10103278319863,70.92626682467485 ) ;
  }
}
