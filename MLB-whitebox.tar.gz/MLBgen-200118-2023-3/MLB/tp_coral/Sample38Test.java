import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(0,0.28081302866551994 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(0,-41.060204685541855 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(0,96.28762865092963 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,-100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,-8.9E-323 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark38(-1.1102230246251565E-16,-100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark38(-12.791196924654756,-99.26501621380177 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark38(-12.825557963728182,-205.03661388993802 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark38(13.126360943761654,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark38(-13.574705116124264,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark38(-15.054557290137268,-15.054557290137268 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark38(-16.132054821234632,-84.28755880709151 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark38(-1.6791579977426891,-26.843968193609687 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark38(-17.282613274642372,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark38(-1.7763568394002505E-15,-65.39136993664339 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark38(-1.7763568394002505E-15,-89.86601860771124 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark38(-1.7763568394002505E-15,-92.31845601880468 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark38(-17.828561473167355,-89.50618069050564 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark38(-1.8692877607267915E-306,-84.0101443635171 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark38(-2.0107646833859488E-87,-5.8774717541114375E-39 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark38(-2.0522684006491881E-289,-100.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark38(-2.220446049250313E-16,-42.20099107623253 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark38(-2.2250738585072014E-306,-100.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark38(-2.2250738585072064E-306,-100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark38(-2.2250738585072457E-306,-100.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark38(-25.202582385950123,-81.81138774355396 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark38(-2554.12854823897,-0.06452188935706893 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark38(-25.666904129020594,-97.90679379327291 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark38(2.6270248420839266,-24.238762641803262 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark38(-2.8421709430404007E-14,-71.64949643765382 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark38(-33.764740475520455,62.0129357570529 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark38(-3.519323781500219,-77.88765635720142 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark38(-39.080585659868184,-95.34062609335996 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark38(-39.21193355889563,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark38(-4.0E-323,-100.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark38(-42.15872049431142,-90.2298552206146 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark38(-42.43810358083915,-61.74652349423988 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark38(-4.37403381741639E-309,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark38(-46.08866697955107,-96.69552982149713 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark38(-4.610895139348343,-73.7123740774413 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark38(-47.429850640975936,-93.87254484416016 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark38(-49.478178783687746,-53.95828272189962 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark38(-5.211134978472543,-97.98514688858604 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark38(-52.28492791396493,-1.7843831882780279 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark38(53.149110742582565,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark38(-53.674055264903586,-91.10689702364665 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark38(-5.551115123125783E-17,-9.69925516523351 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark38(-56.94187762057397,-56.94187762057397 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark38(-57.03148957753547,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark38(-58.700007084143046,-59.526442135059355 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark38(-5.883820322425166,-22.368650248791596 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark38(-5.897504706808832E-13,-49.248064111111646 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark38(-61.264261553357244,-41.13382021902019 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark38(-61.6738790787259,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark38(-6.5174605898538545,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark38(-66.32819960904084,-2.7153514539772488 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark38(-66.69007636731585,-66.69007636731585 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark38(-66.84621954398196,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark38(67.43655672689229,-30.18066964118114 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark38(-6.747006683667535E-80,-2.5849394142282115E-26 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark38(-68.33284136804754,-87.54782123668627 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark38(-70.59790756362892,-93.13097325132327 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark38(-72.76953779815629,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark38(-73.54293821985291,-72.0824002664592 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark38(-7.401798170772622,-149.60393845971726 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark38(-75.40244708770476,-35.159368872872236 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark38(-76.6878750135113,-94.17400017895801 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark38(77.0375612478131,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark38(-77.22941215324016,0.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark38(-77.41755278367684,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark38(-78.2787062355686,-70.18097980627766 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark38(-78.57161779994007,-36.34444738706646 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark38(-78.92290901333033,54.53374807817008 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark38(-8.014328794241194,-58.85671323083448 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark38(-82.61319256743542,-82.61319256743542 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark38(-84.85377797263726,-84.85377797263726 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark38(-8.84128568365503,-65.189165523745 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark38(-8.881784197001252E-16,-32.45523322781105 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark38(-8.881784197001252E-16,-7.2911220195563975E-304 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark38(90.26081345241312,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark38(-96.58604629495846,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark38(-97.63664607540896,-69.06742388287401 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark38(-98.8405178659608,-98.84051786596082 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark38(-99.7598134921039,-55.07212204585799 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark38(-99.99999999999999,-100.0 ) ;
  }
}
