import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(0.0030646160514137756 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(-0.47721462894428157 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark34(-11.010876525669786 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark34(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark34(-12.20390175588966 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948948 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948957 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948963 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948966 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948968 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark34(-1.5708145374217695 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark34(-15.806607135640768 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark34(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark34(-22.250703600398268 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark34(2.465190328815662E-32 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark34(-2607.4644315386313 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark34(-2723.263369412577 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark34(-27.409461617266672 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark34(28.727132839205012 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark34(-3.0385816786431356E-64 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark34(-3.1415926535897953 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark34(-3.14159265358996 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark34(-3.1415926535916125 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark34(-3.141592653591789 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark34(3.149405153657443 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark34(-35.05640772541618 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark34(-368.56632997923805 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark34(-40.738172088544864 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark34(-42.604535005614075 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark34(-437.68137884886585 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark34(-47.2586691791352 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark34(-47.42665168599842 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark34(-47.54441888682097 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark34(-47.879615375281844 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark34(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark34(4.930380657631324E-32 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark34(-54.53679205673141 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark34(-54.57099954339297 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark34(-54.593920408495336 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark34(57.451940406671156 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark34(-6.093903467197578 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark34(-61.065158715527026 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark34(-65.57357309521075 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark34(-65.9734457254439 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark34(-66.41712838672376 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark34(-66.55120385655039 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark34(-67.54745798497095 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark34(-6.844936749354474 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark34(-68.69958731713001 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark34(-70.42149794242258 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark34(72.8211473438214 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark34(74.67369034715912 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark34(-79.86529163772049 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark34(88.26841437517268 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark34(-9.424777964067692 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark34(-94.59248118993007 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark34(-9.586065060551348 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark34(-9.597341699600733 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark34(-98.19299129981702 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark34(-98.34605642133225 ) ;
  }
}
