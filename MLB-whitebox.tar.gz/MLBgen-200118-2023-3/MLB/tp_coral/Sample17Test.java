import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(-0.01292015488829179 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(-0.01932219549007641 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark17(-0.025947268327371376 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark17(-0.03317609252431453 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark17(-0.036309957362703926 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark17(-0.05796878099168623 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark17(-0.10060661645516689 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark17(-0.2829740154207201 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark17(0.36208927206005465 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark17(-0.43012707038498377 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark17(-0.43925527173730927 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark17(-0.46437393331935084 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark17(-0.46972769159737027 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark17(0.6438588300747825 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark17(0.689729400261847 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark17(-0.7071067811865475 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark17(-0.8068416453644858 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark17(-0.8361818092373028 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark17(-0.8374106359347877 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark17(-0.9085871714908222 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark17(-0.9842007615894914 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark17(-0.9913003220871417 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark17(-0.9928972270874681 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark17(0.9994608402054781 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark17(-0.9998462286283469 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark17(0.9999999999999973 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999984 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999991 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark17(0.9999999999999991 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999996 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999997 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999998 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999999 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark17(-1.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000002 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000004 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000009 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000018 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000036 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000548147703268 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000969003152662 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark17(-1.0005425117234399 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark17(1.0719215727933715 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark17(-12.058641489775823 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark17(-1.2338789709326767E-178 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark17(-1266.2068329828915 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark17(-14.683140211056994 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark17(-1551.7515302170812 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark17(-15.730400638095404 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark17(1.734723475976807E-18 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark17(-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark17(-1.955407647819349E-15 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark17(-2.0620731275492687 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark17(-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark17(-2.191809349008403E-193 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark17(-2.50168063443099E-15 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark17(-29.306684603135366 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark17(30.596708357203568 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark17(-31.38188590520612 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark17(3.469446951953614E-18 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark17(-35.50238286356972 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark17(-36.759986179933875 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark17(-38.61314096048996 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark17(-39.01142429783151 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark17(-4.892161394304637 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark17(4.930380657631324E-32 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark17(-52.08428921093218 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark17(53.15729710611603 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark17(-54.44435339053928 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark17(-57.88092173781869 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark17(61.32247040099648 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark17(-6.311765873227458 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark17(-66.83795902130443 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark17(-67.10927503331598 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark17(-68.28205762451503 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark17(-7.096908919775217 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark17(-74.78968232125816 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark17(-75.16919877477555 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark17(-78.8719164170059 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark17(-80.94074680975052 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark17(-8.632065292839755 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark17(8.673617379884035E-19 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark17(-90.12227750630733 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark17(-91.00704244886234 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark17(-92.5011166049793 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark17(-96.55184821394352 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark17(-98.5854439892158 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark17(-98.9350633168975 ) ;
  }
}
