import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-0.555033881678753,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-1.0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000018,-26.824120614916342,0.7250540190504371,62.33999511710678 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000036,-100.0,0.0,1.0001243905060457 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000036,-98.96440405558155,1.0,-0.06259084589377796 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,1.0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0000000000000018,0.06179964631158593,0.3620988260408723 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.000000000000007,-0.09317595762098019,1.0000000110812892 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0000000000000164,1.0,0.8621536651252175 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,-0.2562278589652771 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.006863341463870853,-1.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,-1.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,1.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.013669749809206044,0.03536588781426142 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.019302283041985557,-80.52442804957919 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.02522150938647663,-1.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.048251949266916824,-98.2319165294898 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.05469123277137412,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.06064346749501365,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0625525254030922,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.06256093749643968,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.22702753818928445,6.078631962404874E-15 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.3017891820505356,1.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.5208384785489955,-5.934729841099874E-67 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.5256961907225655,0.9996579505407841 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.664686451197644,-5.852095443365248E-98 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.789163610240687,0.02617844773987457 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.8595477105540041,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.9009451148188397,1.0000000008384349 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.9529083266161431,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.9570710588317257,1.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.9671228726621698,-37.08074488132201 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,0.03539438922052038 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-0.08543960333005185 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-0.23950848076537 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,0.31937381327808234 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,0.5995963251192489 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,-1.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,1.00000031675762 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,1.0339234201806131 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,37.68377426276854 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.3930533107276504,-1.0000080516632488 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,5.860257929098651E-16,0.9726585213812071 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,66.70735556257213,-1.0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-10.613575600046074,0.0,-1.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0824015146286212,1.0,-1.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-14.374397130660316,-0.017472800428481594,-0.9983337172460011 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-14.966194146767954,-0.0784093246944213,0.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-15.54222259425569,3.552713678800501E-15,1.0000000000000036 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-16.05118909432169,1.0,0.3627151769716387 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-16.445090985918192,0.8468403647206859,1.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-16.51869134853836,0.07231471298013786,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-16.641642686570947,-8.881784197001252E-16,1.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-19.173715378787527,0.2583324962850564,-7.327480349199746 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-20.144176314648938,-0.014122175684645353,0.3415451564686114 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-20.999129372232673,-1.0,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-21.159825774165938,0.8728217486157362,-5.293955920339377E-23 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-222.4310748357231,9.002640990952074,-2330.5853333320015 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-24.267573347505703,0.016068799605598594,0.33087636068271514 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-24.563221604848334,-0.9999999999999929,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-25.442115044261605,-0.0029286367499204175,0.5667477994009822 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-25.80303455677415,-1.1102230246251565E-16,-7.550827384880838E-15 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-26.947484673064363,-0.026924967870198935,-1.0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-27.46201833658148,0.0,1.0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-2.752418605299544,0.8934618798054222,1.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-27.813115615965387,6.938893903907228E-18,1.000004021049468 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-30.10201648571629,1.0,-1.0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-31.145851774481155,-0.2613636235651484,0.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-32.037675648278395,0.014871551328134114,1.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-35.30867106441313,-0.03846961499620544,-0.08872749958843212 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-35.89130167666954,0.022922805631995773,1.0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-36.34092265781498,-100.0,1.0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-36.77503320699526,-1.0,-1.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-3.7434836288216085,1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-37.63256833966572,-1.0,0.06255254828973252 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-38.37724241855784,0.9756136770977245,-1.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-38.75435171211874,0.5761760612665852,-1.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-40.01439251112431,0.01573596456261439,-1.0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-40.243034022267025,-0.04855474643833724,100.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-40.46085870371416,1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-40.59509214488445,-0.8855817376468383,0.5759209709446835 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-41.24072495204647,-1.0,-1.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-41.26389569407134,-0.9147424677080466,-1.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-41.842795243585776,1.0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-42.05370975899614,0.018189270223286803,-0.8557708008024947 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-4.314285281894804,-1.0,-7.213264545145106E-130 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-43.58940329107197,-0.7037912328424132,-0.13448045382573137 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-43.66650806908497,-0.0029134456647453844,-25.688108600109032 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-45.91930495817684,-0.5498143837877445,-1.0000043257269433 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-47.40916791526457,0.15759015814502164,-76.77265680714089 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-48.61545107518929,0.6266671523454137,0.07868842673360632 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-49.419048434086314,-0.06986986383030917,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-52.09905173183032,-0.9999999999999997,0.9848948347507331 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark12(-100.05280897186016,-84.48092667961362,-0.03173837084493111,-2196.412215476524 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-52.981847787986375,0.0,-1.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-53.12897534916847,-0.7042069847979431,-0.032689102551494376 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-56.70567808211159,-1.0,95.80891933491466 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-5.703703880818283,0.9999999999999744,1.000014220307415 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-57.72477757237664,-1.0,0.9991142751857996 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-5.778672548751801,1.0,1.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-58.45056685246981,26.76386812950085,-0.05654693507398889 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-62.59147389005047,-0.9999999999999997,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-6.517442293591046,1.3877787807814457E-17,1.0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-65.43224894244636,0.5953372380438873,1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-6.62628461529593,0.0,-1.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-68.08400903599592,0.0,1.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-68.15667897178577,-0.009062107400340635,0.062258810549196186 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-69.80590454239358,-0.4136062708276763,-1.0000209716278343 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-70.84126840621452,0.0,1.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-71.7974059309664,-0.06118457515039655,-17.31892702931559 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-72.11086411471814,8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-72.3315550693848,20.698992245721826,-0.5952706375559131 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-72.91837026801012,0.04224222688459407,-1.0000000003972946 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-74.5502496591006,-0.020193444213323003,52.97020711460842 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-84.41553816221541,-1.0,1.0000005384242643 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-85.71271433187718,-0.9588582066302963,-68.33476079341182 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-85.92560210725098,-0.9691165790225154,-1.0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-89.14158172194453,0.05659565466113356,1.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-89.86164235132223,0.9999999999998946,1.0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-90.78474820247975,0.04146987215866501,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-91.28073308633064,0.9500253173467532,1.0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-9.340130558579176,0.0021180374448028128,-1.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-94.0788106977501,0.04674982125642764,-1.0000007861345226 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-95.89540666848241,-65.20414480330862,1.0254717041353734 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-97.76648627352608,0.6679029895072501,-67.6042926903096 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-99.49977383029022,-0.014093150152688754,-0.8694833269050135 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-99.6298824426797,-0.30103154691271616,-0.6962619337619619 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark12(-100.34738867734168,-85.891332523768,0.060069030215138215,0.06268289281838395 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark12(-1.0045189306411269,-63.14112220152729,0.9240216914067543,1.0188917987368742 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark12(-100.7909334119452,-42.79643436949442,-0.17524844051680255,-2210.8268166975113 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark12(-10.142473175099095,-46.447078044265965,1.0,-1.0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark12(-1.0216298697815827,-100.0,0.2516220864442622,-0.5587485778986654 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark12(-10.234176619800694,-64.01878770196706,0.0,1.0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark12(1.0253124525814172,0,0,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark12(-10.260569198336896,-34.8557888188168,0.0,0.02465246720192943 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark12(-10.382157088424364,-57.98519337183341,-1.0,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark12(-1.0399672017241166,-61.204042431569896,0.0,5.551115123125783E-17 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark12(-10.483183958167979,-38.17556267348138,-0.035159826299714717,0.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark12(-1.0560553199558154,-66.09816807861174,-0.9999999999999991,59.088973030241405 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark12(-10.578330080664525,-67.8300432162507,0.032699936386996524,-0.9999999999999996 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark12(-10.626370017157399,-94.58358513209035,0.0,35.78880648521812 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark12(-10.679342933579994,-9.075314141837554,-0.7949926199495344,-1.0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark12(-10.682971567614386,-49.18238342877051,1.0,-0.9999999999999996 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark12(-10.811191201923378,-41.467530241294526,-46.56768846905792,47.21795967476362 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark12(-10.862321888128363,-38.00437117839266,1.0,0.9999999999999929 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark12(-10.903789492892997,-2.024060357709658,-2465.2941943062415,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark12(-10.90936886394347,-100.0,-1.0,0.8502199552531664 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark12(-10.96959335835104,-2.920581356609648,-0.032761121038610154,-0.9452360818036838 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark12(-11.001816169722986,-33.623981374327144,1.4941491704523972E-4,-0.19095971184539495 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark12(-11.030450209419698,-22.60427233185508,-0.0245287571153376,-1.0000000000000002 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark12(-11.044911625718685,-36.125892623685345,0.41440673392964,-0.013013741580263027 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark12(-11.083269112487642,-34.1425206765249,0.0,-7.304389222138943 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark12(-11.152621375311853,-76.5256338533967,0.0,0.9999999999999982 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark12(-112.23165316650388,-62.88057420283721,0.9374314814672683,76.82303370306084 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark12(-11.306279067586303,-24.693909776600464,-1.5334205360331197,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark12(-11.309906195096769,-30.017332337277068,0.009067159977333317,59.558032431319106 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark12(-1.1332271575801722,-35.4591689027216,-1.0,1.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark12(-1.1367340446270697,-1.5885097639644172,-1.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark12(-11.371724737076562,-50.94473299416049,0.014041955942527828,0.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark12(-11.380953157196537,-8.79435905110249,-0.9809710391038484,-0.06255306180565216 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark12(-11.383336061219905,-31.760223264790408,-5.715954535523275,0.36279008770427085 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark12(-1.1433140571384968,-100.0,-0.4513191362810689,0.38207396361289014 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark12(-11.540209031237229,-18.93524361703527,0.05729961584654271,-73.55808447395185 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark12(-115.68645336361593,-19.398839075380927,-0.04189761073773024,1.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark12(-11.577556240159453,-54.80340298114724,1.0,-0.2354443053321309 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark12(-11.620951519696213,-1.0000000000000142,-1.0,-0.36208930218512614 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark12(-11.678747046518346,-86.01645835818734,0.0,-0.6499515059680915 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark12(-11.778103809325692,-32.35926038806299,48.699391503102056,-1.0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark12(-11.966510988757035,-46.90064100748269,0.0,32.18696474568154 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark12(-11.9724798651431,-92.40862422536271,0.06139919097555154,-0.07199575934238567 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark12(-11.984392731974035,-8.447288536230108,-1.0,1.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark12(-12.110534503213714,-41.905290743334014,0.624088540037719,1.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark12(-12.14153513992063,-88.31526548447587,-0.01637060598076108,-0.029727979821702222 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark12(-12.172626109125005,-98.59994935375235,-4.9598497412537386E-15,0.07638131360970912 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark12(-12.186131711620746,-85.36338838103282,-1.0,-18.17784640085962 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark12(-12.244511571916028,-12.98603742219369,0.9271451380129578,0.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark12(-12.306827093675864,-80.41373896474141,-1.0,0.2947877111825636 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark12(-1.2342614259144398,-3.391934674536034,8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark12(-12.372395017319157,-11.671316502612008,0.3904640305425886,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark12(-124.52755143100607,-19.45291649931596,0.01865979042412287,-2154.158362382565 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark12(-12.474877761094419,-70.96718559825767,1.0,6.41017373374693 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark12(-12.50957587346035,-63.5983791966245,-67.2036117570409,16.69290928752625 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark12(-125.13273613987255,-73.16221060588525,-1.0,2211.109461402401 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark12(-12.560470215882445,-21.44810735918218,0.9753453981158865,-11.204048887176533 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark12(-126.29700353574555,-124.14851749049757,0.05717138184056248,1926.2182326320565 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark12(-12.63257343033501,-95.48076345455794,0.9999999999999998,-0.8488516696840414 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark12(-12.760372928906776,-42.32617638315371,0.0,-1.0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark12(-12.820809263773615,-55.624819045929016,1.0,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark12(-12.873408995773415,-9.085229486208405,0.8308362651460459,-0.9999999999999992 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark12(-12.941261428098372,-52.378298353451136,-16.53776809407198,51.411072085228426 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark12(-12.97431267608767,-49.675508702590385,0.059589260027481286,0.0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark12(-13.000635190982642,-32.99802744026053,-65.20145499254872,1.0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark12(-13.043672561276495,-41.46017150751311,0.0,0.5418290733942435 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark12(-13.171617515523138,-49.74877823200712,-22.50538927657435,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark12(-13.172787528102411,-100.0,-0.5951731783507299,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark12(-132.796329117845,-42.75235563555786,-1.0,74.05773765322019 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark12(-13.309626299696998,-85.62155253783253,-0.011942074340729844,1.0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark12(-13.372672235110542,-93.47639148455477,-0.04380013182526685,1.0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark12(-13.381278445108563,-66.9278312623861,-84.38707975815893,28.83911872286268 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark12(-134.55857146603003,-29.88770872406674,0.04983635207662829,-100.0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark12(-13.503468554013025,-81.19716212537749,-12.055532151906448,-71.17598944161037 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark12(-1.3524785761008076,-11.455159624972763,-0.042309222132522264,39.299807324326885 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark12(-13.553336531961207,-43.41479065580653,-0.9800778354308364,-0.7084465599562897 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark12(-13.62853835633866,-64.44285958401616,-0.04947864644527517,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark12(-13.658281772848573,-7.358015887918771,-0.7085323208478185,38.0495623498649 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark12(-13.679055269424936,-41.19620870655285,-100.0,-1.0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark12(-136.96545316011114,-55.48897057152469,0.0563357440230602,77.10017852526742 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark12(-137.14306110782923,-36.573092134701696,0.07809480747977382,-43.90970900997014 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark12(-13.840314709794933,-34.40962938402893,-0.17037291013086542,30.4137726778078 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark12(-139.04070630260526,-65.40130527527243,-0.9999999999999982,-2028.5306246122896 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark12(-13.923792371175868,-77.91341189949193,0.9995899523586742,-1.0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark12(-13.929743127807772,-69.52945456009236,0.017473691523790906,62.42935412373095 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark12(-14.036372359086187,-82.16591534908859,-0.9344366713789343,-0.9194265004971308 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark12(-141.19739501439835,-170.1738975924843,-1.0,0.36116658909255506 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark12(-14.297276506335265,-21.516014943088216,1.0,-1.0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark12(-14.30840973212728,-2.47825818576735,-0.02208337126821094,-1.000000000000005 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark12(-14.354173387811613,-81.0428480360714,-1.0,-17.595177617313993 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark12(-14.406155771610365,-42.25841928999311,0.0,35.020981690257315 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark12(-14.445162133379165,-2.7606076212035595,-0.9958456899490882,0.3460649463565266 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark12(-14.633920084746848,-1.0241864193004195,-1.0,-1.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark12(-14.635383556593624,-65.4111339766502,0.05634701308908156,-1.0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark12(-14.724312082473642,-28.425833260933885,-0.9328041293640766,-76.10597895574512 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark12(-14.768236831099674,-6.562068425174088,1.0,67.4485955034321 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark12(-14.864848560992755,-67.08048980340087,-1.0,-2168.5744787722365 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark12(-14.866605222560501,-56.65526731220898,-0.3824825699774629,-1.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark12(-14.916488105083825,-3.0673997089713954,0.0,1.0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark12(-14.938821376219403,-1.000592390063159,-0.05180610238222502,-93.34520859878182 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark12(-14.939649981142766,-8.079320988869242,-1.0,-0.8137305014160867 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark12(-14.98322623438758,-100.0,0.0,1.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark12(-149.84309343788226,-80.17119506466734,0.9984596856534926,-2020.337620616933 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark12(-15.0048977887952,-1.0417432005110516,-2.7755575615628914E-17,0.06255789556286975 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark12(-15.048458719866417,-93.16075069422752,0.00911210409347046,-0.5159726799467492 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark12(-1.523856447072538,-50.801026414047065,1.0,-67.3052875400732 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark12(-15.248177874320572,-46.791688525827844,-0.004011943888741265,-0.9365683543144391 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark12(-15.263550433935762,-26.775077960877717,0.9723919045916011,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark12(-15.371464078209497,-24.014948539717594,0.0,-1.0000000000000036 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark12(-1.5404721134920525,-99.99999023137259,-99.99999953996955,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark12(-1.5421216511196718,-100.0,0.6335853371566817,52.89265225554567 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark12(-15.447957870803682,-32.20485700477569,1.0,0.02083307280432456 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark12(-15.568092036554575,-78.12979132774822,0.030048055080813707,1.0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark12(-15.635412606666911,-54.81145612144049,0.0,30.81174523609321 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark12(-15.646818372401661,-1.0996519855278586,-1.0,-0.6251409186143371 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark12(-15.847634774610214,-78.59936055607315,0.9727437564591817,1.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark12(-15.854804839440575,-29.680582341162932,-0.3507307077152575,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark12(-15.864627167259158,-19.852320059801237,-82.02403529421802,0.0637490259830793 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark12(-15.892539675091811,-74.13650236348708,1.0,-43.63048612121987 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark12(-16.01820017983546,-39.87695896612265,0.0,0.0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark12(-16.164531228862273,-100.0,1.0,1.0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark12(-16.226742861531967,-74.95028816458766,-21.93845660209835,-0.9583226098424421 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark12(-16.238660242769217,-90.90463058490319,0.011863979743395835,100.0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark12(-16.25821089207406,-75.22030979777172,-1.0,-5.312322692348788 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark12(-16.281923509361896,-42.25866729557722,-0.041556730786972196,-80.53172976749799 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark12(-162.93337580474818,-110.4048877671831,0.0,-2208.5357506307632 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark12(-16.33646670010881,-2.4577209505715123,-0.043612282278207015,-0.982167277060924 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark12(-16.347783578729548,-49.1572550046661,-1.0,29.516517454035473 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark12(-16.353865606922362,-100.0,0.5886611776578918,-0.9711060699296435 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark12(-16.386331649295162,-58.53999417499812,0.0,-7.359456954106884E-15 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark12(-1.6549251756103445,-100.0,1.0,-0.6388788130061793 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark12(-16.59394118792794,-32.6477794321238,0.036083296660667716,0.021154213939294262 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark12(-16.60185208376485,-5.08344781080288,1.0,0.010812468821062127 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark12(-16.639321064881692,-100.0,-1.7214983353174318E-5,-0.9742677248815096 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark12(-16.735283862399278,-38.50945449450545,-1.0,0.0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark12(-16.758862241946083,-46.59302893589156,-0.995104635849148,-1.0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark12(-16.843532346913765,-50.254650517183464,-6.114736340178601E-4,0.9371008579577498 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark12(-16.89537897364213,-40.047794554855855,-2.6469779601696886E-23,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark12(-169.3176013463509,-1.088106742781548,0.9693607736982963,-2231.4922664570645 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark12(-16.97006840344998,-5.591419250742513,-19.10761480580428,-1.0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark12(-16.974523159617156,-45.79606536129625,-0.4588678488914164,-0.9999999999999947 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark12(-1.7002327810770503,-4.451775367852081,0.9775399544222261,-70.01161411622141 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark12(-17.155659377301617,-27.755911454504428,-15.145566313597499,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark12(-17.159988773275764,-28.04976759184222,46.33064873730538,-0.04339696624370537 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark12(-17.20224555814949,-24.907207648584915,0.0,-1.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark12(-17.355318613453605,-62.66492048011463,1.0,-0.999999999999999 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark12(-17.479258311815038,-88.09750931415952,-100.0,0.04823792112420805 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark12(-17.605398431517077,-33.593185219169875,0.0,-1.0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark12(-17.655802233972963,-42.02189904275548,0.0,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark12(-17.665644813805216,-48.57453630427675,84.21336447953621,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark12(-17.671304039131073,-68.77653961393942,49.68193651315998,-1.0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark12(-17.68619335192016,-79.54407744118205,-1.0,0.0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark12(-177.4150275193157,-48.636533038372505,0.9698990030493513,2108.310665956309 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark12(-1.7774485764179337,-14.876461572831474,-0.005251458527259667,-3.396126192892505E-5 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark12(-1.7803401562290715,-44.52530486337785,-0.034231951304209154,-0.9808803495662244 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark12(-1.7812530605453105,-11.902381653456516,0.012779973366624064,28.85971006443946 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark12(-17.839342560827507,-45.7880544045623,1.0,0.8338714008004249 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark12(-17.914164904653806,-74.822829629615,-0.9980217682133367,0.9998108952815158 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark12(-17.95315636025148,-52.804033636751356,0.023579027625141524,0.9999999999999986 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark12(-17.984896517218075,-100.0,0.9999999999999982,-46.74000305493264 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark12(-18.013352477553333,-40.0640922739243,0.0,-0.8578651329822444 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark12(-181.16047841843087,-106.78845134917698,0.6111801971690776,2310.754481634493 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark12(-18.335912057410177,-75.43209029344636,-76.42769822176194,-1.0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark12(-18.34013285073894,-95.33157775822718,-36.336205050832284,53.12881829264518 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark12(-18.41156240706235,-90.75280552362379,0.0,-0.9999999999999967 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark12(-18.447740112042517,-2.8410121749855657,-1.0,-1.0000000000000004 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark12(-18.477199385730188,-30.15022169174401,0.0,1.0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark12(-18.54580043718181,-18.150682319975985,1.7763568394002505E-15,-14.738180624572081 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark12(-18.54676234093523,-100.0,-0.8679673502219027,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark12(-18.58318445877722,-37.90457559395304,0.013329247380214293,-0.999978608599799 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark12(-18.744183937760212,-96.61432297973056,-56.736142636085106,0.955788362848196 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark12(-18.755157674512503,-11.241838438428701,-0.5630213990578854,-13.195858989702373 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark12(-18.837818286232043,-92.8009295959761,0.02599862697563767,-1.0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark12(-18.840722585225222,-93.51463970472476,-1.6324915792724639E-15,0.20122500674584798 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark12(-18.95182576509094,-100.0,1.0380004845228135,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark12(-19.030685296979584,-42.1634584030943,-49.251549157375905,-37.37817854198218 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark12(-19.043417141310776,-100.0,0.054435617466024086,1.0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark12(-19.079383506885595,-12.16123169127595,0.0,-0.06255259317468169 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark12(-19.12985891702264,-88.12568482297739,0.0,5.07513748845269 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark12(-19.159060011603238,-17.018176663039075,-1.0,-1.0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark12(-1.9268115517817392,-17.685430993477357,0.9999999999999992,86.83695129623754 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark12(-19.300100985984713,-50.230248251740946,0.0,1.0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark12(-19.45031596951714,-86.98701013293473,-0.04012204584109309,-46.51068760655714 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark12(-1.9496429809033557,-70.24679579548385,0.567282154916488,-0.0016274382922937813 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark12(-19.530771326713882,-86.20560209269475,1.0,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark12(-19.561440407086504,0.9999999999999991,0,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark12(-19.621374904681865,-67.30783970301542,-1.0,23.792071533151258 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark12(-1.9685563125609167,-50.7687035336646,-1.0,1.0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark12(-19.77493844496682,-9.267094804626192,-1.0,74.78513368646725 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark12(-19.823358906346552,-62.72653489730289,-0.9290455861942206,0.06396957720183788 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark12(-19.86984131283991,-99.45175923917706,14.974232585041136,-0.9999999999999964 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark12(-19.90412197353658,-67.05440967259672,-1.0,10.958601991015387 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark12(-19.94241804254822,-33.305665581849844,-1.0,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark12(-20.016008885488045,-100.0,-1.0,-86.93641648600206 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark12(-20.14607697692314,-2.752998139019496,-1.0,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark12(-20.147502522666063,-61.72525786145415,0.16611456137838498,0.7813444825817735 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark12(-2.0159933944401893,-41.158732738875884,0.9355005487930131,0.05761218881520802 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark12(-2.0218307834879368,-53.8616882371346,-15.619039294703342,1.0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark12(-20.254512013841946,-77.52907116304965,-2.9965404780624993,-3.948604517393335 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark12(-20.27155892499221,-85.50240135853463,0.0,-50.97356194960953 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark12(-20.310826259510634,-30.745079188669138,-4.0428413086684145,-9.267636647448029 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark12(-20.39743037006248,-100.0,-1.1102230246251565E-16,4.3551866750835266E-5 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark12(-20.63112514674714,-86.49763993428385,-28.877135088897084,0.9784851305679749 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark12(-20.731643352541255,-27.52866581793367,1.0,72.82396943471895 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark12(-20.79989134074289,-50.76637904278236,2.5068980864307377,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark12(-20.831441661544936,-20.842809691944858,0.16965577722168235,-0.05418973082308895 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark12(-21.02715206458804,-26.247072719109703,-0.015244420950689841,0.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark12(-21.043968633624576,-81.80117551340113,0.009625076148713343,11.852122837730917 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark12(-2.119905096627406,-46.97479948980325,-0.01074971393738905,-1.0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark12(-21.214712836847873,-67.53330544111792,-1.0,11.86645841879453 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark12(-21.233241848616085,-14.427009081704316,-30.992145128354842,-1.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark12(-2.1357665311750984,-9.630692031282997,-0.028716973808511726,-0.6466981797391461 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark12(-21.371239091553925,-85.00080267504143,0.017602331713163225,-1.0045790490016413 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark12(-21.45300713773785,-71.4038720822052,-0.9485880917823015,-1.000000000000007 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark12(-21.504231365768504,-29.913219704501998,0.009971143143567328,0.9893060341641432 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark12(-21.525832058554272,-94.67095064986393,1.0,31.54135571557353 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark12(-21.527682412312117,-52.46271612669959,0.38780738300511963,-1.0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark12(-21.619736021020316,-61.261231964648466,1.0,0.41442537992709194 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark12(-21.635447465997274,-100.0,-0.9412968051742561,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark12(-21.6769667062797,-82.79204945816178,-1.0,67.01622859041467 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark12(-21.69854507221533,-36.02440122084243,0.5588298421783513,37.24747298672402 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark12(-2.1782086335170163,-6.6150732605509575,-7.575001686196842,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark12(-21.80577249162321,-56.77556425003531,0.0506360334027495,-0.9997023845878581 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark12(-21.847682912178662,-25.237997923103872,1.0,0.20334255195923845 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark12(-21.934203877604318,-72.70120417121441,0.0173094216577662,-0.016014018338542768 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark12(-21.941226128416126,-55.7225282668254,-0.011289035131498074,0.03394486834760735 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark12(-21.942608504265877,-10.85066176953606,13.237409533216677,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark12(-22.149539488335332,-75.55550019387505,-1.0,-0.6283545251563121 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark12(-22.22744632378768,-6.245091619682202,0.0,1.0073376097458535 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark12(-22.319482782835372,-14.777276946948252,-1.0,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark12(-22.362434528754267,-24.127766496154262,0.2802962865979,-1.0002849417387936 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark12(-22.408795592416524,-20.30472324197281,-1.0,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark12(-2.2438684732457133,-81.77265369249926,-71.6242938198074,0.0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark12(-22.5152293039025,-56.96005619037076,-1.0,1.0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark12(-22.544167325367567,-30.74008415609115,0.11172254473387921,0.8243059302111204 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark12(-2.2585743312033992,-1.9401151635672673,0.0,1.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark12(-22.629439318590826,-100.0,0.0,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark12(-22.669970294931673,-14.992869560598935,0.6353636665004956,-0.014059637970854105 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark12(-22.766406124084938,-71.23779469664106,0.9999999999999964,1.0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark12(-22.82343423874217,-44.89136993246786,0.0,-95.62616225778373 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark12(-22.84974378624555,-67.57853007264796,8.881784197001252E-16,-1.0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark12(-22.896403349553637,-25.142462033137654,13.023944574462426,-0.07456273348389575 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark12(-22.910071503232224,-44.34360722929394,-1.0,40.18604594146997 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark12(-22.971378211768155,-76.28292618090194,-1.0,1.0001050842142076 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark12(-23.05638387987754,-63.92899477422334,0.9296315371254027,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark12(-23.104390940119714,-34.43283463486091,-3.552713678800501E-15,1.0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark12(-23.125210077736014,-87.46222721046541,1.0,-72.64117612242696 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark12(-23.198760480391233,-36.150793767985064,-1.0,1.0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark12(-23.23219614214593,-100.0,-0.28417036338641366,11.253437383048574 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark12(-23.311267000650187,-58.45006596163291,0.043046888284279355,-0.014749865192899718 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark12(-23.32810349858299,-95.9751742303461,-42.93808756894399,-6.489596401320497 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark12(-23.356476269714065,-39.254465794362304,-1.0,1.0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark12(-23.364600309037158,-83.47103908427601,0.6198763895622779,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark12(-2.337206364303826,-54.44390787364939,-30.442369393623284,0.025394847453300562 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark12(-23.421881525695028,-100.0,1.0,0.9999999999999964 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark12(-2.346004114970563,-1.6691978586315164,0.056056509174543336,-0.024476214545481188 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark12(-23.50804954944591,-50.803565732112624,-0.9898961127719339,0.1040182940313154 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark12(-23.613179719106615,-40.896093966414725,-1.0,1.0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark12(-23.725205466158418,-100.0,0.9545313387276901,0.9208629450738863 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark12(-2.3912395742384955,-39.004286148234385,0.0,-0.08614229901911308 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark12(-24.05138285553865,-48.83573811569234,-0.6062635823651703,0.20809530165002776 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark12(-24.05218184391444,-64.84582026563741,-45.20532157785584,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark12(-24.17287932310674,-37.48897591168085,-1.0,1.0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark12(-24.187235422684815,-49.652860833722265,0.0355365163529512,-47.38013153436414 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark12(-24.198740425159187,-60.22402002817646,1.7763568394002505E-15,-44.45270514768429 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark12(-24.30561928815704,-76.19033853997469,-1.0,-44.96184815827651 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark12(-24.359220121993072,-72.15965247213754,-41.55575818750828,0.9598083146504495 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark12(-24.42578660828714,-2.2389475032193076,-0.012374508318338528,-2.9635145262333396 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark12(-24.46823409872547,-73.8727728597772,-39.31256941941999,-0.9637347712279577 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark12(-24.48215251901505,-25.826178736804717,-0.002305781799901009,1.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark12(-24.63436140291556,-62.79618362808499,41.19225881065069,-0.4035512678142913 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark12(-24.695903645196154,-67.6192970917636,0.0,25.55811056386834 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark12(-24.785636689411078,-62.30133255516046,85.13341321285685,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark12(-24.805675238032983,-92.69523237121328,-0.788993739460378,-1.0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark12(-24.81693201038669,-100.0,0.6466143608112742,0.0495672081944043 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark12(-24.935375682327777,-11.723553514070066,0.0,-2.2543500596528223E-16 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark12(-25.084215149080006,-100.0,0.06018877226716948,0.2730728832015668 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark12(-25.155082909204715,-49.21814049200685,1.0,-55.06612552337957 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark12(-2.519954205549912,-45.696152794326544,-1.0,7.888609052210118E-31 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark12(-25.246595433316358,-11.703895633528504,-0.3202213619003498,-49.09151702442501 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark12(-25.392389737027628,-100.0,-0.7193348311080131,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark12(-25.549742578320565,-47.443844383695506,0.05890208724498816,-6.2590793460479395 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark12(-25.65429795919276,-52.95482580268207,-97.86855259492961,-1.0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark12(-25.68182392758783,-55.76465469782419,0.0,0.057706859145203515 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark12(-25.72703910182848,-45.67263460144502,-0.8786642712924433,1.0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark12(-25.743352906040162,-28.295775787428568,1.0,-32.01080848355679 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark12(-2.5746277819694887,-3.1074992912724326,1.0,-1.0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark12(-25.988560152047853,-76.54011800613443,0.0,-1.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark12(-26.117114496616097,-29.211659980416556,-62.55442373686824,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark12(-26.1290987337504,-97.91552063660174,0.04131262179279911,-0.06255337688620811 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark12(-26.173795210999792,-100.0,-2.7755575615628914E-17,0.004502902347056681 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark12(-26.435363000258054,-37.01023113208531,-9.063723904008732,-14.390922053376606 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark12(-26.457821442720725,-11.947901785276898,0.7726256672630532,-16.164527406355816 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark12(-26.567982078947605,-59.09816564769646,1.0,-0.03626309151602848 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark12(-26.586837746167603,-44.34920418596168,-53.918941260866575,-1.0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark12(-26.722268962413352,-40.940174237748856,55.115880666349696,-3.63779346702126E-6 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark12(-26.829420858784047,-24.91870534877369,1.0,-0.03481506523812988 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark12(-27.0412333102363,-3.739246222827039,0.010359174656487627,-1.0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark12(-27.04879991684414,-14.38672617340039,6.160529420237156E-17,1.0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark12(-27.296073731906294,-28.482386286808843,-1.0,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark12(-27.32331516977396,-5.625115897110476,-1.1102230246251565E-16,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark12(-2.7567261570489996,-70.65043889109391,-0.3721262375557902,-0.20445189006226783 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark12(-27.630054558281017,-2.2447382989034237,-0.05996307014299017,-1.8991135491519597E-65 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark12(-27.662509065345965,-67.5016826493651,-1.0,-0.010573919907842927 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark12(-27.663607074888706,-99.99999999999996,0.0,-1.0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark12(-27.677692085025612,-18.755155439429807,-0.7251850736536632,0.9999999999999853 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark12(-27.748824557547792,-52.532405353252166,-47.68323938260897,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark12(-27.80330781914975,-6.251972358850731,1.0,66.43648946740534 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark12(-27.80561632536742,-88.60246699835895,1.0,-1.0000000030705984 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark12(-27.849531191533195,-84.53907869375782,1.0,-0.7299389345447209 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark12(-27.86589701099402,-13.726386757348408,0.5873698211374041,20.44862535918513 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark12(-27.928840764013447,-71.05703182911316,-0.9530484752419832,0.03615386095818904 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark12(-2.8014246975155497,-22.840924242907732,-1.0,1.0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark12(-28.02497049274902,-1.5227996330549813,0.0,0.9869467123393999 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark12(-28.085342399135797,-99.99999999963906,-0.09819014466640659,-2.5849394142282115E-26 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark12(-28.250308620464494,-61.392246607260304,0.0,0.8302621385213512 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark12(-28.251212930708693,-71.70584437645381,7.754625752404517,-0.9543459944746854 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark12(-28.405751515069028,-42.42364626253276,-57.278761551820324,-70.41166423965417 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark12(-28.407073559609614,-59.73274298246955,-1.0,-1.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark12(-28.412364135146532,-79.63849766730658,0.0,1.0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark12(-28.434788420437684,-5.104975680453154,-0.050089392898261115,0.15002845764201284 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark12(-28.67242835187612,-67.18672341615525,0.9649431127758099,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark12(-2.8832241735199204,-100.0,0.5384609519658756,-1.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark12(-28.98261667002895,-86.97018261240186,0.05236449353643151,1.6472184286297693E-83 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark12(-2.9296918446841005,-37.926301366064315,0.9999899892029747,-0.06259465232856866 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark12(-29.326152146425997,-7.197099731337817,-0.9800166644420719,0.09133175696802164 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark12(-29.431807109404474,-100.0,0.5625792091857708,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark12(-29.492980499057836,-59.817562861669174,67.50448195577135,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark12(-29.50774530667107,-78.59949861888236,-22.12160218829327,-0.8941883687488573 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark12(-29.594660357307493,-12.88279474215924,4.0117203562051174E-4,-1.0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark12(-29.643530516257897,-53.36259634347937,1.0,-0.2576129752997085 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark12(-29.666656415751454,-32.62345355958751,0.831716256454494,60.62707682497396 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark12(-29.698581442220267,-82.90225829857937,-0.962490032688558,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark12(-2.973660686374288,-53.846236511087845,-6.899028957504033E-5,0.009368490727334117 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark12(-29.745900147337526,-38.622419561028345,-0.7419114867079879,-0.9877347056455914 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark12(-2.9805821967962487,-20.23625796912269,-71.90300447522603,0.9999999999999964 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark12(-29.93859366573122,-27.974634980883152,-0.058258447898095866,66.88413005926957 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark12(-29.944670429848358,-47.211186894889856,-0.011408584993542706,-1.0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark12(-29.987547845335854,-77.32424286185875,2574.396652235572,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark12(-30.256535449908455,-136.68500378542967,-0.999999999999968,-0.05473352222762051 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark12(-30.32098083682817,-79.04453070166022,-82.84398601327369,0.48350658453626494 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark12(-30.459478523635948,-5.672815000514166,-78.66894338327839,1.0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark12(-30.677384443911645,-14.576959358373927,0.5073944956291091,-0.9310762848297804 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark12(-30.67827903964833,-64.93765758893451,-41.571427700418575,-1.0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark12(-30.693439677201113,-8.738901704825807,-1.0,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark12(-30.72960544884331,-43.74013651827015,-11.497713497316369,-0.9898142952322648 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark12(-30.74592498027866,-88.6129064966819,1.0,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark12(-30.826737979564527,-2.7510333547974426,0,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark12(-30.95156992562945,-46.11409582992992,0.0,-0.4237933683458981 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark12(-30.97411750695572,-20.71535302854163,1.0,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark12(-31.008650805224477,-44.71097207061601,-1.0,2196.7229269458358 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark12(-3.109912209262119,-100.0,-13.371948685402183,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark12(-31.42030899276609,-20.753315547721975,-0.4070648353640016,-0.9854515173901093 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark12(-31.49386987021074,-13.45960252943108,1.0,0.23402776610679132 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark12(-31.515779563464378,-84.50502197466756,-1.0,-6.553412516184935 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark12(-31.53056698604584,-63.8839074431311,0.0,1.0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark12(-31.561971482293316,-3.226379244127415,0,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark12(-31.56778923330976,-71.57784229393818,0.0,100.0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark12(-31.5784203832958,-28.097979545291143,0.5088843996536772,0.04565382814681616 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark12(-31.700882899450974,-70.58588434141319,-0.8757372871574718,1.0000000446305939 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark12(-3.1739798935276724,-44.515473347482065,0.0,87.07590370981025 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark12(-31.790908596337918,-18.910295745385127,0.0,75.91048503984831 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark12(-31.798780532381667,-97.31953409722519,-1.0,0.36210569834974493 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark12(-31.99436645607185,-36.096016308335926,0.9999999999999929,0.9281512386280641 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark12(-32.09859562925048,-57.82565650517595,1.0,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark12(-32.22345117675316,-10.546261614007754,-1.0,-1.0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark12(-32.314436794846415,-11.890138348122573,-1.0,1.0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark12(-32.36088719435664,-32.04451134319971,-0.6282415419538077,-0.006473917169119381 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark12(-32.39092337925166,-100.0,-1.0,-0.6999411887356024 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark12(-32.404809543924884,-62.798364403579285,-1.0,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark12(-32.483952517018636,-39.8641208236664,-30.37324118091449,49.24838271032368 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark12(-32.58382808505072,-43.45003062261571,0.02710038591635984,1.0371598138230615 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark12(-32.58795317767758,-91.11051505272133,-0.47035149085262884,-1.0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark12(-32.61509498208014,-30.66329785890784,-0.46669716651935633,39.39333896919098 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark12(-32.80289704666065,-69.03945954164503,-100.0,-0.061743707603263705 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark12(-32.80338744299437,-57.194046641366576,0.878158932126384,0.06261462063059083 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark12(-32.835631333928134,-10.648468234940486,0.0028874508720191537,1.0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark12(-32.966658393317395,-56.42872704291951,-36.41986579427689,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark12(-32.988608754893114,-7.7802727265346086,-1.0,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark12(-33.082279074273075,-76.77828179267462,-1.0,-1.0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark12(-33.18892921926944,-29.57163984353086,0.011390465127412817,-0.583922687514487 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark12(-33.3732598138662,-88.29042622746553,0.0,2150.3521040902447 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark12(-33.38041101704865,-24.82726293283986,-0.018584894408858955,-1.0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark12(-33.382016890846856,0,0,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark12(-33.42236334393614,-18.198471512671635,-0.2742231458555928,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark12(-3.342503214150483,-96.7718402454887,-11.113464992818251,-0.6916644747861311 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark12(-33.464015020517635,-50.844575293638236,50.380972567326125,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark12(-33.481410008091075,-53.50904247034998,0.9921779445632593,0.4629483657858988 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark12(-33.484140313579374,-27.59215049556309,0.7361139012684674,-1.0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark12(-33.50014340685165,-33.704202904043896,0.7898875672217495,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark12(-33.52168345735929,-49.68617950151426,0.23126425615113488,-33.71662998639637 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark12(-33.522752668004806,-86.65031821845133,-0.37841242168761546,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark12(-33.53039957436148,-47.2159640283906,1.0,-32.08794446870491 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark12(-33.565531022463105,-50.325054617883445,-0.9492241025579403,35.99490904556069 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark12(-33.60387674528597,-28.70011956335472,1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark12(-33.608290367840425,-47.542147365792154,1.0,0.5874547340721618 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark12(-3.366122996704764,-86.54690756902116,1.0,-51.56455093941281 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark12(-33.67024525069618,-54.559701518375434,0.17770397132881643,78.6199951789556 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark12(-33.671937137286,-64.88422223360277,-59.22742263125098,0.8561976936928914 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark12(-33.6971360477328,-12.70757413611109,0.014206952553193307,-42.13047271613488 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark12(-3.3803717042790176,-35.03989412344711,-0.960512703788663,-100.0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark12(-33.80984860150512,-19.68259587134585,0.9539566900787229,0.999999999999959 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark12(-33.88502700282249,-24.93174874717997,-1.0,-0.01672612924655628 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark12(-33.958237918143496,-29.6255964540742,-13.08477716302977,-0.9413332843090418 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark12(-33.97616301763892,-32.075385757188236,-0.00888399580024088,-34.32098284864427 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark12(-34.0270076263268,-80.16015803048634,-0.01796938427656486,-0.9896284866120026 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark12(-3.4110076861089453,-46.54257395415492,0.9999999999999991,-0.640306123610028 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark12(-34.15944674935187,-23.43976977842262,0.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark12(-34.19326885867086,-45.73802767508617,0.0,0.16375744902390887 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark12(-34.35521391313422,-4.464418436507069,-0.7618455570459588,41.53505365374468 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark12(-34.35526407734257,-51.82208438030225,-0.2118037623822976,0.01936786265108513 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark12(-34.41683240960375,-46.92405654520945,1.0,1.0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark12(-34.441108907159744,-64.17811607297945,4.440892098500626E-16,62.049680974123994 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark12(-34.569377042345515,-67.4779784657509,-0.40700550834427884,13.668380013099494 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark12(-34.60471621656614,-10.871612982054023,0.007822748421835224,1.0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark12(-34.6176448700303,-90.19778109498735,1.0,-0.9625491957600396 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark12(-34.627036220621406,-99.99999999999993,0.0,0.9999999999999264 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark12(-34.634875569982846,-63.0708796251001,68.95416946278145,-0.9999999999999982 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark12(-34.71488652877147,-2.490470108714233,0.05777709553956184,47.64048791677877 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark12(-34.79758484627371,-82.8736767003886,-0.057793433362355984,1.0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark12(-34.83990852512027,-100.0,-1.0,2.710505431213761E-20 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark12(-3.4849198704386932,-100.0,-1.0,0.04956470503853866 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark12(-35.03324152700462,-100.0,0.42212971874234784,0.5157835729195974 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark12(-35.20742985056306,-12.884849562162358,-42.286629738925456,11.771687771188184 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark12(-35.2250714017636,-59.73608275694468,1.0,1.0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark12(-35.45460822266803,-100.0,0.950582792074739,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark12(-35.47969423371103,-76.3875417468753,0.01194289026971923,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark12(-35.51616255509669,-30.42026040737808,0.6539624944509945,1.0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark12(-35.56735399720189,-7.605349456436414,0.0,0.9999999999999964 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark12(-3.5595066721504125,-94.90121437737066,-0.9485577737861656,1.0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark12(-35.75015880814553,-35.49835379377316,-0.023601846165073957,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark12(-35.7581898383348,-35.65624461162195,-1.0,-0.8968556597558391 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark12(-35.769651600013134,-26.18336070306389,1.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark12(-35.791490685659525,-30.774223270256112,-1.0,1.0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark12(-35.79948356182636,-75.44421668827074,0.6501590605031942,0.9969435776801981 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark12(-3.583838512049608,-14.551186892061269,-0.8193785556814994,6.3290402157637615 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark12(-35.841524954624724,-8.256014291553852,0.0,-1.0000000501824629 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark12(-35.86224680665977,-88.2892262593999,0.0,2310.2838844872404 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark12(-35.86753920088608,-29.56061249402898,1.0,1.0000000000000002 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark12(-35.882758343250075,-48.83973353445239,1.0,0.06256005813719928 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark12(-35.94692935932855,-100.0,1.0,74.45613599617407 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark12(-35.9490889026892,-26.116575671755825,-1.0,-70.97121744463561 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark12(-36.018852451824564,-34.07929321541642,-1.0000000000000009,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark12(-36.04353143697736,-22.767191418639698,0.9999999999999996,1.0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark12(-36.085134209355,-7.964829874392489,-0.9688720857696781,1.0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark12(-36.09678520600683,-92.42692593456816,-74.33665319474116,-93.38028491711006 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark12(-36.340659253566,-16.818376699371413,-2487.605247799629,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark12(-36.4033750418356,-80.54072674488731,-1.0,-5.348088560115642 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark12(-36.49173126195529,-47.76673114588337,0.43822688518944164,0.0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark12(-36.52766093539505,-78.75073786481815,0.0,-60.95334976609007 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark12(-36.56594519126821,-152.93172106766906,0.0,-0.05876432272143989 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark12(-36.61840985105759,-23.597063563248426,-1.1102230246251565E-16,-69.09770176191869 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark12(-36.92859875744773,-72.46001046908512,-82.43005615966487,0.28498818929346686 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark12(-36.93575924677032,-60.230282045887115,-0.04438851511093772,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark12(-37.039834584851825,-69.37157416736763,-47.53612299153873,-1.0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark12(-37.0578663482051,-40.728893649810644,-0.03453878116162912,-1.0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark12(-37.05888936719464,-41.50171356977628,-1.0,-17.26988914655452 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark12(-37.146209814021766,-20.328595306448705,-0.2350791454163037,1.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark12(-37.25494781811216,-26.289437432217962,-1.0,0.5243540051587829 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark12(-3.7562158207360516,-43.61013724962594,0.25562452229916643,-1.0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark12(-37.570848554812024,-46.08605194354167,-42.82230929558399,0.9579476618050382 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark12(-3.761515141279048,-39.77570144363149,-0.009464659652635266,1.0000000000000142 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark12(-37.61576615108078,-92.99247546647251,0.017288124565060337,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark12(-37.664121642951216,-33.86536258561539,0.0,-41.910130995127226 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark12(-37.762206437269526,-67.48631867719084,0.04439286756575486,-29.23202846211919 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark12(-37.84659131153676,-50.058611690335624,0.05578468693514444,-0.8766252069982653 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark12(-37.92668639773582,-90.20376710841444,0.13849836234675333,0.0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark12(-3.7927757118242766,-2.030788623126739,1.0,93.87482046975003 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark12(-37.98282097319507,-46.97423560999745,-42.37094677698752,0.4580904273259256 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark12(-38.128072173081335,-45.38302449427113,1.0,-0.9140746123948601 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark12(-38.22281730484105,-96.23979126901247,-1.0,-0.9648715734521864 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark12(-38.25091945275294,-2.070458370525216,88.04928033602795,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark12(-38.350153591358094,-79.34928669763003,1.0,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark12(-38.55059929905923,-8.179530574888023,0.9999999999999929,-0.09592035619966621 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark12(-38.58935577800588,-67.06860446690995,-0.01829218876098247,-1.0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark12(-38.632853711736146,-9.720510217899815,-0.7278414476889594,8.226842852157844 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark12(-38.71950714718151,-49.45137555988764,-69.06697012634663,31.735527108406757 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark12(-38.742852749096755,-28.985716888101017,0.7640675024752313,-1.0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark12(-3.8811725017148735,-100.0,-1.0,0.011136554510554605 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark12(-38.83926847108415,-43.47097252345524,1.0,0.5921432771317079 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark12(-39.054501484382826,-31.973224754128616,-1.0,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark12(-3.9152207970716724,-15.3903480017952,0.0,-0.43780478661426303 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark12(-39.17024613509649,-11.736701913378669,-6.943112138818937E-6,1.734723475976807E-18 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark12(-39.23940409980812,-60.14374881872787,1.0,13.598281357785618 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark12(-39.419499753097625,-32.97370020241124,-1.0,0.024480606276046313 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark12(-39.45113823835966,-80.53850156637672,3.552713678800501E-15,-54.34034319548522 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark12(-39.49184665616479,-42.341434299765304,4.440892098500626E-16,47.689170231980285 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark12(-39.52677649163916,-10.915904602670253,-47.1977466045034,42.303918897201555 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark12(-39.68649877228304,-71.89555295501279,-1.0,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark12(-39.92886182821687,-28.933256025390833,0.008437357099767784,-1.0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark12(-39.99088822054475,-36.84143192830291,1.0,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark12(-40.03459673945446,-67.45111629444233,0.9685099966893151,-0.9452542196825887 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark12(-40.05376285225564,-31.875607635601966,-0.6380356964846872,-24.23033326596965 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark12(-40.07839584408189,-61.59435721287589,-0.345543005590944,11.237998355989422 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark12(-40.141597529801544,-33.02190662756835,-1.3877787807814457E-17,-49.53147496109548 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark12(-40.271829940666116,-49.95786315994036,-1.3877787807814457E-17,11.297747643568066 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark12(-40.471244597079334,-67.80152288493298,1.7763568394002505E-15,0.7400901982404614 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark12(-4.057677903882704,-66.95388097360015,-8.881784197001252E-16,1.0000000000000018 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark12(-40.59104547528745,-92.936015532376,0.48602795026642454,1.0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark12(-40.623262846908474,-43.54678233286288,-0.711542900656555,-1.0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark12(-40.76155951846505,-88.54252168155037,-0.42595227088972254,87.93381329328304 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark12(-40.79117775350771,-25.473204606597122,-78.44717563829886,-0.7565793380236251 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark12(-4.082554214690397,-62.78439811471381,0.0,46.46294153240704 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark12(-40.87023392679302,-63.60946532980476,-1.0,-0.9685689821120709 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark12(-40.93726836401197,-12.557433819938357,-0.5860641828893409,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark12(-40.9462490820059,-53.201189496088276,-80.5338742773193,1.0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark12(-40.95548911831064,-95.7874314527161,0.0,-69.38981774876916 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark12(-41.02175070729832,-23.03230639487043,-0.6281802022009146,-84.70563090754008 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark12(-41.071458687851425,-100.0,0.06130784316744309,0.21071108416071746 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark12(-41.08121457118092,-49.22802640969783,-100.0,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark12(-41.196712284475026,-19.61640063436142,-0.3353034043143759,24.17076632547334 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark12(-41.20597563805277,-52.22508711477445,0.2698808552474515,0.9889740634820078 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark12(-41.21149805159822,-3.1731228286653135,-0.4424533325710205,-0.019750122856136983 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark12(-41.43555794103608,-49.054742242416296,-0.5343177775466403,-1.0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark12(-4.153002436397642,-85.07550445688965,-2.1551040623820295,-1.0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark12(-4.153929330308159,-33.19454294814432,0.0,43.484026701521884 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark12(-41.54293700804426,-72.06483991778843,-0.337467037693294,-20.59880156362786 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark12(-41.62690280180974,-11.653555268558875,-27.513865493264376,-0.8811948008276428 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark12(-41.659606218321514,-81.02752482411833,-0.38691561007964026,-0.9375908759702671 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark12(-4.169746152423329,-34.959032665346506,-0.017125259904638996,59.31967301707944 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark12(-4.18093853553296,-43.04696136925212,0.5896025828659222,0.7469328847497545 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark12(-41.90551553609701,-29.775376656219123,-0.01543051356325914,-0.031116192951364807 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark12(-41.94269482394213,-88.27792391496405,-1.0,-1.0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark12(-42.03337059962547,-54.909219243292455,0.0,-61.22592254030411 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark12(-42.05361557282889,-25.06317504408167,-1.0000000000000036,1.0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark12(-42.158851764566485,-76.32961898968527,1.0,0.020829975383583832 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark12(-42.23336049652401,-14.4584064828586,72.50408111242382,0.0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark12(-42.275762270758214,-66.9389737729775,-1.0000000000000102,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark12(-42.27751597387379,-8.2597962017918,-68.01409269664535,-45.922028057766305 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark12(-42.32278126594886,-100.0,0.0,-4.097950990932123E-18 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark12(-42.430606016394925,-38.42513416296776,0.16281976293154088,-1.0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark12(-42.44983637465379,-7.679785693545987,-0.014678203815123747,-0.9389812191961301 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark12(-42.46156546082669,-54.845835431002435,-96.8344370367294,43.67711989529627 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark12(-42.534973959142874,-13.534110210322623,0.03188805036406811,25.957594453522333 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark12(-42.57047809609187,-81.44583375962722,-79.83737885898978,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark12(-42.695322571639174,-71.92791523221183,0.5435147789941266,-38.851355474182945 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark12(-43.167285122704534,-92.53605747083809,91.39484012082133,34.60698420566047 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark12(-43.32701622040866,-56.60742231387689,-0.52119025574786,0.04154436088898272 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark12(-43.3849749354368,-2.1241078028619427,1.1102230246251565E-16,20.805848059646607 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark12(-43.550271176010625,-100.0,-1.0,100.0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark12(-43.5776504128357,-45.40459695429438,-66.38042912248187,-0.9616924381272223 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark12(-43.60156953626135,-100.0,-0.05264836807928752,-100.0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark12(-43.79553831345412,-96.75270446323533,-1.0,-1.0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark12(-43.83666181696194,-13.775161358527866,-1.1102230246251565E-16,-0.028304462489678682 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark12(-44.07270842281644,-30.27430215621066,-2.7755575615628914E-17,1.0000000812821714 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark12(-44.3060891221712,-87.70935089275562,-83.17999032893009,-1.0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark12(-44.400130532889136,-25.144453216304456,-0.01812693976147527,0.7219171714491819 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark12(-44.48942181989617,-21.264529040816996,0.01795778037406684,-58.72553727738836 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark12(-44.54285401323632,-100.0,0.0,-1.0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark12(-4.461603578371109,-75.01483105853593,1.0,-0.6855341946644482 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark12(-44.619651818067695,-74.28197210518474,1.0,0.9120836848673806 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark12(-44.64298996443718,-46.09456969936694,1.0,4.440892098500626E-16 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark12(-44.69705818612928,-22.514868689433893,0.0,-0.021089252466674868 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark12(-44.73582462787371,-97.65135309748412,-5.285645648080463,0.0010401279317571177 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark12(-4.478044406211753,-47.69208079367786,-0.01919403368237138,0.6439863221301039 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark12(-4.4876753760795465,-53.985891759595674,44.41472487201057,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark12(-4.4968557718098685,-69.48494509716349,0.06049552552529525,0.0044274050155486714 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark12(-4.4973904094909045,-20.78685118275412,0.0,0.11534900786701363 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark12(-45.06788304451697,-41.036025271210285,-14.03124512049689,-12.192981598859859 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark12(-45.15410409281262,-71.51210728828958,1.0,0.19572492330155578 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark12(-45.15442180469635,-13.693918705939932,0.032870956963073336,29.856865931320876 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark12(-45.15506663009601,-30.99786884580984,1.0,-0.21105530093527114 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark12(-45.259856315111705,-1.8812555212322473,-1.0,-0.06279451765870847 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark12(-45.26019901518461,-18.51586084650073,0.0,0.6578151123027538 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark12(-45.31673397723003,-18.035838651777606,-0.2907779388598068,-0.9620719911838075 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark12(-45.32619668965067,-91.48692768848613,-0.017368882791592988,0.7676706963564871 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark12(-45.470073639205076,-100.0,1.0,9.9252392025844 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark12(-45.65606080208716,-100.0,-1.0,0.9157046184195847 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark12(-4.573656135543369,-20.794487995862188,1.0,0.030666560168380815 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark12(-45.87933797860752,-2.931388411225541,-0.7812664616084533,1.0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark12(-45.91215229939657,-48.923538715403076,-0.6907549962113111,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark12(-46.12724113618767,-32.359246539628394,-15.451601040679549,-1.0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark12(-46.30062248080548,-91.40644855752511,-1.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark12(-4.641355754877695,-100.0,-100.0,1.0000001042830244 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark12(-4.647667667793723,-38.64438359962617,1.5011257195055063E-5,-0.0024956758752042174 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark12(-46.52971005583302,-53.971332087332314,0.07511500590860543,0.24141358519740289 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark12(-46.66966877438906,-34.62134296115879,-1.0,1.0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark12(-46.801941210278656,-23.204307808000053,0,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark12(-4.683785030068023,-95.04728647103946,1.0,1.0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark12(-46.90899029322874,-59.29836169522225,0.0,1.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark12(-4.6996607078213515,-80.2554249971791,0.01493788840449149,1.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark12(-47.136527894161,-83.71218674925672,0.1286558436139984,0.018476548244803215 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark12(-47.15041147869988,-5.577778164923728,-44.260929860234874,0.9999999999999982 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark12(-47.209314645762305,-55.50564191703775,0.002203550368951035,1.0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark12(-47.23895767172631,-1.7691692008416984,-0.6669112770957288,1.0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark12(-47.25157576206356,-43.77599119963257,-0.03922583940212649,-1.0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark12(-47.260903979500036,-31.939352764364312,0.8772831350011662,-1.000000863868188 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark12(-47.27235042226703,-69.32654288910436,1.0,21.742216066818422 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark12(-47.30955495786066,-16.85810581863788,-0.007622923161741707,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark12(-47.33645919182729,-100.0,0.05944474743151321,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark12(-47.37445218995013,-59.51899101215447,0.08524419928094007,-1.0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark12(-47.51181068067108,-5.69993463342479,-0.048024094523120495,-1.0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark12(-47.513564457447146,-25.75477509989122,-0.9456859834965723,-1.0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark12(-4.753469925194629,-94.73141692222529,-100.76697220639753,0.9999999999997002 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark12(-47.567944154468485,-31.225382281435543,-0.41097997319974233,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark12(-4.762601285038267,-80.17943178252632,-9.893706877836575,-0.986702598216184 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark12(-47.720592380777084,-6.598108065803143,-1.0,11.296358575011958 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark12(-47.75601430051502,-43.14928452428038,0.0,0.8102617087152719 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark12(-47.76037586616013,-21.56432198209051,0.0,0.7414935865078534 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark12(-47.81085768602023,-92.18469409658965,-1.0,0.019435434478098788 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark12(-47.82183278331003,-71.07900270128977,-37.5659794711304,0.040207800029656196 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark12(-47.8440071222394,-15.03696875143328,0.20929100593248842,0.9860258975504352 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark12(-47.95656415065772,-67.77979969528228,0.02628236122678418,0.05741270852594382 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark12(-4.801765356897267,-15.345861565966082,0.9258678063424679,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark12(-4.805759640087514,-81.2643887191857,-0.9720163455820146,0.8370786672845494 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark12(-48.106058776517216,-10.846755844914064,1.0,18.30870868361945 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark12(-48.3288274081668,-20.010781060718923,0.007366512609008449,-1.0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark12(-48.42711696073536,-17.788049958793934,-71.7136553143217,1.0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark12(-48.46140145000974,-72.4629619311764,-0.021974602075661747,44.72742821486287 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark12(-48.54000054100552,-85.1253311530001,-1.0,-57.53944680700761 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark12(-48.63851065493035,-8.476902567262076,-1.0,1.0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark12(-48.72918540908108,-25.90395379311102,-42.47955224820173,-0.04523061231962042 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark12(-48.7293290907943,-53.94718551478141,-0.011673879407824606,-0.3440679429282161 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark12(-4.873002082724955,-90.15658882077216,1.0,1.0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark12(-4.885271388447137,-41.65355246712409,-1.0,-1.0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark12(-48.85542819550599,-38.01169492594711,-14.909103622892975,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark12(-48.86305118797826,-4.1188448781123554,0.017603807024600626,0.20481970842471608 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark12(-49.02014731932462,-69.60570066368786,0.5245244376066596,22.263767566674492 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark12(-49.07887988713433,-25.233151895053496,-0.02597936884765692,-1.0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark12(-49.29031635143034,-34.85967923461058,0.814971325046805,-47.888762089513776 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark12(-49.29110906309658,-43.00967806555358,0.01788658602037239,0.0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark12(-49.444146424598316,-80.73487766734647,-0.03275975700295368,-1.0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark12(-49.57337358712594,-71.99442926054203,79.76781219131087,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark12(-4.963023430191967,-54.51713727744292,0.19405310734454595,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark12(-49.95604698556744,-68.28217074411319,-44.89439780396556,-0.9999999999999982 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark12(-50.0199452029058,-27.05433398965485,-7.381916648687479,1.0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark12(-50.05852224556867,-24.549176106640036,-0.920702740828993,-80.23436922496188 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark12(-50.130801356165186,-63.314219470879955,0.9140193651741432,67.96037857533929 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark12(-50.180463195203316,-2.3339719318633225,0.0,-1.0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark12(-50.19281416462164,-15.05735328452832,-0.6086511765135653,-46.3501692233275 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark12(-50.19597053959075,-7.606539065418278,-26.060382640304198,1.0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark12(-50.24541127898793,-17.673481616586017,0.0,0.38638315859206895 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark12(-50.26608949991228,-49.7848162995753,0.029485004820404268,0.316458526941386 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark12(-50.27301434653937,-35.03953711243864,0.0,-1.0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark12(-50.413353319229934,-78.66748226985355,-0.9400191443672392,40.30402136047525 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark12(-50.46230019477838,-99.73946721435237,-1.0409922703892294,1.0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark12(-50.4874139316255,-52.67607275530252,-0.03898515160311666,0.6964474412883159 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark12(-50.49803762691112,-14.369050409402291,-3.552713678800501E-15,-1.0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark12(-50.54305211991188,-20.86280123703716,-80.43580751939443,-2.1084395886461046E-81 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark12(-50.68490474627215,-5.7761987781952655,-1.0,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark12(-50.88832810839303,-61.16012325971593,0.07462520388316979,0.0015933675995614652 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark12(-50.9066627950409,-62.959577928242446,0.9724299640312922,1.0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark12(-50.97427448789329,-48.19613379583263,-1.0,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark12(-50.99314644710255,-59.82458516730255,-0.8543521625387858,1.0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark12(-50.999718348327804,-33.388292913991805,0.010880031144965246,-0.9716496826348666 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark12(-51.004693433583206,-30.851968919821402,-45.95353558260422,0.7373505464089884 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark12(-51.02362814377874,-14.939604309784048,-3.2944368572595385E-83,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark12(-51.11025574235624,-39.415170222997986,1.0,-46.61520265671702 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark12(-51.11637716585895,-73.47332052463341,0.0,-0.9582003811586439 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark12(-51.15916685888584,-68.89184185362105,0.0,0.9999999999999999 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark12(-51.402806947522606,-77.56361581890113,1.0,0.47155794598985 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark12(-51.49855354163222,-56.25861367609918,1.0,-27.296060495575833 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark12(-51.51644911286904,-26.515442883545987,0.0,-1.017504098354232 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark12(-51.529908603866154,-6.181187665145346,-0.9999999999999996,-0.8841988110724996 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark12(-51.585288769002574,-72.34914990651826,-0.3981826718864704,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark12(-51.64407397627249,-1.616598339367957,0.6270480722899969,49.901458763117716 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark12(-5.169765143190801,96.77632442250578,0,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark12(-51.804944460841185,0,0,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark12(-52.010796245182654,-95.45155799275132,5.551115123125783E-17,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark12(-52.03540333847345,-100.0,1.0,0.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark12(-52.1924673538467,-71.67163227312928,-0.03138151160613505,-1.0000000000240368 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark12(-5.224239748602047,-31.332818484562722,-70.0820339942666,-0.05173810482306865 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark12(-52.281689600840345,-62.26045918688355,1.0,-0.8894094090614802 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark12(-52.29298638202445,-8.034799073726528,-1.0,73.13495235971472 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark12(-52.58099018129502,-11.502359543823582,1.0,-0.05334796792714154 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark12(-52.69729094272958,-119.1492514339768,-0.019508565377679216,2260.7799326945765 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark12(-52.761645763981335,-81.84461202322348,-0.9999999999999996,1.0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark12(-5.278721924621557,-9.611690824737845,0.0,-0.8021359925887168 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark12(-52.78958734808401,-91.18642381185273,-0.05093402188255759,-1.0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark12(-52.83333649895805,-57.71781827077276,-0.9178575132489513,-1.0042612500920739E-7 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark12(-52.838300999654294,-85.52633810036126,0.0,-1.0000000533411553 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark12(-52.87232150137306,-16.774187594523717,0.0,-66.7953916176542 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark12(-53.168826445244676,-18.253659850894906,60.38060994254849,-74.3012155989051 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark12(-5.319714348987494,-23.092314008391472,1.0,7.105427357601002E-15 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark12(-53.25649632283598,-1.3969378601949702,-1.0,-1.0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark12(-53.38553231389589,-100.0,0.0,-1.0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark12(-53.4854591849999,-14.201120332378853,-35.084474805849666,-0.03655779759689195 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark12(-5.351476484490702,-65.2883951905625,100.0,-0.3766085688074119 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark12(-53.535703183254874,-51.95733594212986,0.0,0.0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark12(-53.63750709088566,-77.94227754373455,-94.87421684243938,44.18513389698572 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark12(-53.681576905122654,-60.525392811780954,-1.0,-0.6616789730791788 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark12(-53.701305457090086,-99.96173535588768,-68.57343843328371,0.0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark12(-5.375054161145229,-33.16809406695853,-0.034446590316033955,1.0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark12(-53.75105361757675,-12.6130914580364,-8.24901431761447,-0.3755916220983424 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark12(-53.78940317059416,-45.24749817198335,-1.0,-0.6205706780590727 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark12(-53.81896939672834,-54.03363975390707,-24.18546397677595,-58.37764165065524 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark12(-53.9125838031219,-169.61338341316352,0.0,-0.9699007326152551 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark12(-5.392352422577233,-48.27533838137543,0.0,-0.2601093973444649 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark12(-5.402767761050216,-93.34367685725296,1.0,-1.0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark12(-54.04215480152619,-67.8148983110336,-58.4665004070984,0.0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark12(-54.179539225744634,-46.819810431923,0.05418013820467571,5.77800630937859 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark12(-5.428262793754156,-10.285436555121501,-1.0,-0.49351000383785326 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark12(-54.29006262912719,-33.9409143854549,-0.033907081528291416,-0.25212818997760456 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark12(-54.39427507445549,-100.0,-100.0,1.0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark12(-54.424062391257166,-81.34877923701845,-1.0,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark12(-54.42612230952514,-73.94908711735077,-1.0,-1.0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark12(-54.43734730938894,-27.374944485951335,5.551115123125783E-17,-1.0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark12(-54.45062428707556,-72.19230750089709,0.2048667040836487,0.06037546505262603 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark12(-54.5344316892198,-9.580215124331676,-0.9999999999999982,-1.0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark12(-54.601026811054986,-92.9178475823272,0.8345212816258205,-27.438075336672995 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark12(-54.61988027135454,-31.646959909495067,0.0,82.5511807478612 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark12(-54.683173932173524,-77.56912409234053,-0.08646525786625325,0.0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark12(-54.92407283045464,-35.17111908467663,-0.1353705784154382,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark12(-54.94493240546207,-51.5443872831067,-5.10843788099392E-7,0.21309429926031065 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark12(-54.95328204286813,-98.1252355903815,-0.9999999999999964,-94.69557814541952 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark12(-5.5004908154082885,-31.467991625790663,-63.516685436470254,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark12(-5.50160727593545,-74.52431904553632,-0.23118571307641567,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark12(-55.04745717323813,-28.134933524176446,0.6975744345052084,75.92730827240084 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark12(-5.506128057978188,-60.64232327025461,0.0,-0.05885235467544296 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark12(55.07450914104544,0,0,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark12(-55.07800463958107,-93.56024475388128,1.0,13.655060367274146 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark12(-55.079222602410795,-25.789976825191424,-1.0,13.031725894782799 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark12(-55.27294127769581,-41.413313466439604,-0.8959679526461779,1.0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark12(-55.28069455127318,-46.16213435980288,-1.0,0.9573533678079169 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark12(-55.347011109562274,-1.0000802540576903,0.9652687204810663,0.6031852952715936 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark12(-55.41487537799753,-73.3049786398511,0.0,-1.0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark12(-55.6388853168591,-100.0,1.0,-1.0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark12(-5.566923953938294,-100.0,1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark12(-55.6713620872745,-20.116029389683064,0.0,-1.0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark12(-55.843936979104406,-100.0,-0.01970666257791398,0.7545892190118155 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark12(-55.871064817641944,-31.04598375072743,97.15904063791717,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark12(-56.12106004384299,-85.11565022916498,2639.5415981510305,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark12(-56.25776480121779,-5.061691375741495,0.40166686047502687,-0.6294355220148797 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark12(-56.28057484029232,-18.774196147350224,100.0,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark12(-56.44153296746206,-38.04717925445158,0.0,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark12(-56.44335303028305,-75.03384900074855,-29.168007189602918,1.0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark12(-56.53101851704161,-30.066807313313817,-0.03713026495199667,1.0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark12(-56.68029084190707,-16.731418775221893,-0.06193460217072389,1.0809317766196043 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark12(-56.732014586880155,-38.37266399411023,1.0000000000000036,-1.0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark12(-56.83341781982979,-7.563473440547568,0.0,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark12(-56.928919774610605,-100.0,1.0,1.0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark12(-57.10043623488284,-71.67293911092118,-1.0,-29.702497074409745 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark12(-5.714789330527086,-45.90619866379111,0.0,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark12(-57.28845560436954,-98.85907264392695,1.0,1.0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark12(-57.3513256056998,-61.54345812665056,0.6226585469230181,-0.10721390800573882 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark12(-5.745772599707742,-26.23966119940955,-1.0,0.8189524706358328 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark12(-57.46617002143401,-63.283388898811296,9.735101293438518,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark12(-57.63366820668739,-50.458568953903125,0.05434965235855582,-1.0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark12(-57.656755801219155,-30.55235623523854,0.2139801427297927,-0.4273960759605884 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark12(-57.674609939555936,-19.37280690564456,0.0,1.0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark12(-57.67581323106253,-85.12158630697968,1.0,-54.86303150627443 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark12(-57.71857389020943,-100.0,0.0,-1.0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark12(-57.798634190852205,-67.45103970689249,-73.41603168180603,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark12(-57.89335344862428,-40.548705164502934,1.0,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark12(-57.94044841917936,-78.14365489784771,-0.6342834442947165,68.06707356562646 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark12(-57.9414570255725,-59.92954129916237,0.29677988649670684,12.065042529730022 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark12(-58.087455829137646,-100.0,1.0,0.999999999999998 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark12(-58.15819510359469,-50.10818619391488,1.0,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark12(-58.2038625510617,-24.552414920475414,1.0000000000000142,-0.06259753454380372 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark12(-58.23299191382553,-78.11534027290163,-1.0,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark12(-58.37026465352622,-45.75864135671526,0.9894237147536113,1.0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark12(-58.39222257598595,-100.0,0.9998961130722256,-0.7051417039070791 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark12(-58.48188486123845,-35.24453179740536,-9.105970221029924,-1.0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark12(-58.52490718793425,-23.34241689275925,0.3023932806702697,37.94697428535945 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark12(-58.62340203103716,-84.1410538968591,-1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark12(-58.71492350786542,-86.24227787292651,-0.04024056212436544,-0.06263525266264389 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark12(-58.718859193182425,-9.292038528687767,0.048624373079409755,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark12(-58.9853965525518,-76.63495391810915,1.0,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark12(-59.03018733799646,-18.45643809401072,-0.9580475084846989,-1.0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark12(-59.04393115119488,-72.74019123489992,-12.426528169266547,-0.5204484575453863 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark12(-59.08555631338281,-48.633816289565374,0.0,-1.0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark12(-59.12028390090697,-26.762544652457017,-0.05956770126641264,29.076540708189615 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark12(-59.15493843158639,-64.57271018534593,-79.4265405823171,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark12(-59.219213560429495,-64.37739303278019,1.0,-32.4018804782211 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark12(-59.2882767558657,-3.05551761694464,1.0,-0.05907828882984323 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark12(-59.443280094841036,-8.883784212797933,-1.0,4.440892098500626E-16 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark12(-59.4523256289261,-78.80333070481619,0.0,-1.0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark12(-59.62985881090452,-1.0,0,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark12(-59.67931768528125,-63.96917002905871,-17.729682893315296,-1.0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark12(-59.83775023024799,-2.5239018648057225,1.0,35.1871771532242 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark12(-5.987196166922697,-54.699307739779016,0.0,45.61348097741469 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark12(-59.8737361932669,-20.979286934626405,-0.01790648881978829,0.0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark12(-60.01652772354602,-52.75621505178528,1.0,1.0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark12(-60.07045113226201,-11.094760468087694,-0.06169070731882526,-27.804769941182276 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark12(-60.142031844932326,-15.811747117469661,-0.05774902280800179,53.543933017629776 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark12(-60.20825079235954,-98.85786703845778,1.0,-1.000000026684848 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark12(-60.23913294292131,-54.75200073661028,1.0,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark12(-6.03000763296955,-29.204724008335354,-1.0,1.0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark12(-60.34549997715602,-29.171088487164397,-0.22313253807376676,1.0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark12(-60.34657198039061,-46.442978175268024,14.411141592923315,-1.0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark12(-60.38509620460876,-6.553251284762375,-0.8065829612305704,-0.7977353134785898 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark12(-60.43182245903518,-53.2254666477989,0.0,-1.0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark12(-60.8133351198333,-72.67752486213791,1.0,0.0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark12(-61.093011981616364,-6.124931005945157,-75.45017397444752,1.0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark12(-61.09413658347126,-6.959921911684535,0.9882054647399796,-0.9960400091777817 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark12(-61.10751962855635,-98.27900674433113,-0.025082475303871976,1.0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark12(-61.10832477004492,-87.08891688218381,1.0,-59.580084937618764 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark12(-6.124424200318373,-17.326333356029394,-0.8661239096501392,1.0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark12(-61.25259126599182,-78.72642366137647,0.9999999999999991,-1.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark12(-61.615004167284916,-10.808373542131648,-1.0,-0.004296169675776285 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark12(-61.63572368969372,-28.0976435989481,0.9772886262725908,0.32797784530072405 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark12(-6.1651928852708195,-83.01969462241811,1.0,-1.0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark12(-61.86529002269295,-100.0,0.9999999999999982,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark12(-61.89382337729543,-92.830627338089,-40.65846568769808,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark12(-61.96387647798021,-2.665911699675803,-0.7137352320815733,1.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark12(-61.985385685245916,-100.0,0.009565860432581008,0.5866651417772215 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark12(-6.200686289535625,-100.0,-0.3238960074492477,1.0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark12(62.08409184648676,0,0,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark12(-62.11031496037172,-31.555471036895263,-78.20721695545936,0.13494104965950537 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark12(-6.21145622296218,-62.65132604861895,0.0,-98.39060818807138 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark12(-62.32260790379612,-18.32293878237197,-0.008145259551410117,-1.0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark12(-62.32285458205593,-1.5463050733895187,0.015199901143976758,0.16561079293632397 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark12(-62.45119827956749,-56.613846908038376,-0.8838619546150358,-93.95470688915269 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark12(-62.573136452763556,-58.991226681473755,1.7763568394002505E-15,0.21950846029024262 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark12(-6.257601151771961,-35.35060300046523,-0.9999999999999982,-38.0286902090089 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark12(-62.69549619999131,-1.4441069741928168,1.0,19.708679791724478 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark12(-62.71787210866013,-59.19273554813435,1.0,7.829309818357075 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark12(-62.74100444484017,-73.1353975180593,-0.5849529938483937,1.0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark12(-62.7561851090676,-57.02631025033944,0.455334951180846,27.501249246903612 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark12(-6.275829486386541,-57.21039431398903,1.0,-1.6016664761464807E-145 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark12(-62.76355595524126,-53.00823941086086,-0.9999999999999839,-1.0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark12(-62.90549471768758,-24.18726365569985,-0.05512373941680405,1.0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark12(-62.956339256091745,-30.908523048550002,-61.654944538928234,-1.0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark12(-63.01754554564692,-31.247202793782655,0.010441868894573807,1208.2034203890303 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark12(-63.31683032262023,-81.41577170708509,0.22852982331695804,-0.566360441184762 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark12(-63.3483037356941,-59.702628645371774,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark12(-63.382698892546905,-36.545440421225884,-0.039468148884926724,1.0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark12(-63.38874691781268,-53.68464735223594,0.9764659763143362,17.886903691765923 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark12(-6.33984239778277,-82.22490565498697,0.03841937684862057,-1.0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark12(-63.43917429573171,-14.752213337316784,-0.6809880764554053,80.56528195784756 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark12(-63.544638280917916,-56.70135938824959,0.9529147691924661,-22.18730028003265 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark12(-63.5628079989827,-9.794582678849835,0.06254104336586108,0.11007327305444725 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark12(-63.762169994647316,-7.533149652933652,0.38315888849018975,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark12(-6.37665191825441,-39.25549135040014,-62.060371541982164,67.95884282291274 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark12(-63.79802402505037,-100.0,-1.0,1.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark12(-63.85094580507968,-99.99999933504488,-2.066914744396172,5.293955920339377E-23 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark12(-63.98543796880529,-7.280158396137921,-58.450841429329216,-0.7504433697581767 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark12(-64.00064013418091,-27.254325366741078,0.05372799479325574,-47.37699655198196 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark12(-64.08980983326472,-11.231440647346586,-0.057973749577912445,98.5510894708014 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark12(-64.09311800210065,-85.00898522862713,0.013998966877023239,1.0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark12(-64.112729662806,-100.0,-0.38890653077391707,1.0351861419489794 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark12(-64.11902584668348,-29.869353591030745,6.342990767000256,-0.19703413348050478 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark12(-6.420461304734729,-51.02496272774584,-58.631723441485704,-50.140006361428256 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark12(-64.24272081408174,-50.22728057145905,0.02220810151431235,-1.0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark12(-64.3851563227137,-109.94165626579894,1.0,-2312.698874848523 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark12(-64.42555833366852,-100.0,0.0,0.9999999999999996 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark12(-64.5749388258592,-25.71548678165368,-0.04585062105071014,-90.11611369197881 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark12(-64.670961246399,-91.8803948836552,0.0,46.455058577550886 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark12(-64.74190531768943,-42.9370113598324,24.70780207592693,-1.0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark12(-64.7468337226527,-98.40821453866388,0.9999999999999999,-1.0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark12(-64.7615573004638,-4.219706057752869,0.0,1.0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark12(-64.7727627361596,-33.09861706592736,-0.3718862586063857,-0.4182286453804891 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark12(-64.86933538502319,-21.054121766510743,1.0,-100.0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark12(-64.89874507798268,-37.93546405669652,-55.37241645826265,2055.745349403299 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark12(-65.06841872414859,-28.502642934319358,0.01934062867611952,0.3150782403549948 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark12(-65.14964489888003,-67.99612323952567,-1.0,0.4883922167616175 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark12(-65.18909988447757,-17.143414397941754,54.77078630457265,-2395.601882505814 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark12(-65.28651065823834,-45.12304941451512,-86.07729926764284,1.0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark12(-65.30416205623676,-29.57026723886552,-0.009654815739220349,-100.0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark12(-65.33174863075274,-100.0,0.9636000917332841,1.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark12(-65.43292898041886,-15.17154226831734,1.0,-1.020031343112546 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark12(-6.54349935849246,-100.0,-1.0,-1.0000000000000002 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark12(-65.68129916152336,-24.193514360034968,-0.39831640727074014,17.9714222220298 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark12(-65.72992733457042,-15.23749188035859,-1.0,12.888929760027072 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark12(-65.88012120605055,-34.693140736240814,0.058620152040057494,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark12(-65.91901790474547,-19.273570045700087,-0.7817322888062807,-0.7276830920863095 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark12(-6.592226245112016,-15.998192256798902,-77.19188196586393,-1.0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark12(-66.0744557839977,-44.35706599649165,-0.04884372100219318,31.270453176012694 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark12(-66.10181297562652,-16.376979122410436,1.0,1.0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark12(-66.11292538033416,-24.59170932435232,1.8772862738966424E-4,-0.3778468318329165 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark12(-66.23797864305419,-9.21912463680097,0.9562259168780693,66.65560461660417 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark12(-66.24466572092877,-18.4212428425261,-0.5603377753106538,0.028590848406943557 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark12(-66.26779764167505,-15.6655799879672,1.0,-1.0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark12(-66.29198524023548,-13.747425372174963,-0.033090015096708454,-0.4165714665426683 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark12(-6.630057527166457,-2.252381263346763,-1.0,-97.50699608944386 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark12(-66.32824514410002,-59.4515976061755,-1.0,0.6969091481413697 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark12(-66.32841219059098,-7.051601853296248,-19.579876825918745,1.0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark12(-66.47398623800332,-33.93037520586379,-1.0,0.8388749099842521 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark12(-66.54434314415896,-30.390052723367162,0.019174842436003113,-14.632482446825506 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark12(-66.6252997163052,-87.10538927610804,-26.336425541164203,-31.476361621638176 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark12(-66.98441169678085,-26.125741052657517,-0.013436665023879094,2046.289225966529 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark12(-66.98899850409965,-51.567747442811765,-1.0,0.9999999999999992 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark12(-67.03854577982737,-22.33031394983622,-0.9999999999999964,5.344503487054957E-116 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark12(-67.2263072800428,-3.674015026388542,-1.0,0.7760073760413053 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark12(-67.27674928438212,-53.39268186006012,-7.105427357601002E-15,61.431584273533815 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark12(-6.741561172495935,-47.310051185078805,-62.59374872722277,-27.491052117351373 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark12(-67.5507996940672,-100.0,0.9730236281058515,-1.0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark12(-6.76578262385512,-25.114056596917425,0.05032531592759011,1.0000000003455838 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark12(-67.72355350506156,-98.17482506534662,-16.446751326017377,-64.45021744448414 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark12(-67.77224529299474,-60.19347773463661,0.0,1.0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark12(-67.92913007205354,-6.796924627595279,-1.0,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark12(-67.992065822997,-71.71935402088924,0.9769283701946088,-0.0554423992969353 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark12(-68.08782794848092,-153.46054457485675,-0.25527466340686683,-1.0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark12(-68.09402809391213,-5.809439386409997,-1.0,41.536981620585856 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark12(-68.17791557991852,-61.401606285512,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark12(-68.31649444407685,-84.84106313626162,-0.46828128477641906,-1.0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark12(-68.36018629849545,-6.09239871507252,-1.0,-83.02526182472766 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark12(-68.57949026005753,-56.40414979645255,0.0,41.74063776292982 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark12(-68.71046049261416,-5.982554199073917,0.0,0.059106471248058734 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark12(-68.95094159489716,-51.79341418262539,-0.011186073701386164,0.8177972798269163 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark12(-69.1132782845151,-100.0,45.18920088519769,-0.03803813035492404 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark12(-69.13644460916233,-39.5920911460574,18.2335418356249,0.36255249668592326 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark12(-69.1695669511735,-6.09788579126894,55.34205714014854,-0.6198041826747276 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark12(-6.931845980158172,-11.647215606127531,0.0,-34.36443129565265 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark12(-69.33941073761554,-50.61767767157322,0.5038209809322891,47.086210418414666 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark12(-69.44841114572857,-51.75529951115977,-9.594356488583644E-4,1.0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark12(-69.7483415515137,-28.01273692287976,0.0,5.147557589468029E-85 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark12(-6.989918065007943,-52.6549797579594,0.0,5.421010862427522E-20 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark12(-69.92605680977368,-100.0,-0.01358727063749987,-67.50637239919325 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark12(-70.06169143642323,-100.0,0.0,0.06259376200609343 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark12(-70.17394130608254,-34.46715279972861,-0.018023780679050527,-3.203811557944508 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark12(-70.27737090444333,-24.74225228080371,-1.0,-45.6842413238256 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark12(-70.50767443439534,-48.33063883154838,-54.14950197591446,-1.0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark12(-70.59293865403302,-4.43530789585256,-0.031205571541421673,0.5786118996380396 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark12(-70.67262252865184,-100.0,1.0,1.0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark12(-70.81622042321355,-54.93400779422511,68.08583441968622,-1.8991135491519597E-65 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark12(-70.84914321522652,-88.4198768256324,0.010165111609136177,0.08390492523685911 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark12(-70.87081561132473,-124.97752529334728,1.0,2209.603568868698 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark12(-70.91592000010695,-57.1912860690781,-2.220446049250313E-16,64.16109617983543 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark12(-70.92677020945513,-12.318540003934643,1.0,1.0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark12(-71.24333603265184,-4.983575306827544,0.3072378794460092,0.0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark12(-71.4009509652115,-25.717042854472147,0.8103607939505136,-0.0592710255686478 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark12(-71.44172956590408,-51.74743220982737,-0.04285598804106448,2.710505431213761E-20 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark12(-71.45755544571145,-53.60466454110093,-71.28183065778788,45.73644981541736 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark12(-71.57237636001553,-89.42039029803476,-26.49963613400483,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark12(-71.64162407614793,-52.51864940758158,-0.8003941051005075,-0.014199958359788621 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark12(-7.164242287669879,-45.67805545714292,-0.975935117190644,2149.194808806863 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark12(-71.81133713897475,-89.52392714303895,-1.0,-1.0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark12(-71.95172348718052,-1.346632567558254,-0.01915449075588911,100.0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark12(-71.97685777482178,-37.47992743286171,-7.431961667366704,-0.002125223642273244 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark12(-72.10281551235565,-89.89249972507983,0.1345117671802929,-26.393554982364435 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark12(-72.11044239367767,-82.12917512510047,1.0,1.0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark12(-72.38249921307875,-68.24286026067283,0.020591726551989594,0.7632972179956861 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark12(-72.56019741643341,-56.57823194472134,-0.9615438024500043,-62.67399323332787 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark12(-72.57252168838524,-40.704798549195445,-90.49865989542288,-1.0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark12(-72.58881538750941,-47.30428893498428,60.036439124716374,-0.8974119297344363 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark12(-72.64038130736176,-100.0,0.6340401815188303,-39.17969873119735 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark12(-7.26796302493927,-56.70713810390034,0.9086077567916719,0.4778173944821671 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark12(-72.74282911324585,-75.528933156408,-0.9673814231465167,-63.2038241809687 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark12(-72.7697145313125,-18.548008859684604,0.024289837859066934,0.02744767352961503 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark12(-72.8031511112358,-61.971157664830045,-5.551115123125783E-17,0.7602882798600523 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark12(-72.94335229580113,-79.24236696339655,-1.0,-93.24100351011924 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark12(-72.98858758530555,-13.845635802141878,6.938893903907228E-18,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark12(-73.06310565582851,-21.235882423656914,0.0030823739193530514,-0.6202016437301492 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark12(-73.0749803351989,-46.4857602469709,80.48162025716601,-1.0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark12(-73.12452530824012,-38.372287215668536,-53.036645331641814,-0.06267971491625843 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark12(-73.27351801532683,-62.65766668079742,0.8303558171625454,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark12(-73.4309849524096,-67.3236628618128,1.0,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark12(-7.346763514044284,-51.79141944793342,-5.304534372883126,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark12(-73.54425355352151,-40.203526565070334,0.02623823698896901,-61.388299333624474 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark12(-73.68180688074742,-79.72880138166767,-16.037619356229982,19.851825458309634 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark12(-73.69213651192659,-49.591586940711196,1.0,1.0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark12(-73.71268871816885,-27.902230764458693,0.37737231884723965,1.0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark12(-73.7708465298696,-4.765435185518479,0.0321383133446548,0.9999999999999991 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark12(-73.78130509195364,-14.140900508033454,5.551115123125783E-17,0.0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark12(-73.98483284974911,-56.76816866509689,0.3673793983160625,1.0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark12(-74.05959907217864,-24.527404631118465,0.04514857078225275,-9.625471954975527 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark12(-74.16853413735379,-88.19685999049827,-55.7668965495982,0.01815939027161581 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark12(-74.30779911389098,-7.799753369708378,-0.03670872131319839,22.87211609028568 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark12(-74.38670804862515,-42.71402983955409,-0.05068771239473435,-0.30538007754134755 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark12(-74.44731700190779,-98.9554524730599,-75.58752622294644,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark12(-74.44732263859747,-60.438310912380985,1.0,-53.9900560485713 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark12(-74.53814152473151,-13.075013627591785,-0.9153488738320119,-18.77663442448349 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark12(-74.56670736759958,-35.97915722017976,-1.0,1.0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark12(-74.68862801314387,-54.737793715566355,37.868394098132114,-0.03204503778648249 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark12(-7.48674285987417,-87.99266146977378,0.0,0.0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark12(-74.98876816044645,-83.4825558738513,1.0,-70.18060719818708 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark12(-75.0448059356521,-38.32393295249138,-1.0,-61.864157028399845 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark12(-75.17516699773901,-5.3711776794154105,1.0,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark12(-7.546496217652682,-13.403733352126356,-0.002098293268337272,-1.0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark12(-75.49124275049425,-95.81253635209049,0.9999999999999996,-135.39693605952598 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark12(-75.52444178272147,-100.0,-1.0,-1.0031597271686514 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark12(-75.57384104586303,-35.821197720175945,0.9681290275166813,-0.6103997347365708 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark12(-75.70122304633458,-15.022912024650807,-68.68438553125512,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark12(-75.77844806970404,-66.25052169074546,-66.69097579362992,50.48938038357983 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark12(-75.83691567504079,-25.21271866259578,37.70574801244744,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark12(-75.85584543076187,-3.8367244836157823,1.0,0.09238128482343488 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark12(-75.86879513816547,-56.75675687931299,0.35245830058298955,-1.0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark12(-75.91730195587954,-100.0,-1.0000000097299095,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark12(-7.604435872685659,-100.0,-13.676960027732747,-0.22277839879032912 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark12(-7.626865410406108,-83.76824632938836,-0.01711458571878666,-0.0166866387845088 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark12(-76.27463213986454,-67.2996686775769,0.0,-84.46711240041054 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark12(-7.62778378095589,-49.013124083617825,-0.9622796001035209,-1.0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark12(-76.32548725947518,-1.5902884573000209,1.3877787807814457E-17,-61.964263385108154 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark12(-76.53665183458733,-36.193661966159524,-0.4944006995944107,1.0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark12(-76.57327567418244,-100.0,-1.0,100.0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark12(-76.63948038009873,-2.235162562403576,0.0,-19.845671381731286 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark12(-76.70485457080554,-97.05856422775143,-0.539049585530219,0.6385516766540853 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark12(-76.78148338042197,-82.41514763848431,-0.9999999999999964,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark12(-76.82756937968693,-84.67639857040314,-0.08638490582235114,-5.854425202160005 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark12(-7.704213617299004,-22.300935035104022,1.0,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark12(-77.16499770858623,-18.16737588085087,5.191224071867424,-16.945745826433466 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark12(-77.18688167266858,-60.83686330500908,-0.03966081431620431,1.0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark12(-7.7228960504266695,-29.820698674059926,-7.2372255093928715,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark12(-77.49139738532735,-100.0,-0.23539274597475668,0.00197538700457619 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark12(-77.61757349514822,-51.28649230344081,1.0,1.0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark12(-77.63896724560963,-18.12334217557976,1.0,1.0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark12(-77.65948448514459,-40.96841798307007,-84.32247749860815,0.0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark12(-77.66913778860554,-8.481630256256285,-0.006693096215218316,-1.0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark12(-77.78782940837361,-37.21135862397445,-13.800938075345769,-1.0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark12(-7.788560133849799,-40.40154251463679,1.0,-1.0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark12(-77.88867318878762,-100.0,0.957072850214871,-0.6037035777243797 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark12(-77.91300564977143,-56.73006515072543,1.0,34.89367804467665 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark12(-77.92410445423245,-98.21171025685379,0.1804285372997123,16.851739062228745 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark12(-7.794698660956641,-83.31338373634534,-0.05110275140125997,46.42111904757897 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark12(-77.96424337960762,-75.88560550905434,-0.040562561448540986,2.1084395886461046E-81 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark12(-78.00231248682923,-78.87955580278899,0.8498911763575006,1.0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark12(-78.0237615776551,-25.90994186392168,1.0,-0.6768725980243606 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark12(-78.39671745254238,-22.412042431505782,-18.4792635170204,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark12(-78.41317377636905,-50.0405584197162,0.007606666736081416,-0.031420587137661146 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark12(-78.41353474209696,-87.36303271790209,1.0,-27.905982672512238 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark12(-78.5551924154547,-55.13731721640434,0.976365695739816,-0.9781655776772334 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark12(-78.56914269432457,-77.29884960714247,-1.0,-1.0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark12(-78.68364715981129,-21.854906976267564,0.0,0.008062400681816961 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark12(-7.869497592367592,-32.91095616875055,0.0,-3.2944368572595385E-83 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark12(-78.92614988654303,-75.10258619732926,-1.1102230246251565E-16,-71.38743801258262 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark12(-78.93785623667914,-10.175106365011402,0.8652028675265705,-1.0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark12(-78.94129860214179,-75.47091500913777,0.9701636851529231,89.82165015474186 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark12(-78.9734870534613,-58.71676628827649,0.0,48.37063459177213 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark12(-79.01653290635109,-48.15611071624881,91.2348625363268,-1.0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark12(-79.03489286227418,-30.298781041728834,1.0,0.0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark12(-79.11405264521558,-5.717920136390656,-0.2621002858783092,0.9845116429756829 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark12(-79.26637488854367,-14.847915021852572,-0.2690189086610909,-2.044162831177914 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark12(-79.3182197380979,-100.0,-34.47049773836026,1.0000000001920737 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark12(79.4182156742227,0,0,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark12(-79.44225822244206,-12.408377123402538,0.033911598896718576,-1.0691058840368783E-50 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark12(-79.91716809302622,-51.4564410424328,0.016819185057351475,-0.5216804582237999 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark12(-79.98745055671515,-58.64912745121062,2.7755575615628914E-17,-43.17025988087252 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark12(-80.140598583992,-33.68103441767917,52.68290447585396,-1.0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark12(-80.28240674615674,-97.67196369586524,1.0,-1.0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark12(-80.28705296705215,-62.40212276514791,0.43171056145444003,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark12(-80.29913264875395,-24.155181827553292,0.0,-0.31087895892160944 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark12(-80.39322650428184,-44.982887378716576,-0.056889452622745126,100.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark12(-80.49995050552688,-47.8910306105725,-1.0,0.0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark12(-80.70135864367697,-4.310998157655862,1.0,-0.6599227836652671 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark12(-80.83801407034517,-36.08736096363883,0.0,1.0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark12(-81.04261753127513,-66.29514048017671,-17.232518020354505,-60.33994036016823 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark12(-81.16302878462969,-57.40706500936705,0.0,-52.52587389668712 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark12(-81.24382203122649,0,0,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark12(-8.142372864340539,-100.0,1.0,-2127.5021890526705 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark12(-81.49397138755512,-84.64246949834492,0.8757339511571623,-1.0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark12(-81.52246174661263,-100.0,0.4006579413906227,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark12(-81.54528628798428,-15.604198409217412,1.0,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark12(-81.58528930362193,-80.4373044864259,0.1827273344489313,-1.0000000381262184 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark12(-8.162640183602903,-83.3289157006995,45.791207457964305,-0.7453765289259691 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark12(-81.66759837099734,-100.0,1.0,-100.0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark12(-81.69421823523567,-24.93438002212646,16.670509249417265,-0.8501262318084484 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark12(-8.18777457198297,-11.800561517599595,0.0048337859600908195,1.096314270847657E-16 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark12(-81.92678773837855,-64.23635209081782,-73.41166806773252,-4.169271078091725 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark12(-82.02023800192525,-61.56070904830529,-1.0,-1.0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark12(-82.02780173404463,-60.88068279357999,-0.011307997779243276,-1.0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark12(-82.05132838343405,-68.17105407983989,-0.5383978539955617,-0.9898256708903767 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark12(-8.232623708831651,-1.4000734452096282,0.995345362056694,-0.06106100578524996 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark12(-82.38651850452345,-40.27682518853573,0.0,-0.5890649409536254 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark12(-8.239343316052043,-25.211714202142474,1.0,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark12(-82.45050014313261,-94.61433793169867,1.0,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark12(-82.45929912822713,-10.036644882580672,-0.015434845823656451,1.0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark12(-82.53011504786537,-52.29935181644534,-91.51987550881,0.20173453293678456 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark12(-82.58672974588805,-46.01216153084942,-47.239660620882404,1.0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark12(-82.68393345286012,-24.60318218157323,0.0,14.808803723240715 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark12(-82.85135471188842,-70.12698700135437,1.0,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark12(-83.02385309215046,-26.920518096144527,-21.731036099658823,2176.4233738536677 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark12(-8.321273030132598,-27.53923628788232,79.29990004936545,-1.0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark12(-83.22884408673295,-43.484651332625724,1.0,0.03521898241789373 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark12(-83.30825783855914,-62.79181431518146,55.56312650030313,-0.25161048915979567 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark12(-83.33415895661408,-74.74753183226063,-1.0,100.0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark12(-83.36913160590487,-32.07046450081583,-100.0,1.0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark12(-83.37224946950403,-85.36382714672513,-49.2473912873999,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark12(-83.37241372091952,-5.084762867899973,-36.68747937940525,-0.978393690509585 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark12(-8.338031258102237,-94.06240030538689,1.0,16.2316391441158 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark12(-83.47205902077798,-100.0,-1.0,-1.0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark12(-83.63689063882222,-50.256115011453055,0.8400462381700606,-66.43051259589454 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark12(-83.70536150432946,-49.439945432267706,85.4926939890137,-0.22535638046844042 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark12(-8.394241579335715,-36.211891573160386,1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark12(-83.94882491928762,-20.642891215511455,-1.0000000000000018,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark12(-84.0934632555834,-4.022349687161906,-0.03622886106804546,1.0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark12(-8.4138912447627,-43.46599711651755,1.0,-1.0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark12(-84.15519190535834,-23.984738328783735,-61.72134500231954,53.214861792239134 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark12(-84.25853891814903,-22.88631608219911,0.019774566683451456,100.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark12(-84.31158510188408,-50.17342687575491,41.40353964142936,-1.0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark12(-84.33326615988187,-34.20957953218175,0.0,-15.359193679329877 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark12(-84.33328891844518,-68.96942253913332,1.0,71.41456749847808 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark12(-84.42889630562026,-29.28010766900896,-0.7050164032105959,1.0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark12(-84.53304986461526,-68.00035688519344,-1.0,-0.27790387450202175 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark12(-84.78632856936275,-20.125230522953757,-1.0,-1.0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark12(-84.80689841550307,-80.12865185020253,1.0,-5.720484252339645 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark12(-84.88552937167876,-86.53798284407301,0.009436892674888397,11.516143865385192 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark12(-8.488974991678065,-9.553125935610684,-1.0,2.6355494858076308E-82 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark12(-84.90986420921972,-50.65275167997915,0.0,1.000001163717386 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark12(-85.01483371704846,-13.81906181466907,-1.0,-47.637057053161314 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark12(-85.02548255483312,-58.449690110476816,0.04790376655919878,19.889621520030374 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark12(-85.17953345281047,-58.34359396434429,0.0,0.03113966677698876 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark12(-85.53048886921857,-59.56392719240324,-55.591615148373585,-42.02221140322433 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark12(-85.53326971078394,-40.05516758769776,11.236943950193037,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark12(-8.577113185760393,-74.90555852734184,-1.0,-25.78959244535071 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark12(-85.8371530270993,-37.66984427734023,-0.9971622099055963,-1.000000000000007 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark12(-85.94081022299946,-43.601552190074266,0.7036811096149745,0.025987405101058646 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark12(-86.02459967451729,-99.19481645030325,-0.9921081177646265,1.0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark12(-86.04623234094136,-97.88405662493037,-0.02289215611533396,0.01603226666048646 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark12(-8.61346470779308,-58.11836143426117,0.008046599583292789,-0.9997251325921184 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark12(-86.25448638622447,-85.36576234898835,-1.0,1.0000000000000036 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark12(-86.30799590328496,-86.13731190353873,3.844874299204048,-0.7925877888793098 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark12(-86.41518904104335,-27.03384258123431,0.0,-52.54753318346026 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark12(-86.4963231365818,-99.42713155934723,1.0,1.0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark12(-86.6500054936064,-94.35554266811674,-71.00070127986402,35.316091527017534 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark12(-86.65146788284648,-73.14237203248997,0.05176459911110887,-2192.0221573546833 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark12(-86.72017008486172,-11.817720186389641,-0.9693185412698057,1.0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark12(-8.682713083277832,-49.398065100038565,0.05858783418466376,1.0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark12(-86.85313390625753,-65.05864358758436,0.0,32.23825397833559 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark12(-86.87011064289874,-10.85844977716276,1.0,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark12(-86.92480736841881,-37.62801188718426,-0.959231854647461,0.27550087183622196 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark12(-87.308809205548,-20.001008701362636,0.044294937581736187,57.15178810827754 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark12(-87.5610153107202,-57.46504869957742,1.0,59.84572212801987 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark12(-87.65790829767504,-33.02645602684969,-82.53398194233004,-1.0000000050704467 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark12(-87.80012514528153,-48.67362018757296,0.001712348802643593,73.51751902406579 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark12(-87.82396468882254,-187.06983948099102,-100.0,-2398.38170865809 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark12(-87.93266480032915,-80.2841616937493,-63.56203972295633,0.10566544956445156 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark12(-88.02925520114817,-32.83890316370509,-0.036982757197505114,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark12(-88.05342618112645,-63.50641576182351,-1.0,-0.9108288251562731 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark12(-88.15075589429786,-89.30320756513916,0.0,-65.46622362828998 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark12(-88.19126175409784,-68.93151900696157,-0.057461670481792515,-1325.5148383356493 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark12(-88.28112229228756,-28.866383842080197,5.551115123125783E-17,-50.29422792587798 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark12(-88.44469728487351,-10.252736534051635,12.121329164780661,-0.89349817250045 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark12(-8.845510233996322,-1.0358690801328878,-0.02744366894057032,-0.999941990655403 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark12(-88.4813553261854,-100.0,-1.0,100.0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark12(-88.61301733853117,-90.33963109745736,-0.05462769731753542,1.0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark12(-88.6190921894445,-35.38847348609405,1.0,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark12(-88.65355341099598,-36.98012816513441,1.0,-81.9052060983956 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark12(-88.76438836682807,-100.0,0.1875185680535757,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark12(-88.77356002733325,-4.21369189353113,0.0,-56.27645454401475 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark12(-88.88096113209676,-1.2720192456610562,0.9999999999999991,0.012130582457283434 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark12(-8.893971942376998,-81.50160746123268,1.0,1.0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark12(-89.11472299935848,-35.75732290543624,-0.453717370568848,2098.1655701164873 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark12(-8.934805384925234,-100.0,-0.9743816823389986,0.9803533598890614 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark12(-89.43412633275298,-44.521153985011374,-0.3813437598804841,77.2847707824692 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark12(-89.67358377929322,0.6551757487785608,0,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark12(-89.75822315540405,-10.82039421523331,1.0,1.0395409765644899E-112 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark12(-8.994845315575446,-72.7640025358742,14.485124702041347,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark12(-89.9665575412082,-100.0,-1.0,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark12(-90.18173085158433,-38.88005049633927,-0.8753351748117255,-38.54898213488187 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark12(-90.20258164989777,-17.53013958566821,0.05595842562650599,92.57518247181154 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark12(-9.028003913949505,-60.59017595055711,0.0,0.018808218317384107 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark12(-90.31024583870861,-53.63195093828459,-1.0,-1.0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark12(-90.36076591602648,-55.54907405593068,2.7755575615628914E-17,-1.0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark12(-90.50244525041397,-2.4997396811907024,-0.9999060248451223,-0.9890515055538949 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark12(-90.52085807753264,-42.12652576845415,-1.1102230246251565E-16,3.3619440511852663E-15 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark12(-90.54600816853437,-100.0,0.0,1.0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark12(-90.55434599220666,-35.622483607696445,-1.0,-39.21627193804285 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark12(-90.64406661436892,-23.362035352221895,-36.65158354270772,51.56329728616649 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark12(-90.66258923453282,-100.0,1.0,-0.018734741749246192 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark12(-90.82999984648659,-94.09012335189797,-0.03756173301226151,-74.62455030671416 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark12(-90.83159020667003,-86.44066454294163,17.488656563710748,-1.0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark12(-90.90000367349072,-3.9553620717383495,-99.69223519396142,-38.410921321387505 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark12(-9.091831154116335,-3.3334529926277696,-0.8743243188162346,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark12(-90.93437737417662,-88.83498772298853,-92.99753964618054,-94.57758090987289 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark12(-90.94454798298293,-18.806073071820663,-90.69186144850373,-1.0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark12(-90.95901284108861,-18.714852933937465,1.0,-0.7910395151671281 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark12(-90.96083369217583,-19.424939690316563,-0.2747171302688459,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark12(-91.06700234440562,-70.30796355807361,-0.9070933709366922,1.0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark12(-9.110955327737031,-42.95478792926011,78.71406423825164,-64.57042684022872 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark12(-91.18350941784377,-100.0,2.8189242892966405E-16,1.0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark12(-91.27333398614161,-18.26064152202042,-46.314052691173636,1.0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark12(-91.47288676557737,-43.9022505890208,0.05429378377268146,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark12(-91.48498408259066,-36.601947906838305,-8.881784197001252E-16,-3.5466076782269793 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark12(-91.5224501127468,-24.57192215087464,62.945761364277814,-49.54029043348189 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark12(-91.55287432256765,-86.33560664693336,1.0,-55.409187857304204 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark12(-91.58508064861998,-78.91171337912678,-0.015860906661912644,0.9239665002312427 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark12(-91.86705597599637,-78.39488798224147,-19.83542090589781,-1.0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark12(-91.9448335043607,-44.06274090273779,0.0,29.78818477372599 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark12(-91.95006534828968,-33.141537206589916,-0.05346002565510058,0.0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark12(-92.48923992913068,-61.61722725501186,0.06252901152955026,1.0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark12(-92.51656191808084,-128.48057304736182,1.0,2256.257876011292 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark12(-92.79552554068567,-25.21945761729056,-1.0,45.188440027967616 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark12(-92.8776611757182,-61.49840320251501,10.140062683901235,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark12(-92.94451688975312,-8.6147297989316,0.0,-88.35041792727685 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark12(-9.305621681525231,-24.05750063382753,0.9999999999999996,-33.34021851582363 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark12(-9.314103928469855,-34.206172300972376,0.013916450256617115,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark12(-93.32138566749548,-13.917368732663558,4.440892098500626E-16,-0.8619454125222976 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark12(-93.47649337402065,-10.27597056607265,-89.04080557382528,3.2944368572595385E-83 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark12(-93.50160031431128,-4.210226749661909,-0.9343798555198625,24.91530517743221 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark12(-93.5442654231624,-9.43591328191615,-0.04105261579546554,-1.0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark12(-93.7747689967428,-19.039570922342634,0.5351577149596478,-1.0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark12(-93.81002635096505,-92.05657379498412,-0.06084732321890848,-21.095480814928578 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark12(-93.83453408525561,-49.735349163820274,-1.0,0.951914102071216 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark12(-93.88894979608543,-65.73426040647088,1.0,-0.13040353627075174 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark12(-93.90510383841466,-50.33017969642519,-7.47352307764305E-15,1.0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark12(-93.92002029615587,-62.320023926473965,0.0,-0.9999999999999996 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark12(-93.96823929154272,-66.74488763715931,0.0,-99.35652356272422 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark12(-9.406539315101654,-18.65987305526255,0.052928095123355834,-54.11815291237345 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark12(-94.10504493335287,-8.708588136300502,0.05697893832483474,0.9999999999999999 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark12(-94.24143258051585,-66.14949536583809,-92.78478142537976,84.65640777677609 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark12(-94.29013311989789,-4.922537133308108,1.2513019344894381E-147,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark12(-94.52879463888509,-84.13750285068713,0.060820330317545024,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark12(-94.74627903123879,-41.08169346168435,0.0,-0.07623405305307102 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark12(-95.01000639818673,-95.27963510183294,0.011557584611433469,-98.3766837940346 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark12(-95.14716111789264,-92.5886592244679,-70.63396645763247,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark12(-95.36314019227046,-89.63481088936321,-2.372820940997272,48.62858673180966 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark12(-95.96891248002602,-100.0,-1.0,-0.014154787387411494 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark12(-95.99909451086486,-36.30925351725563,0.37542225824292075,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark12(-96.01764982818248,-76.22033832317152,-76.51287932499652,0.06271528869347776 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark12(-96.13390319450798,-50.74874791732786,-0.022656659444228594,52.2363914447038 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark12(-96.14696393684287,-69.94183970506796,-1.0,0.05491268622554346 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark12(-96.23243161132626,-4.180694711562897,1.0,-1.0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark12(-96.60592504826579,-86.08627451337964,0.06140407437202799,-82.27016085016587 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark12(-96.6369109997783,-68.54949465321201,-1.0,-75.71093243716909 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark12(-97.02099510702104,-97.82228238314396,-1.0,1.0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark12(-97.1005048761641,-20.66417379016536,-8.881784197001252E-16,77.22679724787902 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark12(-97.13435751323186,-12.883928802366512,0.0,100.0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark12(-97.31905387950526,-40.06321920767864,1.0,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark12(-97.43294332922365,-15.341071223603741,-0.05119209664723209,1.0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark12(-97.57168472659147,-2.136534759945163,-1.0,1.0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark12(-97.62730130052142,-100.0,1.0,-1.0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark12(-97.64124125213908,-100.86255019625699,0.0,-2350.907021412097 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark12(-97.85461948323677,-99.72876585519087,0.022621355193272637,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark12(-97.87641303612041,-9.934624818788704,-0.44210886283828366,-0.9607244438711953 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark12(-98.16327937727662,-95.21486350080657,1.0,-1.0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark12(-98.20296761803905,-63.223001842020764,-1.0,-2261.0500640222995 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark12(-9.841596941057327,-19.046749937618152,-0.9622788740541357,-73.63115038859631 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark12(-98.46623536741976,-59.5751630531934,0.0,-0.9033371683938045 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark12(-98.65110789486683,-100.0,-67.5388881475081,0.24781813074853365 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark12(-98.7148499378748,-1.453152701232412,-8.881784197001252E-16,0.029650350346180042 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark12(-98.79407510825615,-45.335665961700066,0.9998322200889308,-0.9947002439889036 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark12(-98.83834399651181,-53.74164226388962,1.0,0.9999085774212261 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark12(-98.85161188430423,-20.02936831975535,-0.897496454828772,-1.0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark12(-9.892427314712563,-85.91369316303133,-1.0,-0.9999999999999858 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark12(-98.95598108016728,-100.0,0.9738789931217035,1.0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark12(-98.96975289902879,-11.374469216973585,0.14361813466156936,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark12(-99.07496570330656,-25.111789210506583,0.027777975477823874,-0.9463256961948091 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark12(-99.09350013652629,-28.561427974472352,-0.6922990956203121,4.785535872311522 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark12(-99.10719619518522,-51.643094083603394,0.7673138393574996,-1.0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark12(-99.13587006270161,-94.45321880483792,-100.0,-2272.2064828046546 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark12(-99.20039872739171,-13.900608281600661,-1.0,0.19016357954272411 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark12(-99.37846091322314,-73.17111238862218,-90.83365204394968,1.0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark12(-99.4458850396363,-86.5437982243728,0,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark12(-99.45752933557816,-100.0,-0.004239250699787478,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark12(-99.63756886586155,-100.0,0.7886891872723584,-100.0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark12(-99.70013632884715,-95.04436912401559,-0.9689913641010393,0.5313169672742766 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark12(-99.70703795731697,-15.774052275348293,-0.005550105322683407,0.8374806632813965 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark12(-99.96627032108407,-100.0,1.0,75.75651809922441 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark12(-99.97457073564671,-59.45830131428409,0.13772786046667093,-1.0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark12(-99.9961278433726,-27.362112398968506,-0.012079902406063462,-1.0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark12(-99.99999989099689,-60.894286872302956,-0.9891662599011359,-0.05125905295395411 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark12(-99.99999999999999,-100.0,0.891498074046418,1.3177747429038154E-82 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark12(-99.99999999999999,-90.41020874314671,0.9999999999999872,1.0 ) ;
  }
}
