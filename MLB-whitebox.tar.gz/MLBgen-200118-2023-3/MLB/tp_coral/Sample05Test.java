import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(-0.0011847968829671075,-35.237749225646496,-0.8744898200626487 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(0.0013118183833805829,-5.551115123125783E-17,0.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-0.0014600278270595916,-1.1277357156985128,20.98864358116714 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark05(-0.001502070556951396,-1.5707963267948957,86.39379797371932 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark05(-0.001515978697161191,-60.28803697910596,-1.5707963267948966 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark05(-0.001854310746078042,-0.12470443459648833,-36.31855905616133 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark05(-0.00193621768462288,-1.5707963267948966,-0.2913863103059337 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark05(-0.0020862996567728854,-48.289851235696275,94.25529462685184 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark05(-0.0022372524777118773,-1.5707963267948966,-6.283185337238127 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark05(-0.0022417509403341363,-1.3552527156068805E-20,0.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark05(-0.0025247551217404975,-73.098337002341,48.80671531052043 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark05(-0.002677653479380266,-129.74116957675471,-1.5707963268012757 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark05(-0.0029327044445168907,28.70353755569781,1.5707963267948966 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark05(0.0029728457172887527,-54.16618867204171,-1.5707963267948966 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark05(-0.002980898039231106,-35.7897234311104,-1.5707963267948966 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark05(-0.0029845521531662498,0.6259265947090337,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark05(-0.002984711780479672,-2.220446049250313E-16,1.4858922962150003 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark05(-0.0030866773663148633,-1.56714469278098,0.40245405356166597 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark05(-0.003160603060145206,-3.457212528731338,369.04948774114916 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark05(-0.0032011064252088772,-73.53110553744251,-61.626995583160365 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark05(-0.0032714194071521876,-73.40801575410865,-78.94681857246651 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark05(-0.003303599936407009,-85.01586029888726,0.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark05(-0.0033207574144665216,-53.46359048541753,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark05(-0.003356315274473265,-0.031924473418572075,-0.7502182994531936 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark05(-0.0033637085378252886,-1.5707963267948961,0.05881080488515561 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark05(-0.0034366321172408405,3.1416002829844047,-72.48678595297147 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark05(-0.0034577809301994792,-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark05(-0.0035037104324909547,-0.41468222669925886,1.5707963267948957 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark05(-0.003539434553786536,-60.61512955597781,-4.146534795534606 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark05(-0.0035525564761409723,-53.52078630031967,-1.5707963267948948 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark05(-0.0037961262192905965,-3.1824096123821817,-1.5707963267948948 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark05(-0.00387315645285073,-0.3925557031947555,93.2837089588064 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark05(-0.003964388957571586,-10.39751595551462,61.44397887928996 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark05(-0.0039808720586931474,4.141592653720377,-57.060185778044925 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark05(-0.004008574652236265,-1.5707963267948966,57.04741913400554 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark05(-0.004035795090251759,-0.010257523645132775,55.172093675252704 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark05(-0.004065330691512352,-3.3244219294616606,-57.81276701995002 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark05(-0.004199837972675705,-34.59271980333669,-70.14785201457602 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark05(-0.004218900144394411,-4.0E-323,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark05(-0.004326996859417259,-10.960857901743282,-60.13316640525692 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark05(-0.004505837612699471,-1.3540483338315856,71.84542832885825 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark05(-0.004663430093482024,-47.441910769202735,-23.292967513687454 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark05(-0.004672107097685359,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark05(-0.004683407750243762,-1.5707963267948966,-78.42313348028603 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark05(-0.00487876916983096,-3.1416549985952615,8.3795584512699 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark05(-0.005092623245002703,-0.7345605029154899,76.39572327992641 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark05(-0.005259954453463823,-129.73580580383793,-60.908077508395024 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark05(-0.005342953353817494,-1.5707963267948983,-8.111529943979036 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark05(-0.0053543634861383934,-53.6356076515301,-8.10398280959391 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark05(-0.005546446483236878,-3.6439053403483115,11.498073481750083 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark05(-0.0056458699834301546,-9.540097576958026,-33.0723932105861 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark05(-0.005660314352982837,-72.46671447845792,1.5766676900062013 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark05(-0.005877247879356617,-47.392717613156734,-10.081696329738207 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark05(-0.005943186618155516,-22.43069433594288,1.5707963267948983 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark05(-0.006111725460420588,-1.5707963267948966,-13.35139093038326 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark05(-0.006124084236154459,-123.8890313915208,-9.601861082296905 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark05(-0.006449586923870348,9.860761315262648E-32,77.4793585541764 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark05(-0.006531440588462556,-91.99737643200841,-42.95709599403562 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark05(-0.006788345151334498,-4.4026272858551673E-134,-51.510691071382034 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark05(-0.006807645752890721,-67.50354450644245,3.169911909474453 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark05(-0.006827369442831328,-34.97538687112679,0.7930234807058977 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark05(-0.006900730765708932,-1.5707963267948966,97.30630986599547 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark05(-0.006956353282043608,-1.5707963267948966,26.703537555513243 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark05(-0.006968123314555055,-66.49715813948484,-39.14320767438308 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark05(-0.0070141360921887955,-0.8829495311076813,-1.5707963267948966 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark05(-0.007173217434469525,-1.5707963267948966,78.1680134587336 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark05(-0.007242680014509019,-0.4999419674762085,1.5707963267948966 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark05(-0.007306212964299896,-1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark05(-0.007412361263852141,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark05(-0.008043229135400343,-4.142279971009844,-1.5707963267948966 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark05(-0.008077234443984435,-1.3060444167296188,-1.0786501080120492 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark05(-0.00821254153149572,1.1566619930446371,100.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark05(-0.008290063122235902,-1.2559776378247012,7.829826528690725 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark05(-0.008402404053126165,-4.277311520197478,-4.21394801967606 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark05(-0.008467823206654623,-16.800310215716316,-1.5707963267948966 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark05(-0.0084970962101986,-1.5707963267948966,-42.72818533432888 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark05(-0.008513071844256344,-1.5707963267948966,-77.2522883674788 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark05(-0.008742655961028495,-1.3262719428377836,25.95754893295191 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark05(-0.0087805871825086,-48.64078317568285,-71.15350716103283 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark05(-0.008861253656681889,-1.7763568394002505E-15,-77.52507895918828 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark05(-0.008900461489874497,-1.5707956343714649,-207.36948641147097 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark05(-0.008957446977516215,-1.5700291183011024,-6.283307643240717 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark05(-0.009100600023803173,-1.5707963267948966,84.473835693106 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark05(-0.009143048339164846,-0.5763879966894132,-23.13723436179467 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark05(0.009219460704178563,-0.8912741019699829,1.5707963267948966 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark05(-0.009626130686569923,-3.552713678800501E-15,67.34687795293654 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark05(-0.009731458294093127,-0.2119444309186066,-73.24683135397004 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark05(-0.009933600842766227,-60.937508720907054,8.156245725026025 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark05(-0.010158248828454397,-48.169075972036794,22.97657467716222 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark05(-0.010240213409669253,-10.057681613641108,-95.03189781454651 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark05(-0.010350797289703673,-1.4400421670782364,-1.5707963267948983 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark05(-0.01052835031885192,-211.7252434724354,-91.75190669256143 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark05(-0.010600162239380831,-1.570796326794893,-3.1416268828760514 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark05(0.010949935196779347,-10.764135090153792,-1.5707963267948966 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark05(-0.01097931901635274,-1.5707963267948966,-22.29253536792271 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark05(-0.0110021184368293,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark05(-0.01107339207675262,-1.0842021724855044E-19,-73.85673724428419 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark05(-0.01120250148091978,-32.98672286269283,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark05(-0.012041018357068691,-23.43911078293637,-3.1847616923829065 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark05(-0.012363737824359622,-22.177080902725724,-42.79761999507331 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark05(-0.012415940990663898,-191.77138703160676,-84.9455349501804 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark05(-0.012516385329024882,-66.92745113572988,61.11724201073622 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark05(-0.012664236611663281,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark05(-0.012875958817448704,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark05(-0.013062223890766694,-0.19633096219861834,1.5707963267948966 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark05(-0.013113017188283864,-0.03786285968206605,65.99411281771019 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark05(-0.013121942651489804,-1.570796333520148,-132.99974892453758 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark05(-0.013534277282459406,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark05(-0.013626901737857118,-66.81624247945656,96.83689918926694 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark05(-0.013822675058146402,-3.65755965210328E-99,1.5707963267948966 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark05(-0.013862726424713168,-48.341284864045534,-69.4684599144958 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark05(-0.014258266406803282,-1.5707963267948966,0.3212100297973002 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark05(-0.014303684831345361,-1.5707963267948966,-1.5322785259539724 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark05(-0.01452878526257409,-9.603563440337325,116.24803854604139 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark05(-0.014557872268183683,-1.5707963267948966,83.78326626885826 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark05(-0.014599019772135013,-1.1102230246251565E-16,-64.91281976908712 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark05(-0.014715199996299232,-1.570796326794897,-1.5707963267948948 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark05(-0.014865310939811562,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark05(-0.014878057999902716,-8.470329472543003E-22,100.0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark05(-0.014932857257862036,-4.474374594868166,-50.15356449891383 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark05(-0.015430681394269938,15.014595940041012,32.09048462813896 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark05(-0.015532465336045792,-10.74779510562003,-3.1682139947823993 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark05(-0.015791084977120694,-1.3613570781118745,-4.7196504318211225 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark05(-0.01580891230356296,-0.02951369291769744,67.21311116277008 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark05(-0.016025868180523296,-15.707963267948967,-31.055103259517608 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark05(-0.01637080916574174,-3.552713678800501E-15,-1.5707963267948983 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark05(-0.01640968540682916,-66.03655635541952,-59.26431561782296 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark05(-0.01656946107847069,-3.9407234947842227,28.17704047208458 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark05(-0.016615666394148645,-1.5707963267948966,3.0814879110195774E-33 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark05(-0.016949391075453412,-1.5707963267948966,15.868569832105045 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark05(-0.017144183268215703,-22.322689355117603,-12.121126105647171 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark05(-0.0172597833693878,-91.11605994499199,0.9910843407838428 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark05(-0.01734175683933066,-1.5699474273517906,-0.811362430185989 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark05(-0.017355549913690715,-1.5707963267948966,72.95326931473784 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark05(-0.0174140244447588,-16.030772547685686,-8.402913842853138 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark05(-0.01745744197743981,-0.11020819450804827,28.11059331455928 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark05(-0.01760954858414643,-42.132769301731535,-1.5707963267948961 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark05(-0.017655490992982248,-135.63016213589373,26.675138932179053 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark05(-0.017865414185213382,-1.5707963267948966,22.866423303348384 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark05(-0.01820903431668691,-1.0604538055353614,-3.141592668596498 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark05(-0.01834753849926367,6.72489385523829,-1.1424510417187115 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark05(-0.018602317640248025,-40.8790784226952,0.0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark05(-0.01888803748231274,-61.166625448402876,1.5707963267948966 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark05(-0.018938705617159934,-0.5580245358540965,20.421114154680527 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark05(-0.01949084979967676,-35.26894360454364,-33.840840474982144 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark05(-0.01962097306046843,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark05(-0.019684556212728854,-0.0569635971957793,12.568323739360599 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark05(-0.019766853836139298,-0.19575041458815223,-49.6909569210225 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark05(-0.01988374629496703,-60.67337954969787,8.854285379980379 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark05(-0.01992096062488964,3.469446951953614E-18,94.25785479595905 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark05(-0.019987393391250774,-1.5707963267948966,0.6223061656979201 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark05(-0.02007906674538093,-1.5707963267948966,64.17168873788125 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark05(-0.020221138659740512,-0.0229364182332389,-42.17880188488178 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark05(-0.020230472659529052,-1.5707963267948963,-72.64851486857704 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark05(-0.02030657269673819,-3.5879706468950445,-1.570796326794893 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark05(-0.02031412933000893,-1.5707963267948966,53.88097068336448 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark05(-0.020367534437510812,-3.633243151060107E-5,1.5707963267948966 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark05(-0.02101200173521267,-54.35276884924116,-78.95067276780807 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark05(-0.021034774052663022,-1.5707963267948948,66.55323648922061 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark05(-0.021077393308489012,-3.1415926686929243,-71.81284399579594 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark05(-0.021110239520987284,-1.5707963267948966,-10.456092520055108 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark05(-0.021253556986929323,-1.0083047045537015,56.045809862369595 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark05(-0.021399318461970886,-23.290888555197103,-1.5707963267948966 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark05(-0.021418336524340165,-4.470231130687779,-54.977871437821385 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark05(-0.021555677464815855,-2.220446049250313E-16,4.712389639925241 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark05(-0.021635787728286296,-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark05(-0.021949727378658218,-117.8030474890247,-14.568377684322883 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark05(-0.022020386207813325,-0.032949364136380416,4.453886278394768 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark05(-0.022171804939859915,-54.71034913207515,-1.3739680005216552 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark05(-0.02230894967293462,-1.5707963267948966,8.151261879589178 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark05(0.02232366351139119,-1.0371128330049477,-72.42172645098536 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark05(-0.022400228822532897,-1.5707963267948974,48.88026549139106 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark05(-0.022625190036287088,-60.76496899197091,0.06052407438271702 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark05(-0.022915206377186394,-1.5707963267948966,31.96024870908981 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark05(-0.022983629335568963,14.429249919768054,-1.5707963267949054 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark05(-0.023096633160719193,-1.5707963267948948,-13.456576067692282 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark05(-0.023151267013236047,-22.286092542414178,3.1415930054683914 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark05(-0.02318872262647742,-1.487877390812714,-7.853981633980094 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark05(-0.023564110211929834,-61.24179967934462,8.898106573565869 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark05(-0.023571437104859427,-61.19671826000377,-83.93047659368527 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark05(-0.02391411920896136,-1.5707963267948841,-19.463969517502672 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark05(-0.02396133822876478,-1.570796326794896,22.426868977510466 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark05(-0.024200035848204023,-35.685942627300165,48.34854543269566 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark05(-0.024484418727687418,-61.036623350691734,-50.976653751884626 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark05(-0.024612230398870973,-1.5707963267948966,-43.14025992894598 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark05(-0.024758622615379006,-61.192991893318954,53.86102880545134 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark05(-0.02507533232846182,-1.1474714398092116,-55.77021839950624 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark05(-0.02507748879179536,-1.5707963267948966,27.860674921304295 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark05(-0.025191013310503906,-54.73738800418984,2.002083095183101E-146 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark05(-0.02529228769812812,-3.360776745163873,-66.18205278087136 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark05(-0.02529793568473615,-1.5707963267948966,-21.58735829558542 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark05(-0.025594551497299955,-1.5707963267948966,86.30236793393405 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark05(-0.02564456237228658,-1.5707963267948966,-4.875113502276761 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark05(-0.02579623040964753,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark05(-0.025865502565224373,-1.5707963267948966,49.2776449719764 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark05(-0.025942194121130916,-15.796997649756278,-97.43220432788858 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark05(-0.026306227077328437,-78.86033362634706,1.5707963267948966 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark05(-0.026399601742324127,3.149405153595381,67.5153647798658 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark05(-0.02643795004287347,-166.5076208284718,95.06257361086335 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark05(-0.0266274504497801,-1.5707963267948912,-99.62790068032825 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark05(-0.026628241469243363,-48.2173169163472,55.05666824533547 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark05(-0.02675009753397406,-9.71246461386491,-35.82768029269643 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark05(-0.026753907425565715,-1.5707963270972438,-47.04817570334985 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark05(-0.02677903132036258,-66.7009686636979,-27.055529747184245 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark05(-0.02685517109674368,-9.521339541261327,-172.41278079408997 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark05(-0.02690119933219693,-40.88106748886866,55.103385288198794 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark05(-0.0270151122323119,-42.02022773680814,94.49296940058284 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark05(-0.027859072519277106,-29.106568169387845,-42.76443512887165 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark05(-0.027949803145817177,-1.5707963267948966,457.09765123960506 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark05(-0.027980170332456034,-53.484713955229665,49.822484654723816 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark05(-0.02852964487403009,-22.838382803155536,-0.18990931387204313 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark05(-0.02858274596778608,-1.219412652409326,46.24675776367021 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark05(-0.029168160581437896,-1.5707963267948966,-1.5707963356076897 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark05(-0.029196410922119984,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark05(-0.029268225895792047,-3.484490451644419,55.00021158920181 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark05(-0.029300314386181033,-3.5668414756325646,66.19781497186456 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark05(-0.02937847672754563,-0.006201517077345519,28.217280445992884 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark05(-0.029596292081223233,-66.06895423485742,1.5707963267948966 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark05(-0.029965127110916256,-16.095957822149927,21.466304486321533 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark05(-0.030009884608726667,-10.149240052593235,68.65921568197699 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark05(-0.030393401182934737,-123.58384267195869,-1.5707963267948912 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark05(-0.030408168467710214,4.1415926536316565,29.560143926227916 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark05(-0.030453556800431103,-98.18799033659708,14.50090204379443 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark05(-0.030508846425401193,-47.64445446235264,-9.500023811420581 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark05(-0.03057264469488924,-0.07243049639384636,6.533185307180293 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark05(-0.03071160778995008,-41.44728984374573,-45.58399345598381 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark05(-0.030787913841642787,-9.496770331663441,-32.4176196540991 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark05(-0.030794509402665145,-66.12698351038804,-1.570796326528044 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark05(-0.031012451004319624,-54.282693148422446,-97.89272898188582 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark05(-0.031106366212195365,-1.5707963267948966,-1.5707963267949159 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark05(-0.03135018885123559,-0.9618973485516449,-1.5707963267948966 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark05(-0.03179589709736591,-2.220446049250313E-16,396.6885529230559 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark05(-0.03190179160000792,-3.1415926548743416,6.879796349340349 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark05(-0.032179290314091724,-0.7269717796454289,25.714707452063394 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark05(-0.03220823023142587,6.81392890631393,-3.146609583175561 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark05(-0.032262570713811334,-1.4896117145526757,77.48878516602826 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark05(-0.03252600507753147,-1.5707963267948966,-76.96902001294994 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark05(-0.03283306906859123,-98.90881538939828,33.92831688514439 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark05(-0.03297191600078031,-32.38161523390713,-50.51507044030413 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark05(-0.033267034836923504,-350.2728121090599,-1.5707963267948983 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark05(-0.033488728812708944,-1.5707963267948966,-42.94121159164814 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark05(-0.03398982663809106,-0.2689343448330632,-1318.778494915449 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark05(-0.03430576840669637,-78.88096650141392,-1.5707963267948966 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark05(-0.03495630061390549,-1.5707963267935543,-75.93274628172277 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark05(-0.03543943517991302,-0.7644982341899882,65.82720832483596 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark05(-0.03581320976870747,-54.82259303569212,52.4511193020042 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark05(-0.03642015488914768,-0.03672938251969,-41.8914305340932 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark05(-0.03661253639293161,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark05(-0.03668382758131207,-1.5707963267948966,0.04610973930387103 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark05(-0.03673427997497676,-1.5707963267948966,63.49835259221189 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark05(-0.03694142083545564,28.703537555513243,17.966965518426985 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark05(-0.03712150453937579,-3.141593349610615,-77.40894316803929 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark05(-0.03722118469272399,-47.12388980384693,76.26355376318158 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark05(-0.03728478893108211,-1.5707963267948966,11.862901207250795 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark05(-0.03728860696386248,-48.48110581036682,17.035055571692613 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark05(-0.03761249806238629,-1.1622640772181454,89.15349969742184 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark05(-0.037667240958454806,-0.7267840414967139,79.19913053171743 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark05(-0.03768851053519229,-97.79072670291033,-69.38601898751469 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark05(0.03788887318571557,-1.5707963267948912,-1.5707963267949054 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark05(-0.03799261175395426,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark05(-0.0380901632820731,-1.5707963267948966,21.50183900631328 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark05(-0.038466631909190536,-10.10109125321592,-100.0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark05(-0.038968055448803995,-0.14979623375229287,1.5707963267948966 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark05(-0.03899465574366445,-1.5707963267948966,20.601087248203086 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark05(-0.03913205199569151,-53.45573865863585,27.719789656418374 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark05(-0.03951799093607665,-1.5707963267948966,82.59363088241733 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark05(-0.0396048574458856,-41.443240506549714,-82.06736546680108 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark05(-0.03967970146138694,-1.570796326794895,-0.6067066860698016 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark05(-0.03979196114039141,-129.61541687787883,-182.44553859311785 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark05(-0.04013375153751042,-2.220446049250313E-16,81.93354957814361 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark05(-0.04081423336321774,-2.465190328815662E-32,-4.095603927704496E-71 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark05(-0.040948582594217964,-0.016543624354156395,-44.00381062593753 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark05(-0.04124929491171159,-1.5707963267948966,-11.964568658939777 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark05(-0.04147263164662391,-1.5707963267948966,-1.5707963267948897 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark05(-0.04154532374934432,-1.5707963267948961,51.5841506706102 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark05(-0.04165115569311695,-123.12514830036136,46.62676889043547 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark05(-0.04177964683228192,-1.5707963267948966,-4.113346420450718 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark05(-0.0419982804217689,-73.08906215084396,-35.032056960198744 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark05(-0.0425957019763711,-78.82763265634402,-2.778448436856347E-163 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark05(-0.04266591379239043,-3.141719794222702,-71.00910975405456 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark05(-0.04279025356072502,-9.893023647021536,3.469446951953614E-18 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark05(-0.04311219701308637,-85.41113919537872,-1.5707963267948966 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark05(-0.04322493107495973,-4.493714850169064,-48.754434169701 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark05(-0.04332510982036711,-123.00187593180416,-1.570796630568889 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark05(-0.043367973907320896,-4.2451316551427425,-69.47379083114022 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark05(-0.04360950444090119,0.6512692960207056,-23.19470999588662 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark05(-0.043622416897051035,-53.647430031185486,-1.5707963267948966 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark05(-0.043884439338842895,-1.5707963267948983,130.33035778913154 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark05(-0.04416216104797503,-1.5707963267948757,-1.1733076832690572 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark05(-0.04470607547308026,-1.5064748127909486,20.80275314234197 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark05(-0.04504837450096605,-42.04234052903141,-79.44362031668723 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark05(-0.0452286739811488,-1.5707963267948966,-9.913835302014255E-119 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark05(-0.04535936232971921,-1.3629304346565174,-39.39467770920667 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark05(-0.04645380998373468,-1.5707963267948966,65.97363432269566 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark05(-0.04717362563678762,-66.65844237740308,-100.0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark05(-0.04726597331953297,-47.897171263696926,-28.424013657431857 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark05(-0.047336042501247094,-1.5707963267948966,1.5613487758725293 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark05(-0.047385759607681016,-1.2846880954475397,15.821811866276011 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark05(-0.047479398939734865,-1.5707963267948966,78.18509789668516 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark05(-0.04784064635128438,-47.402618588723236,-76.71660981466071 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark05(0.048032403717931944,-78.87435017179945,-6.713253367008582 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark05(-0.04820934520920413,-41.87634304363695,-6.361277455779599 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark05(-0.048405870380049065,-3.3325278436811736,71.17759837782097 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark05(-0.048421791945260334,-10.77289395431172,-0.4682742337561058 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark05(-0.04882364592139885,-569.1127734339589,38.994539166781294 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark05(-0.04890011073803498,-0.8376016893084397,38.479098666215464 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark05(-0.04899490393461378,-0.63106371578998,27.026204509915857 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark05(-0.04921833170563063,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark05(-0.04928554464101323,-1.0391282316893864,16.591976990909032 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark05(-0.04935850169687543,-67.18385315224656,7.853981633974491 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark05(-0.049640421421092484,-3.141592892016287,-27.74514521314276 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark05(-0.04968448870129954,-0.5149266136807579,-60.70834898191538 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark05(-0.05022110266270374,-185.81278103985264,83.56263382906047 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark05(-0.05024346326206994,8.673617379884035E-19,75.47569565161295 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark05(-0.05089741158925168,-488.50896135135133,-1.5707963267948966 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark05(-0.05111504966365976,-34.867865799010545,52.219808318456465 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark05(-0.05136022459942069,-47.47836828994145,139.64504623813622 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark05(-0.05155154801781361,-1.5707963267948912,-95.73280295669598 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark05(-0.05157171676870065,-97.98183422432831,0.0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark05(-0.05198199129641748,-22.22409330729785,-0.5088892462611895 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark05(-0.0521045972100771,-66.4048880115442,-712.1576009079295 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark05(-0.05258777705223852,-1.5707963267948912,103.67473670005961 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark05(-0.05320232137582326,-9.98850049352441,-0.9680132301036353 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark05(-0.05352986569573481,-61.13014917314536,-2.9088320132168803 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark05(-0.053644226480866815,-41.686208202477694,47.115639240190205 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark05(-0.05370441792381879,-3.266593746629429,50.984560490292296 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark05(-0.05420857212512182,-1.419090570918074,60.14440456241533 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark05(-0.05426900619231802,-0.22048981185205996,-54.26345104773458 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark05(-0.0554410532595464,-1.5707963267948983,25.44401166329979 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark05(-0.055965308546319516,-29.435685770741415,-23.26316305111181 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark05(-0.05644347853418778,-66.35440454962074,-80.11064967994389 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark05(-0.05662834980298359,-1.0034767407644472,45.29817414566125 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark05(-0.05663316794713236,-10.34228560430168,-72.12705840962113 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark05(-0.05683590784835171,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark05(-0.057102674376566534,-66.48376506101808,-17.091800916409795 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark05(-0.05784110078784188,-1.5707963267948912,-90.70675013331031 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark05(-0.05788365458263019,-1.4106227576921808,9.532280282571264 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark05(-0.05843597443376146,-48.69460233479856,47.26174805506682 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark05(-0.05868807805103602,-1.5707963267948966,27.797679416229002 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark05(-0.058692794372501314,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark05(-0.05943956419140406,-54.75974632384404,61.077460640329605 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark05(-0.05970643528106702,-72.44318916135062,20.127302410449712 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark05(-0.05995131899508177,1.5135213609052574,-7.8548331017282225 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark05(-0.060456545512851956,-48.3850540037408,-1.5707963267948966 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark05(-0.060809631216043436,-60.526018913677795,-1.5707963267948966 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark05(-0.060962719734768946,-2.220446049250313E-16,89.43797412953813 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark05(-0.06115090501246004,-54.4546340903998,111.60975348581636 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark05(-0.06181286235472278,-73.82291594747885,-0.7245620309529133 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark05(-0.061875174889870245,-1.0899306515952478,75.11908722234963 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark05(-0.06196279272698843,-1.2521619272952618,1.5707963267946674 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark05(-0.06211061607034252,-41.619789318115465,-13.881990989020082 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark05(-0.06242324214919892,-1.3254635018593655,-0.2474654202886126 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark05(-0.06257832603481357,-1.2254319560937108,86.96304658168829 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark05(-0.06266489148430487,-1.5707963267948983,-66.17853252534884 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark05(-0.06277449576555795,-41.033753382304965,-0.8491757182756239 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark05(-0.06289548051610114,-1.4386400236544448,-1.4176448603975307 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark05(-0.06313358571746683,-34.583971202998136,16.17184016336385 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark05(-0.06315989554667688,-2.220446049250313E-16,64.91671017273846 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark05(-0.06371078528395413,-1.042695491079009,4.712399913328277 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark05(-0.06396480778640491,-1.5707963267948966,-16.874801742278756 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark05(-0.06539030568109026,-15.831592274422153,36.17975156358743 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark05(-0.06569726895053757,-1.5707963267948912,-79.24464744791347 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark05(0.0657837517968233,-22.006606137213765,55.2037492312999 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark05(-0.06608277175241994,-3.1484761949946716,64.14315658678245 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark05(-0.06678266684225,-0.30919458878284,0.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark05(0.06678424054117796,-1.0590019030869817,6.323791937300091 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark05(-0.06689106925450972,-54.56859378218025,92.6769832808989 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark05(-0.0672021042485209,-1.5707963267948966,-6.2834925456810184 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark05(-0.06775120343814722,-122.91021159451307,96.81073381360258 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark05(-0.0679236574033682,-17.125089753568552,-66.44639921970294 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark05(-0.06872457272260432,-3.5943253097003893,49.86492901702056 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark05(-0.06887531982326399,-1.5707963267948966,-78.00868688284841 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark05(-0.06896634924183331,-1.5707963267948966,-83.98780469942554 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark05(-0.06902339023090971,-0.9099459847822242,710.1721409373923 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark05(-0.0700431787136604,-1.2432842431039746,4.141592681829901 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark05(-0.07019791874021167,-1.5707963267948966,-0.008379105944448845 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark05(-0.07028689221438693,-1.5707963267948966,46.03034926236609 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark05(-0.07029925834179096,-48.549348485379156,1.0539629678608837 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark05(-0.07035292062617766,-1.5707963267948966,-32.8036110901872 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark05(-0.07055201616485074,-0.2993952865012586,-100.0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark05(-0.07082214895289995,-0.9899111816289359,7.487518760627312 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark05(-0.07099634280388187,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark05(-0.07121858641676443,-1.115655301695856,100.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark05(-0.07128650848750713,-3.93133744724703E-17,65.86242505342358 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark05(-0.07146593915295303,-48.67044390188795,-1.5707963267948966 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark05(-0.0715657175239833,-1.5707963267948966,1.5707963238785199 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark05(-0.07159323600088971,-1.5707963267948966,-12.561914254478015 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark05(0.07197938052498457,-0.0010694018049419354,81.18010137881818 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark05(-0.07198811890993458,-54.70123876243206,89.77246332317381 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark05(-0.07214920848324191,-1.560542330788501,50.33358029276926 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark05(-0.07223626121932619,-0.8933707427825525,-18.93349950949157 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark05(-0.0729254438666771,-34.61362708992432,1.5707963267948966 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark05(-0.07309600506191538,-66.59523277178094,-32.579277751388446 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark05(-0.07310652462397094,-1.3951783170801437,21.54932225508921 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark05(-0.07362370395648288,-1.2565402924959868,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark05(-0.0737162385687997,-1.8661451306085228E-4,15.949455622694671 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark05(-0.07375987912444616,-7.105427357601002E-15,-50.45223907713494 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark05(-0.0739708405801541,-1.5707963267948912,25.953259172507572 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark05(-0.07458690263126755,-1.1840401474709277,61.59545317809466 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark05(-0.07507047143866907,-3.266595263519258,26.886878960239947 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark05(-0.07530788580930427,-0.776552817569753,38.33433710390762 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark05(-0.07552213848931544,-1.5707963267948966,-42.98184461244367 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark05(-0.07552277056570268,-85.21009297695468,-22.456736361230707 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark05(-0.07556098696826945,-1.5691356896800086,-66.60092334938489 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark05(-0.07564412079069599,-1.5707963267948966,89.09398680629006 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark05(-0.07588820680506758,-98.92016127970295,-13.872348675095186 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark05(-0.0762862357166833,-1.5707963267948966,21.70785533838427 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark05(-0.07687138508877006,-35.02335737380077,42.96988301200727 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark05(-0.07738153122924729,-0.3102171680421858,0.8103360956534056 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark05(-0.07766178342906681,-1.3641427794386256,0.4940427280325149 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark05(-0.07768893629884932,-61.08176535598138,6.283224394736914 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark05(-0.07840465473543523,3.141678060827835,-1.5707963267948966 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark05(-0.07847595343388036,-9.544469711584838,42.65315454893013 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark05(-0.07849464998892941,-1.432192596617895,3.1657298782662 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark05(-0.07914212878281991,-1.5707963267948966,-4.712396261521476 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark05(-0.07948821078346446,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark05(-0.08030547301203116,-4.440892098500626E-16,-82.74659718576915 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark05(0.08057193387250672,-3.2871267668388433,53.18726696171688 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark05(-0.08059278589632402,-1.5707963267948966,81.03171066008736 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark05(-0.08063500152899446,-1.5566664742497294,-38.07630229009947 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark05(-0.08076559700946007,-1.494739966058118,68.66303881483495 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark05(-0.08082822021098313,-98.80851329284796,118.17444795916177 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark05(-0.08083496341453522,-97.83274084599007,-10.010290975765718 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark05(-0.08150406638911092,-5.551115123125783E-17,95.24777956191123 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark05(-0.08155881399202047,-1.0052069096623324,70.71144131220446 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark05(-0.08157005725763167,-0.044330434232064245,-4.219086123516824 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark05(-0.08186390117656517,-54.61922263120774,0.0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark05(-0.0818755013979055,4.15318673772503,0.0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark05(-0.08237628785324769,-0.12472868631290412,-78.17141026136127 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark05(-0.08252273185998307,-1.5707963267948966,1.2783936646750268E-15 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark05(-0.08286185766533943,-1.5707963267948966,-50.56152849308815 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark05(-0.08304156103513272,-0.4860389438221624,76.96902001294994 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark05(-0.08317519657384764,-1.5707963267948966,-20.87326133316946 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark05(-0.08364408329739881,-1.0370685764785148,48.9411470945476 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark05(-0.08376534641742428,-73.04795903068262,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark05(-0.08402101946456995,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark05(-0.08430753358573106,-0.9218251546178134,-40.47810229458442 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark05(-0.08501248849708665,-0.1734641266341277,-1.5707963267948966 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark05(-0.08505408468566475,-5.551115123125783E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark05(-0.08574955817060792,-1.128201125816038,-0.0014876345699612464 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark05(-0.0857881990201943,-1.5707963267948912,-55.3389044512284 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark05(-0.0868934763148952,-42.40612414531033,67.1025898488356 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark05(-0.0871692059046767,-98.50358701889337,397.3935070198995 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark05(-0.0872562946360085,-15.842004748093586,-100.0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark05(-0.0873442363264057,-85.06666543509405,-0.8441463543319117 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark05(-0.08832904778669243,-42.13421930998324,88.17470843847212 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark05(-0.08838683760637925,-72.4524327816344,-62.83186844973138 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark05(-0.08857950024785778,-1.5227573714229898,-77.45950583453259 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark05(-0.088594713484324,-1.5707963267948966,-14.883495415718267 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark05(-0.08864422141784811,-1.5707963267948966,51.59973767738901 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark05(-0.08882218060983782,-1.9279358920823073E-180,1.5707963267948963 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark05(-0.08895371861931764,-1.5707963267948966,-69.3060546993617 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark05(-0.08899314816945836,-1.5707963267948983,-38.6634593453675 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark05(-0.08942420156480368,-1.5707963267876122,88.55513593580837 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark05(-0.089533996490549,-8.682651365176084E-165,-85.85282502184852 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark05(-0.08984271899625584,-47.593783430265816,-52.26372381416866 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark05(-0.0899868376503763,-525.5794611407011,71.60119166144719 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark05(-0.09007956380906434,-1.5707963267948966,49.61603282783118 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark05(-0.09030247082115625,-1.1945539833324266,-267.0120673068594 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark05(-0.09051405053522535,-1.5707963267948966,-41.94429920650735 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark05(-0.0907931292277497,-84.916865638807,78.43425229570857 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark05(-0.09080797728121415,-0.9664858599266196,27.373050423996975 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark05(-0.09096464498029677,-54.913764873747816,179.30987738629045 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark05(-0.09156408288688134,-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark05(-0.09197477552659686,-1.5707963267948966,71.19446222611327 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark05(-0.09309361594663366,-0.5996838839361128,13.585390494340107 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark05(-0.09322893365904761,-22.97321928444248,-0.4298327364887101 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark05(-0.09327305071379738,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark05(-0.09335893941377257,-1.5707963267948966,-1.5707963267948961 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark05(-0.09342280976585837,-48.47428996465601,46.355931767204886 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark05(-0.09343372555754528,-97.85169547758505,42.91869035628834 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark05(-0.09368731714019782,-0.37804770335483584,83.443362913448 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark05(-0.09459565296247942,-16.11491713204431,39.75334290524174 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark05(-0.09585953364121147,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark05(-0.09617206615847818,-135.50073089891347,-3.143660154111481 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark05(-0.09661016664090051,-1.5707963267948966,-62.604599254122604 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark05(0.09663409890749045,-1.5707963267948966,-21.93770727413255 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark05(-0.09721186562546129,-53.85944489066923,-55.09374701661602 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark05(-0.09728624695765076,9.860761315262648E-32,-6.983984090689887 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark05(-0.09777043271851518,-5.795813574204844E-20,-140.81854345840517 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark05(-0.09847036474575369,-1.4919605686242527,56.437004490149036 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark05(-0.09954342119590302,-0.6915288467852789,0.0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark05(0.09978617071053154,-67.47545672290312,-55.218946432937415 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark05(-0.09999087685289201,-1.5707963267948966,95.99898679940647 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark05(-0.1002692686184866,-28.288452855437313,-63.57945325110649 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark05(-0.10029629482902669,-0.17778571099847648,-1.5517595061329046 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark05(-0.1003130967861073,-1.5707962187192301,0.2438998284746603 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark05(-0.10061457453608269,-0.5637359872823051,-29.681749959249302 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark05(-0.10099635140176441,-0.9889265765403579,0.20126042305848524 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark05(-0.10130319553489897,-1.5707963267948966,10.446859244395124 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark05(-0.10153921384683663,2.465190328815662E-32,0.4491161961513024 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark05(-0.10166986089979346,28.70353776849988,54.57645067004459 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark05(-0.10221669818233847,-1.5707963267948912,12.83329532755981 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark05(-0.10234612705056326,-97.77085423091052,-8.372016302245683 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark05(-0.10237098607271274,-299.95393926528186,1.9431642458952614 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark05(-0.10286186145274431,-76.61805009393963,50.242168703105214 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark05(-0.10314957329654212,-1.5707963267948966,77.27016652105004 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark05(-0.10320339611944784,-47.51820368960436,8.103985707814259 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark05(-0.10341242014319255,-1.5707963267948983,-99.90233796102805 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark05(-0.10346448771318315,-53.49930108408596,-1105.1591248636541 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark05(-0.10353735358765728,-1.5707963267948912,-26.703537555513243 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark05(-0.10381304827654865,-6.038718444981931E-16,12.320862425027457 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark05(-0.10386609589809703,-53.71013427749223,-238.63807153395717 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark05(-0.1040751791188047,-1.2744068134962376,113.48645566360133 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark05(-0.10413582457859816,-79.02524608405969,1.793811327856757 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark05(-0.10446028142799893,-1.955159272639747E-149,28.40807367153887 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark05(-0.10479887904298772,-79.53313750213348,-1.5707963267948963 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark05(-0.10482130559299807,-1.5707963267948966,77.38145735678575 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark05(-0.10519842797538916,-1.5707963267948966,-8.368744110695857 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark05(-0.10528278871137231,-1.5707963262571492,0.0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark05(-0.1057761507259701,-1.562553526659093,20.609305542435276 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark05(-0.10579813347877354,-1.5707963267948966,-27.986331746959046 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark05(-0.10610096968873961,-73.03049497764215,-50.543176610828894 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark05(-0.10635014730966752,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark05(-0.10758597916191603,-1.5707963267948966,-666.2044560852529 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark05(-0.10777677329320365,-2.5626663618343692E-144,88.14451515827201 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark05(-0.10780267807931879,-53.6308688222715,0.0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark05(-0.10820849353456197,-61.14218160733856,55.34212047278102 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark05(-0.10822930077094146,0.11530242646392856,-26.86724079917117 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark05(-0.1084182322443573,-10.117836003550366,-155.50945730525007 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark05(-0.10863264128978178,-16.02707947458528,0.19756429650699658 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark05(-0.10873549790668552,1.6940658945086007E-21,0.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark05(-0.10940704521756354,-1.5707963267948966,5.4795233725210076E-194 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark05(-0.10962509732050196,-22.44250255400767,3.468743944516782 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark05(-0.10968106979875639,-1.5707963267948966,-14.754970888823008 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark05(-0.11013383907294383,-79.39593943252665,-74.62806035686923 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark05(-0.11013430752506657,-53.943247804917036,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark05(-0.11050447063128532,-91.89856744985265,-1.5707963267948966 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark05(-0.11068550541826072,-1.5707963267948968,-1.5707963267948983 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark05(-0.11081671602179939,-47.696506147882076,-15.743288033003434 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark05(-0.11084192997811254,-1.0169286807357338,0.0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark05(-0.11096813379220533,-318.5248464617683,-72.69331875551848 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark05(-0.11097719644889738,-1.5707963267948966,53.927398033535574 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark05(-0.11106185244532009,-2.220446049250313E-16,-89.51082378789283 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark05(-0.11174993014141266,-1.2915322360840635,12.59786516890013 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark05(-0.1129102941461076,-60.90987429851454,-84.48075325953508 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark05(-0.11296266542148603,-16.068298093365463,-54.88606729080594 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark05(-0.11368711593664052,-72.40761982215244,-36.2204520367258 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark05(-0.11400231535778149,-1.570796326794896,-1.5707963267948966 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark05(-0.11413393205351474,-1.5707963267948966,0.23936044974570336 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark05(-0.11424811949398778,6.954578158796321,21.42286430901193 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark05(-0.11458399425823995,-3.552713678800501E-15,23.737890595214097 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark05(-0.1147790436955699,-1.5707963267948966,26.726449733408934 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark05(-0.11656878132336068,7.888609052210118E-31,0.6652412795595605 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark05(-0.11673881731207275,-0.047432500218484684,-88.41552346888815 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark05(-0.11696229938227862,-35.79220576198526,1.5237669818203259 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark05(-0.11708356966731553,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark05(-0.11717588648322258,-3.142080934919592,-78.58039193310636 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark05(-0.1175861575670962,-0.8364717985866799,-7.853983451367628 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark05(-0.11803525560874562,-22.35817615654262,-34.872302085570055 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark05(-0.11818202146706192,-61.2035181259617,-3.9817727205377764 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark05(-0.11847492234464624,-0.09290342859278482,39.073984167456516 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark05(-0.11848730554142588,-66.27659920124722,-78.48475355599703 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark05(-0.11942267335164891,-61.19258401405174,83.33843296685055 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark05(-0.11985453359525167,-85.0539336542305,-4.004166190366202E-146 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark05(-0.12038248959960293,-1.5707963267948966,19.91596854699833 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark05(-0.12103611343507936,-1.5707963267948966,-27.16659656423235 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark05(-0.12165456175759332,-15.8210598711671,356.74264972826296 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark05(-0.12280865160792331,-47.14919080488423,28.07437364479916 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark05(-0.12328960572733572,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark05(-0.12351652605245778,-85.86534536646344,-1.5707963267948966 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark05(-0.12389552326920239,-135.93227197961647,4.198102765904157 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark05(-0.12418342890615791,-1.5707963267948961,1.5707963267948966 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark05(-0.1244079059244084,-1.5707963267948966,1.5654020331759142 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark05(-0.12459433512989726,-136.36731827910836,-148.4310561252039 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark05(-0.1253262446674498,-1.5707963265847766,0.48065936805646725 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark05(-0.12558857942168278,-0.07352314227300832,64.28015414844896 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark05(-0.1258552707261105,-1.5707963267948912,-7.853981633974484 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark05(-0.12716126317050858,-47.53975260104165,82.4200840136919 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark05(-0.12725051362159157,-1.5707963267948966,-0.005160279239127739 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark05(-0.12741309237415016,-1.5707963267948966,497.74340388153337 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark05(-0.12744882119951007,-1.3198426110693533,6.289629122905238 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark05(-0.12746478813838935,-770.318452953263,129.36230235798294 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark05(-0.1276363307359809,-10.471905242599817,-168.38990421460872 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark05(-0.1278724314678056,-3.164913206097637,1.5707963267948966 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark05(-0.12789903203664332,-61.125732191562804,0.0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark05(-0.12801438945369475,-0.17234849566534055,78.22927877278258 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark05(-0.12805867070962496,-1.5707963267948912,51.41669018749383 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark05(-0.12822411802088482,-0.5704298741689088,-40.12284994369914 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark05(-0.12841510696143937,-104.55560755828964,97.74575683770925 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark05(-0.1284210903071763,-1.5707962341387862,25.87449399042585 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark05(-0.12845882572596845,-9.535997148004071,-23.477494828652777 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark05(-0.12850783539106336,-41.833814551960444,1.5937852476782162 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark05(-0.12865705404111427,-66.31915027972157,-11.966569139546944 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark05(-0.1289248442179779,-0.5887533299961967,63.24608691052788 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark05(-0.12911234968679441,-3.1420499519006766,2.8131334231243246E-17 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark05(-0.12930322214651818,-53.95976880299507,-47.12394414678781 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark05(-0.13016492073175467,-1.5707963267948983,21.599979099792264 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark05(-0.13035069178653202,-1.5707963267948912,54.01459635522281 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark05(-0.1304394928227116,-3.141592898604796,89.37497694334816 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark05(-0.1305094353874602,-1.5707963267948966,-83.40384981708154 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark05(-0.13068169434045765,-0.6856780834281366,-42.17837452959567 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark05(-0.13076505272593011,-0.9160100777835362,96.80761716574168 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark05(-0.1309002122210643,-147.8228485903437,6.283207332566908 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark05(-0.13224351186425135,-1.5707963267948966,4.71238898038469 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark05(-0.13225439385346582,-9.649648960088086,16.04358377201416 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark05(-0.13226253504647423,-1.5707963267948966,21.80037072807721 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark05(-0.1324465600341404,-12.592669456857966,-3.0605730443653805 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark05(-0.13253693906461173,-1.073445113077038,0.002227113176370979 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark05(-0.13261639526057273,-53.57516662101195,28.99919303467565 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark05(-0.1328213906399499,-1.560728193928665,1.7740740421720917 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark05(-0.13321099273341186,-9.97358840551177,431.3885138884691 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark05(-0.1336770888214609,-36.084064084756044,48.58771064772596 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark05(-0.1338655003206164,-1.5707963267948966,-12.838720786809953 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark05(-0.13512845919637617,-1.5707963267948966,1.5707963267948932 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark05(-0.1352512960198169,-34.85513055478748,-71.09841776193915 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark05(-0.13557463828772498,-1.570796326794886,-8.040506491989333 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark05(-0.13630451754562378,-60.102749020290176,-56.01460178594225 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark05(-0.1368779693990505,-10.169160342254468,31.493915505418382 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark05(-0.13707621273722176,-783.5073719634106,1.5707963267948966 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark05(-0.1370852538517049,-79.51457950098211,-85.10861043005919 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark05(-0.13715222230359214,-0.6559115667168799,58.336504397894466 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark05(-0.1378084974936673,-3.760732852203617,73.75089105672319 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark05(-0.1382620360153584,-1.5707963267948966,14.442252855021952 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark05(-0.13827191247963036,-2.263919769706678E-72,19.950901670131664 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark05(-0.13844547240341565,-47.54802610306557,-7.853981634182467 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark05(-0.13872667016175727,-1.5707963267948963,-54.76378250303846 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark05(-0.13918532935985517,-15.984028792365223,1.356338699927977 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark05(-0.1392980467072413,-0.30563451350704135,-95.76672724916523 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark05(-0.139614434342741,-1.5707963267948948,-89.27825209086498 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark05(-0.1397039039188884,-78.81851080275511,4.930380657631324E-32 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark05(-0.13975110741769028,-9.580509182678849,-90.81676174311434 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark05(-0.14035652130130905,9.675034426379447,-0.011752322007173799 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark05(-0.14076019564217468,-97.98374829605474,-79.25677634825762 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark05(-0.14085883394085694,-78.90197293936401,8.470329472543003E-22 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark05(-0.14110312925513088,-0.5581795136660298,21.969012422666253 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark05(-0.14165496321643445,-53.533352228665166,-1.5707963267948966 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark05(-0.14180913118469346,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark05(-0.14225200708831828,-1.5707963267948966,-83.564764462708 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark05(-0.14302696609112164,-1.471565014844841,-64.0681527646153 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark05(-0.14325526371877118,-1.5442879714780133,-62.57423406270575 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark05(-0.14328252835991842,-67.3920150920046,-1.5707963267948983 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark05(-0.14345577060160306,-54.90134570912557,59.193376288022144 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark05(-0.1436094716419376,-6.790470840423211,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark05(-0.14442690044934295,-53.6440703322902,20.420461462189422 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark05(-0.14473445729190673,-9.960698872058437,-3.149412282277116 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark05(-0.1461692986563006,1.1102230246251565E-16,-35.00834802306837 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark05(-0.14633724168825693,-1.5707963267948966,-1.9704432002098002 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark05(-0.14697131457422863,-1.5707963267948966,27.33562971476556 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark05(-0.14706513150310702,-84.82300927636906,99.03966436585061 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark05(-0.14793494409355884,-3.141592892991984,-44.78945812140422 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark05(-0.1488710554424121,-3.2959428536053252,-79.41549800822038 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark05(-0.14910417636663018,-2.5737787947340145E-85,49.744559231457 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark05(-0.1492312895855612,-123.78191541903342,-0.6121663825676364 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark05(-0.1493301052004034,-10.289128625670926,1.5707963267948966 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark05(-0.15062801142381338,-8.89103499794031E-162,24.020592686143562 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark05(-0.15069073879338651,-16.146647915163513,85.52927419715907 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark05(-0.15076954367132855,-0.025000850475131793,61.245560573211755 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark05(-0.15106418024229573,-1.5707963267948966,-2.4237761519242063 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark05(-0.1521289799903865,-0.25561633453648663,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark05(-0.1522133014951667,-1.5707963267948966,3.1415926536050733 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark05(-0.15248470630884442,-4.2998762289562595,-1.5707963267948966 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark05(-0.15327511949154948,-9.424793219558534,-49.84145282653419 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark05(-0.15359808232134187,-0.983277672559721,1.570796326793682 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark05(-0.15371293877992698,-66.69538076408523,660.0528048603475 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark05(-0.1537172344926146,-0.0356972914988549,13.36251676065281 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark05(-0.15379768302374375,-91.17558958545784,-68.06762312664877 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark05(-0.1539084406534067,-23.132803088355082,-49.78348165634077 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark05(-0.15406669034108092,-1.2795548641671237,-466.5258240375679 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark05(-0.15429942574626745,-3.6054952828642812,-6.283185868757524 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark05(-0.1546539017299428,-54.95545031068611,-22.153321984791447 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark05(-0.1547802933887576,-36.561087829394175,1.5707963267948966 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark05(-0.15540402720217683,-15.903255040422408,136.44902617205656 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark05(-0.15623034753004428,-41.9756808657457,52.34830104050702 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark05(-0.15636009976789522,-1.5707963267948966,1.1787733488348517 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark05(-0.1565386741303092,-3.971992945656538,-6.533510690569133 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark05(-0.15687874255600368,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark05(-0.15747404683064514,-66.19597068997436,-35.94364687239654 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark05(-0.1577173701522815,-0.44585162061885886,-2320.8310400980267 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark05(-0.15801960596439094,-1.283817899295343,-507.3318826861422 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark05(-0.15805695508493403,-9.597070583714931,0.0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark05(-0.15869898282131162,-66.3499989032864,6.287092073407298 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark05(-0.15911656762648363,-47.592667018420286,0.34362887672690895 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark05(-0.1591547934176575,-1.5707963267948966,-25.783370966464343 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark05(-0.15933928351889415,-92.62534343527473,-55.31647841866434 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark05(-0.1595911705952002,-61.0250137063018,-56.969414854735604 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark05(-0.15977683296089223,-0.05462163149636271,33.591754380631215 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark05(-0.15981475281722565,-53.40707701837512,1.5707963267949019 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark05(-0.1601046000840865,-60.08548175115053,-16.400070260932438 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark05(-0.1602905786583111,-1.5707963267948966,50.06929956052055 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark05(-0.1609843810334013,-48.246164536254184,42.85637386655823 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark05(-0.16104072829664046,-0.7103469323621618,71.34981759672324 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark05(-0.16163094325245697,-1.5707963267966834,-13.502665712883008 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark05(-0.16173404613881526,-98.80805576193787,60.789748613453156 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark05(-0.1617346436633444,-1.0693809958772464,-6.283314097702606 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark05(-0.16175591632523378,-0.33949670306207574,1.5707963267948983 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark05(-0.16284630197367989,-1.5707963267948963,-25.853254072370717 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark05(-0.1630497877486814,-1.4558427591838967,-5.971017476217 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark05(-0.16335218637381588,-0.0010749534832758395,39.175188359051866 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark05(0.1641569676871869,-1.5707963267948166,55.16351414349836 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark05(-0.16424376875559688,-1.1662632867692888,32.62331111719411 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark05(-0.16478081300022362,-122.75489142683136,90.28299459544503 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark05(-0.16507328730365578,-1.0586107431188623,714.1876366996564 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark05(-0.16519576010396697,-0.11208586561412959,54.906144172676946 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark05(-0.16529793104031504,-1.5707963267948983,-1055.528095308514 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark05(-0.1654969301783875,3.2069267933294396,-86.10874372614711 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark05(-0.16577455800113683,-98.93094231237933,169.58743287339723 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark05(-0.16594588875234295,-1.5276463359857873,69.51149920661109 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark05(-0.1659542635190569,-54.483417102702305,-1.5707963267948983 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark05(-0.1664387388190791,-1.2622671146044033,1.5707963267948983 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark05(-0.1664772815891743,-3.1416002852081006,64.43852237411755 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark05(-0.16653160325831795,-35.036004847493345,79.44660149404234 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark05(-0.16664337307133248,-40.98217511128972,7.938668218949019 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark05(-0.16703923773510007,-1.5707963267948966,27.739267858150086 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark05(-0.16718964613951925,28.703537555513247,4.142722998318414 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark05(-0.1672198318457341,-1.3664891836255284,-66.40586108559916 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark05(-0.16860207711127204,-48.563874588063605,-1.2300874260592451 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark05(-0.1689589355640054,-1.5707963267948961,1.4453135085383537 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark05(-0.1696314995145647,-66.65604436264825,-146.08412716970446 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark05(-0.17044101774751774,-48.512656728377145,4.084288653862602 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark05(-0.1707870241513453,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark05(-0.17091881425634803,-10.26253167646308,-40.065122456996576 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark05(-0.17094078754616615,-1.5707963267948966,5.295543818748017 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark05(-0.17117512255650583,-1.5707963267948966,-35.038835219908904 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark05(-0.17122530801054442,-1.5707963267948966,94.80042623856968 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark05(-0.171754908965971,-0.06262652491856957,63.488911003250024 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark05(0.17199119800440454,-0.6545361260234956,-39.07189186601224 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark05(-0.17208751045738693,-0.8165255082228704,-74.99008046105132 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark05(-0.17224913864533994,-28.39854093346223,-1.5707963267948963 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark05(-0.17247935647907886,-1.5707963267948966,-71.84924382940872 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark05(-0.17318084881964205,-0.8129857502344072,91.80646938119467 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark05(-0.17325260913798782,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark05(-0.1733137402855465,-35.15585979239262,-100.0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark05(-0.1743369099525962,1.3877787807814457E-17,-8.392253553487429 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark05(-0.17452512997409997,-34.91985620613368,-13.524563731834862 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark05(-0.17577646525100904,-97.67015147643167,-86.0513913014411 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark05(-0.1769555858863443,-0.08671872945795682,-3.1416002830150234 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark05(0.1775713515244234,-1.5548844998404325,50.25875838938225 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark05(-0.17762714747882657,-0.46869465876387295,-67.89717478338395 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark05(-0.17843120073012994,-1.4338664668363823,37.95760882806641 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark05(-0.17856557702350573,-98.36672321825952,76.07591197678543 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark05(-0.17875161360046482,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark05(-0.17879907378996185,-66.32443196656807,1.5707963267948983 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark05(-0.17884173505489181,-0.4028397976057136,31.528204182891724 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark05(-0.17921126944682608,-10.42176537058237,75.77870739870296 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark05(-0.17975008311297824,-34.590227384109795,34.52513316077467 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark05(-0.18069006722027103,3.944304526105059E-31,-26.069030332796913 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark05(-0.18101529425114304,-2.170662841294021E-165,26.22495061451516 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark05(-0.18102285257510684,-412.9825629251917,9.41884880080812 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark05(-0.18132733442374055,-0.06770386909525636,1.5707963267948966 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark05(-0.18136517513024936,-0.9337704072099927,0.0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark05(-0.18172907499855429,-1.5707963267948957,0.5223374650072472 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark05(-0.18199834020262529,-0.23509005006813127,-52.631061882943385 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark05(-0.1822279455295025,-78.6614254685199,-1.5707963267948966 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark05(-0.18232946059721167,-122.94628706238018,55.25798689263124 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark05(-0.18349838168638288,-1.5707963267948966,7.598754402184195E-16 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark05(-0.18384310168223783,-1.5707963267948966,-85.86134643006031 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark05(-0.1840734885539348,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark05(-0.18446269480957522,-3.303675972441127,-1.1109580220298176 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark05(-0.18478765381861317,-3.1465276091302146,-1.5707963267948966 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark05(-0.18521292264701486,-1.5707963267948966,69.53646110671508 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark05(-0.18531514024622098,-1.34088216152693,1.5707963267948966 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark05(-0.18542079505928286,-0.6457209085665696,-63.78617072272574 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark05(-0.18558580835739547,-22.054740694130892,-1.5707963267948966 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark05(-0.18616608631604237,-73.22798989680908,-152.23090661448495 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark05(-0.18635148392029288,-0.0049410972176159584,-10.641876242681407 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark05(-0.18635472629469477,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark05(-0.18663673656941787,-67.24712435744803,-15.74156178077427 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark05(-0.18684430222160686,-1.5707963267948966,-0.027539652825223873 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark05(-0.18736763147912236,-73.22343379314766,79.27706664093995 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark05(-0.1874193934660604,-72.46844775035461,-1.5707963267948966 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark05(-0.18813898113571526,-4.141592653768274,-0.6753450531964039 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark05(-0.18823285443248833,-1.5707963267948983,-169.51933126738606 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark05(-0.1882713121254237,-1.5707963267948966,51.624247421134356 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark05(-0.1882732537277256,-66.25684083595,42.867940069226975 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark05(-0.1886917560002253,-97.75276050804207,82.8967323312734 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark05(-0.18888059527798745,-42.235352689541145,-2.4614786699389555 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark05(-0.18895514654826773,-54.721246269107056,-19.985896305380216 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark05(-0.189058912664933,-79.53198218266498,-73.71087863409153 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark05(-0.18921444583031996,-85.029352767707,82.7624943557733 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark05(-0.18951364274731664,-1.5707963267948664,-1.5707963267949125 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark05(-0.18958492786406508,-66.44659995683449,20.163202762415043 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark05(-0.1896540400947172,-72.67011598422212,-42.751576584450305 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark05(-0.18993331286025292,-1.5416487082454364,50.11536473506034 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark05(-0.19189068073853033,-1.5707963267948961,-7.8539827274182565 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark05(-0.192744336835867,-142.1551827319574,-154.4264788111215 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark05(-0.19276536297104896,-2.910411384687017E-16,4.660444325995881 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark05(-0.19294759425858327,-0.08903040460705704,45.0059831332795 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark05(-0.19305549085131796,-34.65742553831548,42.63845814730516 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark05(-0.19362801345624103,-66.30142880051442,33.21296030062675 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark05(-0.19410458968667044,-0.1678361372988505,-112.58164682723205 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark05(-0.1943941555138471,-9.571683610839031,119.15726850319643 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark05(-0.19454370635331575,-0.44208034562173815,50.15793457616957 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark05(-0.19488240141394897,-97.78736168251584,-26.928571235960987 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark05(-0.19506545137968467,-0.5536050809374274,-22.022399447415943 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark05(-0.19531790665512586,-0.7905002910515275,-549.6803856858417 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark05(0.1957071350677947,-1.5707963267948912,1.5707963267948966 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark05(-0.19579601867766963,-1.538352118642755,1.5707963267948963 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark05(-0.19592336944252078,-0.06898404608714631,3.141592892063244 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark05(-0.19593244615955568,-4.141593098052902,-149.02152860087605 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark05(-0.196316159879438,-1.5707963267948948,78.32941871241951 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark05(-0.19698094359531138,-1.5707963267948966,-0.35414618665622016 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark05(-0.197000286723163,-3.3922712923478713,1.5707963267948983 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark05(-0.197706271341195,-1.5707963267948966,21.625932547512456 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark05(-0.19806922761238338,-3.14354630039937,-122.96414710214235 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark05(-0.19829901508514047,-79.03939470311829,-57.845466198791016 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark05(-0.19852731804773616,-3.1986988702622807,-1.570796326794897 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark05(-0.19860367888965413,-9.9358989865366,-92.0497713309685 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark05(-0.1986396888862796,-1.5707963267948912,-19.281453941659468 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark05(-0.1987837907633081,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark05(-0.1990165458993596,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark05(-0.19972879285417305,-66.36820853888888,-437.67041437190994 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark05(-0.19988256768612894,-1.5707963267948983,12.362550428693794 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark05(-0.19999685650460433,-48.417654531720046,-6.81048529487299 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark05(-0.2000595081807217,-1.5707263901326354,-21.687655482489806 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark05(-0.2002298023259277,28.703660685491656,397.38000272478297 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark05(-0.20071826367757134,-1.5707963267948966,-25.938292814584045 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark05(-0.2010016982133526,-28.34224663560329,-34.90150205258948 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark05(-0.20196067474172913,-15.707963267948967,22.697714138747724 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark05(-0.20222969689441705,-0.19451460039909196,-52.844282524587065 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark05(-0.2035095260035777,-98.64291760745506,-3.143545778592385 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark05(-0.20357806749014423,-79.94363505263306,-770.6547091346648 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark05(-0.20360246617276756,-1.5707963267948966,-52.01714723372079 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark05(-0.2042241604665746,-185.35845134712417,3.1416542541679786 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark05(-0.20431422281550204,-9.958845237686168,1.2693761383988598 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark05(-0.20435992390962926,-1.437249111995033,-1.5707963267948966 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark05(-0.2045396474407113,4.141592653589794,-0.9445524512782741 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark05(-0.20471166178589026,-1.5707963267948966,6.283185307275255 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark05(-0.20537389233339418,-3.141653703246394,0.9933949275813496 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark05(-0.20556195878850064,-1.5707963267948966,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark05(-0.2059354509841107,-97.57228773017164,-41.00689468262105 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark05(-0.20643410883038546,-1.5707963267948966,-4.712389010389704 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark05(-0.20658846406107545,-9.991496321136928,15.572710442820448 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark05(-0.20684592008588815,-48.435593099654085,47.31295587109578 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark05(-0.20752522312998783,-9.640374511902564,-6.2848932529233625 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark05(-0.20788304625603132,-0.10888100067761824,-23.995834683818188 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark05(-0.20805187783336487,-34.59355107484312,23.259510841651192 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark05(-0.2081530945771381,-35.96609535034487,7.069647124238827 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark05(-0.20824973275384195,-122.9765828449859,1.235451123686708 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark05(-0.20831522260105856,-1.5707963267948966,56.93080296723502 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark05(-0.2090684941515207,-98.63677547772102,-98.9518562584468 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark05(-0.20941214569315747,-0.09329406758731457,54.7402369124717 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark05(-0.20952243472795473,-54.51462528279749,-76.3134462198202 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark05(0.20974310380410655,-122.82629575155161,1.5824549294081005 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark05(-0.2097512187464714,-1.1001048698613711,77.24954807296844 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark05(0.20993284196096687,-1.0395494408131194E-15,20.89035073667942 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark05(-0.21067467333116352,-1.5707963267948966,38.12769362764311 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark05(-0.21098518098193053,-1.5707963267948966,52.05225181916602 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark05(-0.21108977692936753,-0.050480411773345744,-27.044229398672442 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark05(-0.21138613589773367,-1.5707963267948966,-59.811632392501046 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark05(0.21196923259154335,-48.410381395073884,89.2655525133181 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark05(-0.21213799091086416,-22.45575818444493,53.68968090523237 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark05(0.21244865293426676,-1.543227110036953,20.82701719448616 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark05(-0.2135262701475716,-3.172151892897489,70.82445222956883 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark05(-0.21357916494015064,-0.6552201477285355,89.72827359396166 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark05(-0.2138062694424243,-141.74619542777006,42.5365207542622 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark05(-0.21383058614704487,-0.014114650141708318,0.0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark05(-0.2145548106801872,-1.570796326794862,-1.5707963267949054 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark05(-0.21457042700690165,-1.5200147077723976,25.785964790109944 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark05(-0.21487052315673216,-1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark05(-0.21488484003751546,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark05(-0.21753785068565534,-73.08971597530835,-14.774443195184752 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark05(-0.21758059272877972,-35.91153280389528,1.2689709186578246E-116 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark05(-0.21895043518973473,-1.5707963267948966,0.5482493229014272 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark05(-0.21896180300375967,-10.448482589063573,-42.95171498095462 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark05(-0.21924462795685792,-1.7763568394002505E-15,-31.07088595488176 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark05(-0.21938356057136138,-1.5707963263110998,-25.57347001495233 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark05(0.21948345804056923,-0.04680387626856369,-1.5703001524554896 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark05(-0.22025948760460778,-0.2065206664937016,53.687734870069896 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark05(-0.22121682691764388,-98.25668473302449,-54.666658223370405 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark05(-0.22127559080519177,6.938893903907228E-18,82.64599618668346 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark05(-0.22136437035119394,-16.386863900452617,-2.7397616862605038E-194 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark05(-0.22153427795291503,-35.89359202283449,42.65396121709422 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark05(-0.22169434154211842,-0.9606212089373746,-2.773832448402075 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark05(-0.22184111136896623,-35.80180591428104,60.2896847267576 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark05(-0.2223221340405727,-1.2787117245817765,53.407075111797454 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark05(-0.22281321335264706,-1.5707963267948957,5.285543977780492 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark05(-0.22295973957300064,-61.15455186845399,33.78623974482514 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark05(-0.22325629414298126,-0.00566599647402028,0.016506597696693825 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark05(-0.22345195561868972,-3.2811555210598726,80.04716156495871 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark05(-0.2236326004842287,-1.570796326794866,0.18742866189754334 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark05(-0.22391150117356273,-129.40608291853115,49.05064081220459 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark05(-0.2239707836932756,-8.881784197001252E-16,-35.59701951777767 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark05(-0.22487757078924137,-2.220446049250313E-16,1.5707963267948912 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark05(-0.22503647226488926,-54.79639786109755,20.600907906752962 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark05(-0.2252261624785593,-1.5172971909325137,49.78029775937566 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark05(-0.22542510533037094,-15.707963267948967,-0.4015540123467784 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark05(-0.22544031754674976,-1.5707963267948966,-65.8977975025923 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark05(-0.22604603766587272,-41.422358861243694,32.66896921014332 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark05(-0.2263003273627816,-48.61584882711304,5.856423953184054 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark05(-0.22677970726676477,-1.5707963267948968,-4.699925727708571 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark05(-0.22770002169348486,-54.42677351980542,54.42642019128445 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark05(-0.22832196762108586,-0.19875389282212597,6.287091583810286 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark05(-0.22850011353584865,-1.5707963267948966,56.5895742584913 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark05(-0.229199158958225,-1.0701653400398448,-67.52057196618082 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark05(-0.2297986924679174,-3.8293851958793965,9.579581239512919 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark05(-0.23016767400234484,-1.5707963267948912,-15.883254141662015 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark05(-0.23057250456777556,-0.053878602833242084,-145.0607184065172 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark05(-0.23065741154973368,-73.27595815626348,-72.7211620484868 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark05(-0.23138253642200635,-3.143545806032783,49.83672716007832 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark05(-0.2317499184692196,-0.6665324964661306,-57.2987906199349 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark05(-0.23178380078143737,-1.3261991611248187,0.0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark05(-0.231900989397503,-66.78868574322598,2400.1628114119453 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark05(-0.2319340947296098,-60.33157018023722,-1.5707963267948966 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark05(-0.23196309577746343,-47.20966419165685,1.5707963267948957 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark05(-0.23239525028576402,-1.0823288797913868,-15.830747916639556 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark05(-0.23315858937487433,-1.5707963260848028,12.68369781048322 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark05(-0.2332652441437203,-1.0587911840678754E-22,1.4549607428231968 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark05(-0.23376280709182157,-1.5707962740936248,0.0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark05(-0.23493630810497512,-15.987489448103805,-6.2835751726933 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark05(-0.23514944894465484,-1.5707963267948948,-53.48452224085105 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark05(-0.23530693709549255,-3.8452212185959276,-19.039900502959703 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark05(-0.23534369011020262,-48.620484069854996,-28.16086556656192 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark05(-0.23553812853969003,-0.3968115982347041,-1.5051052880715905 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark05(-0.2356082461460446,4.3368086899420177E-19,1.5707963267948963 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark05(-0.23565557232649664,-4.464104428485589,-1.3180841185746044 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark05(-0.23595809636918263,-23.09859786024211,-0.14583228279530971 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark05(-0.23603022481262637,-1.274221515376351,44.9424956559061 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark05(-0.23688035174825145,-1.5707963267948966,-76.13594452874227 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark05(-0.2375227678356625,-3.1416546002193537,-41.41984135347742 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark05(-0.23786093995311813,-9.66899854585002,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark05(-0.23787159780494171,-41.558718980016735,1.5707963267948961 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark05(-0.23808931577946413,-0.11277391809068438,-55.599621794538024 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark05(-0.23829149102684796,-85.12596424013375,-1.5707963267948966 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark05(-0.23923964427970532,-480.78838191239083,-97.82548349997322 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark05(-0.23978905584084098,-72.39869304525769,1.570802748459599 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark05(-0.23982797158372823,-84.94719439860312,-4.142504267090312 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark05(-0.24003369232405813,-42.211796720635476,1.5707963270246077 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark05(-0.24013328030473735,-1.3503212272215794,-29.530958528940715 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark05(-0.24073235766084014,-53.57766317896866,-1.5707963267948912 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark05(-0.24083769510004596,-47.12395084218204,-84.29514862544285 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark05(-0.24154537629558925,-0.7729139116190229,1.5707963267948966 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark05(0.2416036313587905,-66.49476194776985,64.40264939859077 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark05(-0.24188016381966376,-0.8824371084039195,-82.41314056974402 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark05(-0.24301089750618843,-185.57152685488524,113.0081854695018 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark05(-0.24422812372213012,-48.60950995623471,-78.05994017642907 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark05(-0.2447878626982316,-154.65850034811479,1.2843767529345054 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark05(-0.24482728710441837,-1.5707963267948966,3.1423559497639055 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark05(-0.24658573830502084,-1.2300929868661403,48.78127066340278 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark05(-0.24750639159423005,-0.8431745971146034,0.4437865213148271 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark05(-0.24899488666293879,14.44882155339348,-4.712465254941006 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark05(-0.24900821579050358,-1.4487902311476848,146.1386168388177 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark05(-0.2496747134089503,-4.336572834508658,-3.4924710881288945 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark05(-0.2499462156812687,-98.68636359954314,64.59025318153368 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark05(-0.25019921727159533,-1.5707963267948966,0.7477721957757613 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark05(-0.25024201793554235,14.429244944334513,0.19820414921699459 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark05(0.25072480357234184,-343.4045661233144,-1.5707963267948912 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark05(-0.25105664659081706,-1.5707963267948974,-154.84456681337156 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark05(-0.2511525800560548,-2460.988649720397,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark05(-0.2512024916403971,-9.601464325960833,8.826359419311878 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark05(-0.25146974026196595,-1.2606221934029764,53.129833693082205 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark05(0.2516716407768461,-1.5238068970965521,-47.15910219813679 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark05(-0.2521147420052432,-1.5707963267948966,73.42798740934379 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark05(-0.25229108283367513,-60.80473634886952,-84.59102066574383 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark05(-0.25293915521054855,-1.5707963267948966,1.5707908617820303 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark05(-0.25302458872717815,-66.08631727658471,53.45179441177518 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark05(-0.25338675959948953,-0.9314393905341574,-0.8945120891214472 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark05(-0.2544340001013569,-1.5707963267948966,-29.845130209103033 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark05(-0.25546577421598216,-1.070729159612739,21.551971199234924 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark05(-0.25573865255841566,-0.049737459673298415,-77.50629540914235 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark05(-0.25614953661014994,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark05(-0.25615304142031714,-1.5707963267948966,43.55158315509301 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark05(-0.2565232718462763,-78.89156072821552,1.5707963268115175 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark05(-0.2565853177081346,-0.49401235359445494,-59.26217024514081 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark05(-0.2565859545066677,-54.676081113868015,1.5707963267948983 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark05(-0.25709330705302685,-0.10195395120154442,-1.0053823416929744E-87 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark05(-0.257245249537041,-1.5707963267948957,42.786866646376325 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark05(-0.25735464630853516,-9.644441198938154,6.68604072013929 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark05(-0.2575958963044416,-0.7855521230936402,0.0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark05(-0.25770679270273666,-1.570796326791418,31.97526106624853 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark05(-0.2577580586919505,-1.5707963267948966,-40.766009464028194 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark05(-0.25785813474998953,-1.5707963267948966,27.08695736689802 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark05(-0.2580009457562464,-0.09130334187021213,72.35479487716627 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark05(-0.2586600540253883,-0.19924577776912544,51.77346927297347 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark05(-0.2588739930757935,-1.5707963267363192,1.5707963267948966 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark05(-0.2590529092163275,-78.74092698461685,1.5707963267947762 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark05(-0.25961593923374804,-0.8779288099220862,-1.4440589151806538 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark05(-0.25973986797098175,-48.69107631925208,-27.450603665876883 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark05(-0.2598461558634761,-1.5707963267948966,1.3055589900082545 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark05(-0.25985899350185415,-97.80230281257661,14.787752164496773 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark05(-0.25992780092481477,-274.8452741911101,-1.5707963267948983 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark05(-0.25999533954999415,-48.34679320459093,26.70445660710684 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark05(-0.2603149216292593,7.511159673311354,-65.23633374423832 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark05(-0.2611826635902782,-60.99562269737111,1.5707963267948974 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark05(-0.2615678241002723,-1.5707963267948961,44.38721699411262 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark05(-0.2621996628077395,-3.0663634460487213E-18,-8.469060602604007E-34 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark05(-0.26285385039295406,-1.5707963267948966,-449.2310946039947 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark05(-0.26297040286972273,-9.424912905903746,-64.24849802148766 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark05(-0.26320267983939083,-1.5707963267948948,82.90747280006494 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark05(-0.2633380930588178,-1.5707963267948966,4.712389097948026 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark05(-0.26386790418532985,-54.68591398088581,81.05390065515854 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark05(-0.2640595995545047,-34.968544059109924,69.80136136255243 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark05(-0.2641921615537144,-9.596186038274467,-98.4881507687613 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark05(-0.26424616793171496,-35.21891232231706,-34.68926669972798 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark05(-0.2646580676750082,-10.366027159967615,-47.4272068848126 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark05(-0.26471213957493855,-0.8180318909719615,6.8156046155751255 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark05(-0.2649063969424762,-41.99568660594139,-1.5707963269043834 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark05(-0.2650719376093551,-60.8819810223206,-88.06950945344353 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark05(-0.265466657293745,-35.87800005611775,0.0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark05(-0.2655208346382912,-42.193198829936684,12.694070687032813 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark05(-0.265640890493438,-60.90148202477434,22.837789287144464 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark05(-0.26582503047496486,-0.20732237218483496,0.6280347048499751 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark05(-0.26593122353315995,-0.9938899645327712,45.08394990155756 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark05(-0.2660846294251433,-0.1393868978730996,-4.71240786009181 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark05(-0.2668333908644575,-10.315046798724543,6.345707908685576 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark05(-0.2678047584323451,-0.5218132389405452,3.6411096563279313 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark05(-0.2682014906409833,-1.5707963267948966,-52.497172887297005 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark05(-0.26877388025354787,-3.141600283441381,38.53542557603225 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark05(0.2701101965899765,-1.2362103473787986,1.2466896355668358 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark05(-0.2701278158969543,-0.038568779487190286,70.41229259731679 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark05(-0.27098645289720774,-66.32015878816074,-1.0272919276160843 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark05(-0.2710779132849108,-42.3882530804149,158.60062247006994 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark05(-0.2712358300735934,-15.925073197730562,1.5707963267948983 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark05(-0.2720252646792478,-66.28404701231361,24.21813038598897 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark05(-0.2723538970253779,-1.4040626083287622,82.56535391123506 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark05(-0.27356201283145287,-91.3087580326872,-1.5707963267949 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark05(-0.27370943302415596,-1.570796326794895,-29.561534738666513 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark05(-0.27382539402183426,-35.923405205440545,56.05319569208764 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark05(-0.2740618110797333,-22.893496059649095,-0.18760568402187694 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark05(-0.2744048060644285,-66.06955351112478,169.36330496296569 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark05(-0.27527229843217693,-4.0310150172404,0.0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark05(-0.27584654528621183,-1.0438942467371446,-88.93479458140956 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark05(0.276068142004965,-0.5191961244740337,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark05(-0.2766866993140893,-1.5707963267948966,0.9001013012902396 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark05(-0.2767635051056693,-1.3118543779704248,-13.394774759184362 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark05(-0.2771989099019884,-9.621045102065139,1.5707963267948983 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark05(-0.2782863551651896,-34.6870698645654,-48.796288160097504 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark05(-0.2787845474746155,3.3087224502121107E-24,1.5707963267948966 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark05(-0.27903322057687674,-22.272110543820602,40.62096400737012 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark05(-0.2827139807380073,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark05(0.2827577717832547,-538.2850588286025,-59.75150317998341 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark05(-0.28293031926488443,3.196833875376016,1.5707963267948966 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark05(-0.2835442684222468,-135.09671527960708,-1.5708550748842975 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark05(-0.28432463815114684,-3.1575697783640067,-1.5707963267948966 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark05(-0.28439330419540304,-34.59053794527314,-20.84128380642684 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark05(-0.28445553721786393,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark05(-0.2849733336317374,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark05(-0.2854252514282931,-54.576603407372225,1.5707963267948912 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark05(-0.2857468443238242,-35.189902436705566,6.283185784511025 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark05(-0.2863452493328196,-1.5707963267949054,109.94489511115404 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark05(-0.28683592941687863,-0.4986430848039399,78.08023713514831 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark05(-0.2868365337802221,1.3552527156068805E-20,-1.5707963267948966 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark05(-0.2874216493910207,-73.24796865737792,147.65462444264094 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark05(-0.287706524659111,-1.5707963236773597,1.5707963267948966 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark05(-0.28856266337548553,-72.42240288660653,28.4368239051514 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark05(-0.2888979964124986,-0.9382465372459596,1.664760760425395 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark05(-0.2895459555915549,-1.2559363058932875,-37.473220261064895 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark05(-0.28981271264160663,-0.3740253137481882,53.548207995329705 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark05(-0.29000094778591834,-0.20123976289051174,69.65025125310741 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark05(-0.29004381626307496,-36.09396347510864,45.32266478803783 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark05(-0.2903391756940999,-1.0819278378409543,-19.39940609594828 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark05(-0.29043751817727415,-664.4455304071106,0.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark05(-0.2904429114238721,-0.44285222497026666,46.564446983525045 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark05(-0.29072994148715114,-73.45308702884932,-168.3876658679309 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark05(-0.29196282551055497,-3.141925674720285,84.25378973150005 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark05(-0.29394229980003284,-2.220446049250313E-16,49.889714239498566 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark05(-0.2942101636182275,-0.10159322300575635,43.40136742054214 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark05(-0.29437814340421564,-35.63261575545061,60.06507849850749 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark05(-0.2947586905263494,-1.3853591711521291,1.5707963267948983 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark05(-0.29477998271976524,-0.8418483896292537,8.103982480380376 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark05(-0.29534272026860364,-0.39088224791868165,-1.0587911840678754E-22 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark05(-0.29550509630368016,-0.17594933861396722,41.8265438336406 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark05(-0.2956920227962646,-1.434327701591838,-147.70479528748226 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark05(-0.29635810807074564,0.09855863830771161,-77.61861506025328 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark05(-0.2964408713436606,-1.5707963265093332,-1.5707963267948966 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark05(-0.296570289026565,1.0842021724855044E-19,27.787183890000165 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark05(-0.2966569099896844,-1.3650504191216046,73.49467023606016 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark05(-0.2967580987783698,-1.4248674557184147,-56.77877669312879 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark05(0.29684185822974196,-1.5707963267948966,77.28658803105864 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark05(-0.29700502593463723,-1.5707963267948966,-3.1415927646178003 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark05(-0.29821403524357404,-0.381299014624627,-54.59657483470046 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark05(-0.2983095036290506,-0.4275163648101634,-13.875916309978393 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark05(-0.29843404099457743,-28.389899603525606,-1.5707963267948966 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark05(-0.2988120652527726,-2.3081486724182977E-19,-94.24973275726684 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark05(-0.2994806616504806,-21.998188140571813,-9.22948153987582 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark05(-0.29998869325626043,-0.13180084450692828,-0.6982092931994945 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark05(-0.30018676138236366,-1.0796157970624094,-1.570795518361391 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark05(-0.30073177547746166,-3.1415926535916316,35.3081173867308 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark05(0.3008740012810306,-1.5707963267948966,0.21420974743246635 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark05(-0.3009854401155896,-172.79151227345923,-60.50806015776515 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark05(-0.30129351596789666,-0.7560438802704669,-1.3852912288102255 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark05(-0.30185653546961544,-0.39634172196091966,-77.36616506640793 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark05(-0.30188934474768636,-3.1416026335154985,1.5707963267948966 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark05(-0.302046101699698,-9.979453866488102,-422.537474302527 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark05(-0.3025372932581186,-1.5707963267948966,-68.69754126328 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark05(-0.3039499750943825,-6.776263578034403E-21,1.2645226325694454 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark05(-0.3040053045033851,-110.56418355401655,-1.5707963267948966 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark05(-0.3043679679813724,-66.38544410816668,3.265573218641727 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark05(-0.304702076739643,-0.035747124783338996,-71.73916846381164 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark05(-0.30480087290540325,-1.5707963267948966,-92.8400830118177 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark05(-0.3050620371479458,-61.22391969368524,129.09235367294744 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark05(-0.30551505258108635,-1.2873805480207134,107.15137479463766 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark05(-0.30567054028039464,-1.570796326439514,22.902507395302898 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark05(-0.3058474017323368,-1.5707963267948966,1.5192908393215678E-64 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark05(-0.30592317499226607,-1.4227344701311067,-0.980401628646448 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark05(-0.3064920186498279,-1.5707963267948966,-78.04018468871496 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark05(-0.30677368559429896,-67.31040590251577,-562.8778373606982 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark05(-0.30701893812749426,-1.5707963267948966,-12.99962366476769 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark05(-0.30789004708350376,-48.02294126495944,-23.459066451725462 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark05(-0.30840013467176247,-0.03171059828451771,0.0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark05(-0.3087698615858301,-8.881784197001252E-16,-62.93113036231359 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark05(-0.3088486098288371,-1.5707961534883486,-1.5707963267948966 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark05(-0.3088662723694968,-1.570796326794893,-38.9613978668482 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark05(-0.30888625840557893,-9.528484511029403,-97.89921320332527 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark05(-0.3092664976490392,-1.2034961812569016,-0.17848821000399084 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark05(-0.30949105437216684,-22.01278415693872,65.63213355069392 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark05(-0.3104651086219907,-1.5707963267948966,667.4100907610982 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark05(-0.3105754894945656,-86.09867358383718,-66.0267436177563 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark05(-0.31072195494044763,-78.57704473842162,-1.0941643191712023 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark05(-0.31093124665045624,-1.2260030586940998,50.67155012139348 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark05(-0.3113597945768447,-98.86358262866581,-50.84560388811774 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark05(-0.3131045023721134,-3.344722987843222,-41.743105907997574 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark05(-0.31335496334576984,-22.45766575181776,-63.15356060848389 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark05(-0.31505779729047123,-505.885543601444,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark05(-0.31526507908598367,-1.5707963267948983,1.5707963267948963 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark05(-0.31596899012625385,-3.1415926535898095,-1.5707963267948963 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark05(-0.31616731712386187,-0.40742680611336685,54.991113210835096 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark05(-0.31618751409907137,-1.5707963267948966,35.78580134846814 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark05(-0.3169506757569201,-0.3922249508285916,1.3160862364194235 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark05(0.31710517143670447,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark05(-0.3171271742194945,-0.32609354539281254,14.086550616449074 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark05(-0.3173434935133533,-1.5707963267948966,8.105915521956366 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark05(-0.3175199714160187,-0.017279522434889935,0.0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark05(-0.3176090128012935,-154.60475370303485,-46.40912914818384 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark05(-0.3184980747540642,-3.814862707616669,-71.47423559619043 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark05(-0.31851833437053867,-9.594958405578623,-720.6569817713705 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark05(-0.31868466098751036,-2.3398165157698734E-16,31.491864200275028 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark05(-0.3196397681068167,-3.9244012174305993,34.01265531913273 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark05(-0.3199327781768252,-42.22395135968719,73.69740335798187 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark05(-0.32018365924431047,-35.30550069685117,58.48557140268964 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark05(-0.3215735818314457,-1.5707963267948983,-29.132969445767458 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark05(-0.3216225334337036,-1.5707963267948966,10.81733011904194 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark05(-0.32172939896448377,-959.6168795421806,25.826854662274414 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark05(-0.3224091150066747,-3.632798130773425,1.5707963267948966 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark05(-0.32242132740236895,-1.5597333963723718,-51.83727764944399 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark05(-0.32262572965410996,-122.92620281550019,-3.2721652322524606 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark05(-0.32332662461561607,-1.272162470379047,16.48669309915664 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark05(-0.32442115146678063,-1.5707963267948966,44.421997070167436 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark05(-0.32450868072414646,-41.38806931358765,180.641922498073 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark05(-0.3246095206327374,-1.5707963267948963,-20.907680138527198 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark05(-0.32495476692603953,-3.141600282984669,-52.78857854753358 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark05(-0.3258498395270296,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark05(-0.3261144873776969,-66.64291510848017,-1.5040792536271999 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark05(-0.32663793077075504,-3.1415926535899157,10.720063504134764 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark05(-0.3268322085316707,-41.023234401961275,-34.3179613503351 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark05(-0.3278234321864031,-98.65558110687921,1.9968533162276287 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark05(-0.3280607100150478,-9.539910808238766,-144.0730358750138 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark05(-0.32834535533394216,-0.5604762246459494,1.5707963267948966 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark05(-0.3283526902135515,-10.370817434248535,-83.33833811072235 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark05(-0.32973277916480015,-191.6992766068008,-0.29315478918504745 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark05(-0.33064157254499443,-1.5707963267948966,-179.1636944631218 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark05(-0.3313866062181755,-1.5707963267948966,91.02735546223593 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark05(-0.3314676389059687,-1.5707963267948912,82.40235414523241 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark05(-0.33160172242231833,-72.43443905678974,7.860461470337838 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark05(-0.3323367319425965,-9.579108565017473E-4,-100.0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark05(-0.3338595566790561,-48.31017583556593,-28.789872421059442 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark05(-0.33408802164883555,-3.146806935723687,1.5707963267948966 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark05(-0.3343179324971546,-0.17537847830122166,50.21068325685306 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark05(-0.3350244112975354,-3.9581103878214847,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark05(-0.3355123837404026,-1.0494230702498915,20.57286647482249 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark05(-0.3362708655183873,-3.1415926684909707,75.92188606629634 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark05(-0.33674736249886383,-1.5707963267948966,-6.491382304555287 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark05(-0.3376995070347004,-92.02556369495836,-3.1415928929475774 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark05(-0.33785887250513014,-1.5707963265638698,-48.35675432206408 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark05(-0.33803448911142236,-1.5707963267948966,38.882409854118784 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark05(-0.33928372889517316,-3.141600283891098,59.47681297457264 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark05(-0.33940561078608894,-1.5707963267948966,90.08135299376914 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark05(-0.33946800345153694,-1.5707963267948983,16.721243004252095 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark05(-0.3394700381248317,-60.89520717342238,-78.18848001191239 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark05(-0.3403228053847709,-0.337842215246289,78.27498935036662 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark05(-0.34087969716060995,6.130818543979526E-18,74.53193829144806 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark05(-0.34155669407824585,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark05(-0.3417727978959767,-1.0125068260323866,84.75639514712938 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark05(-0.34190440177052395,-1.5707963267948983,57.707546966772696 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark05(-0.34243307596847433,-85.02869656725414,54.67924057003489 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark05(-0.3428601807396442,-1.5707947440804468,-1.4957301796986249 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark05(-0.342935532870072,-1.5707963267948966,-49.94867929949773 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark05(-0.3430198169493898,-1.5707963267948966,-10.711967472443654 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark05(-0.3434393834215844,8.038829792997904E-17,12.641424182942956 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark05(-0.34406116815276744,-72.91552354730018,0.005505800261168832 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark05(-0.3447155723098656,-1.4005735809160642,1.5707963267948966 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark05(-0.3450313496011259,-98.06518375563506,-1.5707963267948983 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark05(-0.3452772735737605,-1.5707963267948966,4.32998002560671 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark05(-0.3460589997866137,-7.105427357601002E-15,-31.086113538084778 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark05(-0.34609514303150496,-1.522867715780856,1.5707963267948966 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark05(-0.346391137475314,-1.5707963267948966,0.9649716627785775 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark05(-0.34646750868171067,4.141592653592587,69.8048992498909 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark05(-0.3476346308422328,-9.944855275012419,1.5707963273131629 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark05(-0.3479995981518384,-1.5707963266027836,9.733764656566386 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark05(-0.3482936877411986,-66.39095083743172,-73.93418217028714 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark05(-0.34830779412456847,-42.196413034240244,12.568324585821612 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark05(-0.3493414168047356,-1.5437832163165761,7.723735651276314 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark05(-0.3497995007850962,-5.1253327236687384E-144,-47.4162052255876 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark05(-0.34980317635373104,-0.28431291054331564,83.27939452503115 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark05(-0.3506365789071729,-9.596863949799863,1.5707963267948966 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark05(-0.35106915572573744,-1.5707963267948966,87.37678678777903 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark05(-0.3511907848077864,-48.601262656749284,1.5707963267948968 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark05(-0.35143921479175,-84.86121622926524,-10.107650880037266 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark05(-0.3515072332038176,-1.5707963267948983,-50.569714197284014 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark05(-0.3520796044900954,-16.035519853700485,-0.7660582942903673 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark05(-0.35348494275562814,-97.71057318851763,62.286285262091766 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark05(-0.3537902339834804,-331.4281788031556,-1.5707963267948966 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark05(-0.35382226590398247,-59.8875918952288,-0.02232830282547929 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark05(-0.35394111380456444,-1.5707963267948966,-26.812334871514338 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark05(-0.3558213725599867,-1.5707963267948966,-67.47291808661042 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark05(-0.35595750851011054,-66.88623127598706,40.8427125226165 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark05(-0.3562769194239318,-192.75785683652026,-3.141593063740515 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark05(-0.35690937727022604,-0.003624071928013692,1.5707963267948966 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark05(-0.35742083424068305,-1.5707963267948966,16.630006728746523 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark05(-0.3578165618149791,-73.18801594643205,-16.948454884816776 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark05(-0.3579204922595603,-48.45052666827497,0.14521538500769915 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark05(-0.3583684558239389,9.476421854273616,173.86910750129792 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark05(-0.35869661655574403,-3.2751228043245058,-8.147342458600024 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark05(-0.3592359869132675,-0.2514150074833382,-83.28828967755804 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark05(-0.36005971108732737,-15.903468156499557,-98.73783586397867 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark05(-0.3602130722863275,-85.59665233023051,-4.5995736845417206 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark05(-0.36021464886333293,-154.75443421578683,-617.5303608600996 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark05(-0.360414707483433,-1.5707963267948912,-11.797576735625668 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark05(-0.3614567657640499,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark05(-0.36180564342822685,-28.436473423470957,-1.5707963267948983 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark05(-0.36189316478515954,-3.1415926727954666,0.0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark05(-0.3631403090488853,-1.5707963267948963,16.167030959747347 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark05(-0.36423926769659437,-1.5707963267948948,-186.92765811733113 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark05(-0.3643521916321369,-0.28079240660691795,-28.134434184905295 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark05(-0.3645389855033101,-91.9103405380747,-1.5707963267948966 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark05(0.36641643175105354,-72.96562127870226,0.0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark05(-0.36644947517638765,-0.4913203682904421,-55.982307414937495 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark05(-0.3675885726528493,-1.5707963267948963,-1.1442696567411956 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark05(-0.3678996067104421,-22.48886046827225,-78.26600419542805 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark05(-0.36839500640803907,-1.5707963267948966,73.60845318645667 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark05(-0.36892970931036473,-1.5707963267948948,77.41170583377698 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark05(-0.36909867677812425,-0.0014461761236460521,4.712388980454526 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark05(-0.36909987597040583,-28.811278228093258,-1.5707963267948983 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark05(-0.36958253890361537,-1.5707963267948966,-45.15023373692124 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark05(-0.36963978874322106,-1.5420211842153684,62.54355136093395 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark05(-0.3696684253640001,-3.141867903084973,95.71449043673974 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark05(-0.36996509425715596,-3.6362356611663103,-108.24835078414785 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark05(-0.3699918176634658,-1.5707963267948983,15.178035980243354 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark05(-0.37046742183638015,-0.6606023487592718,-1.5707961818141296 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark05(-0.3704739984258446,-47.189526039201546,87.04024415009563 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark05(-0.37085360726575556,-66.3589695482405,-92.9641000683474 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark05(-0.3724770476418791,-72.41657760387157,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark05(-0.37296412346693697,-1.5707963267948966,-0.04944390411768218 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark05(-0.3734135329496736,-1.2967714481584915,70.09416977327086 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark05(-0.37352866786331784,-78.79607014630817,-44.15816287434065 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark05(-0.3740367930212206,-15.952371438540752,-84.70375790988726 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark05(-0.3740580049099066,-0.8075013946578136,3.944304526105059E-31 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark05(-0.37413190317568723,-1.5707963267948966,-60.64896831714697 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark05(-0.37433150262395753,-1.5707963267948966,-90.05393075415597 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark05(-0.3748918302378602,-1.1768477803634614,31.946338100281345 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark05(-0.37505409570143,-1.5707963267948966,-1.570796326794897 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark05(-0.37530078257702937,-85.91391342358321,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark05(-0.3755897684155034,-1.5707963267948966,-31.450037168739954 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark05(-0.37594353041249984,-1.5707963267948966,45.16754816785952 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark05(-0.3760985190269107,-2.1684043449710089E-19,22.102103643930956 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark05(-0.3761028052814761,-1.0976712368626135E-16,-39.269908169872416 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark05(-0.3764473794850469,-1.5707963267948966,78.2845308727932 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark05(-0.3769172590232577,-1.094749798499572,863.8858562438875 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark05(-0.377404981713561,-0.16022552171472937,-85.6647725234225 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark05(-0.3779206467053976,-1.5707963267948966,-46.32154003645487 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark05(-0.37822042804552836,-1.5707963267948912,-13.595023052902476 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark05(0.3785320176979309,-22.38728447166622,77.72786027182661 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark05(-0.37912117678320456,-66.94550740260283,32.73048380890685 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark05(0.38019930841993677,-1.5707963267948901,1.5707963267948948 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark05(-0.3805396692015658,28.703537555513336,-1.5707963267948983 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark05(-0.38076832733524785,-0.03692042847395644,48.75548385809125 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark05(-0.3817564692916547,-1.5707963267948966,55.645850963883866 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark05(-0.3819238380603487,-0.3063368616775648,20.796970304530188 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark05(-0.38224767596434006,-35.88503385377996,76.70557101435672 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark05(-0.3823297738600004,-1.5707963267948966,45.44092842157258 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark05(-0.3827223667951054,-1.5707963267948961,95.01602204246288 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark05(0.38292611718124936,-1.5647197521458867,-1.0765406490040724E-17 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark05(-0.38373288015417817,-10.719333970276487,-42.288014395900326 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark05(-0.3844972539233284,-0.6113144309841289,-8.214543863412743 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark05(-0.38474948750887383,-0.4658651595086667,-130.35840801874122 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark05(-0.38475084127490783,-97.3971847612836,-15.432706971311276 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark05(-0.3852187055802758,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark05(-0.38523071840838485,-41.74881561578388,-1.4609100386716989 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark05(-0.3862444261670277,-4.3802450821402,-557.1491296381062 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark05(-0.3862884203243922,-10.871410815528206,-1.1750040354492036E-4 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark05(-0.3865411299391522,-1.5233460246355512,13.96144577170714 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark05(-0.3871853170157584,-40.861758082602954,-1.5707963267948966 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark05(-0.38726479532725416,-1.5048722853433323,-0.47297958209397883 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark05(-0.3872832893126201,-732.9902988957341,31.454725627454593 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark05(-0.3877245019057227,-0.484714947494325,-20.614002476253262 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark05(-0.38792713140046536,-1.5707963265166698,-27.914091240287085 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark05(-0.3879380560071378,-0.7693368472989086,214.62720810703277 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark05(0.3893574726982213,-3.143545783843776,-84.82601582016906 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark05(-0.3895611475414724,-0.30163422518482197,1.5707963267948966 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark05(-0.38997022008735677,-1.5707963267948966,-32.74753252735148 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark05(-0.3908205444062818,-0.8477639139487213,522.4293084034492 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark05(-0.39123782466648627,-41.88777210796006,90.07797245346231 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark05(-0.39131746764399034,-9.59208588108129,89.08280755008309 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark05(-0.39149013699390667,-1.5707963267948946,42.938301384707835 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark05(-0.3916044173403157,-1.5707963267948961,1.5707963267948963 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark05(-0.3916792578314928,-142.07197680945825,-22.48738974930353 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark05(-0.3928139606756802,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark05(-0.3929909468719197,-1.5707963267948966,21.117704991453735 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark05(-0.39361255036670706,-1.5238526993869834,32.29158291926537 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark05(-0.39394199376429867,4.141594183595422,-1.5707963267948957 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark05(-0.3939989728862277,-0.027484163437159675,-28.04969903209669 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark05(-0.3943468371480911,-3.552713678800501E-15,3.8701869159774276 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark05(-0.3943603271413836,-1.5707963267948966,-19.77570301736026 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark05(-0.39523381649638417,-73.61677116744883,-61.71508845521056 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark05(-0.39544042148630576,2.465190328815662E-32,1.5707963267948966 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark05(-0.39700227185235626,-0.6295743012562018,-0.6397912541496029 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark05(-0.39716008200340724,-1.5707963267948968,-5.988662878795367 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark05(-0.39760091113850965,-23.541630100492753,-23.008950879293227 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark05(-0.398517132887016,-0.1329699427527361,6.289356000272913 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark05(-0.39891449673244495,-10.348816734077264,72.2566989350683 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark05(-0.3990513663910844,-78.8671948545227,66.0586691245235 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark05(-0.3995759765400126,-3.20360755245612,-17.112357549265308 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark05(-0.3996043049950751,-241.90748803127744,-0.7016384189807212 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark05(-0.3999920356918949,-10.347843061125367,58.38474675959345 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark05(-0.40064701427177907,-54.45420840534388,36.46579552066216 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark05(-0.40081407112124623,-67.38532822863907,-98.1476983498857 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark05(-0.40130218144448915,-1.3762082117004195,-72.65320021484673 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark05(-0.40143506479997987,-4.085266333860929,-63.23355111445222 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark05(-0.40213235218620796,-0.527984267790378,-38.60361679013994 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark05(-0.40438332190893295,-651.7990182265191,-36.81287520446715 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark05(-0.4057437952052917,-66.3211914520819,1.5707963285991522 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark05(-0.4067245805758989,-0.42117092742571194,50.42100295726908 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark05(-0.40672546667903076,-79.28405336102733,-2197.9866527176337 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark05(-0.40783578035450985,-65.99948986923846,6.283307377492089 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark05(-0.4080730738451557,-0.5815839334267175,-27.154139688126694 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark05(-0.40885349400458754,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark05(-0.408929450989474,-1.5707963267948963,50.03009509585502 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark05(-0.4091125176620864,-0.5017630452416801,3.2667324896904617 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark05(-0.4103015325091276,-3.14160030291336,-86.25952003510062 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark05(-0.4111053832400038,-3.1416861188166876,-11.4782408066326 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark05(-0.41114306743052353,-1.5707963267948966,-84.57138695881903 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark05(-0.41140944428387505,-38.08762188080185,-0.8873967531239924 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark05(-0.4116519861043138,-1.1822427560197637,-27.907558943062053 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark05(-0.41259187833522015,-8.188257969265833E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark05(-0.41283650435891817,-1.0733044111632781,391.58967236776004 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark05(-0.4135526867152888,-1.5707963267948948,53.78174223106133 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark05(-0.4137129965671474,-0.19525394904841425,-24.421204888170905 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark05(0.41460923385607484,-0.006163838343884398,-26.487002543350812 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark05(-0.4150141445952956,-1.5707963267948966,17.17804775678033 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark05(-0.4160177457712244,-54.71137300243249,1.5708114627695744 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark05(-0.41650210601806653,-59.87727632365021,-1.5707963267948966 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark05(-0.4178100129546679,-91.59595220650216,-23.559169433580536 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark05(-0.41835275465160504,-1.5707963267948966,-27.711746369600007 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark05(-0.41963757930087436,-0.8767023004272829,-14.736428678608775 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark05(-0.4201998691333206,-1.5707963267948957,51.46381554309221 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark05(-0.42059692341827315,-48.55996490038086,-140.33949764283616 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark05(-0.42103119086067065,-1.7658000223287237E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark05(-0.42107866319606735,-1.5707963267948966,-72.36099024175032 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark05(-0.42135099249736324,-54.79267097243236,62.12988992851194 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark05(-0.42306478858328234,-1.5707963267948966,8.853981460557506 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark05(-0.42492808075413674,-3.429377562943202,57.21661894339958 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark05(-0.4252397266057779,-0.21304457101947794,1.5707963267948983 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark05(-0.42613609677336195,-55.885784083211014,-1.378010265918948 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark05(-0.42623399270034934,-1.5707963267948983,104.81636877173521 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark05(0.4269561260531102,-41.50687727752805,-23.141485302976353 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark05(-0.42699980080898864,-72.76907555817789,-6.284258210801422 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark05(0.42767896997468025,-41.478000696453925,100.0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark05(-0.4277356141487312,-22.008545824768802,1.412676345509807 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark05(-0.4290233453695553,-79.47445588357544,-1.5707963267948966 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark05(-0.4294159874070944,-1.1995587274143449,-9.353407321505216 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark05(-0.429490884908082,3.3747914183101773,-0.2692218374052554 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark05(0.430270578068378,-103.67374323540542,-146.46236628607056 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark05(-0.4304037160591818,-10.965121391035211,-45.42053908461086 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark05(-0.4310800152512383,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark05(-0.4314040417417493,-1.5707963267948912,5.162887775687602 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark05(-0.43284618548688536,-29.712481599895625,-1.268897301230282 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark05(-0.43345268644241464,-1.5707963267948966,4.2451520834494545 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark05(-0.4335161882886186,-0.2406476793817871,50.99988756571257 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark05(-0.43408505003883135,-1.5707963267948966,-69.93222575127305 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark05(-0.43489414251704933,-53.57066420465301,1.4405940466122336 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark05(-0.43551494215642195,-60.81010461764039,-7.373185873509957 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark05(-0.43580012415026204,-4.440892098500626E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark05(-0.4363745670309625,-0.047397136836095755,-5.917569471916744E-16 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark05(-0.43642727660564545,-1.5707401886265817,-2.2958874039497803E-41 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark05(-0.4366173115830869,-1.0333845958801335,-69.8142184853981 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark05(-0.43679551181338994,-1.5707963267948974,134.03135287775348 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark05(-0.4370040754962745,-1.5707963267948966,-92.09181926376942 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark05(-0.437198364098082,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark05(-0.4380762310587767,-1.5707963267948966,-81.85055692132315 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark05(-0.4392732848416585,-4.670107238770413,-1.5707963267948966 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark05(-0.4400880547246991,0.3066654266115293,-63.99391166457426 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark05(-0.4404439833036389,-10.88678092079958,-9.54919841503838 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark05(-0.4405257171881576,-110.03816935449807,1.2586453955170955E-13 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark05(-0.44100437701677286,-1.366971595424509,4.504788608963466 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark05(-0.4412082020122391,-1.5707963267948966,31.576445594865422 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark05(-0.4417159220963945,-1.570796326794898,524.6457202220666 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark05(-0.4430763002369247,-78.85104507055327,1.5707963267948966 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark05(-0.4437802893141599,-3.1417415568180167,-1.5707963267948966 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark05(-0.4440408493282686,-1.4716585896356833,1.0664659733433262 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark05(-0.44441197625158535,-66.00256592225406,1.5707963267948963 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark05(-0.4446140841951027,-135.18892133525907,9.314058520205574E-9 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark05(-0.4460965452245863,-0.09542478594981485,83.08415233487986 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark05(-0.4463609551887919,-1.2002847648886399,-21.47587411405931 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark05(-0.4464374118881925,-1.087138902812743,7.064476849658803 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark05(0.4469702436452445,-0.1969023252079487,50.2657426279684 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark05(-0.44754947767334385,-72.25663106236759,0.2042979833919727 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark05(-0.44820526012861495,-1.3650207106248047,20.665306638031495 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark05(-0.4483490636669345,-0.9860854200872726,56.040940958132246 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark05(-0.4494408557792553,-10.430948021401734,-5.714936956411375E-101 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark05(-0.4498738183323348,-1.4200621108631557,22.247926354268266 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark05(-0.450059050440291,4.141592653589802,-25.618856385698177 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark05(-0.4501536110221168,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark05(-0.45023180681992125,-1.5707963267948966,-90.0521466460356 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark05(-0.45077735598216645,-66.77692245437675,19.47916268678801 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark05(-0.4509773876416997,-1.570796326807831,-159.24294598563256 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark05(-0.4510291531171396,-1.5607856275304315,-0.2650421113986792 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark05(-0.4511269682732957,-1.5707963267948966,6.351572144012991 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark05(-0.4524621665869919,-0.6932653411376677,-40.076288275666826 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark05(-0.45262235211299057,-54.66817637537596,-4.14159266477667 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark05(-0.4537136432607429,-0.7422971865927003,-1.5707963267948966 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark05(0.45392870948506064,-0.4639843634603402,-146.20233990321415 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark05(-0.4544419215713243,-1.5707963267948966,-1.3481295771431721E-16 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark05(-0.454528747252709,-63.55221867908802,1.5707963267948983 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark05(-0.45474732413108915,-1.5707963267948966,28.186561768553418 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark05(-0.4547508512472262,-53.40707558786632,-1.5707963267948966 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark05(-0.45476508001789906,6.429500331566808,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark05(-0.4548461205128139,-1.5490367659397273E-120,-0.15971635398814832 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark05(-0.4549567442169007,-61.099909626956745,-1.3509129490160907 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark05(-0.4552166720942129,-0.0039373105860452465,-1.5707963267948961 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark05(-0.45594203670155936,-66.51881163152575,67.86996626372033 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark05(-0.45598168778742154,-1.3877787807814457E-17,4.097562602534495 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark05(-0.4560100902642025,-1.5707963267948912,-1.5707963267948966 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark05(-0.4561776088841176,-0.06650397239188793,-1.5707963267949197 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark05(-0.4562326222595664,-0.5573707567537016,90.20781475743854 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark05(-0.4564115080769396,-1.5707963267948966,76.22854637186055 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark05(-0.4565295483347791,-1.5707963267948966,-819.2950831737087 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark05(-0.45667741682615237,-1.3755199944736907,44.79805242161885 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark05(-0.45675599668668815,-0.035305579576396504,-25.178245757859305 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark05(-0.4574300205015658,-6.938893903907228E-18,6.776263578034403E-21 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark05(-0.4577739726466916,-84.97552547413574,-1.5707963267948966 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark05(-0.4590242619763558,-0.5568783918605017,-40.987849824329025 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark05(-0.45913841428361873,-66.49245529491206,-64.47316926536746 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark05(-0.4596348994023529,-9.649200404958595,-41.837649436219095 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark05(-0.4601808389726723,4.14159266916931,0.7928954533698666 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark05(-0.4602359644286804,-1.5707963267948966,24.04148614374914 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark05(-0.4604964699134104,-1.4803389995483087,6.283200566363031 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark05(-0.46055587215055527,-658.1593787108545,-141.19853485939686 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark05(-0.4606264379156514,-0.003383261830493057,-35.566463696628844 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark05(-0.4606420280252646,-22.44031428917144,-79.89374595988949 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark05(-0.461148952364102,-54.84036821072877,-134.0688156498457 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark05(-0.46155756824231553,-3.141592670342365,56.42157092952539 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark05(-0.46169049415972746,-35.01102691724563,35.313060084558714 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark05(-0.46196800142292527,-15.812799053339276,-1.5707963267948966 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark05(-0.46230071585363425,-1.5707963264655047,-82.5400975039541 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark05(-0.46234661618033424,-0.33579895325090275,-0.6737381596348447 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark05(-0.4631911878019479,-59.847922833068964,-22.087162133133205 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark05(-0.4633434429733323,-111.3583898769183,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark05(-0.4634278250251454,-15.751882597960812,-1.5707963267948966 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark05(-0.46348800075107077,-9.326968594094714E-14,-223.83311835156098 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark05(-0.46365024187497206,-47.57392291048581,-42.006242866908906 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark05(-0.4649966495167356,-1.5707963267948963,-90.9818452837686 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark05(-0.46524960217032485,-1.5707963268769474,0.10850317402699453 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark05(-0.4655037458592382,-1.5707963267948966,31.99025317500046 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark05(-0.46588188695461963,28.70407408286764,442.11742250517045 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark05(-0.46600684860390784,-1.5707963267948966,1.1096773297281587E-15 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark05(-0.4667174292763601,-0.044461428570870556,-674.8591350304541 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark05(-0.4668810068339062,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark05(-0.4687123160676483,-0.02804054250432031,26.229040896917073 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark05(-0.468928907389933,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark05(-0.46987140234993774,-1.5707963267948912,-20.913450639881347 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark05(-0.4703357439008734,-66.34056282115907,1.5707963267948983 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark05(-0.47037527279738994,1.3552527156068805E-20,12.499117156248275 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark05(-0.4705015737518554,-1.5707977120509582,329.86693397250434 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark05(-0.47075485940224404,-1.5717195297401945,1.5707963267948966 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark05(-0.47124688759465416,-1.0010415475915505E-146,-1.5707963267948966 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark05(-0.47179539393740433,-1.5707963267948966,-46.535130881622955 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark05(-0.47192445495160673,-78.81423116657265,9.380224711501313 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark05(-0.4719403259900714,-54.82289626192017,287.43572267989293 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark05(-0.4725993865159631,-9.487277960769381,43.684948588388075 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark05(-0.47265154420067057,-1.5707963267948966,4.712392406179493 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark05(-0.47334482361572106,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark05(-0.47367289076471686,-1.5707963267948912,8.152330757143215 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark05(-0.47383405975235976,-1.5707963267948966,-51.839677425680705 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark05(-0.47500833768659456,-0.1418985093137941,-1.5707963267948966 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark05(-0.47536666825101787,-9.99810977420988,-7.853981760788146 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark05(-0.4755521811677199,-0.2577568461879265,-6.283185307195643 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark05(-0.4766427210082008,-3.266592654346542,-20.887075069984704 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark05(-0.4774244138628505,-9.754442009358845,-317.9939335826075 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark05(-0.4774667929559218,-0.7398243354118709,1.5707963267948983 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark05(-0.47894413203973163,-173.12408097188867,-77.40768134551105 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark05(-0.4793301800264689,-1.5707963267948948,-11.550402157330346 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark05(-0.4801256044523786,-0.7850630362212386,-84.31789740057121 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark05(-0.4815965050832176,-0.004497425155399484,42.77617265592512 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark05(-0.48160826769849674,-1.5707963267948966,-63.97626832680575 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark05(-0.48185501056632063,-78.6809868637902,-6.198144460928418 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark05(-0.48234985886508674,-66.50443193981351,165.28018571650813 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark05(-0.4838066618160042,-1.5707963267948966,32.541334325888016 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark05(-0.48421268737343376,-1.5707963267948966,82.79782460013024 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark05(-0.484679375819689,-98.18145642912862,-1.5707963267948966 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark05(-0.4847339223866163,-1.383134411948381,-10.738038196461403 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark05(-0.48478490021079246,-1.5707963267948966,-13.713182763350986 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark05(-0.48500860471706586,-0.5409179670535794,1.5707963267948963 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark05(-0.48574311225042077,-8.881784197001252E-16,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark05(-0.486307408980695,-4.384577513129553,-1.2806760179201584 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark05(-0.48654410380361235,-3.447076288571438,114.79575662151682 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark05(-0.48695626148824545,-91.66825464194224,-112.09444517255154 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark05(-0.4871711729982203,-1.5707963267948328,78.35251325941402 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark05(-0.4877561964759046,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark05(-0.48896735750440823,-72.47543677518,21.901695934095102 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark05(-0.48908995102234826,-4.553106581737339,-67.08955588509657 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark05(-0.4895860008554419,-1.5707963267948966,-77.21646569405614 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark05(-0.48983222840120233,-0.07346519003309437,-1.1103514453073835 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark05(-0.4910173449718213,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark05(-0.4914188479685251,-1.5707963267948966,-31.54568465423707 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark05(-0.49211874807046413,-1.5707963267948966,-8.615582517981725 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark05(-0.4921798587864714,-1.5707963267948966,-84.66641373632811 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark05(-0.49334082378657995,-0.9968841935001267,-1.5707963267948966 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark05(-0.49415629960302243,-98.79666575802634,-54.57422824351325 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark05(-0.49443189607615134,-60.71103858139572,-23.533565017023726 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark05(-0.4947920950719368,-3.5789866003332538,1.5707963267948966 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark05(-0.4950603740206557,-79.63035636569424,-47.92593051661014 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark05(-0.4953892692610196,-59.927666812916435,-22.49105004549156 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark05(-0.4957969762703321,-1.5707963267948966,91.0418289884987 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark05(-0.4959468409297061,-28.906780445115505,-3.508228547792195 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark05(-0.4963997876093345,-1.5707963267948966,0.014261969322095273 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark05(-0.49682015194694973,-1.5707963267948966,-28.998313413956208 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark05(-0.49687737885726524,-0.9762946410710204,6.283760196390753 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark05(-0.49732149078341925,-0.8120054018983642,27.223390724918964 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark05(-0.4978343691444223,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark05(-0.4980482160476134,-66.29633798443152,-21.91001049064656 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark05(-0.4981306342330852,-1.5707963267948966,-8.103981634083794 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark05(-0.4983211572639217,-54.46590152822854,91.36402652472475 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark05(-0.49865152299977394,-1.5707963267948912,24.489806687187695 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark05(-0.5000892098116703,-15.7815926679137,1.5707963267948966 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark05(-0.50030032700212,-66.105597675548,-1.313599890235156 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark05(-0.5011352870101575,-18.596095736827394,89.36546039216702 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark05(-0.501707942677058,-65.98113663564874,128.14095311342618 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark05(-0.5021309150952358,-9.532968582016082,71.05018833706552 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark05(-0.5034636300320627,-1.5707963267948966,15.793007660711147 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark05(-0.5039515128376608,-3.141592653634157,100.0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark05(-0.5046598312143411,-1.2299765508350475,-182.41702444710958 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark05(-0.5049227818394597,-61.24284027259041,3.1494052195673943 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark05(-0.5050060576113964,-122.64019501092812,-46.26448283042012 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark05(-0.5059350393415923,-72.91039195523838,-0.17727948457773934 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark05(-0.5063826034321428,-105.06140479325524,-77.23320798828227 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark05(-0.5067098018669155,-15.735411607585421,71.21145936753575 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark05(-0.5077692908170128,-61.2509897899527,0.3346897540177878 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark05(-0.5077845710990199,-53.495979806928204,45.48718882472268 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark05(-0.5078554871694718,-1.5707963267948966,-29.251760765880547 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark05(-0.5080480481846036,-0.2270776740090265,35.51591280593715 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark05(-0.5080926965391254,28.703537556721713,168.37267537410435 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark05(-0.5088056865592072,-41.71272261178476,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark05(-0.508894777148539,-54.41045835310697,24.49915118148346 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark05(-0.5092613346780572,4.0389678347315804E-28,82.40627993558516 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark05(-0.5093386736357361,-66.26601810055504,-97.199305828163 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark05(-0.5101542810067569,-0.6626329934516385,3.142081150679902 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark05(-0.5115526832524907,-3.272651599085435,50.240394495632984 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark05(-0.5117122503717617,-41.95193238722258,54.336850609819265 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark05(-0.5121616568557954,-1.5707963267948966,-96.98167209037574 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark05(-0.512740236861021,-1.5707963267948966,-146.1220891686608 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark05(-0.5129401596715489,-35.05788291542716,-604.7546708007462 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark05(-0.5139990184371321,-1.5707963267948966,-1.2942775304634173 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark05(-0.5142367459830638,-1.3484539867737197,0.0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark05(-0.5145618748694942,-129.51297278893622,119.37947385402609 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark05(-0.5150664526962743,-129.12340473436547,-42.193846214283994 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark05(-0.5151326028885176,-48.430721035287,-355.99282547986485 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark05(-0.515504619898806,-1.5707963267948966,-57.38612066397977 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark05(-0.5156274048087033,-1.5707963267948966,-79.5365561361782 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark05(-0.5160502220391692,-98.39593499201128,100.0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark05(-0.5169204067057492,-0.06121142048341488,-75.80703070339405 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark05(-0.5169963293572835,-35.130027929708774,51.04421597696128 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark05(-0.5170576791920716,-1.5707963267948877,-3.1420809457509415 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark05(-0.5174618484972173,-0.022585859837446026,-45.9767816117944 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark05(-0.5177331472274003,-1.5707963267948966,21.51044836980178 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark05(-0.5209820678026333,-1.5707963266248473,0.3340851353727411 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark05(-0.5214831332026865,-0.17583468059054702,39.00746639522284 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark05(-0.5223552469013906,-5.389193030079051E-15,-1.2500090046556995 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark05(-0.5228205562794397,-154.91708777055163,-12.796445468046219 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark05(-0.5228317858387349,-1.5707963267948966,-7.8066817360454905 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark05(-0.5239751323311943,-1.5707963267948966,48.33191648603969 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark05(-0.5242315030874038,-1.5707963267939395,90.35826539668638 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark05(-0.5245676959242226,-72.58836238293031,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark05(-0.5247472190037805,-91.78096984960037,-54.311898221804555 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark05(-0.5255475706189559,-16.00150631178503,13.538194018215108 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark05(-0.5260757784326127,-1.0243790158986783,0.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark05(-0.5267842599859932,-53.718314174150116,-1.5707963267931355 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark05(-0.5277311979835316,-1.5707963267948966,-26.75306086912094 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark05(0.5278272253253279,-1.5707963267948966,0.7576136534000035 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark05(-0.527950048663454,-1.469769037951821,-25.728512175959594 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark05(-0.5283116555187295,-98.71412107054884,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark05(-0.5290201335511125,-1.5707963267948912,-73.42964445477229 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark05(-0.5294281126749022,-1.570790176756804,19.33729356276294 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark05(-0.5298356068770431,-1.5707963267948966,-1.2329305897900777 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark05(-0.5299283247382697,-54.104012011722766,-1.2577601398844438 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark05(-0.5300690765411408,-5.551115123125783E-17,55.14711337579908 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark05(-0.5303591063533115,-0.02499694710604461,-0.21099915786965323 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark05(-0.5316221483070006,-3.552713678800501E-15,-54.825979432682544 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark05(-0.5317150108149283,-1.9721522630525295E-31,-0.4237872176612783 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark05(-0.5322492584974206,-66.36767042620754,-32.52345714709976 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark05(-0.5322870111434277,-54.149116092746155,-255.75324623638434 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark05(-0.5339925309130962,-23.380988740931578,-85.19678563647064 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark05(-0.5340696407200843,3.1416002829946645,-16.901139214761862 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark05(-0.5342343362804183,-1.5707963267948961,-0.4922822596906863 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark05(-0.5343487776026414,-0.9830791833747581,0.0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark05(-0.5344925190395049,-35.478991463752976,10.108705419014964 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark05(-0.5347123535502212,-97.7401904351756,84.46171218755924 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark05(-0.5354332116594164,-525.3912231758516,38.459767853850025 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark05(-0.5356789458284412,-34.663995204129066,-53.14480413558777 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark05(-0.5358232606085167,-1.5707963267948521,1.5707963267948966 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark05(-0.5360581813369999,-0.11199578301135392,7.039176952900052 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark05(-0.5372421799491409,-1.5707963267948948,21.174326826232605 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark05(-0.5387365831583498,-3.1647034350675316,2.386802543962521 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark05(-0.5388352585619696,-0.24686543916143716,55.3483326779377 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark05(-0.5396027932961349,-3.8321428410181824,0.0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark05(-0.5397398641401391,-1.2775656682673964E-15,-40.38476929785082 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark05(-0.5399665202922468,-0.8175924756099182,-11.734892173032621 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark05(-0.5403919727493457,-54.54858516932497,32.2277358401062 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark05(-0.541110022486371,-16.60952796112417,-60.422207168467985 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark05(-0.5414146590127871,-0.9933482791049522,64.00347862201173 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark05(-0.5428221649548712,-0.12274001712856676,-71.78594346334195 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark05(-0.5437962458528429,-1.542992021583037,-1.5707963267948968 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark05(-0.5439301256654758,-1.5707963267948966,54.34677033726899 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark05(-0.544177920290791,-0.09642787261878456,-12.104249692259145 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark05(-0.5447957733945614,-135.11653909262418,-23.468886257447778 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark05(-0.545519888183821,-48.127779488400705,28.557018720975705 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark05(-0.5460507700669983,-3.1415926687078524,-100.0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark05(-0.5476842596344653,-85.27346495285447,-59.836549672084715 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark05(-0.5481792945320576,-10.420403484405046,72.51774025684884 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark05(-0.5483151666700247,-1.5707963267948966,-21.16586669457658 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark05(-0.5492041359014751,-1.5707963267948906,64.90109403133377 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark05(-0.5492833888347911,-86.31667806156553,-1.5707963267948966 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark05(-0.5507705901908722,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark05(-0.5507733891219544,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark05(-0.5510057413509268,-1.0060544354087388,-14.429422839429463 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark05(-0.552065683320702,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark05(-0.5530508087179639,-42.05794546993477,-98.42074330442665 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark05(-0.5543568288219112,-1.4626155472043239,7.170503540098858 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark05(-0.5550655704302181,-54.48010272610606,1.5707963267948983 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark05(-0.555478501745594,-3.141600283189053,1.5330463086815935 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark05(-0.5556284276124668,-1.570796326794893,-1.5707963267948966 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark05(-0.5556302003853091,-1.5707963267948966,45.17723518894633 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark05(-0.5570649919004673,-1.5707963267948966,-1033.9653168032937 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark05(-0.5571329492857579,-1.5707963267948966,-86.39379797371932 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark05(-0.5572969935814595,-72.50420623802395,45.60447274097629 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark05(-0.5580365823165067,-3.8515064633465546,-13.853424466227313 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark05(-0.5590777660442825,-73.03196725268006,1.5707963267948983 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark05(-0.5591443951145015,-0.08243891195213457,39.41544308496333 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark05(-0.5598095635722684,-0.999342742228259,-40.84502118198398 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark05(-0.5604925800908023,-97.9245084892595,-12.89021953482029 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark05(-0.5606877158370147,-0.1952783398336969,27.768483283797323 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark05(-0.5607874421109451,-0.6439927576087197,-1.5707963267948966 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark05(-0.5615496809303852,-1.5707963267948966,92.00232870453667 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark05(-0.5617276255411321,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark05(-0.561795370930759,4.141592653701393,-67.50590002316933 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark05(-0.5620535534922718,-1.5707963267948961,1.570796326794871 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark05(-0.5621887733100063,-66.8442721378579,-8.294365826802075 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark05(-0.5625034018166254,-66.74088168445252,-21.871072543665605 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark05(-0.5639994088170711,-4.10517085599294,-85.43560497779976 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark05(-0.5648234251825014,-0.5425604554972598,-18.857368693312903 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark05(-0.5651772854334597,-61.2338045672819,66.36203447821816 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark05(-0.5657976467892395,-0.8565495857670431,-100.0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark05(-0.5665348783806997,-0.38473211205427726,-1.5707963267948966 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark05(-0.5673187678794958,-130.11922452031035,-56.2059072232602 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark05(-0.5689630647644037,-22.70039574219477,-47.596231127041314 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark05(-0.5693044097386704,-1.5707963267948966,-95.11166437075062 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark05(-0.5694628343355825,-26.504434441527213,-1.5707963267948966 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark05(-0.5696164560929989,-1.5707963267948966,-21.80213235332377 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark05(-0.5704017104010557,-1.1102230246251565E-16,544.4721857709444 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark05(-0.5705005774666542,-16.776903000961497,-1.5707963267948966 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark05(-0.5708683622880039,-10.793143719581515,7.854097242687458 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark05(-0.5710056961311208,-631.7311240475932,-72.85348985455738 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark05(-0.5711087688679264,-97.40052032323764,42.2951969575275 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark05(-0.5713494860775699,-41.04157235395491,-26.099607097148514 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark05(-0.5727540422336878,-66.40969960536682,-72.23299454850118 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark05(-0.575105692865876,-0.6833278505960415,-30.881827516875727 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark05(-0.5755833371885728,-1.570796326794817,55.39477842016021 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark05(-0.5768173142367723,-48.37289935519345,33.3966189205516 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark05(-0.5770243319462987,-1.5707963267949054,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark05(-0.5771325399460885,-1.5707963266747642,0.037729427614249425 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark05(-0.5774554205351867,-1.5707963267948948,-3.1415926535897953 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark05(-0.5774736496556621,-0.6729846860781176,3.145100826709249 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark05(-0.5778100218969473,-60.75811499354129,-44.52445409283133 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark05(-0.5778997532150691,-1.3149633930680826,14.451715595277918 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark05(-0.5780014394042884,-0.9675549745397025,-66.34266908661331 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark05(-0.578433467715989,-0.10783039397655592,20.75484648655015 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark05(-0.5786295592291288,4.14159265376504,100.0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark05(-0.5789633755901878,-3.1416002841865858,-21.636016788982133 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark05(-0.5790282801683294,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark05(-0.5798425325868806,-36.074302568361155,-29.342518188982865 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark05(-0.5798808959094153,-1.5707963267948966,-45.222262472997976 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark05(-0.580555183076494,-1.5707963267948966,1161.0245032384842 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark05(-0.5805819832560861,-0.6051804094711883,55.14269239251476 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark05(-0.5807108140191205,-0.9275205229256331,20.59991614944048 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark05(-0.5814574868378016,-0.17265024072760649,-78.11140752070456 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark05(-0.5819451774193828,-123.0547599501586,4.14162046587262 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark05(-0.5839548961960901,-1.5707963267948968,0.8834843587518435 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark05(-0.5840864375874887,-1.5707963267948966,-14.613864863993825 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark05(-0.5846686786081927,-0.45627200558111625,-14.137291251646646 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark05(-0.5858241234049464,-1.5707963267948948,-22.321299918283366 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark05(-0.5864467847285365,-1.0505171069615884,-20.069119475343 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark05(-0.5864943953861461,-9.937785708258545,-45.17380454981587 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark05(-0.5866063540213037,-1.1102230246251565E-16,1.5707963663814444 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark05(-0.5874206339975172,-1.5707963267948966,44.28803539256506 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark05(-0.5877241911517057,-72.42214479336222,-35.29794717347285 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark05(-0.5879979994488321,-1.5707963267948966,3.944304526105059E-31 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark05(-0.5884021796050367,-1.5707963267948966,-14.72025214210534 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark05(-0.5885802018625483,-1.5707963267948966,-10.425735598594352 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark05(-0.5887135259802422,-79.82838080407463,-16.8812185933629 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark05(-0.5889823930291449,-1.220604912478239,65.16619654794334 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark05(-0.5899406262932514,-78.95494905653142,25.318622370161624 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark05(-0.5903238671407544,-1.5707963267948966,24.612959676644024 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark05(-0.59094034753912,-1.5707963267948986,55.477271684732614 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark05(-0.5914271003529166,-3.283658007879964,-0.41462750086564415 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark05(-0.5915630522629023,-72.55106563489126,-4.60561365314544 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark05(-0.5924783890831353,-1.5707963267948948,-27.884743563189573 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark05(-0.5925219740748304,-0.09502656671636887,32.22514416057769 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark05(-0.5925270909083376,-41.69722326687466,1.5707963267948966 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark05(-0.5927807306598312,-0.24137755851487727,32.17328383179029 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark05(-0.5928297618145602,-1.5707963268030647,0.0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark05(-0.5933522745837321,-1.501514549595793,-73.04301867400949 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark05(-0.5933724481388346,-1.1635702914754922,-72.47140591934716 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark05(-0.5937465224819103,-0.07047800931593064,75.47509061487662 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark05(0.5944072107824122,-1.5707963267948966,-2.2483002901899716 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark05(-0.5944929106332992,-53.595190483099856,69.75657351734708 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark05(-0.5960099689211233,-110.31119255228876,123.39491958190646 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark05(-0.5962209424106331,-1.0803959129521896,66.0800146852331 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark05(-0.5968669967797784,-67.25131094516388,-97.87922077807326 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark05(-0.598468647185272,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark05(-0.5986935313233008,-1.5707963267948983,-147.26879267320356 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark05(-0.5988142109154566,-66.59553134601569,-20.420352248333657 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark05(-0.5989722623371563,-0.4038337915515733,119.0180672833725 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark05(-0.6006303484913447,-1.197984835918224,1.4010626813467977 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark05(-0.6008075725460502,-0.33902361299518,56.24902422095451 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark05(-0.6013803470437235,-0.6745821393870721,7.086634353948123 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark05(-0.6014248645687997,-92.25990960205799,-72.89786754996811 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark05(-0.601970512806058,-48.00552360255095,-56.326616193806075 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark05(-0.6027250910778932,-0.17443634611016412,-52.39275789321643 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark05(-0.602796810549959,-1.1763985387530056,-4.712388997824904 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark05(-0.6035895916948188,-123.05184955426824,35.63030933040122 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark05(-0.6046021117166156,-0.37829935140292575,-20.13331555159334 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark05(-0.6063464144492521,-92.28236845587755,-54.82254338005425 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark05(-0.6067195345672521,-1.5707963267948948,67.1591552090476 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark05(-0.6071705249141791,-35.86357193277754,-1.570796326525433 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark05(-0.608113342730618,-0.9678070457295863,-45.05531510976386 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark05(-0.6086843429833328,-1.5707963267948912,34.50114247953645 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark05(-0.6088438109835618,-73.05250679782024,-77.5131757933873 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark05(-0.609501863132202,-1.5678172893946187,-553.0546398460837 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark05(-0.6134821912742012,-78.72190744323264,23.94166753906005 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark05(-0.6135226314348703,-129.14810957743762,-58.90128594124899 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark05(-0.613930396979256,-48.426296387683074,-61.47618175154627 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark05(-0.6145953994948442,-1.5707963267948966,13.632142867356112 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark05(-0.6149826862783542,-9.576956953989239,56.14589830999688 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark05(-0.6151825076519071,-35.715770501096486,-66.26039419801285 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark05(-0.6158217596316226,-1.7763568394002505E-15,-42.734025068965444 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark05(-0.6158860107197865,-1.5707963267948966,16.34933598739216 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark05(0.6171480303823328,3.1423921426666115,-28.10891740466582 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark05(-0.6175446066795518,-1.5707963267948966,0.09590812903826987 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark05(-0.6182406734523527,-72.83025722272498,132.41854856071865 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark05(-0.6190350045874645,-73.21571257720748,-1.5707963267948966 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark05(-0.6193886690351854,-1.5707963267948966,72.26444356428792 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark05(-0.6205443259149803,-1.5707963267948966,12.568333200420993 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark05(-0.6206226516246326,-9.929718835812562,-84.86502628659724 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark05(-0.62062625701614,-78.86227984571734,22.475384530125464 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark05(-0.6209058446639181,-47.24598207503601,0.0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark05(-0.6218841470521869,-54.866236228528976,1.5707963267948983 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark05(-0.6221282460766417,-1.5707963267948983,4.694983999689711 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark05(-0.6224154505329977,-117.31266491279172,76.00309634755311 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark05(-0.6235677476537544,-1.2615712497787417,-29.845130209103036 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark05(-0.6239101140327515,-41.113471725567095,-42.12198150662656 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark05(-0.6240204288716064,-0.6954043914202828,-118.23425308695967 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark05(-0.6241256816897804,-72.36937391833895,-2499.1068040991067 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark05(-0.6250992538319372,-3.141601390268248,-69.96302216476931 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark05(-0.6259114785769281,-53.597045974869786,1.3136820353375498 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark05(-0.6260543764267859,-16.12716838376386,-16.539265458357463 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark05(-0.6265532662181461,-3.2669254641912815,-1.5707963267948966 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark05(-0.6267833791976516,-35.453133893939935,-20.965071853528094 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark05(-0.6273133671440388,-0.37263316106355165,-47.56506143205856 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark05(-0.6280009252147227,-42.30782417524601,107.93904369493268 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark05(-0.6293299272341238,-1.5707963267948966,26.05888336781001 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark05(-0.6302067327888525,-0.23221238104288888,0.0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark05(-0.6309146460454513,-0.28617632587504194,40.13398005566466 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark05(-0.6314864215909258,-122.93786436589743,-3.5717918890295106 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark05(-0.6317250641581843,-9.932181215421792,-12.566370643067845 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark05(-0.6317851133746566,-35.57756038633272,1.5707963267948983 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark05(-0.6319981743902692,-1.5707963267948966,20.681060032283074 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark05(-0.6321958571161975,-3.14354577858985,1.5145716249272092 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark05(-0.6331576735084431,-1.5707963267948968,44.883195037952326 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark05(-0.6342585779867153,-0.7049340525723968,1.5707963267948966 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark05(-0.6359217867669149,-1.0169254493324462,6.759372929106146 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark05(-0.6374753868028449,-1.5707963267948448,-34.785718353039385 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark05(-0.6375276097842946,-59.69123781916143,-1.5707963267948966 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark05(-0.6392964952530935,-78.83317905076818,31.75366175320721 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark05(-0.6393508093646832,-59.89109460049698,-60.613431635978365 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark05(-0.6398705596496841,-9.516170910563991,53.65702906850029 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark05(-0.6402369368845428,-9.999267503245818,-1.5707963267949197 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark05(-0.6405368032429894,-1.5707963267948966,10.02122541901643 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark05(-0.6407179911583266,-98.66757871423083,78.53987737504589 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark05(-0.6438113363138979,-1.57079632679488,-79.15655735712292 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark05(-0.6457092741962365,-41.133336983588585,-72.4843622652873 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark05(-0.645988366888345,-1.3646591101294039,-25.871676529475582 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark05(-0.6468984956754018,-1.5707963267948966,-1.5707963267997849 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark05(-0.647458252258204,-1.4346987359176133,1.5707963267948966 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark05(-0.6498485884304159,-0.02700309998390149,-37.48675893218596 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark05(-0.6505326250170561,-1.435003191874302,91.043697222371 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark05(0.6517410978652046,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark05(-0.6519015906146421,-9.533275106844135,-3.168165937529686 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark05(-0.6526007620124148,-73.16631341515892,-1.5707963267948966 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark05(-0.653287015691993,-0.08556014766995512,1.5707963484983876 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark05(-0.6554186907243675,-28.874883469703143,0.0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark05(-0.6556253523441923,-48.13282125280974,421.96053735633126 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark05(-0.6562978947721518,-73.82163203692531,-72.61899147506689 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark05(-0.6570508796701622,-1.5707963267948966,-87.96459430051421 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark05(-0.6579809003242547,-1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark05(-0.6587597803813717,-41.81917502338975,12.731769231347393 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark05(-0.6592340515805117,-22.3097895431955,-6.2839628755384345 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark05(-0.6593179776967943,-1.5707963267948966,1.4573006188301842 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark05(-0.6594611131974081,-22.325565855366627,-91.1100932041046 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark05(-0.6603062700422466,-1.5707963267948966,-4.199820594148157 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark05(-0.660432778520529,3.1420809361482203,-0.03763922730614835 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark05(-0.6606753385988321,-3.552713678800501E-15,63.42187010171417 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark05(-0.6608026021075011,-35.99205872926817,1.5707962993831157 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark05(-0.6613124302389934,-1.3411761662138784,-78.06964580479584 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark05(-0.6615924886895634,-1.131427221937531,4.108597864974065 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark05(-0.661832166646505,-84.88958631277366,74.51785458774538 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark05(-0.6621592153449276,-1.0806953082984725,-22.00341357488928 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark05(-0.6639151113478552,-0.7063800655030523,56.084361901673816 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark05(-0.665343376199874,-122.92573968033086,-7.854598168426864 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark05(-0.6654469686202424,-0.5651221648773076,-20.886708301376622 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark05(-0.6671983666465398,-0.12062880573604251,-84.37218759608585 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark05(-0.6673348639126095,-1.5707963267948966,37.15692009824822 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark05(-0.6685428082629227,-1.5707963267952154,264.1027024717461 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark05(-0.6700325337238277,-48.379395338105645,55.0348689847581 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark05(-0.6700395561302853,-1.5707963267948912,24.208020797851873 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark05(-0.6701269349088683,-34.571645688349776,-109.99082261993826 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark05(-0.6703142321747286,-0.756918683801473,-91.68126435228557 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark05(-0.6711053768644323,-78.78421507822584,111.54250878092397 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark05(-0.6713254612005131,-1.039486506465658,1.5707963267948966 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark05(-0.6713932717035802,-1.5707963267948966,82.96200861225694 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark05(-0.6724790620988819,-1.5707963267948966,1.5707963267948972 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark05(-0.6725001492898034,-9.462727629487688,-91.17425309938963 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark05(-0.6738949948131765,-0.6569076997418646,-77.46920835308846 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark05(-0.6745854495192646,-73.03715166400686,1.5707963267948966 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark05(-0.6762166822030853,-98.72674333480563,66.34228753225524 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark05(-0.6765125514643012,-1.3655391703280952,-1.509166526700384 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark05(-0.6769870470864306,-1.5707963267948966,-56.00099726802688 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark05(-0.6775285835218376,-0.10216094938746628,77.72290725412208 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark05(-0.6788209942770415,-1.5707963267948966,77.36016569552221 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark05(-0.6789041732391758,-15.928444337664189,-664.3907434576682 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark05(-0.6796922080542256,-48.572934255940545,-5.794847985960292 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark05(-0.6798020984349504,-104.73537602126038,-25.692323480883594 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark05(-0.6800212512142092,3.1415945609384317,-90.60595850526721 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark05(0.6808230978922614,-1.5780702188042965,35.65034419904634 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark05(-0.6809295157185058,-0.5596585020244103,-56.41290241486438 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark05(-0.6809721439101728,-1.5707963267948961,1.5707963267948966 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark05(-0.681068346882206,-0.339952673147263,1.5707963267948966 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark05(-0.6823531355209838,-29.521664817321156,-92.15085072389611 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark05(-0.6834315654910812,-713.6495183909216,80.71499967032463 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark05(-0.6841813268971695,-78.70182853981748,-69.16669650060214 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark05(-0.6864623848737295,-570.0614415215105,-56.50859385214426 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark05(-0.686542757008704,28.703537571310573,-1.5707963267949054 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark05(-0.6874078123952319,-1.5707963267948966,-75.11683859431261 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark05(-0.6878421376123679,-5.077236486889566E-5,69.56463792134778 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark05(-0.6883353074260985,-84.88618626876558,-72.30369009168658 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark05(0.6885547080798273,-66.75089062698002,33.88076960200544 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark05(-0.6891978236521858,-1.5707963267949054,-37.4354601584602 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark05(-0.6892567045239133,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark05(-0.6894805976141787,-1.177543586652974,9.201737005345791 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark05(-0.6915042837259553,-53.95295587852266,-3.142142861228078 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark05(-0.6916130291773972,-42.18512889531339,3.141592653610084 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark05(-0.6920291700282076,-1.5707963267948963,78.76531365920052 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark05(-0.6927896472263164,-66.74722381343894,-57.68974569991025 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark05(-0.6929943450431875,-1.5707963267948872,-16.35830953388178 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark05(-0.6930795169470301,-0.0018269081386054664,48.69469925455867 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark05(-0.693696741179367,-518.95651950071,56.06049882681512 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark05(-0.693823219618349,-1.5707963267948966,-1.6650410694854505 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark05(-0.6939058142683885,-1.5707963267948966,67.08229486556183 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark05(-0.6947052551273423,-72.61670140660836,-56.17994186604341 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark05(-0.695213369301294,-1.5707963267948966,71.5010069460692 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark05(-0.6952754818410893,-1.5707963267948664,-80.62465839557112 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark05(-0.6958542704282153,-1.5707963267948968,-3.141593272017354 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark05(-0.6961963285505934,-72.75260862848721,-56.461713367326816 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark05(-0.696764838673731,-0.5658488180774316,-30.769342254793692 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark05(-0.6970829684942943,-1.1042240562236645,-1.5707963267948948 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark05(-0.6975266070931729,-0.2573210463864242,-15.447778080952048 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark05(-0.6978340808158063,-16.212661847298396,-3.1417781201617854 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark05(-0.6986791828453534,-1.5707963267948966,62.300201306074484 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark05(-0.6990132797339186,-0.05566948666829239,0.0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark05(-0.6994736988993286,-5.1253327236687384E-144,-1.5707963267948966 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark05(-0.69962304333297,-1.5707963267948966,5.6446173453096975 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark05(-0.699736945221227,-1.5707963267948948,635.3951958066373 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark05(-0.7006042764607656,-506.7645077768646,-110.65325175292487 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark05(-0.7043583709338791,-1.5707963267948966,64.44341854979196 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark05(-0.7045933856002888,-1.5707963267948963,76.47647588213502 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark05(-0.7069474382477778,-1.5320915072366974,60.997218068867845 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark05(-0.7075012313196268,-53.45925886475697,-0.38903145045265275 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark05(-0.7080573594778664,-0.7553511542662221,41.43367881030982 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark05(-0.7090547082600998,-1.5707963267946912,-90.30614878784051 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark05(-0.7092263079096384,-1.5707963267948966,93.29592518463724 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark05(-0.7099120912245122,14.429706384543593,12.597621921927683 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark05(-0.7099501811165875,-0.03279708239629164,1.5707963267948966 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark05(-0.7100039582063892,-0.049545847654116515,-100.0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark05(-0.710448552341159,-1.5707963267947598,89.25165257917155 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark05(-0.7112660684125581,0.8704801447379892,-95.46906078176937 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark05(-0.7126870134573157,-500.0758718084838,-23.471261484037754 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark05(-0.712863474926964,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark05(-0.7131713031453781,-60.846227692073384,-89.70508331325621 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark05(-0.7133594269419185,-3.141594144955178,29.527137872202402 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark05(-0.7139929482707474,-688.3803790245204,1.5707963267948968 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark05(-0.7148142320497782,-1.5707963267948966,8.853978478391445 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark05(-0.714844720013061,-1.0140195414401638,-62.28740570721453 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark05(-0.7148879268173562,2.622919108549025,0.0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark05(-0.7150281155902991,-1.5707963267948966,-57.112689734094666 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark05(-0.7166354592876383,-4.689578158158838,-10.524430450952615 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark05(-0.7173070233113914,-0.570621616832475,28.766345497785494 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark05(-0.7175097353474579,-1.9357930236315232E-15,-59.491997448182026 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark05(-0.7179144860335516,-66.54274866741272,-57.670758555186154 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark05(-0.7179574760002451,28.725299331660455,49.769494005199164 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark05(-0.7192046477027723,-41.46443762948,-19.669310571202097 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark05(-0.720167078098541,-47.40189444094156,-3.612724266595791 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark05(-0.7203585193290962,-54.538306921513154,-75.08355336155834 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark05(-0.720505535574772,-3.2665926548370523,88.98397593507568 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark05(-0.7210058505133896,-48.68693939863386,153.59080713967984 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark05(-0.7216550469894618,-79.31563344898626,-161.14217902595337 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark05(-0.721884306886919,-1.5707963267948966,-192.77099736634995 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark05(-0.7220320948403833,-3.141592892043738,100.0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark05(-0.722314966618426,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark05(-0.7226830857403286,-1.8101995628622396E-4,-151.46987248568553 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark05(-0.7241921382605475,-40.984608039353,-1.5707963267948966 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark05(-0.7249858643419012,28.703537555521272,-80.83967412503354 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark05(-0.7263566785193886,-9.521761176192229,-87.55168773071435 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark05(-0.7270888613390497,-3.1435457785897936,-95.35139826404617 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark05(-0.7279015749539817,-35.96334605879167,-1.5707963267948968 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark05(-0.7287005612659581,-4.125125835194167,-94.11586985077483 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark05(-0.7289193885859646,-1.5707963267948966,-92.44930689145039 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark05(-0.7292052257109305,-1.1969686108439337,-84.18043984227805 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark05(-0.7294218362783251,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark05(-0.7298353314740197,-3.1416234785920962,-42.661083403881015 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark05(-0.7299121900383939,-1.3522910893601219,-1.5707963267948928 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark05(-0.7305706597734698,-1.5707963267948966,-59.422866672573264 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark05(-0.730831965608646,-0.36106732703703415,7.8902302648993485 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark05(-0.7311809706993094,-3.1416537282868555,-1.5707963267948966 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark05(-0.7315046110004375,-97.38937226128365,16.189981371596303 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark05(-0.7316312238969492,-3.1632448267244753,4.712388984815341 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark05(-0.7317025101572748,-41.047724561940555,48.10080392825293 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark05(-0.7328416884111152,-1.5707963267948963,-89.58502049336332 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark05(-0.7331980715742806,-3.552713678800501E-15,1.8643966319001777 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark05(0.7334842184651688,-1.5707928084460483,-21.94309448886296 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark05(-0.7339041654952676,-3.168552998989557,-0.42517915117845595 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark05(-0.7349242850728489,-1.5707963267948966,-26.71762368218979 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark05(-0.735042833392266,-0.09353114112778468,25.722050326745464 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark05(-0.735108387857401,-537.4170233088413,-1.5707963267948963 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark05(-0.7351910951765785,-1.7763568394002505E-15,-13.908775237498624 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark05(-0.7357761363314204,-1.5707963267948664,80.22335630362215 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark05(0.7362998621228627,80.28563760582571,-70.01413054852934 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark05(-0.7378254324517037,-16.020000771950198,-37.18888424250968 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark05(-0.7382442198442122,-0.38627391798728516,50.48986184056613 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark05(-0.7386317752094709,-91.1354718701158,-3.182108891280291 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark05(-0.7400638310540812,-9.939577678618203,-1.5707863223403316 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark05(-0.7401102918922362,-22.282216229564156,0.5708624344338334 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark05(-0.7402725640428127,-3.1435457785899117,-32.93506089598468 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark05(-0.7407636850955791,-1.3415591304369554,-3.141602628176276 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark05(-0.741641256924984,-79.02528891804192,-96.87531041394735 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark05(-0.7419661272566458,-1.5707963267948966,-365.5830765044267 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark05(-0.7421115962084294,-1.5707963267948966,0.661558033965026 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark05(-0.7426195473688488,-135.78472781720205,51.951009869407045 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark05(-0.7427750052737536,-21.99114857512857,-59.09645354272939 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark05(-0.743041245195182,-41.5405153285366,-1.5707963267948968 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark05(-0.7432044939386717,-0.007238084038809239,-88.96242846798376 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark05(-0.7437849894753041,-0.5996444155100197,54.2306209617153 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark05(-0.7440257507668613,-9.598377206154971,64.50874082210345 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark05(-0.7444518061841521,-16.04426291105907,-100.0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark05(-0.7445858703547814,-1.5113841708450524,-9.834633393567401 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark05(-0.7468863399024608,-0.22907576038444652,60.51245408228557 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark05(-0.7472124760022041,-72.9228350627192,-57.18668195130728 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark05(-0.7477859054582546,-29.4695124223136,-50.002158398412874 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark05(-0.7484598036736312,-475.5061354204085,42.84280657703613 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark05(-0.7484755725039689,-29.031584769066125,-42.21220930787831 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark05(-0.7486812167065721,-0.9637134648643568,41.26422647004498 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark05(-0.7499362411430732,-10.321680538077945,-1.5707963267948966 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark05(-0.7502699712599593,-0.4565886858334818,48.64690235678053 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark05(-0.7512906354204969,-1.5707963267948966,14.452982933165028 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark05(-0.751959595218777,-9.424778119977088,-21.993767751005706 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark05(-0.7522083169640807,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark05(-0.7538195148781353,-135.708844538135,-39.922624384805346 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark05(-0.7548574426618425,4.1415926535897984,89.9246915866076 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark05(-0.7555969389367088,-1.5707963267948983,-52.43885587239161 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark05(-0.755629202299843,-1.570796326794897,-6.284161974849706 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark05(-0.7559328684526352,-1.5707963267948966,-6.533185307180626 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark05(-0.7562180528398713,-54.956779865479284,936.1834226244501 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark05(-0.7569731527583182,-1.5707963267948966,-67.88814740849763 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark05(-0.7578736419197027,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark05(-0.7582432503680466,-1.5707963267948966,-84.76068171964569 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark05(-0.7582611820625661,-1.5707963267948966,-3.1416536924624596 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark05(-0.7584407804955179,-66.09323575851882,1.5707963267948966 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark05(-0.7584563868658276,-1.5707963267948966,4.71238898038475 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark05(-0.7594592288574518,-14.72006697295815,-33.05071764098227 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark05(-0.7595529520478843,-0.19041353030780117,50.0459791754466 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark05(-0.7607152003576858,-0.7885849012369104,0.48969677036191817 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark05(-0.7613949473659398,-0.6191154781277973,-128.915898626496 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark05(-0.7614671634216217,-10.088216189447175,-1.5707963267948966 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark05(-0.7615201997887349,-0.6543496072822255,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark05(-0.762288975975061,-22.029021309145914,-0.2068931747722425 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark05(-0.7632572964700481,-1.570796326794892,-22.454914023334027 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark05(-0.7635845767438934,-801.327079927214,-127.16088865565354 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark05(-0.7641593856240165,-34.58519227778511,42.80306149530573 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark05(-0.7660833458479095,-9.975946983609296,86.94983016098368 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark05(-0.766623551490987,-9.48731611700343,1.1570116825760506 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark05(-0.766726876055813,-36.104006077301776,-22.0377161910599 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark05(-0.7667863956900585,-3.141592892009852,0.0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark05(-0.7685387759034202,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark05(-0.7685788239180209,3.1420809348446244,-37.02915441759818 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark05(0.769910343529645,95.07190567734776,-30.651955181483785 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark05(-0.7702349225263145,-1.5707963267948948,-54.72806992632129 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark05(-0.7714092353849606,-66.28533625252943,1198.8194572573925 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark05(-0.7717678106928187,-47.37914059021492,0.0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark05(-0.7724938877835292,-1.5707963267948966,72.96204137183707 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark05(-0.7730527250472758,-3.1416002844989737,66.822660863205 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark05(-0.773413974876193,-1.5707963267948957,1.5707963267948968 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark05(-0.7737857840047493,-66.39811078770668,-20.001644016799204 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark05(-0.7738943161486557,-3.697655316910038,-106.96878548500928 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark05(-0.773972507400119,-3.142399419333601,-16.29609312258954 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark05(-0.7744415844564797,-1.5437140452812095,-14.835400021929786 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark05(-0.7744427387545043,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark05(-0.7750823117163268,-1.5707963267948948,55.70085102267282 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark05(-0.7753519953382684,-54.30606889775436,-15.727402013236613 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark05(-0.7754074621309006,-1.5707963267948966,-0.36567842509168713 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark05(-0.7759202787069137,-97.7133140466606,-1.6016664761464807E-145 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark05(-0.7759901114192557,-3.552713678800501E-15,10.701028554676402 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark05(-0.7769904554004592,-1.5707963267948966,45.27322417085489 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark05(-0.7778175344645347,-1.0325337232169083,-28.803164382254405 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark05(-0.7784806283951419,-21.991392780628075,-119.25010352932075 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark05(-0.7796501262106292,4.2351647362715017E-22,1.5707963267948983 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark05(-0.7797257732563829,-61.25195212226355,67.27096160280631 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark05(-0.7798818935857856,-1.5707963267949054,-51.72651038045327 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark05(-0.779967707423725,-1.5707963267931722,-35.42492874519351 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark05(-0.7801255846241927,-0.7759818180344067,66.36816946301596 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark05(-0.7808098679643592,-1.5707963267948966,-27.93751053980841 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark05(-0.7809007351490258,-104.58515304657364,-1.5707963267949054 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark05(-0.785061014046283,-1.5707963267948966,48.65962282027462 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark05(-0.7850876304186658,-707.9021004512679,99.73749591825546 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark05(-0.7853981633974483,-97.95954739830958,100.0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark05(-0.7860806059493912,-73.3184941350288,-98.82343699994736 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark05(-0.787000369649999,-3.6146102107579594,107.43745616414625 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark05(-0.7881114840670421,-1.5707963267948966,26.533596223134413 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark05(-0.7888313421421558,-10.799933811918741,-1.5707963267948966 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark05(-0.7890195955128881,-1.570796326716995,-1.2713554855025495 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark05(-0.7892670800365147,-60.73038151313667,1237.2549407072984 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark05(-0.7895804826616455,-23.16216358489865,-85.07250353272238 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark05(-0.7898974850216023,-15.918896301504994,-31.929576705709145 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark05(-0.7903161910791461,-1.5707963267948966,46.087824986425844 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark05(-0.79036376688935,-0.16734296507644386,26.610061009709128 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark05(-0.7908868331271363,-61.03524498897337,21.817783958257138 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark05(-0.7914205621434018,-4.627950689992514,-42.53650084656978 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark05(-0.7914545693924457,-66.24320289618676,4.712389066376 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark05(-0.791897208800721,-0.7590881160118161,-1.5707963267948966 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark05(-0.7919299611506824,-0.1443787093724589,0.0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark05(-0.7920838140633275,-708.0839171132294,-102.81533933482437 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark05(-0.7929537812030794,-9.926485601056015,35.393327861702815 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark05(-0.7930511571037062,-22.426902240430614,-47.96562277668058 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark05(-0.793841052263821,-3.143545784203365,-100.0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark05(-0.7950832851616916,-66.5080339169848,-145.44427780369898 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark05(-0.7951287293375984,-48.5044896372625,-31.678393787380287 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark05(-0.7951672836466575,-1.5707963267948966,-1.2906314170342625 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark05(-0.7952626101369222,4.141592653589798,-51.91870974670119 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark05(-0.7954164009181837,-3.1623671468872674,0.8180910396247091 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark05(-0.7957466507512616,-1.5707963267948966,-23.79927433126535 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark05(-0.795843169822527,-0.819969689700605,41.52294886702917 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark05(-0.7961576284014739,-1.5707963267948952,-1.0039691201306198 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark05(-0.7962494234046529,-1.5707963262155702,61.55393887887172 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark05(-0.7964672815375708,-73.08208747740414,139.52079856081318 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark05(-0.7974091449878354,-1.5707963267948968,-33.641332085254895 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark05(-0.7977963653591071,-1.5707963267948957,-77.05023021087514 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark05(-0.7985854089962096,-66.82550260893201,56.6461274704286 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark05(-0.799114714412672,-154.34146493701004,89.65478457810318 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark05(-0.8002611757838088,-3.141600860568122,38.054144612518684 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark05(-0.8017761043641656,95.75690114010806,99.61613900854164 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark05(-0.8028060095183761,-0.6895842774955891,-41.746652043639905 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark05(-0.8037945095289991,-1.5707963268158924,69.95342567576469 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark05(-0.8045849286552862,-122.72627119149092,1.5707963267948966 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark05(-0.8052110857121125,-54.69145539293502,-42.475000772943375 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark05(-0.8062213544757408,-48.31187682235096,80.73552309985365 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark05(-0.8064630645333462,-0.29792476470339757,37.86588186294706 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark05(-0.8073059726756213,-1.4563625236995676,662.6597901464945 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark05(-0.8120015851071827,-0.9848715326626261,-69.25473771739641 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark05(-0.8123157689003253,-1.5707963267948966,-17.000885735896365 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark05(-0.8127920452433304,-78.5644725295823,0.26990454706080413 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark05(-0.8134869493286236,-430.7189014878486,-21.736936066176654 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark05(-0.8142592197349963,-154.16886687090155,-34.55734952016192 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark05(-0.8155598846713813,-42.4096663932055,32.064810526487655 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark05(-0.815991120745295,-35.54742311571404,12.225956881065871 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark05(-0.8160644292221182,-98.23922578387631,3.9625077137789617 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark05(-0.8167980547816196,-1.5707963267948966,1.9467177638862437E-208 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark05(-0.8172675186054537,-61.225334459776576,3.141592687832883 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark05(-0.8177777888306432,-1.5707963267948866,-100.0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark05(-0.8178760235883407,-0.10767380378998727,29.199607932529677 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark05(-0.818446519077642,-1.0717665383211326,47.94963815807317 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark05(-0.8185276688519214,-9.618836936078402,6.955592528818357 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark05(-0.819257087392808,-15.809243745178808,-3.1415926535897953 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark05(-0.820689097670472,-98.01412064706467,0.0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark05(-0.8211733752883171,-1.5707963267948966,-86.68710920428396 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark05(-0.8221076020812246,-185.79886783239047,9.65407628917949 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark05(-0.8222777969241051,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark05(-0.8231953555864149,-0.5232000560190274,0.01628825120973107 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark05(-0.823424069823467,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark05(-0.8241246388202816,-1.5707963267948966,-12.566602088836548 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark05(-0.8263175891549213,-1.5707963267948912,-742.8611785356317 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark05(-0.8271025674082525,-47.421113300602286,-14.249631900468927 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark05(-0.8274396130748517,-0.6163379836275586,63.63083439090879 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark05(-0.8276503697941822,-117.29984953892551,91.52119895138182 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark05(-0.8278715823573154,-1.5707963267948966,-28.054097959629665 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark05(-0.8278997887467459,-3.1415929261227107,42.90511041208792 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark05(-0.8282596256371733,-72.40466738721246,80.34714586139114 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark05(-0.8295921446725487,-1.5707963267948966,-0.2841080631021987 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark05(-0.830251701692285,4.141592653589806,-58.00621868063398 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark05(-0.8339518527215873,-48.244623048742255,126.21851669059005 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark05(-0.8344352277790367,-17.204193461992542,-83.6179214932772 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark05(-0.8346509708646224,-1.5707963267948957,-6.365063245634389 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark05(-0.8346585640401702,-0.0866355134378051,3.552713678800501E-15 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark05(-0.8350751267585986,-1.5707963267948966,-0.2099847914484706 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark05(-0.8354318321506264,-59.73989363670515,80.05868096118854 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark05(-0.8372122661676096,-34.898416357487655,1.5707963267948966 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark05(-0.8377946956109854,-6.28026531934107E-16,-47.275123530018476 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark05(-0.8379076802662454,-66.28305729625495,-19.493978153585534 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark05(-0.8384826917660546,3.1415929298880894,-1.5707963267948948 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark05(-0.8385256927988749,-92.5747507561832,-135.5036369243716 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark05(-0.8395544586180856,-0.07984422211629061,-81.71957665060174 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark05(-0.8415395206901168,-1.5707963267948966,-57.162700298157596 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark05(-0.8433039436223545,-0.5641136113699645,77.71471649449285 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark05(-0.8437374468836474,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark05(-0.8438004211475593,-72.89712663456004,6.283316684898108 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark05(-0.8445679633258009,-72.59051449280693,-0.319048878155454 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark05(-0.8446449088801806,-1.5707963267948963,-68.80263472249985 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark05(-0.8448253093131655,-1.5707963267948912,78.68033482421478 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark05(-0.8451563719600679,-147.6587083270858,-53.69824289910754 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark05(-0.8451843253913807,-1.5707963267948901,2.220446049250313E-16 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark05(-0.8451904162419235,-85.53596243546602,-1.5707962266614064 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark05(-0.8460774325712298,-41.42246277998973,-0.8733415130565721 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark05(-0.8471280498382784,-0.41189030380331854,-14.555477728249812 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark05(-0.8472281136960313,-1.5707963267948966,75.28966236800552 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark05(-0.8474466762114637,-0.09944154059966792,-48.883252256020675 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark05(-0.8479836216750608,-73.73314623556936,-0.48477438258288885 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark05(0.8486827552044071,-72.48666439476449,380.05295559384126 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark05(-0.8494114939616844,-53.791919283517224,-3.02856635534881E-9 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark05(-0.8505155160981845,-66.31080568581336,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark05(-0.8506841798583673,-1.5707963267948912,-80.84414130351092 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark05(-0.8507970168321021,-0.023823219613436246,-29.391911201778942 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark05(-0.8513383066918973,-97.67846125231324,-1.5707963267949197 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark05(-0.8519127787636096,-79.52359470312376,-98.15748220010276 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark05(-0.8521330134461881,-0.6762211293655718,4.712389044963609 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark05(-0.8524102730043124,-0.8229120292173332,-73.23966946534671 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark05(-0.8538600718957525,-81.37065956684103,37.90453766916383 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark05(-0.8549124389157896,-16.846655526427675,-1.5707963267948966 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark05(-0.8555872708667174,-1.0217255527932068,78.58301853195695 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark05(-0.8557310282010054,-1.5707963267948966,1.5707963271473764 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark05(-0.8559605742571397,-98.01513725355441,-8.175931289639369 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark05(-0.8571158616867408,-1.5707963267948912,24.435316836120347 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark05(-0.8571302418203715,-1.5684831671043618,-1.5707963267948966 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark05(-0.8574773182120055,-0.8571139415572121,-90.93042869969688 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark05(-0.8575764771221974,-9.583131772709315,-1.250482436085003 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark05(-0.8577112388936599,-1.5707963267948966,58.41518948627917 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark05(-0.8580278450243348,-1.5707963267948912,-57.686042441891004 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark05(-0.8587330166617874,-22.28928885123338,64.94637374596493 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark05(-0.8596993167504264,-1.5707963267948966,60.758025640739916 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark05(-0.8601041211170659,-0.44007637484261863,-0.1535682926207503 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark05(-0.8605904897315422,-1.5707963267948983,-44.39450557575016 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark05(-0.8616848704344626,-54.64387425726574,32.52598040366135 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark05(-0.8626609502516609,-569.0280858356932,0.0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark05(-0.8632846704260038,-946.9060276680597,140.94757894234706 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark05(-0.863327252639386,-47.341776683718315,65.78051473020477 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark05(-0.8637879685446638,-1.570796326794893,-70.42452598955197 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark05(-0.8649536071533831,-78.7463079302826,-7.853981802132908 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark05(-0.8666623055506418,-154.76612454327463,-56.54866824149392 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark05(-0.8669688957431916,-0.17381724117253816,0.0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark05(-0.8677894285942472,-22.363561168278295,-62.78242286422333 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark05(-0.8680544680066352,-563.2383819894477,0.2133741363964522 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark05(-0.8680836692449654,-97.85087329674869,100.0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark05(-0.8693939271143449,-16.013044766138123,79.60751106799927 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark05(-0.8701180437123583,-9.44226975449989,-49.85275243369763 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark05(-0.8706177577720757,-48.62261085561714,-20.735277136958885 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark05(-0.8719770252027228,-1.5707963267948983,44.75286456848235 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark05(-0.8720963076583748,-1.5707963267948966,-19.755040072008246 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark05(-0.8740760042254495,-3.1572177467905664,-1.5707963267948966 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark05(-0.8741425812392581,-42.29333352071236,-3.2623326860003067E-9 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark05(-0.8755504739986826,-16.113512128420638,-26.770501858740904 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark05(-0.875974952221866,-3.663408066855509,1.5707963267948983 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark05(-0.8768657017033661,-29.549896121792138,-0.5484701637718246 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark05(-0.8768709607008702,-142.07981002702462,-48.80299786329688 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark05(-0.8773358700798396,-0.3108912368911475,-42.310377799514626 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark05(-0.8779543758343564,-79.86512425678004,-135.15454807798798 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark05(-0.8784304488995465,-1.5707963265577125,-1.5707963267948974 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark05(-0.8787649193999567,-98.30121869694628,-9.003504247052959 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark05(-0.8796373199162959,9.860761315262648E-32,31.357546592401246 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark05(-0.880300759424351,-3.552713678800501E-15,31.14398991334907 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark05(-0.881400381591204,-1.5707963267948966,0.471450854485326 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark05(-0.8814567132282312,-47.34086581729508,-116.64951145275674 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark05(-0.881850273256843,-0.8131898171899081,0.0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark05(-0.8819883417595666,-4.348010923727614,-237.19557248781544 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark05(-0.882182758255367,-1.1276698047610552,-12.852909015024977 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark05(-0.8834321344281093,-0.45943952059059273,-954.7762561155432 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark05(-0.8835328337367585,-40.871954496667314,-31.908323837787044 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark05(-0.8853530396635825,-98.09985886551628,-1.5707963267948948 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark05(-0.8862676207989422,-15.09162417197184,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark05(-0.8883165460143125,-10.772504188779124,-179.17854888303447 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark05(-0.890687843403835,-98.88898533285821,-0.29950494155013996 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark05(-0.890988988036784,-1.314531357247077,48.67657749874476 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark05(-0.8915947326807956,-41.58878677688239,-89.72230004933826 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark05(-0.8919166801159741,-73.13253962084991,-94.96688081486539 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark05(-0.8929849740987608,-1.5707963267948957,4.340843906446123 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark05(-0.894021083249835,-3.42122573468278,-6.284079229559314 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark05(-0.8956657495924376,-22.405883284419883,-14.137290886398041 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark05(-0.8961069986144288,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark05(-0.8968606833810763,-0.45022173725589704,-4.7123889813190445 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark05(-0.8976117903088084,-60.78164651899527,31.415926535897935 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark05(-0.8982874205461148,-1.5707963267948966,0.8879426070072842 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark05(-0.8995545933144251,-3.14171784324934,-10.470019218932158 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark05(-0.8997416233696642,-15.82970086574851,-98.81345912334322 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark05(-0.8998465585061575,-0.14352909621054394,1061.5954577163218 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark05(-0.9010424882272956,-41.85314170864656,-1.5707963267948966 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark05(-0.901394937704593,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark05(-0.9022394821580884,-1.5334135181009536,-1.5707963270719965 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark05(-0.9023139613442337,-72.39252950319315,6.283185787742534 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark05(-0.9026314493153652,-59.93159721262333,-26.97634441806367 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark05(-0.9033979109625563,-40.9581174581583,-36.074206373377876 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark05(-0.903989461754561,-72.47389038418123,-4.712389810664374 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark05(-0.9041097782794286,-0.9727844714435034,96.6696426267155 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark05(-0.904344692469967,-15.76550320411016,38.904892373152165 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark05(-0.9050450202647552,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark05(-0.9062836247394159,-60.70804186098964,-4.827362138075413 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark05(-0.9063939661997115,-4.592702294236316,-28.274333882308156 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark05(-0.9065334173460172,-36.068216818633715,-78.27330072668681 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark05(-0.9068945677769522,-41.489166936283326,-82.56706948045948 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark05(-0.9069439537224789,-66.08991793577533,-20.420352248333963 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark05(-0.9075331096021334,4.141592654879647,-6.536727724618608 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark05(-0.9079494235674623,-15.748493428926452,51.80196709919576 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark05(-0.9088772110900611,-1.570796326588841,34.2196449899327 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark05(-0.9097518567236713,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark05(-0.910033685590074,-9.623226201849862,-16.080482174618233 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark05(-0.910773829791261,-48.607494119251406,38.597791770790494 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark05(-0.9114965103720483,-1.5707963267948948,-82.27905471266902 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark05(-0.911802928971321,-1.5707963267948963,-55.55548674662607 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark05(-0.9119839467456052,-3.141602163673331,42.75021973736895 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark05(-0.9122829888353166,-1.3901284692608573,4.1416189355304756 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark05(-0.912700083152501,-0.4734925767263107,-1.5707963267948966 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark05(-0.9135865969753805,-1.5707963267948966,1.0806454419566534E-224 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark05(-0.9143190273490968,-0.205492325650774,-3.1494051536117644 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark05(-0.9162910242410598,-1.5707963267948966,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark05(-0.9164070463092895,-54.703458141440585,-1.521798020801277 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark05(-0.9175211545662245,-1.5707963267948966,-0.49102057858635606 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark05(-0.9176290588402563,-619.8932105972348,-38.62849037131878 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark05(-0.9187528032366035,-0.22293252290436838,44.032641377618546 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark05(-0.9192908762137368,-1.5707963267948966,23.2471029609259 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark05(-0.9192963033549189,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark05(-0.9194751590020189,-66.63482451964433,-1.5707963267948983 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark05(-0.9195446183895151,-3.476868141585591,-154.4218131868893 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark05(-0.9197434237444495,-1.4713941320834958,-1.570796321076984 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark05(-0.9218848809614016,-1.5707963267948966,43.387628722653716 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark05(-0.9221111212299622,-1.570796326802701,104.60729462728315 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark05(-0.9221788322939233,-167.57995229660332,-2.5149015778712456 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark05(-0.9225191967129085,-98.71653841184586,-19.501041701535186 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark05(-0.923142246296063,-7.105427357601002E-15,17.721575285257146 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark05(-0.9233919149796066,-35.61953761824475,-0.059123358350130564 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark05(-0.9235463823493992,-59.725748149795585,-69.51672633601467 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark05(-0.923765331752012,-122.94033670174052,76.2783178545553 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark05(-0.9238854632904896,-1.5707963267948966,-13.756056747680546 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark05(-0.924844565433034,-15.731618912732557,-26.577772861018516 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark05(-0.9254657421092365,-0.31971988241282656,-2.2323972485981933E-103 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark05(-0.9255149669811819,-15.894958891997362,-1.5707963267948957 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark05(-0.9262985509229547,-1.5707963267948966,-33.94981448086787 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark05(-0.9272703103876115,-1.236682806874975,1.3695485786668735 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark05(-0.9283150066410375,-1.4858141665587639,62.17197292882566 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark05(-0.9286402534965369,-0.7429487046917682,14.375619331481108 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark05(-0.9287718442053315,-1.5707963267948961,28.13766826869795 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark05(-0.929363069684011,-3.141600283316885,88.95263901977069 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark05(-0.9311490281974638,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark05(-0.9315448344999724,-1.5707963267948983,-84.53508790566505 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark05(-0.9317356844933187,-1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark05(-0.9321572083709668,-42.36519476739598,-136.3813882062124 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark05(-0.9322714350965984,-48.20666585579654,12.305994647236888 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark05(-0.9324014742345561,-0.2965648102853794,8.10398163397482 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark05(-0.9325008518786548,-0.04057000125287713,-701.3654537608475 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark05(-0.9326353802439056,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark05(-0.9351331629530768,-0.4683821799907598,1.5707961705000741 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark05(-0.9358193099483015,-212.0574939914173,-0.5736532846138327 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark05(-0.9364429456735799,-72.58653026744531,-54.977871437821385 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark05(0.9370997511515924,6.101177062860955,22.403701408662457 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark05(-0.9384857820885519,-3.1415928920437155,100.0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark05(-0.9386045395965681,-16.954841599758147,-66.49128853161147 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark05(-0.9390659943146821,-10.342628463858517,0.8862566223689163 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark05(-0.939439994562504,-98.16446606619277,14.441205861062526 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark05(-0.9396731523595854,-97.6477331655235,-75.42112663311403 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark05(-0.939703083504428,-1.5707963267948966,1.5706342298462344 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark05(-0.940479990623717,-53.98242669694373,-380.18803809137887 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark05(-0.941624233840136,-72.44052753733146,64.98458695633417 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark05(-0.9425883328798056,-1.5707963267948966,1.3424306608026944 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark05(-0.9436500822480628,-47.24846840719591,-10.317597002664334 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark05(-0.9439774929979461,-1.1917497949578881,12.568323741614485 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark05(-0.9447649990203881,-1.3446561875605607,-1.5707963267948966 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark05(-0.945447573788875,-30.92021869873824,28.115250868407266 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark05(-0.9470749159287624,-1.5707963267948963,51.61589687435914 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark05(-0.9477389401944529,-1.5123446926599944,-61.0312348641552 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark05(-0.9479492482160761,-0.08639916459371665,-4.141628309788804 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark05(-0.9482584989742874,-1.5707963267948966,51.256976709886594 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark05(-0.9500852089857149,-22.349001965153164,21.59367278280644 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark05(-0.9506239584900271,-78.8890073525578,-119.7111682772166 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark05(-0.9507585797190403,-105.0600357256277,146.08408622598643 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark05(-0.9507929562308051,-15.9204797704718,0.0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark05(-0.9508868505772112,-3.141592654066679,1.5707963267948966 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark05(-0.9509489517246563,-1.5618964769274315,-10.767753010191797 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark05(-0.9512539180130446,-35.18744611581846,-81.982096797087 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark05(-0.9514766837510304,-22.718276440904088,-85.22448720107772 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark05(-0.9515077309988181,-100.0,1.5707963267948963 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark05(-0.9531150688936082,14.429212255138005,56.98348397729926 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark05(-0.9531735129992889,-17.232926918559883,-0.25592102927558 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark05(-0.9540943295734987,-85.65707363500671,-3.746609538782934 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark05(-0.9563994973758854,-97.84296604841077,-58.55999304805354 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark05(-0.9571743507038979,-1.5707963267948966,17.052680505403714 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark05(-0.9576311236939963,-7.105427357601002E-15,42.55643135339963 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark05(-0.9583339308103547,-22.391196769429147,-42.8256030765253 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark05(-0.9583393794571379,-97.61374557981894,-1.5707963265876332 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark05(-0.9587875292863544,-168.07160305314187,54.86591115701901 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark05(-0.9601033732838893,-40.98355219959294,-0.08820776309644895 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark05(-0.9603685643764645,-1.118173133831216,-9.30551536105466 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark05(-0.9612339839194155,-1.5707963267948966,53.39763590407131 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark05(-0.961731730211288,-61.0463692957843,-8.103982177235517 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark05(-0.9617366089226409,-0.021937177727857558,-3.1494729530322254 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark05(-0.9622663911061065,-61.208313118516514,-91.72198990358388 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark05(-0.9630090290200606,-60.63047351637134,-23.01986435912028 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark05(-0.9634547449421262,-4.3368086899420177E-19,0.0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark05(-0.9635332673558776,-97.71100501030693,3.798699879158903 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark05(-0.9639611954273658,-54.30624505250605,-175.70727564093033 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark05(-0.9644397756508936,-0.06290936434244065,0.06781616018974826 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark05(-0.9646651001915338,-111.26803920196664,-18.5796818109375 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark05(-0.9648451280687405,-3.5970790375664308,-41.27089419567005 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark05(-0.9667184224169689,-1.5707963267948966,3.1420809348400303 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark05(-0.9674938478618778,-34.85002054677267,107.76400621520614 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark05(-0.9677798055045859,-1.5707963267948966,92.34283900917484 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark05(-0.9681632265038043,-66.25255956096443,57.943794995050254 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark05(-0.9687620120445166,-1.5707963267948966,-5.141592653590041 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark05(-0.9694644531024328,-67.33104283568963,-9.681658751558325 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark05(-0.9701083633094993,-3.266592653593041,1.5707963267949125 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark05(-0.9722735240226292,-1.5707963267948966,83.62219041802693 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark05(-0.9735645964751537,-3.141593236362647,26.784699077263344 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark05(-0.9736128758691032,-1.32112727661503,-18.00665016926738 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark05(-0.9737744176593052,-1.570796313185193,2.220446049250313E-16 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark05(-0.9739899377313179,-66.09313116560791,42.94746835244467 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark05(-0.9740756906799377,-22.34634910193705,44.566319120241644 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark05(-0.9745765680226344,-1.4735274029965237,0.9995450873661206 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark05(-0.9746368223737748,-67.53248272805115,-3.141602187682807 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark05(-0.9746584283704962,-1.5707963267948966,-82.41163023399749 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark05(-0.9751087834082678,-0.030174998308570844,117.81362595570594 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark05(-0.9752774373951993,-0.39537557860304806,23.06053622694158 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark05(-0.9765787217666481,-128.8148155763704,31.288656403511197 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark05(-0.9768031237951349,-0.5139993981545641,37.78437058923549 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark05(-0.9774134539833609,-73.72697253015397,-78.78583419776365 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark05(-0.977969479411886,-1.5707963267948966,66.43076918502985 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark05(-0.9784918990952853,-0.3866324818663427,4.141592704699396 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark05(-0.9787628255706897,-97.86222249048686,6.245034336169958 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark05(-0.9787929672079585,-1.5707963267948983,-26.9077411308551 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark05(-0.9788884702204028,-0.548923884494062,-1.5707963267948966 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark05(-0.980226825490145,-0.1616839800108859,-1.5707963267948966 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark05(-0.9808081482901388,-0.4827656174670988,91.3867851675165 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark05(-0.9813104394402695,-9.512450586638568,-100.0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark05(-0.9833223501124592,-1.5707963267948966,19.55194703657151 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark05(-0.9837095066564193,-1.5707963267948966,-77.37059937439726 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark05(-0.9842533597264653,-0.262912412201473,-21.617359357903027 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark05(-0.9843322485612873,-35.87495061378124,-77.42890983557719 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark05(-0.9843787220139224,-0.34982083222606186,42.579929028746854 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark05(-0.9844783136961146,-3.9145464677513075,84.74640661123016 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark05(-0.9848288954725373,-1.5707963267948966,78.1381694623561 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark05(-0.9848442852636845,-122.72284834346945,-43.261449506361835 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark05(-0.9854122002342021,4.142439098540469,3.1417552025854145 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark05(-0.9857397952066496,-66.32905135098295,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark05(-0.9867549147389685,-66.78750781876138,-34.853023491803036 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark05(-0.987331683746762,-1.570796326793594,53.84475830797679 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark05(-0.9886326441020827,-1.5707963267948948,-38.9466576650332 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark05(-0.9886990810242826,-6.344854593289123E-117,75.82515409000132 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark05(-0.9887426736794337,-0.006738603452008888,1.5707963262221507 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark05(-0.989280414174444,-1.2994181726487244,-123.01872056038707 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark05(-0.9892925302255974,-67.25161758462953,-9.816836260683374 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark05(-0.9893971763037008,-0.23750748202975894,9.42526017799296 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark05(-0.9898449560303998,-1.09141662688981,40.19305455068745 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark05(-0.9899342702223208,-1.5707963267948968,89.6336915138647 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark05(-0.9900005604024356,-92.07010171739698,-16.480050135302555 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark05(-0.9912537836102189,-15.91722508452176,58.057260837367764 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark05(-0.9915225006468233,-1.5707963267948983,90.38029687652616 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark05(-0.9933685230377699,-1.5707963267948966,-17.94635152327062 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark05(-0.9939624581032156,-84.82684437709395,-91.1048022279816 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark05(-0.9940195379895889,-1.5707963267948966,3.173101229644137 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark05(-0.9943379605948408,-160.97896561532764,-169.64634227694725 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark05(-0.9948410945856065,-22.251701668020218,2.016479702151159 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark05(-0.9964122856899422,-22.986668380380465,-98.850462878264 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark05(-0.9971238369009425,-73.34323253950015,-0.8223926361443539 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark05(-0.9981609074773585,-3.454901971575641,-66.52295610598429 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark05(-0.9982959774647199,-0.8758313059519216,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark05(-0.9986326729956654,-3.16544633321688,1.5707953328629713 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark05(-0.9987348536546021,-1.070695768592137,-90.55259611291369 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark05(-1.000050828560568,-1.5707963267948966,25.420795943270925 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark05(-1.0002695657103811E-5,-161.7752594042932,48.694686062606834 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark05(-1.0002831834248256,-28.651596707080696,-1.1754230661199125 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark05(-10.00623609225049,-82.86966591422652,6.084880699609485 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark05(-1.0007744914305823,-160.24426152599509,-151.74146873637886 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark05(-1.0010415475915505E-146,-98.02956003618445,-55.362755485260976 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark05(-1.0010902580823637,-1.5707963267948966,-83.52950904646889 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark05(-1.0012060713296969,-3.8523365591757024,1.570796326810899 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark05(-1.0016525387312132,-78.91688114779325,17.25487353768724 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark05(-1.00467787286631,-0.25971425541627874,84.3544149816149 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark05(-10.048237533886308,30.748026213775205,39.146511841172895 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark05(-1.004879802302142,-35.65522130344518,116.92689634452691 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark05(-1.0055183929445677,-10.981533857242937,-22.65305816360093 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark05(-1.0055780262987988,-15.708024305942274,-28.19096563610725 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark05(-1.0080844493908188,-1.3334806917045272,-3.1416233863187175 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark05(-1.0083211318012126,-1.5707963267948966,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark05(-1.0102506756765255,-72.48900258039546,14.993157060743547 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark05(-1.0102583976038733,-98.62831836132658,-98.9083523940788 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark05(-1.0106570743770442,-0.5269214815901325,83.35068712410182 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark05(-1.0131786930745754,3.2311742677852644E-27,54.24714963228643 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark05(-1.0132774166922875,-3.2665926535950134,-89.7502347054378 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark05(-1.0134312558156857,-9.624177128793056,-45.741306149860876 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark05(-1.0137267568915371,-1.046177472886427,73.93581940083203 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark05(-1.0148819245356444,-1.5707963267948966,1.5707963267936447 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark05(-1.0152042450665766,-16.139908596366613,-29.717905475895748 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark05(-1.0153157391520287,-85.04126107495566,117.10863275582324 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark05(-1.015877115463002,-66.25778333267355,998.4106042997402 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark05(-1.016801762197455,-1.5707963267948966,-50.991406479094636 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark05(-1.017581640573851,-1.5707963267948966,6.406665904585923E-145 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark05(-1.0178471115946404,-10.271013148167508,-32.43959691376541 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark05(-1.018328828635104,-0.8916459846846534,0.0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark05(-1.019405370928368,-60.75471228276186,60.97481039576361 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark05(-1.0198287063497657,-40.97176891543832,-8.30317261216529 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark05(-1.020512800449457,-1.5707963267948966,-1.5707963286843667 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark05(-1.0214342429724912,-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark05(-1.022127727779651,-1.5707963267948966,0.8687438282132385 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark05(-1.0225795185480173,-1.5707963267934846,150.81514627703316 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark05(-1.0225910780376937,-98.42633972257417,49.76120032289354 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark05(-1.0234037522976656,-22.451443873339798,75.8244723662918 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark05(-1.023570091062537,-34.88975714705168,-100.0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark05(-1.0238558386671326,-9.907946441445507,-1.5707963267947695 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark05(-1.0243401299262018,-1.5707963267948912,-38.561636404371846 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark05(-1.0250880641919737,-0.9597323636480679,42.08281781159623 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark05(-1.0251615529479916,-1.5492589548888616,-82.1584398967914 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark05(-1.025959042580846,-1.5707963267948966,-0.9501696157703481 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark05(-1.0259884918308337,-35.16651495970718,-84.82495477826414 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark05(-1.0267546809533599,-35.15321576873947,-45.108764011114054 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark05(10.287071135876474,-65.32581471231651,70.77817831455329 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark05(-1.0290910738527472,-15.707963267949992,-22.012457330717666 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark05(-1.0291345117906834,-10.865270106952384,-3.1420820542022105 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark05(-1.0298326589282334,-15.74631838008425,-47.66022542519644 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark05(-1.030382279256072,-9.674777961040492,-42.118063547885576 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark05(-1.0309110059361668,-1.5707963267948308,20.900127866794257 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark05(-1.0309820167099044,-9.99058698635428,-71.93894864298491 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark05(-1.0310848903052974,-48.641236160148814,26.95753071996799 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark05(-1.0319146161170683,-73.17160066781227,53.766877451985266 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark05(-1.032070784154797,-42.16820591619603,-59.26316774386661 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark05(-1.0321107462233847,-66.79248847832653,100.0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark05(-1.032335054594216,-1.0664650402362383,1.5707963267948966 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark05(-1.0323650696412296,-1.5707963267948961,-0.40539384352186536 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark05(-1.0324684007090923,-35.02278639987494,1.5707963267948966 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark05(-1.032848492726203,-1.5707963267948966,-46.747666090733794 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark05(-1.0331022233732823,-1.5707963267948966,-95.82987928729196 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark05(-1.0334469378784168,-54.645403177495425,43.982785455905116 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark05(-1.0338197996998517,-1.5707963267948966,-83.252441746402 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark05(10.34160695866386,36.86249033810435,19.844582716117557 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark05(-1.0346255955311463,-3.141618625300384,-100.0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark05(-1.03526595072548,-85.01543871212161,34.59926970013797 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark05(-1.0357332269202932,-67.48954079269728,-48.77590859980435 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark05(-1.0364909549304477,-47.51615281407023,-1.5707963267948966 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark05(-1.0368556486443985,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark05(-1.03693044955439,-0.6187089063527671,-94.66293619917371 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark05(-1.0370410128218925,-1.5707963264916782,0.0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark05(-1.0374192621063887,-23.365395032917103,-2.6469779601696886E-23 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark05(-1.0387813100410597,-54.743280450903264,-25.07453436131243 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark05(-1.0393316612343355,-66.46510837617336,-73.89432580029064 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark05(-1.039587116960253,-41.63152730553998,1.5707963267948948 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark05(-1.0402596875552472,-15.975813969008263,6.2831853378812195 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark05(-1.0405334102399681,-0.019993232348491083,-1.5707963267948968 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark05(-1.040597346383289,-10.878186218304293,-223.0629473291374 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark05(-1.0406237079649487E-258,-3.8528276414848888,0.0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark05(-1.040993244302935,-1.4257404285574773,-79.55789512726139 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark05(-1.0410952592220337,-9.919694465573372,-50.139059261334054 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark05(-1.0418563588967515,-0.22779542884082682,78.94919710759935 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark05(-1.0427090381695479,-1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark05(-1.0453184950245527,-86.24404004124764,-0.3993415045072215 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark05(-1.0453882071888587,-1.5707963267948966,-32.033482348343206 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark05(-1.0459743202083138,-66.50290195595025,-1.5707973090168013 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark05(-1.0461741744532964,-0.23306882463770365,-5.141592657165091 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark05(-1.0468298564268988E-19,-1.5707963267948966,-86.40161072069792 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark05(-1.0469193948453617,-34.74723300102809,-0.2507601873904469 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark05(-1.047303572431766,-3.751182206985092,20.794196623702295 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark05(-1.0476408963439938,-1.4797161080368126E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark05(-1.0479502124161302,-42.08831390124219,-535.6403484606398 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark05(-1.0479722192234855,-9.016580681431383E-131,-13.8035777347615 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark05(-1.0480315982943393,-66.41998916787293,-0.24218582829267432 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark05(-1.0482205466031285,-34.660974648363776,33.10280948585176 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark05(10.489067845795816,65.57886518530933,23.895108742475443 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark05(-1.0493799498505043,-16.156185193824466,8.673617379884035E-19 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark05(-1.0502758421294667,-0.01538307575289783,-76.90598778095885 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark05(-1.0530379550369662,-42.13262511370352,1.5707963267948963 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark05(-1.0530885266624086,-1.5369013865849837,-31.08619995090025 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark05(-1.0536903927494077,-36.050694598422474,3.1420814587159347 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark05(-1.0538255034969706,-1.5707963267948963,-45.78081490505347 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark05(-1.0539941378966198,-78.67209851080004,93.23553086037899 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark05(-1.0541343256360207,-1.5707963267948966,75.20822439531189 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark05(-1.0541898460857124,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark05(-1.0542443227594789,3.149405157786654,26.708285508322437 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark05(-1.0553178144107943E-227,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark05(-1.0570121824567718,-224.61469114995816,-0.7019791859929363 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark05(-1.057147186486384,-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark05(-1.0575223752269094,-1.7763568394002505E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark05(-1.0576618640006057,-1.5707963267948966,61.484258278539144 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark05(-1.058893002521071,-42.307181428168384,0.09187642673829283 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark05(-1.0590920933024588,-1.5707963267948966,-72.44526417334548 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark05(-1.0604874968432494,-66.05010977697498,21.574972019109975 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark05(-1.0607416874375644,-54.49124982098107,98.33961646059177 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark05(-1.061655552629503,-1.3455045305899205,-9.915268311475476 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark05(-1.062780352691675,-98.78430379298231,-42.06883216237964 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark05(-1.0629197476641805,-0.5138387250387703,61.53719470388812 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark05(-1.06395319859302,-1.5707963267948983,-87.96459430155093 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark05(-1.0640732968785933,-1.5707963267948966,-1.5707963267948912 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark05(-1.0645869668095278,-66.51319622816149,-43.346785593076184 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark05(-1.0646174556550794,-38.013389058176884,26.84875459947913 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark05(-1.0649941679447126,-54.89437004344153,35.530441032319345 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark05(-1.0654679148841437,-1.5707963267948966,-89.73764839078899 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark05(-1.0657166509565883,-0.7203545839663531,-94.49349770723134 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark05(-1.0658362695077988,-85.03738116096382,40.0452353379697 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark05(-1.0678822011349633,-3.9319886869975136,4.712490416555185 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark05(-1.0682759935978318E-14,-1.5707963267948966,-16.059409814191227 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark05(-10.695750584934089,0,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark05(-1.0708025826353111,-4.130896416386648,1.5707963268056029 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark05(-1.071152244988781,-0.10378059161653486,-1.1955360399186143 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark05(-1.0719146200302934,-72.54243384324637,-9.539895492536779 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark05(-1.0723249237105652,-1.5707963266546618,-155.09089558826963 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark05(-1.0730888965301083E-8,-1.5707963267948966,208.92677711038402 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark05(-1.0731922468566637,-0.5932450578716302,0.0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark05(-1.07390020847973,-5.739718509874451E-42,-31.105625560889226 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark05(-1.0747947686596875,-35.052423766902756,82.64506039413521 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark05(-1.0783282965604428,-86.16826656318759,-92.10514054458034 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark05(-1.0784864795530407,-0.028505829999833754,-53.536334768257916 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark05(-1.0788426794764143,-1.3560472520990534,-22.022399090917865 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark05(-1.0790427687929802,-3.149405153678018,-1.5707963267948966 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark05(-1.0794266108857187,-3.469446951953614E-18,-41.2591692618211 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark05(-1.0795350438786668,-0.22723851928396321,-50.11354136409674 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark05(-1.0795858396379396,-167.16262590967972,90.35028138358888 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark05(-1.0797400451888075,14.431621635500441,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark05(-1.0802064320274063,-61.228404139355696,-50.25986696380236 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark05(-1.0806454419566534E-224,-0.10864933255205195,-0.08941533548507133 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark05(-1.080814238175216,-66.51488663302871,-12.250065803195305 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark05(-1.081812809463727,-1.5707963265394727,-1.3646562398689428 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark05(-1.0824576149459464,-1.5707963267948966,-56.13074182480468 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark05(-1.0825267301301387,-1.5707963267948963,-14.538687862453031 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark05(-1.082531088632611,-0.04504441908974775,3.3299958654878358E-257 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark05(-1.0834775287238283,6.429479283507775,13.433288555765326 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark05(-1.0842021724855044E-19,-1.5707963267948966,-94.28149340724562 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark05(1.0842021724855044E-19,-23.306978199725148,-1.5707963267948966 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark05(-1.08429174572737,-60.715050062277534,-60.8519904571842 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark05(-1.085763512834538,-0.43458018685529076,1.2157247565182212 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark05(-1.0859678706896991,-1.3573271214416724,37.32932987142395 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark05(-1.0867296223941572,-3.746836351447184,36.88072839926266 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark05(-1.086754038341856,-141.75185413413539,63.495772932584295 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark05(-1.0869639129249151,-9.49318890469766,46.89242593284244 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark05(-1.088054390229635,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark05(-1.0886553932967267,-1.7322776533843266E-8,89.47487672782378 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark05(-1.0887945741746137,-1.3317508446864466,-17.86483598415984 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark05(-1.0893356202882472,-0.6528619959336495,-35.46931453332263 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark05(-1.0905359467440405,-59.897170913992134,-136.32625113610138 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark05(-1.0908071023623194,-10.434308883400732,-1.5707963267948966 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark05(-1.0909231744295529,-0.3509298252336484,-8.103982785014894 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark05(-1.0911850285443307,-41.75496683263924,10.117332289602347 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark05(-1.0911892370492637,-1.5657438845168945,0.46916713741073757 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark05(-1.0918369252037756,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark05(-1.0928026399756408,-1.5707963267948966,79.76546475098009 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark05(-1.0954306637346929,-60.935501068034526,67.6574674548751 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark05(-1.0958434211102404,-66.40651211453464,-18.090571301431595 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark05(-1.0963013299782718,-29.57050410488921,-60.94552960772529 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark05(-1.0963181001467996,-0.6362558726064554,9.52921187996364 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark05(-1.0966150387996432,-98.05914767702038,-49.03320878218944 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark05(-1.096617579862249,-40.99917704841899,-13.43967703941027 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark05(-1.096847734436887,-0.5113575550782495,0.0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark05(-1.0970419747643552,-10.148016862992819,70.68470652535308 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark05(-1.0971072294963409,-0.9635452786239399,-72.44208460396783 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark05(-1.0974345636657197,-0.02153091324919787,-28.86619347919364 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark05(-1.0979008666293855,-0.3451465428113853,0.22062836477273612 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark05(-1.0984535569272913,-98.74675264394907,-85.8683626555661 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark05(-1.0986189196639562,-72.39241695010864,1.5707963267948966 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark05(-1.0992083669667356,-47.83589311589372,-0.7181264024408961 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark05(-1.0997053750290076,-1.5707963267948966,-14.835597701483877 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark05(-1.0997149491532667,-78.91308004389796,0.0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark05(10.999305502522276,86.74596532982198,11.010465380629043 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark05(-1.1002760397069122,-1.5707963267948966,7.634016066691345 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark05(-1.1015182488111195,-0.6649654108829449,44.358612423157254 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark05(-1.1016339901979089,-67.38767336400983,-155.03815255190827 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark05(-1.102066883580057,-0.43750937142750324,-19.80293020516384 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark05(-1.1021873870887884,-1.5707963267948957,18.88865526268976 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark05(-1.1024435985522494,-1.5707963267948966,12.9004587161714 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark05(-1.102651862767802,-41.39742318764694,8.35441976095315 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark05(-1.1040364250827543E-4,-1.2508119088896126,-65.42811401283491 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark05(-1.1046508643785344,-594.5800278376165,-40.15728978937594 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark05(-1.1052689692834523,-0.029545067367280554,-95.54788938236737 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark05(-1.1054800961778086,-0.1188971584201184,-6.283271897824461 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark05(-1.1071735135187333,-78.55947494556806,-1.5707963267948966 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark05(-1.1077557803762381,-1.5707963267948966,-64.6693181673862 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark05(-1.1080231408028967,-1.5677797549217887,28.601493726264223 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark05(-1.10893271114184,-59.97583786820613,-98.10239355300524 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark05(-1.1091793555979639,-1.5707963267948966,21.67402405113667 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark05(-1.109597850837023,-23.311126208071997,-85.87754163397564 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark05(-1.1099669663849448E-16,-2.1106356288215886E-227,0.0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark05(-1.109989606720462,-10.611430812584317,-72.73390241810675 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.43443708897262245,0.0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.632373008647136,96.59576646211428 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-0.9794532110445262,-22.420767098473807 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707962490218146,43.98226086017888 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948912,1.0447008999469887 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,1.2799816943865459 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,1.5258609046028215 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-25.435786349639887 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-32.648729585996556 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,54.07642332161555 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-70.87138737881993 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,78.23458366166824 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-2.7755575615628914E-17,-15.996432583849767 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-35.09745820422117,-1.3292514297516929 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-3.7155986349341283,-78.27319384649422 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-41.72666217209762,-0.16883765562009706 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-54.581645916123364,-1.2629792799061677 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-60.86210671165253,0.0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-7.105427357601002E-15,18.983323302026704 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-7.596454196607839E-65,-100.0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-92.64047807275705,-55.319578829002104 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-98.77322886076922,89.58244582200602 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark05(-11.105614712022543,-75.20592886801107,-45.30764214374319 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark05(-1.1113742656008814,-154.69545733963608,90.01376222772191 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark05(-1.1122183108090464,-35.30789279128872,22.924040150211678 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark05(-1.1123975782297513,-36.110177061394104,-20.87792790351442 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark05(1.1129950804221238,-34.28358146341472,-4.989947659302089 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark05(-1.1140852265970065,-1.5707963267948966,5.079386134690675E-4 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark05(-1.1142176775256831,-9.425835151040879,4.712388980384778 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark05(-1.115205817106986,-1.5707963267948966,61.13121877653381 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark05(-1.1160630384962977,-98.42351940156166,-19.88594471598651 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark05(11.161905437442357,1.4421055667814784,-10.081194735696442 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark05(-1.1170373554484532,-141.79122234432305,79.53580688549417 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark05(-1.1173999283518605,-3.1417510382889158,0.0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark05(-1.1177869211592117,-85.02775586406618,-83.41876789746047 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark05(-1.1187631110010878,-1.5707963267986582,7.90690562802779 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark05(-1.1192285739505055,-22.308973310478194,-3.49745759932466 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark05(-1.1197915652920287,-41.14233644944709,-601.6134317330034 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark05(-1.1202554331114465,-4.051031324082402,1.5707963267948966 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark05(-1.1205522478282472,-98.47519783476041,-22.334768567691242 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark05(-1.120778030581489,-0.17588351212189102,12.568451658466433 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark05(-1.1215187975675218,-100.0,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark05(-1.1222920749570966,-79.81705080343261,-122.93709373422529 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark05(-1.1227796804664028,-86.15982202154922,-65.2617019111566 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark05(-1.1228076353957919,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark05(-1.1231852798994717,-54.88875993713649,1.5707963267948968 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark05(-1.1238769856452766,3.1494051607538203,-42.08012264724048 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark05(-1.1240763413806603,-15.880714360779434,0.6467074886250705 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark05(-1.1246636828657832,-0.4241832462487576,-7.853981633974518 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark05(-1.1274605117262653,-15.768854695438307,14.018679359475811 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark05(-1.127995632609644,-16.65368182796282,-66.40084671682861 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark05(-1.1287965682622636,-1.5707963267948968,1.5707963267948966 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark05(-1.13051792847614,-0.320009196917751,1.5707963267948966 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark05(-1.1305211630429994,-46.82055946221271,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark05(-1.1305307092934547,-122.64908430152938,-87.13003196560436 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark05(-1.1309619029197955,3.469446951953614E-18,54.09870417797316 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark05(-1.1315996571836826,-3.266592653611743,-48.5827708189357 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark05(-1.1316813396033254,-1.5707963267948966,47.285396322702866 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark05(-1.1326626222472207,-0.5171877270258628,272.9108618948135 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark05(-1.1328060204636876,-1.570796326794889,78.35048936538824 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark05(-1.1342105044375217,-3.822097382263945,100.0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark05(-1.1344784239134764,-72.79630005269262,-111.20703698503924 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark05(-1.1351783574503704,-1.5707963267948948,-27.272207811589446 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark05(-1.135392736310006,-1.190726301910023,-107.92561527275787 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark05(-1.1354396371479196,-6.77034318537495E-4,-4.712388987243963 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark05(-1.1373475930125514,-594.6178390724057,0.4733444907403615 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark05(-1.1374223619735813,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark05(-1.1376238746573553,-1.5707963267947465,-1.5707963267948968 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark05(-1.137974576915982,-48.36636356135989,-1.1360721496075428 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark05(-1.1380524797363597E-159,-0.8534218343850359,69.49104609126829 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark05(-1.1399052619795333,14.484247946209969,-1.5216099345845382 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark05(-1.14130727849955,-34.83956151532457,12.597621059425627 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark05(-1.1413801989200367,-0.4562587604894546,20.796518803610756 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark05(-1.1422195075271904,-9.655677939871401,-4.712394516489572 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark05(-1.1427949690382182,-1.5707963267948966,-42.645132421362476 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark05(-1.1451634925414704,-35.08649146179941,1.5707963267948966 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark05(-1.147155646379244,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark05(-1.1484395070181486,-1.5707963267948966,25.65817233421857 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark05(-1.1496406873080285,-72.44583760940627,534.4862780143819 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark05(-1.1501203413619048,-66.30839435775991,-31.488486821050195 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark05(-1.150800830917275,-4.31234123788812,-238.63396910281048 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark05(-1.151136544937523,-4.300252778852986,-1.109808005522351 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark05(-1.1518067982578701,-104.46791172613996,61.343362400069026 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark05(-1.1530727154720178E-5,-1.5655034899978522,26.703415034806756 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark05(-1.1531611604324528,-85.02575317750086,0.3780243973429454 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark05(-1.1535621162892722,-0.6604141711481293,54.38119177844955 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark05(-1.1535646079743755,-1.5707963267948983,-46.666830544465874 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark05(-1.1539043073119912,-714.6807876302959,-4.277382861792049 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark05(-1.1540264904126285,-1.5707963267948966,22.74920779801311 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark05(-1.1542238804186586,-4.5719495651291E-100,10.123652641906705 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark05(-1.154347438622661,-22.439894449082004,-0.10521476580107227 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark05(-1.1546783741877178,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark05(-1.1557951146174883,-1.5707963267948966,27.234470979681745 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark05(-1.1558147241232752,-1.5707963267948966,-64.66081008675926 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark05(-11.558189801186685,-5.933016869782321,23.561381325556212 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark05(-1.156400816668751,-0.2961652020639892,-1.5707963267948966 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark05(1.1564482601329489,52.77120377688435,-19.922114004317805 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark05(-1.1576602620184744,-72.40762873625317,-1.5707963267948983 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark05(-1.1577938276901665,-42.259829833490244,1.5707963267948966 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark05(-1.158683219374891,-1.5707963267948966,-57.41113321143938 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark05(-1.1589944490266149,-255.57511140163788,-54.05541047364238 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark05(-1.1606296547248188E-14,-0.5872195762934533,0.0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark05(-1.1608843701196188,-1.5402570877076969,79.27041386459516 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark05(-1.1611787084169565,-42.07112904698405,117.91826857876109 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark05(-1.1613681820255755,-0.1476839706545816,1.5691721931041143 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark05(1.1619730314669001E-17,-1.5707963267948966,-13.87517355221435 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark05(-1.1620699035056106,-8.881784197001252E-16,-77.586259576912 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark05(-1.1626577924381394,-35.05250548096144,-17.989194851102326 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark05(-1.1631259386019084,-1.5707963267948966,6.776263578034403E-21 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark05(-1.1638416933870042,-97.41047318941472,-44.48990599432858 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark05(-1.1640259473836203,4.141592653894217,31.585715426942226 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark05(-1.1645951141840696,-60.829177378212506,-77.00332964431226 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark05(-1.165097454184132,-0.2391009410424932,0.0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark05(-1.1659840046491983,-98.13732492627148,88.97941852473113 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark05(-1.1665173461080827,-1.5707963267948966,-1.189045336214289 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark05(-1.1670923427463311,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark05(-1.1679966241900694,-1.178984572693679,-20.035949808524293 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark05(-1.1684258186763265E-16,-1.5707963267948966,-89.53539062730911 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark05(-1.1685426907249314,-128.81598492067715,6.734855279125071 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark05(-1.1687354132025982E-4,-47.464983890119015,83.90551772914745 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark05(-1.1694168672119243,-1.2550846979798673,42.868884875542705 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark05(-1.1698442207809845,28.703538110676714,-77.20623415993131 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark05(-1.170079312414779,-0.5241582606705386,10.439382111819043 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark05(1.170804388335413,-1.567473875147419,-1.5707963267948963 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark05(-1.1708833062393376,-3.149580116492877,-1.5707963267948966 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark05(-1.1728961398376994,-1.5707963267948912,-86.33248074289035 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark05(-1.1741921347141162,-1.5707963267948966,63.76088243842773 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark05(-1.1747879812359583,-1.5707963267948966,-12.692030843869212 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark05(-1.1759891656829713,-0.5276563253612725,-88.05094197457366 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark05(-1.1761757370413942E-13,-1.5707963267948966,-82.04500599748866 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark05(-1.1766077851913648,-1.5707963267948966,0.28843566671975696 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark05(-1.1770809128775999,-1.2014757903201023,-7.8539816340178 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark05(-1.1771908904822426,-1.7763568394002505E-15,-41.92342285241281 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark05(-1.1777726029192435,-1.5707963267948966,-0.07189622565971376 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark05(-1.1778015734723062,-1.5707963267948966,-25.37704540228183 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark05(-1.1778829154175745,-1.5707963267948966,21.058879037189616 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark05(-1.1783229268018705,-1.5707963267948966,93.12296689855171 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark05(-1.1786685060711266,-1.3621179178162028E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark05(-1.1806284969459722,-1.5707963267948966,3.2345637927969135 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark05(-1.181422540286794,-54.66764767028802,71.21780890418816 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark05(-1.1814537052286893,-40.87976076128067,20.735840746875265 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark05(-1.18186599799286,-0.15127185284560912,50.111128965632524 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark05(-1.182114984063268,-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark05(-1.1822881692693539,-22.396535106932944,69.05800925076585 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark05(-1.1825844112461514,-66.17004892195368,-118.17342335245533 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark05(-1.183344231624279,4.141592653589795,94.76719480786043 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark05(-1.1848717143593117,-6.6174449004242214E-24,1.5707963267948966 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark05(-1.1856574268533453,-3.8092859035571363,28.703541060743376 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark05(-1.1859508501218663,-122.7880645393641,95.58476644349932 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark05(-1.1860754221349055,-47.53285928139574,-0.1527145444310709 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark05(-1.1866761342644182E-4,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark05(-1.1880032644812735,-1.5707963267948966,-44.22292472008989 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark05(-1.1883721674709014,-3.1435457785897936,-12.802041205395838 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark05(-1.188694993738668,-1.5707963267948966,-12.566370614269946 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark05(-1.1887717476747157,-59.69029097673904,95.58228166346908 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark05(-1.1902500652754246E-14,-1.5707963267948966,-51.43665459846077 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark05(-1.1904832458759929,-0.21851857110301448,-26.183629593190396 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark05(-1.1917949750434254,-122.84390690272843,72.56429428540918 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark05(-1.1918159529025585,-1.3595266177898608,0.0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark05(-1.1919016388627666,-1.569828751277225,0.0018497068444950308 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark05(-1.1920210084245131E-17,-1.5707963267948966,-6.283186247898575 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark05(-1.1952864838920156,-47.579761002775776,63.68187610080733 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark05(-1.1972226195912523,-1.5707963267948912,12.573102805808201 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark05(-1.1973434121116902,-9.970977839241897,-1.5707963267948983 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark05(-1.198160110462407,-1.5707963267948983,48.43199607644593 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark05(-1.1989199164245405,-35.37743715558136,-76.179594990543 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark05(-1.199130099966288,-0.805384685159941,-90.83840047816123 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark05(-1.1999202691859097,-1.5707963267948966,43.186668731337605 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark05(-1.2001652889100776,-0.4187197797737964,89.41569906089292 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark05(-1.2005791039714169,-66.96125336373086,-116.13681170344455 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark05(-1.2011717882863595,-801.6246139239228,16.15440232104266 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark05(-1.2013062976424902,-54.19433691129271,-47.97146248418282 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark05(-1.2039925619607175,-1.5707963267948983,41.25958791695169 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark05(-1.204001097932487,-9.657965000998194,1.5707963267948966 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark05(-1.2049437204968099,-4.709329851876447,-22.3763928289287 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark05(-12.053818304128157,-8.949561158420323,-90.9456651702738 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark05(-1.208564956173961,-1.546762457141757,-23.263175440171544 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark05(-1.209634520242195,-0.00782464487821887,-70.57721426387471 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark05(-1.211112699019059,-135.4752873025995,-60.116424073251615 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark05(-1.2116292428019904,-3.6227961019084447E-13,169.4020865824968 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark05(-1.2142162382913262,28.703537555513243,-57.747551363998376 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark05(-1.214244308788013E-16,15.70797207244608,-70.4891322446034 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark05(-1.2143619887570765,-72.44768079193145,50.59031536336454 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark05(-1.215406526610053,-0.05085282150107884,-32.92306680594258 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark05(-1.215537122961347,-4.012305882034816,-1.5707963267948983 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark05(-1.215781791879948,-1.5707963267948983,82.88013852531896 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark05(1.216320727465155,-1.5707963267948966,0.689922317830693 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark05(-1.2166754857185782,-1.298457073381706,1.5707963267948966 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark05(-1.2170050497019211,-0.32227458026979106,62.363617807624095 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark05(-1.2176004236842075,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark05(-1.2178977255551484,14.431319754470636,1.5707963267948966 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark05(-1.2185590722535196,-122.98162829018312,-15.297612298228103 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark05(-1.2188607470441928,-3.1416007541842093,0.012216020998628507 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark05(-1.2193966144553343,-0.455845738755025,-12.885860289518748 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark05(-1.2194491431838421,2.710505431213761E-20,0.0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark05(-1.2194944050316678,-1.5707963267948966,-77.92186059411725 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark05(-1.2196027299848426,3.1420809420905425,0.0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark05(-1.21971795153631,-0.5706316563065058,18.88827054642618 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark05(-1.2209593602293851,-47.15233331005341,-83.05797667827875 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark05(-1.221216952345923,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark05(-1.221869066709959,-10.579716864996083,-22.744495851668688 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark05(-1.2223291566850656,-25.313021575755414,-26.217452866490873 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark05(-1.2232733785078909,4.141605473620415,70.3384464764281 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark05(-1.2238612570057403,-16.166653818297874,-91.43358441520323 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark05(-1.2249751019246495,-1.2248174525350568,-6.2843997042264474 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark05(-1.2255662865043413,-10.414479565175824,1.5707963267948983 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark05(-1.2261264028894494,-1.4050170196856384,44.77487412831352 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark05(-1.22640583432129,-1.5707963267948966,86.49090846660937 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark05(-1.2265317616676867,-54.90024264776095,-83.0161740086206 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark05(-1.2268510448575696,-1.233490493668243,-95.37971120927834 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark05(-1.2269289022855938,-97.38937226128365,0.0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark05(-1.227369013968379,-0.7679832455974349,91.10297265724839 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark05(-1.228086472774419,-0.03727344844671009,97.2030532055296 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark05(-1.2291125697784775,-1.1821397006032015,34.4837381273844 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark05(-1.2297203403940873,-41.922381195440316,-1.231417453409009 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark05(-1.2301103364794634,-0.44437325803114913,-772.7998571254521 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark05(-1.2304703156255834,-0.8779198684274971,77.12019141328825 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark05(-1.2323443318876002,-28.322439138006956,-3.1435550663126013 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark05(-1.2327075467534718,-66.55945855141559,-197.34169538966492 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark05(-1.232826827970521,3.1729215105231243,1.1812237417540916 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark05(-1.2329522422728971,-0.057893398456569156,42.971202234125684 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark05(-1.2348335789120406,-0.15632263416508746,-1.5707963267948966 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark05(-1.235556218788738,4.141770903042819,-1.5708402940311643 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark05(-1.2356259306912762,-1.0794315536431571,-6.298810552809154 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark05(-1.23576898628535,-66.40371893548314,-98.73124475879845 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark05(-1.2383065336110581,-1.5707963267948966,82.35381082871339 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark05(-1.2385807699511608,-47.44115659602694,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark05(-1.2390733939238885,-97.82229521852673,77.28984315320159 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark05(-1.239751778568079,-0.011091283016366305,9.273015376718553E-69 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark05(-1.2401775797878907,-72.8953396033339,0.0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark05(-1.2405184378534135,-66.3638293077144,78.31598956660696 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark05(-1.240960030682909E-10,-1.5707963267948966,-69.14693599041814 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark05(-1.2415722554365587,-1.5707963267948912,-13.54253026126517 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark05(-1.241700764495008,-161.34638005585307,-8.103989333068759 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark05(-1.2423654462699385,-35.27670148951903,-22.66080698091433 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark05(-1.242927906019912,-1.5707963267948963,100.0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark05(-1.2429714019863083,-1.5707963267948966,1.5707963267948906 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark05(-1.2435527150575914,-1.2245258072070775,1.5707963267948972 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark05(-1.2437115760081254,-1.5707963267948912,-54.73134064907106 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark05(-1.2444206415718089,-0.3764056723568455,-1.1853613395727294 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark05(-1.245334549731227,-1.5707963267948966,0.5392915794044613 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark05(-1.245899368887196E-206,-17.205502553264118,-79.98043255315037 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark05(-1.2460605397515683,-0.2357493069016422,-4.712389801560988 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark05(-1.2462249316268117,-104.31644075791436,63.04237087942245 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark05(-1.246810426210129,4.141596383839007,1.5707963267949054 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark05(-1.247222117503934,6.4304022593682655,54.63221725584904 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark05(12.479360092783025,41.30325138678339,-9.903809493434764 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark05(-1.24906191199129,-28.368047042910224,42.645519341677186 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark05(-1.2495572414408458,-1.3044265470833853,55.01615064274661 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark05(-1.2498736178344705,-22.354666127040062,-100.0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark05(-1.250270485168818,-54.56776536735413,49.96749150436571 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark05(-1.2516587815145555,-1.3877787807814457E-17,-8.34434460242727 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark05(-1.252194179734926,-0.14395269048115378,-62.09783496414249 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark05(-1.252387731507918,-1.448525167425935,-81.19780006751861 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark05(-1.252681174870283,-47.70587272400854,-1.5707963267948961 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark05(-1.2529038738484246,-130.00886040388855,-130.02969136711175 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark05(-1.253149585956016,-1.5707963267948966,-74.30982482258716 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark05(-1.2533599111268643,-1.5707963267948966,-18.991049880809946 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark05(-1.253453160500238,-1.5707963267948966,-19.77322178116473 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark05(-1.2552639517708393,-97.97340161671401,-5.464950283026781 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark05(-1.255355916649411,-54.51621380355287,-8.107403929814524 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark05(-1.255434049037465,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark05(-1.2555807971959538,-1.5707963267948966,-81.54336605603316 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark05(-1.256695795855668,-47.562642838899194,0.3541036408647065 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark05(-1.2582319679690928,-1.570793766238604,112.9403857494669 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark05(-1.2583712608473815E-15,-129.16694447399357,-93.99902493935556 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark05(-1.2585938154773093,-98.3212982654599,16.020858145927384 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark05(-1.2589331285793475,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark05(-1.260009012669715,-1.3451592538854638,1.5707965231201002 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark05(-1.2600789748673717,-35.96682318706154,126.45369078817353 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark05(-1.2604088276954537,-1.5707963267941984,1.5707963267948966 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark05(-1.2604171602246366,-0.7729229464696696,1.5707963267948983 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark05(-1.2610343626933525,-1.5707963267948963,1.5707963267944232 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark05(-1.2612162943994094,-24.355004213387417,-10.778573610479114 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark05(-1.2616939507580873,-1.5707963267948963,2253.9998480209465 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark05(-1.2623512110354151,-41.02758552761156,-52.425121577530035 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark05(-1.2633047192173767,-34.96920626005059,-17.279080547336473 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark05(-1.2637705062246984,-0.8356663148503878,-34.11474787967073 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark05(-1.2638082631897105,-3.141600458218153,12.759500813873245 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark05(-1.2643923750432446,-1.5707963267948966,39.64750081314179 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark05(-1.2648770829049976,-1.5707963267948966,-7.524269830416704 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark05(-1.2655542623131628,-66.22343197720738,-0.13182340438161452 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark05(-1.2664722508032895,-97.69485903945409,-4.401691794936397 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark05(-1.2670709681202226,-1.4026471517189119,1.230409545375035E-17 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark05(-1.2673011882056784,-117.7459477016496,-21.122699782548793 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark05(-1.2674296401772849,-0.9287322630345503,-54.5692052474902 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark05(-1.2677086308775047,-1.5707963267948966,65.62465794724031 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark05(-1.2678642569924816,-65.9949768895001,795.5933781956174 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark05(-1.2690816317627125,-3.5935991119618222,-0.45715922981538837 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark05(-1.2698237323056771,-1.5707963267948308,13.906528324720128 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark05(-1.271618754173266,-79.01621601455139,98.34971578213174 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark05(-1.2722216562743371,-35.61102557345925,6.43190497221723 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark05(-1.2727747763487378,-1.5707963267948024,-100.0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark05(-1.272790365599581,-9.897162007815234,-16.86925599358537 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark05(-12.741572043127448,25.622625221025046,-18.19727239936553 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark05(-1.2748305572085372,-1.5707963267948948,504.9163676632263 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark05(-1.2773547865460273,-0.3155553171051393,27.790472898636793 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark05(-1.2776043126562655,-249.56316686355197,-122.79815305513279 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark05(-1.2779817296007394,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark05(-1.2779841385387076,-1.5707963267948983,62.53570476241565 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark05(-1.2784098665959096,-47.270430833717406,144.8040477119573 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark05(-1.2785440704341604,-66.46076014456435,-1.305237207097141 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark05(-1.2791014024666016,-16.121765573804034,56.383567849464114 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark05(-1.2791384660767777,-0.06965627076758338,-613.3760028536368 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark05(-1.2791588814857553,-78.69951800959889,56.01484694225966 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark05(-1.2799814997509316,-66.46325578615662,37.010532806900585 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark05(-1.280100409396897,-35.560791902048884,-77.0262438894618 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark05(-1.2804818326171334,-1.5707963267948966,-92.84150381810515 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark05(-1.2807140973963231,-35.63685566999489,-75.34813048259218 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark05(-1.2809807529040598,-15.893795126731312,4.712388982995497 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark05(-1.281598958638046,-98.33814898093841,45.90117657834959 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark05(-1.2820814973483827,-1.5707963267948968,0.0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark05(-1.2833763774113374,-47.35677966325283,73.39779511408744 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark05(-1.2836223380429903,-3.2010655353703816,-16.84544927214087 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark05(-1.284181745526113,-3.1441534738279424,-1.3426252250662347 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark05(-1.2847023335773688,-35.81949028537311,-95.14566175314323 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark05(-1.2847331865714084,-66.38006056943843,-0.04436651989845303 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark05(-1.285652394376549,-3.1435600319525907,-189.57330956854378 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark05(-1.2859796423593906,-54.64738818980106,59.32754670397923 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark05(-1.2861526769293086,-98.63546009574166,-100.0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark05(-1.2863606323767414,-1.4022462528019073,-31.973446779211105 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark05(-1.2864606593021393,-29.6333644193429,-1.5707963267948966 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark05(-1.287749399037141,-1.5707963267948966,-787.0816046612297 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark05(-1.287958039783313,-66.42807597652472,-62.03115864787745 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark05(-1.288514668562165,-66.22449972492566,-42.35049749229651 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark05(-1.2888673416920342,-72.84986318215927,31.416060680191713 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark05(-1.2890872540647047,-48.43648804960319,-3.141593074142326 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark05(-1.2893313983010188,-3.167321972992866,41.389526993284186 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark05(-1.2912537003168065,-0.14590512489110194,1.5707963267948983 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark05(-1.2921178602218334E-16,-0.28442910186075565,-789.9036387051069 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark05(-1.292205972232675,-0.03910087658600503,14.764618067772439 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark05(-1.2922816946695144,-9.965992820854803,4.712441269192299 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark05(-1.292735678487304,-0.26313935144466427,-61.91284494962569 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark05(-1.293004178356317,-1.5707963267948912,40.07841284617507 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark05(-1.293031706292124,-1.5707963267948957,-1.5707963267948895 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark05(-1.2939109073686115,-1.5707963266753198,1.5707963267948966 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark05(-1.293948257744147,-42.36649531409379,-63.63257734559559 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark05(-1.29493414415562,-47.54076972924861,-49.97842437213592 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark05(-1.2951063321668643,-1.5707963267948966,37.71473687870023 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark05(-1.2952739495745391,-73.62372707403036,-0.609996559249472 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark05(-1.2953104745355237,-1.5707963267948966,-33.79062857788635 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark05(-1.295461823278765,6.59466345824485,20.758279552927682 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark05(-1.2964373331090706,-1.5707963267948966,-95.314789625367 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark05(-1.2966321190852168,-40.99664166386171,15.935079805239713 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark05(-1.2973846962274554E-4,-1.5695514356749454,-20.753395035810442 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark05(-1.2977363887931443E-14,-1.423824202044554E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark05(-1.2985063645563106,-1.5707963267948983,21.42409702100492 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark05(-1.2985587453248666,-1.5707963267948966,12.568323880778145 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark05(-1.2987445021173216,-10.470932570495588,7.8539819022141195 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark05(-1.29878926250213,-0.9682401415856096,15.91368409953387 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark05(-12.991557091292634,49.66843319501427,68.17613485391513 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark05(-1.2999913673105892,-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark05(-1.3001375735741187,-3.8558717841646146E-180,-46.99332256458925 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark05(-1.300313751460408,-104.75305298670042,20.420420891647566 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark05(-1.300872413908057,-0.629881055305011,92.35816695303942 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark05(-1.302583617195503,-66.38617760045902,25.132741347932093 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark05(-1.3030555280015361,-78.53981633974485,-1.2061234098866374 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark05(-1.3036598666514407,-1.5707963267948966,-18.570696029278814 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark05(-1.3038121700145613,-35.98845950005689,-68.4026195255494 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark05(-1.305145208948977,-1.5707963267948966,77.46467942173172 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark05(-1.3061457027722099,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark05(13.061762749491649,-77.65808255824345,43.18275334639375 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark05(-1.3062190235789974,-54.974152771659156,135.08901807050677 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark05(-1.3064195601362836,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark05(-1.3067887135432257,-53.40707558786576,-88.64794772639048 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark05(-13.070015251105005,22.924066253112542,25.295189430329714 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark05(-1.307343255151029,-66.80348078854006,-48.05880205057835 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark05(-1.3080674330929853,-1.5707963267948968,-0.3432964239982349 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark05(-1.3087056721215136,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark05(-1.3091714632402127,-78.90532935124013,35.178150134243445 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark05(-1.3095957414035269,-1.5707963267948966,2438.0625480864505 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark05(-1.3100150718902885,-66.48871923084765,-75.7695498340783 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark05(-1.3101819935057608,-1.5707963267948966,8.148345913285912 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark05(-1.3101993873829691,-0.40833889704592347,64.02075929879841 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark05(-1.3113661276167892,-0.8119017772299448,20.02116248158007 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark05(-1.3124139741427026,-72.78375045045271,1.5709099088952725E-89 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark05(-1.3125650791203838,-66.27193477424439,-72.85306895078709 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark05(-1.3127395783625522,-0.20374447552589214,1.9039939836879256 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark05(-1.3127472729659622,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark05(-1.3129401364044693,-0.8984678037626599,79.90473004576529 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark05(-1.3132448573309277,-15.723588267972158,20.427188479341268 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark05(-1.3135688096491251,-0.5102732384245283,8.103993692893514 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark05(-1.3144692967892864,-0.15043480891043703,-20.420352248333657 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark05(-1.3146837317196958,-0.4851924254210239,20.87490329357026 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark05(-1.3147771692336294,-632.4237235216381,-97.87421519205171 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark05(-1.315041414651453,-92.54209812662981,14.439348203754342 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark05(-1.3152640014912431,-47.527715113123215,-55.36428677141876 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark05(-1.3159278590466752,-1.5707963267948966,-26.521059523493612 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark05(-1.3166656618716273,-1.5707963267948966,64.90452910792676 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark05(-1.317005625296311,-1.5707963267948912,89.57210942864303 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark05(-1.317303767260397,-3.9484127069845653E-177,-75.52195338346094 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark05(-1.3176848301458168,-1.5707963267948948,-25.91049313358486 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark05(-1.3180906762410307,-17.08958641185128,-0.32403207578244153 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark05(-1.3184526186984755,-1.5707963267948912,1.570796295334342 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark05(-1.3196693268908497,-117.08637839974334,-67.35192552439865 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark05(-1.320221593319824,-1.5707963267948963,3.141592653493596 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark05(-1.321232574482371,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark05(-1.322416347466687,-3.141600282984325,66.07565477711574 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark05(-1.3234889800848443E-23,-1.5707963267948966,12.55909439480528 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark05(-1.3234889800848443E-23,-22.30940114281522,88.57129991375125 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark05(-1.3237642382190014,-0.8336229664366295,75.07405299689347 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark05(-1.3239486522399662,-9.558652942410488,8.103981633974639 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark05(-1.3248046752135498,-0.24174199791681256,24.18457710374839 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark05(-1.3262007316695583,-1.5707963267948966,17.90434629440764 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark05(-1.3263868508746832,-1.5707963267948948,37.90733265591665 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark05(-1.3263886768911277,-41.82858974484077,146.44984380432822 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark05(-1.326820290292484,4.141592655315243,106.83762435502263 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark05(-1.3284122296595198,-1.5707963267948966,71.72687131989467 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark05(-1.32845971332978,-1.5707963267948966,32.30091778585454 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark05(1.3291639197369238E-17,-1.5707963267948966,0.6000552559712125 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark05(-1.3294269919877664,-35.368671150986216,-83.5144871153228 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark05(-1.3305389337239015,-1.5707963267948966,27.514527609650514 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark05(-1.331257709881863,-1.471962091646668,86.80237937208116 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark05(-1.3317163007636144,-3.1416024801643534,-0.5275906575498854 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark05(-1.3320441515839994,-1.5465861368515526,-4.712391813135996 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark05(-1.3321821324301322,-66.38927120219743,8.10398494545533 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark05(-1.3323519174079117,-0.01670555488871373,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark05(-1.332431075099404,-3.1494053151003087,-42.87324345296119 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark05(-1.332625111977824,-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark05(-1.33429447568543,-22.36007915734742,-13.916788376552148 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark05(-1.3345786914446478,-1.5707963267948983,-6.5475081144602925 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark05(-1.3346199846054665,-66.30363689312212,-37.7575974307517 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark05(-1.3350485666868679,14.434447314120725,-132.3531572801293 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark05(-1.3350870796007435,-1.5707963267948966,7.156539026006595 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark05(-1.3351317965387466,-1.5707963267948966,-23.3397417887591 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark05(-1.3351784887840015,-2.710505431213761E-20,91.90341792110205 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark05(-1.3353138521019499,-47.19875214378384,-16.446755872807138 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark05(-1.3355465559285769,3.1572238610083287,-117.96799776414723 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark05(-1.3359761632863187,-16.069140691441078,-1.5707963267948966 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark05(-1.336459215925512,-1.5599194966101693,20.676954123912672 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark05(-1.3366537206101061,-1.6016664761464807E-145,21.971569822267675 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark05(-1.3366576510743224,-1.4018333464710926,-32.44154545518923 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark05(-1.3368865662220015,-0.1457969571300611,34.33152057420506 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark05(-1.3377229746651065,-28.48377756321792,-1.5707963267948966 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark05(-1.337791433194687,-40.846318914002694,44.02699783782995 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark05(-1.3387381952935782,-66.3427121052828,13.358442990577638 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark05(-1.3387627652831802,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark05(-1.3390609653302032,4.141592666680062,55.144329025780856 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark05(-1.339721195092677,-1.5707963267948983,6.577635556124562 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark05(-1.3401418614307703,-0.2715712726502315,31.87468927395574 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark05(-1.3407653858953301,-1.2425619159976085,90.57705253315669 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark05(-1.3408238719345678,-3.1416004066740446,175.4571406271939 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark05(-1.3416024021773296,-42.4079059857267,-37.81983937269836 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark05(-1.3419862129848283,-28.34430931946268,-54.58083819804588 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark05(-1.343263220841356,-98.10153829317983,118.85242418669912 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark05(-1.3448952363571198,-1.5707963267948966,70.68583470577035 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark05(-1.3449301480034928,-1.5707963267948521,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark05(-1.3455438164498048,-795.8133523575289,52.32272948667633 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark05(-1.3456601884790937,-1.5707963267948966,17.334194841494522 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark05(-1.346137175181596,-0.1558818406276572,0.0 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark05(13.462478943136631,-56.92238050072562,86.88906396131458 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark05(-1.3475273975985438,-3.141592679083027,1.5707963267948983 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark05(-1.348022679062045,-73.57444416576435,-40.97332747832061 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark05(-1.34839965600715,-1.5707963267948966,27.552568755868332 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark05(-1.348833616050511,-0.2146789458608512,-7.853998891900317 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark05(-1.3489570118332352,-0.09109720121306267,-0.0667539667523317 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark05(-1.3493567869507928,-1.5707963267948966,44.343019004789674 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark05(-1.3494993769619925,-0.9287151845083963,88.93117095678164 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark05(-1.35018554359775,-1.5707963267948966,-28.012666699885074 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark05(-1.350251202982028,-0.026922614543620355,0.0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark05(-1.3502556292041383,-2513.799819757384,0 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark05(-1.3502802828042064,-78.73009227018963,90.89576813447499 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark05(-1.3505950890197858,-1.5707963267948966,-1.570796422480113 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark05(-1.350675880733779,-1.5707963267948966,44.373563906636214 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark05(-1.3508221409090002E-15,-1.5707963267948966,-9.350634407918161 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark05(-1.3509506363477488,-0.4246816426070996,113.51373130552528 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark05(-1.3548992405987854,-9.913835302014255E-119,1.5707963267948957 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark05(-1.3552527156068805E-20,-0.3409511381816548,90.87470339699297 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark05(1.3552527156068805E-20,-10.269892513711856,11.040788908333909 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark05(-1.3557126965111095,-15.899797144541958,-2.5520571996739886E-9 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark05(-1.3561194494607156,-1.466365729198075,136.6834443986725 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark05(-1.3563660419495873,-41.64913177401664,-73.7532863177107 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark05(-1.3565623833852438,-180.47168064651495,20.645916612223605 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark05(-1.358135364322003,-35.27529527068833,0.0 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark05(-1.3594013000869405,-2.220446049250313E-16,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark05(-1.360242509555863,-1.7763568394002505E-15,-88.07160889001764 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark05(-1.36030106113318,-3.251923432273345,-1.570796326572278 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark05(-1.360375213925618,-0.6837593076666353,42.55910096673351 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark05(-1.36049947287462,-1.232595164407831E-32,20.368688855485217 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark05(-1.3605802973912946,-1.5707963267948966,71.74623268115214 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark05(-1.3607307960276112,-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark05(-1.3629468777278357,-1.5707963267948966,-1.4145749204676292 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark05(-1.3630172394662745,-98.95035472994468,34.570401128407205 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark05(-1.364530131389367,-60.697060333059085,6.383202427886648 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark05(-1.3655613065023313,-1.5707963267563767,-169.6469809276172 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark05(-1.3656116393128173,-0.42268113945045394,-66.44852479565688 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark05(-1.365715564616515,-1.272220098427591,-34.78983822335408 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark05(-1.3666705174051472,-15.70802436205975,-57.402337364486314 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark05(-1.3670749169490013,-1.570796326702105,21.757843338381367 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark05(-1.3674802416665273,-425.6857527440268,-51.56426695533773 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark05(-1.3676485865328447,-0.22211494845766122,-1.5707963267948966 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark05(-1.367682522830242,-9.432708768112903,-15.909131739011912 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark05(-1.3683581313405406,-154.77852489627844,-18.849796475808176 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark05(-1.3685947922997843,-14.095538857453867,1.5707963267948966 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark05(1.3687689630843352,-61.793364479076175,14.223208809280521 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark05(-1.369157921839948E-15,-1.5707963267948966,-52.716056486067146 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark05(-1.3694605642749011,-1.305818616659998,0.0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark05(-1.3698808431302519E-194,-1.5707963267948966,-41.86949846541697 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark05(-1.3707005322498418,-1.5225275602362398,-27.1103876713597 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark05(-1.3717615069700129,-73.14234344439623,-12.569558747487445 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark05(-1.372174726509769,-66.36598583652506,4.264172673410956 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark05(-1.3723611487184026,-0.3903693237796464,-3.5568625916213197 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark05(-1.3724099121430573,-66.83145021275246,-17.879826783713085 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark05(-1.3724341637453352,-1.3993287865022588,26.647539019821682 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark05(-1.3727586164997998,-1.5707963267948966,53.27834497343113 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark05(-1.3732647079862987,-1.3877787807814457E-17,-1.1345564311710656 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark05(-1.3737082050881306,-66.38659344066544,-100.0 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark05(-1.3737125690377683,-1.5707963267948983,-157.50990000003537 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark05(-1.3743164106145431,-0.9520759581964882,27.90873474187901 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark05(-1.3743679738960264,-66.1136066066299,-9.58797466322729 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark05(-1.3748357643067446,-92.39951728522203,-0.19149794038218623 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark05(-1.3753992502122863,-16.2780006085026,-85.67974303595314 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark05(-1.375741861260039,-1.5707963267948966,0.10520030523688739 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark05(-1.3760100265241557,4.215242370063679,1.5713103649516553 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark05(-1.3763175703144501,-1.5707963267948237,98.06020253761301 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark05(-1.376527041879491,-3.141600285802262,-104.21314869991515 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark05(-1.3768428612813695,-0.5650568898698413,0.0 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark05(-1.377306820323902,-1.454454011163957,97.68673696916136 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark05(-1.3774206124624708,-10.121934967562387,-0.63590409272785 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark05(-1.3776754398557599E-14,-1.5707963267948966,27.053900766029905 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark05(-1.3781175601358497,-1.5707963260954199,-1.5707963267948966 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark05(-1.3786550592646285,-34.86098793884455,-68.60269929029643 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark05(-1.3789704271392473,-34.80923446420793,-3.278923903649108 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark05(-1.379353150825791,-3.469446951953614E-18,-77.33499262574762 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark05(-1.3794378452793747,-48.54833856146401,-67.39064749423301 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark05(-1.380541554080072,-34.66456663042217,2.8332310891291006E-22 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark05(-1.3807229059411104,-1.5707963267948966,-53.7040180802237 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark05(-1.3816248383762726,0.003356956107106429,1.5707963267948966 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark05(-1.3833236625325467,-3.6675240073661845E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark05(-1.384662441208657,-0.5062775075280138,-41.3992207066581 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark05(-1.3848085933281626,-0.2478274715505362,-3.141600283146203 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark05(-1.3850626664611982,-48.226216256984465,-0.39208651507990555 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark05(-1.3855289119275165,-173.80172175225724,-22.375211300465242 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark05(-1.385943806648217,-1.5707963267948948,55.54783918026283 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark05(-1.3860894205159928,-1.5707963267948966,22.874077545220693 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark05(-1.3864104645562367,-41.047834667634085,-31.981657535820666 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark05(-1.3867315987840623,-0.15134784979169513,1.5707963267948966 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark05(-1.3869848401613123,-4.302795939581802,-0.27215311597733743 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark05(-1.3873088308210646,-1.5707963267939373,-37.837397340394034 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark05(-1.3874377990318294,-13.503259962724186,-51.60571121105924 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark05(-1.3876524158466825,-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-0.0177235578700633,1.5402179667262021 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-0.2539399487238495,1.5707963267948966 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark05(1.3877787807814457E-17,-0.5014213559392867,1.5707963267948983 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark05(1.3877787807814457E-17,-1.5707963267948912,66.89432844744633 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-35.228331642770044,84.39684279400531 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-53.42878781775328,25.372237036432505 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark05(-1.387778973401159E-17,-1.5707963267948966,45.55309347681442 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark05(-1.3878206957480368,-48.63740115535681,25.558698476817348 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark05(-1.387976993808386,-0.29277340797764656,-28.27433390713479 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark05(-1.3885085292989459,-9.826169091156668E-14,-138.63439368979982 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark05(-1.3887437623967411,-3.1572102659113193,-0.7498385649377433 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark05(-1.3892242184281734E-163,-9.985542660536805,51.914470639790366 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark05(-1.3899458183354336,-0.5704205996453587,100.0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark05(-1.3899865271235838,-9.995208250603152,-17.278759594743864 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark05(-1.390394861414869,-1.5707963267948966,34.600284059233026 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark05(-1.3911508736532605,-35.92460517172094,8.1410515418455 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark05(-1.3918066527752653,-34.63863574635538,0.0 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark05(-1.3927261839359986,-41.8199724719257,182.0517384131146 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark05(-1.3927822526554317,14.429847503730485,-0.06323360076396661 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark05(-1.3931328150434588,14.429276900881206,0.0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark05(-1.393176993783925,-60.72643353274596,-73.28906077848458 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark05(-1.3937960303842423,-35.062968298802176,-79.03755915279076 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark05(-1.393797647050252,-1.5707963267948966,-17.447577062903235 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark05(-1.3943427570703926,-54.86536342849284,3.4873920435265013 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark05(-1.395072997603711,-1.5707963267948966,64.5991279227201 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark05(-1.3956912340336531,1.9721522630525295E-31,-63.88644520232951 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark05(-1.3957945497106319,-1.2343448383420268,1.5707963267948966 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark05(-1.3960378448747874,-1.2678780989388165,582.6918250250633 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark05(-1.3961057910149113,-1.5707963267948966,-59.98113462021853 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark05(-1.3964347638117816,-40.996453553602606,3.1494051540820225 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark05(-1.3968290278450433,-3.3304347805659242,1.5707963267949054 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark05(-1.3970258072118922,-41.03090864999199,-1.5707963267948966 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark05(-13.971062625951532,-70.43776471223035,85.07050270454874 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark05(-1.3979380721288328,-41.77869956187605,-75.61833994245205 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark05(-1.399471587418854,-85.04821891055596,-86.0971842697487 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark05(-1.3999523962968254,-15.9073735278578,-44.093503249942515 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark05(-1.4016828482808947,-1.5707963267948968,0.0873584753855156 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark05(-1.4020849325996187,0.3726764798292316,-0.002406941903863249 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark05(-1.4022720401003284,-1.5707963267948966,-1256.2890991532106 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark05(-1.402504901208065,-34.57315066652827,20.463406013679016 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark05(-1.4026136362510198,-47.1376111817656,-1.5707963267948966 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark05(-1.403432126530321,-98.10202232813978,1.5707963267948983 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark05(-1.4048758883055952,-72.62479100134219,-1.145235306665675 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark05(-1.4049905817594563,-48.17468456619136,-10.916869529627029 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark05(-1.4055464369808472,-42.135658925085245,3.1476423636746973 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark05(-1.4060630046142562,-1.5707963267948948,-32.59516871010227 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark05(-1.406126303906193,-9.948580482863761,54.181316141333866 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark05(-1.406835489248924,-41.71078308743383,-83.61235085950025 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark05(-1.407180533468769,-66.25546371537254,-806.9157547937615 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark05(-1.4079683449297176,-4.1010376301706675,68.75029261322811 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark05(-1.4084291371951592,-1.5707963267948966,9.995866914063855 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark05(-1.4088328036544886,-35.646995453360006,-26.77126242071373 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark05(-1.4088407314736535E-132,-1.5707963267948966,-12.80749812604547 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark05(-1.409136121185803,-41.41561505312837,38.73521073830935 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark05(-1.4093049268157962,-1.5707963267948966,45.1703086811784 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark05(-1.409406958989709,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark05(-1.4098335256357324,-3.1415950366066054,-36.066241817833905 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark05(-1.4101645764754611,-0.2370796185134742,-26.958062555156374 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark05(-1.4101674463185896,-8.881784197001252E-16,72.70183679767982 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark05(-1.4111867898725468,-3.9567322188587433,-83.3304668788584 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark05(-1.4122855622460122,-60.37788828878749,-49.74769344450442 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark05(-1.412303438347335,-1.1504365173888627,6.283313761031624 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark05(-1.412370960396959,-1.3877787807814457E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark05(-1.4132807421473994,-1.2560207329871425,-10.061731902209004 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark05(-1.4137690952681048,-1.570796326794896,1.5707963267948966 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark05(-1.4145963729565993,-3.1416084215951177,100.0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark05(-1.414956109125168,-1.5707963267948966,0.0350544050745992 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark05(-1.4152849940696006,-53.60998562823524,-0.3083718040252206 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark05(-1.4158959454597602,-72.89075701697375,-87.46738668088369 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark05(-1.4160376846524065,-1.5707963267948966,22.68111387365876 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark05(-1.4161914806110747,-78.76340826918012,0.17588512983496266 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark05(-1.4162017237256024,2.429934757569979,-5.881622281401229 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark05(-1.4163127511800897,-94.53257219561537,0.0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark05(-1.4164234527221637,-91.49812930387179,-53.40710317696685 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark05(-1.416825659363885,-60.71785176456727,-66.40677055002743 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark05(-1.41790963906986,-1.5707963267948966,28.970887240078127 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark05(-1.4179725438594462,-66.69191807282756,-37.82414960580216 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark05(-1.4184797402987808,-1.07236167238231,100.0 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark05(-1.4185083848292663,-1.5707963267948966,-27.846352958932755 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark05(-1.4186030211639393,-85.30445567631713,-3.149408843560438 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark05(-1.4192176150555733,-16.657192935611345,3.142161518433891 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark05(-1.4192809233185057,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark05(-1.4204747513001088,-1.5707963267948966,-54.7955587665814 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark05(-1.420500195292692,-5.2879098282642705E-15,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210854715202004E-14,-1.5707963267948966,-147.62896351749612 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210854715202004E-14,-35.988957904078674,63.06286249998436 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark05(-1.4220435148631427,14.431914951455902,-8.33061557441778E-7 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark05(-1.4224754644313007,-1.5707963267948966,-97.30873663523208 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark05(-1.4227277330673036,-9.980724281526498,-8.103999609760542 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark05(-1.4236775503870591,-191.8384352016545,95.24310060768863 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark05(-1.4237810635534913,-35.477486057652854,1.5707963267948963 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark05(-1.423806917215657,-66.92056830680373,55.38042332948612 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark05(-1.4238152976467884,-1.5707963267948963,-209.02374265985475 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark05(-1.4240336218264962,6.938893903907228E-18,-0.06009423652348829 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark05(-1.424060994682559,-10.209031913006855,27.741696505579256 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark05(-1.4241657887282728,-1.5707963267948966,-94.27208536439511 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark05(-1.4244075460891565,-0.2321317008633521,-88.781395647457 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark05(-1.4246599970337837,-1.5707736448111935,-72.47199993869908 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark05(-1.4251657021293662,-40.965744157602856,-1.5707963267948966 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark05(-1.4261510302936018,-22.103178736249806,3.1415940143961887 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark05(-1.4263461248510796,-0.009749183907030504,-1.5707963267948966 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark05(-1.426377180585524,-34.910912961360374,3.1416232341990047 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark05(-1.4265793395922137,-2.3884408649488572E-32,-1.5079365727889984 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark05(-1.4267575723422494,-54.10227442004495,-1.5707963267948912 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark05(-1.4272509636888238,-47.44611664830512,35.63396596761161 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark05(-1.4277988408264732,-6.397334931431238E-15,50.128559477290196 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark05(-1.4286274010360687,-1.5707963267948961,-0.06672066871346068 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark05(-1.4286948465941958,-1.4121233135185807,0.7078076659022164 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark05(-1.4287112710849594,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark05(-1.4287342391028437E-101,-15.902311546849106,-57.632657279822475 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark05(-1.4301977487899231,-4.596324304585735,-55.181112931224085 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark05(-1.4304355785779654,-53.43780708391255,9.487277972351652 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark05(-1.4304752656858866,-1.5707962722753972,77.43062329760518 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark05(-1.4313482776516142,-42.071118947381336,94.38804753848684 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark05(-1.4315649410093028,-0.25684858102941915,90.76940946615458 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark05(-1.4315885441576794,-4.135737462513276,-17.534221581361766 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark05(-1.4315969793421444,-10.187997281832821,-4.71239865244037 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark05(-1.4316106370375292,-0.18707844593647602,-8.10398163600764 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark05(-1.4322094538253274,-54.89836384392333,-1.5707963267949303 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark05(-1.433135702363848,-1.1309107859206284,-14.39763008210548 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark05(-14.333112497448482,-98.35528793143946,17.92689007745814 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark05(-14.334480694220673,-72.21528526289227,57.599630368002096 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark05(-1.4349168794937124,-98.18923069870584,-107.41932783446202 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark05(-1.4351627296521183,-67.34055366873694,-1.5707963267948966 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark05(-1.4353571220513412,-2.220446049250313E-16,0.0 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark05(-1.435417584745131,-1.5707963267948966,49.734518560011935 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark05(-1.4361536343491925,-1.1150286099615663,8.354661255380758 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark05(-1.4362595267231273,-16.201284012710982,-35.48577907996813 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark05(-1.4370270630922342,-9.484939065426659,-10.145733395160647 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark05(-1.4372388136825813,-9.963121566077064,2.8033627067179463 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark05(-1.4376167005953127,-84.96418259890875,20.396258221942304 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark05(-1.4386693924922973,-1.5707963267948966,-40.30900314230278 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark05(-1.438723404361758,-0.15259565413746012,42.64121833306344 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark05(-1.4389991948561698,-16.64490435441378,-3.1494051602136217 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark05(-1.4399005185263007,-154.60133606462475,0.7844707627063698 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark05(-1.4408699278837427,-48.124367980135126,1.5707963267948966 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark05(-1.4429164431332335,-97.89648513190198,39.36823775338115 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark05(14.429203682695722,-3.0814879110195774E-33,-100.0 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark05(14.429210648986675,-47.368495697786884,40.29083656321025 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark05(14.429237853093731,-60.99066068219032,-56.83544306419149 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark05(14.42924967664674,-1.4261562191871326,8.281549342852372 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark05(14.429288314318164,-1.4898143644262551,10.599329769387058 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark05(14.42929297612502,7.888609052210118E-31,-1.1512891821904516 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark05(14.429313231987905,-48.3648075940486,-82.97073039825861 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark05(14.429431466972098,-1.5707963267948966,45.29322841589811 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark05(14.429431706476194,-3.345172141923877,-0.621747789828039 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark05(14.429476066783643,-1.9037744977506598E-20,84.29363754610725 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark05(14.429503664613826,2.2926648475979174E-22,1.5707963267948966 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark05(14.429551931161967,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark05(14.429564419506669,-1.57077747806893,99.51370166485091 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark05(14.429781133617489,-556.488460563629,-0.6354492301909285 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark05(14.42978955199068,-1.5707963267948966,0.8616511325064351 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark05(14.429914934819855,-98.88551470334286,562.1955296212246 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark05(14.429963414562593,-0.35039621379258545,201.51964160688604 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark05(14.429995883437222,-92.30499149203902,-53.568475860410786 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark05(14.43019290120872,-136.0297580528433,56.61947241535748 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark05(14.430776083626434,1.0587911840678754E-22,39.861695047691086 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark05(-1.443085398613507,-122.90437422556857,-37.69297822243236 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark05(14.431056636773945,-1.5707963267948966,1.5707963267948912 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark05(14.431322039241742,-0.09924344007146846,78.89076084410338 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark05(14.431383535802915,-1.5707963267948966,33.53378793406537 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark05(14.432670818482052,-100.0,1.5707963267948983 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark05(14.432837393214825,-72.30004427760834,-142.45840400268992 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark05(14.433306998684117,-1.5560645807273374,-58.445008420834874 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark05(14.434038581547632,-1.2446416439486045,-6.284184787133829 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark05(14.434750303632711,-1.5707963267948966,76.70323661425846 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark05(14.435632896137179,-3.14171997153452,68.26795266029573 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark05(14.437688084947496,-1.5707963267948966,93.92058861014503 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark05(14.438255184007573,-2.220446049250313E-16,-78.11793619164087 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark05(14.44569158769822,-3.1416200266988574,0.0 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark05(14.446283968588759,-1.5707963267948966,78.19408993939965 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark05(-1.4446593090955377,-0.636896541314185,0.5702755434689571 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark05(14.450342815871466,-0.053177332719965914,-1.0934403869469036 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark05(14.451280659311792,-3.145334190374669,-0.25226397768815023 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark05(14.451717378331317,-0.004598386393379846,6.287091557179613 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark05(14.454727470095875,-9.487500934344435,53.11891729569824 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark05(14.455167323778653,-98.53539229289576,1.5707963267948966 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark05(-1.4457798599548548,-1.5707963267946652,9.210602671197073 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark05(-1.445895389701609,-0.22116235063857867,-6.283185307179592 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark05(-1.4460235215224406,-0.017822254200742016,-44.57511699284944 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark05(-1.4466017344863167,-66.46730414922432,-12.48277302426897 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark05(14.469724135585324,-35.55647034186856,174.17586213503256 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark05(-1.4475970579707154,-48.32614233090441,1.5707963267948968 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark05(-1.4479638257187428,-3.142082939085386,-49.81788063572188 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark05(-1.4482544718123567,-0.10288272584653357,72.86758489146189 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark05(-1.448653424416955,-0.6215328063978707,81.21677284701997 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark05(-1.448666704946346,-1.5707963267948912,-47.213928092231825 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark05(-1.4488917060456596,-0.5550733821894198,54.7912833270554 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark05(-1.449144363455789,-1.5707963267948961,-48.402653052408716 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark05(-1.4492044703495957,-92.28890973496691,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark05(-1.4492318994887383,-66.23022615065489,1.5707963267948966 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark05(14.493613627743983,-47.31779100124952,-31.845448993895022 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark05(-1.4496983438845916,-1.5707963267948966,20.638099387433357 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark05(-1.4497760268268778,-23.54853775958449,-456.0850214009766 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark05(14.49930312578526,-3.1579709120213035,1.5707963267948966 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark05(-1.4499637082681762,-1.5707963267948966,59.615977030745086 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark05(-1.4504792802474242,-10.356496039874713,164.88922774830112 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark05(14.508828609162755,-3.173338229209343,-56.05935841877456 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark05(-1.4512037536764422,-0.01850959925023607,-3.141687833954647 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark05(-1.4519796123010131,-1.5707963267948963,100.0 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark05(-1.4523096723722864,-1.5515892863218304,-84.82300164692441 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark05(14.523631853388274,-84.97431498114682,543.0082894903958 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark05(-1.4525188300801135,-19.888761756526655,92.530464845953 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark05(14.52591223829311,-1.5707963267948966,-0.06289822350840737 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark05(-1.4526838969831288,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark05(-1.4531958978978565,-0.4571932981392941,0.8754722467949156 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark05(-1.4537069334462585,-607.897465797419,72.27575591221154 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark05(-1.4538213937159643,-1.5707963267948966,-97.67647889370636 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark05(-1.4539263863518235,-17.186322290857206,-97.57731595448844 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark05(-1.4540082582705156,-1.5707963267948966,24.172172822782617 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark05(-1.4541613429186815,-0.10781583012277127,-100.0 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark05(-1.4542712280552672,-1.0869090168451692,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark05(-1.454402720528238,-0.009559758394563833,-79.28800242136377 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark05(-1.4551541736279854,-9.985386245235304,55.320440447305494 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark05(-1.4554310744789467,-97.3894027821436,-98.76578573139555 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark05(-1.455657768207197,-3.684791442884645,611.8686040802197 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark05(-1.4560364517781232,-66.30600081284638,1.982767060402851E-118 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark05(-1.4569615923966863,-53.595263468465056,6.292450409396736 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark05(-1.4570548453093801,-1.5707963267948983,-0.38310340657637915 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark05(-1.4572361796981355,-41.692364859335875,-108.25407308118128 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark05(-1.457607267792887,-103.7163826043527,90.74371598724957 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark05(-1.4579277651366307,-122.99379894369633,-113.59759946744992 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark05(14.590246057998918,-66.34585810527342,1.5707963267948983 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark05(-1.460540049061143E-14,-66.25802531736242,1.5707963267948966 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark05(-1.4607056549067892,-0.10362506832578544,55.119284826699044 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark05(-1.4607493785768169,-73.2606126909509,-73.02139168449126 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark05(-1.4608735039594944,-97.8799401648479,-1.5707963267948966 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark05(1.461208121622164,23.70189615261613,29.591640767900827 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark05(-1.461272672932345,-5.551115123125783E-17,-31.759328847968323 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark05(-1.461295916321401,-5.449848714085856E-15,-75.39920116534306 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark05(-1.4615508539332018,-67.3632411610116,-9.424827537627223 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark05(14.61741742326732,-3.143567197563542,-1.5707963267948024 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark05(-1.462710347204769,28.70353755551348,-4.7307514436879785 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark05(-1.4632808183805188,-28.4559368546836,-1.5707963267948966 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark05(-1.4637146580309093,-73.65548012059894,-168.60213794857924 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark05(-1.464403623616267,-41.86994868333099,-78.52247903055655 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark05(-1.4646449594615092,-9.522381582767409,-30.443954408178485 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark05(-1.4651810276172377,-1.2900392862142915,84.45301301468666 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark05(-1.4652689922351096,-1.4199553902314657,79.58190075166053 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark05(-1.465291254077259,-1.5707963267948966,6.283185311754326 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark05(14.656270858991796,-167.20926976865644,-1.229238693854569 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark05(-1.4659060526281515,-51.442756359591016,-0.8652238235140093 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark05(-1.4675000316721885,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark05(14.681566743092532,4.142186722617752,216.49477500402776 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark05(-1.4688029250376164,-1.3236924031065669,51.565092213925055 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark05(-1.4688807472056777,-1.3421650288617963,-86.49981983626493 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark05(-1.469312149111064,-66.57785836227227,-131.89580369699465 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark05(-1.4696368839770413,-60.382838524925035,-1.5707963267948966 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark05(-1.4722446869953416,14.44049918979843,-103.73255108349282 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark05(-1.4722714740517657,-0.16056896678557142,1.5707963267948963 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark05(-1.4723385937775744,-1.5707963267948966,76.67132687411863 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark05(-1.4723978050749673,-4.170010094479975,-10.001844856292095 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark05(-1.4731099964467786,-1.5707963267948957,-1.5707963267948966 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark05(-1.4732819075983237,-0.022159050030870514,-89.77474072727117 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark05(-1.4733756486258405,-0.788238470771184,-1.570796335292307 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark05(-1.4745719035373936,-0.014193484974009296,40.18209182107873 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark05(-14.747431745996423,0,0 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark05(-1.4749192617438731,-9.519981054748879,0.0 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark05(-1.475478301635776,-73.14113010358143,-0.019329811158240617 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark05(-1.476339002042377,-0.2326848585181256,-6.283185307179591 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark05(-1.4772197139370868,-191.71781169878858,-100.0 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark05(-1.4775218918990356,-1.404172569415921,-94.24974898161271 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark05(-1.4781944441581683,-4.588118804793368,-29.694554060617122 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark05(-1.478621631337898,-111.09379001722195,-46.22517568495126 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark05(-1.4792879700381447,-1.5707963267948966,1.232595164407831E-32 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark05(-1.4799720627865622,-1.5707963267948966,4.712388981030359 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark05(-1.4801621583552578,-91.72891189354281,-0.14745078544462972 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark05(-1.4802454129680236,-35.42302822751348,0.0 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark05(-1.4812740562940698,-0.2187625823795868,-85.10991710667722 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark05(-1.4813572155486645,-1.5707963265551352,83.78508618130581 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark05(14.813869267554836,80.74874450020855,-54.88035420011461 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark05(-1.4818080960271516,-172.88141379896783,0.09441318885395766 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark05(14.822068812326023,6.908040572319038,41.18901957956848 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark05(-1.4824937612075482,-1.5707963267948966,-26.17887349067226 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark05(-1.4828134586864203,-771.2574094152565,-27.826370889483137 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark05(-1.483114278541589,-0.29881669431198155,-34.77734035883139 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark05(-1.4832669560485585,3.141627743177184,74.38311391255876 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark05(-1.4833474404658784,-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark05(-1.4834332368546554,-10.032214166403183,28.99343397566406 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark05(-1.4835786162817586,-66.29111428915623,69.85548352339327 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark05(-1.4842868587408256,-1.5707963267948966,25.438802231121613 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark05(-1.4843522912228675,-1.5707963267948966,71.36575749641528 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark05(-1.4847989863782112,-1.0855453535940547,119.34619573708872 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark05(-1.4848726081743475,-104.44387854470432,-14.661717178964821 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark05(-1.4849977646873818,14.429405887656955,-4.713776323984786 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark05(-1.485093762945437,-1.0732286231543393,-20.420352248333657 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark05(-1.4851260377545208,-3.266896784576379,66.15078298171846 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark05(-1.4861544415421246,-9.435762105186782,-41.896600819590695 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark05(-1.4861950016045578,-1.5707963267948983,20.541255017352782 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark05(-1.4862136519135083,-3.1649109871847116,-83.85449671192153 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark05(-1.4876788720392706,-1.5707963267948966,-12.566492977319065 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark05(-1.4877815545704518,-0.1718091543555369,69.60040368433069 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark05(-1.4883993035136118,-16.388099833008525,-0.2775310752615104 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark05(-1.48841853949491,-1.5707963267948966,18.662089331656208 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark05(-1.4884191746688795,-66.7906276804534,-69.07265440754226 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark05(-1.488846732596842,-1.5707963267948957,-52.97290529718361 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark05(-1.4892999226418044,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark05(-1.4894409200944665,-66.69794379742824,41.28503466262651 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark05(-1.4897209956130553,-41.90215292022346,19.8136918214487 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark05(-1.4916208216341063,-1.5707963267948983,-18.361796653478535 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark05(-1.491937731761844,-67.53357285931911,-146.1882460203874 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark05(-1.4922911778669061,-0.023908899515886546,1.5707963267948966 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark05(-1.4924176786453474,-0.037260449540108445,52.301183492301334 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark05(-1.492449901790244,-3.504106455661457,42.35253737015418 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark05(-1.4927079574308664,-0.051412802393566014,365.9386814761052 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark05(-1.493078449105111,-1.5707963267948966,23.41528941811132 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark05(-1.494473195539133,-66.33090596013156,1.5707963267948968 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark05(-1.4944931854026224,-3.5868061585132267,141.3715023635852 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark05(-1.4945781136266332,-1.5707963267948966,77.2822690365082 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark05(-1.4946341485907517,-167.08904654461705,64.95483274495386 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark05(-1.4965075863849424,-0.7542480936718184,77.53464081159001 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark05(-1.4975788696727603,-59.690887381102065,-3.189925747234477 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark05(-1.4977921707906923,-54.31507733785574,-1.570796310277697 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark05(-1.4984809782368929,-9.877769674730814,-1.5707963267948966 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark05(-1.4986440003151817,-0.030768735676615273,-84.90184937587617 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark05(-1.4992778356249952,-0.2401836089817709,-1.5707963267948968 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark05(-1.4999156208005502,-1.570796326794886,120.71071063900791 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark05(-1.5005856555343875,-97.76260545734358,-10.193148550614708 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark05(-1.5011980066302688,3.27612000438806,56.4731905841339 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark05(-1.501232533777539,-1.0704034459476952,-21.10529724149535 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark05(-1.501277511665954,-1.5707963267948966,-6.283401532574562 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark05(15.013227735285042,-48.016136532437706,-34.769575906309626 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark05(-1.5013792701499913,-73.01519328780266,0.0 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark05(-1.501759866764838,-60.47974380583116,-1.5707963267948966 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark05(-1.5020816960464611,-1.1050659714852518,-16.06868109551499 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark05(-15.027383537165818,71.10342489157537,-35.199872019541445 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark05(-1.5027489763495134,-117.64968236798711,-72.95170590872695 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark05(-1.502881284137593,-0.3604792904240366,-459.0095387893468 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark05(-1.5032903530139763,-0.9915847385092564,-53.46220138812545 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark05(-1.5039305332717021,-15.985120506880797,-99.450291859171 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark05(-1.5042528048812263,-9.644433958649547,6.16865267831588 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark05(-1.5042821995763391,-3.267795057792077,-1.3879854728359646 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark05(-1.5045451903439752E-13,-2.220446049250313E-16,-0.20407532676848664 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark05(-1.5051727949317406,-3.1488638051800266,-20.830447448989222 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark05(-1.505691704517492,-104.36151284636409,-27.57492638221835 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark05(-1.5059906447984028,-0.06872202654901916,49.75292491037204 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark05(-1.5063915001628048,-54.18889182278582,-0.6215576636023422 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark05(-1.5065461720900628,-1.5707963267948966,-3.1415928635929524 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark05(-1.5068120222727348,-550.7755242624999,-107.41946524747573 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark05(-1.5072238362190848,-0.6009307878418859,-1.5707963267948983 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark05(-1.507292275045858,-3.1015839479233716E-10,-4.207386042326915 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark05(-1.507330964458125,4.141592653589796,-48.58485710520993 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark05(-1.507430212922512,-54.193082877797906,-53.88961931854159 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark05(-1.5079878388658958,-0.8128954983621047,0.0 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark05(-1.5083112556106135,-4.141592653589798,-0.18072774914709555 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark05(-1.5084766834097076,-0.7453662816235442,-46.76509807073514 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark05(-1.5086273344812213,-4.440892098500626E-16,-1.5707963267948968 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark05(-1.5088808622182777,-1.5707963267948966,6.283185307179594 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark05(-1.5089496155455546,-10.825787786952796,-28.676406310505154 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark05(-1.509605160065187,-35.44023870519646,89.66477846102433 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark05(-1.5096349463879981,-1.5707963267948966,98.17543143885962 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark05(-1.5102462514130102,-97.91335363887103,0.0 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark05(-1.5107442484880391,-22.006980497906653,98.49971536531196 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark05(-1.5109025939709881,-0.12178224194230006,8.10398176639967 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark05(-1.5112930220910217,-61.24124281216164,44.545476619272286 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark05(-1.5115651933806136,-9.657943590636378,1.5707963267948966 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark05(-1.5119993771810791,-192.17607845508053,-44.381620336203724 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark05(-1.5120623379518139,-1.5707963267948966,-39.123114009257975 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark05(-1.51226054689002,-0.03908106398183578,1.5707963267948966 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark05(-1.51227482550658,5.421010862427522E-20,66.51458082725279 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark05(-1.5124367969615682,-16.182583833129456,-49.35211426120243 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark05(-1.5135292495046837,-4.2351647362715017E-22,-79.18996045674314 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark05(-1.5137356891277598,-41.618597596879354,20.536027592638845 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark05(-1.513960805579846,-47.56100870806916,80.70484102350136 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark05(-1.5140110769522261,-1.5707963267948963,90.14110936957091 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark05(-1.5143382774019063,-0.10968280907232703,65.26619241745006 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark05(-1.5144596969851,-16.095576259062454,1.3752427524461102 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark05(-1.5151982468006133,-1.5707963267948966,8.103981948884602 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark05(-1.5154764385284665,-22.010915174499118,69.13783002957126 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark05(-1.5156141833097065,-1.5707963267948912,1.5707963267948983 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark05(-1.516212463376927,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark05(15.164899114173181,-14.464571361902046,-84.8456706693537 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark05(-1.5171834461776867,-72.40771274831658,-79.28595396863841 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark05(-1.517406244698373,-4.471465098835225,-1.5707963267948912 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark05(-1.5175517474141995,-1.5707963267948966,-9.42477796076938 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark05(-1.5176337625824379,-35.92711921942346,0.059619734246731754 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark05(-1.517713759130769,-833.7544809341993,-99.71385198996533 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark05(-1.5183135918588941,-1.0287994446158972,-27.69095346280244 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark05(-1.5184399502958414,-1.5580053951377708,-6.215026058398889 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark05(-1.5193030913185843,-1.5707963267948966,-69.4985761337055 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark05(-1.5195846478010648,-1.3423170007498662,2.778448436856347E-163 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark05(-1.519592916067578,-0.6686332822897865,5.659166841229053E-10 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark05(-1.519597525593781,-41.70839293003123,-10.995574287564276 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark05(-1.5203416576340714,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark05(-1.520678258451667,-53.82893603258029,-29.178447828774168 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark05(-1.5216631186183975,-6.514053679857885E-15,0.0 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark05(-1.5217747735061715,-4.073961150383397,-26.748426780709696 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark05(-1.521977746513876,-66.18010163601798,-41.42514242979171 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark05(-1.522210055193537,-9.583414387785755,-698.4147792968042 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark05(-1.5229971071924908,-2.220446049250313E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark05(-1.5230515624228136,-15.974598788706416,-89.53037146678803 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark05(-1.5230967554837833,-65.99796435453132,6.288344805227921 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark05(-1.523258635094225,-3.760975688307925,458.6889244345144 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark05(-1.5237294565274115,-0.009173595939656984,-4.70356589618941 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark05(-1.5239027301742598,-35.199506089078575,1.5707963267948966 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark05(-1.5239439475507182,-1.5707963267948966,-0.6092376958089865 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark05(-1.5241225083630654,-72.5007207601396,38.532382491151786 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark05(-1.5242421160178024,-1.5707963267948966,-84.40890113395156 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark05(-1.5243240493122885,-1.7837408568704453E-4,1.5660032787023859 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark05(-1.5245834513661238,-16.12260682095723,80.94743192241651 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark05(-1.5246501819085279,-61.0185212249332,91.09002880779013 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark05(-1.5246617573224408,-66.68247782220217,27.826279902894978 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark05(-1.5254575167703552,-1.5707963267948966,-50.05329947528371 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark05(-1.5257001205198897,-35.98696967910999,-78.42016855092905 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark05(-1.5258887699462933,-1.5707963267948966,-35.62554066715953 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark05(-1.526024653637106,-0.40831758742572494,0.0 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark05(-1.5266112437511556,-3.6705988245582013,-12.799313914152648 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark05(-1.5266124085840258,-0.3027863018469498,-100.0 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark05(-1.5270181170547494,-3.1945123707053096,-1.5707963267948966 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark05(-1.5272174410835717,-0.4265002409755497,-5.141597606896977 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark05(-1.5274681817498023E-151,-1.5707963267948917,-100.0 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark05(-1.5277799420049263,-10.268357612502882,-23.061272272582965 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark05(-1.5279071097452612,-10.028734482207268,100.66558652334419 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark05(-1.5281631839784733,-41.60089653211847,22.038358037806447 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark05(-1.5292564231017065,-1.570796326794893,-2.5231722942036896 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark05(-1.5292823042815495,-0.31529290326348997,9.031022122017589 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark05(-1.529327771528521,-110.98369318974088,16.226400015195637 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark05(-1.5297738685765285,-72.44565815120393,1.5707963267948968 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark05(-1.5298121968823537,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark05(-1.5302950743922301,-123.37194633318944,77.53143068688834 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark05(-1.5317750105151933,-10.990982317341278,45.374728240765144 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark05(-1.5321080618388634,-0.27250522164283,-88.99419851325791 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark05(-1.5321309831443095,-72.78727692132168,77.45776364335345 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark05(-1.5321654685441268,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark05(-1.532793454277705,-130.25614980367953,-16.208093073546102 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark05(-1.5334518355107116,-1.5707963267947074,89.10281950295919 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark05(-1.533600371413364,-0.6283016556561369,-19.485235604343444 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark05(-1.5341218070369633,-1.5707963267949019,-12.44777459572488 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark05(-1.5348436039558817,-0.2946275933293042,1.5707963267948966 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark05(-1.5348829817824186,-3.267311519512406,-1.5707963267948966 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark05(-1.5351434530294816,-60.878076772376104,-55.36315976562287 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark05(-1.5355069637495984,-1.5707963267948966,40.38478692281046 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark05(-1.5355715686165343,-48.285672787834784,88.09258465342053 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark05(-1.5358640552473966,-16.79302406935406,-1.0270337831515444 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark05(-1.5365729174193374,28.703537555513428,-100.0 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark05(-1.5371150673207887,-123.14503614143916,44.265268755769775 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark05(-1.5374549923793417,-1.982767060402851E-118,2.786394756383558 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark05(-1.5374977264557377,-0.005295001031919692,-67.46937210820158 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark05(-1.5376035728120692,-3.141600283064327,-94.78391253027168 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark05(-1.5379471339842006,-34.965090253713285,-285.94518473900416 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark05(-1.5381901597021255,-54.83365434384266,-1.570796326794893 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark05(-1.5390633466935277,-97.60339278557173,-91.49974821251959 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark05(-1.5391585396068752,-1.5707963267948968,-1.5707963267948966 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark05(-1.5392576584218938,-1.570796326794895,72.4239920779533 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark05(-1.5393029721196754,-299.4512673389509,-49.94902897770777 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark05(-1.5394427421030448,-47.19191563439391,-41.81252051505284 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark05(-1.5394966471954186,-34.81673076729935,-1.5707963267948948 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark05(-1.5395330546542125,-0.8681154491211542,-1.5707963267948966 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark05(-1.539650909010993,-0.3026942132678486,-28.13117390141698 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark05(-1.5400623403134668,-9.946707321334827,-57.75822829936316 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark05(-1.540314002985241,-0.4674021875509955,-77.38311612081803 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark05(-1.5403539019162864,-1.5707963267948966,-62.08905826344559 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark05(-1.5411154664080366,-47.28536789370228,485.7129146504885 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark05(-1.541127568270896,-3.341517504248486,9.856694569569683 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark05(-1.5412041986576668,-48.3261450834797,-41.762877750395546 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark05(-1.5420758395349865,-21.995054825184614,-1.5707963267948966 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark05(-1.542097420652411,-0.2972225553779977,0.0 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark05(-1.5423487136658458E-179,-1.5707963267948966,7.414326507589635 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark05(-1.5427334262156946,-60.1664066183678,-1.5707963267948966 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark05(-1.543025706860668,-1.5707963267948966,-95.83935998111942 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark05(-1.5431890144862335,-1.5707963267948966,430.46732542344716 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark05(-1.5432496554580224,-9.975034223443036,-88.27742332051221 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark05(-1.5434023677684197,-1.5098980989096749,-41.41330863045576 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark05(-1.5435602808358664,-1.5707963267948966,97.39869497424903 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark05(-1.5448854552498108,-1.342952380884496,6.283246641758751 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark05(-1.5450883389313965,-1.570796326538297,42.55254496006945 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark05(-1.5460091022995697,-1.5707963265188403,-35.147182482976035 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark05(-1.5461859201915,-1.5707963267948966,-26.838432096592836 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark05(-1.5462360829512114,-54.71568309163831,-85.97712253335116 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark05(-1.5464319235608701,-48.69440896483607,21.98860452475737 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark05(-1.5465089953158917,3.141592653591692,-1.5707963267948966 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark05(-1.5465714549435683,-1.5707963266096907,44.19307866092089 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark05(-1.5466327789137444,-1.5707963267845895,81.91678501886383 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark05(-1.546725275959203,-3.141592653599204,-48.09041178859589 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark05(-1.5471547381018735,-67.30627107127067,-0.05499847244972567 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark05(-1.547305814824803,-10.18775202779625,-1.570796326795012 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark05(-1.5474658838009634,-167.29390372800023,10.83868924948679 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark05(-1.5479341159686817,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark05(-1.5480981197921393,-4.569947364261795,-110.1193666119728 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark05(-1.5481377954453512,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark05(-1.548445501965741,-0.29541349578993187,117.81009741304342 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark05(-1.5486068279926049,-10.093002584833167,0.7816635372597247 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark05(-1.548655992520129,-1.4457651948897698,-937.2308321996628 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark05(-1.5487563982162225,-1.5707963267948966,-62.143300133157744 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark05(15.491443760362984,-40.19663383730112,-88.61383932107303 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark05(-1.5495745943416177,-135.4866863563635,-35.29185119697411 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark05(-1.5503133239400455,-35.13305107648947,4.440892098500626E-16 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark05(-1.5503717673021526,-10.390219587428387,100.0 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark05(-1.5503794094203687,-1.5707963267948966,29.306971027784424 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark05(-1.5506418803206724E-4,-0.013799416177427236,111.56241309982732 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark05(-1.5509837635092478,-110.1184573926131,90.03954300844167 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark05(-1.5510699736968554,-53.877359639845125,-5.404131129645947 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark05(-1.551420118530488,-41.41857956940913,69.51991181790211 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark05(-1.5514583262358006,-78.69555048135985,-5.1415999928072855 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark05(-1.5520410863870324,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark05(-1.552558282745877,-66.08826159219076,-4.141592653811689 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark05(-1.5529120774876284,-1.5707963267943486,-32.409465373503366 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark05(-1.5534418135502068,-42.33308211373429,-1.5707963249032701 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark05(-1.5536358320603247,-78.87411228061985,-2258.9168011451884 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark05(-1.5538032801524222,-73.69626906087099,-1.5707963267948966 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark05(-1.553822649253456,0.21017623538043118,1.933388967427985 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark05(-1.5539228966701522,-9.543742458937233,32.423203354455445 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark05(-1.5542115428602037,-1.5707963267948963,6.08209161401486 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark05(-1.554307758350415,-1.5707963267947818,-120.94270981581431 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark05(-1.5543866058727047,-3.1420810359027915,-78.76397584016226 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark05(-1.5549492905012432,-0.8211699862836177,135.93806810788993 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark05(-1.5555552127879555,-1.5707963267948966,-1.570796326794896 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark05(-1.555708714637394,-1.5707963267948966,-94.63705730374605 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark05(-1.5560522054355292,-66.25244951843534,-37.59309580392555 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark05(-1.556628223558267,-72.95863983769057,20.624386095640535 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark05(-1.5567791046027526,-3.141592668490963,8.392057653834343 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark05(-1.5569273602930618,4.14159268992101,-1.5707963267948966 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark05(-1.5571354779669944,-1.5707963267948961,383.30741094360997 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark05(-1.5572673875487313,-47.53891167576213,-43.50793958798577 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark05(-1.5573021237584104,-1.5707963267948966,5.141603882488038 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark05(-1.5576445150629301,-1.5707963267948963,3.2206909318216645 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark05(-1.5576604802802492,-42.310361576865986,-1.2565994067947333 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark05(-1.5577272723136273,-1.5707963267948948,-19.753895371749902 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark05(-1.5578349136047842,-15.982048630196825,-78.22408904807074 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark05(-1.5578897568690895,-1.5707963267948966,-2.2651930378724643 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark05(-1.557896497944977,-1.4445406140190986,-0.020307372423418596 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark05(-1.5580617354660404,-1.5707963267948966,0.5904548966274956 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark05(-1.558242733290143,-66.57005920345412,-4.712389041414063 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark05(-1.5582484687279323,-1.5707963267948966,4.6341723013327325 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark05(-1.5583444901509822,-1.5707963267948966,90.78140548979282 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark05(-1.558479513505894,-1.6016664761464807E-145,-0.8278271106478514 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark05(-1.5585472783934866,-78.94965561927644,64.16123172155557 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark05(-1.5587357814419491,-783.5783812007755,89.71519002761036 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark05(-1.5587560484812806,-180.23581344585446,-418.60671614169314 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark05(-1.5590066496533044,-92.03331803683605,-3.141623331410103 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark05(-1.559127027521564,-0.42235729415694356,-51.64582254620203 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark05(-1.559392602727787,-0.12821209905074815,69.25996002137822 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark05(-1.5596467167354042,-1.5707963267948966,-65.15361494072336 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark05(-1.5597375949183752,-1.5707963267948966,-42.895090581818714 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark05(-1.5598146693555077,-9.933633722865848,-12.566378248431482 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark05(-1.5599705680084257,-1.3552527156068805E-20,0.48976711353464086 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark05(-1.5600191211745045,0.8408500318036131,-100.0 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark05(-1.560590763620332,-9.952878807114747,-10.614748649937253 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark05(-1.5606884938692642,-87.9512515659716,0.0 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark05(-1.5608925826915534,-1.2179714233427024,2.9038804473648963 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark05(-1.561120117253385,-35.55659691019058,20.092002929981916 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark05(-1.5611276305156894,-4.440892098500626E-16,90.33241323442417 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark05(-1.5614306696493305,-47.92551861191998,-3.1416726947676086 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark05(-1.5616282612177108,-1.5707963267948966,205.77624575482383 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark05(-1.5619804298093434,-0.14349852559700188,-89.96141818750905 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark05(-1.5622273540014149,-1.5707963267948966,70.01415096346653 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark05(-1.5623533374420364,-1.5707963267948963,8.103981683005777 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark05(-1.5626781112784387,-1.5707963267948966,-3.1415926535910614 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark05(-1.5627666935314857,-9.793399440830825,-66.26691299873094 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark05(-1.5630797897185247,-10.648285818977875,-3.141600871519501 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark05(-1.5632988788338165,0.045051036344011246,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark05(-1.563323101464205,-60.800829922964404,-15.524985832086884 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark05(-1.5636486443317534,-22.414260430075288,437.76140114326836 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark05(-1.5642507429227388,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark05(-1.5643435795710008,-1.5707963267948966,-2.7397616862605038E-194 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark05(-1.564546619351637,-1.5707963267948966,-8.554603947469756 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark05(-1.5645793524716847,-36.11115867555179,-15.848183207364784 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark05(-1.564759116827588,-1.5707963267948966,-307.9930325073936 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark05(-1.5648796844030388,-72.419748342595,0.17643556918754494 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark05(-1.5648901498492724,-35.9270556272517,-0.44458950132559516 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark05(-1.5653348928455288,-0.016200266975473422,70.57635770783195 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark05(-1.5653507033140759,0.0,0 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark05(-1.5657498643828291,-1.5707963267948966,3.141637871941736 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark05(-1.5658609400780743,-0.0021067467545368337,8.49521888783589 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark05(-1.5658783086939525,-3.142080934839795,-28.81121238268301 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark05(-1.5658810201418203,-47.65299070982266,-1.5707963267948966 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark05(-1.566242904608655,-1.5707963267948966,145.19718682217106 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark05(-1.5662599890415512,-47.25992763293256,19.87520759880091 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark05(-1.5663945968082804,-78.56065939712099,0.0 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark05(-1.5666980909148405,-84.84106044049864,0 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark05(-1.5667599404360533,-1.5707963267948983,-78.17628012921801 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark05(-1.5667823844966335,-23.423498811572504,-1.5707963267948912 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark05(-1.5668143057551451,-0.5367438354564852,1.9467177638862437E-208 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark05(-1.567120537927599,-0.25113990873886033,0.01697324171721732 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark05(-1.5672618112472083,-53.97546530053517,-9.916590115255717 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark05(-1.5672780704092568,-78.84606941772935,-85.01050865765129 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark05(-1.5673688351953268,-0.2617357260917165,-7.853996298573338 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark05(-1.567495691824527,-16.4456095110542,-56.32600566636312 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark05(-1.5676019994684316,-1.5701247131743508,-26.170164630245825 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark05(-1.5676160516463034,4.1415926537038885,-1.5707963267948966 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark05(-1.5676308300210737,-48.47350714669963,-94.22619678803642 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark05(-1.5677012419619025,-0.4417245854240684,73.53393328452789 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark05(-1.567726643162788,-1.5707963267948966,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark05(-15.679479426391111,51.81624056050157,-76.44448131980354 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark05(-1.56812691782938,-1.224085284322185,-1.5707963267948966 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark05(-1.5681511598326763,-0.01053068065936505,-13.462822841734166 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark05(-1.568174378436722,-0.30343481883352297,-1.5707963267948966 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark05(-1.5683130789823045,-72.97412808380734,6.2831857850633845 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark05(-1.568674608687747,-1.2188389211724981,355.2279642895314 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark05(-1.5688564372421914,-41.66753655586503,9.769598533510191 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark05(-1.5690128286707599,-1.5707963267788787,-100.0 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark05(-1.5690884095781192,-3.1415928935711994,90.54238691281797 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark05(-1.5691129684581995,-0.25617326511179495,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark05(-1.5692724261604667,-9.526110932513395,6.287099924984485 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark05(-1.5692907840845962,28.703537555513677,96.58994684764912 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark05(-1.5694985364562886,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark05(-1.5695771526707143,-42.21323774737907,0.0 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark05(-1.5696457729197733,-0.2676694069663813,0.0 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark05(-1.5696869920078926,-0.11712036399379519,1.5707963271774001 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark05(-1.5697246430289358,-1.5707963267948966,-16.411847835324945 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark05(-1.5700742576183697,-1.5707963267948966,44.48811847418874 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark05(-1.5701059370862773,-0.7264382411684474,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark05(-1.5701857803539474,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark05(-1.570256667718879,-1.5707963267948983,29.18546582431759 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark05(-1.5702589853311417,-0.48655176551994483,0.0 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark05(-1.5702807171944622,-1.5707963267948961,-1.5707963267948966 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark05(-1.5703639732320454,-0.2608404819130211,55.367949340996375 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark05(-1.5704526120204023,-1.5707963267948966,20.42035224944318 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707645546796796,-4.564923024043036E-4,69.08910723375942 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark05(-1.570764854047506,-97.63937226329114,1.5707963267948966 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707870339484797,-7.087664018217332E-7,-94.29414303998902 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark05(-1.570794191901343,-0.6618246599120118,49.703069450664145 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707948552052553,-1.5707963322714116,-183.37402029874244 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707950904204098,-47.12395083900322,1.5707963267948966 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079570569363,-1.5707963272574887,-140.46371980584115 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962602777574,-1.5542243056849498,-18.849754387019587 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962779498381,-72.43316808517173,-44.32752985529521 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962806708389,-1.290224085479013,-0.624083133375116 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963116489065,-0.8440353031081336,83.39392599003483 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796314126522,-1.0842021724855044E-19,-7.843264924315855E-4 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796315744246,-6.15380220733835E-8,94.24775483554451 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796317828185,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079631856503,-0.5897056156529573,-91.65993179575383 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963204707738,-1.5301346787902854,66.5689938035743 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796321230516,-1.5707963267948966,95.2537748444814 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963228148778,-15.763144100655976,-0.013924289856947191 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963229484503,-1.5707963267948957,77.40715998197507 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963230763702,-22.417397719652683,54.98410866043713 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963231401676,-15.814735419561382,-10.797292611991395 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963237380969,-1.5707963267948966,19.109691175832317 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963242725935,-5.837137104938634E-7,50.23480382396923 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796325117865,-1.5707963267948966,-91.97957239852266 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963251415689,-79.01351301479274,-12.967844293519477 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963252115282,-66.7261336958421,-56.7414374218245 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963255405244,-10.36200829009253,44.14382222678301 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796325578245,-1.406184288472656,-111.7690735808582 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963255989026,-35.74608583225121,100.0 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963256152506,-1.5707963267948966,-55.00343285748944 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963256497959,-0.402299133970649,55.46920818615635 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963256698465,-0.004438998027173839,26.71157002098956 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963256736042,-0.06919463606052334,-110.08328846773789 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963256913096,-0.9347979910665841,60.77127029378339 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963257127104,-17.122900214417083,-10.402325566647056 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963257223359,-91.93504400947779,-1.5707963267948966 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796325760198,-0.45362102381551195,47.83805184708752 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963257670114,-180.28383875030653,2.1309068401313005 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963257766977,-0.06065517566728818,-1.5707963267948966 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963259402395,-217.03006537405506,-20.458327762149587 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963259593856,-0.29113049314898265,-3.8317179166504047 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963259872286,-1.5620147400379627,-0.03765658704529123 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963260382025,-0.03525564465496782,1.5707963267948966 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326038328,-28.643299953728143,-91.49760523002945 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963260384465,-1.5707963267948966,83.25241872674594 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963260411606,-66.99234123904589,-42.735364614636744 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963260457936,-72.73498424038993,-119.02442231135734 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963260597473,-1.5707963267948761,-1.5707963267948983 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963261121898,-1.5707963267948972,-0.5225268453362637 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963261335487,-1.5707963267948983,1.5707963267949054 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963261518716,-53.62163631318286,-1.5707963267948966 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326152617,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963261844125,-41.67691427342815,-23.483648656879758 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963262020002,-1.5193178161937417,1.5707963267948966 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963262201081,-1.4400121681598412,6.762833276642127 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963262495288,-1.5707963267948983,35.35721935584145 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963262946245,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326303484,-1.5707963267948968,-77.00141612122951 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963263339082,-0.9798956340142505,-1.5707963267948983 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265061102,-1.2801925198186697,-100.0 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326507482,-0.09019042564611485,23.350470255625737 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326510551,-28.353372576712488,-0.4129821328284038 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265138007,-0.0023461942120142076,45.46988099146946 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326520519,-1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265282243,-35.85394229143055,20.636709416733467 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326534322,-78.8636373533182,-64.59779694011306 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326535795,-0.9947823778860143,0.0 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265385023,-3.3126568713572606,13.25453288523184 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265408196,-0.484539695097829,1.5707963267948966 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326549985,-0.9185561530724593,84.0941797391299 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326551707,-1.5707963267948966,29.495805360089115 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265632903,-73.25318962450123,48.284180072233916 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265677254,-35.035867752922876,126.34646151463402 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326568336,-0.04354343432188412,100.0 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326568522,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265696974,-1.2855377301306243,-9.412300609386993 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265725122,-1.5707963267948966,90.5582516610687 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265748432,-1.5707963267948966,-76.981673055988 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265778824,-47.56606506198173,78.05816944297449 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265781306,-0.41155394525315053,-6.839205422067577 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265792955,-0.7571958046740229,-84.80730735693132 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265802398,-1.2435383843629682,7.849172141337302 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326581187,-41.79340505362862,-51.45217218968244 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265814366,-35.33007966575255,0.0 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326581473,-84.85030137997553,0.0 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326582246,-0.07092612568423542,-8.33163735884898 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265825156,-1.5707963267948983,-89.32499334031758 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265842624,-1.5707963267948966,17.3569542863576 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265866791,-98.0595947194983,182.05876456508193 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265875258,-34.74712831195024,-0.9752666387050555 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326589783,-66.31896561072263,100.0 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265949185,-0.2782737202074681,24.722878235395584 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265963072,-1.5707963267948963,-62.68964726354989 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265990337,-0.10832688046722144,0.6299877025834362 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632661111,-1.5707963267948983,-52.77545326150429 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266314326,-1.5707963267948966,51.066562735198076 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266343066,-61.1087992457428,91.75956558047176 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266414755,-1.5707963267948974,11.817156352648412 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266502798,-16.021575064848577,-198.89009463619985 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266581852,-0.10244165779296407,-139.72078548420413 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266597778,-1.5470070727916965,-67.37048405970694 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266603933,-1.5707963267948966,-66.71043575336502 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266626375,-1.5707963267948972,-32.61890058193003 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326678779,-1.5707963267948966,-7.250810928007503 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266834184,-7.105427357601002E-15,-45.039603675720286 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266949578,-42.14305739472728,-21.77598346095361 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267006495,-1.5707963267948966,-75.81109804796594 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267084695,-42.36242471441432,48.76430355817612 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267137732,-97.69187442449498,-46.7480127752416 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267198126,-1.5157327207193863,-33.32267461516073 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267224734,-1.5707963267948948,-100.0 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267283214,-1.5707963267948966,77.3994634118007 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267308525,-98.2589883140081,0.3686467448390219 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267327933,-54.78847810270649,1.5707963267948966 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267329244,-0.5264457747033373,1.5707963267949054 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267348561,-0.1767213799207771,58.5121212764343 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267487368,-48.39651526104195,9.817093456629214 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267502574,-1.475002164826573,7.531849346110633 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267508593,-15.852355785864418,-1.5707963267948963 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326752582,-1.5707963267948966,-1.570796326794893 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267559621,-78.67367566141857,-84.97695635203026 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267615312,-1.5707963267948966,-30.618727709242037 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267805845,-1.5707963267948966,-1.5707963267948988 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267810763,-0.7942760505667011,-56.489014320812494 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267812786,-72.33912562141575,-49.842869487139325 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267854441,-9.991812869050873,-27.797894505359466 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267859355,-22.608231887532334,-1.5707963267948966 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326789125,-15.752122980119644,34.716844300264924 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267894316,-0.4100368049403811,8.259097081170722 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267901701,-0.9465386396223334,169.25337524789762 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267907907,-1.3643462942606115,100.0 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267910716,-0.8304031601606545,-14.02962674778774 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267912401,-1.5707963267948966,-56.4971536028217 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267919012,-60.52140187572725,-1.5707963267948966 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326792923,-54.567535060748476,99.60028781584978 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267930953,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267931198,-1.5707963267948966,64.39458294881298 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326793493,-1.5707963267948966,21.454705817666024 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267935299,-1.5707963267948966,34.83904835568823 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267937288,-172.86337491388076,-53.763519655197335 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267937348,-1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267938312,-1.321212568407739,-35.98959878608106 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267938885,-36.12657665076151,-64.7969111077665 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326793889,-10.47775574078874,-42.16860355738287 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267940066,-135.7267039642779,66.48086201825825 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267941822,-54.936746038854096,-45.30261963873249 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267943121,-1.5707963267948966,6.959235111790065 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267943899,-0.1280285671214488,0.9655560511589016 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267944873,-1.5707963267948966,-98.2956291356044 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267944969,-0.42482554963443775,-9.623110227138781 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267945355,-1.5707963267948966,92.47276503484052 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267945395,-61.029469638717046,0.0 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267945444,-1.4826247221947697,1.5707963267948966 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267945553,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794563,-0.46100193858674354,87.53338689561232 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267945844,-40.98085059822208,1.5707963267948966 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946154,-1.0277136006615715,-64.30684289242609 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946206,-1.3508068024458167E-225,0.0 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946297,-0.47566877387351475,61.26105674500097 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946559,-97.4401288773714,11.176275884363164 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946645,-1.5707963267948966,-8.385893236192661 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947207,-92.6479181566723,0 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947314,-72.79995386537723,-27.021652060553194 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947436,-1.1463195826325678,-1.5707963267948957 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947527,-15.929240099831325,100.0 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947578,-1.5707963267948966,-42.86270204472451 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947633,-98.29951762414784,87.90866017811527 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947664,-10.208718841482732,1.2256595079486625 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947704,-98.68461035979648,-38.73990253679711 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794774,-0.4844230319089373,-56.37653178182608 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794786,-1.5707963267948957,20.535392466874463 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947946,-53.63975985755533,-78.37722984801339 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947989,-0.7436494429313147,85.5253353746249 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947995,-1.5707963267948966,-50.257144305827765 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794813,-0.14665280958760718,39.012394215129376 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948137,-0.03890160636788947,53.6792707528231 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948142,-5.551115123125783E-17,-57.61935585387076 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948146,-0.23574722181950414,20.25266838779815 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948202,-48.4950278512501,135.67343004901883 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948237,-61.158691731546895,-21.49617218582121 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794827,-1.5707963267948966,-4.47400360616321 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794831,-1.5707963267948966,6.2988107610121915 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948402,-1.5707963267948963,66.06526812531494 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948404,-36.05947034539578,-1.5707963267948966 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948415,-1.5707963267948966,-9.810208356538194 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948415,-1.5707963267948983,78.45265034226762 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948415,-1.9721522630525295E-31,18.947720436177818 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948444,-1.5707963267948966,-30.70964529416023 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948466,-22.480034840561878,1.5707963267948966 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948484,-0.03101799961937246,90.79565928096156 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948508,-1.4280656214233587,-86.06210569697099 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948517,-53.42901580374655,-1.5707963267948966 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948593,-98.51368720791962,-27.76243354702079 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948608,-1.5707963267948966,-60.99896547817938 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794861,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948628,-1.5707963267948966,-87.64477081376815 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948628,-66.0607900017232,1.5707963267948966 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948635,-15.964492807114045,42.13019817669825 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948641,-1.3903315285412747,-0.5093481378476137 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794866,-2.220446049250313E-16,-51.81311178424522 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948664,-1.5707963267948912,6.393250617422154 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948664,-1.5707963267948966,9.868166267372718 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948664,-54.11058762597838,-1.4978726624105896 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948692,-41.446873358945744,82.22633516814722 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948704,-1.5707963267948966,-83.23868401063292 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794872,-1.5707963267948966,-1.2550147636443851 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948735,-1.3896692189859774,24.220728956930618 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948735,-60.92612042939575,-45.53984789627359 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794874,-3.4141107279069445,-95.37457912792325 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948746,-47.514551181231965,-83.21650460017679 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948761,-8.881784197001252E-16,0.0 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948764,-1.5707963267948948,17.203954423687293 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948764,-73.08196081927008,-10.409620547819983 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-4.012513378414762,-35.09161939095755 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-72.52898780406278,-49.770162961833535 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-78.6748790845543,122.25455828552461 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-9.608885970084806,-9.308940901197076 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679487,-84.9745634084314,48.28057062805786 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948788,-1.5707963267948968,12.911571232232788 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948788,-72.47694169216767,1.3229764635028047 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794879,-1.5707963267948966,-77.61780538180426 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948801,-1.5707963267948966,-51.00243945686675 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948806,-1.5707963267948966,-11.283928235105378 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794881,-174.04650587961865,-88.00505196671374 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794881,-54.797370283844316,-75.16276907335441 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948828,-0.4426021991783123,8.173168258117679 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948828,-111.17211141647168,-44.6138121286033 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948832,-10.35270148937856,-528.4196453221406 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-1.3411508299264974,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-1.5707963267948963,-86.28576568494415 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-1.5707963267948966,1.5411551412035607 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-1.5707963267948966,-56.2226943299765 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-1.5707963267948966,57.40299425681144 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-1.5707963267948966,-69.4832819301366 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-1.5707963267948966,89.6846429816132 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-15.985737669524937,1.5707963267948966 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-1.7763568394002505E-15,16.30063995731353 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-41.399829001174496,-86.23223023679047 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-53.96957882282718,-54.925086647060304 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-78.83207105559492,14.68075526732207 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-9.533178100015522,-26.732136643882043 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948852,-0.9233258347706119,-83.43708168105482 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948855,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-1.5618488124888794,1.5707963267948966 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,28.703537555513243,26.10089390224328 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-41.56974085350065,1.5707963267948948 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948883,-1.5707963267948966,-4.712389810073489 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948886,-1.5707963267948912,-10.421036617564397 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948888,28.703537556311087,-4.758588598293242 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948888,-92.31420281646629,-50.19476113413046 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794889,-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794889,-1.5707963267948963,-8.34351181746404 ) ;
  }

  @Test
  public void test3992() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948895,-1.5707963267948966,93.44750296685879 ) ;
  }

  @Test
  public void test3993() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948895,-73.23976036082912,-4.712388987284829 ) ;
  }

  @Test
  public void test3994() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948901,-1.5707963267948966,3.2346858142056586E-15 ) ;
  }

  @Test
  public void test3995() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948903,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3996() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948903,-1.5707963267948966,-70.53827678133064 ) ;
  }

  @Test
  public void test3997() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948903,-42.216822485865045,-1.5707963267948966 ) ;
  }

  @Test
  public void test3998() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.005032264752624749,27.12633779094395 ) ;
  }

  @Test
  public void test3999() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.029401985215690787,1.0773073966297173 ) ;
  }

  @Test
  public void test4000() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.04295742719111065,95.05563136956525 ) ;
  }

  @Test
  public void test4001() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.0882991401644837,79.4738683275994 ) ;
  }

  @Test
  public void test4002() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.13820774790801066,-65.11690138975761 ) ;
  }

  @Test
  public void test4003() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.21848014582031006,31.51265963527906 ) ;
  }

  @Test
  public void test4004() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.29130853145054897,-9.645165078272754 ) ;
  }

  @Test
  public void test4005() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.3592053947760214,1.5707963267948968 ) ;
  }

  @Test
  public void test4006() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.36514014821638874,-88.64940295881895 ) ;
  }

  @Test
  public void test4007() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.39201018227722273,-3.7703253198890936 ) ;
  }

  @Test
  public void test4008() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.3942951504060713,-7.853981633974484 ) ;
  }

  @Test
  public void test4009() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.45968014762763687,-22.491538606537134 ) ;
  }

  @Test
  public void test4010() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.4827526893749656,-63.93928441246728 ) ;
  }

  @Test
  public void test4011() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.5707336712011034,-76.86938018730041 ) ;
  }

  @Test
  public void test4012() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.8199745518810748,6.283186267085589 ) ;
  }

  @Test
  public void test4013() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.8790288330221152,48.29213941097353 ) ;
  }

  @Test
  public void test4014() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.9004578125908457,56.01441681781375 ) ;
  }

  @Test
  public void test4015() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.0005369944948512,-40.5063342268106 ) ;
  }

  @Test
  public void test4016() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.036293234220302,1.5707963267948968 ) ;
  }

  @Test
  public void test4017() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.117206128632636,56.96295931045721 ) ;
  }

  @Test
  public void test4018() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.265345743246854,-65.4787053397357 ) ;
  }

  @Test
  public void test4019() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.0442866032724436,-1.5707963267948966 ) ;
  }

  @Test
  public void test4020() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.746476740500924,-3.3872058136597043 ) ;
  }

  @Test
  public void test4021() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-122.6230031260151,-67.77749535452675 ) ;
  }

  @Test
  public void test4022() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-123.07434966627036,117.6249162963991 ) ;
  }

  @Test
  public void test4023() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.2325000913984998,31.41592653589797 ) ;
  }

  @Test
  public void test4024() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.232505020801721,50.5883818971501 ) ;
  }

  @Test
  public void test4025() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.2909101610875866E-15,-54.298164674941 ) ;
  }

  @Test
  public void test4026() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.311326587250739,-42.7797731061228 ) ;
  }

  @Test
  public void test4027() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.3552527156068805E-20,6.876919073345107 ) ;
  }

  @Test
  public void test4028() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.36152477588179,77.00880783729798 ) ;
  }

  @Test
  public void test4029() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-136.59356327468845,-607.3273814585647 ) ;
  }

  @Test
  public void test4030() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.4016820357124011,-34.61914341879829 ) ;
  }

  @Test
  public void test4031() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.4321192881597527E-17,12.56637044127117 ) ;
  }

  @Test
  public void test4032() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5504934274525262,-28.64602224677403 ) ;
  }

  @Test
  public void test4033() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.570796326794886,-10.89761313509156 ) ;
  }

  @Test
  public void test4034() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948948,1.5707963267948968 ) ;
  }

  @Test
  public void test4035() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948948,55.30810804759656 ) ;
  }

  @Test
  public void test4036() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.570796326794895,2.3892559825113437 ) ;
  }

  @Test
  public void test4037() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948957,72.56072839119295 ) ;
  }

  @Test
  public void test4038() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948961,58.72923363536183 ) ;
  }

  @Test
  public void test4039() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948963,-60.009038318275856 ) ;
  }

  @Test
  public void test4040() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4041() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,14.175834620999382 ) ;
  }

  @Test
  public void test4042() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4043() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test4044() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test4045() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,19.369287749686308 ) ;
  }

  @Test
  public void test4046() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,20.285065486904756 ) ;
  }

  @Test
  public void test4047() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-21.124641806417582 ) ;
  }

  @Test
  public void test4048() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-21.133059216604195 ) ;
  }

  @Test
  public void test4049() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-29.075638751704716 ) ;
  }

  @Test
  public void test4050() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,42.341500208306485 ) ;
  }

  @Test
  public void test4051() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-4.9355158837307067E-178 ) ;
  }

  @Test
  public void test4052() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-54.921171467000086 ) ;
  }

  @Test
  public void test4053() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,63.03750904773513 ) ;
  }

  @Test
  public void test4054() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,71.4340404036036 ) ;
  }

  @Test
  public void test4055() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-75.71136182291119 ) ;
  }

  @Test
  public void test4056() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,76.21961573550215 ) ;
  }

  @Test
  public void test4057() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,79.71964746661479 ) ;
  }

  @Test
  public void test4058() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,84.30355065000495 ) ;
  }

  @Test
  public void test4059() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,84.39220015921549 ) ;
  }

  @Test
  public void test4060() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-91.43664730203203 ) ;
  }

  @Test
  public void test4061() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,98.60667564103487 ) ;
  }

  @Test
  public void test4062() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-98.96879508881875 ) ;
  }

  @Test
  public void test4063() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948983,-1.5707963267948983 ) ;
  }

  @Test
  public void test4064() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948983,-20.63024816479225 ) ;
  }

  @Test
  public void test4065() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948983,-39.045913302408565 ) ;
  }

  @Test
  public void test4066() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-15.811280390730857,0.0 ) ;
  }

  @Test
  public void test4067() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-15.89598379809056,-83.27823452429139 ) ;
  }

  @Test
  public void test4068() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.073610289340536,82.31851256601362 ) ;
  }

  @Test
  public void test4069() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.130882342707206,85.88404374633203 ) ;
  }

  @Test
  public void test4070() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.158657963012587,45.03078151181869 ) ;
  }

  @Test
  public void test4071() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.171740179772215,-96.44191234181082 ) ;
  }

  @Test
  public void test4072() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.19785209678348,9.668412705782714 ) ;
  }

  @Test
  public void test4073() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.417243024348224,-0.10730070661857381 ) ;
  }

  @Test
  public void test4074() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-167.09481172382442,-15.974867600056314 ) ;
  }

  @Test
  public void test4075() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-17.034125833477535,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test4076() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-180.15455925510386,-141.03097905966416 ) ;
  }

  @Test
  public void test4077() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.804796498744432E-4,9.424778138494236 ) ;
  }

  @Test
  public void test4078() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-191.785271065455,-8.774023898703959 ) ;
  }

  @Test
  public void test4079() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-192.5588462442568,21.556021446602262 ) ;
  }

  @Test
  public void test4080() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-2.220446049250313E-16,13.113997722906063 ) ;
  }

  @Test
  public void test4081() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-22.509073981451607,-54.77751337013182 ) ;
  }

  @Test
  public void test4082() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-28.27651274232788,1.5707963267948983 ) ;
  }

  @Test
  public void test4083() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-28.36790856745025,-1.5707963267948966 ) ;
  }

  @Test
  public void test4084() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-28.68722262167647,-225.03834620727852 ) ;
  }

  @Test
  public void test4085() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-29.837480448548284,-1.5707963267948966 ) ;
  }

  @Test
  public void test4086() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.1416161707553476,35.61676185425095 ) ;
  }

  @Test
  public void test4087() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.1494051579295532,-129.03467735473902 ) ;
  }

  @Test
  public void test4088() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.2867232628631413,-434.56036948391977 ) ;
  }

  @Test
  public void test4089() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.82036783213688,18.941486236161992 ) ;
  }

  @Test
  public void test4090() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.839123304247984,-0.15588857621948193 ) ;
  }

  @Test
  public void test4091() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.90369221014017,-1.5707963267948966 ) ;
  }

  @Test
  public void test4092() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.94181194554669,6.284161869690897 ) ;
  }

  @Test
  public void test4093() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.29493201798684,86.09141116665276 ) ;
  }

  @Test
  public void test4094() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.437436559434175,-87.46181449071025 ) ;
  }

  @Test
  public void test4095() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.552713678800501E-15,-74.34456276747 ) ;
  }

  @Test
  public void test4096() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.56790644499401,8.2973674145222 ) ;
  }

  @Test
  public void test4097() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.6066717928543,-4.394392827267794 ) ;
  }

  @Test
  public void test4098() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.564302426243131,-0.7785338296272526 ) ;
  }

  @Test
  public void test4099() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.7785967212713,-9.871031767461413E-178 ) ;
  }

  @Test
  public void test4100() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.81488731514449,27.841410856086053 ) ;
  }

  @Test
  public void test4101() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.582923503637531,46.39559188229663 ) ;
  }

  @Test
  public void test4102() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.85372206753655,43.00444207410039 ) ;
  }

  @Test
  public void test4103() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.94155531358747,-24.967088705713692 ) ;
  }

  @Test
  public void test4104() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.99825515622183,-8.183269565596717 ) ;
  }

  @Test
  public void test4105() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-36.05408155732235,55.293840922200786 ) ;
  }

  @Test
  public void test4106() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.7032678738808187,-27.972365475393673 ) ;
  }

  @Test
  public void test4107() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.9680767284347134,1.5707963267948983 ) ;
  }

  @Test
  public void test4108() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.9968073550117253,-1.5707932191083471 ) ;
  }

  @Test
  public void test4109() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.08211770689077,10.79136004297121 ) ;
  }

  @Test
  public void test4110() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.22997031811968,-1.5707963267948968 ) ;
  }

  @Test
  public void test4111() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,4.141592653589803,-38.60079896521234 ) ;
  }

  @Test
  public void test4112() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.48213992250935,44.47130141719006 ) ;
  }

  @Test
  public void test4113() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.84299653384886,-143.50559327066048 ) ;
  }

  @Test
  public void test4114() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-42.02024961351525,-3.1416231740929526 ) ;
  }

  @Test
  public void test4115() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-42.34543729965654,-0.13155806912348078 ) ;
  }

  @Test
  public void test4116() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-425.6853818394709,104.10693242812211 ) ;
  }

  @Test
  public void test4117() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-444.50573686496875,-191.85577886802045 ) ;
  }

  @Test
  public void test4118() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-47.27130558425334,14.935466517060917 ) ;
  }

  @Test
  public void test4119() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-47.272083429973264,-47.00300666829608 ) ;
  }

  @Test
  public void test4120() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-47.360196210421925,1.5707963267948966 ) ;
  }

  @Test
  public void test4121() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-47.43884033652781,-0.20435083328748127 ) ;
  }

  @Test
  public void test4122() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-47.67530510987178,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test4123() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.13029997935667,68.66816662212159 ) ;
  }

  @Test
  public void test4124() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.17338886341852,78.87429291938827 ) ;
  }

  @Test
  public void test4125() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.43119632252784,-126.69886336575337 ) ;
  }

  @Test
  public void test4126() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.438316820254144,-27.78819159192561 ) ;
  }

  @Test
  public void test4127() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.482551236311444,0.06427981387641385 ) ;
  }

  @Test
  public void test4128() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.50326188156571,18.893524235473105 ) ;
  }

  @Test
  public void test4129() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.562738810268996,-68.48127997841964 ) ;
  }

  @Test
  public void test4130() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.71008013292489,-1.5707963267948966 ) ;
  }

  @Test
  public void test4131() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.85647187126188,-41.77694232882966 ) ;
  }

  @Test
  public void test4132() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.26070838405133,-0.4226757307286133 ) ;
  }

  @Test
  public void test4133() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.49373080956831,-1034.9940904597265 ) ;
  }

  @Test
  public void test4134() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.573744972191434,-1.5707963267948966 ) ;
  }

  @Test
  public void test4135() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.62121004948612,19.988719663255367 ) ;
  }

  @Test
  public void test4136() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.895426233397075,-38.473707771880115 ) ;
  }

  @Test
  public void test4137() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-59.990533746983274,-1.5707963267948963 ) ;
  }

  @Test
  public void test4138() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.70072727906219,-16.719621311770943 ) ;
  }

  @Test
  public void test4139() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.924620819808474,65.60126758151952 ) ;
  }

  @Test
  public void test4140() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-61.01741835553383,-46.682581422246884 ) ;
  }

  @Test
  public void test4141() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-61.075904428944085,1.0643771554689643 ) ;
  }

  @Test
  public void test4142() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-65.99929813041184,138.77363334104243 ) ;
  }

  @Test
  public void test4143() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.04441834923745,0.0 ) ;
  }

  @Test
  public void test4144() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.0760264124979,-57.20900479739731 ) ;
  }

  @Test
  public void test4145() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.24831728722927,94.92845933256748 ) ;
  }

  @Test
  public void test4146() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.28942175383253,67.49481237158145 ) ;
  }

  @Test
  public void test4147() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.36681548374868,-18.143444831851212 ) ;
  }

  @Test
  public void test4148() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.39742956235762,1.5707963267948966 ) ;
  }

  @Test
  public void test4149() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.42113454736626,-41.021570065505486 ) ;
  }

  @Test
  public void test4150() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.52690441092736,1.5707963267948966 ) ;
  }

  @Test
  public void test4151() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.57958339008256,-8.375274679697691 ) ;
  }

  @Test
  public void test4152() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.74847212518091,128.4068207008666 ) ;
  }

  @Test
  public void test4153() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.77011399960367,1.5707963267948966 ) ;
  }

  @Test
  public void test4154() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.39754672337408,-1.6401064715739963E-142 ) ;
  }

  @Test
  public void test4155() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.46723222107936,8.351228937299354 ) ;
  }

  @Test
  public void test4156() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.73174575300195,-80.01332512468468 ) ;
  }

  @Test
  public void test4157() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.92122634085139,0.0 ) ;
  }

  @Test
  public void test4158() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.06279012218573,57.33540996258381 ) ;
  }

  @Test
  public void test4159() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.15254945777367,-34.232715445541444 ) ;
  }

  @Test
  public void test4160() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.37402198489639,-79.37660279014509 ) ;
  }

  @Test
  public void test4161() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.37728023685375,-49.801932252306486 ) ;
  }

  @Test
  public void test4162() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-78.74823499349715,59.69026041962411 ) ;
  }

  @Test
  public void test4163() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-78.92345466768873,-76.21372037494766 ) ;
  }

  @Test
  public void test4164() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-84.89040492531632,-54.03229118944155 ) ;
  }

  @Test
  public void test4165() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-86.30890521097713,-1.5707963267948966 ) ;
  }

  @Test
  public void test4166() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-91.35541665862002,0 ) ;
  }

  @Test
  public void test4167() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-91.73311961048071,-84.93655924630198 ) ;
  }

  @Test
  public void test4168() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-9.582420747649792,21.454615370096707 ) ;
  }

  @Test
  public void test4169() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-9.639877442459536,-62.01581779769192 ) ;
  }

  @Test
  public void test4170() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-9.650595158681668,42.03820381280369 ) ;
  }

  @Test
  public void test4171() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-97.66610088901894,181.98370135687236 ) ;
  }

  @Test
  public void test4172() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-97.69400148561118,-52.28005765982056 ) ;
  }

  @Test
  public void test4173() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-97.729234522194,52.91038474891937 ) ;
  }

  @Test
  public void test4174() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-97.9644219680186,-100.0 ) ;
  }

  @Test
  public void test4175() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-98.2507841148765,3.3087224502121107E-24 ) ;
  }

  @Test
  public void test4176() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-9.843601617864081,-1.5707963267948968 ) ;
  }

  @Test
  public void test4177() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-98.62394226007734,-84.5005319653209 ) ;
  }

  @Test
  public void test4178() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-98.67332803959859,-70.29081135624259 ) ;
  }

  @Test
  public void test4179() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-98.74424195712012,-8.103981633975103 ) ;
  }

  @Test
  public void test4180() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794891,-48.207840618188634,27.726490990850273 ) ;
  }

  @Test
  public void test4181() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948917,-35.12926973411244,-72.73338610572543 ) ;
  }

  @Test
  public void test4182() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948921,-0.48786324042037404,-1.5707963267948966 ) ;
  }

  @Test
  public void test4183() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794892,-1.5707963267948966,90.60566810444658 ) ;
  }

  @Test
  public void test4184() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948923,-1.5707963267948966,77.32917624495511 ) ;
  }

  @Test
  public void test4185() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948928,-86.01672785440495,-16.298155807199795 ) ;
  }

  @Test
  public void test4186() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-0.27971489561684815,-40.74897490460223 ) ;
  }

  @Test
  public void test4187() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-0.7886500202799347,73.4978430422297 ) ;
  }

  @Test
  public void test4188() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-1.402904288984315,-49.496930342975396 ) ;
  }

  @Test
  public void test4189() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-1.4766957339577904,0.0685328971973258 ) ;
  }

  @Test
  public void test4190() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-1.5379208193500062,20.64602922813259 ) ;
  }

  @Test
  public void test4191() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test4192() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-1.5707963267948966,-7.896825413969131E-177 ) ;
  }

  @Test
  public void test4193() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-1.5707963267948983,19.29045057609602 ) ;
  }

  @Test
  public void test4194() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948932,-1.5707963267948966,-50.26580135870253 ) ;
  }

  @Test
  public void test4195() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-35.47763658809767,-20.374356785355 ) ;
  }

  @Test
  public void test4196() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948934,-78.59147257009636,-21.475511398344317 ) ;
  }

  @Test
  public void test4197() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-60.889900794517644,-98.47876042410233 ) ;
  }

  @Test
  public void test4198() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794893,-66.04370888652275,0.0 ) ;
  }

  @Test
  public void test4199() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948941,-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test4200() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948941,-1.5707963267948966,-4.767034852787614 ) ;
  }

  @Test
  public void test4201() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948941,-1.5707963267948966,-51.690571774707905 ) ;
  }

  @Test
  public void test4202() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794894,-1.3611730232057937,-25.506066295545203 ) ;
  }

  @Test
  public void test4203() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948946,-1.3838855635542293,-25.969155680857277 ) ;
  }

  @Test
  public void test4204() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948946,-1.5707963267948966,-2319.4919625187495 ) ;
  }

  @Test
  public void test4205() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948946,-1.5707963267948966,-3.8839677137469266 ) ;
  }

  @Test
  public void test4206() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948946,-23.520145190076573,-7.896825413969131E-177 ) ;
  }

  @Test
  public void test4207() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.05958324694186696,-97.16194756107078 ) ;
  }

  @Test
  public void test4208() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.06735279763417461,44.53533275265739 ) ;
  }

  @Test
  public void test4209() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.08658207329956195,34.291795825249835 ) ;
  }

  @Test
  public void test4210() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.26869083424141316,63.89667137646192 ) ;
  }

  @Test
  public void test4211() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.2738960409949851,-78.88133110500483 ) ;
  }

  @Test
  public void test4212() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.28403336655991823,-82.21111188452852 ) ;
  }

  @Test
  public void test4213() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.28951864593834437,-29.076805476110042 ) ;
  }

  @Test
  public void test4214() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.2967801157107786,0.0 ) ;
  }

  @Test
  public void test4215() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.2989059586769527,19.054880821241227 ) ;
  }

  @Test
  public void test4216() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.330571096736787,-9.891100830941184 ) ;
  }

  @Test
  public void test4217() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.4867894418807754,66.15506696128307 ) ;
  }

  @Test
  public void test4218() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.6245579760599624,85.46228543863707 ) ;
  }

  @Test
  public void test4219() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.7499888082984266,1.554233485559011 ) ;
  }

  @Test
  public void test4220() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.7772579112264499,-45.2201972891309 ) ;
  }

  @Test
  public void test4221() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.7796132194113857,24.309066128944636 ) ;
  }

  @Test
  public void test4222() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.8985646634739566,-78.2216559088704 ) ;
  }

  @Test
  public void test4223() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.9196992048748656,27.795820176683133 ) ;
  }

  @Test
  public void test4224() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-0.9374819453752239,61.13262563497882 ) ;
  }

  @Test
  public void test4225() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-100.0,0 ) ;
  }

  @Test
  public void test4226() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,1.0339757656912846E-25,-46.329917752966665 ) ;
  }

  @Test
  public void test4227() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-10.406563436547636,48.33478339085394 ) ;
  }

  @Test
  public void test4228() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-10.605758232421593,-66.31799671787591 ) ;
  }

  @Test
  public void test4229() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.1005414012514505,-9.816472891709417 ) ;
  }

  @Test
  public void test4230() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-110.10323197891458,55.17203367924391 ) ;
  }

  @Test
  public void test4231() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.1102230246251565E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test4232() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.1102230246251565E-16,55.48290830469862 ) ;
  }

  @Test
  public void test4233() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.161056552632221,-17.078218181772684 ) ;
  }

  @Test
  public void test4234() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.295942451657233,74.79929170669145 ) ;
  }

  @Test
  public void test4235() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.302171597216835,66.81841729707853 ) ;
  }

  @Test
  public void test4236() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.3495062236717104,-0.31066264789981585 ) ;
  }

  @Test
  public void test4237() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-136.09060385816707,-50.16221382390718 ) ;
  }

  @Test
  public void test4238() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-142.19824451828782,-9.692347090564947 ) ;
  }

  @Test
  public void test4239() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-154.56866256673095,47.19876054665764 ) ;
  }

  @Test
  public void test4240() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-155.13556462727666,55.275461392304635 ) ;
  }

  @Test
  public void test4241() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948826,-1.5707963267948966 ) ;
  }

  @Test
  public void test4242() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948912,16.355556924055172 ) ;
  }

  @Test
  public void test4243() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948912,28.154812568146525 ) ;
  }

  @Test
  public void test4244() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948912,-92.6769832808989 ) ;
  }

  @Test
  public void test4245() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948912,96.48371301808331 ) ;
  }

  @Test
  public void test4246() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948948,-28.771417693123073 ) ;
  }

  @Test
  public void test4247() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948948,46.91475115912549 ) ;
  }

  @Test
  public void test4248() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948957,65.34302127251331 ) ;
  }

  @Test
  public void test4249() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948963,6.162975822039155E-33 ) ;
  }

  @Test
  public void test4250() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4251() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-0.17150066828273305 ) ;
  }

  @Test
  public void test4252() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test4253() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-1.5507141221090706 ) ;
  }

  @Test
  public void test4254() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,1.5707963267948943 ) ;
  }

  @Test
  public void test4255() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test4256() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4257() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,1.5707963267949019 ) ;
  }

  @Test
  public void test4258() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,16.28646553246815 ) ;
  }

  @Test
  public void test4259() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,210.4295822337765 ) ;
  }

  @Test
  public void test4260() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,2457.1186777835633 ) ;
  }

  @Test
  public void test4261() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-26.139648152656875 ) ;
  }

  @Test
  public void test4262() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-27.770437584480796 ) ;
  }

  @Test
  public void test4263() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,3.4467983629013995E-14 ) ;
  }

  @Test
  public void test4264() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,43.418614660073025 ) ;
  }

  @Test
  public void test4265() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,53.92916811883066 ) ;
  }

  @Test
  public void test4266() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-5.4827098720699325 ) ;
  }

  @Test
  public void test4267() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,56.667846227300004 ) ;
  }

  @Test
  public void test4268() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-76.37784567015709 ) ;
  }

  @Test
  public void test4269() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,78.94468490237212 ) ;
  }

  @Test
  public void test4270() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,8.274089515361105 ) ;
  }

  @Test
  public void test4271() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-84.31673460724231 ) ;
  }

  @Test
  public void test4272() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-84.60789336878047 ) ;
  }

  @Test
  public void test4273() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,89.05822126903108 ) ;
  }

  @Test
  public void test4274() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-91.53166314905259 ) ;
  }

  @Test
  public void test4275() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948966,-98.4737981779762 ) ;
  }

  @Test
  public void test4276() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948968,36.588020497780256 ) ;
  }

  @Test
  public void test4277() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948968,54.324551161129136 ) ;
  }

  @Test
  public void test4278() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948983,10.700722787708798 ) ;
  }

  @Test
  public void test4279() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948983,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test4280() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948983,-1.570796178931304 ) ;
  }

  @Test
  public void test4281() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948983,-18.168118595449386 ) ;
  }

  @Test
  public void test4282() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948983,-50.73699447927942 ) ;
  }

  @Test
  public void test4283() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267948983,-9.151036238134319 ) ;
  }

  @Test
  public void test4284() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-15.707963267949877,1.5707963267948966 ) ;
  }

  @Test
  public void test4285() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-1.5707963267956808,1.5707963267838592 ) ;
  }

  @Test
  public void test4286() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-15.877293542017924,-57.073809192987696 ) ;
  }

  @Test
  public void test4287() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-15.95471599752571,3.7068510487601856 ) ;
  }

  @Test
  public void test4288() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-15.962174957139261,-0.3733208633257612 ) ;
  }

  @Test
  public void test4289() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-16.068228557602595,-32.85332625927782 ) ;
  }

  @Test
  public void test4290() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-2.220446049250313E-16,72.09549345687932 ) ;
  }

  @Test
  public void test4291() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-22.599695248087585,-1.2802442668906582 ) ;
  }

  @Test
  public void test4292() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-28.381851708948552,11.935388731370992 ) ;
  }

  @Test
  public void test4293() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-28.396589444218677,62.15771710818138 ) ;
  }

  @Test
  public void test4294() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-29.82396049670635,-9.98992104585923 ) ;
  }

  @Test
  public void test4295() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.1416232067002614,-48.75626188499673 ) ;
  }

  @Test
  public void test4296() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-33.93053480520337,0 ) ;
  }

  @Test
  public void test4297() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.4317282877691595E-15,49.916434964155755 ) ;
  }

  @Test
  public void test4298() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-34.66593652454544,100.0 ) ;
  }

  @Test
  public void test4299() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.5254309652278017,-86.24380197951113 ) ;
  }

  @Test
  public void test4300() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-35.507498755346,-48.7404547558161 ) ;
  }

  @Test
  public void test4301() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-3.944304526105059E-31,-67.98878238365238 ) ;
  }

  @Test
  public void test4302() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,4.141689461340657,-6.498845823797239 ) ;
  }

  @Test
  public void test4303() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-47.33220274505263,-2374.973935851825 ) ;
  }

  @Test
  public void test4304() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-47.532552289105936,1.5707963267948966 ) ;
  }

  @Test
  public void test4305() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-48.347280872332554,-75.25467050281583 ) ;
  }

  @Test
  public void test4306() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-48.40737923240966,1.5678477471539682 ) ;
  }

  @Test
  public void test4307() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-48.413140991064935,-1306.3140826099464 ) ;
  }

  @Test
  public void test4308() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-48.476915889587346,-34.13878839720475 ) ;
  }

  @Test
  public void test4309() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-48.663736001541146,17.049954035974466 ) ;
  }

  @Test
  public void test4310() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-5.4454965300017225E-15,-1.5707963267948952 ) ;
  }

  @Test
  public void test4311() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-60.77998595098492,-1.5495860267021788 ) ;
  }

  @Test
  public void test4312() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-60.90128467090446,-40.70201836782405 ) ;
  }

  @Test
  public void test4313() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-61.193121503390586,21.484568812708602 ) ;
  }

  @Test
  public void test4314() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-66.04918073014679,0.0 ) ;
  }

  @Test
  public void test4315() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-66.30464867725381,-0.496572505923862 ) ;
  }

  @Test
  public void test4316() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-66.7597771588254,-0.06777603701140933 ) ;
  }

  @Test
  public void test4317() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-66.9111538758763,20.643030316793116 ) ;
  }

  @Test
  public void test4318() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-67.4814071438858,-92.30804934236991 ) ;
  }

  @Test
  public void test4319() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-7.105427357601002E-15,24.775307933793144 ) ;
  }

  @Test
  public void test4320() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-72.50786780122104,-22.02239857534247 ) ;
  }

  @Test
  public void test4321() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-73.36160415577596,-97.71036618694616 ) ;
  }

  @Test
  public void test4322() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-73.72997770742018,-0.10625076923364091 ) ;
  }

  @Test
  public void test4323() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-78.67510540141922,-32.90228105016804 ) ;
  }

  @Test
  public void test4324() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-78.97875961156747,1.5707963267948966 ) ;
  }

  @Test
  public void test4325() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-84.96320898902053,57.04457428667976 ) ;
  }

  @Test
  public void test4326() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-84.99622818269602,31.34093932061134 ) ;
  }

  @Test
  public void test4327() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-92.16439238214917,-47.76721956663079 ) ;
  }

  @Test
  public void test4328() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-9.493389303492538,-646.8622421827823 ) ;
  }

  @Test
  public void test4329() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-9.524125670147626,26.254393483844748 ) ;
  }

  @Test
  public void test4330() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-97.45167947213223,0.0 ) ;
  }

  @Test
  public void test4331() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-97.90895286236514,2415.9061974334004 ) ;
  }

  @Test
  public void test4332() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-97.922953320176,83.44145248535244 ) ;
  }

  @Test
  public void test4333() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-98.45784393329818,-100.0 ) ;
  }

  @Test
  public void test4334() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-9.847522659952124E-16,0.0 ) ;
  }

  @Test
  public void test4335() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-98.80904076187407,-78.2697002579758 ) ;
  }

  @Test
  public void test4336() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-9.955772328833419,-1318.2109873244888 ) ;
  }

  @Test
  public void test4337() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948948,-9.970633899007629,9.45927602220955 ) ;
  }

  @Test
  public void test4338() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794895,-1.5707963267948966,0.2522270654529264 ) ;
  }

  @Test
  public void test4339() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-0.1376020924751953,60.63477811293957 ) ;
  }

  @Test
  public void test4340() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-0.1615311072691993,19.78649920026949 ) ;
  }

  @Test
  public void test4341() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-1.3836995924594993,1.5707963267948983 ) ;
  }

  @Test
  public void test4342() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-1.518733781215158,-6.298953066608811 ) ;
  }

  @Test
  public void test4343() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948952,-1.5707963206116389,55.42330112565758 ) ;
  }

  @Test
  public void test4344() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-1.154825625467953,68.63088342354969 ) ;
  }

  @Test
  public void test4345() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-1.5707963267948966,-0.8586500814829473 ) ;
  }

  @Test
  public void test4346() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948954,-54.8951889391402,100.0 ) ;
  }

  @Test
  public void test4347() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test4348() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.01818559556906975,22.76839466576044 ) ;
  }

  @Test
  public void test4349() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.06845204096317814,57.232495353033585 ) ;
  }

  @Test
  public void test4350() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.2368837367676034,-98.60648653919276 ) ;
  }

  @Test
  public void test4351() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.2578994692622558,-1.5707963267948948 ) ;
  }

  @Test
  public void test4352() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.29224309469098464,-73.28525731794582 ) ;
  }

  @Test
  public void test4353() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.3203485125659026,57.56536546461867 ) ;
  }

  @Test
  public void test4354() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.4252941827358814,-1.5707963267948983 ) ;
  }

  @Test
  public void test4355() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.45245237012999856,64.13837313892343 ) ;
  }

  @Test
  public void test4356() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-0.45377432624964786,100.0 ) ;
  }

  @Test
  public void test4357() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-10.03620609061801,0.0 ) ;
  }

  @Test
  public void test4358() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.047197551196599,48.60510476515399 ) ;
  }

  @Test
  public void test4359() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.4585258248425892,48.37326436408598 ) ;
  }

  @Test
  public void test4360() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963264536942,-54.36114881486695 ) ;
  }

  @Test
  public void test4361() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963265361125,61.0287051287488 ) ;
  }

  @Test
  public void test4362() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948628,-33.79462682163688 ) ;
  }

  @Test
  public void test4363() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.570796326794883,56.29466532333663 ) ;
  }

  @Test
  public void test4364() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948912,-1.5707963267970466 ) ;
  }

  @Test
  public void test4365() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948957,-2.1237775369338716 ) ;
  }

  @Test
  public void test4366() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4367() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,0.9783533651397729 ) ;
  }

  @Test
  public void test4368() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,1.3158216645516296 ) ;
  }

  @Test
  public void test4369() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,146.33022194283353 ) ;
  }

  @Test
  public void test4370() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4371() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-19.01995229532345 ) ;
  }

  @Test
  public void test4372() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-31.836183764130965 ) ;
  }

  @Test
  public void test4373() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,-34.59377969673856 ) ;
  }

  @Test
  public void test4374() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,56.68384130417131 ) ;
  }

  @Test
  public void test4375() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,63.262084463076164 ) ;
  }

  @Test
  public void test4376() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,70.83782591271311 ) ;
  }

  @Test
  public void test4377() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,8.103981633974504 ) ;
  }

  @Test
  public void test4378() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267948966,81.9057455193348 ) ;
  }

  @Test
  public void test4379() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-1.5707963267949019,-12.78012055297814 ) ;
  }

  @Test
  public void test4380() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,22.415430737967576,0 ) ;
  }

  @Test
  public void test4381() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-41.34047422896015,-29.616111104072246 ) ;
  }

  @Test
  public void test4382() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-47.4206479100959,94.86211056699156 ) ;
  }

  @Test
  public void test4383() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-48.13129723706765,1.5707963267948966 ) ;
  }

  @Test
  public void test4384() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-60.81172264578191,1.0840883773411687 ) ;
  }

  @Test
  public void test4385() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-7.055397572396201E-15,34.589740448467374 ) ;
  }

  @Test
  public void test4386() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-73.02219558185786,-1.5707963267948966 ) ;
  }

  @Test
  public void test4387() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-91.33305511383192,-60.866963751302244 ) ;
  }

  @Test
  public void test4388() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-97.49159765684908,-80.0100971893749 ) ;
  }

  @Test
  public void test4389() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-98.63391883147835,3.489478024143626 ) ;
  }

  @Test
  public void test4390() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-98.83793490490417,-22.18282445542583 ) ;
  }

  @Test
  public void test4391() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948957,-9.979325953307283,-7.853981634007076 ) ;
  }

  @Test
  public void test4392() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-0.8191668838678197,1.5707963267948966 ) ;
  }

  @Test
  public void test4393() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-0.9530359924919907,1.5707963267948966 ) ;
  }

  @Test
  public void test4394() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.039127783558493334,51.65347397478038 ) ;
  }

  @Test
  public void test4395() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.0913568660516328,-0.2924467360973503 ) ;
  }

  @Test
  public void test4396() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.11579944665029585,-1.672746010477439 ) ;
  }

  @Test
  public void test4397() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.336228692008654,-1.5707963267948966 ) ;
  }

  @Test
  public void test4398() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.41354013311178406,-7.771455434341579 ) ;
  }

  @Test
  public void test4399() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.6567082742522258,42.576544374658255 ) ;
  }

  @Test
  public void test4400() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.8395103874213072,-69.4606541330171 ) ;
  }

  @Test
  public void test4401() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-0.9069574752570939,-43.887709982411295 ) ;
  }

  @Test
  public void test4402() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-10.065310628339049,0.2355381520388748 ) ;
  }

  @Test
  public void test4403() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.0985251679963148,-32.981658973235355 ) ;
  }

  @Test
  public void test4404() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.2055022791378947,1.5707963267948937 ) ;
  }

  @Test
  public void test4405() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.2184542696551068E-15,-26.708942400716282 ) ;
  }

  @Test
  public void test4406() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963265998675,29.917286917891968 ) ;
  }

  @Test
  public void test4407() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.570796326794877,38.69933845717879 ) ;
  }

  @Test
  public void test4408() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948948,-70.41958440503306 ) ;
  }

  @Test
  public void test4409() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948963,1.5707963199918469 ) ;
  }

  @Test
  public void test4410() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948963,66.38384676816001 ) ;
  }

  @Test
  public void test4411() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test4412() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4413() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-19.259674147356662 ) ;
  }

  @Test
  public void test4414() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,25.891667608613858 ) ;
  }

  @Test
  public void test4415() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-29.54632953748377 ) ;
  }

  @Test
  public void test4416() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,44.13007289702144 ) ;
  }

  @Test
  public void test4417() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,44.360718406283866 ) ;
  }

  @Test
  public void test4418() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948966,-76.31556646999803 ) ;
  }

  @Test
  public void test4419() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-1.5707963267948983,-544.9799940615052 ) ;
  }

  @Test
  public void test4420() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-173.790773428871,-36.15352742816234 ) ;
  }

  @Test
  public void test4421() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-3.266592653598564,1.5707963267948966 ) ;
  }

  @Test
  public void test4422() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-35.51683774446349,-650.266742613173 ) ;
  }

  @Test
  public void test4423() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-48.13947410929684,-47.914990478693895 ) ;
  }

  @Test
  public void test4424() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.4987966769748988,-63.01372779705159 ) ;
  }

  @Test
  public void test4425() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-5.421010862427522E-20,-37.69917415866324 ) ;
  }

  @Test
  public void test4426() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.5707963267947387,-100.0 ) ;
  }

  @Test
  public void test4427() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.5707963267948963,-20.893592415713286 ) ;
  }

  @Test
  public void test4428() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-1.5707963267948966,28.455278583754783 ) ;
  }

  @Test
  public void test4429() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-66.44781135921221,-52.45680300280373 ) ;
  }

  @Test
  public void test4430() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-73.005714939734,46.00879006703087 ) ;
  }

  @Test
  public void test4431() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-73.07539244818261,-61.459405549459476 ) ;
  }

  @Test
  public void test4432() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-84.8757824591386,-91.29950751060588 ) ;
  }

  @Test
  public void test4433() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-84.91951532695619,-79.43160271006924 ) ;
  }

  @Test
  public void test4434() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-97.78038404275885,13.542506077858201 ) ;
  }

  @Test
  public void test4435() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-98.78540298565431,1.4088407314736535E-132 ) ;
  }

  @Test
  public void test4436() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948961,-9.941045842486377,-100.0 ) ;
  }

  @Test
  public void test4437() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.0116392695695108,-1.5707963267948966 ) ;
  }

  @Test
  public void test4438() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.011973542935119173,-53.832911478937135 ) ;
  }

  @Test
  public void test4439() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.022717312662364934,56.870814610616826 ) ;
  }

  @Test
  public void test4440() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.029822343207520068,-68.54170144144756 ) ;
  }

  @Test
  public void test4441() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.03655509184267634,0.0 ) ;
  }

  @Test
  public void test4442() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.04526112560277506,49.71770361641964 ) ;
  }

  @Test
  public void test4443() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.15277575980567015,77.01831063012773 ) ;
  }

  @Test
  public void test4444() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.1813612807359771,-8.646199866248438 ) ;
  }

  @Test
  public void test4445() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.28746074598263316,0.0 ) ;
  }

  @Test
  public void test4446() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.38482164028172955,98.74819710474878 ) ;
  }

  @Test
  public void test4447() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.44589570698729963,1318.3202821901648 ) ;
  }

  @Test
  public void test4448() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.45539889525140204,1.5707963267948966 ) ;
  }

  @Test
  public void test4449() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.5378870575602855,18.634677370629767 ) ;
  }

  @Test
  public void test4450() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.5793466160102547,0.0 ) ;
  }

  @Test
  public void test4451() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.6247756332408487,50.03734174562672 ) ;
  }

  @Test
  public void test4452() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.6481436142915064,-0.18409292493078094 ) ;
  }

  @Test
  public void test4453() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.7212618850484704,-100.0 ) ;
  }

  @Test
  public void test4454() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.7752859882747636,13.279193151970585 ) ;
  }

  @Test
  public void test4455() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.8269562060665977,-5.84138287427966 ) ;
  }

  @Test
  public void test4456() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-0.9562856243288614,54.66358063735595 ) ;
  }

  @Test
  public void test4457() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-10.192499729896397,76.01609911092964 ) ;
  }

  @Test
  public void test4458() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-10.224083228291189,0.0 ) ;
  }

  @Test
  public void test4459() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-10.229686540098891,-88.38316461180729 ) ;
  }

  @Test
  public void test4460() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.027265764517797,-8.260204465328286 ) ;
  }

  @Test
  public void test4461() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,1.0587911840678754E-22,-83.3362525796989 ) ;
  }

  @Test
  public void test4462() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.071429409395181,66.44225878554082 ) ;
  }

  @Test
  public void test4463() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.1451454884344066,-1.5707963267948966 ) ;
  }

  @Test
  public void test4464() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.1995217479624927,-1.5707963267948966 ) ;
  }

  @Test
  public void test4465() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-122.88663763126216,-5.574827189542948E-9 ) ;
  }

  @Test
  public void test4466() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.3235271042423669,0.8135572548677606 ) ;
  }

  @Test
  public void test4467() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.4609054760155296,-50.19073774832859 ) ;
  }

  @Test
  public void test4468() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.4812256840707396,-1.075834560625843 ) ;
  }

  @Test
  public void test4469() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5663028756738417,-30.31852996156006 ) ;
  }

  @Test
  public void test4470() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963265682432,-17.03329609218325 ) ;
  }

  @Test
  public void test4471() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267710041,26.737150231436623 ) ;
  }

  @Test
  public void test4472() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948912,0.05942842961189332 ) ;
  }

  @Test
  public void test4473() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948932,1.5707963267948966 ) ;
  }

  @Test
  public void test4474() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948948,-1.5707963267949054 ) ;
  }

  @Test
  public void test4475() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948948,47.17678377579371 ) ;
  }

  @Test
  public void test4476() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948948,-7.110447961270352E-15 ) ;
  }

  @Test
  public void test4477() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948957,79.58133931815846 ) ;
  }

  @Test
  public void test4478() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948961,19.397082542643897 ) ;
  }

  @Test
  public void test4479() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4480() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,0.7854250331556719 ) ;
  }

  @Test
  public void test4481() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test4482() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test4483() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,14.126745807402344 ) ;
  }

  @Test
  public void test4484() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test4485() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4486() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4487() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-2106.624623017945 ) ;
  }

  @Test
  public void test4488() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,21.949934489005646 ) ;
  }

  @Test
  public void test4489() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,25.273298239212608 ) ;
  }

  @Test
  public void test4490() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,25.45525121530986 ) ;
  }

  @Test
  public void test4491() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-25.717972787838264 ) ;
  }

  @Test
  public void test4492() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,26.938502837514335 ) ;
  }

  @Test
  public void test4493() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-27.996657837451238 ) ;
  }

  @Test
  public void test4494() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,28.215331918539476 ) ;
  }

  @Test
  public void test4495() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-32.416371612625106 ) ;
  }

  @Test
  public void test4496() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,33.742632558523304 ) ;
  }

  @Test
  public void test4497() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,3.4199378354059036 ) ;
  }

  @Test
  public void test4498() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-38.529834382575764 ) ;
  }

  @Test
  public void test4499() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-38.53357945139808 ) ;
  }

  @Test
  public void test4500() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,48.43138309422711 ) ;
  }

  @Test
  public void test4501() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,6.283185792851576 ) ;
  }

  @Test
  public void test4502() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-6.283200717619801 ) ;
  }

  @Test
  public void test4503() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-62.8320170418728 ) ;
  }

  @Test
  public void test4504() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-68.21410980094552 ) ;
  }

  @Test
  public void test4505() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,76.04569356514338 ) ;
  }

  @Test
  public void test4506() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,80.7849424910516 ) ;
  }

  @Test
  public void test4507() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-8.103981646368824 ) ;
  }

  @Test
  public void test4508() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-8.103998614427805 ) ;
  }

  @Test
  public void test4509() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,85.59173444511956 ) ;
  }

  @Test
  public void test4510() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-90.67169150094203 ) ;
  }

  @Test
  public void test4511() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,92.30705306082821 ) ;
  }

  @Test
  public void test4512() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948966,-97.12664895584899 ) ;
  }

  @Test
  public void test4513() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267948968,-80.73751381373174 ) ;
  }

  @Test
  public void test4514() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-1.5707963267949054,11.014867195709764 ) ;
  }

  @Test
  public void test4515() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,16.207963343062904,-32.78137215574244 ) ;
  }

  @Test
  public void test4516() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-16.610662878379237,-60.55367574184255 ) ;
  }

  @Test
  public void test4517() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-16.89078186164408,-0.5521020487889544 ) ;
  }

  @Test
  public void test4518() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-2.220446049250313E-16,0.03353488371186212 ) ;
  }

  @Test
  public void test4519() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-22.4636802423361,27.794686789865786 ) ;
  }

  @Test
  public void test4520() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-28.849233864313256,-0.9209847201440198 ) ;
  }

  @Test
  public void test4521() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-29.073643454253975,-60.77298047057871 ) ;
  }

  @Test
  public void test4522() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.1420809670087877,-10.589766905627117 ) ;
  }

  @Test
  public void test4523() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.173258481850469,14.137984546252934 ) ;
  }

  @Test
  public void test4524() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-3.3509398728558057,-90.0011880260403 ) ;
  }

  @Test
  public void test4525() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-35.13139024484387,70.47093773004869 ) ;
  }

  @Test
  public void test4526() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-35.944001043842675,0.0 ) ;
  }

  @Test
  public void test4527() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-35.961342656738104,-0.028248858870228044 ) ;
  }

  @Test
  public void test4528() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-36.070830927230354,1.1811679773149701 ) ;
  }

  @Test
  public void test4529() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-4.060037496011077,0.037375143140375384 ) ;
  }

  @Test
  public void test4530() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,4.1415926536114975,92.08802398339344 ) ;
  }

  @Test
  public void test4531() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-41.483272612964385,-80.61818547610537 ) ;
  }

  @Test
  public void test4532() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-41.59549274218283,-62.13568893722092 ) ;
  }

  @Test
  public void test4533() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-41.924943078126994,29.049932223538235 ) ;
  }

  @Test
  public void test4534() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-42.401462804363035,-35.59305426263408 ) ;
  }

  @Test
  public void test4535() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-4.3368086899420177E-19,-0.007258262514708277 ) ;
  }

  @Test
  public void test4536() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-4.6042255035611985,-1.5707963267948966 ) ;
  }

  @Test
  public void test4537() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-47.761276659717645,-1.5707963267948966 ) ;
  }

  @Test
  public void test4538() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-48.1467148786961,7.854265973022617 ) ;
  }

  @Test
  public void test4539() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-48.57126767394013,-1.5707963267948966 ) ;
  }

  @Test
  public void test4540() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-48.64349061957389,1.5707963267948966 ) ;
  }

  @Test
  public void test4541() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-5.053215498074303E-16,-60.15435012243673 ) ;
  }

  @Test
  public void test4542() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-53.57645513069049,1.5707963267948983 ) ;
  }

  @Test
  public void test4543() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-53.642763352596226,57.77122449579829 ) ;
  }

  @Test
  public void test4544() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-54.579944085919465,93.52122164654966 ) ;
  }

  @Test
  public void test4545() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-54.9481727944179,1.5707963267948966 ) ;
  }

  @Test
  public void test4546() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-35.90449134649986,39.96571574791559 ) ;
  }

  @Test
  public void test4547() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-59.690262325554954,59.08378363298398 ) ;
  }

  @Test
  public void test4548() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-59.760268016908945,-1.5707963267948966 ) ;
  }

  @Test
  public void test4549() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-60.52959053457864,-0.9853607097715696 ) ;
  }

  @Test
  public void test4550() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-60.72570367605539,13.183554775097164 ) ;
  }

  @Test
  public void test4551() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-60.78918534071333,75.3950323608366 ) ;
  }

  @Test
  public void test4552() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-61.09846820586502,-24.269523030906626 ) ;
  }

  @Test
  public void test4553() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-66.54854908746874,-1.5707963267948983 ) ;
  }

  @Test
  public void test4554() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-66.71334845238351,0.0 ) ;
  }

  @Test
  public void test4555() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-67.08707211120013,-180.68974798486218 ) ;
  }

  @Test
  public void test4556() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-72.49954763984043,6.28332349593067 ) ;
  }

  @Test
  public void test4557() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-72.70226173522241,-0.2813832619980928 ) ;
  }

  @Test
  public void test4558() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-72.85039654838542,-21.34986498065306 ) ;
  }

  @Test
  public void test4559() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-72.97735708032417,-80.10887554344208 ) ;
  }

  @Test
  public void test4560() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-72.99995986001963,-9.950069674878883 ) ;
  }

  @Test
  public void test4561() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-73.02804501660695,-1.5707963243868246 ) ;
  }

  @Test
  public void test4562() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-78.68570859350015,71.1699356156787 ) ;
  }

  @Test
  public void test4563() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-78.95920289401022,55.03600491912459 ) ;
  }

  @Test
  public void test4564() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-85.58250595289779,-0.028334454255094958 ) ;
  }

  @Test
  public void test4565() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-97.72929936993515,0.0 ) ;
  }

  @Test
  public void test4566() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-98.4777198648886,0.0 ) ;
  }

  @Test
  public void test4567() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-98.56735693910169,4.712389065885094 ) ;
  }

  @Test
  public void test4568() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-98.8721859909633,-14.437360241298649 ) ;
  }

  @Test
  public void test4569() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948963,-98.94867247080607,-4.7123890792636995 ) ;
  }

  @Test
  public void test4570() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test4571() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948966,-1.5558939820203943,-83.25938004565248 ) ;
  }

  @Test
  public void test4572() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794896,-66.38825754011094,-12.418412441712665 ) ;
  }

  @Test
  public void test4573() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948968,-1.3059963511105748,35.11199127518972 ) ;
  }

  @Test
  public void test4574() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948983,-22.484191449188117,51.31810859217046 ) ;
  }

  @Test
  public void test4575() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679489,-85.71126789452956,-10.63873125946573 ) ;
  }

  @Test
  public void test4576() {
    coral.tests.JPFBenchmark.benchmark05(15.771826721809902,11.889467740766136,67.7764881589037 ) ;
  }

  @Test
  public void test4577() {
    coral.tests.JPFBenchmark.benchmark05(-1.5776444495308916E-30,-17.278759592719165,-1.5707963267948966 ) ;
  }

  @Test
  public void test4578() {
    coral.tests.JPFBenchmark.benchmark05(-1.5862136483222808E-117,-35.970673026781476,-83.2559887182518 ) ;
  }

  @Test
  public void test4579() {
    coral.tests.JPFBenchmark.benchmark05(-15.929925972375187,30.453869939889444,-44.29471031121166 ) ;
  }

  @Test
  public void test4580() {
    coral.tests.JPFBenchmark.benchmark05(-1.5943560790796785E-5,-42.14267550938995,-73.34406722503924 ) ;
  }

  @Test
  public void test4581() {
    coral.tests.JPFBenchmark.benchmark05(1.5994958307236355,-3.5478646352738245E-16,96.0462154941047 ) ;
  }

  @Test
  public void test4582() {
    coral.tests.JPFBenchmark.benchmark05(-1.6016664761464807E-145,-0.2976675226170345,-51.098191637668926 ) ;
  }

  @Test
  public void test4583() {
    coral.tests.JPFBenchmark.benchmark05(-16.043473334231905,78.445001345126,-12.898523535846124 ) ;
  }

  @Test
  public void test4584() {
    coral.tests.JPFBenchmark.benchmark05(1.6083404443965417E-11,-116.71393590571994,-112.95923261787853 ) ;
  }

  @Test
  public void test4585() {
    coral.tests.JPFBenchmark.benchmark05(-1.6121768620444757E-5,-1.5707753100878021,-43.982785786109346 ) ;
  }

  @Test
  public void test4586() {
    coral.tests.JPFBenchmark.benchmark05(1.6155871338926322E-27,-1.5707963267948966,44.25795785991315 ) ;
  }

  @Test
  public void test4587() {
    coral.tests.JPFBenchmark.benchmark05(16.161151680710304,23.268779278231193,67.24464247711015 ) ;
  }

  @Test
  public void test4588() {
    coral.tests.JPFBenchmark.benchmark05(-16.41284435909978,-66.96250482798413,88.96276306689691 ) ;
  }

  @Test
  public void test4589() {
    coral.tests.JPFBenchmark.benchmark05(-1.6428407604287543,-25.00651832722616,-68.85167553747516 ) ;
  }

  @Test
  public void test4590() {
    coral.tests.JPFBenchmark.benchmark05(-16.500258260543887,-19.722791946195755,41.5296223963081 ) ;
  }

  @Test
  public void test4591() {
    coral.tests.JPFBenchmark.benchmark05(-1.6581305673535098,-66.22524335559746,76.26225647127188 ) ;
  }

  @Test
  public void test4592() {
    coral.tests.JPFBenchmark.benchmark05(16.63261082701723,57.29159791549051,91.15581832751423 ) ;
  }

  @Test
  public void test4593() {
    coral.tests.JPFBenchmark.benchmark05(16.66432974864898,90.95383704553416,-35.69673799333452 ) ;
  }

  @Test
  public void test4594() {
    coral.tests.JPFBenchmark.benchmark05(16.680369639297595,92.3356026587179,41.629922517785474 ) ;
  }

  @Test
  public void test4595() {
    coral.tests.JPFBenchmark.benchmark05(16.6930126477462,-63.3434157859335,59.01957824868384 ) ;
  }

  @Test
  public void test4596() {
    coral.tests.JPFBenchmark.benchmark05(-1.6756840028992408E-15,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4597() {
    coral.tests.JPFBenchmark.benchmark05(-1.6765494709019584E-9,-1.5707963267948966,-20.9817860543544 ) ;
  }

  @Test
  public void test4598() {
    coral.tests.JPFBenchmark.benchmark05(-16.864415441566763,82.17194832990546,-43.7488400607692 ) ;
  }

  @Test
  public void test4599() {
    coral.tests.JPFBenchmark.benchmark05(-1.688508503057271E-226,-16.1726722618841,-58.270519896604284 ) ;
  }

  @Test
  public void test4600() {
    coral.tests.JPFBenchmark.benchmark05(-1.6940658945086007E-21,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4601() {
    coral.tests.JPFBenchmark.benchmark05(1.6940658945086007E-21,-1.5707963267948966,-8.351143385101057 ) ;
  }

  @Test
  public void test4602() {
    coral.tests.JPFBenchmark.benchmark05(-1.6940658945086007E-21,-6.776263578034403E-21,-58.11946337523468 ) ;
  }

  @Test
  public void test4603() {
    coral.tests.JPFBenchmark.benchmark05(-1.6940658945086007E-21,-73.09000404617335,78.85108699574238 ) ;
  }

  @Test
  public void test4604() {
    coral.tests.JPFBenchmark.benchmark05(-1.705501859841479E-21,-1.5707963267948966,1.570796213060391 ) ;
  }

  @Test
  public void test4605() {
    coral.tests.JPFBenchmark.benchmark05(-1.7144993522098883E-19,-1.5707963267948966,-88.08959602334232 ) ;
  }

  @Test
  public void test4606() {
    coral.tests.JPFBenchmark.benchmark05(-1.72053792746419E-16,-48.2175871462769,-0.4185446917326186 ) ;
  }

  @Test
  public void test4607() {
    coral.tests.JPFBenchmark.benchmark05(-1.7267543095147413E-12,-1.5707963267948966,26.703473026513063 ) ;
  }

  @Test
  public void test4608() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-1.5707943159494056,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test4609() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-1.734723475976807E-18,-64.40264842028272 ) ;
  }

  @Test
  public void test4610() {
    coral.tests.JPFBenchmark.benchmark05(-1.734723475976807E-18,-36.09047729733217,-20.785831580163006 ) ;
  }

  @Test
  public void test4611() {
    coral.tests.JPFBenchmark.benchmark05(-1.7347350479586947E-18,-1.5707963267948966,77.0002700203773 ) ;
  }

  @Test
  public void test4612() {
    coral.tests.JPFBenchmark.benchmark05(-17.357058605914858,-19.196185774861732,-67.19226495274573 ) ;
  }

  @Test
  public void test4613() {
    coral.tests.JPFBenchmark.benchmark05(-1.739622584244834E-15,-1.5707963267948912,42.8870416911533 ) ;
  }

  @Test
  public void test4614() {
    coral.tests.JPFBenchmark.benchmark05(-1.7440603504673385E-105,-1.5707963267948948,-56.12433712664536 ) ;
  }

  @Test
  public void test4615() {
    coral.tests.JPFBenchmark.benchmark05(-1.744096517166491E-14,-2.332014251327028E-14,-1.570796326794897 ) ;
  }

  @Test
  public void test4616() {
    coral.tests.JPFBenchmark.benchmark05(17.450430613518748,-39.01690735475116,1.7468232044498961 ) ;
  }

  @Test
  public void test4617() {
    coral.tests.JPFBenchmark.benchmark05(-1.7475398428867982E-15,-86.39379797280716,-1.5707963267948966 ) ;
  }

  @Test
  public void test4618() {
    coral.tests.JPFBenchmark.benchmark05(-1.7534474792067224E-192,-72.91744150494972,60.34051717416487 ) ;
  }

  @Test
  public void test4619() {
    coral.tests.JPFBenchmark.benchmark05(-1.7550820849905762,-5.266169485575915,93.31475410733594 ) ;
  }

  @Test
  public void test4620() {
    coral.tests.JPFBenchmark.benchmark05(-1.761050914342067E-133,-1.5707963267948966,99.91415784070642 ) ;
  }

  @Test
  public void test4621() {
    coral.tests.JPFBenchmark.benchmark05(17.612637582540486,67.61641511020099,-33.72451627217484 ) ;
  }

  @Test
  public void test4622() {
    coral.tests.JPFBenchmark.benchmark05(-1.7623463414444518E-15,-1.5707963265835296,38.36543378907648 ) ;
  }

  @Test
  public void test4623() {
    coral.tests.JPFBenchmark.benchmark05(-1.7664541563435257E-6,-1.5707963267948966,-95.92389612574253 ) ;
  }

  @Test
  public void test4624() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-0.05119631667848373,-35.60768349313359 ) ;
  }

  @Test
  public void test4625() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-0.34782572698210856,86.89377288927327 ) ;
  }

  @Test
  public void test4626() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-0.9635440459972315,14.472360912853752 ) ;
  }

  @Test
  public void test4627() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-10.401693083624577,-82.73504857350586 ) ;
  }

  @Test
  public void test4628() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.048149278244722,7.232310798982645 ) ;
  }

  @Test
  public void test4629() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-11.87137720743516,0 ) ;
  }

  @Test
  public void test4630() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948906,10.34673021018564 ) ;
  }

  @Test
  public void test4631() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948912,-12.359286283921648 ) ;
  }

  @Test
  public void test4632() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948966,-31.415926535897935 ) ;
  }

  @Test
  public void test4633() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948966,-57.91171461745245 ) ;
  }

  @Test
  public void test4634() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948966,82.65721373807412 ) ;
  }

  @Test
  public void test4635() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test4636() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-42.209469842009526,1.5707963267948966 ) ;
  }

  @Test
  public void test4637() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-47.22437747408181,-6.462511801993585 ) ;
  }

  @Test
  public void test4638() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-54.44771208535494,-3.141592892008449 ) ;
  }

  @Test
  public void test4639() {
    coral.tests.JPFBenchmark.benchmark05(-1.7763568394002505E-15,-54.733797511004845,0 ) ;
  }

  @Test
  public void test4640() {
    coral.tests.JPFBenchmark.benchmark05(17.89120522070327,-42.05082367011188,-63.84693751903183 ) ;
  }

  @Test
  public void test4641() {
    coral.tests.JPFBenchmark.benchmark05(-1.7894165008342745E-15,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test4642() {
    coral.tests.JPFBenchmark.benchmark05(-1.8033161362862765E-130,-1.5707963267948966,-49.92030278841891 ) ;
  }

  @Test
  public void test4643() {
    coral.tests.JPFBenchmark.benchmark05(18.049644049941847,91.71292082607741,-64.831609285649 ) ;
  }

  @Test
  public void test4644() {
    coral.tests.JPFBenchmark.benchmark05(1.8101175544680161,-0.26997871772214116,100.70149347098646 ) ;
  }

  @Test
  public void test4645() {
    coral.tests.JPFBenchmark.benchmark05(-1.823249582512052E-15,-56.962943214324326,-97.9950218940846 ) ;
  }

  @Test
  public void test4646() {
    coral.tests.JPFBenchmark.benchmark05(-1.82877982605164E-99,-1.5707963267948966,54.0143389064027 ) ;
  }

  @Test
  public void test4647() {
    coral.tests.JPFBenchmark.benchmark05(18.31908637737503,-47.88967698582294,-76.23301479081385 ) ;
  }

  @Test
  public void test4648() {
    coral.tests.JPFBenchmark.benchmark05(1.8487931337123322,-47.65877669148557,-1.5707963267948948 ) ;
  }

  @Test
  public void test4649() {
    coral.tests.JPFBenchmark.benchmark05(-18.493238220930635,-75.22164746210287,-94.00470295167788 ) ;
  }

  @Test
  public void test4650() {
    coral.tests.JPFBenchmark.benchmark05(-18.66927302055484,0,0 ) ;
  }

  @Test
  public void test4651() {
    coral.tests.JPFBenchmark.benchmark05(-1.890476837287025,34.16918825808693,77.16324937805729 ) ;
  }

  @Test
  public void test4652() {
    coral.tests.JPFBenchmark.benchmark05(-1.9004384396170588,3.853528773353094,-1.5707963267948966 ) ;
  }

  @Test
  public void test4653() {
    coral.tests.JPFBenchmark.benchmark05(19.016219973492568,14.715231093007205,56.232709987893514 ) ;
  }

  @Test
  public void test4654() {
    coral.tests.JPFBenchmark.benchmark05(-19.048648436955105,27.317219431192513,-91.49993949178446 ) ;
  }

  @Test
  public void test4655() {
    coral.tests.JPFBenchmark.benchmark05(-1.9057307175201146,75.87608477729663,78.82267979332795 ) ;
  }

  @Test
  public void test4656() {
    coral.tests.JPFBenchmark.benchmark05(19.061503397696185,20.502026996864814,36.09417570105626 ) ;
  }

  @Test
  public void test4657() {
    coral.tests.JPFBenchmark.benchmark05(-1.9065943895838937E-16,-1.5707963267948983,-1.570796326785176 ) ;
  }

  @Test
  public void test4658() {
    coral.tests.JPFBenchmark.benchmark05(-1.9092196268136977E-4,-0.41763344553686077,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test4659() {
    coral.tests.JPFBenchmark.benchmark05(-1.9166390815014876E-15,-0.4355136516533596,-66.40653970116941 ) ;
  }

  @Test
  public void test4660() {
    coral.tests.JPFBenchmark.benchmark05(-1.9179238367479254E-11,-1.5707963267948983,161.68591989065527 ) ;
  }

  @Test
  public void test4661() {
    coral.tests.JPFBenchmark.benchmark05(-1.941224035100549E-15,-1.360077995374836E-14,-77.32078155011625 ) ;
  }

  @Test
  public void test4662() {
    coral.tests.JPFBenchmark.benchmark05(-1.9721522630525295E-31,-1.5707963267948966,-39.380548048676594 ) ;
  }

  @Test
  public void test4663() {
    coral.tests.JPFBenchmark.benchmark05(-1.9721522630525295E-31,-41.55566056012933,-92.10393094602475 ) ;
  }

  @Test
  public void test4664() {
    coral.tests.JPFBenchmark.benchmark05(1.9734217496303985,-174.21586776314203,58.280645569192245 ) ;
  }

  @Test
  public void test4665() {
    coral.tests.JPFBenchmark.benchmark05(-1.9734740573962212E-16,-1.5707963267948963,-65.84285808561133 ) ;
  }

  @Test
  public void test4666() {
    coral.tests.JPFBenchmark.benchmark05(19.7372717261252,-40.376932798258245,90.92084035098921 ) ;
  }

  @Test
  public void test4667() {
    coral.tests.JPFBenchmark.benchmark05(1.9792291351152128E-17,-3.562121502507722,-1.5707963267948966 ) ;
  }

  @Test
  public void test4668() {
    coral.tests.JPFBenchmark.benchmark05(-19.834565494094008,-13.257077208301823,-59.64159829485316 ) ;
  }

  @Test
  public void test4669() {
    coral.tests.JPFBenchmark.benchmark05(1.9857954111480216,-1.6406669046433895,-32.97196893384136 ) ;
  }

  @Test
  public void test4670() {
    coral.tests.JPFBenchmark.benchmark05(-1.988240429126601E-9,-1.5607213911042916,0.0 ) ;
  }

  @Test
  public void test4671() {
    coral.tests.JPFBenchmark.benchmark05(-1.993188719026072E-17,-73.24228910082591,0.0 ) ;
  }

  @Test
  public void test4672() {
    coral.tests.JPFBenchmark.benchmark05(-19.94752576952689,20.33301864807406,85.35072385079059 ) ;
  }

  @Test
  public void test4673() {
    coral.tests.JPFBenchmark.benchmark05(-2.0029931484347406E-20,-1.5707963267948966,21.991395197847364 ) ;
  }

  @Test
  public void test4674() {
    coral.tests.JPFBenchmark.benchmark05(-2.0105186774216908E-4,-59.6902604182061,55.26483691068384 ) ;
  }

  @Test
  public void test4675() {
    coral.tests.JPFBenchmark.benchmark05(20.292060441975053,7.012427630516598,40.091583707956346 ) ;
  }

  @Test
  public void test4676() {
    coral.tests.JPFBenchmark.benchmark05(-2.0388713451566634E-7,-1.5707963267948966,-28.274283333178154 ) ;
  }

  @Test
  public void test4677() {
    coral.tests.JPFBenchmark.benchmark05(20.717060794058767,3.986861823699897,61.95025346679651 ) ;
  }

  @Test
  public void test4678() {
    coral.tests.JPFBenchmark.benchmark05(-2.086471923602477E-15,-1.5707963267948966,1.5707963267948946 ) ;
  }

  @Test
  public void test4679() {
    coral.tests.JPFBenchmark.benchmark05(-2.09104375929497E-15,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test4680() {
    coral.tests.JPFBenchmark.benchmark05(-2.0964039594060027E-4,-0.015527883468797661,-61.145791904033686 ) ;
  }

  @Test
  public void test4681() {
    coral.tests.JPFBenchmark.benchmark05(-2.102279824050433E-7,-1.5707963267948966,-172.78625669278046 ) ;
  }

  @Test
  public void test4682() {
    coral.tests.JPFBenchmark.benchmark05(-21.114470829156147,-82.51303703490602,1.1977681215979317 ) ;
  }

  @Test
  public void test4683() {
    coral.tests.JPFBenchmark.benchmark05(-2.111589067203343E-12,-1.5707963267948966,-20.68246415432921 ) ;
  }

  @Test
  public void test4684() {
    coral.tests.JPFBenchmark.benchmark05(2.1175823681357508E-22,-1.210995441469166,-33.237610634772935 ) ;
  }

  @Test
  public void test4685() {
    coral.tests.JPFBenchmark.benchmark05(-2.1175823681357508E-22,-1.5707963267948966,-37.714737753768254 ) ;
  }

  @Test
  public void test4686() {
    coral.tests.JPFBenchmark.benchmark05(2.1175823681357508E-22,-15.739353184101844,77.00825838505952 ) ;
  }

  @Test
  public void test4687() {
    coral.tests.JPFBenchmark.benchmark05(-2.1350303234945922E-5,-0.13458889317066114,1.5707963267948966 ) ;
  }

  @Test
  public void test4688() {
    coral.tests.JPFBenchmark.benchmark05(-2.1549161928854206E-16,-9.99007718231679,1.5707963267948966 ) ;
  }

  @Test
  public void test4689() {
    coral.tests.JPFBenchmark.benchmark05(2.1684043449710089E-19,-0.08396621508232484,-0.7502265807271804 ) ;
  }

  @Test
  public void test4690() {
    coral.tests.JPFBenchmark.benchmark05(-2.1684043449710089E-19,-1.5707963267948966,1.570796326464082 ) ;
  }

  @Test
  public void test4691() {
    coral.tests.JPFBenchmark.benchmark05(-2.1684043449710089E-19,-1.5707963267948966,31.985193884573725 ) ;
  }

  @Test
  public void test4692() {
    coral.tests.JPFBenchmark.benchmark05(-21.71646850604745,60.99944742171891,-5.095171701431056 ) ;
  }

  @Test
  public void test4693() {
    coral.tests.JPFBenchmark.benchmark05(21.7819226483672,23.51123546797706,94.49154118221358 ) ;
  }

  @Test
  public void test4694() {
    coral.tests.JPFBenchmark.benchmark05(-2.191688646440215E-14,-1.5707963267948966,-65.15684448801515 ) ;
  }

  @Test
  public void test4695() {
    coral.tests.JPFBenchmark.benchmark05(-22.094444168174718,69.02975192100686,-13.082912142669628 ) ;
  }

  @Test
  public void test4696() {
    coral.tests.JPFBenchmark.benchmark05(-2.2121484616079157E-4,-0.8373394493238386,177.4286561702266 ) ;
  }

  @Test
  public void test4697() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.006583368159545902,-4.771463611811194 ) ;
  }

  @Test
  public void test4698() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,0.01179613351745915,-1.5707963267948966 ) ;
  }

  @Test
  public void test4699() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.07754063396568964,-94.24777960769386 ) ;
  }

  @Test
  public void test4700() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.25403908887145465,63.31980922820042 ) ;
  }

  @Test
  public void test4701() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-0.7504363496632775,25.468336053630193 ) ;
  }

  @Test
  public void test4702() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-100.0,-100.0 ) ;
  }

  @Test
  public void test4703() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-10.448425879559721,-54.986864034847116 ) ;
  }

  @Test
  public void test4704() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.280351931259741,-1.5707963259854452 ) ;
  }

  @Test
  public void test4705() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.4659424151624028,-3.141639280412817 ) ;
  }

  @Test
  public void test4706() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5289040335632504,-7.853981776731226 ) ;
  }

  @Test
  public void test4707() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.570796326702037,-1.5707963267949125 ) ;
  }

  @Test
  public void test4708() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.570796326794891,-21.60806768992653 ) ;
  }

  @Test
  public void test4709() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948961,15.803785744671899 ) ;
  }

  @Test
  public void test4710() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948963,-1.5707963267948963 ) ;
  }

  @Test
  public void test4711() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4712() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,-0.3299234495252434 ) ;
  }

  @Test
  public void test4713() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,10.989368260542662 ) ;
  }

  @Test
  public void test4714() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4715() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-1.5707963267948966,4.440892098500626E-16 ) ;
  }

  @Test
  public void test4716() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-3.1415928920083727,-15.226680978086236 ) ;
  }

  @Test
  public void test4717() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-3.141600282985822,-22.285610243908756 ) ;
  }

  @Test
  public void test4718() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-3.4321832490825273,-89.98548811313402 ) ;
  }

  @Test
  public void test4719() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-3.671342179817742,1.92953728847705 ) ;
  }

  @Test
  public void test4720() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-42.03380266196234,-31.079286309962043 ) ;
  }

  @Test
  public void test4721() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-6.556659808372287E-17,-82.55111785230554 ) ;
  }

  @Test
  public void test4722() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-66.31832411164697,-67.40051475272281 ) ;
  }

  @Test
  public void test4723() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-66.36010912725322,8.23565580310005 ) ;
  }

  @Test
  public void test4724() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-73.11115053312027,74.43724252139802 ) ;
  }

  @Test
  public void test4725() {
    coral.tests.JPFBenchmark.benchmark05(-2.220446049250313E-16,-92.20074279430702,-72.64195651350363 ) ;
  }

  @Test
  public void test4726() {
    coral.tests.JPFBenchmark.benchmark05(-22.31086738776318,74.18220967331177,60.86897645957242 ) ;
  }

  @Test
  public void test4727() {
    coral.tests.JPFBenchmark.benchmark05(-22.319744633387373,-3.154131193998637,84.14548866096953 ) ;
  }

  @Test
  public void test4728() {
    coral.tests.JPFBenchmark.benchmark05(-22.428600096289003,-65.61749645087731,72.11228553832862 ) ;
  }

  @Test
  public void test4729() {
    coral.tests.JPFBenchmark.benchmark05(-22.554747347527453,-65.91387059320724,-75.69704763723067 ) ;
  }

  @Test
  public void test4730() {
    coral.tests.JPFBenchmark.benchmark05(-22.57518662828045,33.83107285111558,-46.176002044188216 ) ;
  }

  @Test
  public void test4731() {
    coral.tests.JPFBenchmark.benchmark05(-2.2666439929150327E-6,-1.5707963267948966,-10.994639435032871 ) ;
  }

  @Test
  public void test4732() {
    coral.tests.JPFBenchmark.benchmark05(-22.825829435509732,59.81513575274889,-94.51993510522246 ) ;
  }

  @Test
  public void test4733() {
    coral.tests.JPFBenchmark.benchmark05(22.93829744326061,61.64136898685982,-39.10351699120631 ) ;
  }

  @Test
  public void test4734() {
    coral.tests.JPFBenchmark.benchmark05(-23.014849933305427,31.19011788427963,-51.288532471263814 ) ;
  }

  @Test
  public void test4735() {
    coral.tests.JPFBenchmark.benchmark05(-2.3034973218718515E-13,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test4736() {
    coral.tests.JPFBenchmark.benchmark05(-2.3064012787040576E-5,-42.18017209851682,-59.887404221497576 ) ;
  }

  @Test
  public void test4737() {
    coral.tests.JPFBenchmark.benchmark05(23.082715333536825,62.02849277325754,-28.024323368409924 ) ;
  }

  @Test
  public void test4738() {
    coral.tests.JPFBenchmark.benchmark05(-23.51911939832783,-19.08816121127228,51.176165477533374 ) ;
  }

  @Test
  public void test4739() {
    coral.tests.JPFBenchmark.benchmark05(-2.3526556390666474E-29,-1.5707963267948966,78.82712002236049 ) ;
  }

  @Test
  public void test4740() {
    coral.tests.JPFBenchmark.benchmark05(23.55841082175833,-64.57156098635608,-5.474355989385174 ) ;
  }

  @Test
  public void test4741() {
    coral.tests.JPFBenchmark.benchmark05(23.605011713270102,-52.50217721426775,-90.82775164978551 ) ;
  }

  @Test
  public void test4742() {
    coral.tests.JPFBenchmark.benchmark05(-2.3731905359595863E-15,-1.5707963267948966,-7.383676762516698E-16 ) ;
  }

  @Test
  public void test4743() {
    coral.tests.JPFBenchmark.benchmark05(-23.785018816195574,22.38508765552389,69.46798844741707 ) ;
  }

  @Test
  public void test4744() {
    coral.tests.JPFBenchmark.benchmark05(23.946416424652455,-52.86743816989863,-13.516345500802629 ) ;
  }

  @Test
  public void test4745() {
    coral.tests.JPFBenchmark.benchmark05(-23.948297896659355,-50.76411237198073,52.08298953984368 ) ;
  }

  @Test
  public void test4746() {
    coral.tests.JPFBenchmark.benchmark05(-2.3995149022330095E-240,-1.570796326794802,-1.5707963267948966 ) ;
  }

  @Test
  public void test4747() {
    coral.tests.JPFBenchmark.benchmark05(-2.4140008987763E-19,-1.5707963267948966,70.68583470532974 ) ;
  }

  @Test
  public void test4748() {
    coral.tests.JPFBenchmark.benchmark05(24.332750170157638,82.67254785509243,88.00676864061941 ) ;
  }

  @Test
  public void test4749() {
    coral.tests.JPFBenchmark.benchmark05(-24.406867866678212,55.3696209168408,-0.1777574176733907 ) ;
  }

  @Test
  public void test4750() {
    coral.tests.JPFBenchmark.benchmark05(2.4522426005718034,-1.0573062473376527,-99.8132912944634 ) ;
  }

  @Test
  public void test4751() {
    coral.tests.JPFBenchmark.benchmark05(2.4541224572123297,-0.23202503784150993,-1.5707963267948983 ) ;
  }

  @Test
  public void test4752() {
    coral.tests.JPFBenchmark.benchmark05(24.544894619072167,21.033136340694014,50.45211832696447 ) ;
  }

  @Test
  public void test4753() {
    coral.tests.JPFBenchmark.benchmark05(-24.54657832252755,-79.37558203951352,37.9425740571144 ) ;
  }

  @Test
  public void test4754() {
    coral.tests.JPFBenchmark.benchmark05(-2.462526246904096E-6,-1.5707963267948966,40.84070530698858 ) ;
  }

  @Test
  public void test4755() {
    coral.tests.JPFBenchmark.benchmark05(-2.465190328815662E-32,-0.10672034796192797,1.3806348107874208E-17 ) ;
  }

  @Test
  public void test4756() {
    coral.tests.JPFBenchmark.benchmark05(-2.465190328815662E-32,-1.268049072201208,1.5707963267948968 ) ;
  }

  @Test
  public void test4757() {
    coral.tests.JPFBenchmark.benchmark05(-2.465190328815662E-32,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test4758() {
    coral.tests.JPFBenchmark.benchmark05(-2.4677579418653533E-178,-0.4107048452259379,-45.918009712977145 ) ;
  }

  @Test
  public void test4759() {
    coral.tests.JPFBenchmark.benchmark05(-2.4717730234943257E-11,-66.38265475808635,-113.58891404988432 ) ;
  }

  @Test
  public void test4760() {
    coral.tests.JPFBenchmark.benchmark05(-2.5026038689788762E-147,-0.5824039972721675,46.42667818720182 ) ;
  }

  @Test
  public void test4761() {
    coral.tests.JPFBenchmark.benchmark05(-25.058895804560024,-44.974342972970874,90.34796974912976 ) ;
  }

  @Test
  public void test4762() {
    coral.tests.JPFBenchmark.benchmark05(-2.5066674179391126E-17,-80.08814521455285,-1.5707963267948948 ) ;
  }

  @Test
  public void test4763() {
    coral.tests.JPFBenchmark.benchmark05(2.510544733721138,-5.421010862427522E-20,1.5707963267948983 ) ;
  }

  @Test
  public void test4764() {
    coral.tests.JPFBenchmark.benchmark05(25.21505784892493,20.68821391072011,31.307541486246038 ) ;
  }

  @Test
  public void test4765() {
    coral.tests.JPFBenchmark.benchmark05(-2.5218229887275596E-4,-1.5707963267948963,-56.855190492094486 ) ;
  }

  @Test
  public void test4766() {
    coral.tests.JPFBenchmark.benchmark05(-2.5379418373156492E-116,-1.324340893330585,16.015127865876224 ) ;
  }

  @Test
  public void test4767() {
    coral.tests.JPFBenchmark.benchmark05(2.5550082986574423,-1.5707963267948966,-41.85119249130228 ) ;
  }

  @Test
  public void test4768() {
    coral.tests.JPFBenchmark.benchmark05(-25.570065917568257,1.220742016916688,-35.200222556534584 ) ;
  }

  @Test
  public void test4769() {
    coral.tests.JPFBenchmark.benchmark05(-25.77652302942785,-71.49977787393284,-36.51693394993521 ) ;
  }

  @Test
  public void test4770() {
    coral.tests.JPFBenchmark.benchmark05(25.83190147950438,63.05657033238535,8.888112428361225 ) ;
  }

  @Test
  public void test4771() {
    coral.tests.JPFBenchmark.benchmark05(-2.5848386117265518E-5,-48.23321076165619,22.015954731369746 ) ;
  }

  @Test
  public void test4772() {
    coral.tests.JPFBenchmark.benchmark05(-2.5893720378419255E-14,-1.5707963267948966,-18.291395563049775 ) ;
  }

  @Test
  public void test4773() {
    coral.tests.JPFBenchmark.benchmark05(2.602298136313081,-27.311775129720473,-11.694394027674136 ) ;
  }

  @Test
  public void test4774() {
    coral.tests.JPFBenchmark.benchmark05(26.02560353001293,29.697696803210874,44.80616796243325 ) ;
  }

  @Test
  public void test4775() {
    coral.tests.JPFBenchmark.benchmark05(26.2096574008512,-89.54407662519814,-51.545661579766275 ) ;
  }

  @Test
  public void test4776() {
    coral.tests.JPFBenchmark.benchmark05(26.23664711391018,-46.81494625420832,50.53191256385736 ) ;
  }

  @Test
  public void test4777() {
    coral.tests.JPFBenchmark.benchmark05(-2625.4768051394917,0,0 ) ;
  }

  @Test
  public void test4778() {
    coral.tests.JPFBenchmark.benchmark05(-2.6324404675850526E-11,-0.6407703043018944,-96.29981278884792 ) ;
  }

  @Test
  public void test4779() {
    coral.tests.JPFBenchmark.benchmark05(-2.643974212814596E-10,-1.5707963267948966,-80.11063508017052 ) ;
  }

  @Test
  public void test4780() {
    coral.tests.JPFBenchmark.benchmark05(26.45212945648781,67.97919303154521,2.663357988523998 ) ;
  }

  @Test
  public void test4781() {
    coral.tests.JPFBenchmark.benchmark05(-2.6469779601696886E-23,-1.5707963267948966,48.79581142278918 ) ;
  }

  @Test
  public void test4782() {
    coral.tests.JPFBenchmark.benchmark05(26.500428367131533,10.197696715631693,-72.80157511720256 ) ;
  }

  @Test
  public void test4783() {
    coral.tests.JPFBenchmark.benchmark05(-2.652265319713129E-16,-0.6013661721828214,100.0 ) ;
  }

  @Test
  public void test4784() {
    coral.tests.JPFBenchmark.benchmark05(-26.685916821515534,-87.0007370950306,35.62245173902076 ) ;
  }

  @Test
  public void test4785() {
    coral.tests.JPFBenchmark.benchmark05(-26.760705159654123,82.38748353561388,-69.71232292968857 ) ;
  }

  @Test
  public void test4786() {
    coral.tests.JPFBenchmark.benchmark05(-26.886256581006634,57.232879391843085,88.13320960280868 ) ;
  }

  @Test
  public void test4787() {
    coral.tests.JPFBenchmark.benchmark05(26.943938682210586,40.391552438253825,30.249683340500326 ) ;
  }

  @Test
  public void test4788() {
    coral.tests.JPFBenchmark.benchmark05(-26.96067091453145,2.2245468331382483,-46.42040472222077 ) ;
  }

  @Test
  public void test4789() {
    coral.tests.JPFBenchmark.benchmark05(-27.031447010232768,7.375530840240501,53.014658162413895 ) ;
  }

  @Test
  public void test4790() {
    coral.tests.JPFBenchmark.benchmark05(-2708.6161883581563,0,0 ) ;
  }

  @Test
  public void test4791() {
    coral.tests.JPFBenchmark.benchmark05(-27.09413583120343,-81.99587886735675,12.840213581302478 ) ;
  }

  @Test
  public void test4792() {
    coral.tests.JPFBenchmark.benchmark05(-2.710505431213761E-20,-1.5707963232883497,0.0 ) ;
  }

  @Test
  public void test4793() {
    coral.tests.JPFBenchmark.benchmark05(-2.710505431213761E-20,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4794() {
    coral.tests.JPFBenchmark.benchmark05(-2.710505431213761E-20,-1.5707963267948966,-29.845618490583057 ) ;
  }

  @Test
  public void test4795() {
    coral.tests.JPFBenchmark.benchmark05(27.172451576783004,69.2058625172595,-34.88681263793512 ) ;
  }

  @Test
  public void test4796() {
    coral.tests.JPFBenchmark.benchmark05(27.395054215301485,-77.42163025992889,-0.9011434330015646 ) ;
  }

  @Test
  public void test4797() {
    coral.tests.JPFBenchmark.benchmark05(-2.7397616862605038E-194,-1.5707963267948966,-83.59973070855334 ) ;
  }

  @Test
  public void test4798() {
    coral.tests.JPFBenchmark.benchmark05(-27.448280566190093,99.93353334163672,53.03435728264401 ) ;
  }

  @Test
  public void test4799() {
    coral.tests.JPFBenchmark.benchmark05(2.7755575615628914E-17,-0.14755298090079874,4.152004094805241 ) ;
  }

  @Test
  public void test4800() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-0.6697865037792317,45.33716225242622 ) ;
  }

  @Test
  public void test4801() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-1.5707963267948912,-18.849800062171433 ) ;
  }

  @Test
  public void test4802() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4803() {
    coral.tests.JPFBenchmark.benchmark05(2.7755575615628914E-17,-1.5707963267948966,-49.94342005272536 ) ;
  }

  @Test
  public void test4804() {
    coral.tests.JPFBenchmark.benchmark05(2.7755575615628914E-17,-41.53797654806628,-0.261500369129188 ) ;
  }

  @Test
  public void test4805() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-97.91855170898738,-204.20276260528027 ) ;
  }

  @Test
  public void test4806() {
    coral.tests.JPFBenchmark.benchmark05(-2.7755575615628914E-17,-98.5105618943863,4.712388986893704 ) ;
  }

  @Test
  public void test4807() {
    coral.tests.JPFBenchmark.benchmark05(-2.7772886616276082,-52.01160367588968,-77.51920928862586 ) ;
  }

  @Test
  public void test4808() {
    coral.tests.JPFBenchmark.benchmark05(27.779514987251503,-17.290587975691267,-69.65118061157773 ) ;
  }

  @Test
  public void test4809() {
    coral.tests.JPFBenchmark.benchmark05(-2.778448436856347E-163,-0.3923962808019293,-72.80429420747188 ) ;
  }

  @Test
  public void test4810() {
    coral.tests.JPFBenchmark.benchmark05(2.778467722547562E-17,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4811() {
    coral.tests.JPFBenchmark.benchmark05(-2.789200059320992E-4,-1.339467522670863,0.0 ) ;
  }

  @Test
  public void test4812() {
    coral.tests.JPFBenchmark.benchmark05(28.184166187976956,7.423550273681485,19.424623285264403 ) ;
  }

  @Test
  public void test4813() {
    coral.tests.JPFBenchmark.benchmark05(28.357838803467928,37.904382249090816,78.43977093815539 ) ;
  }

  @Test
  public void test4814() {
    coral.tests.JPFBenchmark.benchmark05(-2.8451311993408992E-160,-98.5955500018635,-1.5707963267948966 ) ;
  }

  @Test
  public void test4815() {
    coral.tests.JPFBenchmark.benchmark05(2.872450937862405,14.448561425192871,-0.8293203294056579 ) ;
  }

  @Test
  public void test4816() {
    coral.tests.JPFBenchmark.benchmark05(2.8916784479416697,-35.961052652521644,-1.5707963267948966 ) ;
  }

  @Test
  public void test4817() {
    coral.tests.JPFBenchmark.benchmark05(28.944658505013166,-83.17394356930924,-76.64816412949918 ) ;
  }

  @Test
  public void test4818() {
    coral.tests.JPFBenchmark.benchmark05(-2.89550378926024E-15,-1.5707963267795853,1.5707963267948983 ) ;
  }

  @Test
  public void test4819() {
    coral.tests.JPFBenchmark.benchmark05(29.08203274542751,-95.78519998737708,93.50799135983374 ) ;
  }

  @Test
  public void test4820() {
    coral.tests.JPFBenchmark.benchmark05(2.9108628434688,15.363552328598757,6.533665186446305 ) ;
  }

  @Test
  public void test4821() {
    coral.tests.JPFBenchmark.benchmark05(29.112903830388518,8.68623700482874,-26.930765761256083 ) ;
  }

  @Test
  public void test4822() {
    coral.tests.JPFBenchmark.benchmark05(-2.946017928369223E-7,-0.08447201792179726,60.10354127149208 ) ;
  }

  @Test
  public void test4823() {
    coral.tests.JPFBenchmark.benchmark05(-29.467063596060257,77.85390909281423,47.85165999936518 ) ;
  }

  @Test
  public void test4824() {
    coral.tests.JPFBenchmark.benchmark05(29.467126305749503,-47.75636691565148,57.519254336407556 ) ;
  }

  @Test
  public void test4825() {
    coral.tests.JPFBenchmark.benchmark05(29.530475994974864,32.34285935389008,24.900452586146343 ) ;
  }

  @Test
  public void test4826() {
    coral.tests.JPFBenchmark.benchmark05(2.961117719627681,-1.5707963267948877,0.23531737531038116 ) ;
  }

  @Test
  public void test4827() {
    coral.tests.JPFBenchmark.benchmark05(-29.639956155786834,96.46069064776407,-50.74490117324362 ) ;
  }

  @Test
  public void test4828() {
    coral.tests.JPFBenchmark.benchmark05(-29.665144862319465,3.7405734188378688,85.70620620489825 ) ;
  }

  @Test
  public void test4829() {
    coral.tests.JPFBenchmark.benchmark05(-2.973060744020886E-8,-1.5707963267948966,-65.97314146317224 ) ;
  }

  @Test
  public void test4830() {
    coral.tests.JPFBenchmark.benchmark05(-29.737266099899216,0,0 ) ;
  }

  @Test
  public void test4831() {
    coral.tests.JPFBenchmark.benchmark05(-2.9766075082279E-17,-1.5707963267948966,-50.27437863658126 ) ;
  }

  @Test
  public void test4832() {
    coral.tests.JPFBenchmark.benchmark05(30.46397892090559,-50.55413951951566,6.096521073214987 ) ;
  }

  @Test
  public void test4833() {
    coral.tests.JPFBenchmark.benchmark05(30.481668625134915,19.74999372321267,-57.35213578965561 ) ;
  }

  @Test
  public void test4834() {
    coral.tests.JPFBenchmark.benchmark05(30.601861364948235,-97.49032697870292,-19.061730914959284 ) ;
  }

  @Test
  public void test4835() {
    coral.tests.JPFBenchmark.benchmark05(3.0625832214774817,56.842789594187906,64.45433464141672 ) ;
  }

  @Test
  public void test4836() {
    coral.tests.JPFBenchmark.benchmark05(30.684552309773665,-70.77478210480677,-18.565127321510346 ) ;
  }

  @Test
  public void test4837() {
    coral.tests.JPFBenchmark.benchmark05(-3.0846974273316917E-179,-1.5707963267948912,-54.3051087068969 ) ;
  }

  @Test
  public void test4838() {
    coral.tests.JPFBenchmark.benchmark05(-30.941199684305914,11.826036487713992,65.83626135621657 ) ;
  }

  @Test
  public void test4839() {
    coral.tests.JPFBenchmark.benchmark05(-3.099593111494589E-4,-1.5707963267948966,-10.995687266167183 ) ;
  }

  @Test
  public void test4840() {
    coral.tests.JPFBenchmark.benchmark05(3.1015862745012157,83.28635288861287,-17.064196912744862 ) ;
  }

  @Test
  public void test4841() {
    coral.tests.JPFBenchmark.benchmark05(-31.10824777561831,23.550661622084945,-83.34357571867545 ) ;
  }

  @Test
  public void test4842() {
    coral.tests.JPFBenchmark.benchmark05(-3.139747829001581E-15,-1.5707963267948966,-20.50604276461003 ) ;
  }

  @Test
  public void test4843() {
    coral.tests.JPFBenchmark.benchmark05(-3.1525411378865645E-16,-0.06329656075139073,-91.06401604296187 ) ;
  }

  @Test
  public void test4844() {
    coral.tests.JPFBenchmark.benchmark05(-3.1550739109937693E-17,-42.178605449362166,-1.5707963267948966 ) ;
  }

  @Test
  public void test4845() {
    coral.tests.JPFBenchmark.benchmark05(-31.673426887884588,71.65756028477603,-37.86023850410061 ) ;
  }

  @Test
  public void test4846() {
    coral.tests.JPFBenchmark.benchmark05(-3.1724272966445615E-117,-91.62402656226999,-56.13846801553768 ) ;
  }

  @Test
  public void test4847() {
    coral.tests.JPFBenchmark.benchmark05(-31.774029934899772,76.21851752960572,-11.444409241042777 ) ;
  }

  @Test
  public void test4848() {
    coral.tests.JPFBenchmark.benchmark05(-3.200417256796257,41.54241386671629,-20.61180046647941 ) ;
  }

  @Test
  public void test4849() {
    coral.tests.JPFBenchmark.benchmark05(-3.2095069508082276E-15,-1.5707963267948966,-90.84770723074939 ) ;
  }

  @Test
  public void test4850() {
    coral.tests.JPFBenchmark.benchmark05(32.09990458039701,21.532729279018326,31.85218400606331 ) ;
  }

  @Test
  public void test4851() {
    coral.tests.JPFBenchmark.benchmark05(3.2114439277906683,51.20292335898958,35.252583553605945 ) ;
  }

  @Test
  public void test4852() {
    coral.tests.JPFBenchmark.benchmark05(-32.228777736258095,26.257355979920078,-10.177107061619424 ) ;
  }

  @Test
  public void test4853() {
    coral.tests.JPFBenchmark.benchmark05(32.33329519752431,-50.352596070562996,-24.288584046502734 ) ;
  }

  @Test
  public void test4854() {
    coral.tests.JPFBenchmark.benchmark05(-32.34862025022123,59.0831063347168,-57.97400780536732 ) ;
  }

  @Test
  public void test4855() {
    coral.tests.JPFBenchmark.benchmark05(-3.248565551764031E-114,-1.2676427566026525,-20.95397073024903 ) ;
  }

  @Test
  public void test4856() {
    coral.tests.JPFBenchmark.benchmark05(32.550343739787394,-70.39282379364067,69.74711064116607 ) ;
  }

  @Test
  public void test4857() {
    coral.tests.JPFBenchmark.benchmark05(-32.769820037010234,-79.87408045432758,89.34194524302333 ) ;
  }

  @Test
  public void test4858() {
    coral.tests.JPFBenchmark.benchmark05(32.89569462634802,17.28397536328265,5.567821273161783 ) ;
  }

  @Test
  public void test4859() {
    coral.tests.JPFBenchmark.benchmark05(3.2911151863171995,45.49089534872169,-67.41108913867049 ) ;
  }

  @Test
  public void test4860() {
    coral.tests.JPFBenchmark.benchmark05(32.94728205125932,-80.7085843352337,1.0341792597968151 ) ;
  }

  @Test
  public void test4861() {
    coral.tests.JPFBenchmark.benchmark05(-3.3087224502121107E-24,-1.548487564453976,50.02556222043276 ) ;
  }

  @Test
  public void test4862() {
    coral.tests.JPFBenchmark.benchmark05(-3.3087224502121107E-24,-1.5707963267948961,-0.07433466685619779 ) ;
  }

  @Test
  public void test4863() {
    coral.tests.JPFBenchmark.benchmark05(-3.3087224502121107E-24,-48.21887194828636,-95.07719421915861 ) ;
  }

  @Test
  public void test4864() {
    coral.tests.JPFBenchmark.benchmark05(-3.3263663783049395,63.15843252185451,56.920734649093674 ) ;
  }

  @Test
  public void test4865() {
    coral.tests.JPFBenchmark.benchmark05(-3.334832609697028E-17,-35.758733660461914,-1.3897493572380413 ) ;
  }

  @Test
  public void test4866() {
    coral.tests.JPFBenchmark.benchmark05(-3.349646903531365,-35.98827219821332,-63.54501701603665 ) ;
  }

  @Test
  public void test4867() {
    coral.tests.JPFBenchmark.benchmark05(-3.3582113247794645E-14,-1.5707963267948966,-45.379387334113034 ) ;
  }

  @Test
  public void test4868() {
    coral.tests.JPFBenchmark.benchmark05(-3.374391146647928E-4,-42.41074146344599,-26.732717741122414 ) ;
  }

  @Test
  public void test4869() {
    coral.tests.JPFBenchmark.benchmark05(33.747189741612374,21.441917587998077,94.39131293776504 ) ;
  }

  @Test
  public void test4870() {
    coral.tests.JPFBenchmark.benchmark05(3.3748969423235593,80.19939441330578,27.11339048870478 ) ;
  }

  @Test
  public void test4871() {
    coral.tests.JPFBenchmark.benchmark05(-3.3881317890172014E-21,-0.07332921219506916,-35.969296799603484 ) ;
  }

  @Test
  public void test4872() {
    coral.tests.JPFBenchmark.benchmark05(3.3881317890172014E-21,-1.5707963267948966,20.691242544329725 ) ;
  }

  @Test
  public void test4873() {
    coral.tests.JPFBenchmark.benchmark05(33.938694770594736,79.12866889354578,75.7868214054474 ) ;
  }

  @Test
  public void test4874() {
    coral.tests.JPFBenchmark.benchmark05(-3.394775259457472E-17,-1.5707963267948966,15.626305669248847 ) ;
  }

  @Test
  public void test4875() {
    coral.tests.JPFBenchmark.benchmark05(3.4153499984674876E-15,-192.3384570919072,-75.52953782320078 ) ;
  }

  @Test
  public void test4876() {
    coral.tests.JPFBenchmark.benchmark05(-3.4247021078256297E-195,-1.5707963267948966,1.5707963267950615 ) ;
  }

  @Test
  public void test4877() {
    coral.tests.JPFBenchmark.benchmark05(34.32504262708636,58.96490864210912,-5.832779238765923 ) ;
  }

  @Test
  public void test4878() {
    coral.tests.JPFBenchmark.benchmark05(-3.434393228862903E-17,-1.5707963267948966,93.26268409113132 ) ;
  }

  @Test
  public void test4879() {
    coral.tests.JPFBenchmark.benchmark05(3.443507472970159,-1.5707963267948966,-1.2294338288775095 ) ;
  }

  @Test
  public void test4880() {
    coral.tests.JPFBenchmark.benchmark05(-3.4439697647622864,15.491369635604556,32.95253831957231 ) ;
  }

  @Test
  public void test4881() {
    coral.tests.JPFBenchmark.benchmark05(34.48550677865586,0.8165777655338502,-68.0482215268095 ) ;
  }

  @Test
  public void test4882() {
    coral.tests.JPFBenchmark.benchmark05(3.450765061450022,-34.94519945729768,-54.750941272599846 ) ;
  }

  @Test
  public void test4883() {
    coral.tests.JPFBenchmark.benchmark05(-3.452764505782241,79.20680300925994,-84.7588954076243 ) ;
  }

  @Test
  public void test4884() {
    coral.tests.JPFBenchmark.benchmark05(-34.53905854503378,82.95891789301186,-75.81588906996939 ) ;
  }

  @Test
  public void test4885() {
    coral.tests.JPFBenchmark.benchmark05(-3.469446951953614E-18,-1.5707963267948966,-97.4631338627096 ) ;
  }

  @Test
  public void test4886() {
    coral.tests.JPFBenchmark.benchmark05(3.4716234152960936,-43.143701662776614,-78.78759140665088 ) ;
  }

  @Test
  public void test4887() {
    coral.tests.JPFBenchmark.benchmark05(-3.4730605460704336E-164,-48.43168440064891,-1.5707963267948957 ) ;
  }

  @Test
  public void test4888() {
    coral.tests.JPFBenchmark.benchmark05(34.81109279963579,92.21330567670034,-52.1706658256043 ) ;
  }

  @Test
  public void test4889() {
    coral.tests.JPFBenchmark.benchmark05(-35.089262115902486,32.58286369743439,46.503229720953726 ) ;
  }

  @Test
  public void test4890() {
    coral.tests.JPFBenchmark.benchmark05(-3.515474723161873E-15,-1.5707963267948966,37.880898552851164 ) ;
  }

  @Test
  public void test4891() {
    coral.tests.JPFBenchmark.benchmark05(3.525587580151509,-23.8522870283699,92.40262315631307 ) ;
  }

  @Test
  public void test4892() {
    coral.tests.JPFBenchmark.benchmark05(-35.285129366347846,-85.14283054003877,-9.718864331221539 ) ;
  }

  @Test
  public void test4893() {
    coral.tests.JPFBenchmark.benchmark05(-3.5363167605016864E-15,-1.5707963267948966,53.18732718516725 ) ;
  }

  @Test
  public void test4894() {
    coral.tests.JPFBenchmark.benchmark05(-3.5378482666892337E-16,-1.5707963267948966,51.83628423372827 ) ;
  }

  @Test
  public void test4895() {
    coral.tests.JPFBenchmark.benchmark05(-3.5431328425922725E-16,-1.5707963267948966,-16.91222121251721 ) ;
  }

  @Test
  public void test4896() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-0.3484990150088123,1.5707963267948968 ) ;
  }

  @Test
  public void test4897() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.0799169937119217,16.066062246721287 ) ;
  }

  @Test
  public void test4898() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-117.27899239305806,-28.24242113945961 ) ;
  }

  @Test
  public void test4899() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948912,50.455992109734005 ) ;
  }

  @Test
  public void test4900() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test4901() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948963,-24.245408105985348 ) ;
  }

  @Test
  public void test4902() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948963,7.399393997925102 ) ;
  }

  @Test
  public void test4903() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948963,91.5914826130269 ) ;
  }

  @Test
  public void test4904() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,-0.23096357806704418 ) ;
  }

  @Test
  public void test4905() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,1.53200854304865 ) ;
  }

  @Test
  public void test4906() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,27.79193307852917 ) ;
  }

  @Test
  public void test4907() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-1.5707963267948966,40.92212988042944 ) ;
  }

  @Test
  public void test4908() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-2.220446049250313E-16,26.72766262033198 ) ;
  }

  @Test
  public void test4909() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-3.1415952158015883,-1.5707963267948966 ) ;
  }

  @Test
  public void test4910() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-34.59854357312764,21.470851695508344 ) ;
  }

  @Test
  public void test4911() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-3.6781872992791804,18.725807469406888 ) ;
  }

  @Test
  public void test4912() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-41.752702098367465,-41.9810894365501 ) ;
  }

  @Test
  public void test4913() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-47.70169406889051,-99.51742399000459 ) ;
  }

  @Test
  public void test4914() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-73.05520105375012,1.5707963267948983 ) ;
  }

  @Test
  public void test4915() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-73.79251845456741,-47.277644992892085 ) ;
  }

  @Test
  public void test4916() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-79.4582568891305,-0.41498921563427604 ) ;
  }

  @Test
  public void test4917() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-85.83364821348968,-44.405405804996526 ) ;
  }

  @Test
  public void test4918() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-8.881784197001252E-16,2352.0399769822016 ) ;
  }

  @Test
  public void test4919() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-91.79151684129646,-40.840704496667314 ) ;
  }

  @Test
  public void test4920() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-97.7039861420177,181.29653210040763 ) ;
  }

  @Test
  public void test4921() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800501E-15,-98.72264634605637,-74.20615421430074 ) ;
  }

  @Test
  public void test4922() {
    coral.tests.JPFBenchmark.benchmark05(-3.552713678800651E-15,-1.5707963267948966,13.445916636955886 ) ;
  }

  @Test
  public void test4923() {
    coral.tests.JPFBenchmark.benchmark05(-3.556413999176124E-161,-53.56340653851422,84.59882799972972 ) ;
  }

  @Test
  public void test4924() {
    coral.tests.JPFBenchmark.benchmark05(3.591239928092017,-3.1420818460891105,-1.5707963267948966 ) ;
  }

  @Test
  public void test4925() {
    coral.tests.JPFBenchmark.benchmark05(35.91866428639696,-83.55777814405681,-21.88703502193256 ) ;
  }

  @Test
  public void test4926() {
    coral.tests.JPFBenchmark.benchmark05(36.1500032218525,-45.93043137101005,69.59915415353186 ) ;
  }

  @Test
  public void test4927() {
    coral.tests.JPFBenchmark.benchmark05(36.18207241030288,-75.30179966333897,11.568430972828224 ) ;
  }

  @Test
  public void test4928() {
    coral.tests.JPFBenchmark.benchmark05(-3.6280449161469077E-9,-41.398180954267595,-38.02318538359928 ) ;
  }

  @Test
  public void test4929() {
    coral.tests.JPFBenchmark.benchmark05(-3.6440416813245225E-17,-1.5707963267948966,-13.415198497683662 ) ;
  }

  @Test
  public void test4930() {
    coral.tests.JPFBenchmark.benchmark05(36.51927554135824,37.36079564258259,57.94854570034963 ) ;
  }

  @Test
  public void test4931() {
    coral.tests.JPFBenchmark.benchmark05(3.668643355836481,-3.4912036725841773,-16.04918601825644 ) ;
  }

  @Test
  public void test4932() {
    coral.tests.JPFBenchmark.benchmark05(-36.7275620358916,8.579868076919524,-42.98639810808125 ) ;
  }

  @Test
  public void test4933() {
    coral.tests.JPFBenchmark.benchmark05(36.99778883451873,6.137773241090883,25.417358253311576 ) ;
  }

  @Test
  public void test4934() {
    coral.tests.JPFBenchmark.benchmark05(3.7003188505585007,-1.5707963267948966,-125.69070639742847 ) ;
  }

  @Test
  public void test4935() {
    coral.tests.JPFBenchmark.benchmark05(-37.068602894259264,45.1244398769372,-67.28811074002199 ) ;
  }

  @Test
  public void test4936() {
    coral.tests.JPFBenchmark.benchmark05(-37.09896851867796,-23.100884535014615,94.7766621682866 ) ;
  }

  @Test
  public void test4937() {
    coral.tests.JPFBenchmark.benchmark05(-3.7157183472200404E-16,-1.5707963267948966,-1.5707963261711086 ) ;
  }

  @Test
  public void test4938() {
    coral.tests.JPFBenchmark.benchmark05(-37.19042472810159,-29.872117207886163,26.57859738392206 ) ;
  }

  @Test
  public void test4939() {
    coral.tests.JPFBenchmark.benchmark05(-37.21276743054318,-98.97430749886328,-2.4831046422554124 ) ;
  }

  @Test
  public void test4940() {
    coral.tests.JPFBenchmark.benchmark05(-3.7337272815280773E-16,-1.5707963267948966,31.187537900391753 ) ;
  }

  @Test
  public void test4941() {
    coral.tests.JPFBenchmark.benchmark05(-37.44792569204274,34.52608902669303,-73.55130399777315 ) ;
  }

  @Test
  public void test4942() {
    coral.tests.JPFBenchmark.benchmark05(-3.7492420347390774E-242,-0.006009392259297494,8.157868937717407 ) ;
  }

  @Test
  public void test4943() {
    coral.tests.JPFBenchmark.benchmark05(-37.57967454426723,-72.75365853472537,33.88006911292655 ) ;
  }

  @Test
  public void test4944() {
    coral.tests.JPFBenchmark.benchmark05(-37.61097623369389,-38.58245944957752,0.042155408594751975 ) ;
  }

  @Test
  public void test4945() {
    coral.tests.JPFBenchmark.benchmark05(37.89738402569418,-27.000602717772964,-22.911932676888398 ) ;
  }

  @Test
  public void test4946() {
    coral.tests.JPFBenchmark.benchmark05(-3.8097435478668744E-8,-0.14221056429014178,116.36143926737452 ) ;
  }

  @Test
  public void test4947() {
    coral.tests.JPFBenchmark.benchmark05(38.19376187460193,94.88825311845969,31.986717214853996 ) ;
  }

  @Test
  public void test4948() {
    coral.tests.JPFBenchmark.benchmark05(38.31383287679208,64.70838964262765,42.29650463340457 ) ;
  }

  @Test
  public void test4949() {
    coral.tests.JPFBenchmark.benchmark05(-38.38696889839777,75.94667560145345,-98.7737317704305 ) ;
  }

  @Test
  public void test4950() {
    coral.tests.JPFBenchmark.benchmark05(-3.8392238435728152E-239,-1.5707963267948966,-0.3020749543721846 ) ;
  }

  @Test
  public void test4951() {
    coral.tests.JPFBenchmark.benchmark05(3.8537212398414975,-2.1684043449710089E-19,-94.70649875922975 ) ;
  }

  @Test
  public void test4952() {
    coral.tests.JPFBenchmark.benchmark05(-3.877332915473687E-4,-1.5707963267948966,54.269527307185946 ) ;
  }

  @Test
  public void test4953() {
    coral.tests.JPFBenchmark.benchmark05(-39.00146370462858,38.16904101093306,-68.38939315138894 ) ;
  }

  @Test
  public void test4954() {
    coral.tests.JPFBenchmark.benchmark05(-39.073225692348615,16.839264345363446,18.23139747671381 ) ;
  }

  @Test
  public void test4955() {
    coral.tests.JPFBenchmark.benchmark05(39.281984322175106,84.68712164453706,54.877551690589115 ) ;
  }

  @Test
  public void test4956() {
    coral.tests.JPFBenchmark.benchmark05(-39.31024837138865,53.26399427459506,93.25488114569669 ) ;
  }

  @Test
  public void test4957() {
    coral.tests.JPFBenchmark.benchmark05(-39.35926480730614,16.100424358094088,-82.99276592785381 ) ;
  }

  @Test
  public void test4958() {
    coral.tests.JPFBenchmark.benchmark05(39.41440630644868,-48.8605116273759,-57.75965508070628 ) ;
  }

  @Test
  public void test4959() {
    coral.tests.JPFBenchmark.benchmark05(-3.9484127069845653E-177,-48.38742122471804,100.0 ) ;
  }

  @Test
  public void test4960() {
    coral.tests.JPFBenchmark.benchmark05(39.71386365234929,89.48891946169539,4.281297338066679 ) ;
  }

  @Test
  public void test4961() {
    coral.tests.JPFBenchmark.benchmark05(39.7162406543072,-40.69327252163526,17.08651951911054 ) ;
  }

  @Test
  public void test4962() {
    coral.tests.JPFBenchmark.benchmark05(-3.9779288370720056E-9,-1.5707963267948966,-132.0203402097325 ) ;
  }

  @Test
  public void test4963() {
    coral.tests.JPFBenchmark.benchmark05(-40.21500596425085,-46.43117564163284,-93.02040671790917 ) ;
  }

  @Test
  public void test4964() {
    coral.tests.JPFBenchmark.benchmark05(-4.025128356871971E-4,-9.614915814376594,-6.429243184442734 ) ;
  }

  @Test
  public void test4965() {
    coral.tests.JPFBenchmark.benchmark05(-40.29078342959149,-55.65323312403419,31.56850774063608 ) ;
  }

  @Test
  public void test4966() {
    coral.tests.JPFBenchmark.benchmark05(40.38595503453661,1.3424385975528992,91.71983745780685 ) ;
  }

  @Test
  public void test4967() {
    coral.tests.JPFBenchmark.benchmark05(-4.0389678347315804E-28,-97.75302896128275,95.34680507656509 ) ;
  }

  @Test
  public void test4968() {
    coral.tests.JPFBenchmark.benchmark05(40.43044208899778,-30.883751867149684,-86.81258729386492 ) ;
  }

  @Test
  public void test4969() {
    coral.tests.JPFBenchmark.benchmark05(-4.0437525138388875E-4,-161.7496063964078,142.5989352940297 ) ;
  }

  @Test
  public void test4970() {
    coral.tests.JPFBenchmark.benchmark05(-4.079767055079378E-14,-42.1889085711416,-73.16035879746455 ) ;
  }

  @Test
  public void test4971() {
    coral.tests.JPFBenchmark.benchmark05(4.086786774342627,-17.12248662871272,83.13494535670216 ) ;
  }

  @Test
  public void test4972() {
    coral.tests.JPFBenchmark.benchmark05(40.928489276405315,64.22932650512288,76.9719256405892 ) ;
  }

  @Test
  public void test4973() {
    coral.tests.JPFBenchmark.benchmark05(-4.112600495221537E-12,-35.459432632165566,-175.6783841591558 ) ;
  }

  @Test
  public void test4974() {
    coral.tests.JPFBenchmark.benchmark05(-41.42768686494917,53.6046462458294,58.835490382439076 ) ;
  }

  @Test
  public void test4975() {
    coral.tests.JPFBenchmark.benchmark05(-41.586248638605625,82.43691556822264,29.8387944919412 ) ;
  }

  @Test
  public void test4976() {
    coral.tests.JPFBenchmark.benchmark05(-41.723065978185204,-85.7888919278221,72.79094234336549 ) ;
  }

  @Test
  public void test4977() {
    coral.tests.JPFBenchmark.benchmark05(-4.173331424796258E-16,-1.4070106457695104,-2265.3413897974633 ) ;
  }

  @Test
  public void test4978() {
    coral.tests.JPFBenchmark.benchmark05(-4.2006682124568694E-15,-1.5707963267948966,-11.952785302961715 ) ;
  }

  @Test
  public void test4979() {
    coral.tests.JPFBenchmark.benchmark05(-4.202978710922204E-15,-73.19492955762158,-1.5707963267948966 ) ;
  }

  @Test
  public void test4980() {
    coral.tests.JPFBenchmark.benchmark05(42.287956646906565,65.33825166174006,73.3807842601596 ) ;
  }

  @Test
  public void test4981() {
    coral.tests.JPFBenchmark.benchmark05(-4.2351647362715017E-22,-0.033970069893247905,0.0 ) ;
  }

  @Test
  public void test4982() {
    coral.tests.JPFBenchmark.benchmark05(-4.2351647362715017E-22,-1.5664310270879416,-1.5707963267948966 ) ;
  }

  @Test
  public void test4983() {
    coral.tests.JPFBenchmark.benchmark05(-4.2351647362715017E-22,-48.28232708287297,1.5707963267948966 ) ;
  }

  @Test
  public void test4984() {
    coral.tests.JPFBenchmark.benchmark05(42.85809778121313,-30.60379052261996,66.74939691853405 ) ;
  }

  @Test
  public void test4985() {
    coral.tests.JPFBenchmark.benchmark05(-43.25993293391295,34.17759958669427,-42.545898641598214 ) ;
  }

  @Test
  public void test4986() {
    coral.tests.JPFBenchmark.benchmark05(43.300096735516775,-68.55365172811341,-66.64627707617272 ) ;
  }

  @Test
  public void test4987() {
    coral.tests.JPFBenchmark.benchmark05(4.3368086899420177E-19,-0.47336179091652564,-45.2249538446174 ) ;
  }

  @Test
  public void test4988() {
    coral.tests.JPFBenchmark.benchmark05(-4.3368086899420177E-19,-1.5707963267948966,26.184794239894416 ) ;
  }

  @Test
  public void test4989() {
    coral.tests.JPFBenchmark.benchmark05(-4.3368086899420177E-19,-1.5707963267948966,89.53545167261304 ) ;
  }

  @Test
  public void test4990() {
    coral.tests.JPFBenchmark.benchmark05(-4.3368086899420177E-19,-35.33427947534052,-58.90987202889246 ) ;
  }

  @Test
  public void test4991() {
    coral.tests.JPFBenchmark.benchmark05(-43.7184002743229,-86.25101542030774,-12.759719830003462 ) ;
  }

  @Test
  public void test4992() {
    coral.tests.JPFBenchmark.benchmark05(43.805073897175504,-46.99322649277802,-20.164277007103323 ) ;
  }

  @Test
  public void test4993() {
    coral.tests.JPFBenchmark.benchmark05(-43.91125745895814,-74.26820124860294,98.8678459166174 ) ;
  }

  @Test
  public void test4994() {
    coral.tests.JPFBenchmark.benchmark05(-44.21191263738551,75.12429919452558,31.141415246679827 ) ;
  }

  @Test
  public void test4995() {
    coral.tests.JPFBenchmark.benchmark05(44.30401724831816,-91.64965710743964,27.35553347702428 ) ;
  }

  @Test
  public void test4996() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-0.21724905882587886,35.322688971476346 ) ;
  }

  @Test
  public void test4997() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-0.766545598024372,-15.192105245355393 ) ;
  }

  @Test
  public void test4998() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-0.964981442167442,-37.4284092565897 ) ;
  }

  @Test
  public void test4999() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.1871873700529496,75.61082151263571 ) ;
  }

  @Test
  public void test5000() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.5707963267948948,867.0065903253034 ) ;
  }

  @Test
  public void test5001() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.5707963267948966,-1.3556708720262842 ) ;
  }

  @Test
  public void test5002() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.5707963267948966,21.402958082313962 ) ;
  }

  @Test
  public void test5003() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.5707963267948966,2.710505431213761E-20 ) ;
  }

  @Test
  public void test5004() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-1.570796326794897,-0.06008415736553326 ) ;
  }

  @Test
  public void test5005() {
    coral.tests.JPFBenchmark.benchmark05(-4.440892098500626E-16,-53.93451569927554,-41.34561128709422 ) ;
  }

  @Test
  public void test5006() {
    coral.tests.JPFBenchmark.benchmark05(44.42845531292045,-49.07069899205803,75.87631218893097 ) ;
  }

  @Test
  public void test5007() {
    coral.tests.JPFBenchmark.benchmark05(-4.445517498970155E-162,-1.5707963267948966,-77.41737527451973 ) ;
  }

  @Test
  public void test5008() {
    coral.tests.JPFBenchmark.benchmark05(-4.4623613132372036E-14,-9.860761315262648E-32,4.557206403435828 ) ;
  }
}
